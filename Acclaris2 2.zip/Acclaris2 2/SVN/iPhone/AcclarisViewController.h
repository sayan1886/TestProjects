//
//  AcclarisViewController.h
//  Acclaris
//
//  Created by Objectsol5 on 23/09/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "request.h"
#import "AcclarisAppDelegate.h"
#import "MyTools.h"

@interface AcclarisViewController : UIViewController <UITextFieldDelegate>{

	MyTools *tools;
	UIView *loadingView;

	UITextField	*txtf_UserName;
	AcclarisAppDelegate *app;
	NSMutableArray *userinfo;
	UIButton *btn_Remember_Me;

	NSString *linkappDwnld;
	bool changed; 
	NSArray *uploadItems1;
}

//+(NSString *)Get_UserName;
-(void)pusttoPassscreen;
//+(NSString *)userName;
-(void)savedata;
-(void)getdata;
+(NSString *)userName;
+(NSMutableArray *)staticarr_config;
-(NSString *)formatString:(NSString *)Uname;


@end

