//
//  PaynowOBJ.m
//  Acclaris
//
//  Created by Subhojit on 22/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "PaynowOBJ.h"


@implementation PaynowOBJ

@synthesize strid,
streeID,
strClaimCategory,
strClaimAmt,
strserviceBegins,
strserviceEnds,
strstrprevYearPlanInd,
strproviderID,
strproviderName,
strexternalCode,
strexternalID,
strerrorText,
strreturnCode,strClaimType;
@synthesize arr;
@end
