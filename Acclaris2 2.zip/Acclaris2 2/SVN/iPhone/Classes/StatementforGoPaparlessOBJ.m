//
//  StatementforGoPaparlessOBJ.m
//  Acclaris
//
//  Created by Subhojit on 12/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "StatementforGoPaparlessOBJ.h"


@implementation StatementforGoPaparlessOBJ
@synthesize strname,strlabel,arrselectoption;
@end
