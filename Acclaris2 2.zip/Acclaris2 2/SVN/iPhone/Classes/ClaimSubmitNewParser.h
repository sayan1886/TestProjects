//
//  ClaimSubmitNewParser.h
//  Acclaris
//
//  Created by Subhojit on 25/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ClaimSubmitNewOBJ.h"
#import "ClaimSubOBJ.h"


@interface ClaimSubmitNewParser : NSObject<NSXMLParserDelegate> {

	NSMutableString *contentOfString;
	ClaimSubmitNewOBJ *objclaimsubmitnewOBJ;
	ClaimSubOBJ *objClaimSubOBJ;
	BOOL istype;

	
}
+(NSMutableArray *)getarrCatagory;
+(NSMutableArray *)getarrsubCatagory;
+(NSMutableArray *)getarrm_passArray;
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error;
@end
