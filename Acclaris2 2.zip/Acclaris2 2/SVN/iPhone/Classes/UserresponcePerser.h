//
//  UserresponcePerser.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 02/10/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AcclarisAppDelegate.h"
@class errorcodeOBJ;

@interface UserresponcePerser : NSObject<NSXMLParserDelegate> {

	AcclarisAppDelegate *app;
	NSMutableString *contentOfString;
	errorcodeOBJ *myerrorcodeOBJ;
	NSMutableArray *errordetails;
	NSMutableArray *buildinfo;
}
+(NSMutableArray *)userdesc;
+(NSString *)userName;
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error;
@end
