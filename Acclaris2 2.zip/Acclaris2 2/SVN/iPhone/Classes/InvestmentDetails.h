//
//  InvestmentDetails.h
//  Acclaris
//
//  Created by Sumit Kr Prasad on 31/12/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "configurables.h"

@interface InvestmentDetails : NSObject 
{
	NSArray *arr_celltytle,*arr_celldetails;
	configurables *con;
	NSMutableArray *arr_alltransaction;
}

@end
