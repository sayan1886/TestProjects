//
//  ClaimonlineSaveOBJ.h
//  Acclaris
//
//  Created by Subhojit on 31/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface ClaimonlineSaveOBJ : NSObject {

	NSString *strreturnCode;
	NSString *strerrorText;
	NSString *strclaimCategory;
	NSString *strclaimType;
	NSString *stramount;
	NSString *strserviceBeginDt;
	NSString *strserviceEndDt;
	NSString *strnote;
	NSString *strisPriorYear;
	NSString *strpayMode;
	NSString *strmultipleAcct;
	
}
@property(nonatomic,retain)NSString *strreturnCode;
@property(nonatomic,retain)NSString *strerrorText;
@property(nonatomic,retain)NSString *strclaimCategory;
@property(nonatomic,retain)NSString *strclaimType;
@property(nonatomic,retain)NSString *stramount;
@property(nonatomic,retain)NSString *strserviceBeginDt;
@property(nonatomic,retain)NSString *strserviceEndDt;
@property(nonatomic,retain)NSString *strnote;
@property(nonatomic,retain)NSString *strisPriorYear;
@property(nonatomic,retain)NSString *strpayMode;
@property(nonatomic,retain)NSString *strmultipleAcct;
@end
