//
//  request.m
//  Trail
//
//  Created by mmandal on 02/10/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//
#import "AcclarisAppDelegate.h"
#import "request.h"
#import "SSCrypto.h"
#import "DateFormate.h"
#import "UserresponcePerser.h"
#import "AcclarisViewController.h"
#import "SignIn.h"
#import "accPerser.h"
#import "AccountDetails.h"
#import "transactionPerser.h"
#import "passPerser.h"
#import "ticketPerser.h"
#import "ticketupdatePerser.h"
#import "ticketclosePerser.h"
#import "ticketTypePerser.h"
#import "claimactivityPerser.h"
#import "configurableParser.h"
#import "imagePerser.h"
#import "alertParser.h"
#import "InvestmentParser.h"
#import "errorResponseAlert.h"


@implementation request


-(id)initWithTarget:(id)actionTarget
	  SuccessAction:(SEL)successAction 
	  FailureAction:(SEL)failureAction
{
	self=[super init];
	if(self==nil)
	{
		return nil;
	}
	
	target=actionTarget;
	successHandler=successAction;
	failureHandler=failureAction;
	

	return self;
}
#pragma mark CREATE HEADER
-(NSMutableString *)createHeader
{
	NSMutableString *header=[[NSMutableString alloc] init];
	[header appendString:@"<?xml version=\"1.0\" encoding=\"utf-8\" ?>"];
	[header appendString:@"<soapenv:Envelope xmlns:ser=\"http://www.acclaris.com/servicetypesma\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">"];
	[header appendString:@"<soapenv:Header><wsse:Security soapenv:mustUnderstand=\"1\" xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\">"];
	[header appendString:@"<wsse:UsernameToken wsu:Id=\"UsernameToken-28376915\" xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">"];
	[header appendString:@"<wsse:Username>objectsolwsuser</wsse:Username>"];
	[header appendString:@"<wsse:Password Type=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordDigest\">"];
	
	SSCrypto *crypto = [ [ SSCrypto alloc ] init ];
	
	NSTimeInterval t = [ [ NSDate date ] timeIntervalSince1970 ];
	NSString * nonce = [ [ NSNumber numberWithDouble:t ] stringValue];
	
	[ crypto setClearTextWithString:nonce ];
	NSString *base64nonce = [ [ crypto clearTextAsData ] encodeBase64WithNewlines:NO ];
	
	//NSString *created = [ DateFormate stringFromDate:[ NSDate date ] ];
	
	
	NSString *created =[self getUTCFormateDate:[ NSDate date]];
	
	
	NSString *combined = [ NSString stringWithFormat:@"%@%@%@", nonce, created, @"local123" ];
	[ crypto setClearTextWithString:combined ];
	NSString *passwordDigest = [ [crypto digest:@"SHA1" ] encodeBase64WithNewlines:NO ];
	[header appendString:passwordDigest];
	[header appendString:@"</wsse:Password><wsse:Nonce>"];
	[header appendString:base64nonce];
	[header appendString:@"</wsse:Nonce><wsu:Created>"];
	[header appendString:created];
	[header appendString:@"</wsu:Created></wsse:UsernameToken></wsse:Security></soapenv:Header>"];
	
	return header;
}

-(NSString *)getUTCFormateDate:(NSDate *)localDate
{
	NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
	NSTimeZone *timeZone = [NSTimeZone timeZoneWithName:@"UTC"];
	[dateFormatter setTimeZone:timeZone];
	[dateFormatter setDateFormat:@"YYYY-MM-dd'T'HH:mm:ss.S"];
	NSString *dateString = [dateFormatter stringFromDate:localDate];
	
	return dateString;
}

#pragma mark -
#pragma mark serverconnection
-(void)senduserRequest:(NSString *)user
{
	
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	else
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
		
	whichAPI=@"senduserName";
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader];
	[sRequest appendString:@"<soapenv:Body><ser:GetLoginInfoMA><ser:userName>"];
	[sRequest appendString:	user];
	[sRequest appendString:@"</ser:userName><ser:IMEI/><ser:param1/><ser:clientName>Mobile</ser:clientName><ser:phoneType>iPhone</ser:phoneType><ser:param2/><ser:param3/><ser:param4/></ser:GetLoginInfoMA></soapenv:Body></soapenv:Envelope>"];
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	link=[link stringByAppendingString:@"GetLoginInfoMAService"];
	[self callPostMethod:sRequest Action:@"GetLoginInfoMA" API:link];
	
	
}

-(void)sendcdonfigRequest:(NSString *)user
{
	
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	else
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	whichAPI=@"GetAppConfigurableItemsMA";
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader];
	[sRequest appendString:@"<soapenv:Body><ser:GetAppConfigurableItemsMA><ser:userName>"];
	[sRequest appendString:	user];
	[sRequest appendString:@"</ser:userName><ser:phoneType>iPhone</ser:phoneType><ser:model/><ser:param1/><ser:param2/><ser:param3/><ser:param4/></ser:GetAppConfigurableItemsMA></soapenv:Body></soapenv:Envelope>"];
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	link=[link stringByAppendingString:@"GetAppConfigurableItemsMAService"];
	[self callPostMethod:sRequest Action:@"GetAppConfigurableItemsMA" API:link];

}

-(void)sendpassRequest:(NSString *)user pass:(NSString *)password
{
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	else
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	
	whichAPI=@"senduserPass";
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader];
	[sRequest appendString:@"<soapenv:Body><ser:AuthenticateUserMA><ser:userName>"];
	[sRequest appendString:user];//append Username
	[sRequest appendString:@"</ser:userName><ser:password>"];
	[sRequest appendString:password];//append Password
	[sRequest appendString:@"</ser:password><ser:clientName>Mobile</ser:clientName><ser:param1/><ser:param2/><ser:param3/><ser:param4/></ser:AuthenticateUserMA></soapenv:Body></soapenv:Envelope>"];
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	link=[link stringByAppendingString:@"AuthenticateUserMAService"];
	[self callPostMethod:sRequest Action:@"AuthenticateUserMA" API:link];
	
}
-(void)sendaccountRequest:(NSString *)pId userid:(NSString *)uId
{
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	else
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	whichAPI=@"sendaccountRequest";
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	//NSMutableArray *userinfo_arr=[passPerser passresponce];//static method fired
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader];
	[sRequest appendString:@"<soapenv:Body><ser:GetAccountInfoMA><ser:participantID>"];
	[sRequest appendString:pId];//[userinfo_arr objectAtIndex:2]];//participant ID
	[sRequest appendString:@"</ser:participantID><ser:userID>"];
	[sRequest appendString:uId];//[userinfo_arr objectAtIndex:4]];//User ID
	[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType><ser:participantCode/><ser:clientName>Mobile</ser:clientName><ser:param1/><ser:param2/><ser:param3/><ser:param4/></ser:GetAccountInfoMA></soapenv:Body></soapenv:Envelope>"];
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	link=[link stringByAppendingString:@"GetAccountInfoMAService"];
	[self callPostMethod:sRequest Action:@"GetAccountInfoMA" API:link];
	
	
}



// This Is the code for Investment HSA type (FOR SUMIT)
-(void)sendHSA_InvestmenttransactionRequest:(NSString *)pId userid:(NSString *)uId election:(NSString *)eId actype:(NSString *)actyp startid:(NSString *)strid
{
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	else
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	whichAPI=@"sendHSA_InvestmenttransactionRequest";
	
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader];
	[sRequest appendString:@"<soapenv:Body><ser:GetInvestmentActivityMA><ser:participantID>"];
	[sRequest appendString:pId];
	[sRequest appendString:@"</ser:participantID><ser:participantCode>"];
	[sRequest appendString:@""];//Replace If Necessary
	[sRequest appendString:@"</ser:participantCode><ser:userID>"];
	[sRequest appendString:uId];
	[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType><ser:elctID>"];
	[sRequest appendString:eId];
	[sRequest appendString:@"</ser:elctID>"];//<ser:accountTypeCode>"];
	//[sRequest appendString:actyp];
	//[sRequest appendString:@"</ser:accountTypeCode>
	[sRequest appendString:@"<ser:startDate>"];
	[sRequest appendString:@""];//Replace with StartDate
	[sRequest appendString:@"</ser:startDate><ser:endDate>"];
	[sRequest appendString:@""];//Replace with EndDate
	[sRequest appendString:@"</ser:endDate><ser:transactionType>"];
	[sRequest appendString:@"All"];//Replace If Necessary
	[sRequest appendString:@"</ser:transactionType><ser:transactionStatus>"];
	[sRequest appendString:@"All"];//Replace If Necessary
	[sRequest appendString:@"</ser:transactionStatus><ser:noOfRecords>10</ser:noOfRecords><ser:startAfterSeqID>"];
	[sRequest appendString:strid];
	[sRequest appendString:@"</ser:startAfterSeqID><ser:clientName>Mobile</ser:clientName><ser:param1/><ser:param2/><ser:param3/><ser:param4/></ser:GetInvestmentActivityMA></soapenv:Body></soapenv:Envelope>"];
		
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	link=[link stringByAppendingString:@"GetInvestmentActivityMAService"];
	[self callPostMethod:sRequest Action:@"GetInvestmentActivityMA" API:link];
	
}



-(void)sendtransactionRequest:(NSString *)pId userid:(NSString *)uId election:(NSString *)eId actype:(NSString *)actyp startid:(NSString *)strid
{
	
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	else
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	whichAPI=@"sendtransactionRequest";
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	//NSMutableArray *userinfo_arr=[passPerser passresponce];//static method fired
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader];
	[sRequest appendString:@"<soapenv:Body><ser:GetTransactionsMA><ser:participantID>"];
	[sRequest appendString:pId];
	[sRequest appendString:@"</ser:participantID><ser:userID>"];
	[sRequest appendString:uId];
	[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType><ser:electionID>"];
	[sRequest appendString:eId];//[AccountDetails electionID]];//
	[sRequest appendString:@"</ser:electionID><ser:accountTypeCode>"];
	[sRequest appendString:actyp];//[AccountDetails acType]];//
	[sRequest appendString:@"</ser:accountTypeCode><ser:noOfRecords>10</ser:noOfRecords><ser:startAfterSeqID>"];
	[sRequest appendString:strid];
	[sRequest appendString:@"</ser:startAfterSeqID><ser:participantCode/><ser:clientName>Mobile</ser:clientName><ser:param1/><ser:param2/><ser:param3/><ser:param4/></ser:GetTransactionsMA></soapenv:Body></soapenv:Envelope>"];
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	link=[link stringByAppendingString:@"GetTransactionsMAService"];
	[self callPostMethod:sRequest Action:@"GetTransactionsMA" API:link];
}
-(void)sendticketRequest:(NSString *)startAfterSeqID participentid:(NSString *)pId userid:(NSString *)uId
{
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	else
		
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	whichAPI=@"sendticketRequest";
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader];
	[sRequest appendString:@"<soapenv:Body><ser:GetTicketsMA><ser:participantID>"];
	[sRequest appendString:pId];
	[sRequest appendString:@"</ser:participantID><ser:userID>"];
	[sRequest appendString:uId];
	[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType><ser:status/><ser:participantCode/>"];
	[sRequest appendString:@"<ser:noOfRec>10</ser:noOfRec><ser:startAfterSeqID>"];
	[sRequest appendString:startAfterSeqID];
	[sRequest appendString:@"</ser:startAfterSeqID><ser:clientName>Mobile</ser:clientName><ser:param1/><ser:param2/><ser:param3/><ser:param4/></ser:GetTicketsMA></soapenv:Body></soapenv:Envelope>"];
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	link=[link stringByAppendingString:@"GetTicketsMAService"];
	[self callPostMethod:sRequest Action:@"GetTicketsMA" API:link];
}
-(void)sendcloseMSGRequest:(NSString *)ticketType description:(NSString *)desc tickitcatagory:(NSString *)tcatagory tid:(NSString *)tID
{
	
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	else
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	whichAPI=@"sendticketCloseRequest";
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	NSMutableArray *userinfo_arr=[passPerser passresponce];//static method fired
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader];
	[sRequest appendString:@"<soapenv:Body><ser:TicketOperationMA><ser:participantID>"];
	[sRequest appendString:[userinfo_arr objectAtIndex:2]];
	[sRequest appendString:@"</ser:participantID><ser:operationType>R</ser:operationType><ser:ticketType>"];
	[sRequest appendString:ticketType];
	[sRequest appendString:@"</ser:ticketType><ser:description><![CDATA["];
	[sRequest appendString:desc];
	[sRequest appendString:@"]]></ser:description><ser:participantCode/><ser:userID>"];
	[sRequest appendString:[userinfo_arr objectAtIndex:4]];
	[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType><ser:ticketCategory>"];
	[sRequest appendString:tcatagory];
	[sRequest appendString:@"</ser:ticketCategory><ser:tktID>"];
	[sRequest appendString:tID];
	[sRequest appendString:@"</ser:tktID><ser:status/>"];
	[sRequest appendString:@"<ser:clientName>Mobile</ser:clientName><ser:param1/><ser:param2/><ser:param3/><ser:param4/></ser:TicketOperationMA></soapenv:Body></soapenv:Envelope>"];
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	link=[link stringByAppendingString:@"TicketOperationMAService"];
	[self callPostMethod:sRequest Action:@"TicketOperationMA" API:link];
}
-(void)sendupdateMSGRequest:(NSString *)ticketType description:(NSString *)desc tickitcatagory:(NSString *)tcatagory tid:(NSString *)tID
{
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	else
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	whichAPI=@"sendticketUpdateRequest";
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	NSMutableArray *userinfo_arr=[passPerser passresponce];//static method fired
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader];
	[sRequest appendString:@"<soapenv:Body><ser:TicketOperationMA><ser:participantID>"];
	[sRequest appendString:[userinfo_arr objectAtIndex:2]];
	[sRequest appendString:@"</ser:participantID><ser:operationType>A</ser:operationType><ser:ticketType>"];
	[sRequest appendString:ticketType];
	[sRequest appendString:@"</ser:ticketType><ser:description><![CDATA["];
	[sRequest appendString:desc];
	[sRequest appendString:@"]]></ser:description><ser:participantCode/><ser:userID>"];
	[sRequest appendString:[userinfo_arr objectAtIndex:4]];
	[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType><ser:ticketCategory>"];
	[sRequest appendString:tcatagory];
	[sRequest appendString:@"</ser:ticketCategory><ser:tktID>"];
	[sRequest appendString:tID];
	[sRequest appendString:@"</ser:tktID><ser:status/>"];
	[sRequest appendString:@"<ser:clientName>Mobile</ser:clientName><ser:param1/><ser:param2/><ser:param3/><ser:param4/></ser:TicketOperationMA></soapenv:Body></soapenv:Envelope>"];
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	link=[link stringByAppendingString:@"TicketOperationMAService"];
	[self callPostMethod:sRequest Action:@"TicketOperationMA" API:link];
}

-(void)newticketTypeRequest
{
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	else
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	whichAPI=@"newticketRequest";
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	NSMutableArray *userinfo_arr=[passPerser passresponce];//static method fired
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader];
	[sRequest appendString:@"<soapenv:Body><ser:GetTicketTypesMA><ser:participantID>"];
	[sRequest appendString:[userinfo_arr objectAtIndex:2]];
	[sRequest appendString:@"</ser:participantID><ser:participantCode/><ser:category>Employee</ser:category><ser:admnID/><ser:erID/>"];
	[sRequest appendString:@"<ser:clientName>Mobile</ser:clientName><ser:param1/><ser:param2/><ser:param3/><ser:param4/></ser:GetTicketTypesMA></soapenv:Body></soapenv:Envelope>"];
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	link=[link stringByAppendingString:@"GetTicketTypesMAService"];
	[self callPostMethod:sRequest Action:@"ser:GetTicketTypesMA" API:link];
}
-(void)newticketRequest:(NSString *)lbl description:(NSString *)desc
{
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	else
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	whichAPI=@"newticketRequest";
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	NSMutableArray *userinfo_arr=[passPerser passresponce];//static method fired
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader];
	[sRequest appendString:@"<soapenv:Body><ser:TicketOperationMA><ser:participantID>"];
	[sRequest appendString:[userinfo_arr objectAtIndex:2]];
	[sRequest appendString:@"</ser:participantID><ser:operationType>N</ser:operationType><ser:ticketType>"];
	[sRequest appendString:lbl];
	[sRequest appendString:@"</ser:ticketType><ser:description><![CDATA["];
	[sRequest appendString:desc];
	[sRequest appendString:@"]]></ser:description><ser:participantCode/><ser:userID>"];
	[sRequest appendString:[userinfo_arr objectAtIndex:4]];
	[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType><ser:ticketCategory>Employee</ser:ticketCategory><ser:tktID/><ser:status/>"];
	[sRequest appendString:@"<ser:clientName>Mobile</ser:clientName><ser:param1/><ser:param2/><ser:param3/><ser:param4/></ser:TicketOperationMA></soapenv:Body></soapenv:Envelope>"];
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	link=[link stringByAppendingString:@"TicketOperationMAService"];
	[self callPostMethod:sRequest Action:@"ser:TicketOperationMA" API:link];
}
-(void)claimactivityRequest:(NSString *)startAfterSeqID participentid:(NSString *)pId userid:(NSString *)uId receiptRequired:(NSString *)rr receiptRequiredType:(NSString *)rrt
{
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	else
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	whichAPI=@"claimactivityRequest";
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	//NSMutableArray *userinfo_arr=[passPerser passresponce];//static method fired
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader];
	[sRequest appendString:@"<soapenv:Body><ser:GetClaimActivitiesMA><ser:participantID>"];
	[sRequest appendString:pId];
	[sRequest appendString:@"</ser:participantID><ser:participantCode/><ser:userID>"];
	[sRequest appendString:uId];
	[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType><ser:elctID/><ser:claimSource>All</ser:claimSource><ser:receiptRequired>"];
	[sRequest appendString:rr];
	[sRequest appendString:@"</ser:receiptRequired><ser:receiptRequiredType>"];
	[sRequest appendString:rrt];
	[sRequest appendString:@"</ser:receiptRequiredType><ser:noOfRec>10</ser:noOfRec><ser:startAfterSeqID>"];
	[sRequest appendString:startAfterSeqID];
	[sRequest appendString:@"</ser:startAfterSeqID>"];
	[sRequest appendString:@"<ser:clientName>Mobile</ser:clientName><ser:param1/><ser:param2/><ser:param3/><ser:param4/></ser:GetClaimActivitiesMA></soapenv:Body></soapenv:Envelope>"];
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	link=[link stringByAppendingString:@"GetClaimActivitiesMAService"];
	[self callPostMethod:sRequest Action:@"ser:GetClaimActivitiesMA" API:link];
}
-(void)pendingpassthru:(NSString *)pId userid:(NSString *)uId startid:(NSString *)strid
{
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	else
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	whichAPI=@"passthroughClaimRequest";
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	//NSMutableArray *userinfo_arr=[passPerser passresponce];//static method fired
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader];
	[sRequest appendString:@"<soapenv:Body><ser:GetClaimActivitiesMA><ser:participantID>"];
	[sRequest appendString:pId];
	[sRequest appendString:@"</ser:participantID><ser:participantCode/><ser:userID>"];
	[sRequest appendString:uId];
	[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType><ser:elctID/><ser:claimSource>passthru</ser:claimSource><ser:receiptRequired/><ser:receiptRequiredType/><ser:noOfRec>10</ser:noOfRec><ser:startAfterSeqID>"];
	[sRequest appendString:strid];
	[sRequest appendString:@"</ser:startAfterSeqID>"];
	[sRequest appendString:@"<ser:clientName>Mobile</ser:clientName><ser:param1/><ser:param2/><ser:param3/><ser:param4/></ser:GetClaimActivitiesMA></soapenv:Body></soapenv:Envelope>"];
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	link=[link stringByAppendingString:@"GetClaimActivitiesMAService"];
	[self callPostMethod:sRequest Action:@"ser:GetClaimActivitiesMA" API:link];
}
-(void)req_images:(NSString *)pId userid:(NSString *)uId startid:(NSString *)strid
{
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	else
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	whichAPI=@"imageRequest";
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	//NSMutableArray *userinfo_arr=[passPerser passresponce];//static method fired
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader];
	[sRequest appendString:@"<soapenv:Body><ser:GetReceiptsMA><ser:participantID>"];
	[sRequest appendString:pId];
	[sRequest appendString:@"</ser:participantID><ser:userID>"];
	[sRequest appendString:uId];
	[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType><ser:noOfRecords>10</ser:noOfRecords><ser:startAfterSeqID>"];
	[sRequest appendString:strid];
	[sRequest appendString:@"</ser:startAfterSeqID>"];
	[sRequest appendString:@"<ser:participantCode/><ser:clientName>Mobile</ser:clientName><ser:param1/><ser:param2/><ser:param3/><ser:param4/></ser:GetReceiptsMA></soapenv:Body></soapenv:Envelope>"];
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	link=[link stringByAppendingString:@"GetReceiptsMAService"];
	[self callPostMethod:sRequest Action:@"ser:GetReceiptsMA" API:link];
}
-(void)req_alerts:(NSString *)pId userid:(NSString *)uId startid:(NSString *)strid
{
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	else
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	whichAPI=@"alertRequest";
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	//NSMutableArray *userinfo_arr=[passPerser passresponce];//static method fired
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader];
	[sRequest appendString:@"<soapenv:Body><ser:GetActionNeededItemsMA><ser:participantID>"];
	[sRequest appendString:pId];
	[sRequest appendString:@"</ser:participantID><ser:userID>"];
	[sRequest appendString:uId];
	[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType>"];
	[sRequest appendString:@"<ser:param1/><ser:param2/><ser:param3/><ser:param4/></ser:GetActionNeededItemsMA></soapenv:Body></soapenv:Envelope>"];
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	link=[link stringByAppendingString:@"GetActionNeededItemsMAService"];
	[self callPostMethod:sRequest Action:@"ser:GetActionNeededItemsMA" API:link];
}


#pragma mark -
-(void)callPostMethod:(NSMutableString *)sRequest Action:(NSString *)action API:(NSString *)api
{
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
	
	NSData *postBody;
	postBody=[sRequest dataUsingEncoding:NSUTF8StringEncoding];
	NSURL *apiURL=[NSURL URLWithString:api];
	NSMutableURLRequest *request=[NSMutableURLRequest requestWithURL:apiURL];
	[request addValue:@"text/xml" forHTTPHeaderField:@"Content-Type"];
	[request addValue:action forHTTPHeaderField:@"SOAPAction"];
	[request setHTTPMethod:@"POST"];
	[request setHTTPBody:postBody];
	NSURLConnection *conn=[[NSURLConnection alloc] initWithRequest:request delegate:self];
	if (conn)
	{
		;
	}
}

#pragma mark -
#pragma mark Connection Deligate
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
	NSLog(@"HERE RESPONSE: %d",[(NSHTTPURLResponse*) response statusCode]);
	if([(NSHTTPURLResponse*) response statusCode]!=200)
	{
		isstatus=YES;
		errorResponseAlert *myerrorResponseAlert=[[errorResponseAlert alloc]init];
		[myerrorResponseAlert showAlert];
		[target performSelector:failureHandler withObject:nil withObject:nil];
		[myerrorResponseAlert release],myerrorResponseAlert=nil;
		return;

	}
	if(d2)
		[d2 release];
	d2=[[NSMutableData alloc]init];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
	[d2 appendData:data];	
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{  
	if(isstatus==YES)
	{
		isstatus=NO;
		return;
	}
	
	else
	{
		
	

	NSString *data_Response = [[NSString alloc] initWithData:d2 encoding:NSUTF8StringEncoding];
	NSLog(@"Response_of_submit =%@",data_Response);
	
	NSString *XHTMLsearchForWarning = @"XHTML";
	NSRange rangeXHTMLWarning = [data_Response rangeOfString : XHTMLsearchForWarning];
	
	NSString *HTMLsearchForWarning = @"HTML";
	NSRange rangeHTMLWarning = [data_Response rangeOfString : HTMLsearchForWarning];
	if (rangeXHTMLWarning.location != NSNotFound || rangeHTMLWarning.location != NSNotFound)
	{
		[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
		[target performSelector:failureHandler];
		
		NSDictionary *customMessageList_dict=[[NSUserDefaults standardUserDefaults] objectForKey:@"customMessageList"];

		NSString *strmessage=[[customMessageList_dict valueForKey:@"200004"]valueForKey:@"message"];
		
		
		NSString *strtype=[[customMessageList_dict valueForKey:@"200004"]valueForKey:@"type"];
		
		
		UIAlertView *alert=[[UIAlertView alloc] initWithTitle:strtype message:strmessage delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		[alert show];
		[alert release];
		return ;
	}
	if ([whichAPI isEqualToString:@"senduserName"]) {
		
		
		/*for testing config files*/
		//NSString* filePath = [[NSBundle mainBundle] pathForResource:@"userresponse" ofType:@"xml"];
//		NSString* fileContents = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
//		NSMutableData *data=((NSMutableData *)[fileContents dataUsingEncoding:NSUTF8StringEncoding]);
		/*for testing config files*/
		
		NSError *parseError = nil;
		UserresponcePerser *userinfoParser = [[UserresponcePerser alloc] init];
		[userinfoParser parseXMLFileAtData:d2 parseError:&parseError];	
		[userinfoParser release];
		[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
		//NSMutableArray *userinfo_arr=[UserresponcePerser userdesc];		
		//app.logoIMG=[UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[userinfo_arr objectAtIndex:3]]]];
		[target performSelector:successHandler withObject:nil withObject:nil];
		
		
		
		
		
	}
	if ([whichAPI isEqualToString:@"GetAppConfigurableItemsMA"]) {
		
		/*for testing config files*/
		//NSString* filePath = [[NSBundle mainBundle] pathForResource:@"configXML" ofType:@"xml"];
		//NSString* fileContents = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
		//NSMutableData *data=((NSMutableData *)[fileContents dataUsingEncoding:NSUTF8StringEncoding]);
		/*for testing config files*/
		
		NSError *parseError1 = nil;
		configurableParser *acinfoParser = [[configurableParser alloc] init];
		[acinfoParser parseXMLFileAtData:d2 parseError:&parseError1];	
		[acinfoParser release];
		[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
		[target performSelector:successHandler];

		
	}
	
	if ([whichAPI isEqualToString:@"senduserPass"]) {
		
		
		/*for testing config files*/
		NSString* filePath = [[NSBundle mainBundle] pathForResource:@"rollBased" ofType:@"xml"];
		NSString* fileContents = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
		NSMutableData *data=((NSMutableData *)[fileContents dataUsingEncoding:NSUTF8StringEncoding]);
		/*for testing config files*/
		
		
		NSError *parseError = nil;
		passPerser *userinfoParser = [[passPerser alloc] init];
		[userinfoParser parseXMLFileAtData:data parseError:&parseError];	
		[userinfoParser release];
		[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
		[target performSelector:successHandler];
		
	}
	if ([whichAPI isEqualToString:@"sendaccountRequest"]) {
		
		/*for testing config files*/
		//NSString* filePath = [[NSBundle mainBundle] pathForResource:@"accounts" ofType:@"xml"];
//		NSString* fileContents = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
//		NSMutableData *data=((NSMutableData *)[fileContents dataUsingEncoding:NSUTF8StringEncoding]);
		/*for testing config files*/
		
		NSError *parseError = nil;
		accPerser *acinfoParser = [[accPerser alloc] init];
		[acinfoParser parseXMLFileAtData:d2 parseError:&parseError];	
		[acinfoParser release];
		[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
		[target performSelector:successHandler];
		
	}
	if ([whichAPI isEqualToString:@"sendtransactionRequest"]) {
		NSError *parseError = nil;
		transactionPerser *parser = [[transactionPerser alloc] init];
		[parser parseXMLFileAtData:d2 parseError:&parseError];	
		[parser release];
		[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
		[target performSelector:successHandler];
	}
	if ([whichAPI isEqualToString:@"sendHSA_InvestmenttransactionRequest"]) {///////Change this if investment respose is different from sendtransactionRequest response(FOR SUMIT)
		NSError *parseError = nil;
		InvestmentParser *parser = [[InvestmentParser alloc] init];
		[parser parseXMLFileAtData:d2 parseError:&parseError];	
		[parser release];
		[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
		
		[target performSelector:successHandler];
	}
	if ([whichAPI isEqualToString:@"sendticketRequest"]) {
		NSError *parseError = nil;
		ticketPerser *parser = [[ticketPerser alloc] init];
		[parser parseXMLFileAtData:d2 parseError:&parseError];	
		[parser release];
		[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
		[target performSelector:successHandler];
	}
	if ([whichAPI isEqualToString:@"sendticketUpdateRequest"] ) {
		NSError *parseError = nil;
		ticketupdatePerser *parser = [[ticketupdatePerser alloc] init];
		[parser parseXMLFileAtData:d2 parseError:&parseError];	
		[parser release];
		[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
		[target performSelector:successHandler];
	}
	if ([whichAPI isEqualToString:@"sendticketCloseRequest"]) {
		NSError *parseError = nil;
		ticketclosePerser *parser = [[ticketclosePerser alloc] init];
		[parser parseXMLFileAtData:d2 parseError:&parseError];	
		[parser release];
		[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
		[target performSelector:successHandler];
	}
	if ([whichAPI isEqualToString:@"newticketRequest"] ) {
		NSError *parseError = nil;
		ticketTypePerser *parser = [[ticketTypePerser alloc] init];
		[parser parseXMLFileAtData:d2 parseError:&parseError];	
		[parser release];
		[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
		[target performSelector:successHandler];
	}
	if ([whichAPI isEqualToString:@"claimactivityRequest"]||[whichAPI isEqualToString:@"passthroughClaimRequest"] ) {
		NSError *parseError = nil;
		claimactivityPerser *parser = [[claimactivityPerser alloc] init];
		[parser parseXMLFileAtData:d2 parseError:&parseError];	
		[parser release];
		[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
		[target performSelector:successHandler];
	}
	if ([whichAPI isEqualToString:@"imageRequest"] ) {
		NSError *parseError = nil;
		
		
		/*for testing config files*/
		       //NSString* filePath = [[NSBundle mainBundle] pathForResource:@"Image" ofType:@"xml"];
				//NSString* fileContents = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
				//NSMutableData *data=((NSMutableData *)[fileContents dataUsingEncoding:NSUTF8StringEncoding]);
		/*for testing config files*/
		
		imagePerser *parser = [[imagePerser alloc] init];
		[parser parseXMLFileAtData:d2 parseError:&parseError];	
		[parser release];
		[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
		[target performSelector:successHandler];
	}
	if ([whichAPI isEqualToString:@"alertRequest"] ) {
		NSError *parseError = nil;
		alertParser *parser = [[alertParser alloc] init];
		[parser parseXMLFileAtData:d2 parseError:&parseError];	
		[parser release];
		[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
		[target performSelector:successHandler];
	}
	
 }
	
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Sorry" message:[error localizedDescription] delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
	[alert show];
	[alert release];
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
	[target performSelector:failureHandler];
	
		
}


@end
