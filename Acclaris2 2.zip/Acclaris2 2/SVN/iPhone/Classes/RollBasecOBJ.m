//
//  RollBasecOBJ.m
//  Acclaris
//
//  Created by Subhojit on 22/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "RollBasecOBJ.h"


@implementation RollBasecOBJ
@synthesize strName,strDisplayseq,strlabel,arrSubRole,displayable;

-(void)dealloc{
	arrSubRole=nil;
	[super dealloc];
}
- (id)init{
	arrSubRole=nil;//[[[NSMutableArray alloc]init]autorelease];
	return self;
}

@end
