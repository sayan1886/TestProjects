//
//  GopaperlessParser.m
//  Acclaris
//
//  Created by Subhojit on 11/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "GopaperlessParser.h"
NSMutableArray *arrgoPaperlessinfo;
NSMutableArray *arrStatement;

@implementation GopaperlessParser
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error
{
	
	NSXMLParser *parser;
	parser = [[NSXMLParser alloc] initWithData:data];
    [parser setDelegate:self];
	[parser setShouldProcessNamespaces:NO];
    [parser setShouldReportNamespacePrefixes:NO];
    [parser setShouldResolveExternalEntities:NO];
    [parser parse];
    NSError *parseError = [parser parserError];
    if (parseError && error) 
	{
        *error = parseError;
    }
	[parser release];
}

-(void)parserDidStartDocument:(NSXMLParser *)parser
{
	
	arrgoPaperlessinfo=[[NSMutableArray alloc]init];
	arrStatement=[[NSMutableArray alloc]init];

	
}		

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
	if (qName)
	{
		elementName = qName;
	}
	
	else
		if([elementName isEqualToString:@"GetEEPrflSmryMADetails"])
	{
		
		  myGoPaperlessOBJ=[[GoPaperlessOBJ alloc]init];		
	}
	  else 
			if([elementName isEqualToString:@"returnCode"])
			{
				contentOfString=[NSMutableString string];
				[contentOfString retain];
				return;		
				
			}
			else 
				if([elementName isEqualToString:@"errorText"])
				{
					contentOfString=[NSMutableString string];
					[contentOfString retain];
					return;		
					
				}
				else 
					if([elementName isEqualToString:@"eeID"])
					{
						contentOfString=[NSMutableString string];
						[contentOfString retain];
						return;		
						
					}
					else 
						if([elementName isEqualToString:@"SSN"])
						{
							contentOfString=[NSMutableString string];
							[contentOfString retain];
							return;		
							
						}
						else 
							if([elementName isEqualToString:@"erCode"])
							{
								contentOfString=[NSMutableString string];
								[contentOfString retain];
								return;		
								
							}
							else 
								if([elementName isEqualToString:@"status"])
								{
									contentOfString=[NSMutableString string];
									[contentOfString retain];
									return;		
									
								}
								else 
									if([elementName isEqualToString:@"eeName"])
									{
										contentOfString=[NSMutableString string];
										[contentOfString retain];
										return;		
										
									}
									else 
										if([elementName isEqualToString:@"erName"])
										{
											contentOfString=[NSMutableString string];
											[contentOfString retain];
											return;		
											
										}
										else 
											if([elementName isEqualToString:@"admnID"])
											{
												contentOfString=[NSMutableString string];
												[contentOfString retain];
												return;		
												
											}
											else 
												if([elementName isEqualToString:@"admnName"])
												{
													contentOfString=[NSMutableString string];
													[contentOfString retain];
													return;		
													
												}
												else 
													if([elementName isEqualToString:@"begins"])
													{
														contentOfString=[NSMutableString string];
														[contentOfString retain];
														return;		
														
													}
													else 
														if([elementName isEqualToString:@"ends"])
														{
															contentOfString=[NSMutableString string];
															[contentOfString retain];
															return;		
															
														}
													else 
														if([elementName isEqualToString:@"email"])
														{
															contentOfString=[NSMutableString string];
															[contentOfString retain];
															return;		
															
														}
														else 
															if([elementName isEqualToString:@"dob"])
															{
																contentOfString=[NSMutableString string];
																[contentOfString retain];
																return;		
																
															}
														else 
															if([elementName isEqualToString:@"isAchValid"])
															{
																
															}
															else 
																if([elementName isEqualToString:@"achActNo"])
																{
																	contentOfString=[NSMutableString string];
																	[contentOfString retain];
																	return;		
																	
																}
																else 
																	if([elementName isEqualToString:@"achRoutingNo"])
																	{
																		contentOfString=[NSMutableString string];
																		[contentOfString retain];
																		return;		
																		
															}
																else 
																	if([elementName isEqualToString:@"achStatus"])
																	{
																		contentOfString=[NSMutableString string];
																		[contentOfString retain];
																		return;		
																		
																	}

																	else 
																		if([elementName isEqualToString:@"achActType"])
																		{
																			contentOfString=[NSMutableString string];
																			[contentOfString retain];
																			return;		
																			
																		}

																	else 
																		if([elementName isEqualToString:@"emailReqForAch"])
																		{
																			contentOfString=[NSMutableString string];
																			[contentOfString retain];
																			return;		
																			
																		}
																		else 
																			if([elementName isEqualToString:@"dobReqForAch"])
																			{
																				contentOfString=[NSMutableString string];
																				[contentOfString retain];
																				return;		
																				
																			}
	
																		else 
																			if([elementName isEqualToString:@"statement"])
																			{
																				
																				myStatementforGoPaparlessOBJ=[[StatementforGoPaparlessOBJ alloc]init];
																				
																																							
																				myStatementforGoPaparlessOBJ.arrselectoption=[[NSMutableArray alloc]init];
																			}
																			else 
																				if([elementName isEqualToString:@"name"])
																				{
																					
																					contentOfString=[NSMutableString string];
																					[contentOfString retain];
																					return;
																				}
																				else 
																					if([elementName isEqualToString:@"label"])
																					{
																						
																						contentOfString=[NSMutableString string];
																						[contentOfString retain];
																						return;
																					}
																					else 
																						if([elementName isEqualToString:@"value"])
																						{
																							
																							contentOfString=[NSMutableString string];
																							[contentOfString retain];
																							return;
																						}
																						else 
																							if([elementName isEqualToString:@"selected"])
																							{
																								
																								contentOfString=[NSMutableString string];
																								[contentOfString retain];
																								return;
																							}
																						else 
																							if([elementName isEqualToString:@"selectOptions"])
																							{
																								objselect=[[SelectOptionGoPaperlessOBJ alloc]init];
																								isSelected=YES;
																								
																							}
	

}
- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName     
{	
	if (qName)
	{
        elementName = qName;
		
    }
	
	else 
		if([elementName isEqualToString:@"GetEEPrflSmryMADetails"])
		{
			
			if(myGoPaperlessOBJ)
			{
				
				[arrgoPaperlessinfo addObject:myGoPaperlessOBJ];
				[myGoPaperlessOBJ release],myGoPaperlessOBJ=nil;
			}
			
		}
		else 
			if([elementName isEqualToString:@"returnCode"])
			{
				
				
				if(contentOfString)
				{
					myGoPaperlessOBJ.strreturnCode=contentOfString;
					[contentOfString release];
					contentOfString = nil;
					
					
				}		
			}
			else 
				if([elementName isEqualToString:@"errorText"])
				{
					if(contentOfString)
					{
						myGoPaperlessOBJ.strerrorText=contentOfString;
						[contentOfString release];
						contentOfString = nil;
						
						
					}			
					
				}
				else 
					if([elementName isEqualToString:@"eeID"])
					{
						if(contentOfString)
						{
							myGoPaperlessOBJ.streeID=contentOfString;
							[contentOfString release];
							contentOfString = nil;
							
							
						}
						
					}
					else 
						if([elementName isEqualToString:@"SSN"])
						{
							
							if(contentOfString)
							{
								myGoPaperlessOBJ.strSSN=contentOfString;
								[contentOfString release];
								contentOfString = nil;
								
								
							}		
							
						}
						else 
							if([elementName isEqualToString:@"erCode"])
							{
								if(contentOfString)
								{
									myGoPaperlessOBJ.strerCode=contentOfString;
									[contentOfString release];
									contentOfString = nil;
									
									
								}	
								
							}
							else 
								if([elementName isEqualToString:@"status"])
								{
									if(contentOfString)
									{
										myGoPaperlessOBJ.strstatus=contentOfString;
										[contentOfString release];
										contentOfString = nil;
										
										
									}			
									
								}
								else 
									if([elementName isEqualToString:@"eeName"])
									{if(contentOfString)
									{
										myGoPaperlessOBJ.streeName=contentOfString;
										[contentOfString release];
										contentOfString = nil;
										
										
									}		
										
									}
									else 
										if([elementName isEqualToString:@"erName"])
										{
											if(contentOfString)
											{
												myGoPaperlessOBJ.strerName=contentOfString;
												[contentOfString release];
												contentOfString = nil;
												
												
											}		
											
										}
										else 
											if([elementName isEqualToString:@"admnID"])
											{
												if(contentOfString)
												{
													myGoPaperlessOBJ.stradmnID=contentOfString;
													[contentOfString release];
													contentOfString = nil;
													
													
												}		
												
											}
											else 
												if([elementName isEqualToString:@"admnName"])
												{
													if(contentOfString)
													{
														myGoPaperlessOBJ.stradmnName=contentOfString;
														[contentOfString release];
														contentOfString = nil;
														
														
													}		
													
												}
												else 
													if([elementName isEqualToString:@"begins"])
													{
														if(contentOfString)
														{
															myGoPaperlessOBJ.strbegins=contentOfString;
															[contentOfString release];
															contentOfString = nil;
															
															
														}		
														
													}
													else 
														if([elementName isEqualToString:@"ends"])
														{
															if(contentOfString)
															{
																myGoPaperlessOBJ.strends=contentOfString;
																[contentOfString release];
																contentOfString = nil;
																
																
															}		
															
														}
														else 
															if([elementName isEqualToString:@"email"])
															{
																if(contentOfString)
																{
																	myGoPaperlessOBJ.stremail=contentOfString;
																	[contentOfString release];
																	contentOfString = nil;
																	
																	
																}		
																
															}
															else 
																if([elementName isEqualToString:@"dob"])
																{
																	if(contentOfString)
																	{
																		myGoPaperlessOBJ.strdob=contentOfString;
																		[contentOfString release];
																		contentOfString = nil;
																		
																		
																	}		
																	
																}
															else 
																if([elementName isEqualToString:@"isAchValid"])
																{
																	if(contentOfString)
																	{
																		myGoPaperlessOBJ.strisAchValid=contentOfString;
																		[contentOfString release];
																		contentOfString = nil;
																		
																		
																	}																	}
																else 
																	if([elementName isEqualToString:@"achActType"])
																	{
																		
																		if(contentOfString)
																		{
																			myGoPaperlessOBJ.strachActType=contentOfString;
																			[contentOfString release];
																			contentOfString = nil;
																	
																			
																		}		
																		
																		
																	}
																	else 
																		if([elementName isEqualToString:@"achRoutingNo"])
																		{
																			if(contentOfString)
																			{
																				myGoPaperlessOBJ.strachRoutingNo=contentOfString;
																				[contentOfString release];
																				contentOfString = nil;
																				
																				
																				
																			}			
																			
																		}
																		else 
																			if([elementName isEqualToString:@"emailReqForAch"])
																			{
																				if(contentOfString)
																				{
																					myGoPaperlessOBJ.stremailReqForAch=contentOfString;
																					[contentOfString release];
																					contentOfString = nil;
																					
																					
																					
																				}			
																				
																			}
																			else 
																				if([elementName isEqualToString:@"dobReqForAch"])
																				{
																					if(contentOfString)
																					{
																						myGoPaperlessOBJ.strdobReqForAch=contentOfString;
																						[contentOfString release];
																						contentOfString = nil;
																						
																						
																						
																					}			
																					
																				}
																			else 
																				if([elementName isEqualToString:@"achStatus"])
																				{
																					if(contentOfString)
																					{
																						myGoPaperlessOBJ.strachStatus=contentOfString;
																						[contentOfString release];
																						contentOfString = nil;
																						
																						
																						
																					}	
																				}
																				else 
																					if([elementName isEqualToString:@"statement"])
																					{
																						if(myStatementforGoPaparlessOBJ)
																						{
																																														
																							[arrStatement addObject:myStatementforGoPaparlessOBJ];
																							[myStatementforGoPaparlessOBJ release],myStatementforGoPaparlessOBJ=nil;
																							
																						}	
																					}
																					else 
																						if([elementName isEqualToString:@"name"])
																						{
																																															
																								myStatementforGoPaparlessOBJ.strname=contentOfString;
																																								
																							
																							[contentOfString release];
																							contentOfString = nil;

										
																						}
																						else 
																							if([elementName isEqualToString:@"label"])
																							{
																								
																								if(contentOfString)
																								{
																									if(isSelected==YES)
																								        objselect.strSublabel=contentOfString;
																									
																									else 
																									{
																										
																										myStatementforGoPaparlessOBJ.strlabel=contentOfString;
																									}
																									
																								}
																																																
																								
																								[contentOfString release];
																								contentOfString = nil;
																								
																							}
																							else 
																								if([elementName isEqualToString:@"value"])
																								{
																									
																									if(contentOfString)
																									{
																										
																											 objselect.strsSubvalue=contentOfString;
																										
										
																									}
																																														
									
																									[contentOfString release];
																									contentOfString = nil;
																									
																								}
																								else 
																									if([elementName isEqualToString:@"selected"])
																									{
																										
																										if(contentOfString)
																										{
																											
																											objselect.strsubSelected=contentOfString;
																											
																											
																										}
																										
																										
																										[contentOfString release];
																										contentOfString = nil;
																										
																									}
	
	
	
																							else 
																								if([elementName isEqualToString:@"selectOptions"])
																								{
																									if(objselect)
																									{
																										isSelected=NO;
																										
																										[myStatementforGoPaparlessOBJ.arrselectoption addObject:objselect];
																										[objselect release];
																										objselect = nil;
																										
																										
																										
																									}	
																								}
	
																				
	
}	
-(void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
	if(contentOfString)
		[contentOfString appendString:string];
}

- (void)parserDidEndDocument:(NSXMLParser *)parse
{
	
	NSLog(@"%@",arrgoPaperlessinfo);
	
	
	for (int i=0; i<[arrStatement count]; i++) {
		StatementforGoPaparlessOBJ *myStatementforGoPaparless=(StatementforGoPaparlessOBJ *)[arrStatement objectAtIndex:i];
		NSLog(@"%@",myStatementforGoPaparless.strname);
		NSLog(@"%@",myStatementforGoPaparless.strlabel);
		for (int j=0; j<[myStatementforGoPaparless.arrselectoption count]; j++) 
		{
			SelectOptionGoPaperlessOBJ *mySelectOptionGoPaperless=(SelectOptionGoPaperlessOBJ *)[myStatementforGoPaparless.arrselectoption objectAtIndex:j];
			
			NSLog(@"%@",mySelectOptionGoPaperless.strSublabel);
			NSLog(@"%@",mySelectOptionGoPaperless.strsSubvalue);
			NSLog(@">>>%@",mySelectOptionGoPaperless.strsubSelected);

		}

	}
	
	
	
}
+(NSMutableArray *)getarrgoPaperlessinfo
{
	
	
	return arrgoPaperlessinfo;
}
+(NSMutableArray *)getarrStatement
{

	
	
	return arrStatement;
}
@end
