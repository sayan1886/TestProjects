//
//  eCommunicationDisclosure.h
//  Acclaris
//
//  Created by Subhojit on 11/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AcclarisAppDelegate.h"
#import "Decode64.h"
#import "passPerser.h"
#import "MyTools.h"
#import "Decode64.h"
#import "RequestPhase2_2.h"
#import "eCommunicationOBJ.h"
#import "eCommunicationParser.h"
#import "PaynowcontinueParser.h"

@class configurables;

@interface eCommunicationDisclosure : UIViewController<UITextViewDelegate> {

	AcclarisAppDelegate *app;
	configurables *con;
	UIButton *btn_Remember_Me;
	MyTools *tools;
	UIView *loadingView;
	NSMutableDictionary *dictvalue;
	UITextView *txtview;
	
}
-(void)ClickbtnSubmit;
-(void)GetText;
-(void)btn_RememberMe_Clicked:(id)sender;
-(id)initWithDict:(NSMutableDictionary *)dict;
@end
