    //
//  GopaperLess.m
//  Acclaris
//
//  Created by Subhojit on 22/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "GopaperLess.h"
#import "configurables.h"
#import "AcclarisViewController.h"

@implementation GopaperLess


- (void)viewDidLoad {
    [super viewDidLoad];
	
	
	
	
	NSMutableArray *arr_myconfig=[AcclarisViewController staticarr_config];
	con=(configurables *)[arr_myconfig objectAtIndex:0];
	tools=[[MyTools alloc]init];
	
	loadingView=[tools createActivityIndicator1];

	self.navigationController.navigationBar.tintColor=[UIColor colorWithRed:con.navbarRed/255.0f green:con.navbarGreen/255.0f blue:con.navbarBlue/255.0f alpha:1.0];
	
	self.view.backgroundColor = [UIColor colorWithRed:con.bgRed/255.0f green:con.bgGreen/255.0f blue:con.bgBlue/255.0f alpha:1.0];
	UIImageView *logo_img = [[UIImageView alloc]initWithFrame:CGRectMake(0, 2, 170, 40)];
	NSData *data=[Base64 decode:con.logoImgdata];
	logo_img.image=	[UIImage imageWithData:[NSData dataWithData:data]];
	self.navigationItem.titleView=logo_img;
	
     customMessageList_dict=[[NSUserDefaults standardUserDefaults] objectForKey:@"customMessageList"];
	[self createbar_button];
	
	
	pickerViewArrayH = [[NSMutableArray alloc]init];
	pickerViewArrayO = [[NSMutableArray alloc]init];
	pickerViewArrayA = [[NSMutableArray alloc]init];
	strOther=@"No";
	strHSA=@"No";
	strAccount=@"No";
	
	[self CreateConnectionforsummery];
	
	
}
-(void)createbar_button
{
	
	UIBarButtonItem *signoutButton = [[UIBarButtonItem alloc]
									  initWithTitle:@"Sign Off"
									  style:UIBarButtonItemStyleBordered
									  target:self
									  action:@selector(signout)];
	self.navigationItem.rightBarButtonItem =signoutButton;
	
}
-(void)signout
{
	 [((AcclarisAppDelegate *)[[UIApplication sharedApplication] delegate]) removeTabBar];
}

-(void)CreateConnectionforsummery
{
	
	
       NSMutableArray *userinfo_arr=[passPerser passresponce];
		RequestPhase2_2 *objrequestPhase2_2=[[RequestPhase2_2 alloc] initWithTarget:self
																	  SuccessAction:@selector(onSuccefful)
																	  FailureAction:@selector(onFailure)];
		
		[objrequestPhase2_2 GetPrimarySummery:[userinfo_arr objectAtIndex:2] uID:[userinfo_arr objectAtIndex:4]];
		[objrequestPhase2_2 release];
		
		[tools startLoading:self.view childView:loadingView text:@"Loading your Claim activity. Wait…."];
	
	
}
	
-(void)onSuccefful
{
		
	[tools stopLoading:loadingView];
	
	arrGopaperless=[GopaperlessParser getarrgoPaperlessinfo];
	arrStatementInfo=[GopaperlessParser getarrStatement];
	
	for (int i=0; i<[arrStatementInfo count]; i++) 
	{
		myStatementforGoPaparless=(StatementforGoPaparlessOBJ *)[arrStatementInfo objectAtIndex:i];
	
		
		for(int j=0;j<[myStatementforGoPaparless.arrselectoption count];j++)
	 {
		if([myStatementforGoPaparless.strname isEqualToString:@"OTHERCOMM"])

		{
				SelectOptionGoPaperlessOBJ *obj=(SelectOptionGoPaperlessOBJ *)[myStatementforGoPaparless.arrselectoption objectAtIndex:j];
			   [pickerViewArrayO addObject:obj.strSublabel];
			
			
			   if([obj.strsubSelected isEqualToString:@"true"])
			   {
				   arrSelectedlabelO=[[NSMutableArray alloc]init];

				  [arrSelectedlabelO addObject:obj.strSublabel];
				   strOther=obj.strsSubvalue; 
				   
			   }
			else {
				
			}

		}
		else if([myStatementforGoPaparless.strname isEqualToString:@"HSASTMT"])
		
		{
			SelectOptionGoPaperlessOBJ *obj=(SelectOptionGoPaperlessOBJ *)[myStatementforGoPaparless.arrselectoption objectAtIndex:j];
			[pickerViewArrayH addObject:obj.strSublabel];
			
			
			if([obj.strsubSelected isEqualToString:@"true"])
			{
				
				arrSelectedlabelH=[[NSMutableArray alloc]init];
				[arrSelectedlabelH addObject:obj.strSublabel];
			     strHSA=obj.strsSubvalue;
			}
			 
			
			else {
				
			}

		}
		else if([myStatementforGoPaparless.strname isEqualToString:@"ACCOUNTSTMT"])
			
			
		{
		   SelectOptionGoPaperlessOBJ *obj=(SelectOptionGoPaperlessOBJ *)[myStatementforGoPaparless.arrselectoption objectAtIndex:j];
			[pickerViewArrayA addObject:obj.strSublabel];
			
		    if([obj.strsubSelected isEqualToString:@"true"])
			{
				
				
				arrSelectedlabelA=[[NSMutableArray alloc]init];

				[arrSelectedlabelA addObject:obj.strSublabel];
			      strAccount=obj.strsSubvalue;
			}
			else 
			{
				
			}
		}
	}
		
 }
				 
	NSLog(@"pickerViewArrayO %@",arrSelectedlabelO);
	NSLog(@"pickerViewArrayA %@",arrSelectedlabelA);
	NSLog(@"pickerViewArrayH %@",arrSelectedlabelH);
	
	[self CreateView];
}
		
-(void)onFailure
{
			
	[tools stopLoading:loadingView];
	
}
		
-(void)CreateView
{
	
	NSString	*strFont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];
	NSData *data_btnimg=[Base64 decode:con.btnImgdata];//btn background image
	
	table=[[UITableView alloc]initWithFrame:CGRectMake(0, 70, 320, 220) style:UITableViewStylePlain];
	table.backgroundColor = [UIColor clearColor];
	table.bounces = YES;
	table.delegate=self;
	table.dataSource=self;
	table.separatorColor=[UIColor clearColor];
	[self.view addSubview:table];
	
	UIView *HeaderView=[[[UIView alloc]initWithFrame:CGRectMake(0, 0, 320, 60)]autorelease];
	HeaderView.backgroundColor=[UIColor colorWithRed:con.bgRed2/255.0 green:con.bgGreen2/255.0 blue:con.bgBlue2/255.0 alpha:1.0];
	[self.view addSubview:HeaderView];
	
	NSString *strViewTitle=@"Go Paperless";
	//strViewTitle=[strViewTitle stringByAppendingString:@"\n"];
	//strViewTitle=[strViewTitle stringByAppendingFormat:@"%@",@"Paperless"];
	
	UILabel *lbltext=[[UILabel alloc]initWithFrame:CGRectMake(10, 5, 250, 60)];
	lbltext.text=strViewTitle;
	lbltext.backgroundColor=[UIColor clearColor];
	lbltext.textColor=[UIColor whiteColor];
	lbltext.numberOfLines=0;
	lbltext.font=[UIFont fontWithName:strFont size:con.headerImpfntsize];
	[HeaderView addSubview:lbltext];
	[lbltext release],lbltext=nil;
	
	

	UIButton *btnContinue=[UIButton buttonWithType:UIButtonTypeCustom];
	btnContinue.frame=CGRectMake(30, 320, 260, 40);
	[btnContinue setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
	[btnContinue setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	btnContinue.titleLabel.font = [UIFont fontWithName:con.btnfontname size:con.btnfontsize];
	[btnContinue setTitle:@"Continue" forState:UIControlStateNormal];
	[btnContinue addTarget:self action:@selector(ClickbtnContinue) forControlEvents:UIControlEventTouchUpInside];					 
	[self.view addSubview:btnContinue];
	
	
	[self constructTableCell];
	
}

-(void)ClickbtnContinue
{
	[self Saveinfo];
	
	
	
	 if([((GoPaperlessOBJ *)[arrGopaperless objectAtIndex:0]).stremail isEqualToString: txtEmail.text] && [((GoPaperlessOBJ *)[arrGopaperless objectAtIndex:0]).stremail isEqualToString:txtRenterEmail.text] &&	
	   [[arrSelectedlabelH objectAtIndex:0] isEqualToString:txtInvesmentStatement.text] && 
	   [[arrSelectedlabelO objectAtIndex:0] isEqualToString:txtOther.text] && 
	   [[arrSelectedlabelA objectAtIndex:0] isEqualToString:txtAccountStatement.text])
	{
		
		NSMutableArray *userinfo_arr=[passPerser passresponce];
		RequestPhase2_2 *objrequestPhase2_2=[[RequestPhase2_2 alloc] initWithTarget:self
																	  SuccessAction:@selector(onSucceffulsubmit)
																	  FailureAction:@selector(onFailure)];
		
		[objrequestPhase2_2 SubmitforeCommunication:[userinfo_arr objectAtIndex:2] uID:[userinfo_arr objectAtIndex:4] email:txtEmail.text reenterEmail:txtRenterEmail.text hsaStatement:strHSA accountStatement:strAccount otherCommunication:strOther];
		[objrequestPhase2_2 release];
		
		[tools startLoading:self.view childView:loadingView text:@"Loading your Claim activity. Wait…."];
		
	}
	    
	    
	else if(![txtEmail.text isEqualToString:txtRenterEmail.text])
		{
			
			
			UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:@"Info" 
																  message:@"Email and Reenter Email should be same" 
																 delegate:self 
														cancelButtonTitle:@"OK" 
														otherButtonTitles:nil];
			[alertWarning show];
			[alertWarning release];
			return;
			
			
		}
	
		
	  else if([txtEmail.text length]==0)
		{
			
			NSString *strmessage=[[customMessageList_dict valueForKey:@"200050"]valueForKey:@"message"];
			NSString *strtype=[[customMessageList_dict valueForKey:@"200050"]valueForKey:@"type"];
			
			UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:strtype 
																  message:strmessage
																 delegate:self 
														cancelButtonTitle:@"OK" 
														otherButtonTitles:nil];
			[alertWarning show];
			[alertWarning release];
			return;
		}
	  else if([txtRenterEmail.text length]==0 )
	  {
		  
		  NSString *strmessage=[[customMessageList_dict valueForKey:@"200051"]valueForKey:@"message"];
		  NSString *strtype=[[customMessageList_dict valueForKey:@"200051"]valueForKey:@"type"];
		  UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:strtype 
																message:strmessage
															   delegate:self 
													  cancelButtonTitle:@"OK" 
													  otherButtonTitles:nil];
		  [alertWarning show];
		  [alertWarning release];
		  return;
	  }
	
	
	else if([strtitlecheckH isEqualToString:@"Yes"] ||[strtitlecheckA isEqualToString:@"Yes"] || [strtitlecheckO isEqualToString:@"Yes"])
		  
	  {
		  
		  
		  eCommunicationDisclosure *obj=[[eCommunicationDisclosure alloc]initWithDict:dict];
		  [self.navigationController pushViewController:obj animated:YES];
		  [obj release],obj=nil;
		  
		  
		  
	  }
	
	else if((![txtEmail.text isEqualToString:((GoPaperlessOBJ *)[arrGopaperless objectAtIndex:0]).stremail]) && ([strHSA isEqualToString:@"Yes"] ||[strAccount isEqualToString:@"Yes"] || [strOther isEqualToString:@"Yes"]))
	{
		eCommunicationDisclosure *obj=[[eCommunicationDisclosure alloc]initWithDict:dict];
		[self.navigationController pushViewController:obj animated:YES];
		[obj release],obj=nil;
		
		
	}
	
	else 
	{
		
		
		NSMutableArray *userinfo_arr=[passPerser passresponce];
		RequestPhase2_2 *objrequestPhase2_2=[[RequestPhase2_2 alloc] initWithTarget:self
																	  SuccessAction:@selector(onSucceffulsubmit)
																	  FailureAction:@selector(onFailure)];
		
		[objrequestPhase2_2 SubmitforeCommunication:[userinfo_arr objectAtIndex:2] uID:[userinfo_arr objectAtIndex:4] email:txtEmail.text reenterEmail:txtRenterEmail.text hsaStatement:strHSA accountStatement:strAccount otherCommunication:strOther];
		[objrequestPhase2_2 release];
		
		[tools startLoading:self.view childView:loadingView text:@"Loading your Claim activity. Wait…."];
		
	 }
 }	  
	   

-(void)onSucceffulsubmit
{
	
	[tools stopLoading:loadingView];
	NSString *strerror=[PaynowcontinueParser getErrortext];
	NSString *strreturncode=[PaynowcontinueParser getreturncode];
	
	if([strreturncode isEqualToString:@"0"])
	{
		
		[self.navigationController popViewControllerAnimated:YES];
		
	}
	
	else
	{
		UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:@"Info" 
															  message:strerror
															 delegate:self 
													cancelButtonTitle:@"OK" 
													otherButtonTitles:nil];
		[alertWarning show];
		[alertWarning release];
	}
	
	
	
}


-(void)Saveinfo

{
	
	dict=[[NSMutableDictionary alloc]init];
	[dict setObject:txtEmail.text forKey:@"Email"];
	[dict setObject:txtRenterEmail.text forKey:@"EmailRe"];
	[dict setObject:strHSA forKey:@"HSA"];
	[dict setObject:strAccount forKey:@"ACCOUNT"];
	[dict setObject:strOther forKey:@"OTHER"];
	[dict retain];

	
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	
    return 1;
}



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	
	
	return [arrStatementInfo count]+2;
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	
   	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
	if(nil == cell)
	{
		//NSLog(@"%@",[[arrAllSection objectAtIndex:0] objectAtIndex:indexPath.row]);
		cell = [[arrAllSection objectAtIndex:0] objectAtIndex:indexPath.row];
		
	}
	
	cell.selectionStyle = UITableViewCellSelectionStyleNone;
	
    return cell;
	
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	
	
	return 80.0;
	
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath

{
	
	
	
	
}
-(void)constructTableCell
{
	arrAllSection = [[NSMutableArray alloc] init];
	
 #pragma mark --First Section
	NSMutableArray *arrFirstSection = [[NSMutableArray alloc]init];
	
	UITableViewCell *cell00 = [[UITableViewCell alloc] init];
	[self EmailInput:cell00];
	[arrFirstSection addObject:cell00];
	[cell00 release];
	
	UITableViewCell *cell01 = [[UITableViewCell alloc] init];
	[self RenterEmailInput:cell01];
	[arrFirstSection addObject:cell01];
	[cell01 release];
	
	for (int i=0; i<[arrStatementInfo count]; i++) 
	{
		myStatementforGoPaparless=(StatementforGoPaparlessOBJ *)[arrStatementInfo objectAtIndex:i];
		if([myStatementforGoPaparless.strname isEqualToString:@"OTHERCOMM"])
			
		{
			 O=i;
			UITableViewCell *cell10 = [[UITableViewCell alloc] init];
			[self OtherToInput:cell10]; 
			[arrFirstSection addObject:cell10];
			
			[cell10 release];
			
		}
		else if([myStatementforGoPaparless.strname isEqualToString:@"HSASTMT"]||[myStatementforGoPaparless.strname isEqualToString:@"HSASTMT/HSA"])
			
		{   H=i;
			UITableViewCell *cell02 = [[UITableViewCell alloc] init];
			[self InvesmentStatementInput:cell02];
			[arrFirstSection addObject:cell02];
			[cell02 release];
		}
		else if([myStatementforGoPaparless.strname isEqualToString:@"ACCOUNTSTMT"])
			
			
		{
			A=i;
			UITableViewCell *cell03 = [[UITableViewCell alloc] init];
			[self AccountStatementFromInput:cell03];
			[arrFirstSection addObject:cell03];
			[cell03 release];
		}
	}
	
	
	[arrAllSection addObject:arrFirstSection];
	[arrFirstSection release];
	
}
-(void)EmailInput:(UITableViewCell *)cell
{
	UILabel *lblEmail=[[UILabel alloc]initWithFrame:CGRectMake(10, 0, 70, 45)];
	lblEmail.text=@"Email address";
	lblEmail.backgroundColor=[UIColor clearColor];
	lblEmail.textColor=[UIColor blackColor];
	lblEmail.numberOfLines=0;
	lblEmail.font=[UIFont fontWithName:@"Helvetica-Bold" size:18];
	[cell.contentView addSubview:lblEmail];
	[lblEmail release],lblEmail=nil;
	
	
	txtEmail=[[UITextField alloc]initWithFrame:CGRectMake(100, 25, 210, 35)];
	txtEmail.delegate=self;	
	txtEmail.text=((GoPaperlessOBJ *)[arrGopaperless objectAtIndex:0]).stremail;
	txtEmail.backgroundColor=[UIColor whiteColor];
	txtEmail.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	txtEmail.borderStyle=UITextBorderStyleLine;
	txtEmail.returnKeyType=UIReturnKeyDone;
	txtEmail.textAlignment=UITextAlignmentLeft;
	txtEmail.autocorrectionType =UITextAutocorrectionTypeNo;
	txtEmail.userInteractionEnabled=YES;
	
	[cell.contentView addSubview:txtEmail];			
	
}

#pragma mark -
#pragma mark emailInput Method

-(void)RenterEmailInput:(UITableViewCell *)cell
{
	
	UILabel *lblRenterEmail=[[UILabel alloc]initWithFrame:CGRectMake(10, 0,130, 50)];
	lblRenterEmail.text=@"Reenter Email address";
	lblRenterEmail.backgroundColor=[UIColor clearColor];
	lblRenterEmail.textColor=[UIColor blackColor];
	lblRenterEmail.numberOfLines=0;
	lblRenterEmail.font=[UIFont fontWithName:@"Helvetica-Bold" size:18];
	[cell.contentView addSubview:lblRenterEmail];
	[lblRenterEmail release],lblRenterEmail=nil;
	
	
	txtRenterEmail=[[UITextField alloc]initWithFrame:CGRectMake(100, 30, 210, 35)];
	txtRenterEmail.delegate=self;
	txtRenterEmail.text=((GoPaperlessOBJ *)[arrGopaperless objectAtIndex:0]).stremail;
	txtRenterEmail.backgroundColor=[UIColor whiteColor];
	txtRenterEmail.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	txtRenterEmail.keyboardType=UIKeyboardTypeNumbersAndPunctuation;
	txtRenterEmail.borderStyle=UITextBorderStyleLine;
	txtRenterEmail.returnKeyType=UIReturnKeyDone;
	txtRenterEmail.textAlignment=UITextAlignmentLeft;
	txtRenterEmail.autocorrectionType =UITextAutocorrectionTypeNo;
	txtRenterEmail.userInteractionEnabled=YES;
	
	
	
	[cell.contentView addSubview:txtRenterEmail];
}

#pragma mark -
#pragma mark DOBInput Method

-(void)InvesmentStatementInput:(UITableViewCell *)cell
{
	UILabel *lblInvesmentStatement=[[UILabel alloc]initWithFrame:CGRectMake(10, 0, 145, 50)];
	lblInvesmentStatement.text=((StatementforGoPaparlessOBJ *)[arrStatementInfo objectAtIndex:H]).strlabel;//@"HSA/Investment Statement";
	lblInvesmentStatement.backgroundColor=[UIColor clearColor];
	lblInvesmentStatement.textColor=[UIColor blackColor];
	lblInvesmentStatement.numberOfLines=0;
	lblInvesmentStatement.font=[UIFont fontWithName:@"Helvetica-Bold" size:17];
	[cell.contentView addSubview:lblInvesmentStatement];
	[lblInvesmentStatement release],lblInvesmentStatement=nil;
	
	
	txtInvesmentStatement=[[UITextField alloc]initWithFrame:CGRectMake(100, 35, 210, 35)];
	txtInvesmentStatement.delegate=self;
	
	if(![[arrSelectedlabelH objectAtIndex:0] isEqualToString:@""])
		  txtInvesmentStatement.text=[arrSelectedlabelH objectAtIndex:0];
	
	else 
	{
		 txtInvesmentStatement.text=[arrSelectedlabelH objectAtIndex:1];
		
	}

	txtInvesmentStatement.backgroundColor=[UIColor whiteColor];
	txtInvesmentStatement.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	txtInvesmentStatement.borderStyle=UITextBorderStyleLine;
	txtInvesmentStatement.returnKeyType=UIReturnKeyDone;
	txtInvesmentStatement.textAlignment=UITextAlignmentLeft;
	txtInvesmentStatement.autocorrectionType =UITextAutocorrectionTypeNo;
	txtInvesmentStatement.userInteractionEnabled=YES;
	[cell.contentView addSubview:txtInvesmentStatement];	
	
	
}

#pragma mark -
#pragma mark sexInput Method

-(void)AccountStatementFromInput:(UITableViewCell *)cell
{
	UILabel *lblAccountStatement=[[UILabel alloc]initWithFrame:CGRectMake(10, 5, 240, 50)];
	lblAccountStatement.text=((StatementforGoPaparlessOBJ *)[arrStatementInfo objectAtIndex:A]).strlabel;;
	lblAccountStatement.backgroundColor=[UIColor clearColor];
	lblAccountStatement.textColor=[UIColor blackColor];
	lblAccountStatement.numberOfLines=0;
	lblAccountStatement.font=[UIFont fontWithName:@"Helvetica-Bold" size:17];
	[cell.contentView addSubview:lblAccountStatement];
	[lblAccountStatement release],lblAccountStatement=nil;
	
	txtAccountStatement=[[UITextField alloc]initWithFrame:CGRectMake(100, 53, 210, 35)];
	txtAccountStatement.delegate=self;	
	
	if(![[arrSelectedlabelA objectAtIndex:0] isEqualToString:@""])
	
	     txtAccountStatement.text=[arrSelectedlabelA objectAtIndex:0];
	
	else 
	{
		txtAccountStatement.text=[arrSelectedlabelA objectAtIndex:1];
		
	}
	txtAccountStatement.backgroundColor=[UIColor whiteColor];
	txtAccountStatement.borderStyle=UITextBorderStyleLine;
	txtAccountStatement.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	txtAccountStatement.returnKeyType=UIReturnKeyDone;
	txtAccountStatement.textAlignment=UITextAlignmentLeft;
	txtAccountStatement.autocorrectionType =UITextAutocorrectionTypeNo;
	txtAccountStatement.userInteractionEnabled=YES;
	[cell.contentView addSubview:txtAccountStatement];
}

#pragma mark -
#pragma mark lookingForInput Method

-(void)OtherToInput:(UITableViewCell *)cell
{
	UILabel *lblOther=[[UILabel alloc]initWithFrame:CGRectMake(10, 5, 140, 50)];
	lblOther.text=((StatementforGoPaparlessOBJ *)[arrStatementInfo objectAtIndex:O]).strlabel;;
	lblOther.backgroundColor=[UIColor clearColor];
	lblOther.textColor=[UIColor blackColor];
	lblOther.numberOfLines=0;
	lblOther.font=[UIFont fontWithName:@"Helvetica-Bold" size:17];
	[cell.contentView addSubview:lblOther];
	[lblOther release],lblOther=nil;
	
	
	txtOther=[[UITextField alloc]initWithFrame:CGRectMake(100,50, 210, 35)];
	txtOther.delegate=self;	
	txtOther.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	
	if(![[arrSelectedlabelO objectAtIndex:0] isEqualToString:@""])//{}
	     txtOther.text=[arrSelectedlabelO objectAtIndex:0];
	
	else 
	{
		txtOther.text=[arrSelectedlabelO objectAtIndex:1];
		
	}
	
	txtOther.backgroundColor=[UIColor whiteColor];
	txtOther.borderStyle=UITextBorderStyleLine;
	txtOther.returnKeyType=UIReturnKeyDone;
	txtOther.textAlignment=UITextAlignmentLeft;
	txtOther.autocorrectionType =UITextAutocorrectionTypeNo;
	txtOther.userInteractionEnabled=YES;
	[cell.contentView addSubview:txtOther];
	
	
	
}
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component;
{
	
	NSString *str=@"";
	if([strTxtNm isEqualToString:@"txtInvesmentStatement"])
	 {
		 
		  txtInvesmentStatement.text=[str stringByAppendingFormat:@"%@",[pickerViewArrayH objectAtIndex:[pickerView selectedRowInComponent:0]]];
		 
		 if([txtInvesmentStatement.text isEqualToString:@"Electronic"])
			 strtitlecheckH=@"Yes";
		 
		 else 
		 {
			 strtitlecheckH=@"No";		
		 }
		
		  SelectOptionGoPaperlessOBJ *obj=(SelectOptionGoPaperlessOBJ *)[myStatementforGoPaparless.arrselectoption objectAtIndex:row];
		  strHSA=obj.strsSubvalue;
		 [strtitlecheckH retain];
		 
	 }
	
	else if([strTxtNm isEqualToString:@"txtAccountStatement"]) 
	{
	
		 txtAccountStatement.text=[str stringByAppendingFormat:@"%@",[pickerViewArrayA objectAtIndex:[pickerView selectedRowInComponent:0]]];
		if([txtAccountStatement.text isEqualToString:@"Electronic"])
			strtitlecheckA=@"Yes";
		else 
		{
			strtitlecheckA=@"No";
		}
		
		  SelectOptionGoPaperlessOBJ *obj=(SelectOptionGoPaperlessOBJ *)[myStatementforGoPaparless.arrselectoption objectAtIndex:row];
		  strAccount=obj.strsSubvalue;
		[strtitlecheckA retain];
	}
	
	else if([strTxtNm isEqualToString:@"txtOther"])
	{
		  txtOther.text=[str stringByAppendingFormat:@"%@",[pickerViewArrayO objectAtIndex:[pickerView selectedRowInComponent:0]]];
		
		if([txtOther.text isEqualToString:@"Electronic"])
			strtitlecheckO=@"Yes";
		else 
		{
			strtitlecheckO=@"No";
		}
		
	     SelectOptionGoPaperlessOBJ *obj=(SelectOptionGoPaperlessOBJ *)[myStatementforGoPaparless.arrselectoption objectAtIndex:row];
	     strOther=obj.strsSubvalue;
		[strtitlecheckO retain];

	}
     
	 
	
	
}
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
	if([strTxtNm isEqualToString:@"txtInvesmentStatement"])
	{
		
		return [pickerViewArrayH objectAtIndex:row];
		
	}
	else if([strTxtNm isEqualToString:@"txtAccountStatement"]) 
	{
		return [pickerViewArrayA objectAtIndex:row];
		
	}
	else if([strTxtNm isEqualToString:@"txtOther"])
    {
		return [pickerViewArrayO objectAtIndex:row];
	}
	else
	{
		return @"";
	}
	
	
	
	
}

- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component
{
	// first column size is wider to hold names
	
	return 150.0;                     // second column is narrower to show numbers
	
}

- (CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component
{
	return 40.0;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
	
	if([strTxtNm isEqualToString:@"txtInvesmentStatement"])
	{

		return [pickerViewArrayH count];
		
	}
	else if([strTxtNm isEqualToString:@"txtAccountStatement"]) 
	{
		return [pickerViewArrayA count];
		
	}
	else if([strTxtNm isEqualToString:@"txtOther"])
    {
		return [pickerViewArrayO count];
	}
	else
	{
		return 0;
		
	}


}


- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
	return 1;
	
}
-(void)CreatePickerView
{
	
	
	myPickerView = [[UIPickerView alloc] initWithFrame:CGRectMake(0, 155, 180, 150)];
	myPickerView.showsSelectionIndicator = YES;
	myPickerView.delegate = self;
	[self.view addSubview:myPickerView];
	
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
	
	
	if(textField==txtInvesmentStatement)
	{
	
		strTxtNm=@"txtInvesmentStatement";
		[self Vanishpicker];
		[self createbarbuttondone];
		[self CreatePickerView];
		
			  
		return NO;
	}
	else if(textField==txtAccountStatement)
	{
	
		strTxtNm=@"txtAccountStatement";
		[self Vanishpicker];
		[self createbarbuttondone];
		[self CreatePickerView];
		return NO;
	}
	else if(textField==txtOther)
	{
		strTxtNm=@"txtOther";
		[self Vanishpicker];
		[self createbarbuttondone];
		[self CreatePickerView];
		return NO;
	}

	return YES;
}
- (BOOL)textFieldShouldEndEditing:(UITextField *)textField
{
		return YES;
	
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
	if([strHSA isEqualToString:@"No"] && [strAccount isEqualToString:@"No"] && [strOther isEqualToString:@"No"])
		
	{
		 if(textField==txtEmail || textField==txtRenterEmail)
		{
			
			if(![txtRenterEmail.text isEqualToString:@""])
			{
			
				BOOL check=[self validateEmail:textField.text];
				if(check==NO)
				{
					NSString *strmessage=[[customMessageList_dict valueForKey:@"200052"]valueForKey:@"message"];
					NSString *strtype=[[customMessageList_dict valueForKey:@"200052"]valueForKey:@"type"];
					
					UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:strtype 
																		  message:strmessage
																		 delegate:self 
																cancelButtonTitle:@"OK" 
																otherButtonTitles:nil];
					[alertWarning show];
					[alertWarning release];
					
				}
				else 
				{
					NSArray *arr=[textField.text componentsSeparatedByString:@".@"];
					if([arr	 count]==2)
					{
						NSString *strmessage=[[customMessageList_dict valueForKey:@"200052"]valueForKey:@"message"];
						NSString *strtype=[[customMessageList_dict valueForKey:@"200052"]valueForKey:@"type"];
						
						UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:strtype
																			  message:strmessage
																			 delegate:self 
																	cancelButtonTitle:@"OK" 
																	otherButtonTitles:nil];
						[alertWarning show];
						[alertWarning release];
						
						
					}
					else 
					{
						
					}
					
			   }
			
								
			}
		}
			
		
	    if([txtEmail.text isEqualToString:@""] && [txtRenterEmail.text isEqualToString:@""])
			
		{
			
			;
		}
		else if(![txtEmail.text isEqualToString:txtRenterEmail.text])
		{
			
			
			
			/*UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:@"Error" 
																  message:@"Email and Re-enter email should be same" 
																 delegate:self 
														cancelButtonTitle:@"OK" 
														otherButtonTitles:nil];
			[alertWarning show];
			[alertWarning release];
			return NO;*/
		}
		
		
	}
	
	 
	else if([txtEmail.text isEqualToString:@""])
		{
			NSString *strmessage=[[customMessageList_dict valueForKey:@"200050"]valueForKey:@"message"];
			NSString *strtype=[[customMessageList_dict valueForKey:@"200050"]valueForKey:@"type"];

			UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:strtype
																  message:strmessage 
																 delegate:self 
														cancelButtonTitle:@"OK" 
														otherButtonTitles:nil];
			[alertWarning show];
			[alertWarning release];
			return NO;
		}
		else if([txtRenterEmail.text isEqualToString:@""])
		 {
	
			 NSString *strmessage=[[customMessageList_dict valueForKey:@"200051"]valueForKey:@"message"];
			 NSString *strtype=[[customMessageList_dict valueForKey:@"200051"]valueForKey:@"type"];

			UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:strtype 
																  message:strmessage 
																 delegate:self 
														cancelButtonTitle:@"OK" 
														otherButtonTitles:nil];
			[alertWarning show];
			[alertWarning release];
			return NO;
		  }

		else if(textField==txtEmail || textField==txtRenterEmail)
			{
				
				
				BOOL check=[self validateEmail:textField.text];
				if(check==NO)
				{
					NSString *strmessage=[[customMessageList_dict valueForKey:@"200052"]valueForKey:@"message"];
					NSString *strtype=[[customMessageList_dict valueForKey:@"200052"]valueForKey:@"type"];

					UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:strtype 
																		  message:strmessage
																		 delegate:self 
																cancelButtonTitle:@"OK" 
																otherButtonTitles:nil];
					[alertWarning show];
					[alertWarning release];
					
				}
				else 
				{
					NSArray *arr=[textField.text componentsSeparatedByString:@".@"];
					if([arr	 count]==2)
					{
						NSString *strmessage=[[customMessageList_dict valueForKey:@"200052"]valueForKey:@"message"];
						NSString *strtype=[[customMessageList_dict valueForKey:@"200052"]valueForKey:@"type"];

						UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:strtype
																			  message:strmessage
																			 delegate:self 
																	cancelButtonTitle:@"OK" 
																	otherButtonTitles:nil];
						[alertWarning show];
						[alertWarning release];
						
						
					}
					else 
					{
						
					}
					
				}
				
			}
	//}
	// else 
	//{
		
		
	
	//}
	
	[textField resignFirstResponder];
	return YES;
	
}
-(void)createbarbuttondone
{
	UIBarButtonItem *doneButton = [[UIBarButtonItem alloc]
								   initWithTitle:@"Done"
								   style:UIBarButtonItemStyleBordered
								   target:self
								   action:@selector(donecancel)];
	
	
	
    self.navigationItem.rightBarButtonItem =doneButton;
	
}

-(void)donecancel
{
	[self  createbar_button];
	
		
	[self Vanishpicker];
	
	
}
-(void)Vanishpicker
{
	if(myPickerView)
	{
		[myPickerView removeFromSuperview];
	    [myPickerView release],myPickerView=nil;
	}
}
-(BOOL)validateEmail:(NSString *)email 
{  
	BOOL stricterFilter = YES; 
	NSString *stricterFilterString = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
	NSString *laxString = @".+@.+\\.[A-Za-z]{2}[A-Za-z]*";
	NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
	NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
	return [emailTest evaluateWithObject:email];
}  
-(void)viewWillAppear:(BOOL)animated
{

	
}
/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
   
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
	txtEmail=nil;
	txtRenterEmail=nil;
	txtOther=nil;
	txtAccountStatement=nil;
	txtInvesmentStatement=nil; 
	pickerViewArrayA=nil;
	pickerViewArrayH=nil;
	pickerViewArrayO=nil;
	arrSelectedlabelA=nil;
	arrSelectedlabelH=nil; 
	arrSelectedlabelO=nil;
	[super viewDidUnload];
}


- (void)dealloc {
	[txtEmail release];
	[txtRenterEmail release];
	[txtOther release];
	[txtAccountStatement release];
	[txtInvesmentStatement release];
	[pickerViewArrayA release];
	[pickerViewArrayH	release];
	[pickerViewArrayO release];
	[arrSelectedlabelA release];
	[arrSelectedlabelH release];
	[arrSelectedlabelO release];
    [super dealloc];
}


@end
