//
//  UnsubmittedClaimParser.m
//  Acclaris
//
//  Created by Subhojit on 01/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "UnsubmittedClaimParser.h"
NSMutableArray *arrgetunsubmittedClaim;

@implementation UnsubmittedClaimParser
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error
{
	
	
	NSXMLParser *parser;
	parser = [[NSXMLParser alloc] initWithData:data];
    [parser setDelegate:self];
	[parser setShouldProcessNamespaces:NO];
    [parser setShouldReportNamespacePrefixes:NO];
    [parser setShouldResolveExternalEntities:NO];
    [parser parse];
    NSError *parseError = [parser parserError];
    if (parseError && error) 
	{
        *error = parseError;
    }
	[parser release];
}

-(void)parserDidStartDocument:(NSXMLParser *)parser
{
	
	arrgetunsubmittedClaim = [[NSMutableArray alloc]init];
}		

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
	if (qName)
	{
		elementName = qName;
	}
	
	else 
		if([elementName isEqualToString:@"claim"])
		{
			
			objunsubmittedClaim=[[UnsubmittedclaimOBJ alloc]init];
			return;
			
			
		}
		else 
			if([elementName isEqualToString:@"id"])
			{
				contentOfString=[NSMutableString string];
				[contentOfString retain];
				return;		
				
			}
			else 
				if([elementName isEqualToString:@"eeID"])
				{
					contentOfString=[NSMutableString string];
					[contentOfString retain];
					return;		
					
				}
			else 
				if([elementName isEqualToString:@"actpCD"])
			{
				contentOfString=[NSMutableString string];
				[contentOfString retain];
				return;		
				
			}
	
			else 
				if([elementName isEqualToString:@"ClaimCategory"])
				{
					contentOfString=[NSMutableString string];
					[contentOfString retain];
					return;		
					
				}
				else 
					if([elementName isEqualToString:@"ClaimType"])
					{
						contentOfString=[NSMutableString string];
						[contentOfString retain];
						return;		
						
					}
					else 
						if([elementName isEqualToString:@"ClaimAmt"])
						{
							contentOfString=[NSMutableString string];
							[contentOfString retain];
							return;		
							
						}
					else 
						if([elementName isEqualToString:@"serviceBegins"])
						{
							contentOfString=[NSMutableString string];
							[contentOfString retain];
							return;		
							
						}
						else 
							if([elementName isEqualToString:@"serviceEnds"])
							{
								contentOfString=[NSMutableString string];
								[contentOfString retain];
								return;		
								
							}
							else 
								if([elementName isEqualToString:@"note"])
								{
									contentOfString=[NSMutableString string];
									[contentOfString retain];
									return;		
									
								}
	
								else 
									if([elementName isEqualToString:@"prevYearPlanInd"])
									{
										contentOfString=[NSMutableString string];
										[contentOfString retain];
										return;		
										
									}
									else 
										if([elementName isEqualToString:@"payeeID"])
										{
											contentOfString=[NSMutableString string];
											[contentOfString retain];
											return;		
											
										}
										else 
											if([elementName isEqualToString:@"paymentRef"])
											{
												contentOfString=[NSMutableString string];
												[contentOfString retain];
												return;		
												
											}
									else 
										if([elementName isEqualToString:@"invoiceNo"])
										{
											contentOfString=[NSMutableString string];
											[contentOfString retain];
											return;		
											
										}
										else 
											if([elementName isEqualToString:@"customerNo"])
											{
												contentOfString=[NSMutableString string];
												[contentOfString retain];
												return;		
												
											}
											else 
												if([elementName isEqualToString:@"providerID"])
												{
													contentOfString=[NSMutableString string];
													[contentOfString retain];
													return;		
													
												}
												else 
													if([elementName isEqualToString:@"providerName"])
													{
														contentOfString=[NSMutableString string];
														[contentOfString retain];
														return;		
														
													}
										else 
											if([elementName isEqualToString:@"elctID"])
											{
												contentOfString=[NSMutableString string];
												[contentOfString retain];
												return;		
												
											}
											else 
												if([elementName isEqualToString:@"accountNo"])
												{
													contentOfString=[NSMutableString string];
													[contentOfString retain];
													return;		
													
													}
								else 
									if([elementName isEqualToString:@"dpndtID"])
									{
										contentOfString=[NSMutableString string];
										[contentOfString retain];
										return;		
										
									}
									else 
										if([elementName isEqualToString:@"reference"])
										{
											contentOfString=[NSMutableString string];
											[contentOfString retain];
											return;		
											
										}
										else 
											if([elementName isEqualToString:@"refNo"])
											{
												contentOfString=[NSMutableString string];
												[contentOfString retain];
												return;		
												
											}
											else 
												if([elementName isEqualToString:@"trxnID"])
												{
													contentOfString=[NSMutableString string];
													[contentOfString retain];
													return;		
													
												}
												else 
													if([elementName isEqualToString:@"description"])
													{
														contentOfString=[NSMutableString string];
														[contentOfString retain];
														return;		
														
													}
													else 
														if([elementName isEqualToString:@"receiptMethod"])
														{
															contentOfString=[NSMutableString string];
															[contentOfString retain];
															return;		
															
														}
														else 
															if([elementName isEqualToString:@"claimBatchType"])
															{
																contentOfString=[NSMutableString string];
																[contentOfString retain];
																return;		
																
															}
															else 
																if([elementName isEqualToString:@"forceReview"])
																{
																	contentOfString=[NSMutableString string];
																	[contentOfString retain];
																	return;		
																	
																}
																else 
																	if([elementName isEqualToString:@"payType"])
																	{
																		contentOfString=[NSMutableString string];
																		[contentOfString retain];
																		return;		
																		
																	}
	
																else 
																	if([elementName isEqualToString:@"hsaRealtimeBalance"])
																	{
																		contentOfString=[NSMutableString string];
																		[contentOfString retain];
																		return;		
																		
																	}

}
- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName     
{	
	if (qName)
	{
		elementName = qName;
		
	}
	
	else 
		if([elementName isEqualToString:@"claim"])
		{
			if(objunsubmittedClaim)
			{
				
				
				[arrgetunsubmittedClaim addObject:objunsubmittedClaim];
				[objunsubmittedClaim release],objunsubmittedClaim=nil;
				
				
				
			}	
			
		}
		else 
			if([elementName isEqualToString:@"id"])
			{
				if(contentOfString)
				{
					
					objunsubmittedClaim.strclaimid=contentOfString;
					[contentOfString release];
					contentOfString = nil;
					
					
				}		
				
			}
			else 
				if([elementName isEqualToString:@"eeID"])
				{
					if(contentOfString)
					{
						objunsubmittedClaim.streeID=contentOfString;							
						[contentOfString release];
						contentOfString = nil;
						
						
					}		
					
				}
				else 
					if([elementName isEqualToString:@"actpCD"])
					{
						if(contentOfString)
						{
							objunsubmittedClaim.stractpCD=contentOfString;							
							[contentOfString release];
							contentOfString = nil;
							
							
						}		
						
					}
					else 
						if([elementName isEqualToString:@"ClaimCategory"])
						{
							if(contentOfString)
							{
								objunsubmittedClaim.strClaimCategory=contentOfString;							
								[contentOfString release];
								contentOfString = nil;
								
								
							}		
							
						}
						else 
							if([elementName isEqualToString:@"ClaimType"])
							{
								if(contentOfString)
								{
									objunsubmittedClaim.strClaimType=contentOfString;							
									[contentOfString release];
									contentOfString = nil;
									
									
								}		
								
							}
							else 
								if([elementName isEqualToString:@"ClaimAmt"])
								{
									if(contentOfString)
									{
										objunsubmittedClaim.strClaimAmt=contentOfString;							
										[contentOfString release];
										contentOfString = nil;
										
										
									}		
									
								}
	
							else 
								if([elementName isEqualToString:@"note"])
								{
									if(contentOfString)
									{
										objunsubmittedClaim.strnote=contentOfString;							
										[contentOfString release];
										contentOfString = nil;
										
										
									}		
									
								}
								else 
									if([elementName isEqualToString:@"serviceBegins"])
									{
										if(contentOfString)
										{
											objunsubmittedClaim.strserviceBegins=contentOfString;							
											[contentOfString release];
											contentOfString = nil;
											
											
										}		
										
									}
									else 
										if([elementName isEqualToString:@"serviceEnds"])
										{
											if(contentOfString)
											{
												objunsubmittedClaim.strserviceEnds=contentOfString;							
												[contentOfString release];
												contentOfString = nil;
												
												
											}		
											
										}
										else 
											if([elementName isEqualToString:@"prevYearPlanInd"])
											{
												if(contentOfString)
												{
													objunsubmittedClaim.strprevYearPlanInd=contentOfString;							
													[contentOfString release];
													contentOfString = nil;
													
													
												}		
												
											}
											else 
												if([elementName isEqualToString:@"payeeID"])
												{
													if(contentOfString)
													{
														objunsubmittedClaim.strpayeeID=contentOfString;							
														[contentOfString release];
														contentOfString = nil;
														
														
													}		
													
												}
												else 
													if([elementName isEqualToString:@"paymentRef"])
													{
														if(contentOfString)
														{
															objunsubmittedClaim.strpaymentRef=contentOfString;							
															[contentOfString release];
															contentOfString = nil;
															
															
														}		
														
													}
													else 
														if([elementName isEqualToString:@"invoiceNo"])
														{
															if(contentOfString)
															{
																objunsubmittedClaim.strinvoiceNo=contentOfString;							
																[contentOfString release];
																contentOfString = nil;
																
																
															}		
															
														}
														else 
															if([elementName isEqualToString:@"customerNo"])
															{
																if(contentOfString)
																{
																	objunsubmittedClaim.strcustomerNo=contentOfString;							
																	[contentOfString release];
																	contentOfString = nil;
																	
																	
																}		
																
															}
															else 
																if([elementName isEqualToString:@"providerID"])
																{
																	if(contentOfString)
																	{
																		objunsubmittedClaim.strproviderID=contentOfString;							
																		[contentOfString release];
																		contentOfString = nil;
																		
																		
																	}		
																	
																}
																else 
																	if([elementName isEqualToString:@"providerName"])
																	{
																		if(contentOfString)
																		{
																			objunsubmittedClaim.strproviderName=contentOfString;							
																			[contentOfString release];
																			contentOfString = nil;
																			
																			
																		}		
																		
																	}
																else 
																	if([elementName isEqualToString:@"elctID"])
																	{
																		if(contentOfString)
																		{
																			objunsubmittedClaim.strelctID=contentOfString;							
																			[contentOfString release];
																			contentOfString = nil;
																			
																			
																		}		
																			
														          }
								else 
									if([elementName isEqualToString:@"accountNo"])
									{
										if(contentOfString)
										{
											objunsubmittedClaim.straccountNo=contentOfString;							
											[contentOfString release];
											contentOfString = nil;
											
											
										}		
										
									}
									else 
										if([elementName isEqualToString:@"dpndtID"])
										{
											if(contentOfString)
											{
												objunsubmittedClaim.strdpndtID=contentOfString;							
												[contentOfString release];
												contentOfString = nil;
												
												
											}		
											
										}
										else 
											if([elementName isEqualToString:@"trxnID"])
											{
												if(contentOfString)
																																			
																																		
												{
													objunsubmittedClaim.strtrxnID=contentOfString;							
													[contentOfString release];
													contentOfString = nil;
													
													
												}		
												
											}
							else 
								if([elementName isEqualToString:@"reference"])
								{
									if(contentOfString)
										
										
									{
										objunsubmittedClaim.strreference=contentOfString;							
										[contentOfString release];
										contentOfString = nil;
										
										
									}		
									
								}
								else 
									if([elementName isEqualToString:@"description"])
									{
										if(contentOfString)
											
											
										{
											objunsubmittedClaim.strdescription=contentOfString;							
											[contentOfString release];
											contentOfString = nil;
											
											
										}		
										
									}
									else 
										if([elementName isEqualToString:@"receiptMethod"])
										{
											if(contentOfString)
												
												
											{
												objunsubmittedClaim.strreceiptMethod=contentOfString;							
												[contentOfString release];
												contentOfString = nil;
												
												
											}		
											
										}
										else 
											if([elementName isEqualToString:@"claimBatchType"])
											{
												if(contentOfString)
													
													
												{
													objunsubmittedClaim.strclaimBatchType=contentOfString;							
													[contentOfString release];
													contentOfString = nil;
													
													
												}		
												
											}
											else 
												if([elementName isEqualToString:@"forceReview"])
												{
													if(contentOfString)
														
														
													{
														objunsubmittedClaim.strforceReview=contentOfString;							
														[contentOfString release];
														contentOfString = nil;
														
														
													}		
													
												}
												else 
													if([elementName isEqualToString:@"payType"])
													{
														if(contentOfString)
															
															
														{
															objunsubmittedClaim.strpayType=contentOfString;							
															[contentOfString release];
															contentOfString = nil;
															
															
														}		
														
													}

												else 
													if([elementName isEqualToString:@"hsaRealtimeBalance"])
													{
														if(contentOfString)
															
															
														{
															objunsubmittedClaim.strhsaRealtimeBalance=contentOfString;							
															[contentOfString release];
															contentOfString = nil;
															
															
														}		
														
													}

}
- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
	if(contentOfString)
		[contentOfString appendString:string];
}

- (void)parserDidEndDocument:(NSXMLParser *)parse

{
	
	NSLog(@"arrgetunsubmittedClaim%@",arrgetunsubmittedClaim);
	for(int i=0;i<[arrgetunsubmittedClaim count];i++)
	 {
		 UnsubmittedclaimOBJ*  myrole=(UnsubmittedclaimOBJ*)[arrgetunsubmittedClaim objectAtIndex:i];
		 NSLog(@">>>>>>%@",myrole.stractpCD);
	 
	// NSLog(@">strpriorYearActivePlan%@",myrole.strpriorYearActivePlan);
	 }
	
	
}	
+(NSMutableArray *)getarrgetunsubmittedClaim
{

	if(arrgetunsubmittedClaim){
		
		return arrgetunsubmittedClaim;
	}
	else
	{
		return nil;
	}
	
	
}
@end
