//
//  CountryParser.m
//  Acclaris
//
//  Created by Subhojit on 26/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "CountryParser.h"
NSMutableArray *arrCountry;

@implementation CountryParser
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error
{
	
	NSXMLParser *parser;
	parser = [[NSXMLParser alloc] initWithData:data];
    [parser setDelegate:self];
	[parser setShouldProcessNamespaces:NO];
    [parser setShouldReportNamespacePrefixes:NO];
    [parser setShouldResolveExternalEntities:NO];
    [parser parse];
    NSError *parseError = [parser parserError];
    if (parseError && error) 
	{
        *error = parseError;
    }
	[parser release];
}

-(void)parserDidStartDocument:(NSXMLParser *)parser
{
	
	arrCountry=[[NSMutableArray alloc]init];
	
}		

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
	if (qName)
	{
		elementName = qName;
	}
	
	
	else 
		if([elementName isEqualToString:@"returnCode"])
		{
			contentOfString=[NSMutableString string];
			[contentOfString retain];
			return;		
			
		}
		else 
			if([elementName isEqualToString:@"errorText"])
			{
				contentOfString=[NSMutableString string];
				[contentOfString retain];
				return;		
				
			}
			else 
				if([elementName isEqualToString:@"country"])
				{
					objcountry=[[CountryOBJ alloc]init];					
				}
				else 
					if([elementName isEqualToString:@"value1"])
					{
						contentOfString=[NSMutableString string];
						[contentOfString retain];
						return;		
						
					}
					else 
						if([elementName isEqualToString:@"value2"])
						{
							contentOfString=[NSMutableString string];
							[contentOfString retain];
							return;		
							
						}
						else 
							if([elementName isEqualToString:@"value3"])
							{
								contentOfString=[NSMutableString string];
								[contentOfString retain];
								return;		
								
							}
	
}
- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName     
{	
	if (qName)
	{
        elementName = qName;
		
    }
	
	else 
		if([elementName isEqualToString:@"returnCode"])
		{
			if(contentOfString)
			{
				
				
				
			}
			
		}
		else 
			if([elementName isEqualToString:@"errorText"])
			{
				
				if(contentOfString)
				{
					
					
				}
			}
			else 
				if([elementName isEqualToString:@"country"])
				{
					if(objcountry)
						
					{
						
						[arrCountry addObject:objcountry];
						[objcountry release],objcountry=nil;
					}
					
				}
				else 
					if([elementName isEqualToString:@"value1"])
					{
						if(contentOfString)
						{
							objcountry.strvalue1=contentOfString;
							[contentOfString release];
							contentOfString = nil;
							
						}
						
					}
					else 
						if([elementName isEqualToString:@"value2"])
						{
							if(contentOfString)
							{
								objcountry.strvalue2=contentOfString;
								[contentOfString release];
								contentOfString = nil;
								
							}
							
							
						}
						else 
							if([elementName isEqualToString:@"value3"])
							{
								if(contentOfString)
								{
									objcountry.strvalue3=contentOfString;
									[contentOfString release];
									contentOfString = nil;
									
								}
								
								
							}
}
- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
	if(contentOfString)
		[contentOfString appendString:string];
}

- (void)parserDidEndDocument:(NSXMLParser *)parse

{
	
	NSLog(@"%d",[arrCountry count]);
	
	for (int i=0; i<[arrCountry count];i++) 
	{
		CountryOBJ *obj=(CountryOBJ *)[arrCountry objectAtIndex:i];
		NSLog(@">>>>%@",obj.strvalue2);
	}
	
	
	
}
+(NSMutableArray *)getarrCountry
{
	
	return arrCountry;
}

@end
