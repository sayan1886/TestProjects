    //
//  alerts.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 07/10/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import "alerts.h"
#import "passPerser.h"
#import "request.h"
#import "alertsOBJ.h"
#import "alertParser.h"
#import "configurables.h"
#import "configurableParser.h"
#import "UserresponcePerser.h"
#import "Decode64.h"
#import "AcclarisViewController.h"
#import "alertsDetails.h"
#import "claimPassthru.h"
#import "request.h"
#import "claimActivity.h"
@implementation alerts

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
    }
    return self;
}
*/
-(id)initWithTabBar:(NSString *)label
{
	if([self init])
	{
		//this is the label on tab button itself
		self.title=label;
		
		self.tabBarItem.image=[UIImage imageNamed:@"Alerts.png"];
		
	}
	return self;
}

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	tools=[[MyTools alloc]init];
	loadingView=[tools createActivityIndicator1];
	NSMutableArray *arr_myconfig=[AcclarisViewController staticarr_config];//[configurableParser getconfig_arr];//
	con=(configurables *)[arr_myconfig objectAtIndex:0];
	self.navigationItem.title=@"Back";
	self.navigationController.navigationBar.tintColor=[UIColor colorWithRed:con.navbarRed/255.0f green:con.navbarGreen/255.0f blue:con.navbarBlue/255.0f alpha:1.0];
	self.view.backgroundColor = [UIColor colorWithRed:con.bgRed/255.0f green:con.bgGreen/255.0f blue:con.bgBlue/255.0f alpha:1.0];
	
	//NSMutableArray *my_arrUserinfo=[UserresponcePerser userdesc];
	
	UIImageView *logo_img = [[UIImageView alloc]initWithFrame:CGRectMake(0, 2, 170, 40)];
	
	NSData *data=[Base64 decode:con.logoImgdata];
	logo_img.image=	[UIImage imageWithData:[NSData dataWithData:data]];
	self.navigationItem.titleView=logo_img;
	
	//////////////Test Purpose///////////////////
	/*bt_previous=[UIButton buttonWithType:UIButtonTypeCustom];
	bt_previous.frame = CGRectMake(0,290, 70, 30);
	//[bt_previous setBackgroundImage:[UIImage imageNamed: @"green-button.png"] forState:UIControlStateNormal];
	//bt_previous.titleLabel.font = [UIFont fontWithName:con.btnfontname size:con.btnfontsize];
	[bt_previous setTitle:@"Test" forState:UIControlStateNormal];
	[bt_previous setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	[bt_previous addTarget:self action:@selector(Test) forControlEvents:UIControlEventTouchUpInside];
	//bt_previous.enabled=NO;

	[self.view addSubview:bt_previous];*/
	
	
   /* bt_next=[UIButton buttonWithType:UIButtonTypeCustom];
    bt_next.frame = CGRectMake(320-70,308+25, 70, 30);
    [bt_next setBackgroundImage:[UIImage imageNamed: @"green-button.png"] forState:UIControlStateNormal];
	bt_next.titleLabel.font = [UIFont fontWithName:con.btnfontname size:con.btnfontsize];
    [bt_next setTitle:@"next" forState:UIControlStateNormal];
    [bt_next setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	[bt_next addTarget:self action:@selector(next) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:bt_next];*/
	
	str_startID1=@"0";
	[self signoutbt];
	//[self reqAlerts];                                                                                                                                                           
}
-(void)Test
{
	
	//ElectronicDeposit *obj=[[ElectronicDeposit alloc]init];
	//[self.navigationController pushViewController:obj animated:YES];
	
	
}
-(void)previous
{
	if (startID<=0)
	{
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Sorry" message:@"No Previous Records" delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
		[alert show];
		[alert release];
		startID=0;
		return ;
	}
	if (startID<=5)
	{
	//	bt_previous.enabled=NO;
		bt_previous.hidden=YES;
	}
	
	startID-=5;
	str_startID1=@"";
	str_startID1=[str_startID1 stringByAppendingFormat:@"%d",startID];
	[str_startID1 retain];
	[acctable removeFromSuperview];
	//bt_next.enabled=YES;
	bt_next.hidden=NO;
	[self reqAlerts]; 
	
}
-(void)next
{
	startID+=5;
	str_startID1=@"";
	str_startID1=[str_startID1 stringByAppendingFormat:@"%d",startID];
	[str_startID1 retain];
	[acctable removeFromSuperview];
	//bt_previous.enabled=YES;
	bt_previous.hidden=NO;
	[self reqAlerts]; 
}

-(void)signoutbt
{
	
	
	UIBarButtonItem *signoutButton = [[UIBarButtonItem alloc]
									  initWithTitle:@"Sign Off"
									  style:UIBarButtonItemStyleBordered
									  target:self
									  action:@selector(signout)];
    self.navigationItem.rightBarButtonItem =signoutButton;
}
-(void)signout
{
	[((AcclarisAppDelegate *)[[UIApplication sharedApplication] delegate]) removeTabBar];
}

-(void)reqAlerts
{
	NSMutableArray *userinfo_arr=[passPerser passresponce];//static method fired
	request *r=[[request alloc] initWithTarget:self
								 SuccessAction:@selector(onSucceffulLogin)
								 FailureAction:@selector(onFailureLogin)];
	[r req_alerts:[userinfo_arr objectAtIndex:2] userid:[userinfo_arr objectAtIndex:4] startid:str_startID1];
	[r release];
	[tools startLoading:self.view childView:loadingView text:@"Loading your Alerts. Wait…"];
	
}		
-(void)onSucceffulLogin
{
	arr_celltytle=[alertParser alertARRresponce];
	if([arr_celltytle count]>1)
	{
		arr_celltytle=[[self sortAlertForSeverity:arr_celltytle] retain];
	}
	[tools stopLoading:loadingView];
	BOOL morerec=[alertParser gethasMoreRecords_alert];
	if (!morerec)
	{
		//bt_next.enabled=NO;
		bt_next.hidden=YES;
	}
	else {
		bt_next.hidden=NO;
	}

	if ([arr_celltytle count]==0) 
	{
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Sorry" message:@"“Currently no data available, please visit again later”" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
		[alert show];
		[alert release];
		return ;
		
	}
	[self createtableview];
}
-(void)onFailureLogin
{
	[tools stopLoading:loadingView];
}
-(NSArray *)sortAlertForSeverity:(NSArray *)unsorted
{
	NSMutableArray *sortedArray=[[[NSMutableArray alloc] init] autorelease];
	
	for(int i=0;i<[unsorted count];i++)
	{
		alertsOBJ *alrtObj1=[unsorted objectAtIndex:i];
		
		if([[alrtObj1.severity lowercaseString] isEqualToString:@"high"])
		{
			[sortedArray addObject:alrtObj1];
		}
	}
	for(int j=0;j<[unsorted count];j++)
	{
		alertsOBJ *alrtObj1=[unsorted objectAtIndex:j];
		
		if([[alrtObj1.severity lowercaseString] isEqualToString:@"medium"])
		{
			[sortedArray addObject:alrtObj1];
		}
	}
	for(int k=0;k<[unsorted count];k++)
	{
		alertsOBJ *alrtObj1=[unsorted objectAtIndex:k];
		
		if([[alrtObj1.severity lowercaseString] isEqualToString:@"low"])
		{
			[sortedArray addObject:alrtObj1];
		}
	}
	if([sortedArray count]==[unsorted count])
		return sortedArray;
	else {
		return nil;
	}
	
}
-(void)createtableview
{
	acctable=[[UITableView alloc] initWithFrame:CGRectMake(0,0,320,290) style:UITableViewStyleGrouped];
	acctable.delegate = self;
	acctable.dataSource = self;
	acctable.scrollEnabled = YES;
	acctable.autoresizesSubviews = YES;
	acctable.showsVerticalScrollIndicator=YES;
	acctable.showsHorizontalScrollIndicator=YES;
	acctable.backgroundColor=[UIColor clearColor];
	[self.view addSubview:acctable];	
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView  
{
	return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	
	return [arr_celltytle  count];
	
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{  
	static NSString *CellIdentifier = @"Cell";
	static NSString *CellIdentifier1 = @"Cell1";
	UITableViewCell *cell;
	NSString *strFont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];
	
	if(cell==nil)
	{
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier] autorelease];
	}
	else
	{
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier1];
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier1] autorelease];
		
	}
		cell.selectionStyle=UITableViewCellSelectionStyleNone;
		cell.backgroundColor=[UIColor whiteColor];
	
		cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;	
	
	
		UIImageView * icon = [[[UIImageView alloc] init] autorelease];//WithFrame:CGRectMake(5, 3, 20, 20)] autorelease];
		NSData *data=[Base64 decode:((alertsOBJ *)[ arr_celltytle objectAtIndex:indexPath.row]).imagePath];
		UIImage *image=	[UIImage imageWithData:[NSData dataWithData:data]];
		icon.image=image;
		if(icon)
		{
			cell.image=icon.image;
		}
	
		UILabel *cellalertlabel=[[UILabel alloc]initWithFrame:CGRectMake(45,3,210,50)];
		cellalertlabel.numberOfLines=0;
		cellalertlabel.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
	
	if ([((alertsOBJ *)[ arr_celltytle objectAtIndex:indexPath.row]).severity isEqualToString:@"High"]) {
		cellalertlabel.textColor=[UIColor colorWithRed:con.linkimpRed/255.0 green:con.linkimpGreen/255.0 blue:con.linkimpBlue/255.0 alpha:1.0];

	}
	else {
		cellalertlabel.textColor=[UIColor colorWithRed:con.linkgnRed/255.0 green:con.linkgnGreen/255.0 blue:con.linkgnBlue/255.0 alpha:1.0];
	}

	
		cellalertlabel.backgroundColor=[UIColor clearColor];
		cellalertlabel.text =((alertsOBJ *)[ arr_celltytle objectAtIndex:indexPath.row]).label;
		[cell.contentView addSubview:cellalertlabel];
		[cellalertlabel release];
		
	
		
	return cell;
	
	
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return 60;
	
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	
	
	if ([((alertsOBJ *)[ arr_celltytle objectAtIndex:indexPath.row]).name isEqualToString:@"RecReqForDBCardsClaims"])
	{
		NSArray *arr_recpt=[[NSArray alloc]initWithObjects:@"Yes",@"DebitCard",nil];
		claimActivity *myclaimActivity = [[claimActivity alloc] initWithArrayName:arr_recpt];
		[self.navigationController pushViewController:myclaimActivity animated:YES];
		
	}
	else if ([((alertsOBJ *)[ arr_celltytle objectAtIndex:indexPath.row]).name isEqualToString:@"OnlineClaimsRecptReqd"])
	{
		NSArray *arr_recpt=[[NSArray alloc]initWithObjects:@"Yes",@"Online",nil];
		claimActivity *myclaimActivity = [[claimActivity alloc] initWithArrayName:arr_recpt];
		[self.navigationController pushViewController:myclaimActivity animated:YES];
		
	}
	else if ([((alertsOBJ *)[ arr_celltytle objectAtIndex:indexPath.row]).name isEqualToString:@"NotPaidPassThruClams"])
	{
		claimPassthru *myclaimPassthru = [[claimPassthru alloc] initWithstring:@"fromAlert"];
		[self.navigationController pushViewController:myclaimPassthru animated:YES];
	}
	
	else  if([((alertsOBJ *)[ arr_celltytle objectAtIndex:indexPath.row]).name isEqualToString:@"MissingEmail"])

	{
		
		EmailInput *obj = [[EmailInput alloc]init];
		[self.navigationController pushViewController:obj animated:YES];
		[obj release],obj=nil;
	}
	else  if([((alertsOBJ *)[ arr_celltytle objectAtIndex:indexPath.row]).name isEqualToString:@"MissingPhone"])
		
	{
		
		
		AddPhoneNumber *obj = [[AddPhoneNumber alloc]init];
		[self.navigationController pushViewController:obj animated:YES];
		[obj release],obj=nil;
	}
	else  if([((alertsOBJ *)[ arr_celltytle objectAtIndex:indexPath.row]).name isEqualToString:@"VerifyEmail"])
		
	{
		
		
		VerifyEmailAddress *obj = [[VerifyEmailAddress alloc]init];
		[self.navigationController pushViewController:obj animated:YES];
		[obj release],obj=nil;
	}
	
	else  if([((alertsOBJ *)[ arr_celltytle objectAtIndex:indexPath.row]).name isEqualToString:@"GoPaperLess"])
		
	{
		
		GopaperLess *obj = [[GopaperLess alloc]init];
		[self.navigationController pushViewController:obj animated:YES];
		[obj release],obj=nil;
	}
	
	else  if([((alertsOBJ *)[ arr_celltytle objectAtIndex:indexPath.row]).name isEqualToString:@"ElectronicDeposit"])
		
	{
		
		ElectronicDeposit *obj = [[ElectronicDeposit alloc]init];
		[self.navigationController pushViewController:obj animated:YES];
		[obj release],obj=nil;
	}
	
	else 
	{
		
		NSString *genericDescription=((alertsOBJ *)[ arr_celltytle objectAtIndex:indexPath.row]).genericDescription;
		alertsDetails *myalertsDetails=[[alertsDetails alloc]initWithString:genericDescription];
		[self.navigationController pushViewController:myalertsDetails animated:YES];
	}

	
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}

-(void)viewWillAppear:(BOOL)animated
{
	[acctable removeFromSuperview];
	[self reqAlerts]; 
}
@end
