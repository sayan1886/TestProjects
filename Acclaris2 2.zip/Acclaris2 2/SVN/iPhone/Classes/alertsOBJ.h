//
//  alertsOBJ.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 07/12/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface alertsOBJ : NSObject {
	NSString	*label;
	NSString	*url;
	NSString	*severity;
	NSString	*imagePath;
	NSString	*priority;
	NSString	*genericDescription;
	NSString	*name;
	
}
@property(nonatomic,retain)NSString	*label;
@property(nonatomic,retain)NSString	*url;
@property(nonatomic,retain)NSString	*severity;
@property(nonatomic,retain)NSString	*imagePath;
@property(nonatomic,retain)NSString	*priority;
@property(nonatomic,retain)NSString	*genericDescription;
@property(nonatomic,retain)NSString	*name;


@end
