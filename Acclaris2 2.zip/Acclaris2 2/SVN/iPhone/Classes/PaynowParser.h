//
//  PaynowParser.h
//  Acclaris
//
//  Created by Subhojit on 22/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PaynowOBJ.h"
#import "PaynowAccountOBJ.h"


@interface PaynowParser : NSObject<NSXMLParserDelegate> {

	PaynowOBJ *objpaynow;
	PaynowAccountOBJ *objpaynowAcc;
	NSMutableString *contentOfString;
	
}
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error;
+(NSMutableArray *)getarrpaynowAccountdetail;
+(NSMutableArray *)getarrpaynowdetail;
@end
