//
//  ticketPerser.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 26/10/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ticketOBJ.h"
#import "ticketLogsOBJ.h"
@class ticketPerser;
@class errorcodeOBJ;

@interface ticketPerser : NSObject<NSXMLParserDelegate> {
	
	ticketOBJ *tickets;
	ticketLogsOBJ *ticketLogs;
	NSMutableArray *arrItem,*arrLogs;
	NSMutableString *contentOfString;
	BOOL ticketID_persed;

	errorcodeOBJ *myerrorcodeOBJ;
	
	
}
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error;
+(NSMutableArray *)ticketArr;
+(NSMutableArray *)geterror_arr;
+(BOOL)gethasMoreRecords;

@end
