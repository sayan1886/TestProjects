//
//  ticketTypePerser.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 08/11/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import "ticketTypePerser.h"
NSMutableArray *arrticketType;

@implementation ticketTypePerser
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error
{
	
	NSXMLParser *parser;
	parser = [[NSXMLParser alloc] initWithData:data];
    [parser setDelegate:self];
	[parser setShouldProcessNamespaces:NO];
    [parser setShouldReportNamespacePrefixes:NO];
    [parser setShouldResolveExternalEntities:NO];
    [parser parse];
    NSError *parseError = [parser parserError];
    if (parseError && error) 
	{
        *error = parseError;
    }
	[parser release];
}

-(void)parserDidStartDocument:(NSXMLParser *)parser
{
	
	arrticketType=[[NSMutableArray alloc]init];
}		

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
	if(qName)
	{
        elementName = qName;
    }	
	
	if([elementName isEqualToString:@"ticketTypes"])
	{	
		ticketType=[[ticketTypeOBJ alloc]init];
		return;		
	}
	else if([elementName isEqualToString:@"category"])
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}	
	else if([elementName isEqualToString:@"label"])
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}	
	else if([elementName isEqualToString:@"note"])
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}
}
- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName     
{	
	if(qName)
	{
        elementName = qName;
		
    }	
	if([elementName isEqualToString:@"ticketTypes"])
	{
		[arrticketType addObject:ticketType ];
		ticketType=nil;			
			
				
	}
	else if([elementName isEqualToString:@"category"])
	{
		if(contentOfString)
		{
			ticketType.category = contentOfString;			
			contentOfString=nil;
		}		
	}
	else if([elementName isEqualToString:@"label"])
	{
		if(contentOfString)
		{
			ticketType.label = contentOfString;			
			contentOfString=nil;
		}		
	}
	else if([elementName isEqualToString:@"note"])
	{
		if(contentOfString)
		{
			ticketType.note = contentOfString;			
			contentOfString=nil;
		}		
	}
	
}	
- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
	if(contentOfString)
		[contentOfString appendString:string];
}
- (void)parserDidEndDocument:(NSXMLParser *)parse
{
	for(int i=0;i<[arrticketType count];i++)
	{
		ticketTypeOBJ *ticket=(ticketTypeOBJ *)[arrticketType objectAtIndex:i];
		NSLog(@"%@",ticket.category);
		NSLog(@"%@",ticket.label);
		NSLog(@"%@",ticket.note);
		NSLog(@"---------------------------\n\n");
	}
}

+(NSMutableArray *)tickettypeArr
{
	if (arrticketType) {
		
		return arrticketType;
	}
	else {
		return nil;
	}
	
}

@end
