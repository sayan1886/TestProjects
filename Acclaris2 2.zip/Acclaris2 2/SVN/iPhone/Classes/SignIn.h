//
//  SignIn.h
//  Acclaris
//
//  Created by Objectsol5 on 23/09/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ASYImage.h"
#import "AcclarisAppDelegate.h"
#import "MyTools.h"
#import "Decode64.h"
#import "SubmitNewClaimTwo.h"
#import "ElectronicDeposit.h"
#import "PaynowClaimsuccess.h"
#import "AddImage.h"
#import "EmailInput.h"
#import "AddPhoneNumber.h"
#import  "VerifyEmailAddress.h"

@class configurables;

@interface SignIn : UIViewController<UITextFieldDelegate>
{
	
	configurables *con;
	MyTools *tools;
	UIView *loadingView;
	
	AcclarisAppDelegate *app;
	UITextField	*txtf_Password;
	NSMutableArray *my_arrUserinfo;

}
-(NSString *)UrlDecoder:(NSString *)url;
+(NSString *)userPass;
+(NSString *)getString;
-(void)onSucceffulLogin1;
-(NSString *)formatString:(NSString *)Uname;  
@end
