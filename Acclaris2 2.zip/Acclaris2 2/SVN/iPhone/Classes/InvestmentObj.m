//
//  InvestmentObj.m
//  Acclaris
//
//  Created by Sumit Kr Prasad on 31/12/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "InvestmentObj.h"


@implementation InvestmentObj
@synthesize date,lblDate;
@synthesize transactionCode, lblTransactionCode;
@synthesize investmentName, lblInvestmentName;
@synthesize units, lblUnits;
@synthesize price, lblPrice;
@synthesize amount, lblAmount;
@synthesize transactionStatus,lblTransactionStatus;
@synthesize contributionType , lblContributionType;
@synthesize optyprDesc,lblOptyprDesc;
@synthesize planID, lblPlanID;
@synthesize sequence, lblSequence;
@synthesize sourceNum, lblSourceNum;
@synthesize activityType, lblActivityType;
@synthesize transactionType, lblTransactionType;
@end
