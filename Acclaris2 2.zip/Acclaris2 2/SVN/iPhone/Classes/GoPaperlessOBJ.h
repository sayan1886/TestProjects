//
//  GoPaperlessOBJ.h
//  Acclaris
//
//  Created by Subhojit on 11/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface GoPaperlessOBJ : NSObject {

	
	NSString *strreturnCode;
	NSString *strerrorText;
	NSString *streeID;
	NSString *strSSN;
	NSString *strerCode;
	NSString *strstatus;
	NSString *streeName;
	NSString *strerName;
	NSString *stradmnID;
	NSString *stradmnName;
	NSString *strbegins;
	NSString *strends;
	NSString *stremail;
	NSString *strisAchValid;
	NSString *strachActNo;
	NSString *strachRoutingNo;
	NSString *strachStatus;
	NSString *strachActType;
	NSString *stremailReqForAch;
	NSString *strdobReqForAch;
	NSString *strdob;
	
}
@property(nonatomic,retain)NSString *strreturnCode;
@property(nonatomic,retain)NSString *strerrorText;
@property(nonatomic,retain)NSString *streeID;
@property(nonatomic,retain)NSString *strSSN;
@property(nonatomic,retain)NSString *strerCode;
@property(nonatomic,retain)NSString *strstatus;
@property(nonatomic,retain)NSString *streeName;
@property(nonatomic,retain)NSString *strerName;
@property(nonatomic,retain)NSString *stradmnID;
@property(nonatomic,retain)NSString *stradmnName;
@property(nonatomic,retain)NSString *strbegins;
@property(nonatomic,retain)NSString *strends;
@property(nonatomic,retain)	NSString *stremail;
@property(nonatomic,retain)NSString *strisAchValid;
@property(nonatomic,retain)	NSString *strachActNo;
@property(nonatomic,retain)NSString *strachRoutingNo;
@property(nonatomic,retain)NSString *strachStatus;
@property(nonatomic,retain)NSString *strachActType;
@property(nonatomic,retain)NSString *stremailReqForAch;
@property(nonatomic,retain) NSString *strdob;
@property(nonatomic,retain) NSString *strdobReqForAch;

@end
