//
//  images.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 07/10/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyTools.h"
#import "ImageDetail.h"
@class configurables;
@interface images : UIViewController<UITableViewDelegate,UITableViewDataSource> {

	configurables *con;
	MyTools *tools;
	UIView *loadingView;
	NSMutableArray *arr_celltytle;
	UITableView *acctable;
	
	NSInteger startID;
	NSString *str_startID1;
	UIButton *bt_previous;
	UIButton *bt_next;
	
}
-(id)initWithTabBar;
-(void)reqImage;
-(void)createtableview;
-(void)signoutbt;
-(void)createHeader;
@end
