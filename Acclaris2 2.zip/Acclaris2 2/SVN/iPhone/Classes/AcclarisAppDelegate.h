//
//  AcclarisAppDelegate.h
//  Acclaris
//
//  Created by Subhojit on 29/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Reachability.h"
@class AcclarisViewController;

@interface AcclarisAppDelegate : NSObject <UIApplicationDelegate,UITabBarControllerDelegate> {
    UIWindow *window;
    AcclarisViewController *viewController;
	//NSMutableArray *arr_accInfo,*arr_transaction;
	UINavigationController *MyNavigationController;
	//UIImage *logoIMG;
	UITabBarController *tabBarController;
	NSString *checkclassname;
	
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet AcclarisViewController *viewController;
@property (nonatomic, retain)NSString *checkclassname;
@property (nonatomic, retain)UITabBarController *tabBarController;
//@property (nonatomic, retain) UIImage *logoIMG;

-(void)createTabBar;
-(void)createNavigation;
-(void)removeTabBar;
+(void)updateStatus;
+(BOOL)isNetworkAvailable;
-(void)setupNetworkCheck;
-(void)testing;

@end

