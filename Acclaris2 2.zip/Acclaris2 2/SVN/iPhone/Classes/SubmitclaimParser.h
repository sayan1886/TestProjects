//
//  SubmitclaimParser.h
//  Acclaris
//
//  Created by Subhojit on 08/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SubmitclaimOBJ.h"


@interface SubmitclaimParser : NSObject<NSXMLParserDelegate> {

	NSMutableString *contentOfString;
	SubmitclaimOBJ *objSubmitclaim;
	NSString *strWhichtag;
	
	
	
}
+(NSMutableArray *)getarrdenydetail;
+(NSMutableArray *)getarrReceiptrequired;
+(NSMutableArray *)getarrpendingclaim;
+(NSString *)getErrortxt;
+(NSString *)getstrtrxnID;
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error;
@end
