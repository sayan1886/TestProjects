//
//  confirmationPage.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 29/04/11.
//  Copyright 2011 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@class configurables;
@class MyTools;
@interface confirmationPage : UIViewController {

	configurables *con;
	MyTools *tools;
	NSString *message;
	
	id target;
	SEL successHandler;
	SEL failureHandler;
}
-(void)createView;
-(id)initWithstring:(NSString *)mesg Target:(id)actionTarget
	  SuccessAction:(SEL)successAction 
	  FailureAction:(SEL)failureAction;
@end
