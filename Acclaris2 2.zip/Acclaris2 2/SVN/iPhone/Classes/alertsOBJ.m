//
//  alertsOBJ.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 07/12/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import "alertsOBJ.h"


@implementation alertsOBJ

@synthesize label;
@synthesize url;
@synthesize severity;
@synthesize imagePath;
@synthesize priority;
@synthesize genericDescription;
@synthesize name;





@end
