    //
//  Paynow.m
//  Acclaris
//
//  Created by Subhojit on 28/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Paynow.h"
#import "configurables.h"
#import "AcclarisViewController.h"

@implementation Paynow


- (void)viewDidLoad {
    [super viewDidLoad];
	
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	tools=[[MyTools alloc]init];
	loadingView=[tools createActivityIndicator1];
	
	pickerViewArray=[[NSMutableArray alloc]init];
	arrpaynow=[PaynowParser getarrpaynowdetail];
	
	objpay=(PaynowOBJ *)[arrpaynow objectAtIndex:0];

	NSLog(@"objpay.arr %@",objpay.arr);

	for(int i=0; i<[objpay.arr count];i++)
		
	{
		
				
		[pickerViewArray addObject:((PaynowAccountOBJ *)[objpay.arr objectAtIndex:i]).straccountTypeDesc];

		
	}
	
		
	
	NSLog(@"pickerViewArray %@",pickerViewArray);
	
	
	
	NSMutableArray *arr_myconfig=[AcclarisViewController staticarr_config];
	con=(configurables *)[arr_myconfig objectAtIndex:0];
	strFront=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];

	self.view.backgroundColor = [UIColor colorWithRed:con.bgRed/255.0f green:con.bgGreen/255.0f blue:con.bgBlue/255.0f alpha:1.0];
	
	self.navigationController.navigationBar.tintColor=[UIColor colorWithRed:con.navbarRed/255.0f green:con.navbarGreen/255.0f blue:con.navbarBlue/255.0f alpha:1.0];
	
	UIImageView *logo_img = [[UIImageView alloc]initWithFrame:CGRectMake(0, 2, 170, 40)];
	NSData *data=[Base64 decode:con.logoImgdata];
	logo_img.image=	[UIImage imageWithData:[NSData dataWithData:data]];
	self.navigationItem.titleView=logo_img;
	
	
	[self createbar_button];
	
	[self CreateView];
}
-(void)createbar_button
{
	
	UIBarButtonItem *signoutButton = [[UIBarButtonItem alloc]
									  initWithTitle:@"Sign Off"
									  style:UIBarButtonItemStyleBordered
									  target:self
									  action:@selector(signout)];
	self.navigationItem.rightBarButtonItem =signoutButton;
	
}

-(void)signout
{
	
	[((AcclarisAppDelegate *)[[UIApplication sharedApplication] delegate]) removeTabBar];
	
}

-(void)CreateView
{
	
	NSData *data_btnimg=[Base64 decode:con.btnImgdata];//btn background image

	table=[[UITableView alloc]initWithFrame:CGRectMake(0, 65, 320, 215+15) style:UITableViewStylePlain];
	table.backgroundColor = [UIColor clearColor];
	table.bounces = YES;
	table.delegate=self;
	table.dataSource=self;
	table.separatorColor=[UIColor clearColor];
	[self.view addSubview:table];
	
	UIView *HeaderView=[[[UIView alloc]initWithFrame:CGRectMake(0, 0, 320, 45)]autorelease];
	HeaderView.backgroundColor=[UIColor colorWithRed:con.bgRed2/255.0 green:con.bgGreen2/255.0 blue:con.bgBlue2/255.0 alpha:1.0];
	[self.view addSubview:HeaderView];
	
	NSString *strViewTitle=@"Claims To Pay";
	//strViewTitle=[strViewTitle stringByAppendingString:@"\n"];
	//strViewTitle=[strViewTitle stringByAppendingFormat:@"%@",@"Claim"];
	
	UILabel *lbltext=[[UILabel alloc]initWithFrame:CGRectMake(10, 3, 230, 40)];
	lbltext.text=strViewTitle;
	lbltext.backgroundColor=[UIColor clearColor];
	lbltext.textColor=[UIColor whiteColor];
	lbltext.numberOfLines=0;
	lbltext.font=[UIFont fontWithName:@"Helvetica-Bold" size:18];
	[HeaderView addSubview:lbltext];
	[lbltext release],lbltext=nil;
	
	
	/*UIView *secondView=[[[UIView alloc]initWithFrame:CGRectMake(0,243, 320, 40)]autorelease];
	secondView.backgroundColor=[UIColor colorWithRed:con.bgRed2/255.0 green:con.bgGreen2/255.0 blue:con.bgBlue2/255.0 alpha:1.0];
	[self.view addSubview:secondView];
	
	NSString *strViewTitlesecond=@"Select";
	//strViewTitle=[strViewTitle stringByAppendingString:@"\n"];
	//strViewTitle=[strViewTitle stringByAppendingFormat:@"%@",@"Claim"];
	
	UILabel *lbltextsecond=[[UILabel alloc]initWithFrame:CGRectMake(10, 3, 210, 35)];
	lbltextsecond.text=strViewTitlesecond;
	lbltextsecond.backgroundColor=[UIColor clearColor];
	lbltextsecond.textColor=[UIColor whiteColor];
	lbltextsecond.numberOfLines=0;
	lbltextsecond.font=[UIFont fontWithName:@"Helvetica-Bold" size:18];
	[secondView addSubview:lbltextsecond];
	[lbltextsecond release],lbltextsecond=nil;
	
	btnRadio=[UIButton buttonWithType:UIButtonTypeCustom];
	btnRadio.frame=CGRectMake(10, 290, 25, 20);
	[btnRadio setBackgroundImage:[UIImage imageNamed:@"rdo_btn.png"] forState:UIControlStateNormal];
	[btnRadio addTarget:self action:@selector(ClickbtnRadio:) forControlEvents:UIControlEventTouchUpInside];
	[self.view addSubview:btnRadio];
	
	UILabel *lblPayself=[[UILabel alloc]initWithFrame:CGRectMake(43, 282, 60, 35)];
	lblPayself.text=@"Pay Self";
	lblPayself.backgroundColor=[UIColor clearColor];
	lblPayself.textColor=[UIColor blackColor];
	lblPayself.font=[UIFont fontWithName:@"Helvetica-Bold" size:13];
	[self.view addSubview:lblPayself];
	[lblPayself release],lblPayself=nil;
	
	
	btnRadio1=[UIButton buttonWithType:UIButtonTypeCustom];
	btnRadio1.frame=CGRectMake(210, 290, 25, 20);
	[btnRadio1 setBackgroundImage:[UIImage imageNamed:@"rdo_btn.png"] forState:UIControlStateNormal];
	[btnRadio1 addTarget:self action:@selector(ClickbtnRadio1:) forControlEvents:UIControlEventTouchUpInside];
	[self.view addSubview:btnRadio1];
	
	
	UILabel *lblother=[[UILabel alloc]initWithFrame:CGRectMake(245, 282, 70, 35)];
	lblother.text=@"Pay Others";
	lblother.backgroundColor=[UIColor clearColor];
	lblother.textColor=[UIColor blackColor];
	lblother.font=[UIFont fontWithName:@"Helvetica-Bold" size:13];
	[self.view addSubview:lblother];
	[lblother release],lblother=nil;*/
	
	
	
	UIButton *btnContinue=[UIButton buttonWithType:UIButtonTypeCustom];
	btnContinue.frame=CGRectMake(30, 320, 260, 40);
	[btnContinue setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
	[btnContinue setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	btnContinue.titleLabel.font = [UIFont fontWithName:con.btnfontname size:con.btnfontsize];
	[btnContinue setTitle:@"Continue" forState:UIControlStateNormal];
	[btnContinue addTarget:self action:@selector(ClickbtnContinue) forControlEvents:UIControlEventTouchUpInside];					 
	[self.view addSubview:btnContinue];
	
	
	[self constructTableCell];
	
	
}
-(void)ClickbtnRadio:(id)sender
{
	
	
	if(btnRadio.currentBackgroundImage==[UIImage imageNamed:@"rdo_btn.png"])
	{
		strPaystatus=@"Self";
		
		[btnRadio setBackgroundImage:[UIImage imageNamed:@"rdo_btn_ckd.png"] forState:UIControlStateNormal];
	    [btnRadio1 setBackgroundImage:[UIImage imageNamed:@"rdo_btn.png"] forState:UIControlStateNormal];
	}
	
	else 
	{
		
		
		//[btnRadio setBackgroundImage:[UIImage imageNamed:@"rdo_btn.png"] forState:UIControlStateNormal];
		//[btnRadio setBackgroundImage:[UIImage imageNamed:@"rdo_btn_ckd.png"] forState:UIControlStateNormal];
		
	}
	
	
}

-(void)ClickbtnRadio1:(id)sender
{
	
	
	if(btnRadio1.currentBackgroundImage==[UIImage imageNamed:@"rdo_btn.png"])
	{
		strPaystatus=@"Other";
		[btnRadio1 setBackgroundImage:[UIImage imageNamed:@"rdo_btn_ckd.png"] forState:UIControlStateNormal];
	    [btnRadio setBackgroundImage:[UIImage imageNamed:@"rdo_btn.png"] forState:UIControlStateNormal];
	}
	
	else {
		
		//[btnRadio1 setBackgroundImage:[UIImage imageNamed:@"rdo_btn.png"] forState:UIControlStateNormal];
		
	}
	
}
-(void)ClickbtnContinue
{
	if([txtSelectAccount.text isEqualToString:@""])
	{
		
		
		UIAlertView *alertview=[[UIAlertView alloc]initWithTitle:@"Info" message:@"Select Account" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		alertview.delegate=self;
		[alertview show];
		[alertview release],alertview=nil;
		return ;
		
		
	}
	
	else if(btnRadio.currentBackgroundImage==[UIImage imageNamed:@"rdo_btn.png"] && btnRadio1.currentBackgroundImage==[UIImage imageNamed:@"rdo_btn.png"])
	{
		
		UIAlertView *alertview=[[UIAlertView alloc]initWithTitle:@"Info" message:@"Select Payee" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		alertview.delegate=self;
		[alertview show];
		[alertview release],alertview=nil;
		return ;
		
	}
	
	else 
		
	{
		
	
	DictSavedSubmitclaimInfo=[[NSMutableDictionary alloc]init];
	[DictSavedSubmitclaimInfo setObject:((PaynowOBJ *)[arrpaynow objectAtIndex:0]).strid forKey:@"claimid"]; 
	[DictSavedSubmitclaimInfo setObject:((PaynowAccountOBJ *)[objpay.arr objectAtIndex:Selectedpickerrow]).strlabelAssociatedValue forKey:@"Account"]; 
	[DictSavedSubmitclaimInfo setObject:strPaystatus forKey:@"paystatus"]; 

	

	if([strPaystatus isEqualToString:@"Self"])
	{
	
		NSMutableArray *userinfo_arr=[passPerser passresponce];
		
		
		RequestPhase2 *objrequestPhase2=[[RequestPhase2 alloc] initWithTarget:self
																SuccessAction:@selector(onSuccesful)
																FailureAction:@selector(onFailure)];
		
		[objrequestPhase2 ClaimsToPaySubmit:[userinfo_arr objectAtIndex:2] userid:[userinfo_arr objectAtIndex:4] claimID:((PaynowOBJ *)[arrpaynow objectAtIndex:0]).strid payMode:strPaystatus actpCD:((PaynowAccountOBJ *)[objpay.arr objectAtIndex:Selectedpickerrow]).strlabelAssociatedValue PayeeId:@""];
		
		[objrequestPhase2 release];
		
		[tools startLoading:self.view childView:loadingView text:@"Loading your Claim activity. Wait…."];
	}
	else 
	{
		
		type=self;
		
		SelectServiceProvider *obj=[[SelectServiceProvider alloc]initwithDict:DictSavedSubmitclaimInfo withtype:type];
		[self.navigationController pushViewController:obj animated:YES];
		
	}
 }
	
}
-(void)onSuccesful
{
 
	[tools stopLoading:loadingView];
	
	NSString *str=[PaynowcontinueParser  getErrortext];
	NSString *returncode=[PaynowcontinueParser getreturncode];
	
	if([returncode isEqualToString:@"0"])
	{
		
		if([strPaystatus isEqualToString:@"Self"])
		{
			
			PaynowClaimsuccess *obj=[[[PaynowClaimsuccess alloc]init]autorelease];
			[self.navigationController pushViewController:obj animated:YES];
			
		
		}
		else 
			
		{
			
		
			//type=self;
			
			//SelectServiceProvider *obj=[[SelectServiceProvider alloc]initwithDict:DictSavedSubmitclaimInfo withtype:type];
			//[self.navigationController pushViewController:obj animated:YES];
			
			
			UIAlertView *alertview=[[UIAlertView alloc]initWithTitle:@"Info" message:str delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
			alertview.delegate=self;
			[alertview show];
			[alertview release],alertview=nil;
			
			
		}

		
	}
	 else
		 
	{
		
		UIAlertView *alertview=[[UIAlertView alloc]initWithTitle:@"Info" message:str delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
		alertview.delegate=self;
		[alertview show];
		[alertview release],alertview=nil;
		
	}

		
}

-(void)onFailure
{
	
	[tools stopLoading:loadingView];

}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	
    return 1;
}



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	
	
	return 7;
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	
   	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
	if(nil == cell)
	{
		NSLog(@"%@",[[arrAllSection objectAtIndex:0] objectAtIndex:indexPath.row]);
		cell = [[arrAllSection objectAtIndex:0] objectAtIndex:indexPath.row];
		
	}
	
	
	cell.selectionStyle = UITableViewCellSelectionStyleNone;
	
    return cell;
	
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	
	
	return 47.0;
	
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath

{
	
	
	
	
}

-(void)constructTableCell
{
	arrAllSection = [[NSMutableArray alloc] init];
	
#pragma mark --First Section
	NSMutableArray *arrFirstSection = [[NSMutableArray alloc]init];
	
	UITableViewCell *cell00 = [[UITableViewCell alloc] init];
	[self DateInput:cell00];
	[arrFirstSection addObject:cell00];
	[cell00 release];
	
	UITableViewCell *cell01 = [[UITableViewCell alloc] init];
	[self FromInput:cell01];
	[arrFirstSection addObject:cell01];
	[cell01 release];
	
	UITableViewCell *cell02 = [[UITableViewCell alloc] init];
	[self CatagoryInput:cell02];
	[arrFirstSection addObject:cell02];
	[cell02 release];
	
	UITableViewCell *cell03 = [[UITableViewCell alloc] init];
	[self AmountInput:cell03];
	[arrFirstSection addObject:cell03];
	[cell03 release];
	
	
	/*UITableViewCell *cell10 = [[UITableViewCell alloc] init];
	[self InvoiceInput:cell10];
	[arrFirstSection addObject:cell10];
	[cell10 release];
	
	UITableViewCell *cell11 = [[UITableViewCell alloc] init];
	[self AccountInput:cell11];
	[arrFirstSection addObject:cell11];
	[cell11 release];
	
	UITableViewCell *cell12 = [[UITableViewCell alloc] init];
	[self paymentInput:cell12];
	[arrFirstSection addObject:cell12];
	[cell12 release];*/
	
	UITableViewCell *cell13 = [[UITableViewCell alloc] init];
	[self SelectAccountInput:cell13];
	[arrFirstSection addObject:cell13];
	[cell13 release];
	
	
	UITableViewCell *cell14 = [[UITableViewCell alloc] init];
	[self HeadertypeInput:cell14];
	[arrFirstSection addObject:cell14];
	[cell14 release];
	
	UITableViewCell *cell15 = [[UITableViewCell alloc] init];
	[self PaytypeInput:cell15];
	[arrFirstSection addObject:cell15];
	[cell15 release];
	
	[arrAllSection addObject:arrFirstSection];
	[arrFirstSection release];
	
}
-(void)DateInput:(UITableViewCell *)cell
{
	UILabel *lblDate = [[UILabel alloc]initWithFrame:CGRectMake(10,0,85,35)];
	lblDate.backgroundColor = [UIColor clearColor];
	lblDate.text=@"Date";
	lblDate.font = [UIFont fontWithName:strFront size:con.bodyImpfntsize];
	lblDate.textAlignment = UITextAlignmentLeft;
	lblDate.textColor=[UIColor blackColor];
	[cell.contentView addSubview:lblDate];
	[lblDate release], lblDate = nil;	
	
	txtDate = [[UITextField alloc]initWithFrame:CGRectMake(105,5,130,30)];
	txtDate.backgroundColor = [UIColor clearColor];
	txtDate.autocorrectionType = UITextAutocorrectionTypeNo;
	
	NSString *strtxtDate=((PaynowOBJ *)[arrpaynow objectAtIndex:0]).strserviceBegins;

	
	if (strtxtDate.length == 0 )
		
		txtDate.text=@"";
	else
		txtDate.text=strtxtDate;
	
	txtDate.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	txtDate.keyboardType=UIKeyboardTypeDefault;
	txtDate.delegate=self;
	txtDate.borderStyle = UITextBorderStyleLine;
	[focusArray addObject:txtDate];
	
	[cell.contentView addSubview:txtDate];			
	
}

#pragma mark -
#pragma mark emailInput Method

-(void)FromInput:(UITableViewCell *)cell
{
	
	UILabel *lblFrom = [[UILabel alloc]initWithFrame:CGRectMake(10,5,85,35)];
	lblFrom.backgroundColor = [UIColor clearColor];
	lblFrom.text=@"From";
	lblFrom.font =[UIFont fontWithName:strFront size:con.bodyImpfntsize];
	lblFrom.textAlignment = UITextAlignmentLeft;
	lblFrom.textColor=[UIColor blackColor];
	[cell.contentView addSubview:lblFrom];
	[lblFrom release], lblFrom = nil;	
	
	txtFrom = [[UITextField alloc]initWithFrame:CGRectMake(105,5,200,30)];
	txtFrom.backgroundColor = [UIColor clearColor];
	txtFrom.autocorrectionType = UITextAutocorrectionTypeNo;
	
	NSString *strtxtFrom=((PaynowOBJ *)[arrpaynow objectAtIndex:0]).strproviderName;

	
	if (strtxtFrom.length == 0 )
		
		txtFrom.text=@"";
	else
		txtFrom.text=strtxtFrom;
	
	txtFrom.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	txtFrom.keyboardType=UIKeyboardTypeDefault;
	txtFrom.delegate=self;
	txtFrom.borderStyle = UITextBorderStyleLine;
	[focusArray addObject:txtFrom];
	
	[cell.contentView addSubview:txtFrom];
}
-(void)CatagoryInput:(UITableViewCell *)cell
{
	UILabel *lblCatagory = [[UILabel alloc]initWithFrame:CGRectMake(10,5,85,35)];
	lblCatagory.backgroundColor = [UIColor clearColor];
	lblCatagory.text=@"Category";
	lblCatagory.font =[UIFont fontWithName:strFront size:con.bodyImpfntsize];
	lblCatagory.textAlignment = UITextAlignmentLeft;
	lblCatagory.textColor=[UIColor blackColor];
	[cell.contentView addSubview:lblCatagory];
	[lblCatagory release], lblCatagory = nil;
	
	
	txtCatagory = [[UITextField alloc]initWithFrame:CGRectMake(105,5,200,30)];
	txtCatagory.backgroundColor = [UIColor clearColor];
	txtCatagory.autocorrectionType = UITextAutocorrectionTypeNo;
	
	NSString *strtxtCatagory=((PaynowOBJ *)[arrpaynow objectAtIndex:0]).strClaimCategory;

	
	if (strtxtCatagory.length == 0 )
		
		txtCatagory.text=@"";
	else
		txtCatagory.text=strtxtCatagory;	
	
	txtCatagory.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	
	txtCatagory.keyboardType=UIKeyboardTypeEmailAddress;
	txtCatagory.delegate=self;
	txtCatagory.borderStyle = UITextBorderStyleLine;
	[focusArray addObject:txtCatagory];
	
	[cell.contentView addSubview:txtCatagory];
	
}

#pragma mark -
#pragma mark DOBInput Method

-(void)AmountInput:(UITableViewCell *)cell
{
	UILabel *lblAmount = [[UILabel alloc]initWithFrame:CGRectMake(10,5,85,35)];
	lblAmount.backgroundColor = [UIColor clearColor];
	lblAmount.text=@"Amount";
	lblAmount.font = [UIFont fontWithName:strFront size:con.bodyImpfntsize];
	lblAmount.textAlignment = UITextAlignmentLeft;
	lblAmount.textColor=[UIColor blackColor];
	[cell.contentView addSubview:lblAmount];
	[lblAmount release], lblAmount = nil;	
	
	txtAmount = [[UITextField alloc]initWithFrame:CGRectMake(105,5,130,30)];
	txtAmount.backgroundColor = [UIColor clearColor];
	txtAmount.autocorrectionType = UITextAutocorrectionTypeNo;
	
	NSString *strtxtAmount=((PaynowOBJ *)[arrpaynow objectAtIndex:0]).strClaimAmt;

	if (strtxtAmount.length == 0 )
		
		txtAmount.text=@"";
	else
		txtAmount.text=strtxtAmount;
	
	txtAmount.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	txtAmount.keyboardType=UIKeyboardTypeNumberPad;
	txtAmount.delegate=self;
	txtAmount.borderStyle = UITextBorderStyleLine;
	[focusArray addObject:txtAmount];
	
	[cell.contentView addSubview:txtAmount];
}
-(void)HeadertypeInput:(UITableViewCell *)cell
{
	
	
	UIView *secondView=[[[UIView alloc]initWithFrame:CGRectMake(0,0, 320, 40)]autorelease];
	secondView.backgroundColor=[UIColor colorWithRed:con.bgRed2/255.0 green:con.bgGreen2/255.0 blue:con.bgBlue2/255.0 alpha:1.0];
	[cell.contentView addSubview:secondView];
	
	
	NSString *strViewTitlesecond=@"Select Payee";
	//strViewTitle=[strViewTitle stringByAppendingString:@"\n"];
	//strViewTitle=[strViewTitle stringByAppendingFormat:@"%@",@"Claim"];
	
	
	UILabel *lbltextsecond=[[UILabel alloc]initWithFrame:CGRectMake(10, 3, 210, 35)];
	lbltextsecond.text=strViewTitlesecond;
	lbltextsecond.backgroundColor=[UIColor clearColor];
	lbltextsecond.textColor=[UIColor whiteColor];
	lbltextsecond.numberOfLines=0;
	lbltextsecond.font=[UIFont fontWithName:strFront size:con.headerImpfntsize];
	[cell.contentView addSubview:lbltextsecond];
	[lbltextsecond release],lbltextsecond=nil;
	
	
	
}
-(void)PaytypeInput:(UITableViewCell *)cell

{
	
	
	btnRadio=[UIButton buttonWithType:UIButtonTypeCustom];
	btnRadio.frame=CGRectMake(10, 10, 25, 25);
	[btnRadio setBackgroundImage:[UIImage imageNamed:@"rdo_btn.png"] forState:UIControlStateNormal];
	[btnRadio addTarget:self action:@selector(ClickbtnRadio:) forControlEvents:UIControlEventTouchUpInside];
	[cell.contentView addSubview:btnRadio];
	
	UILabel *lblPayself=[[UILabel alloc]initWithFrame:CGRectMake(43, 4, 60, 35)];
	lblPayself.text=@"Pay Self";
	lblPayself.backgroundColor=[UIColor clearColor];
	lblPayself.textColor=[UIColor blackColor];
	lblPayself.font=[UIFont fontWithName:@"Helvetica-Bold" size:13];
	[cell.contentView addSubview:lblPayself];
	[lblPayself release],lblPayself=nil;
	
	
	btnRadio1=[UIButton buttonWithType:UIButtonTypeCustom];
	btnRadio1.frame=CGRectMake(180, 10, 25, 25);
	[btnRadio1 setBackgroundImage:[UIImage imageNamed:@"rdo_btn.png"] forState:UIControlStateNormal];
	[btnRadio1 addTarget:self action:@selector(ClickbtnRadio1:) forControlEvents:UIControlEventTouchUpInside];
	[cell.contentView addSubview:btnRadio1];
	
	UILabel *lblother=[[UILabel alloc]initWithFrame:CGRectMake(215, 4, 70, 35)];
	lblother.text=@"Pay Others";
	lblother.backgroundColor=[UIColor clearColor];
	lblother.textColor=[UIColor blackColor];
	lblother.font=[UIFont fontWithName:@"Helvetica-Bold" size:13];
	[cell.contentView addSubview:lblother];
	[lblother release],lblother=nil;
	
	
}

#pragma mark -
#pragma mark sexInput Method

/*-(void)InvoiceInput:(UITableViewCell *)cell
{
	
	UILabel *lblinvoice = [[UILabel alloc]initWithFrame:CGRectMake(10,5,85,35)];
	lblinvoice.backgroundColor = [UIColor clearColor];
	lblinvoice.text=@"Invoice#";
	lblinvoice.font = [UIFont fontWithName:@"Helvetica-Bold" size:15];
	lblinvoice.textAlignment = UITextAlignmentLeft;
	lblinvoice.textColor=[UIColor blackColor];
	[cell.contentView addSubview:lblinvoice];
	[lblinvoice release], lblinvoice = nil;	
	
	txtinvoice = [[UITextField alloc]initWithFrame:CGRectMake(105,5,200,30)];
	txtinvoice.backgroundColor = [UIColor clearColor];
	txtinvoice.autocorrectionType = UITextAutocorrectionTypeNo;
	txtinvoice.text=@"";
	txtinvoice.keyboardType=UIKeyboardTypeNumberPad;
	txtinvoice.delegate=self;
	txtinvoice.borderStyle = UITextBorderStyleLine;
	[focusArray addObject:txtinvoice];
	
	[cell.contentView addSubview:txtinvoice];
}

#pragma mark -
#pragma mark lookingForInput Method

-(void)AccountInput:(UITableViewCell *)cell
{
	UILabel *lblAccount = [[UILabel alloc]initWithFrame:CGRectMake(10,5,85,35)];
	lblAccount.backgroundColor = [UIColor clearColor];
	lblAccount.text=@"Account#";
	lblAccount.font = [UIFont fontWithName:@"Helvetica-Bold" size:15];
	lblAccount.textAlignment = UITextAlignmentLeft;
	lblAccount.textColor=[UIColor blackColor];
	[cell.contentView addSubview:lblAccount];
	[lblAccount release], lblAccount = nil;
	
	txtAccount = [[UITextField alloc]initWithFrame:CGRectMake(105,5,200,30)];
	txtAccount.backgroundColor = [UIColor clearColor];
	txtAccount.autocorrectionType = UITextAutocorrectionTypeNo;
	txtAccount.text=@"";
	txtAccount.keyboardType=UIKeyboardTypeDefault;
	txtAccount.delegate=self;
	txtAccount.borderStyle = UITextBorderStyleLine;
	[focusArray addObject:txtAccount];
	
	[cell.contentView addSubview:txtAccount];
}

#pragma mark -
#pragma mark ageUpperInput Method

-(void)paymentInput:(UITableViewCell *)cell
{
	UILabel *lblpayment = [[UILabel alloc]initWithFrame:CGRectMake(10,5,85,35)];
	lblpayment.backgroundColor = [UIColor clearColor];
	lblpayment.text=@"Payment Reff";
	lblpayment.font = [UIFont fontWithName:@"Helvetica-Bold" size:15];
	lblpayment.textAlignment = UITextAlignmentLeft;
	lblpayment.textColor=[UIColor blackColor];
	[cell.contentView addSubview:lblpayment];
	[lblpayment release], lblpayment = nil;
	
	txtpayment = [[UITextField alloc]initWithFrame:CGRectMake(105,5,200,30)];
	txtpayment.backgroundColor = [UIColor clearColor];
	txtpayment.autocorrectionType = UITextAutocorrectionTypeNo;
	txtpayment.text=@"";
	txtpayment.keyboardType=UIKeyboardTypeDefault;
	txtpayment.delegate=self;
	txtpayment.borderStyle = UITextBorderStyleLine;
	[focusArray addObject:txtpayment];
	
	[cell.contentView addSubview:txtpayment];
	
}
*/
#pragma mark -
#pragma mark AgeLowerInput Method

-(void)SelectAccountInput:(UITableViewCell *)cell
{
	UILabel *lblSelectAccount = [[UILabel alloc]initWithFrame:CGRectMake(10,5,90,40)];
	lblSelectAccount.backgroundColor = [UIColor clearColor];
	lblSelectAccount.text=@"Select Account";
	lblSelectAccount.numberOfLines=0;
	lblSelectAccount.font =[UIFont fontWithName:strFront size:con.bodyImpfntsize];
	lblSelectAccount.textAlignment = UITextAlignmentLeft;
	lblSelectAccount.textColor=[UIColor blackColor];
	[cell.contentView addSubview:lblSelectAccount];
	[lblSelectAccount release], lblSelectAccount = nil;
	
	txtSelectAccount = [[UITextField alloc]initWithFrame:CGRectMake(105,5,130,30)];
	txtSelectAccount.backgroundColor = [UIColor whiteColor];
	txtSelectAccount.autocorrectionType = UITextAutocorrectionTypeNo;
	txtSelectAccount.text=[pickerViewArray objectAtIndex:0];
	
	txtSelectAccount.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	txtSelectAccount.keyboardType=UIKeyboardTypeNumberPad;
	txtSelectAccount.delegate=self;
	txtSelectAccount.borderStyle = UITextBorderStyleLine;
	
	[focusArray addObject:txtSelectAccount];
	
	[cell.contentView addSubview:txtSelectAccount];
	
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
	
	if(textField==txtDate)
	{
		strTxtNm=@"txtDate";
		//[self datePickerCreate];
		return NO;
	}
	else if(textField==txtSelectAccount)
	{
		[self Vanishpicker];	
		[self createbarbuttondone];
		[self CreatePickerView];
		return NO;
	}
	else  if(textField==txtAmount)
	{
		return NO;
	}
	else  if(textField==txtCatagory)
	{
		return NO;
	}
	else if(textField==txtFrom)
	{
		return NO;
	}

	


	return YES;
}
- (BOOL)textFieldShouldEndEditing:(UITextField *)textField
{
	
	return YES;
	
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
	
	[textField resignFirstResponder];
	return YES;
	
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string 
{
	if(textField==txtAmount)
		
	{
		
		
		NSString *resultingString = [textField.text stringByReplacingCharactersInRange: range withString: string];
		
		
		if ([resultingString length] == 0) 
			
		{
			
			return true;
			
		}
		
		CGFloat holder;
		
		NSScanner *scan = [NSScanner scannerWithString: resultingString];
		
		return [scan scanFloat:&holder] && [scan isAtEnd];
	}
	return YES;
	
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component;
{
		
			NSString *str=@"";
			txtSelectAccount.text=[str stringByAppendingFormat:@"%@",[pickerViewArray objectAtIndex:[pickerView selectedRowInComponent:0]]];
			
	         Selectedpickerrow=row;
}
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
			
			
			return [pickerViewArray objectAtIndex:row];	
}
		 
- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component
{
			// first column size is wider to hold names
			
			return 150.0;                     // second column is narrower to show numbers
			
}
		 
- (CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component
{
			return 40.0;
}
		 
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
			return [pickerViewArray count];
			
			
}
		 
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
			return 1;
			
}
-(void)CreatePickerView
{
			
			
			myPickerView = [[UIPickerView alloc] initWithFrame:CGRectMake(0, 200, 180, 150)];
			myPickerView.showsSelectionIndicator = YES;
			myPickerView.delegate = self;
			[self.view addSubview:myPickerView];
			
	}
		 
/*-(void)datePickerCreate
{		
	NSDateFormatter *df = [[NSDateFormatter alloc] init];
	df.dateStyle = NSDateFormatterMediumStyle;
	[df release];
	
	datePicker = [[UIDatePicker alloc] initWithFrame:CGRectMake(85, 240, 60, 60)];
	//datePicker = datePick;
	datePicker.transform = CGAffineTransformMake(0.6, 0, 0, 0.7, -80, 0);
	
	datePicker.datePickerMode = UIDatePickerModeDate;
	datePicker.hidden = NO;
	datePicker.date = [NSDate date];
	datePicker.maximumDate=[NSDate date];
	[datePicker addTarget:self
				   action:@selector(changeDateInLabel:)
		 forControlEvents:UIControlEventValueChanged];
	
	[self.view addSubview:datePicker];
	//[datePick release];
}
- (void)changeDateInLabel:(id)sender
{	
	NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
	[dateFormat setDateStyle:NSDateFormatterMediumStyle];
	//[dateFormat setTimeStyle:NSDateFormatterShortStyle];
	NSDate *date=datePicker.date;
	
	NSString *strDate1 = [dateFormat stringFromDate:date];
	
	if([strTxtNm isEqualToString:@"txtDate"])
		txtDate.text=strDate1;
	
	
	
	
}*/

-(void)createbarbuttondone
{
	UIBarButtonItem *doneButton = [[UIBarButtonItem alloc]
								   initWithTitle:@"Done"
								   style:UIBarButtonItemStyleBordered
								   target:self
								   action:@selector(donecancel)];
	
	
	
    self.navigationItem.rightBarButtonItem =doneButton;
	
}

-(void)donecancel
{
	[self  createbar_button];
	
	[self Vanishpicker];
	
	
}
-(void)Vanishpicker
{
	if(myPickerView)
	{
		[myPickerView removeFromSuperview];
	    [myPickerView release],myPickerView=nil;
	}
	
	
}
/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
