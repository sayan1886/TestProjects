    //
//  ActiveSchedule.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 08/04/11.
//  Copyright 2011 ObjectSol Technologies. All rights reserved.
//

#import "ActiveSchedule.h"
#import "passPerser.h"
#import "MyTools.h"
#import "RequestPhase2.h"
#import "activeScheduleParser.h"
#import "configurables.h"
#import "ActiveScheduleOBJ.h"
#import "ScheduleOBJ.h"
#import "scheduleDetails.h"
NSInteger scheduleselectedRow;
@implementation ActiveSchedule
-(id)initWithArray:(NSMutableArray *)arr
{
	self=[super init];
	transaction_info=[[NSMutableArray alloc]init];
	transaction_info=arr;
	return self;
}

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	tools=[[MyTools alloc]init];
	loadingView=[tools createActivityIndicator1];
	NSMutableArray *arr_myconfig=[AcclarisViewController staticarr_config];
	con=(configurables *)[arr_myconfig objectAtIndex:0];
	self.view.backgroundColor = [UIColor colorWithRed:con.bgRed/255.0f green:con.bgGreen/255.0f blue:con.bgBlue/255.0f alpha:1.0];
	arr_scheduleInfo=[[NSMutableArray alloc]init];
	
	[self requestActiveSchedule];
	[self createHeader];
	[self signoutbt];
}
-(void)signoutbt
{
	
	
	UIBarButtonItem *signoutButton = [[UIBarButtonItem alloc]
									  initWithTitle:@"Sign Off"
									  style:UIBarButtonItemStyleBordered
									  target:self
									  action:@selector(signout)];
    self.navigationItem.rightBarButtonItem =signoutButton;
}
-(void)signout
{
	[((AcclarisAppDelegate *)[[UIApplication sharedApplication] delegate]) removeTabBar];
}

-(void)requestActiveSchedule
{

	NSMutableArray *userinfo_arr=[passPerser passresponce];
	RequestPhase2 *r=[[RequestPhase2 alloc] initWithTarget:self
								 SuccessAction:@selector(onSucceffulconnection)
								 FailureAction:@selector(onFailureLogin)];
	if ([[transaction_info objectAtIndex:3] isEqualToString:@"GetActiveSchedules"]) {
		[r sendActiveScheduleRequest:[userinfo_arr objectAtIndex:2] userid:[userinfo_arr objectAtIndex:4] Eid:[transaction_info objectAtIndex:0] startId:@"0" noOfRec:@"10" scheduletype:[transaction_info objectAtIndex:3]];

	}
	else {
		[r sendInActiveScheduleRequest:[userinfo_arr objectAtIndex:2] userid:[userinfo_arr objectAtIndex:4] Eid:[transaction_info objectAtIndex:0] startId:@"0" noOfRec:@"10" scheduletype:[transaction_info objectAtIndex:3]];

	}

	//[r sendActiveScheduleRequest:[userinfo_arr objectAtIndex:2] userid:[userinfo_arr objectAtIndex:4] Eid:[transaction_info objectAtIndex:0] startId:@"0" noOfRec:@"10" scheduletype:[transaction_info objectAtIndex:3]];
	[r release];
	[tools startLoading:self.view childView:loadingView text:@"Loading your Schedule. Wait…."];
	
}
-(void)onSucceffulconnection
{
	arr_scheduleInfo=[activeScheduleParser getscheduleArr];
	myScheduleOBJ=(ScheduleOBJ *)[arr_scheduleInfo objectAtIndex:0];

	if ([myScheduleOBJ.scheduleArr count]==0) {
		
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"“Currently no data available, please visit again later”" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
		[alert show];
		[alert release];
		return ;
		
	}
	else {
		
		[self createtableview];
	}

	
	[tools stopLoading:loadingView];
}
-(void)onFailureLogin
{
	[tools stopLoading:loadingView];
}
-(void)createHeader
{
	
	UIView *vw=[[UIView alloc]initWithFrame:CGRectMake(10, 0,300,120)];
	vw.backgroundColor=[UIColor colorWithRed:con.bgRed2/255.0 green:con.bgGreen2/255.0 blue:con.bgBlue2/255.0 alpha:1.0];
	[self.view addSubview:vw];
	
	NSString *strFont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];
	
	UILabel *Labelclaimdate=[[UILabel alloc]initWithFrame:CGRectMake(5,3,135,50)];
	Labelclaimdate.font=[UIFont fontWithName:strFont size:con.headerImpfntsize];
	Labelclaimdate.backgroundColor=[UIColor clearColor];
	//Labelclaimdate.lineBreakMode=UILineBreakModeWordWrap;
	Labelclaimdate.text =@"Transfer Schedule";
	Labelclaimdate.numberOfLines=0;
	Labelclaimdate.textColor=[UIColor whiteColor];
	[vw addSubview:Labelclaimdate];
	[Labelclaimdate release];
	
	UILabel *LabelAccount=[[UILabel alloc]initWithFrame:CGRectMake(5,50,145,40)];
	LabelAccount.font=[UIFont fontWithName:con.fontname size:con.headerfntsize];
	LabelAccount.backgroundColor=[UIColor clearColor];
	//LabelAccount.lineBreakMode=UILineBreakModeWordWrap;
	LabelAccount.text = @"Initial Transfer Date";
	LabelAccount.numberOfLines=0;
	LabelAccount.textColor=[UIColor whiteColor];
	[vw addSubview:LabelAccount];
	[LabelAccount release];
	
	UILabel *Labeltype=[[UILabel alloc]initWithFrame:CGRectMake(5,85,145,30)];
	Labeltype.font=[UIFont fontWithName:con.fontname size:con.headerfntsize];
	Labeltype.backgroundColor=[UIColor clearColor];
	//Labeltype.lineBreakMode=UILineBreakModeWordWrap;
	Labeltype.numberOfLines=0;
	Labeltype.text = @"Status";
	Labeltype.textColor=[UIColor whiteColor];
	[vw addSubview:Labeltype];
	[Labeltype release];
	
	/////////////////////////////////////////////
	
	UILabel *LabelAmmount=[[UILabel alloc]initWithFrame:CGRectMake(150,3,145,50)];
	LabelAmmount.font=[UIFont fontWithName:strFont size:con.headerImpfntsize];
	LabelAmmount.backgroundColor=[UIColor clearColor];
	LabelAmmount.text = @"Request Amount";
	LabelAmmount.numberOfLines=0;
	LabelAmmount.textColor=[UIColor whiteColor];
	LabelAmmount.textAlignment=UITextAlignmentRight;
	[vw addSubview:LabelAmmount];
	[LabelAmmount release];
	
	
	UILabel *LabelCatagory=[[UILabel alloc]initWithFrame:CGRectMake(150,50,145,40)];
	LabelCatagory.font=[UIFont fontWithName:con.fontname size:con.headerfntsize];
	LabelCatagory.backgroundColor=[UIColor clearColor];
	LabelCatagory.numberOfLines=0;
	LabelCatagory.text = @"Schedule End Date";
	LabelCatagory.textColor=[UIColor whiteColor];
	LabelCatagory.textAlignment=UITextAlignmentRight;
	[vw addSubview:LabelCatagory];
	[LabelCatagory release];
	
	
	UILabel *LabelStatus=[[UILabel alloc]initWithFrame:CGRectMake(150,85,145,30)];
	LabelStatus.font=[UIFont fontWithName:con.fontname size:con.headerfntsize];
	LabelStatus.backgroundColor=[UIColor clearColor];
	LabelStatus.text = @"Status Date";
	LabelStatus.numberOfLines=0;
	LabelStatus.textColor=[UIColor whiteColor];
	LabelStatus.textAlignment=UITextAlignmentRight;
	[vw addSubview:LabelStatus];
	[LabelStatus release];
	
	[vw release];
}
-(void)createtableview
{
	acctable=[[UITableView alloc] initWithFrame:CGRectMake(0,112,320,290-80) style:UITableViewStyleGrouped];
	acctable.delegate = self;
	acctable.dataSource = self;
	acctable.scrollEnabled = YES;
	acctable.autoresizesSubviews = YES;
	acctable.showsVerticalScrollIndicator=YES;
	acctable.showsHorizontalScrollIndicator=YES;
	acctable.backgroundColor=[UIColor clearColor];
	[self.view addSubview:acctable];	
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView  
{
	return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	if ([arr_scheduleInfo count]>0) {
		myScheduleOBJ=(ScheduleOBJ *)[arr_scheduleInfo objectAtIndex:0];
		return [myScheduleOBJ.scheduleArr  count];
	}
	else {
		return 0;
	}

	
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{  
	static NSString *CellIdentifier = @"Cell";
	static NSString *CellIdentifier1 = @"Cell1";
	UITableViewCell *cell;
	
	if(cell==nil)
	{
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier] autorelease];
	}
	else
	{
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier1];
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier1] autorelease];
		
	}
	cell.selectionStyle=UITableViewCellSelectionStyleNone;
	cell.backgroundColor=[UIColor whiteColor];
	
	
	
	NSString *strFont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];
	
	cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;	
	
	UILabel *cellclaimdate=[[UILabel alloc]initWithFrame:CGRectMake(5,3,110,20)];
	cellclaimdate.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
	cellclaimdate.backgroundColor=[UIColor clearColor];
	cellclaimdate.text =((ActiveScheduleOBJ *)[ myScheduleOBJ.scheduleArr objectAtIndex:indexPath.row]).transferSchedule;
	cellclaimdate.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
	[cell.contentView addSubview:cellclaimdate];
	[cellclaimdate release];
	
	UILabel *cellclaimaccount=[[UILabel alloc]initWithFrame:CGRectMake(5,26,145,20)];
	cellclaimaccount.font=[UIFont fontWithName:con.fontname size:con.bodyImpfntsize];
	cellclaimaccount.backgroundColor=[UIColor clearColor];
	cellclaimaccount.text = ((ActiveScheduleOBJ *)[ myScheduleOBJ.scheduleArr objectAtIndex:indexPath.row]).initTransferDate;
	cellclaimaccount.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
	[cell.contentView addSubview:cellclaimaccount];
	[cellclaimaccount release];
	
	UILabel *cellclaimtype=[[UILabel alloc]initWithFrame:CGRectMake(5,49,110,20)];
	cellclaimtype.font=[UIFont fontWithName:con.fontname size:con.bodyImpfntsize];
	cellclaimtype.backgroundColor=[UIColor clearColor];
	cellclaimtype.text = ((ActiveScheduleOBJ *)[ myScheduleOBJ.scheduleArr objectAtIndex:indexPath.row]).lastStatus;
	cellclaimtype.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
	[cell.contentView addSubview:cellclaimtype];
	[cellclaimtype release];
	
	
	///////////////////////////////////////////////////////////////
	
	UILabel *cellAmmount=[[UILabel alloc]initWithFrame:CGRectMake(120,3,150,20)];
	cellAmmount.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
	cellAmmount.backgroundColor=[UIColor clearColor];
	NSString *str=[self chkvalue:((ActiveScheduleOBJ *)[ myScheduleOBJ.scheduleArr objectAtIndex:indexPath.row]).transferAmount];
	if (((ActiveScheduleOBJ *)[ myScheduleOBJ.scheduleArr objectAtIndex:indexPath.row]).transferAmount<0)
	{
		
		cellAmmount.textColor=[UIColor colorWithRed:con.ngtvRed/255.0f green:con.ngtvGreen/255.0f blue:con.ngtvBlue/255.0f alpha:1.0];
	}
	else 
	{
		cellAmmount.textColor=[UIColor colorWithRed:con.posnumRed/255.0f green:con.posnumGreen/255.0f blue:con.posnumBlue/255.0f alpha:1.0];
	}		
	
	
	cellAmmount.text =str;
	cellAmmount.textAlignment=UITextAlignmentRight;
	[cell.contentView addSubview:cellAmmount];
	[cellAmmount release];
	
	UILabel *cellclaimcatagory=[[UILabel alloc]initWithFrame:CGRectMake(125,26,150,20)];
	cellclaimcatagory.font=[UIFont fontWithName:con.fontname size:con.bodyImpfntsize];
	cellclaimcatagory.backgroundColor=[UIColor clearColor];
	cellclaimcatagory.text = ((ActiveScheduleOBJ *)[ myScheduleOBJ.scheduleArr objectAtIndex:indexPath.row]).endDate;
	cellclaimcatagory.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
	cellclaimcatagory.textAlignment=UITextAlignmentRight;
	[cell.contentView addSubview:cellclaimcatagory];
	[cellclaimcatagory release];
	
	UILabel *cellclaimstatus=[[UILabel alloc]initWithFrame:CGRectMake(125,49,150,20)];
	cellclaimstatus.font=[UIFont fontWithName:con.fontname size:con.bodyImpfntsize];
	cellclaimstatus.backgroundColor=[UIColor clearColor];
	cellclaimstatus.text = ((ActiveScheduleOBJ *)[ myScheduleOBJ.scheduleArr objectAtIndex:indexPath.row]).lastTransferDate;
	cellclaimstatus.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
	cellclaimstatus.textAlignment=UITextAlignmentRight;
	[cell.contentView addSubview:cellclaimstatus];
	[cellclaimstatus release];
	
	//}
	
	return cell;
	
	
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return 75;
	
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	scheduleselectedRow=indexPath.row;
	scheduleDetails *myscheduleDetails=[[scheduleDetails alloc]init];
	[self.navigationController pushViewController:myscheduleDetails animated:YES];
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	if (buttonIndex==0)
	{
		[self.navigationController popViewControllerAnimated:YES];
	}
	
}

-(NSString *)chkvalue:(NSString *)value
{
	NSString *newvalue=@"";
	if([value intValue]>=0)
	{
		newvalue=[newvalue stringByAppendingString:con.ptvPrefix];
		newvalue=[newvalue stringByAppendingString:value];
	}
	else {
		value=[value substringFromIndex:1];
		newvalue=[newvalue stringByAppendingString:con.ngtvPrefix];
		newvalue=[newvalue stringByAppendingString:value];
		newvalue=[newvalue stringByAppendingString:con.ngtvSufix];
		
	}
	return newvalue;
}

+(NSInteger)getscheduleselectedRow
{
	if (scheduleselectedRow) {
		return scheduleselectedRow;
	}
	else {
		return 0;
	}
	
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
