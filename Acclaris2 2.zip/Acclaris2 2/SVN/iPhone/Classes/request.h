//
//  request.h
//  Trail
//
//  Created by mmandal on 02/10/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AcclarisAppDelegate.h"
#import "MyTools.h"
#import "Constants.h"

@class SignIn;
@class AccountDetails;
@class accPerser;
@class passPerser;
@interface request : NSObject 
{
	AcclarisAppDelegate *app;
	NSMutableData *d2;
	NSString *whichAPI;
	MyTools *tools;
	
	id target;
	SEL successHandler;
	SEL failureHandler;
	BOOL isstatus;
}
-(id)initWithTarget:(id)actionTarget
	  SuccessAction:(SEL)successAction 
	  FailureAction:(SEL)failureAction;
-(void)senduserRequest:(NSString *)user;
-(void)sendcdonfigRequest:(NSString *)user;
-(void)sendpassRequest:(NSString *)user pass:(NSString *)password;
-(void)sendaccountRequest:(NSString *)pId userid:(NSString *)uId;
-(void)sendtransactionRequest:(NSString *)pId userid:(NSString *)uId election:(NSString *)eId actype:(NSString *)actyp startid:(NSString *)strid;
-(void)sendticketRequest:(NSString *)startAfterSeqID participentid:(NSString *)pId userid:(NSString *)uId;
-(void)sendcloseMSGRequest:(NSString *)ticketType description:(NSString *)desc tickitcatagory:(NSString *)tcatagory tid:(NSString *)tID;
-(void)sendupdateMSGRequest:(NSString *)ticketType description:(NSString *)desc tickitcatagory:(NSString *)tcatagory tid:(NSString *)tID;
-(void)newticketTypeRequest;
-(void)claimactivityRequest:(NSString *)startAfterSeqID participentid:(NSString *)pId userid:(NSString *)uId receiptRequired:(NSString *)rr receiptRequiredType:(NSString *)rrt;
-(void)sendHSA_InvestmenttransactionRequest:(NSString *)pId userid:(NSString *)uId election:(NSString *)eId actype:(NSString *)actyp startid:(NSString *)strid;
-(void)pendingpassthru:(NSString *)pId userid:(NSString *)uId startid:(NSString *)strid;
-(void)newticketRequest:(NSString *)lbl description:(NSString *)desc;
-(void)req_images:(NSString *)pId userid:(NSString *)uId startid:(NSString *)strid;
-(void)req_alerts:(NSString *)pId userid:(NSString *)uId startid:(NSString *)strid;
-(void)callPostMethod:(NSMutableString *)sRequest Action:(NSString *)action API:(NSString *)api;
-(NSString *)getUTCFormateDate:(NSDate *)localDate;
-(void)req_images:(NSString *)pId userid:(NSString *)uId startid:(NSString *)strid;

-(void)sendtransactionRequest:(NSString *)pId userid:(NSString *)uId election:(NSString *)eId actype:(NSString *)actyp startid:(NSString *)strid;

-(void)claimactivityRequest:(NSString *)startAfterSeqID participentid:(NSString *)pId userid:(NSString *)uId receiptRequired:(NSString *)rr receiptRequiredType:(NSString *)rrt;

-(void)sendtransactionRequest:(NSString *)pId userid:(NSString *)uId election:(NSString *)eId actype:(NSString *)actyp startid:(NSString *)strid;

@end
