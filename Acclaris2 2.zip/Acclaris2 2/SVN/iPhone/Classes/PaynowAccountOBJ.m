//
//  PaynowAccountOBJ.m
//  Acclaris
//
//  Created by Subhojit on 22/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "PaynowAccountOBJ.h"


@implementation PaynowAccountOBJ

@synthesize straccountTypeCD,
straccountTypeDesc,
strelctID,
straccountNO,
strpurseType,
strlabelAssociatedValue;
@end
