//
//  imageUploadForClaim.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 30/04/11.
//  Copyright 2011 ObjectSol Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface imageUploadForClaim : NSObject {

	id target;
	SEL successHandler;
	SEL failureHandler;
		
	int row;
	
	
}
-(id)initWithTarget:(id)actionTarget
	  SuccessAction:(SEL)successAction 
	  FailureAction:(SEL)failureAction
			  rowno:(int)rowSelected;

-(void)uploadImage:(NSInteger )imageNo;

@end
