//
//  SubmitNewClaimTwo.h
//  Acclaris
//
//  Created by Subhojit on 21/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MyTools.h"
#import "Decode64.h"
#import "ClaimSubmitNewOBJ.h"
#import "ClaimSubmitNewParser.h"
#import "ClaimSubOBJ.h"
#import "RequestPhase2.h"
#import "passPerser.h"
#import "AcclarisAppDelegate.h"
#import "SubmitNewClaimThree.h"
#import "SelectServiceProvider.h"
#import "ClaimonlineSaveOBJ.h"
#import "Claimonlineserviceparser.h"
#import "MultipleAccountView.h"



@class configurables;

@interface SubmitNewClaimTwo : UIViewController<UITextFieldDelegate,UITableViewDelegate,UITableViewDataSource,UIPickerViewDelegate,UIPickerViewDataSource,UITextViewDelegate,didSelectInterested> {

	
	AcclarisAppDelegate *app;
	configurables *con;
	MyTools *tools;
	UITextField *txttype;
	UITextField *txtAmount;
	UITextField *txtProvider;
	UITextField *txtserviceFrom;
	UITextField *txtserviceTo;
	UITextField *txtPriorYear;
	UITextView *txtViewNote;
	
	UITableView *table;
	NSArray *placeholders;
	UIButton *btnRadio;
	UIButton *btnRadio1;
	
	//NSArray *pickerViewArray;
	UIPickerView *myPickerView;
	NSMutableArray *arrAllSection;
	UIDatePicker    *datePicker;

	NSString *strTxtNm;
	NSMutableArray *pickerViewArray;
	ClaimSubOBJ*  objClaimsub;;
	ClaimSubmitNewOBJ*  objClaimsubmit;
	
	NSString *strFont;
	NSMutableArray *arrsubmitcatagory;
	NSString *strPriorCheck;
	NSString *strPaystatus;
	NSMutableDictionary *DictSavedSubmitclaimInfo;
	NSString *icheckbox;
	UIView *loadingView;
	
	NSMutableDictionary *dictget;
	NSString *strselectclaimcatagory;
	 NSMutableArray *arrclaimsave;
	
	NSMutableArray *userinfo_arr;
	
	NSString *strAccValue;
	NSString *strallowDuplicateClaim;
	
	id type;
	NSString *stropcodevalue;
	NSString *strFront;
	BOOL isfirstmultiple;
	NSMutableArray *arrDecide;
	NSString *strClaimid;
	NSDictionary *customMessageList_dict;
	
	
}
-(void)ClaimSave;
-(void)ClaimSave2;

-(void)createbarbuttondone;
-(void)donecancel;
-(void)signout;
-(void)PaytypeInput:(UITableViewCell *)cell;
-(void)HeadertypeInput:(UITableViewCell *)cell;
-(void)constructTableCell;
-(void)TypeInput:(UITableViewCell *)cell;
-(void)AmountInput:(UITableViewCell *)cell;
-(void)ProviderInput:(UITableViewCell *)cell;
-(void)ServiceFromInput:(UITableViewCell *)cell;
-(void)ServiceToInput:(UITableViewCell *)cell;
-(void)PriorInput:(UITableViewCell *)cell;
-(void)NoteInput:(UITableViewCell *)cell;
-(void)CreateView;
-(void)ClickbtnRadio:(id)sender;
-(void)ClickbtnRadio1:(id)sender;
-(id)initWitharr:(NSMutableArray *)arr str:(NSString *)s catagory:(NSMutableDictionary *)dict;
-(void)Vanishpicker;
-(void)constructTableCellnew;
-(void)Save;
-(void)createbar_button;


@end
