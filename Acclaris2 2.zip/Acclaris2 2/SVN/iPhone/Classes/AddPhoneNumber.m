    //
//  AddPhoneNumber.m
//  Acclaris
//
//  Created by Subhojit on 18/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "AddPhoneNumber.h"
#import "configurables.h"
#import "AcclarisViewController.h"
@implementation AddPhoneNumber


- (void)viewDidLoad {
    [super viewDidLoad];
	
	NSMutableArray *arr_myconfig=[AcclarisViewController staticarr_config];
	con=(configurables *)[arr_myconfig objectAtIndex:0];
	tools=[[MyTools alloc]init];
	loadingView=[tools createActivityIndicator1];
	
	self.view.backgroundColor = [UIColor colorWithRed:con.bgRed/255.0f green:con.bgGreen/255.0f blue:con.bgBlue/255.0f alpha:1.0];
	self.navigationController.navigationBar.tintColor=[UIColor colorWithRed:con.navbarRed/255.0f green:con.navbarGreen/255.0f blue:con.navbarBlue/255.0f alpha:1.0];
	
	UIImageView *logo_img = [[UIImageView alloc]initWithFrame:CGRectMake(0, 2, 170, 40)];
	NSData *data=[Base64 decode:con.logoImgdata];
	logo_img.image=	[UIImage imageWithData:[NSData dataWithData:data]];
	self.navigationItem.titleView=logo_img;
	
	UIBarButtonItem *signoutButton = [[UIBarButtonItem alloc]
									  initWithTitle:@"Sign Off"
									  style:UIBarButtonItemStyleBordered
									  target:self
									  action:@selector(signout)];
    self.navigationItem.rightBarButtonItem =signoutButton;
	
	customMessageList_dict=[[NSUserDefaults standardUserDefaults] objectForKey:@"customMessageList"];

	[self CreateView];
}
-(void)CreateView
{

	NSString	*strFont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];
	NSData *data_btnimg=[Base64 decode:con.btnImgdata];//btn background image
	UIView *HeaderView=[[[UIView alloc]initWithFrame:CGRectMake(0, 0, 320, 60)]autorelease];
	HeaderView.backgroundColor=[UIColor colorWithRed:con.bgRed2/255.0 green:con.bgGreen2/255.0 blue:con.bgBlue2/255.0 alpha:1.0];
	[self.view addSubview:HeaderView];
	
	NSString *strViewTitle=@"Add Phone Number";
	//strViewTitle=[strViewTitle stringByAppendingString:@"\n"];
	//strViewTitle=[strViewTitle stringByAppendingFormat:@"%@",@"Number"];
	
	UILabel *lbltext=[[UILabel alloc]initWithFrame:CGRectMake(10, 5, 240, 55)];
	lbltext.text=strViewTitle;
	lbltext.backgroundColor=[UIColor clearColor];
	lbltext.textColor=[UIColor whiteColor];
	lbltext.numberOfLines=0;
	lbltext.font=[UIFont fontWithName:strFont size:18];
	[HeaderView addSubview:lbltext];
	[lbltext release],lbltext=nil;
	
	
	UILabel *lblprimaryphno=[[UILabel alloc]init];
	lblprimaryphno.frame= CGRectMake(20, 80, 250, 55);
	lblprimaryphno.backgroundColor=[UIColor clearColor];
	lblprimaryphno.text=@"Primary Phone Number";
	lblprimaryphno.font=[UIFont fontWithName:@"Helvetica-Bold" size:20];
	[self.view addSubview:lblprimaryphno];
	[lblprimaryphno release],lblprimaryphno=nil;
	
	
	txtPCode=[[UITextField alloc]initWithFrame:CGRectMake(40, 135, 40, 35)];
	txtPCode.delegate=self;	
	txtPCode.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	txtPCode.borderStyle=UITextBorderStyleLine;
	txtPCode.returnKeyType=UIReturnKeyDone;
	txtPCode.keyboardType=UIKeyboardTypeNumbersAndPunctuation;
	txtPCode.autocorrectionType = UITextAutocorrectionTypeNo;
	txtPCode.userInteractionEnabled=YES;
	txtPCode.backgroundColor=[UIColor whiteColor];	
	//txtPCode.clearButtonMode = UITextFieldViewModeWhileEditing;
	[self.view addSubview:txtPCode];
	

	txtPphno=[[UITextField alloc]initWithFrame:CGRectMake(85, 135, 140, 35)];
	txtPphno.delegate=self;	
	txtPphno.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;

	txtPphno.borderStyle=UITextBorderStyleLine;
	txtPphno.returnKeyType=UIReturnKeyDone;
	txtPphno.keyboardType=UIKeyboardTypeNumbersAndPunctuation;
	txtPphno.autocorrectionType = UITextAutocorrectionTypeNo;
	txtPphno.userInteractionEnabled=YES;
	txtPphno.backgroundColor=[UIColor whiteColor];
	//txtPphno.clearButtonMode = UITextFieldViewModeWhileEditing;
	[self.view addSubview:txtPphno];
	
	txtExtPno=[[UITextField alloc]initWithFrame:CGRectMake(230, 135,80, 35)];
	txtExtPno.delegate=self;
	txtExtPno.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	txtExtPno.borderStyle=UITextBorderStyleLine;
	txtExtPno.keyboardType=UIKeyboardTypeNumbersAndPunctuation;
	txtExtPno.returnKeyType=UIReturnKeyDone;
	txtExtPno.autocorrectionType = UITextAutocorrectionTypeNo;
	txtExtPno.backgroundColor=[UIColor whiteColor];
	txtExtPno.userInteractionEnabled=YES;
	////txtExtPno.clearButtonMode = UITextFieldViewModeWhileEditing;
	[self.view addSubview:txtExtPno];
	
	
	UILabel *lblsecondaryphno=[[UILabel alloc]init];
	lblsecondaryphno.frame= CGRectMake(20, 175, 265, 55);
	lblsecondaryphno.text=@"Secondary Phone Number";
	lblsecondaryphno.backgroundColor=[UIColor clearColor];
	lblsecondaryphno.font=[UIFont fontWithName:@"Helvetica-Bold" size:20];
	[self.view addSubview:lblsecondaryphno];
	[lblsecondaryphno release],lblsecondaryphno=nil;
	
	
	txtSCode=[[UITextField alloc]initWithFrame:CGRectMake(40, 230, 40, 35)];
	txtSCode.delegate=self;	
	txtSCode.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	txtSCode.keyboardType=UIKeyboardTypeNumbersAndPunctuation;
	txtSCode.borderStyle=UITextBorderStyleLine;
	txtSCode.returnKeyType=UIReturnKeyDone;
	txtSCode.backgroundColor=[UIColor whiteColor];
	txtSCode.autocorrectionType = UITextAutocorrectionTypeNo;
	txtSCode.userInteractionEnabled=YES;
	//txtSCode.clearButtonMode = UITextFieldViewModeWhileEditing;
	[self.view addSubview:txtSCode];
	
	
	txtSphno=[[UITextField alloc]initWithFrame:CGRectMake(85, 230, 140, 35)];
	txtSphno.delegate=self;	
	txtSphno.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	txtSphno.keyboardType=UIKeyboardTypeNumbersAndPunctuation;
	txtSphno.borderStyle=UITextBorderStyleLine;
	txtSphno.returnKeyType=UIReturnKeyDone;
	txtSphno.autocorrectionType = UITextAutocorrectionTypeNo;
	txtSphno.backgroundColor=[UIColor whiteColor];
	txtSphno.userInteractionEnabled=YES;
	//txtSphno.clearButtonMode = UITextFieldViewModeWhileEditing;
	[self.view addSubview:txtSphno];
	
	txtSExtPno=[[UITextField alloc]initWithFrame:CGRectMake(230, 230,80, 35)];
	txtSExtPno.delegate=self;
	txtSExtPno.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	txtSExtPno.keyboardType=UIKeyboardTypeNumbersAndPunctuation;
	txtSExtPno.borderStyle=UITextBorderStyleLine;
	txtSExtPno.returnKeyType=UIReturnKeyDone;
	txtSExtPno.autocorrectionType = UITextAutocorrectionTypeNo;
	txtSExtPno.userInteractionEnabled=YES;
	txtSExtPno.backgroundColor=[UIColor whiteColor];
	//txtSExtPno.clearButtonMode = UITextFieldViewModeWhileEditing;
	[self.view addSubview:txtSExtPno];
	
	
	
	UIButton *btnSubmit=[UIButton buttonWithType:UIButtonTypeCustom];
	btnSubmit.frame=CGRectMake(50, 290, 220, 40);
	[btnSubmit setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
	[btnSubmit setTitle:@"Submit" forState:UIControlStateNormal];
	[btnSubmit setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	btnSubmit.titleLabel.font = [UIFont fontWithName:con.btnfontname size:con.btnfontsize];
	[btnSubmit addTarget:self action:@selector(ClickbtnSubmit) forControlEvents:UIControlEventTouchUpInside];					 
	[self.view addSubview:btnSubmit];
	
	
	
}

-(void)signout
{

	
	;
	
}

-(void)ClickbtnSubmit
{

	
	if(txtPphno.text.length==0 ||txtPCode.text.length==0)
		
	{
		NSString *strmessage=[[customMessageList_dict valueForKey:@"200062"]valueForKey:@"message"];
		NSString *strtype=[[customMessageList_dict valueForKey:@"200062"]valueForKey:@"type"];

		UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:strtype 
															  message:strmessage
															 delegate:self 
													cancelButtonTitle:@"OK" 
													otherButtonTitles:nil];
		[alertWarning show];
		[alertWarning release];
		return;
		
	}
	else if(txtSphno.text.length==0||txtSCode.text.length==0)
	{
		NSString *strmessage=[[customMessageList_dict valueForKey:@"200079"]valueForKey:@"message"];
		NSString *strtype=[[customMessageList_dict valueForKey:@"200079"]valueForKey:@"type"];
		
		UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:strtype 
															  message:strmessage
															 delegate:self 
													cancelButtonTitle:@"OK" 
													otherButtonTitles:nil];
		[alertWarning show];
		[alertWarning release];
		return;
		
		
	}
	else if(txtPphno.text.length<7)
		
	{
		
		NSString *strmessage=[[customMessageList_dict valueForKey:@"200078"]valueForKey:@"message"];
		NSString *strtype=[[customMessageList_dict valueForKey:@"200078"]valueForKey:@"type"];
		
		UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:strtype 
															  message:strmessage
															 delegate:self 
													cancelButtonTitle:@"OK" 
													otherButtonTitles:nil];
		[alertWarning show];
		[alertWarning release];
		return;		
	}
	else if(txtSphno.text.length<7)
	{
		
		
		NSString *strmessage=[[customMessageList_dict valueForKey:@"200079"]valueForKey:@"message"];
		NSString *strtype=[[customMessageList_dict valueForKey:@"200079"]valueForKey:@"type"];
		
		UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:strtype 
															  message:strmessage
															 delegate:self 
													cancelButtonTitle:@"OK" 
													otherButtonTitles:nil];
		[alertWarning show];
		[alertWarning release];
		return;		
		
	}
	else if(txtPCode.text.length<3)
		
	{
		
		NSString *strmessage=[[customMessageList_dict valueForKey:@"200078"]valueForKey:@"message"];
		NSString *strtype=[[customMessageList_dict valueForKey:@"200078"]valueForKey:@"type"];
		
		UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:strtype 
															  message:strmessage
															 delegate:self 
													cancelButtonTitle:@"OK" 
													otherButtonTitles:nil];
		[alertWarning show];
		[alertWarning release];
		return;		
		
	}
	else if(txtSCode.text.length<3)
	{
		
		NSString *strmessage=[[customMessageList_dict valueForKey:@"200079"]valueForKey:@"message"];
		NSString *strtype=[[customMessageList_dict valueForKey:@"200079"]valueForKey:@"type"];
		
		UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:strtype 
															  message:strmessage
															 delegate:self 
													cancelButtonTitle:@"OK" 
													otherButtonTitles:nil];
		[alertWarning show];
		[alertWarning release];
		return;		
		
	}
	else 
	{
	
		NSMutableArray *userinfo_arr=[passPerser passresponce];
		
		RequestPhase2_2 *objrequestPhase2_2=[[RequestPhase2_2 alloc] initWithTarget:self
																	  SuccessAction:@selector(onSuccefful)
																	  FailureAction:@selector(onFailure)];
		
		
		
		[objrequestPhase2_2 AddPhoneNumber:[userinfo_arr objectAtIndex:2] uID:[userinfo_arr objectAtIndex:4] areaP:txtPCode.text restP:txtPphno.text extnP:txtExtPno.text areaS:txtSCode.text restS:txtSphno.text extnS:txtSExtPno.text];
		[objrequestPhase2_2 release];
		
		[tools startLoading:self.view childView:loadingView text:@"Loading your Claim activity. Wait…."];
	}

	
}

-(void)onSuccefful
{
		
		[tools stopLoading:loadingView];
		
		NSMutableArray *arrEmailinfo=[AddEmailParser getarrAddemail];
		
		
		if([((AddEmailOBJ *)[arrEmailinfo  objectAtIndex:0]).strreturnCode isEqualToString:@"0"])
		{
			
			UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:@"Info" 
																  message:((AddEmailOBJ *)[arrEmailinfo  objectAtIndex:0]).strresult
																 delegate:self 
														cancelButtonTitle:@"OK" 
														otherButtonTitles:nil];
			[alertWarning show];
			[alertWarning release];		
		}
		else
		{
			UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:@"Info" 
																  message:((AddEmailOBJ *)[arrEmailinfo  objectAtIndex:0]).strerrorText															 delegate:self 
														cancelButtonTitle:@"OK" 
														otherButtonTitles:nil];
			[alertWarning show];
			[alertWarning release];
		}
		
	
}
-(void)onFailure
{
		
	[tools stopLoading:loadingView];
}
	
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{

	if(textField==txtSCode)
	{
		if(textField.frame.origin.y>=175)
		{
			UIView *ContainedView=[textField superview];
			CGRect rect=ContainedView.frame;
			[UIView beginAnimations:nil context:nil];
			[UIView setAnimationDuration:0.3];
			rect.origin.y-=(textField.frame.origin.y-160);
			ContainedView.frame=rect;
			[UIView commitAnimations];
		}
	}
	
	
	return YES;
}
- (BOOL)textFieldShouldEndEditing:(UITextField *)textField
{

	
	return YES;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
	
	
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.3];
	self.view.frame=CGRectMake(0, 0, 320, 410);
	[UIView commitAnimations];
	
    [textField resignFirstResponder];
	return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string 
{
	
	
	if(textField==txtPCode || textField==txtSCode)
	{
		
			NSString *newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
			if([newString length]>3)
			{
				
				 return NO;
			}
		
	}
	
	else if(textField==txtPphno || textField==txtSphno)
	{
		
		NSString *newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
		if([newString length]>7)
		{
			
			return NO;
		}
		
	}
	else if(textField==txtExtPno || textField==txtSExtPno)
	{
		
		NSString *newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
		if([newString length]>4)
		{
			
			return NO;
		}
		
	}
	
		NSString *resultingString = [textField.text stringByReplacingCharactersInRange: range withString: string];
		
		
		if ([resultingString length] == 0) 
			
		{
			
			return true;
			
		}
		
		CGFloat holder;
		
		NSScanner *scan = [NSScanner scannerWithString: resultingString];
		
		return [scan scanFloat:&holder] && [scan isAtEnd];
	
	return YES;
	
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
	txtPCode=nil;
	txtSphno=nil;
	txtSExtPno=nil;
	txtPphno=nil;
	txtExtPno=nil;
}


- (void)dealloc {
	[txtPCode release];
	[txtSphno release];
	[txtSExtPno release];
	[txtPphno release];
	[txtExtPno release];
	
    [super dealloc];
}


@end
