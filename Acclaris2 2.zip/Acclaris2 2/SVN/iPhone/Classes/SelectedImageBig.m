    //
//  SelectedImageBig.m
//  Acclaris
//
//  Created by Subhojit on 24/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "SelectedImageBig.h"
#import "configurables.h"
#import "AcclarisViewController.h"

@implementation SelectedImageBig

-(id)initWithImgView:(UIImageView *)aImageView  target:(id)target action:(SEL)action
{

	self=[super init];
	if(self==nil)
	{

		return nil;
	}
	else 
	{
		actionTarget=target;
		actionHandler=action;
		
				
	    newImageView = [[UIImageView alloc] initWithFrame:aImageView.frame];
		newImageView.image = aImageView.image;
		newImageView.frame=CGRectMake(20,55,280,200);
		newImageView.userInteractionEnabled = NO;
		[self.view addSubview:newImageView];
		
		
	}
	return self;
	
}
-(void)signout
{
	
	[((AcclarisAppDelegate *)[[UIApplication sharedApplication] delegate]) removeTabBar];
	
}

- (void)viewDidLoad {
    [super viewDidLoad];
	
	NSMutableArray *arr_myconfig=[AcclarisViewController staticarr_config];
	con=(configurables *)[arr_myconfig objectAtIndex:0];
	self.view.backgroundColor = [UIColor colorWithRed:con.bgRed/255.0f green:con.bgGreen/255.0f blue:con.bgBlue/255.0f alpha:1.0];
	
	self.navigationController.navigationBar.tintColor=[UIColor colorWithRed:con.navbarRed/255.0f green:con.navbarGreen/255.0f blue:con.navbarBlue/255.0f alpha:1.0];
	
	UIImageView *logo_img = [[UIImageView alloc]initWithFrame:CGRectMake(0, 2, 170, 40)];
	NSData *data=[Base64 decode:con.logoImgdata];
	logo_img.image=	[UIImage imageWithData:[NSData dataWithData:data]];
	self.navigationItem.titleView=logo_img;
	[logo_img release],logo_img=nil;
	
	
	
	UIBarButtonItem *signoutButton = [[UIBarButtonItem alloc]
									  initWithTitle:@"Sign Off"
									  style:UIBarButtonItemStyleBordered
									  target:self
									  action:@selector(signout)];
    self.navigationItem.rightBarButtonItem =signoutButton;
	[signoutButton release],signoutButton=nil;
	
	[self CreateView];
	
}
-(void)CreateView
{

	NSData *data_btnimg=[Base64 decode:con.btnImgdata];//btn background image
	
	UIButton *btnDelete=[UIButton buttonWithType:UIButtonTypeCustom];
	btnDelete.frame=CGRectMake(20, 285, 120, 40);
	[btnDelete setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
	[btnDelete setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	 btnDelete.titleLabel.font = [UIFont fontWithName:con.btnfontname size:con.btnfontsize];
	[btnDelete setTitle:@"Delete" forState:UIControlStateNormal];
	[btnDelete addTarget:self action:@selector(ClickbtnDelete) forControlEvents:UIControlEventTouchUpInside];	
	[self.view addSubview:btnDelete];
	
	
	UIButton *btnBack=[UIButton buttonWithType:UIButtonTypeCustom];
	btnBack.frame=CGRectMake(165, 285, 120, 40);
	[btnBack setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
	[btnBack setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	 btnBack.titleLabel.font = [UIFont fontWithName:con.btnfontname size:con.btnfontsize];
	[btnBack setTitle:@"Back" forState:UIControlStateNormal];
	[btnBack addTarget:self action:@selector(ClickbtnBack) forControlEvents:UIControlEventTouchUpInside];	
	[self.view addSubview:btnBack];
	
	
	
}

-(void)ClickbtnDelete
{

	UIAlertView *alertview=[[UIAlertView alloc]initWithTitle:@"Alert" message:@"Are you sure to delete this photo?" delegate:self cancelButtonTitle:@"No" otherButtonTitles:@"Yes",nil];
	alertview.delegate=self;
	[alertview show];
	[alertview release],alertview=nil;
	
	
	
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{

	
	if(buttonIndex==1)
		
	{
		[newImageView removeFromSuperview];
		
		[actionTarget performSelector:actionHandler withObject:nil];//@selector(press) in place of actionHandler.

		[self.navigationController popViewControllerAnimated:YES];
		
	}
}
-(void)ClickbtnBack
{

	
	[self.navigationController popViewControllerAnimated:YES];
}
/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
	newImageView=nil;
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[newImageView release];
    [super dealloc];
}


@end
