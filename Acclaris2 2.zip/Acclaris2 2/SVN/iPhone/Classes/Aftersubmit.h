//
//  Aftersubmit.h
//  Acclaris
//
//  Created by Subhojit on 12/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SubmitclaimOBJ.h"
#import "SubmitclaimParser.h"
#import "MyTools.h"
#import "Decode64.h"
#import "AcclarisAppDelegate.h"
#import "AddImage.h"
#import "DenialreasonList.h"
#import "passPerser.h"
@class configurables;


@interface Aftersubmit : UIViewController<UITableViewDelegate,UITableViewDataSource> {

	configurables *con;
	MyTools *tools;
	AcclarisAppDelegate *app;
	UIView *loadingView;
	
	
	UITableView *table;
	
	NSMutableArray *arrdeny;
	NSMutableArray *arrreptrequd;
	NSMutableArray *arrpendingpayclaim;
	
	NSString *strFont;
	BOOL issinglerowdeny;
	BOOL issinglerowreceipt;
	BOOL issinglerowpending;
	NSMutableDictionary *roleDict;
	
	NSString *strclaimid;
	
	
}
-(void)signout;
-(void)CreateView;
-(NSString *)chkvalue:(NSString *)value;
@end
