    //
//  EmailInput.m
//  Acclaris
//
//  Created by Subhojit on 18/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "EmailInput.h"
#import "configurables.h"
#import "AcclarisViewController.h"
@implementation EmailInput



- (void)viewDidLoad {
    [super viewDidLoad];
	
	
	
	NSMutableArray *arr_myconfig=[AcclarisViewController staticarr_config];
	con=(configurables *)[arr_myconfig objectAtIndex:0];
	tools=[[MyTools alloc]init];
	loadingView=[tools createActivityIndicator1];
	
	
	self.view.backgroundColor = [UIColor colorWithRed:con.bgRed/255.0f green:con.bgGreen/255.0f blue:con.bgBlue/255.0f alpha:1.0];
	self.navigationController.navigationBar.tintColor=[UIColor colorWithRed:con.navbarRed/255.0f green:con.navbarGreen/255.0f blue:con.navbarBlue/255.0f alpha:1.0];
	
	UIImageView *logo_img = [[UIImageView alloc]initWithFrame:CGRectMake(0, 2, 170, 40)];
	NSData *data=[Base64 decode:con.logoImgdata];
	logo_img.image=	[UIImage imageWithData:[NSData dataWithData:data]];
	self.navigationItem.titleView=logo_img;
	
	
     customMessageList_dict=[[NSUserDefaults standardUserDefaults] objectForKey:@"customMessageList"];

	UIBarButtonItem *signoutButton = [[UIBarButtonItem alloc]
									  initWithTitle:@"Sign Off"
									  style:UIBarButtonItemStyleBordered
									  target:self
									  action:@selector(signout)];
    self.navigationItem.rightBarButtonItem =signoutButton;
	
	[self CreateView];
	
	
}

-(void)CreateView
{
    NSString	*strFont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];
	
	NSData *data_btnimg=[Base64 decode:con.btnImgdata];//btn background image
	UIView *HeaderView=[[[UIView alloc]initWithFrame:CGRectMake(0, 0, 320, 60)]autorelease];
	HeaderView.backgroundColor=[UIColor colorWithRed:con.bgRed2/255.0 green:con.bgGreen2/255.0 blue:con.bgBlue2/255.0 alpha:1.0];
	[self.view addSubview:HeaderView];
						
	NSString *strViewTitle=@"Add Email Address";
	//strViewTitle=[strViewTitle stringByAppendingString:@"\n"];
	//strViewTitle=[strViewTitle stringByAppendingFormat:@"%@",@"Address"];
	
	UILabel *lbltext=[[UILabel alloc]initWithFrame:CGRectMake(10, 5, 240, 55)];
	lbltext.text=strViewTitle;
	lbltext.backgroundColor=[UIColor clearColor];
	lbltext.textColor=[UIColor whiteColor];
	lbltext.numberOfLines=0;
	lbltext.font=[UIFont fontWithName:strFont size:con.headerImpfntsize];
	[HeaderView addSubview:lbltext];
	[lbltext release],lbltext=nil;
	
						
	
	NSString *str=@"Email";
	str=[str stringByAppendingString:@"\n"];
	str=[str stringByAppendingFormat:@"%@",@"address"];
	
	UILabel *lblEmail=[[UILabel alloc]init];
	lblEmail.frame= CGRectMake(10, 80, 125, 60);
	lblEmail.numberOfLines=0;
	lblEmail.backgroundColor=[UIColor clearColor];
	lblEmail.text=str;
	lblEmail.font=[UIFont fontWithName:@"Helvetica-Bold" size:20];
	[self.view addSubview:lblEmail];
	[lblEmail release],lblEmail=nil;
	
	
	NSString *str1=@"Reenter Email";
	str1=[str1 stringByAppendingString:@"\n"];
	str1=[str1 stringByAppendingFormat:@"%@",@"address"];

	UILabel *lblEmailreEnter=[[UILabel alloc]initWithFrame:CGRectMake(10, 160, 150, 65)];
	lblEmailreEnter.text=str1;
	lblEmailreEnter.backgroundColor=[UIColor clearColor];
	lblEmailreEnter.numberOfLines=0;
	lblEmailreEnter.font=[UIFont fontWithName:@"Helvetica-Bold" size:20];
	[self.view addSubview:lblEmailreEnter];
	[lblEmailreEnter release],lblEmailreEnter=nil;
	
	
	txtEmail=[[UITextField alloc]initWithFrame:CGRectMake(105, 115, 205, 30)];
	txtEmail.delegate=self;	
	txtEmail.backgroundColor=[UIColor whiteColor];
	txtEmail.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	txtEmail.borderStyle=UITextBorderStyleLine;
	txtEmail.text=@"";
	txtEmail.returnKeyType=UIReturnKeyDone;
	txtEmail.autocorrectionType = UITextAutocorrectionTypeNo;
	txtEmail.userInteractionEnabled=YES;
	txtEmail.clearButtonMode = UITextFieldViewModeWhileEditing;
	[self.view addSubview:txtEmail];
	
	
	txtrenterEmail=[[UITextField alloc]initWithFrame:CGRectMake(105, 198, 205, 30)];
	txtrenterEmail.delegate=self;
	txtrenterEmail.text=@"";
	txtrenterEmail.backgroundColor=[UIColor whiteColor];
	txtrenterEmail.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	txtrenterEmail.borderStyle=UITextBorderStyleLine;
	txtrenterEmail.returnKeyType=UIReturnKeyDone;
	txtrenterEmail.autocorrectionType = UITextAutocorrectionTypeNo;
	txtrenterEmail.userInteractionEnabled=YES;
	txtrenterEmail.clearButtonMode = UITextFieldViewModeWhileEditing;
	[self.view addSubview:txtrenterEmail];
	
	UIButton *btnSubmit=[UIButton buttonWithType:UIButtonTypeCustom];
	btnSubmit.frame=CGRectMake(50, 290, 220, 40);
	[btnSubmit setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
	[btnSubmit setTitle:@"Submit" forState:UIControlStateNormal];
	[btnSubmit setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	 btnSubmit.titleLabel.font = [UIFont fontWithName:con.btnfontname size:con.btnfontsize];
	[btnSubmit addTarget:self action:@selector(ClickbtnSubmit) forControlEvents:UIControlEventTouchUpInside];					 
	[self.view addSubview:btnSubmit];
			  
}
-(void)signout
{

	[((AcclarisAppDelegate *)[[UIApplication sharedApplication] delegate]) removeTabBar];
	
}
-(void)ClickbtnSubmit
{
	
	if([txtEmail.text isEqualToString:@""])
	{
		NSString *strmessage=[[customMessageList_dict valueForKey:@"200050"]valueForKey:@"message"];
		NSString *strtype=[[customMessageList_dict valueForKey:@"200050"]valueForKey:@"type"];
		
		UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:strtype
															  message:strmessage
															 delegate:self 
													cancelButtonTitle:@"OK" 
													otherButtonTitles:nil];
		[alertWarning show];
		[alertWarning release];
		return;
		
		
	}
	else if([txtrenterEmail.text isEqualToString:@""])
	{
		
		NSString *strmessage=[[customMessageList_dict valueForKey:@"200051"]valueForKey:@"message"];
		NSString *strtype=[[customMessageList_dict valueForKey:@"200051"]valueForKey:@"type"];

		UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:strtype
															  message:strmessage 
															 delegate:self 
													cancelButtonTitle:@"OK" 
													otherButtonTitles:nil];
		[alertWarning show];
		[alertWarning release];
		return;
		
	}
	else if(![txtEmail.text isEqualToString:txtrenterEmail.text])
	{
	
		UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:@"Info" 
															  message:@"Email and Reenter Email should be same" 
															 delegate:self 
													cancelButtonTitle:@"OK" 
													otherButtonTitles:nil];
		[alertWarning show];
		[alertWarning release];
		return;
	}
	else 
	{
	   NSMutableArray *userinfo_arr=[passPerser passresponce];
		
		RequestPhase2_2 *objrequestPhase2_2=[[RequestPhase2_2 alloc] initWithTarget:self
																SuccessAction:@selector(onSuccefful)
																FailureAction:@selector(onFailure)];
		
		[objrequestPhase2_2 AddEmail:[userinfo_arr objectAtIndex:2] uID:[userinfo_arr objectAtIndex:4] email:txtEmail.text];
		[objrequestPhase2_2 release];
		
		[tools startLoading:self.view childView:loadingView text:@"Loading your Claim activity. Wait…."];
		
	}

							 
							 
}
-(void)onSuccefful
{
	
	[tools stopLoading:loadingView];
	
	NSMutableArray *arrEmailinfo=[AddEmailParser getarrAddemail];
	
	
	if([((AddEmailOBJ *)[arrEmailinfo  objectAtIndex:0]).strreturnCode isEqualToString:@"0"])
	{
		
		UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:@"Info" 
															  message:((AddEmailOBJ *)[arrEmailinfo  objectAtIndex:0]).strresult
															 delegate:self 
													cancelButtonTitle:@"OK" 
													otherButtonTitles:nil];
		[alertWarning show];
		[alertWarning release];		
	}
	else
	{
		UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:@"Info" 
															  message:((AddEmailOBJ *)[arrEmailinfo  objectAtIndex:0]).strerrorText															 delegate:self 
													cancelButtonTitle:@"OK" 
													otherButtonTitles:nil];
		[alertWarning show];
		[alertWarning release];
	}
	
	
}
-(void)onFailure
{
	
	[tools stopLoading:loadingView];
	
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{

	if(textField.frame.origin.y>=175)
	{
		UIView *ContainedView=[textField superview];
		CGRect rect=ContainedView.frame;
		[UIView beginAnimations:nil context:nil];
		[UIView setAnimationDuration:0.3];
		rect.origin.y-=(textField.frame.origin.y-160);
		ContainedView.frame=rect;
		[UIView commitAnimations];
	}
	
	
	return YES;
}
- (BOOL)textFieldShouldEndEditing:(UITextField *)textField
{

	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.3];
	self.view.frame=CGRectMake(0, 0, 320, 410);
	[UIView commitAnimations];
	
	
	return YES;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{

	
	if(textField==txtEmail || textField==txtrenterEmail)
	{
	
		
		BOOL check=[self validateEmail:textField.text];
		if(!check)
		{
			NSString *strmessage=[[customMessageList_dict valueForKey:@"200052"]valueForKey:@"message"];
			NSString *strtype=[[customMessageList_dict valueForKey:@"200052"]valueForKey:@"type"];
			UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:strtype
																  message:strmessage 
																 delegate:self 
														cancelButtonTitle:@"OK" 
														otherButtonTitles:nil];
			[alertWarning show];
			[alertWarning release];
			return NO;
			
		}
		else 
		{
			NSArray *arr=[textField.text componentsSeparatedByString:@".@"];
			if([arr	 count]==2)
			{
				
				NSString *strmessage=[[customMessageList_dict valueForKey:@"200052"]valueForKey:@"message"];
				NSString *strtype=[[customMessageList_dict valueForKey:@"200052"]valueForKey:@"type"];
				
				UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:strtype 
																	  message:strmessage 
																	 delegate:self 
															cancelButtonTitle:@"OK" 
															otherButtonTitles:nil];
				[alertWarning show];
				[alertWarning release];
				return NO;
				
			}
			else 
			{
				
			}
			
		}
		
	}
	
		
	[textField resignFirstResponder];
	
	return YES;
}
-(BOOL)validateEmail:(NSString *)email 
{  
	BOOL stricterFilter = YES; 
	NSString *stricterFilterString = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
	NSString *laxString = @".+@.+\\.[A-Za-z]{2}[A-Za-z]*";
	NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
	NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
	return [emailTest evaluateWithObject:email];
}  
/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
	txtEmail=nil;
	txtrenterEmail=nil;
}


- (void)dealloc {
	[txtEmail release];
	[txtrenterEmail release];
    [super dealloc];
	
}


@end
