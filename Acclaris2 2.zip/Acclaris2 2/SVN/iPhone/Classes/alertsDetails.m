    //
//  alertsDetails.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 13/12/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import "alertsDetails.h"
#import "AcclarisViewController.h"
#import "UserresponcePerser.h"
#import "Decode64.h"
#import "configurables.h"

@implementation alertsDetails

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/

-(id)initWithString:(NSString *)str
{
	self=[super init];
	genericDescription=[[NSString alloc]init];
	genericDescription=str;
	return self;
}
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	
	NSMutableArray *arr_myconfig=[AcclarisViewController staticarr_config];//[configurableParser getconfig_arr];//
	con=(configurables *)[arr_myconfig objectAtIndex:0];
	
	
	self.view.backgroundColor = [UIColor colorWithRed:con.bgRed/255.0f green:con.bgGreen/255.0f blue:con.bgBlue/255.0f alpha:1.0];
	//NSMutableArray *my_arrUserinfo=[UserresponcePerser userdesc];
	UIImageView *logo_img = [[UIImageView alloc]initWithFrame:CGRectMake(0, 2, 170, 40)];
	
	NSData *data=[Base64 decode:con.logoImgdata];
	logo_img.image=	[UIImage imageWithData:[NSData dataWithData:data]];
	self.navigationItem.titleView=logo_img;
	
	
	[self createview];
	
	NSLog(@"%@",genericDescription);
	[self signoutbt];
}
-(void)signoutbt
{
	
	
	UIBarButtonItem *signoutButton = [[UIBarButtonItem alloc]
									  initWithTitle:@"Sign Off"
									  style:UIBarButtonItemStyleBordered
									  target:self
									  action:@selector(signout)];
    self.navigationItem.rightBarButtonItem =signoutButton;
}
-(void)signout
{
	[((AcclarisAppDelegate *)[[UIApplication sharedApplication] delegate]) removeTabBar];
}

-(void)createview
{
	
	
	UIView	*view_textview = [[UIView alloc]initWithFrame:CGRectMake(10, 50, 300, 200)];
	view_textview.backgroundColor = [UIColor whiteColor];
	view_textview.layer.cornerRadius=4;
	view_textview.layer.borderWidth=1.5;
	CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();	
	float grayComponents[4] = { 0.3, 0.3, 0.3, 1.0 };

	view_textview.layer.borderColor=CGColorCreate(colorSpace, grayComponents);
	[self.view addSubview:view_textview];
	
	
	txtv_msgNewNotes=[[UITextView alloc] initWithFrame:CGRectMake(5, 5, 290, 195)];
    txtv_msgNewNotes.textColor = [UIColor blackColor];
	txtv_msgNewNotes.font = [UIFont fontWithName:con.fontname size:con.fontsize];
	txtv_msgNewNotes.returnKeyType = UIReturnKeyDefault;
	txtv_msgNewNotes.autocorrectionType=NO;
	txtv_msgNewNotes.keyboardType = UIKeyboardTypeDefault;
	txtv_msgNewNotes.backgroundColor=[UIColor whiteColor];
	txtv_msgNewNotes.keyboardAppearance=UIKeyboardAppearanceAlert;
	txtv_msgNewNotes.delegate=self;
	txtv_msgNewNotes.text=genericDescription;
	[view_textview addSubview:txtv_msgNewNotes];
	
	
	
	UIButton *btn_back=[UIButton buttonWithType:UIButtonTypeRoundedRect];
	btn_back.frame = CGRectMake(43, 308, 234, 47);
	NSData *data_btnimg=[Base64 decode:con.btnImgdata];
	[btn_back setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
	btn_back.titleLabel.font = [UIFont fontWithName:con.btnfontname size:con.btnfontsize];
	[btn_back setTitle:@"Back to Alert" forState:UIControlStateNormal];
	[btn_back setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn_back addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
	[self.view addSubview:btn_back];
}
-(void)back
{
	[self.navigationController popViewControllerAnimated:YES ];
}
- (BOOL)textViewShouldBeginEditing:(UITextView *)textView
{
	return NO;
}
/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
