//
//  CountryParser.h
//  Acclaris
//
//  Created by Subhojit on 26/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CountryOBJ.h"


@interface CountryParser : NSObject<NSXMLParserDelegate> {

	CountryOBJ *objcountry;
	NSMutableString *contentOfString;
	
}
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error;
+(NSMutableArray *)getarrCountry;
@end
