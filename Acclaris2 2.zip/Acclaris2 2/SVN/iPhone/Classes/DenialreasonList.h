//
//  DenialreasonList.h
//  Acclaris
//
//  Created by Subhojit on 13/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyTools.h"
#import "Decode64.h"
#import "AcclarisAppDelegate.h"
@class configurables;

@interface DenialreasonList : UIViewController {

	configurables *con;
	MyTools *tools;
	AcclarisAppDelegate *app;
	NSString *strReasontext;
}
-(void)Createview;
-(void)signout;
-(id)initWithtext:(NSString *)str;
@end
