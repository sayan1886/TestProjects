//
//  CountryOBJ.h
//  Acclaris
//
//  Created by Subhojit on 26/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface CountryOBJ : NSObject {

	NSString *strreturnCode;
	NSString *strerrorText;
	NSString *strcountry;
	NSString *strvalue1;
	NSString *strvalue2;
	NSString *strvalue3;
	
}
@property(nonatomic,retain)NSString	*strreturnCode;
@property(nonatomic,retain)NSString *strerrorText;
@property(nonatomic,retain)NSString *strcountry;
@property(nonatomic,retain)NSString *strvalue1;
@property(nonatomic,retain)	NSString *strvalue2;
@property(nonatomic,retain)	NSString *strvalue3;
@end
