//
//  claimActivity.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 09/11/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AcclarisAppDelegate.h"
#import "MyTools.h"
#import "claimActivityDetails.h"
@class configurables;
@interface claimActivity : UIViewController <UITableViewDelegate,UITableViewDataSource>{

	MyTools *tools;
	configurables *con;
	AcclarisAppDelegate *app;
	UIView *loadingView;
	UITableView	*acctable;
	NSMutableArray *arr_celltytle;
	NSMutableArray *arr_recpt;
	
	
	NSInteger startID;
	NSString *str_startID1;
	UIButton *bt_previous;
	UIButton *bt_next;
	
}
-(void)signoutbt;
-(void)claimActivityReq;
-(void)createtableview;
+(NSInteger)getSelectedClaimRow;
-(NSString *)chkvalue:(NSString *)value;
-(id)initWithArrayName:(NSArray *)arr;
-(void)createHeader;
@end
