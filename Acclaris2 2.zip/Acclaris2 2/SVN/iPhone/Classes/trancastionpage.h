//
//  trancastion.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 19/10/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyTools.h"
@class configurables;
@class transactionDetailsPage;
@class transactionOBJ;

@interface trancastionpage : UIViewController<UITableViewDelegate,UITableViewDataSource> {
	
	configurables *con;
	
	transactionOBJ *mytransactionOBJ;
	NSMutableArray *arr_alltransaction;
	UITableView	*acctable;
	
	NSInteger startID;
	NSString *str_startID1;
	UIButton *bt_previous;
	UIButton *bt_next;
	
	NSMutableArray *transaction_info;
	

	MyTools *tools;
	UIView *loadingView;
	BOOL isInvestment;
}
-(void)signoutbt;
-(void)createtableview;
+(NSInteger)getSelectedRow;
-(NSString *)chkvalue:(NSString *)value;
-(void)fetchTransaction;
-(id)initWithArrayName:(NSMutableArray *)arr;
@end
