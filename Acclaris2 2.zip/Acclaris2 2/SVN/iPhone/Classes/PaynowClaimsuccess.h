//
//  PaynowClaimsuccess.h
//  Acclaris
//
//  Created by Subhojit on 28/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyTools.h"
#import "Decode64.h"
#import "AcclarisAppDelegate.h"
#import "PaynowcontinueParser.h"
@class configurables;

@interface PaynowClaimsuccess : UIViewController {

	
	AcclarisAppDelegate *app;
	configurables *con;
	MyTools *tools;
    UIView *loadingView;
	
}
-(void)CreateView;
-(void)Clickbtnbackclaim;
@end
