//
//  Paynow.h
//  Acclaris
//
//  Created by Subhojit on 28/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyTools.h"
#import "Decode64.h"
#import "PaynowOBJ.h"
#import "PaynowParser.h"
#import "PaynowAccountOBJ.h"
#import "RequestPhase2.h"
#import "AcclarisAppDelegate.h"
#import "passPerser.h"
#import "PaynowcontinueParser.h"
#import "PaynowClaimsuccess.h"
#import "SelectServiceProvider.h"
@class configurables;

@interface Paynow : UIViewController<UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate,UIPickerViewDelegate> {

	
	AcclarisAppDelegate *app;
	configurables *con;
	MyTools *tools;
    UIView *loadingView;
	UITableView *table;
	UITextField *txtDate;
	UITextField *txtFrom;
	UITextField *txtCatagory;
	UITextField *txtAmount;
	UITextField *txtinvoice;
	UITextField *txtAccount;
	UITextField *txtpayment;
	UITextField *txtSelectAccount;
	NSMutableArray *arrAllSection;
	NSMutableArray *focusArray;
	UIButton *btnRadio;
	UIButton *btnRadio1;
	UIPickerView	*myPickerView;
	UIDatePicker  *datePicker;
	NSString   *strTxtNm;
	NSMutableArray   *pickerViewArray;
	NSMutableArray *arrpaynow;
	NSMutableArray *arrAcountdetail;
	PaynowOBJ *objpay;
	PaynowAccountOBJ *objAcc;
	
	NSString *strPaystatus;
	
	int Selectedpickerrow;
	id type;
	NSMutableDictionary *DictSavedSubmitclaimInfo;
		

	NSString *strFront;
}
-(void)CreatePickerView;
-(void)datePickerCreate;
-(void)HeadertypeInput:(UITableViewCell *)cell;
-(void)PaytypeInput:(UITableViewCell *)cell;
-(void)DateInput:(UITableViewCell *)cell;
-(void)FromInput:(UITableViewCell *)cell;
-(void)CatagoryInput:(UITableViewCell *)cell;
-(void)AmountInput:(UITableViewCell *)cell;
-(void)SelectAccountInput:(UITableViewCell *)cell;
-(void)CreateView;
-(void)constructTableCell;
-(void)signout;
-(void)createbarbuttondone;
-(void)Vanishpicker;
-(void)createbar_button;

@end
