//
//  denialReasonOBJ.h
//  Acclaris
//
//  Created by Ayon on 16/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface denialReasonOBJ : NSObject
{
	NSString *sequence;
	NSString *text;
	NSString *deniedOn;
	NSString *deniedBy;
	
}
@property(nonatomic,retain)NSString *sequence;
@property(nonatomic,retain)NSString *text;
@property(nonatomic,retain)NSString *deniedOn;
@property(nonatomic,retain)NSString *deniedBy;
@end
