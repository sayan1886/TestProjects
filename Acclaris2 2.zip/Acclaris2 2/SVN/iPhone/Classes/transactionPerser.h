//
//  transactionPerser.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 19/10/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AcclarisAppDelegate.h"
@class transactionOBJ;
@class errorcodeOBJ;
@interface transactionPerser : NSObject<NSXMLParserDelegate> {

	AcclarisAppDelegate *app;
	NSMutableString *contentOfString;
	NSMutableArray *arrLocal;
	transactionOBJ *mytransactionOBJ;
	
	errorcodeOBJ *myerrorcodeOBJ;
}
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error;
+(NSMutableArray *)get_arr_transaction;
+(NSMutableArray *)geterror_arr;
+(BOOL)gethasMoreRecords_transaction;

@end
