//
//  ShowImageDetailsOBJ.m
//  Acclaris
//
//  Created by Subhojit on 19/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ShowImageDetailsOBJ.h"


@implementation ShowImageDetailsOBJ

@synthesize strfileID,strfileType,strfilePath,strfileSize,strfileReceivedOn,strOrigFileName;
@end

