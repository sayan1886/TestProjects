//
//  transactionPerser.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 19/10/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import "transactionPerser.h"
#import "transactionOBJ.h"
#import "errorcodeOBJ.h"
NSMutableArray *arr_transaction;
NSMutableArray *errordetails;
BOOL hasMoreRecords_transaction;
@implementation transactionPerser
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error
{
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	arr_transaction = [[NSMutableArray alloc]init];
	NSXMLParser *parser;
	parser = [[NSXMLParser alloc] initWithData:data];
    [parser setDelegate:self];
	[parser setShouldProcessNamespaces:NO];
    [parser setShouldReportNamespacePrefixes:NO];
    [parser setShouldResolveExternalEntities:NO];
    [parser parse];
    NSError *parseError = [parser parserError];
    if (parseError && error) 
	{
        *error = parseError;
    }
	[parser release];
}

-(void)parserDidStartDocument:(NSXMLParser *)parser
{
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	myerrorcodeOBJ=[[errorcodeOBJ alloc]init];
	errordetails=[[NSMutableArray alloc]init];
}		

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
	if (qName)
	{
		elementName = qName;
	}
	else 
		if([elementName isEqualToString:@"returnCode"])
		{
			
			contentOfString=[NSMutableString string];
			[contentOfString retain];
			return;		
			
		}
		else 
			if([elementName isEqualToString:@"errorText"])
			{
				
				contentOfString=[NSMutableString string];
				[contentOfString retain];
				return;		
				
			}
			else 
				if([elementName isEqualToString:@"hasMoreRecords"])
				{
					contentOfString=[NSMutableString string];
					[contentOfString retain];
					return;		
					
				}
	else 
		if([elementName isEqualToString:@"transaction"])
		{
			mytransactionOBJ=[[transactionOBJ alloc]init];
			return;			
			
		}
		else 
			if([elementName isEqualToString:@"transactionDate"])
			{
				contentOfString=[NSMutableString string];
				[contentOfString retain];
				return;		
				
			}
			else 
				if([elementName isEqualToString:@"transactionAmount"])
				{
					contentOfString=[NSMutableString string];
					[contentOfString retain];
					return;		
					
				}
				else 
					if([elementName isEqualToString:@"transactionType"])
					{
						contentOfString=[NSMutableString string];
						[contentOfString retain];
						return;	
						
					}
					else 
						if([elementName isEqualToString:@"transactionCode"])
						{
							contentOfString=[NSMutableString string];
							[contentOfString retain];
							return;	
							
						}
						else 
							if([elementName isEqualToString:@"transactionDescription"])
							{
								contentOfString=[NSMutableString string];
								[contentOfString retain];
								return;		
								
							}
							else 
								if([elementName isEqualToString:@"serviceDate"])
								{
									contentOfString=[NSMutableString string];
									[contentOfString retain];
									return;		
									
								}
								else 
									if([elementName isEqualToString:@"From"])
									{
										contentOfString=[NSMutableString string];
										[contentOfString retain];
										return;		
										
									}
									else 
										if([elementName isEqualToString:@"status"])
										{
											contentOfString=[NSMutableString string];
											[contentOfString retain];
											return;			
											
										}
										else 
											if([elementName isEqualToString:@"category"])
											{
												contentOfString=[NSMutableString string];
												[contentOfString retain];
												return;		
												
											}
											else 
												if([elementName isEqualToString:@"note"])
												{
													contentOfString=[NSMutableString string];
													[contentOfString retain];
													return;		
													
												}
												else 
													if([elementName isEqualToString:@"account"])
													{
														contentOfString=[NSMutableString string];
														[contentOfString retain];
														return;		
														
													}
													else 
														if([elementName isEqualToString:@"effectiveDate"])
														{
															contentOfString=[NSMutableString string];
															[contentOfString retain];
															return;		
															
														}
														else 
															if([elementName isEqualToString:@"dpstType"])
															{
																contentOfString=[NSMutableString string];
																[contentOfString retain];
																return;		
																
															}
	
		
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName     
{	
	if (qName)
	{
        elementName = qName;
		
    }
	else 
		if([elementName isEqualToString:@"returnCode"])
		{
			if(contentOfString)
			{
				myerrorcodeOBJ.returnCode=contentOfString;
				[contentOfString release];
				contentOfString = nil;
				
				
			}	
			
		}
		else 
			if([elementName isEqualToString:@"errorText"])
			{
				if(contentOfString)
				{
					myerrorcodeOBJ.errorText=contentOfString;
					[errordetails addObject:myerrorcodeOBJ];
					[contentOfString release];
					contentOfString = nil;
					
					
				}		
				
			}
			else 
				if([elementName isEqualToString:@"hasMoreRecords"])
				{
					if(contentOfString)
					{
						if ([contentOfString isEqualToString:@"Yes"])
						{
							hasMoreRecords_transaction=YES;
						}
						else {
							hasMoreRecords_transaction=NO;	
						}
						
					}		
					
				}
	
	else 
		if([elementName isEqualToString:@"transaction"])
		{
			
			[arr_transaction addObject:mytransactionOBJ];
			[mytransactionOBJ release];
			mytransactionOBJ = nil;
			
			
			
			
		}
		else 
			if([elementName isEqualToString:@"transactionDate"])
			{
				if(contentOfString)
				{
					NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
					if ([arrlocal1 count]>1)
					{
						mytransactionOBJ.transactionDate=[arrlocal1 objectAtIndex:1];
						mytransactionOBJ.lbltransactionDate=[arrlocal1 objectAtIndex:0];
					}
					else {
						mytransactionOBJ.transactionDate=[arrlocal1 objectAtIndex:0];
					}

					
					[contentOfString release];
					contentOfString = nil;
					
					
				}		
				
			}
			else 
				if([elementName isEqualToString:@"transactionAmount"])
				{
					if(contentOfString)
					{
						NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
						if ([arrlocal1 count]>1)
						{
							mytransactionOBJ.transactionAmount=[arrlocal1 objectAtIndex:1];
							mytransactionOBJ.lbltransactionAmount=[arrlocal1 objectAtIndex:0];
						}
						else {
							mytransactionOBJ.transactionAmount=[arrlocal1 objectAtIndex:0];
						}

						[contentOfString release];
						contentOfString = nil;
						
						
					}	
					
				}
				else 
					if([elementName isEqualToString:@"transactionType"])
					{
						if(contentOfString)
						{
							NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
							if ([arrlocal1 count]>1)
							{
								mytransactionOBJ.transactionType=[arrlocal1 objectAtIndex:1];
								mytransactionOBJ.lbltransactionType=[arrlocal1 objectAtIndex:0];
							}
							else {
								mytransactionOBJ.transactionType=[arrlocal1 objectAtIndex:0];
							}

							[contentOfString release];
							contentOfString = nil;
							
							
							
						}	
						
					}
					else 
						if([elementName isEqualToString:@"transactionCode"])
						{
							if(contentOfString)
							{
								
								NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
								if ([arrlocal1 count]>1)
								{
									mytransactionOBJ.transactionCode=[arrlocal1 objectAtIndex:1];
									mytransactionOBJ.lbltransactionCode=[arrlocal1 objectAtIndex:0];
								}
								else {
									mytransactionOBJ.transactionCode=[arrlocal1 objectAtIndex:0];
								}

								[contentOfString release];
								contentOfString = nil;
								
								
								
							}	
							
						}
						else 
							if([elementName isEqualToString:@"transactionDescription"])
							{
								if(contentOfString)
								{
									NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
									if ([arrlocal1 count]>1)
									{
										mytransactionOBJ.transactionDescription=[arrlocal1 objectAtIndex:1];
										mytransactionOBJ.lbltransactionDescription=[arrlocal1 objectAtIndex:0];
									}
									else {
										mytransactionOBJ.transactionDescription=[arrlocal1 objectAtIndex:0];
									}

									[contentOfString release];
									contentOfString = nil;
									
									
								}		
								
							}
							else 
								if([elementName isEqualToString:@"serviceDate"])
								{
									if(contentOfString)
									{
										
										NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
										if ([arrlocal1 count]>1)
										{
											mytransactionOBJ.serviceDate=[arrlocal1 objectAtIndex:1];
											mytransactionOBJ.lblserviceDate=[arrlocal1 objectAtIndex:0];
										}
										else
										mytransactionOBJ.serviceDate=[arrlocal1 objectAtIndex:0];	
										

										[contentOfString release];
										contentOfString = nil;
										
										
									}	
									
								}
								else 
									if([elementName isEqualToString:@"From"])
									{
										if(contentOfString)
										{
											NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
											if ([arrlocal1 count]>1)
											{
												mytransactionOBJ.From=[arrlocal1 objectAtIndex:1];
												mytransactionOBJ.lblFrom=[arrlocal1 objectAtIndex:0];
											}
												else
												{
													mytransactionOBJ.From=[arrlocal1 objectAtIndex:0];
												}
											[contentOfString release];
											contentOfString = nil;
											
										}	
										
									}
	
									else 
										if([elementName isEqualToString:@"status"])
										{
											if(contentOfString)
											{
												NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
												if ([arrlocal1 count]>1)
												{
												mytransactionOBJ.status=[arrlocal1 objectAtIndex:1];
													mytransactionOBJ.lblstatus=[arrlocal1 objectAtIndex:0];
												}
												else {
													mytransactionOBJ.status=[arrlocal1 objectAtIndex:0];
												}

												[contentOfString release];
												contentOfString = nil;
											
											}
																						
										}
										else 
											if([elementName isEqualToString:@"category"])
											{
												if(contentOfString)
												{
													NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
													if ([arrlocal1 count]>1)
													{
														mytransactionOBJ.category=[arrlocal1 objectAtIndex:1];
														mytransactionOBJ.lblcategory=[arrlocal1 objectAtIndex:0];

													}
													else
														mytransactionOBJ.category=[arrlocal1 objectAtIndex:0];
													[contentOfString release];
													contentOfString = nil;
													
													
												}	
												
											}
											else 
												if([elementName isEqualToString:@"note"])
												{
													if(contentOfString)
													{
														NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
														if ([arrlocal1 count]>1)
														{
															mytransactionOBJ.note=[arrlocal1 objectAtIndex:1];
															mytransactionOBJ.lblnote=[arrlocal1 objectAtIndex:0];
														}
															else 
														mytransactionOBJ.note=[arrlocal1 objectAtIndex:0];
														[contentOfString release];
														contentOfString = nil;
														
														
														
													}	
													
												}
												else 
													if([elementName isEqualToString:@"account"])
													{
														if(contentOfString)
														{
															NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
															if ([arrlocal1 count]>1)
															{
																mytransactionOBJ.account=[arrlocal1 objectAtIndex:1];
																mytransactionOBJ.lblaccount=[arrlocal1 objectAtIndex:0];
															}
															else {
																mytransactionOBJ.account=[arrlocal1 objectAtIndex:0];
															}

															[contentOfString release];
															contentOfString = nil;
															
															
														}		
														
													}
													else 
														if([elementName isEqualToString:@"effectiveDate"])
														{
															if(contentOfString)
															{
																NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
																if ([arrlocal1 count]>1)
																{
																mytransactionOBJ.effectiveDate=[arrlocal1 objectAtIndex:1];
																	mytransactionOBJ.lbleffectiveDate=[arrlocal1 objectAtIndex:0];
																}
																else 
																	mytransactionOBJ.effectiveDate=[arrlocal1 objectAtIndex:0];
																[contentOfString release];
																contentOfString = nil;
																
																
															}	
															
														}
														else 
															if([elementName isEqualToString:@"dpstType"])
															{
																if(contentOfString)
																{
																	NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
																	if ([arrlocal1 count]>1)
																	{
																		mytransactionOBJ.dpstType=[arrlocal1 objectAtIndex:1];
																		mytransactionOBJ.lbldpstType=[arrlocal1 objectAtIndex:0];
																	}
																	
																	else 
																		mytransactionOBJ.dpstType=[arrlocal1 objectAtIndex:0];
																	[contentOfString release];
																	contentOfString = nil;
																	
																	
																}	
																
															}
	
															
	
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
	if(contentOfString)
		[contentOfString appendString:string];
}

- (void)parserDidEndDocument:(NSXMLParser *)parse
{
	NSLog(@"**********%@",arr_transaction);
}	
+(NSMutableArray *)get_arr_transaction
{
	if (arr_transaction) {
		
		return arr_transaction;
	}
	else {
		return nil;
	}
	
}
+(NSMutableArray *)geterror_arr
{
	if (errordetails) {
		
		return errordetails;
	}
	else {
		return nil;
	}
	
}
+(BOOL)gethasMoreRecords_transaction
{
	if (hasMoreRecords_transaction) {
		
		return hasMoreRecords_transaction;
	}
	else {
		return NO;
	}
	
}

@end
