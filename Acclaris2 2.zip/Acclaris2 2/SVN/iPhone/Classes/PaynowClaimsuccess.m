    //
//  PaynowClaimsuccess.m
//  Acclaris
//
//  Created by Subhojit on 28/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "PaynowClaimsuccess.h"
#import "configurables.h"
#import "AcclarisViewController.h"

@implementation PaynowClaimsuccess

- (void)viewDidLoad {
    [super viewDidLoad];
	
	
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	tools=[[MyTools alloc]init];
	loadingView=[tools createActivityIndicator1];
	
		
	NSMutableArray *arr_myconfig=[AcclarisViewController staticarr_config];
	con=(configurables *)[arr_myconfig objectAtIndex:0];
	self.view.backgroundColor = [UIColor colorWithRed:con.bgRed/255.0f green:con.bgGreen/255.0f blue:con.bgBlue/255.0f alpha:1.0];
	
	self.navigationController.navigationBar.tintColor=[UIColor colorWithRed:con.navbarRed/255.0f green:con.navbarGreen/255.0f blue:con.navbarBlue/255.0f alpha:1.0];
	
	UIImageView *logo_img = [[UIImageView alloc]initWithFrame:CGRectMake(0, 2, 170, 40)];
	NSData *data=[Base64 decode:con.logoImgdata];
	logo_img.image=	[UIImage imageWithData:[NSData dataWithData:data]];
	self.navigationItem.titleView=logo_img;
	
	[self CreateView];

}
-(void)CreateView
{

	  
	  NSString *strFont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];
	
		NSData *data_btnimg=[Base64 decode:con.btnImgdata];//btn background image
		UIView *HeaderView=[[[UIView alloc]initWithFrame:CGRectMake(0, 0, 320, 45)]autorelease];
		HeaderView.backgroundColor=[UIColor colorWithRed:con.bgRed2/255.0 green:con.bgGreen2/255.0 blue:con.bgBlue2/255.0 alpha:1.0];
		[self.view addSubview:HeaderView];

		NSString *strViewTitle=@"Claim Success";
		UILabel *lbltext=[[UILabel alloc]initWithFrame:CGRectMake(10, 3, 210, 40)];
		lbltext.text=strViewTitle;
		lbltext.backgroundColor=[UIColor clearColor];
		lbltext.textColor=[UIColor whiteColor];
		lbltext.numberOfLines=0;
		lbltext.font=[UIFont fontWithName:strFont size:con.headerImpfntsize];
		[HeaderView addSubview:lbltext];
		[lbltext release],lbltext=nil;
	
	
	UIButton *btnbackclaim=[UIButton buttonWithType:UIButtonTypeRoundedRect];
	btnbackclaim.frame=CGRectMake(30, 310, 260, 40);
	[btnbackclaim setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
	[btnbackclaim setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	btnbackclaim.titleLabel.font = [UIFont fontWithName:con.btnfontname size:con.btnfontsize];
	[btnbackclaim setTitle:@"Back to claims" forState:UIControlStateNormal];
	[btnbackclaim addTarget:self action:@selector(Clickbtnbackclaim) forControlEvents:UIControlEventTouchUpInside];					 
	[self.view addSubview:btnbackclaim];
	
	NSString *str=[PaynowcontinueParser  getErrortext];

	UILabel *lblmsg=[[UILabel alloc]initWithFrame:CGRectMake(10, 60, 300, 100)];
	lblmsg.backgroundColor=[UIColor clearColor];
	lblmsg.text=str;
	lblmsg.font=[UIFont fontWithName:con.fontname size:con.bodyfntsize];
	lblmsg.numberOfLines=0;
	[self.view addSubview:lblmsg];
	
}
-(void)Clickbtnbackclaim
{
	
	[self.navigationController popToRootViewControllerAnimated:YES];
}
/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
