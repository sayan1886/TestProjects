//
//  claimPassthru.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 30/11/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyTools.h"
#import "PaynowOBJ.h"
#import "PaynowParser.h"

@class configurables;

@interface claimPassthru : UIViewController <UITableViewDelegate,UITableViewDataSource>{

	MyTools *tools;
	UIView *loadingView;
	configurables *con;
	UITableView	*acctable;
	NSMutableArray *arr_celltytle;
	
	
	NSString *whichclass;
	NSInteger startID;
	NSString *str_startID1;
	UIButton *bt_previous;
	UIButton *bt_next;
	
	UIButton *btnRadio,*btnRadio1;
	UILabel *btnRadiotext,*btnRadio1text;
	NSMutableArray *arrpaynow;
	
	UIView	*view_rounded;
	
	BOOL ignoreAll;
	NSString *pclaimid;
	NSString *strFont;
	
	NSDictionary *customMessageList_dict;
	
}
-(void)showIgnoredClaims;
-(void)signoutbt;
-(void)claimPassthruReq;
-(void)createtableview;
-(NSString *)chkvalue:(NSString *)value;
//-(id)initWithArrayName:(NSArray *)arr;
-(id)initWithstring:(NSString *)str;
-(void)ignoreAllclaim;
@end
