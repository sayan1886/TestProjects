//
//  ticketClose.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 02/11/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AcclarisAppDelegate.h"
#import "MyTools.h"
@class configurables;

@class ticket;
@interface ticketClose : UIViewController <UITextViewDelegate>{
	AcclarisAppDelegate *app;
	UITextView *txtv_msgCloseNotes;
	NSInteger selectedRow;
	NSMutableArray *arr_celltytle;
	UIBarButtonItem *signoutButton;
	UIBarButtonItem *doneButton;
	UIButton *btn_submitcloseMSG;
	
	MyTools *tools;
	UIView *loadingView;
	configurables *con;
}
-(void)signoutbt;
-(void)donebt;
-(void)reqTicket;
@end
