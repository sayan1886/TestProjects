//
//  SelectedImageBig.h
//  Acclaris
//
//  Created by Subhojit on 24/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyTools.h"
#import "Decode64.h"
@class configurables;

@interface SelectedImageBig : UIViewController {

	configurables *con;
	MyTools *tools;

	NSMutableArray *arrImage;
	UIImageView *newImageView;
	int i;
	id actionTarget;
	SEL actionHandler;
}
//-(id)initWithImgView:(UIImageView *)aImageView target:(id)target action:(SEL)action;
-(id)initWithImgView:(UIImageView *)aImageView  target:(id)target action:(SEL)action;
-(void)CreateView;
-(void)signout;
@end
