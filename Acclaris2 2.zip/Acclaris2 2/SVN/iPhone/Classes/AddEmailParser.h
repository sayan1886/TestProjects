//
//  AddEmailParser.h
//  Acclaris
//
//  Created by Subhojit on 18/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AddEmailOBJ.h"


@interface AddEmailParser : NSObject<NSXMLParserDelegate> {

	AddEmailOBJ *obj;
	NSMutableString *contentOfString;
	
}
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error;
+(NSMutableArray *)getarrAddemail;
@end
