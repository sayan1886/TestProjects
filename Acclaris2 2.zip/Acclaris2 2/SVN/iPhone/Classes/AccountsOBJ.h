//
//  AccountsOBJ.h
//  Acclaris
//
//  Created by Sayan banerjee on 19/11/10.
//  Copyright 2010 Objectsol. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface AccountsOBJ : NSObject {

	NSString *accountTypeCode;
	NSString *accountDisplaySeq;
	NSString *accountShortName;
	NSString *accountDisplayName;
	NSString *balanceRelevant;
	NSString *investmentRelevant;
	NSString *electionListCount;
	NSString *planPeriodType;
	NSString *manageContribLink,*lblmanageContribLink;
	NSMutableArray *elections;

}
@property(nonatomic,retain)NSString *accountTypeCode;
@property(nonatomic,retain)NSString *accountDisplaySeq;
@property(nonatomic,retain)NSString *accountShortName;
@property(nonatomic,retain)NSString *accountDisplayName;
@property(nonatomic,retain)NSString *balanceRelevant;
@property(nonatomic,retain)NSString *investmentRelevant;
@property(nonatomic,retain)NSString *electionListCount;
@property(nonatomic,retain)NSString *planPeriodType;
@property(nonatomic,retain)NSString *enrollmentStatus;
@property(nonatomic,retain)NSString *manageContribLink,*lblmanageContribLink;
@property(nonatomic,retain)NSMutableArray *elections;

@end
