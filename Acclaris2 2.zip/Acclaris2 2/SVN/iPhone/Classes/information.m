    //
//  information.m
//  Acclaris
//
//  Created by Sayan banerjee on 21/11/10.
//  Copyright 2010 Objectsol. All rights reserved.
//

#import "information.h"
#import "configurables.h"
#import "configurableParser.h"
#import "AcclarisViewController.h"
#import "SignIn.h"
#define FONT_SIZE 15.0f
#define CELL_CONTENT_WIDTH 290.0f
#define CELL_CONTENT_MARGIN 10.0f

@implementation information

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	
	NSMutableArray *arr_myconfig=[AcclarisViewController staticarr_config];//[configurableParser getconfig_arr];//
	con=(configurables *)[arr_myconfig objectAtIndex:0];
	self.view.backgroundColor = [UIColor colorWithRed:con.bgRed/255.0f green:con.bgGreen/255.0f blue:con.bgBlue/255.0f alpha:1.0];
	
	UIView	*view_textview = [[UIView alloc]initWithFrame:CGRectMake(10, 50, 300, 300)];
	view_textview.backgroundColor = [UIColor whiteColor];
	view_textview.layer.cornerRadius=4;
	view_textview.layer.borderWidth=1.5;
	CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();	
	float grayComponents[4] = { 0.3, 0.3, 0.3, 1.0 };
	view_textview.layer.borderColor=CGColorCreate(colorSpace, grayComponents);
	[self.view addSubview:view_textview];
	
	
	//NSString *str=@"";
		
	UILabel	*lbl_text = [[UILabel alloc]initWithFrame:CGRectMake(15, 55, 320-30, 65)];
	lbl_text.textAlignment = UITextAlignmentLeft;
	lbl_text.numberOfLines=0;
	lbl_text.font = [UIFont fontWithName:con.fontname size:con.fontsize];
	lbl_text.backgroundColor = [UIColor clearColor];
	lbl_text.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
	NSString *strDisplay=[SignIn getString];
	if ([strDisplay isEqualToString:@""]) {
		strDisplay=@"No data Available.";
	}
	
	NSArray *localarr=[strDisplay componentsSeparatedByString:@"|"];
	NSString *str=@"";
	NSString *text =[str stringByAppendingString:[localarr objectAtIndex:1]];
	CGSize constraint = CGSizeMake(CELL_CONTENT_WIDTH - (CELL_CONTENT_MARGIN * 2), 20000.0f);
	CGSize size = [text sizeWithFont:[UIFont fontWithName:con.fontname size:con.fontsize] constrainedToSize:constraint lineBreakMode:UILineBreakModeWordWrap];
	CGFloat height = MAX(size.height, 10.0f);
	lbl_text.frame=CGRectMake(15, 55, 320-30, height);

	//str=[str stringByAppendingString:[localarr objectAtIndex:0]];
	//str=[str stringByAppendingString:@"\n"];
	
	if ([localarr count]>1)
	{
		str=[str stringByAppendingString:[localarr objectAtIndex:1]];

	}
	
	lbl_text.text =str;
	[self.view addSubview:lbl_text];
	
	
}



/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
