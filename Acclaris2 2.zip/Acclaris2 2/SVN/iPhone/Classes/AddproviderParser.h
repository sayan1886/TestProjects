//
//  AddproviderParser.h
//  Acclaris
//
//  Created by Subhojit on 19/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "errorcodeOBJ.h"


@interface AddproviderParser : NSObject<NSXMLParserDelegate> {

	errorcodeOBJ *objerror;
	NSMutableString *contentOfString;
}
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error;
+(NSString *)getstraddprovidererrortext;
@end
