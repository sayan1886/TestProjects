//
//  claimactivityPerser.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 09/11/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import "claimactivityPerser.h"
#import "claimActivityOBJ.h"
#import "errorcodeOBJ.h"
#import "denialReasonOBJ.h"
NSMutableArray *errordetails;
NSMutableArray *arrclaimActivity;
BOOL hasMoreRecords_claim;
@implementation claimactivityPerser
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error
{
	
	NSXMLParser *parser;
	parser = [[NSXMLParser alloc] initWithData:data];
    [parser setDelegate:self];
	[parser setShouldProcessNamespaces:NO];
    [parser setShouldReportNamespacePrefixes:NO];
    [parser setShouldResolveExternalEntities:NO];
    [parser parse];
    NSError *parseError = [parser parserError];
    if (parseError && error) 
	{
        *error = parseError;
    }
	[parser release];
}

-(void)parserDidStartDocument:(NSXMLParser *)parser
{
	
	arrItem=[[NSMutableArray alloc]init];
	myerrorcodeOBJ=[[errorcodeOBJ alloc]init];
	errordetails=[[NSMutableArray alloc]init];
}		

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
	if(qName)
	{
        elementName = qName;
    }	
	else 
		if([elementName isEqualToString:@"returnCode"])
		{
			
			contentOfString=[NSMutableString string];
			[contentOfString retain];
			return;		
			
		}
		else 
			if([elementName isEqualToString:@"errorText"])
			{
				
				contentOfString=[NSMutableString string];
				[contentOfString retain];
				return;		
				
			}
				else 
				if([elementName isEqualToString:@"hasMoreRecords"])
				{
					contentOfString=[NSMutableString string];
					[contentOfString retain];
					return;		
					
				}
	
	if([elementName isEqualToString:@"claimsActivity"])
	{	
		myclaimActivity=[[claimActivityOBJ alloc]init];
		return;		
	}
	else if([elementName isEqualToString:@"claimID"] )
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}	
	else if([elementName isEqualToString:@"trxnID"])
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}	
	else if([elementName isEqualToString:@"serviceDate"])
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}	
	else if([elementName isEqualToString:@"accountType"])
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}
	else if([elementName isEqualToString:@"claimType"])
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}
	else if([elementName isEqualToString:@"claimCategory"])
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}	
	else if([elementName isEqualToString:@"amount"])
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}	
	else if([elementName isEqualToString:@"status"])
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}
	else if([elementName isEqualToString:@"denialReasonList"])
	{
		myclaimActivity.arrdenialReason=[[NSMutableArray alloc]init];
		return;
	}
	else if([elementName isEqualToString:@"denialReason"])
	{
		mydenialOBJ=[[denialReasonOBJ alloc]init];
		[mydenialOBJ retain];
		return;
		
	}
	else if([elementName isEqualToString:@"sequence"])
	{
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;
		
	}
	else if([elementName isEqualToString:@"text"])
	{
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;
		
	}
	else if([elementName isEqualToString:@"deniedOn"])
	{
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;
	}
	else if([elementName isEqualToString:@"deniedBy"])
	{
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;
	}
	
	else if([elementName isEqualToString:@"provider"])
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}
	else if([elementName isEqualToString:@"paymentStatus"])
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}
	else if([elementName isEqualToString:@"checkNo"])
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}	

	else if([elementName isEqualToString:@"paymentAmount"])
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}	

	else if([elementName isEqualToString:@"paymentMethod"])
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}	

	else if([elementName isEqualToString:@"paymentDate"])
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}	

	else if([elementName isEqualToString:@"isPreTax"])
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}	

	else if([elementName isEqualToString:@"claimSubType"])
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}	

	else if([elementName isEqualToString:@"submitDate"])
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}	
	else if([elementName isEqualToString:@"passthruClaimDate"])
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}
	
	
	
}
- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName     
{	
	if(qName)
	{
        elementName = qName;
		
    }	
	else 
		if([elementName isEqualToString:@"returnCode"])
		{
			if(contentOfString)
			{
				myerrorcodeOBJ.returnCode=contentOfString;
				[contentOfString release];
				contentOfString = nil;
				
				
			}	
			
		}
		else 
			if([elementName isEqualToString:@"errorText"])
			{
				if(contentOfString)
				{
					myerrorcodeOBJ.errorText=contentOfString;
					[errordetails addObject:myerrorcodeOBJ];
					[contentOfString release];
					contentOfString = nil;
					
					
				}		
				
			}
	 
	else if([elementName isEqualToString:@"hasMoreRecords"])
	{
		if(contentOfString)
		{
			if ([contentOfString isEqualToString:@"Yes"])
			{
				hasMoreRecords_claim=YES;
			}
			else {
				hasMoreRecords_claim=NO;	
			}
			
		}		
		
	}
	
	else if([elementName isEqualToString:@"claimsActivity"])
	{
		[arrItem addObject:myclaimActivity];
		myclaimActivity=nil;			
	}	
	else if([elementName isEqualToString:@"claimID"])
	{
		if(contentOfString)
		{
			NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
			if([tempArr count]==2)
			{
				myclaimActivity.LBLclaimID =[tempArr objectAtIndex:0];
				myclaimActivity.claimID = [tempArr objectAtIndex:1];	
			}
			else {
				myclaimActivity.LBLclaimID=@"";
				myclaimActivity.claimID=contentOfString;
			}
			
			
			
			contentOfString=nil;
		}		
	}	
	else if([elementName isEqualToString:@"trxnID"])
	{
		if(contentOfString)
		{
			NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
			if([tempArr count]==2)
			{
				myclaimActivity.LBLtrxnID=[tempArr objectAtIndex:0];
				myclaimActivity.trxnID = [tempArr objectAtIndex:1];	
			}
			else {
				myclaimActivity.LBLtrxnID=@"";
				myclaimActivity.trxnID=contentOfString;
			}
			
			contentOfString=nil;
		}		
	}
	else if([elementName isEqualToString:@"serviceDate"])
	{
		if(contentOfString)
		{
			
			NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
			if([tempArr count]==2)
			{
				myclaimActivity.LBLserviceDate=[tempArr objectAtIndex:0];
				myclaimActivity.serviceDate = [tempArr objectAtIndex:1];
			}
			else {
				myclaimActivity.LBLserviceDate=@"";
				myclaimActivity.serviceDate=contentOfString;
			}
			
			contentOfString=nil;
		}		
	}
	else if([elementName isEqualToString:@"accountType"])
	{
		if(contentOfString)
		{
			NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
			if([tempArr count]==2)
			{
				myclaimActivity.LBLaccountType=[tempArr objectAtIndex:0];
				myclaimActivity.accountType = [tempArr objectAtIndex:1];	
			}
			else {
				myclaimActivity.LBLaccountType=@"";
				myclaimActivity.accountType= contentOfString;
			}
			
			
			contentOfString=nil;
		}		
	}
	else if([elementName isEqualToString:@"claimType"])
	{
		if(contentOfString)
		{
			NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
			if([tempArr count]==2)
			{
				myclaimActivity.LBLclaimType=[tempArr objectAtIndex:0];
				myclaimActivity.claimType = [tempArr objectAtIndex:1];	
			}
			else {
				myclaimActivity.LBLclaimType=@"";
				myclaimActivity.claimType=contentOfString;
			}
			
			
			contentOfString=nil;
		}		
	}
	else if([elementName isEqualToString:@"claimCategory"])
	{
		if(contentOfString)
		{
			NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
			if([tempArr count]==2)
			{
				myclaimActivity.LBLclaimCategory=[tempArr objectAtIndex:0];
				myclaimActivity.claimCategory = [tempArr objectAtIndex:1];
			}
			else {
				myclaimActivity.LBLclaimCategory=@"";
				myclaimActivity.claimCategory=contentOfString;
			}
			
			contentOfString=nil;
		}		
	}
	else if([elementName isEqualToString:@"amount"])
	{
		if(contentOfString)
		{
			NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
			if([tempArr count]==2)
			{
				myclaimActivity.LBLamount=[tempArr objectAtIndex:0];
				myclaimActivity.amount = [tempArr objectAtIndex:1];	
			}
			else {
				myclaimActivity.LBLamount=@"";
				myclaimActivity.amount=contentOfString;
			}
			
			
			contentOfString=nil;
		}		
	}
	else if([elementName isEqualToString:@"status"])
	{
		if(contentOfString)
		{
			NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
			if([tempArr count]==2)
			{
				myclaimActivity.LBLstatus=[tempArr objectAtIndex:0];
				myclaimActivity.status = [tempArr objectAtIndex:1];	
			}
			else {
				myclaimActivity.LBLstatus=@"";
				myclaimActivity.status=contentOfString;
			}
			
			
			contentOfString=nil;
		}		
	}
	else if([elementName isEqualToString:@"denialReason"])
	{
		[myclaimActivity.arrdenialReason addObject:mydenialOBJ];
		
		
	}
	else if([elementName isEqualToString:@"sequence"])
	{
		if(contentOfString)
		{
			mydenialOBJ.sequence=contentOfString;
			contentOfString=nil;
		}
		
	}
	else if([elementName isEqualToString:@"text"])
	{
		if(contentOfString)
		{
			mydenialOBJ.text=contentOfString;
			
			contentOfString=nil;
		}
		
	}
	else if([elementName isEqualToString:@"deniedOn"])
	{
		if(contentOfString)
		{
			mydenialOBJ.deniedOn=contentOfString;
			contentOfString=nil;
		}
	}
	else if([elementName isEqualToString:@"deniedBy"])
	{
		if(contentOfString)
		{
			mydenialOBJ.deniedBy=contentOfString;
			contentOfString=nil;
		}
	}
	else if([elementName isEqualToString:@"denialReasonList"])
	{
				
		;
	}
	else if([elementName isEqualToString:@"provider"])
	{
		if(contentOfString)
		{
			NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
			if([tempArr count]==2)
			{
				myclaimActivity.LBLprovider=[tempArr objectAtIndex:0];
				myclaimActivity.provider = [tempArr objectAtIndex:1];	
			}
			else {
				myclaimActivity.LBLprovider=@"";
				myclaimActivity.provider=contentOfString;
			}
			
			
			contentOfString=nil;
		}		
	}
	else if([elementName isEqualToString:@"paymentStatus"])
	{
		if(contentOfString)
		{
			NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
			if([tempArr count]==2)
			{
				myclaimActivity.LBLpaymentStatus=[tempArr objectAtIndex:0];
				myclaimActivity.paymentStatus= [tempArr objectAtIndex:1];	
			}
			else {
				myclaimActivity.LBLpaymentStatus=@"";
				myclaimActivity.paymentStatus=contentOfString;
			}
			
			
			contentOfString=nil;
		}		
	}
	else if([elementName isEqualToString:@"checkNo"])
	{
		if(contentOfString)
		{
			NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
			if([tempArr count]==2)
			{
				myclaimActivity.LBLcheckNo=[tempArr objectAtIndex:0];
				myclaimActivity.checkNo = [tempArr objectAtIndex:1];	
			}
			else {
				myclaimActivity.LBLcheckNo=@"";
				myclaimActivity.checkNo=contentOfString;
			}
			
			
			contentOfString=nil;
		}		
	}
	else if([elementName isEqualToString:@"paymentAmount"])
	{
		if(contentOfString)
		{
			NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
			if([tempArr count]==2)
			{
				myclaimActivity.LBLpaymentAmount=[tempArr objectAtIndex:0];
				myclaimActivity.paymentAmount = [tempArr objectAtIndex:1];	
			}
			else {
				myclaimActivity.LBLpaymentAmount=@"";
				myclaimActivity.paymentAmount=contentOfString;
			}
			
			
			contentOfString=nil;		
		}		
	}
	else if([elementName isEqualToString:@"paymentMethod"])
	{
		if(contentOfString)
		{
			NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
			if([tempArr count]==2)
			{
				myclaimActivity.LBLpaymentMethod=[tempArr objectAtIndex:0];
				myclaimActivity.paymentMethod = [tempArr objectAtIndex:1];	
			}
			else {
				myclaimActivity.LBLpaymentMethod=@"";
				myclaimActivity.paymentMethod=contentOfString;
			}
			
			
			contentOfString=nil;
		}		
	}
	else if([elementName isEqualToString:@"paymentDate"])
	{
		if(contentOfString)
		{
			NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
			if([tempArr count]==2)
			{
				myclaimActivity.LBLpaymentDate=[tempArr objectAtIndex:0];
				myclaimActivity.paymentDate = [tempArr objectAtIndex:1];	
			}
			else {
				myclaimActivity.LBLpaymentDate=@"";
				myclaimActivity.paymentDate=contentOfString;
			}
			
			
			contentOfString=nil;
		}		
	}
	else if([elementName isEqualToString:@"isPreTax"])
	{
		if(contentOfString)
		{
			NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
			if([tempArr count]==2)
			{
				myclaimActivity.LBLisPreTax=[tempArr objectAtIndex:0];
				myclaimActivity.isPreTax = [tempArr objectAtIndex:1];	
			}
			else {
				myclaimActivity.LBLisPreTax=@"";
				myclaimActivity.isPreTax=contentOfString;
			}
			
			
			contentOfString=nil;
		}		
	}
	else if([elementName isEqualToString:@"claimSubType"])
	{
		if(contentOfString)
		{
			NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
			if([tempArr count]==2)
			{
				myclaimActivity.LBLclaimSubType=[tempArr objectAtIndex:0];
				myclaimActivity.claimSubType = [tempArr objectAtIndex:1];	
			}
			else {
				myclaimActivity.LBLclaimSubType=@"";
				myclaimActivity.claimSubType=contentOfString;
			}
			
			
			contentOfString=nil;
		}		
	}
	else if([elementName isEqualToString:@"submitDate"])
	{
		if(contentOfString)
		{
			NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
			if([tempArr count]==2)
			{
				myclaimActivity.LBLsubmitDate=[tempArr objectAtIndex:0];
				myclaimActivity.submitDate = [tempArr objectAtIndex:1];	
			}
			else {
				myclaimActivity.LBLsubmitDate=@"";
				myclaimActivity.submitDate=contentOfString;
			}
			
			
			contentOfString=nil;
		}		
	}
	else if([elementName isEqualToString:@"passthruClaimDate"])
	{
		if(contentOfString)
		{
			NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
			if([tempArr count]==2)
			{
				myclaimActivity.LBLpassthruClaimDate=[tempArr objectAtIndex:0];
				myclaimActivity.passthruClaimDate = [tempArr objectAtIndex:1];	
			}
			else {
				myclaimActivity.LBLpassthruClaimDate=@"";
				myclaimActivity.passthruClaimDate=contentOfString;
			}
			
			
			contentOfString=nil;
		}		
	}
	
	
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
	if(contentOfString)
		[contentOfString appendString:string];
}

- (void)parserDidEndDocument:(NSXMLParser *)parse
{
	arrclaimActivity=arrItem;
	//NSLog(@"BIGARRAY==%@",arrclaimActivity);
	for(int i=0;i<[arrItem count];i++)
	{
		claimActivityOBJ *ticket=(claimActivityOBJ *)[arrItem objectAtIndex:i];
		
		/*denialReasonOBJ *den=(denialReasonOBJ *)[arrItem objectAtIndex:i];
		
		NSLog(@"Sequence:%@",den.sequence);
		NSLog(@"Text:%@",den.text);
		NSLog(@"DeniedOn:%@",den.deniedOn);
		NSLog(@"DeniedBy:%@",den.deniedBy);*/
		//NSLog(@"%@",ticket.claimID);
//		NSLog(@"%@",ticket.trxnID);
//		NSLog(@"%@",ticket.serviceDate);
//		NSLog(@"%@",ticket.LBLisPreTax);
		
		NSLog(@"-------------------------------");
		NSLog(@"LBLaccountType %@",ticket.LBLaccountType);
		NSLog(@"LBLamount %@",ticket.LBLamount);
		NSLog(@"LBLcheckNo %@",ticket.LBLcheckNo);
		NSLog(@"LBLclaimCategory %@",ticket.LBLclaimCategory);
		
		NSLog(@"LBLclaimID %@",ticket.LBLclaimID);
		NSLog(@"LBLclaimSubType %@",ticket.LBLclaimSubType);
		NSLog(@"LBLclaimType %@",ticket.LBLclaimType);
		NSLog(@"LBLisPreTax %@",ticket.LBLisPreTax);
		
		NSLog(@"LBLpaymentAmount %@",ticket.LBLpaymentAmount);
		NSLog(@"LBLpaymentDate %@",ticket.LBLpaymentDate);
		NSLog(@"LBLpaymentMethod %@",ticket.LBLpaymentMethod);
		NSLog(@"LBLpaymentStatus %@",ticket.LBLpaymentStatus);
		
		NSLog(@"LBLprovider %@",ticket.LBLprovider);
		NSLog(@"LBLserviceDate %@",ticket.LBLserviceDate);
		NSLog(@"LBLstatus %@",ticket.LBLstatus);
		NSLog(@"LBLsubmitDate %@",ticket.LBLsubmitDate);
		NSLog(@"LBLtrxnID %@",ticket.LBLtrxnID);
		NSLog(@"Status %@",ticket.status);
		NSLog(@"-----------------------------ooooooooooooooo");
	}
	
}	
+(NSMutableArray *)claimactivityArr
{
	if (arrclaimActivity) {
		
		return arrclaimActivity;
	}
	else {
		return nil;
	}
	
}
+(NSMutableArray *)geterror_arr
{
	if (errordetails) {
		
		return errordetails;
	}
	else {
		return nil;
	}
}
+(BOOL)gethasMoreRecords_claim
{
	if (hasMoreRecords_claim) {
		
		return hasMoreRecords_claim;
	}
	else {
		return NO;
	}
	
}


@end
