    //
//  SignIn.m
//  Acclaris
//
//  Created by Objectsol5 on 23/09/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "SignIn.h"
#import "AcclarisViewController.h"
#import "information.h"
#import "UserresponcePerser.h"
#import "passPerser.h"
#import "configurables.h"
#import "configurableParser.h"
#import "AddImage.h"

NSString *strpass;
NSString *displaystr;
@implementation SignIn

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/
+(NSString *)userPass
{
	if (strpass) {
		return strpass;
	}
	else {
		return nil;
	}
	
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	tools=[[MyTools alloc]init];
	loadingView=[tools createActivityIndicator1];

	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	my_arrUserinfo=[UserresponcePerser userdesc];
	
	UIImageView *imgv_Background = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 320, 460-43)];
	[imgv_Background setImage:[UIImage imageNamed: @"sign-in2-bg.png"]];
	[self.view addSubview:imgv_Background];
	
	NSMutableArray *arr_myconfig=[AcclarisViewController staticarr_config];//[configurableParser getconfig_arr];//
	con=(configurables *)[arr_myconfig objectAtIndex:0];
	
	NSData *data_btnimg=[Base64 decode:con.btnImgdata];//btn background image
	
	
	
	self.navigationController.navigationBar.tintColor=[UIColor colorWithRed:con.navbarRed/255.0f green:con.navbarGreen/255.0f blue:con.navbarBlue/255.0f alpha:1.0];
	self.view.backgroundColor = [UIColor colorWithRed:con.bgRed/255.0f green:con.bgGreen/255.0f blue:con.bgBlue/255.0f alpha:1.0];

	/////////adding rounded rect view///////////////////
	UIView	*view_rounded = [[UIView alloc]initWithFrame:CGRectMake(18, 14, 280, 386)];
	view_rounded.backgroundColor = [UIColor whiteColor];
	view_rounded.layer.cornerRadius=19;
	view_rounded.layer.borderWidth=0;
	view_rounded.backgroundColor=[UIColor whiteColor];//[UIColor colorWithRed:con.bgRed2/255.0f green:con.bgGreen2/255.0f blue:con.bgBlue2/255.0f alpha:1.0];
	[self.view addSubview:view_rounded];
	/////////adding rounded rect view///////////////////
	
	
	//---Adding a Custom Title to a UINavigationItem---
	UILabel	*lbl_title = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 170, 44)];
	lbl_title.textAlignment = UITextAlignmentCenter;
	lbl_title.font = [UIFont fontWithName:con.fontname size:30];
	lbl_title.backgroundColor = [UIColor clearColor];
	lbl_title.textColor = [UIColor colorWithRed:197/255.0f green:238/255.0f blue:253/255.0f alpha:1.0];
	lbl_title.text = @"";
	self.navigationItem.titleView = lbl_title;
	
		
	UILabel	*lbl_UserName = [[UILabel alloc]initWithFrame:CGRectMake(26, 106, 92, 21)];
	lbl_UserName.backgroundColor = [UIColor clearColor];
	lbl_UserName.font=[UIFont fontWithName:con.fontname size:con.fontsize];
	lbl_UserName.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
	lbl_UserName.text = [[[my_arrUserinfo objectAtIndex:2] componentsSeparatedByString:@"|"] objectAtIndex:0 ];
	[self.view addSubview:lbl_UserName];
	
	
	UILabel	*lbl_UserName_Value = [[UILabel alloc]initWithFrame:CGRectMake(126, 106, 161, 21)];
	lbl_UserName_Value.backgroundColor = [UIColor clearColor];
	lbl_UserName_Value.text = [ self formatString:[[[my_arrUserinfo objectAtIndex:2] componentsSeparatedByString:@"|"] objectAtIndex:1 ]];//[AcclarisViewController userName];  //------------------------------------<<STATIC METHOD CALLING>>
	lbl_UserName_Value.font=[UIFont fontWithName:con.fontname size:con.fontsize];
	lbl_UserName_Value.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
	[self.view addSubview:lbl_UserName_Value];
	
		
	UILabel	*lbl_Password = [[UILabel alloc]initWithFrame:CGRectMake(26, 140, 80, 21)];
	lbl_Password.backgroundColor = [UIColor clearColor];
	lbl_Password.font=[UIFont fontWithName:con.fontname size:con.fontsize];
	lbl_Password.text = @"Password";
	lbl_Password.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
	[self.view addSubview:lbl_Password];
	
	txtf_Password = [[UITextField alloc]initWithFrame:CGRectMake(126, 135, 151, 28)];
	txtf_Password.secureTextEntry = YES;
	txtf_Password.textColor = [UIColor blackColor];
	txtf_Password.borderStyle = UITextBorderStyleRoundedRect;
	txtf_Password.delegate=self;
	//txtf_Password.text=@"prabirmj";
	txtf_Password.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
	txtf_Password.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
	txtf_Password.font=[UIFont fontWithName:con.fontname size:con.fontsize];
	txtf_Password.keyboardAppearance=UIKeyboardAppearanceAlert;
	[self.view addSubview:txtf_Password];
	
	UIButton *btn_SignIn=[UIButton buttonWithType:UIButtonTypeCustom];
	btn_SignIn.frame = CGRectMake(43, 180, 234, 47);
	[btn_SignIn setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
	btn_SignIn.titleLabel.font = [UIFont fontWithName:con.btnfontname size:con.btnfontsize];
	[btn_SignIn setTitle:@"Sign In" forState:UIControlStateNormal];
	[btn_SignIn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn_SignIn addTarget:self action:@selector(btn_SignIn_Clicked) forControlEvents:UIControlEventTouchUpInside];
	[self.view addSubview:btn_SignIn];
	
	UIButton *btn_Forgot_Identifier=[UIButton buttonWithType:UIButtonTypeCustom];
	btn_Forgot_Identifier.frame = CGRectMake(43, 235, 234, 47);
	[btn_Forgot_Identifier setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
	btn_Forgot_Identifier.titleLabel.font = [UIFont fontWithName:con.btnfontname size:con.btnfontsize];
	[btn_Forgot_Identifier setTitle:@"Forgot your site identifier?" forState:UIControlStateNormal];
	[btn_Forgot_Identifier setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn_Forgot_Identifier addTarget:self action:@selector(btn_Forgot_Identifier_Clicked) forControlEvents:UIControlEventTouchUpInside];
	[self.view addSubview:btn_Forgot_Identifier];
	
	UIButton *btn_Incorrect_Identifier=[UIButton buttonWithType:UIButtonTypeCustom];
	btn_Incorrect_Identifier.frame = CGRectMake(43, 290, 234, 47);
	[btn_Incorrect_Identifier setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
	btn_Incorrect_Identifier.titleLabel.font = [UIFont fontWithName:con.btnfontname size:con.btnfontsize];
	[btn_Incorrect_Identifier setTitle:@"Showing incorrect site identifier?" forState:UIControlStateNormal];
	[btn_Incorrect_Identifier setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn_Incorrect_Identifier addTarget:self action:@selector(btn_Incorrect_Identifier_Clicked) forControlEvents:UIControlEventTouchUpInside];
	[self.view addSubview:btn_Incorrect_Identifier];
	
	UIButton *btn_Forgot_Password=[UIButton buttonWithType:UIButtonTypeCustom];
	btn_Forgot_Password.frame = CGRectMake(43, 345, 234, 47);
	[btn_Forgot_Password setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
	btn_Forgot_Password.titleLabel.font = [UIFont fontWithName:con.btnfontname size:con.btnfontsize];
	[btn_Forgot_Password setTitle:@"Forgot Password?" forState:UIControlStateNormal];
	[btn_Forgot_Password setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn_Forgot_Password addTarget:self action:@selector(btn_Forgot_Password_Clicked) forControlEvents:UIControlEventTouchUpInside];
	[self.view addSubview:btn_Forgot_Password];
	
	
	UIImageView * imgv_siteidentifier = [[[UIImageView alloc] initWithFrame:CGRectMake(109, 23, 101, 75)] autorelease];
	NSData *data=[Base64 decode:[my_arrUserinfo objectAtIndex:4]];
	imgv_siteidentifier.image=	[UIImage imageWithData:[NSData dataWithData:data]];
	[self.view addSubview:imgv_siteidentifier];
	
	
	
	
}
#pragma mark UrlDecoder
-(NSString *)UrlDecoder:(NSString *)url
{
	
	NSString *escaped = url ;
	escaped=[escaped stringByReplacingOccurrencesOfString:@"%26" withString:@"&"];
	escaped=[escaped stringByReplacingOccurrencesOfString:@"%2B" withString:@"+"];
	escaped=[escaped stringByReplacingOccurrencesOfString:@"%2C" withString:@","];
	escaped=[escaped stringByReplacingOccurrencesOfString:@"%2F" withString:@"/"];
	escaped=[escaped stringByReplacingOccurrencesOfString:@"%3A" withString:@":"];
	escaped=[escaped stringByReplacingOccurrencesOfString:@"%3B" withString:@";"];
	escaped=[escaped stringByReplacingOccurrencesOfString:@"%3D" withString:@"="];
	escaped=[escaped stringByReplacingOccurrencesOfString:@"%3F" withString:@"?"];
	escaped=[escaped stringByReplacingOccurrencesOfString:@"%40" withString:@"@"];
	escaped=[escaped stringByReplacingOccurrencesOfString:@"%20" withString:@" "];
	escaped=[escaped stringByReplacingOccurrencesOfString:@"%09" withString:@"\t"];
	escaped=[escaped stringByReplacingOccurrencesOfString:@"%23" withString:@"#"];
	escaped=[escaped stringByReplacingOccurrencesOfString:@"%3C" withString:@"<"];
	escaped=[escaped stringByReplacingOccurrencesOfString:@"%3E" withString:@">"];
	escaped=[escaped stringByReplacingOccurrencesOfString:@"%22" withString:@"\""];
	escaped=[escaped stringByReplacingOccurrencesOfString:@"%0A" withString:@"\n"];
	return escaped;
	
	
}

-(void)btn_SignIn_Clicked
{
	NSDictionary *customMessageList_dict=[[NSUserDefaults standardUserDefaults] objectForKey:@"customMessageList"];
	
	if ([txtf_Password.text length]==0)
	{
		
		NSString *strmessage=[[customMessageList_dict valueForKey:@"200042"]valueForKey:@"message"];
		NSString *strtype=[[customMessageList_dict valueForKey:@"200042"]valueForKey:@"type"];
		
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:strtype message:strmessage delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
		[alert show];
		[alert release];
		
	}
	else {
	[txtf_Password resignFirstResponder];
	strpass=txtf_Password.text;
		
	[tools startLoading:self.view childView:loadingView text:@"Verifying password. Wait…."];	
	request *r=[[request alloc] initWithTarget:self
								 SuccessAction:@selector(onSucceffulLogin)
								 FailureAction:@selector(onFailureLogin)];
	[r sendpassRequest:[AcclarisViewController userName] pass:txtf_Password.text];
	[r release];
	
	}
}
-(void)onSucceffulLogin
{
	[tools stopLoading:loadingView];
	NSMutableArray *userinfo_arr=[passPerser passresponce];
	if ([[userinfo_arr objectAtIndex:0]intValue]!=0)
	{
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Sorry" message:[userinfo_arr objectAtIndex:1] delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
		[alert show];
		[alert release];
	}
	else 		
	{
		NSMutableArray *userinfo_arr=[passPerser passresponce];
		[tools startLoading:self.view childView:loadingView text:@"Fetching Accounts. Wait…."];
		request *r=[[request alloc] initWithTarget:self
									 SuccessAction:@selector(onSucceffulLogin1)
									 FailureAction:@selector(onFailureLogin)];
		
		NSMutableDictionary *roleDict=[passPerser getRolebaseDict];
		if ([[roleDict objectForKey:@"ACCOUNT"] isEqualToString:@"Yes"]) {
			
			[r sendaccountRequest:[userinfo_arr objectAtIndex:2] userid:[userinfo_arr objectAtIndex:4]];
		}
			else if ([[roleDict objectForKey:@"CLAIM"] isEqualToString:@"Yes"]) {
				
				[self onSucceffulLogin1];
			}
				else if ([[roleDict objectForKey:@"MESSAGE"] isEqualToString:@"Yes"]) {
					
					[r sendticketRequest:@"0" participentid:[userinfo_arr objectAtIndex:2] userid:[userinfo_arr objectAtIndex:4]];
				}
					else if ([[roleDict objectForKey:@"RECEIPT"] isEqualToString:@"Yes"]) {
						
						[r req_alerts:[userinfo_arr objectAtIndex:2] userid:[userinfo_arr objectAtIndex:4] startid:@"0"];
					}
						else if ([[roleDict objectForKey:@"ALERT"] isEqualToString:@"Yes"]) {
							
							[r req_images:[userinfo_arr objectAtIndex:2] userid:[userinfo_arr objectAtIndex:4] startid:@"0"];
						}
		else {
			
			[tools stopLoading:loadingView];
			UIAlertView *alert= [[UIAlertView alloc] initWithTitle:@"Sorry" message:@"Nothing to display"
														  delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
			[alert show];    
			[alert release];
		}

		
		
		[r release];
		
	}
	
}

-(void)onFailureLogin
{
	[tools stopLoading:loadingView];	
	
}
-(void)onSucceffulLogin1
{
	[tools stopLoading:loadingView];
	[app createTabBar];
}

-(void)btn_Forgot_Identifier_Clicked
{
	displaystr=[my_arrUserinfo objectAtIndex:5] ;
	
	information *myinfo = [[information alloc] init];
	[self.navigationController pushViewController:myinfo animated:YES];
}
-(void)btn_Incorrect_Identifier_Clicked
{
	displaystr=[my_arrUserinfo objectAtIndex:6];
	
	information *myinfo = [[information alloc] init];
	[self.navigationController pushViewController:myinfo animated:YES];
}

-(void)btn_Forgot_Password_Clicked
{
	displaystr=[my_arrUserinfo objectAtIndex:7] ;
	
	information *myinfo = [[[information alloc] init]autorelease];
	[self.navigationController pushViewController:myinfo animated:YES];
	

	//SubmitNewClaimTwo *obj=[[[SubmitNewClaimTwo alloc]init]autorelease];
	//[self.navigationController pushViewController:obj animated:YES];

	
}
#pragma mark -
#pragma mark textfield deligate
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
	if(textField.frame.origin.y>=165)
	{
		UIView *ContainedView=[textField superview];
		CGRect rect=ContainedView.frame;
		[UIView beginAnimations:nil context:nil];
		[UIView setAnimationDuration:0.3];
		rect.origin.y-=(textField.frame.origin.y-165);
		ContainedView.frame=rect;
		[UIView commitAnimations];
	}
	return YES;
}

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField
{
	if((textField.frame.origin.y-165)>0)
	{
		UIView *ContainedView=[textField superview];
		CGRect rect=ContainedView.frame;
		[UIView beginAnimations:nil context:nil];
		[UIView setAnimationDuration:0.3];
		rect.origin.y+=(textField.frame.origin.y-165);
		ContainedView.frame=rect;
		[UIView commitAnimations];
	}
	return YES;
}

-(BOOL)textFieldShouldReturn:(UITextField *)theTextField 
{
	[theTextField  resignFirstResponder];
	return YES;
}
#pragma mark -

-(NSString *)formatString:(NSString *)Uname
{
	if ([Uname length]>0) {
		NSString *nottoMask=[Uname substringToIndex:[Uname length]-4];//
		NSString *formatedText=[nottoMask stringByAppendingString:@"****"];
		return formatedText;
	}
	else {
		return @"";
	}
	
}
- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}
+(NSString *)getString
{
	if (displaystr) {
		
		return displaystr;
	}
	else {
		return nil;
	}

}

@end
