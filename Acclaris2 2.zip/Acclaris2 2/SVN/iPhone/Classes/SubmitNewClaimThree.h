//
//  SubmitNewClaimThree.h
//  Acclaris
//
//  Created by Subhojit on 29/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyTools.h"
#import "Decode64.h"
#import "passPerser.h"
#import "AcclarisAppDelegate.h"
#import "RequestPhase2.h"
#import "UnsubmittedclaimOBJ.h"
#import "UnsubmittedClaimParser.h"
#import "EditClaim.h"
#import "SubmitclaimOBJ.h"
#import "SubmitclaimParser.h"
#import "Deleteparser.h"
#import "Aftersubmit.h"
@class configurables;


@interface SubmitNewClaimThree : UIViewController<UITableViewDelegate,UITableViewDataSource> {

	
	AcclarisAppDelegate *app;
	configurables *con;
	MyTools *tools;
	NSString *strFont;
	UITableView *table;
	UIView *loadingView;
	NSMutableArray *arrunsubmittedClaimwork;
	int Selectedrow;
	NSMutableArray *userinfo_arr;
	BOOL isback;
	NSMutableDictionary *roleDict;
	BOOL isbackfromselectpayee;
	
	NSString *strdeceide;
	
}
-(void)CreateConnection;
-(void)CreateView;
-(void)signout;
-(void)DeleteClaim;
@end
