//
//  AddImage.h
//  Acclaris
//
//  Created by Subhojit on 24/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyScrollView.h"
#import "QuartzCore/QuartzCore.h"
#import "SelectedImageBig.h"
#import "MyTools.h"
#import "Decode64.h"
@class configurables;

@interface AddImage : UIViewController<UIScrollViewDelegate,UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate> {

	configurables *con;
	MyTools *tools;
	UIView *loadingView;
	MyScrollView *scroll;
	NSData *dataImage;
	
	//NSMutableArray *arrImageIndex;

	//NSMutableArray *arr;
	NSNumber *newImageTag;
	int Tag;
	int rowSelected;

	NSInteger Imageno;
	NSInteger noOfFail;
	
	
}
-(id)initWithindex:(int)row;
-(void)CreateView;
-(void)captureImage;
- (void)PickImageForIndex;
-(void)saveImage:(UIImage *)image;
- (UIImage*)scaleAndRotateImage:(UIImage *)image;
-(void)getImage;
-(void)albumDetails;
-(void)createPage;
-(void)Clickdelete;
-(void)imageTapped:(id)sender;
-(void)signout;
+(NSMutableArray *)getImageDataArr;
-(void)UploadPhoto;
@end
