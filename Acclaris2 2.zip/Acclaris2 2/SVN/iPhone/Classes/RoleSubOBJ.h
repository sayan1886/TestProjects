//
//  RoleSubOBJ.h
//  Acclaris
//
//  Created by Subhojit on 22/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface RoleSubOBJ : NSObject {

	NSString *strsubName;
	NSString *strsubDisplayseq;
	NSString *strsublabel;
	NSString *displayable;
	
}
@property(nonatomic,retain)NSString *strsubName;
@property(nonatomic,retain)NSString *strsubDisplayseq;
@property(nonatomic,retain)NSString *strsublabel;
@property(nonatomic,retain)NSString *displayable;
@end
