//
//  ticketTypeOBJ.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 08/11/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface ticketTypeOBJ : NSObject {

	NSString *category;
	NSString *label;
	NSString *note;
	
}
@property(nonatomic,retain)NSString *category;
@property(nonatomic,retain)NSString *label;
@property(nonatomic,retain)NSString *note;
@end
