//
//  imagePerser.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 07/12/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
@class imagesOBJ;
@class errorcodeOBJ;
#import "ShowImageDetailsOBJ.h"
@interface imagePerser : NSObject<NSXMLParserDelegate> {
	
	NSMutableString *contentOfString;
	imagesOBJ *myimagesOBJ;
	
	ShowImageDetailsOBJ *obj;
	errorcodeOBJ *myerrorcodeOBJ;
}
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error;
+(NSMutableArray *)imageARRresponce;
+(NSMutableArray *)geterror_arr;
+(BOOL)gethasMoreRecords_image;
@end
