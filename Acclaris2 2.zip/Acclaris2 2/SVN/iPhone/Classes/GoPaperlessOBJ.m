//
//  GoPaperlessOBJ.m
//  Acclaris
//
//  Created by Subhojit on 11/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "GoPaperlessOBJ.h"


@implementation GoPaperlessOBJ
@synthesize strreturnCode,strerrorText,streeID,strSSN,strerCode,strstatus,streeName,strerName,stradmnID,stradmnName,strbegins,strends,stremail,strisAchValid,strachActNo,strachRoutingNo,strachStatus,strachActType,stremailReqForAch,strdob,strdobReqForAch;
@end
