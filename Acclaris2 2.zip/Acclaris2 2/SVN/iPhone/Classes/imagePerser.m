//
//  imagePerser.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 07/12/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import "imagePerser.h"
#import "imagesOBJ.h"
#import "errorcodeOBJ.h"
NSMutableArray *errordetails;
NSMutableArray *arrImages;
BOOL hasMoreRecords_image;
@implementation imagePerser
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error
{
	
	NSXMLParser *parser;
	parser = [[NSXMLParser alloc] initWithData:data];
    [parser setDelegate:self];
	[parser setShouldProcessNamespaces:NO];
    [parser setShouldReportNamespacePrefixes:NO];
    [parser setShouldResolveExternalEntities:NO];
    [parser parse];
    NSError *parseError = [parser parserError];
    if (parseError && error) 
	{
        *error = parseError;
    }
	[parser release];
}

-(void)parserDidStartDocument:(NSXMLParser *)parser
{
	arrImages=[[NSMutableArray alloc]init];
	errordetails=[[NSMutableArray alloc]init];
	myerrorcodeOBJ=[[errorcodeOBJ alloc]init];
}		

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
	if (qName)
	{
		elementName = qName;
	}
	
	else 
		if([elementName isEqualToString:@"returnCode"])
		{
			contentOfString=[NSMutableString string];
			[contentOfString retain];
			return;		
			
		}
		else 
			if([elementName isEqualToString:@"errorText"])
			{
				contentOfString=[NSMutableString string];
				[contentOfString retain];
				return;		
				
			}
			else 
				if([elementName isEqualToString:@"hasMoreRecords"])
				{
					contentOfString=[NSMutableString string];
					[contentOfString retain];
					return;		
					
				}
	
			else 
				if([elementName isEqualToString:@"receipt"])
				{
					myimagesOBJ=[[imagesOBJ alloc]init];
					
					myimagesOBJ.arrshowimageDetail=[[NSMutableArray alloc]init];
					
					return;		
					
				}
				else 
					if([elementName isEqualToString:@"receiptDate"])
					{
						contentOfString=[NSMutableString string];
						[contentOfString retain];
						return;		
						
					}
					else 
						if([elementName isEqualToString:@"accountShortName"])
						{
							contentOfString=[NSMutableString string];
							[contentOfString retain];
							return;		
							
						}
						else 
							if([elementName isEqualToString:@"receiptStatus"])
							{
								contentOfString=[NSMutableString string];
								[contentOfString retain];
								return;		
								
							}
							else 
								if([elementName isEqualToString:@"receiptPurpose"])
								{
									contentOfString=[NSMutableString string];
									[contentOfString retain];
									return;		
									
								}
								else 
									if([elementName isEqualToString:@"receiptID"])
									{
										contentOfString=[NSMutableString string];
										[contentOfString retain];
										return;		
										
									}
	
									else 
										if([elementName isEqualToString:@"receiptImageDtls"])
										{
													
											obj=[[ShowImageDetailsOBJ alloc]init];
										}
										else 
											if([elementName isEqualToString:@"fileID"])
											{
												contentOfString=[NSMutableString string];
												[contentOfString retain];
												return;		
												
											}
											else 
												if([elementName isEqualToString:@"fileType"])
												{
													contentOfString=[NSMutableString string];
													[contentOfString retain];
													return;		
													
												}
												else 
													if([elementName isEqualToString:@"filePath"])
													{
														contentOfString=[NSMutableString string];
														[contentOfString retain];
														return;		
														
													}
													else 
														if([elementName isEqualToString:@"fileSize"])
														{
															contentOfString=[NSMutableString string];
															[contentOfString retain];
															return;		
															
														}
														else 
															if([elementName isEqualToString:@"fileReceivedOn"])
															{
																contentOfString=[NSMutableString string];
																[contentOfString retain];
																return;		
																
															}
															else 
																if([elementName isEqualToString:@"OrigFileName"])
																{
																	contentOfString=[NSMutableString string];
																	[contentOfString retain];
																	return;		
																	
																}
	}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName     
{	
	if (qName)
	{
        elementName = qName;
		
    }
	
	else 
		if([elementName isEqualToString:@"returnCode"])
		{
			if(contentOfString)
			{
				myerrorcodeOBJ.returnCode=contentOfString;
				[contentOfString release];
				contentOfString = nil;
				
				
			}	
			
		}
		else 
			if([elementName isEqualToString:@"errorText"])
			{
				if(contentOfString)
				{
					myerrorcodeOBJ.errorText=contentOfString;
					[errordetails addObject:myerrorcodeOBJ];
					[contentOfString release];
					contentOfString = nil;
					
					
				}		
				
			}
			else 
				if([elementName isEqualToString:@"hasMoreRecords"])
				{
					if(contentOfString)
					{
						if ([contentOfString isEqualToString:@"Yes"])
						{
							hasMoreRecords_image=YES;
						}
						else {
							hasMoreRecords_image=NO;	
						}
						
					}		
					
				}
	
			else 
				if([elementName isEqualToString:@"receipt"])
				{
					
					if(myimagesOBJ)
					{
						
						[arrImages addObject:myimagesOBJ];
						[myimagesOBJ release],myimagesOBJ=nil;
						
					}
										
					
				}
	
			else 
				if([elementName isEqualToString:@"receiptDate"])
				{
					if(contentOfString)
					{
						NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
						if ([tempArr count]>1) {
							myimagesOBJ.receiptDate=[tempArr objectAtIndex:1];
							myimagesOBJ.LBLreceiptDate=[tempArr objectAtIndex:0];
						}
						
						[contentOfString release];
						contentOfString = nil;
						
						
					}		
					
				}
				else 
					if([elementName isEqualToString:@"accountShortName"])
					{
						if(contentOfString)
						{
							NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
							if ([tempArr count]>1) {
								myimagesOBJ.accountShortName=[tempArr objectAtIndex:1];
								myimagesOBJ.LBLaccountShortName=[tempArr objectAtIndex:0];
							}
							
							[contentOfString release];
							contentOfString = nil;
							
						}	
						
					}
					else 
						if([elementName isEqualToString:@"receiptStatus"])
						{
							if(contentOfString)
							{
								NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
								if ([tempArr count]>1) {
									myimagesOBJ.receiptStatus=[tempArr objectAtIndex:1];
									myimagesOBJ.LBLreceiptStatus=[tempArr objectAtIndex:0];
								}
								
								[contentOfString release];
								contentOfString = nil;
								
								
							}	
							
						}
						else 
							if([elementName isEqualToString:@"receiptPurpose"])
							{
								if(contentOfString)
								{
									NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
									if ([tempArr count]>1) {
										myimagesOBJ.receiptPurpose=[tempArr objectAtIndex:1];
										myimagesOBJ.LBLreceiptPurpose=[tempArr objectAtIndex:0];
									}
									
									[contentOfString release];
									contentOfString = nil;
									
									
								}	
								
							}
							else 
								if([elementName isEqualToString:@"receiptID"])
								{
									if(contentOfString)
									{
										NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
										if ([tempArr count]>1) {
											myimagesOBJ.receiptID=[tempArr objectAtIndex:1];
											myimagesOBJ.LBLreceiptID=[tempArr objectAtIndex:0];
										}
										
										[contentOfString release];
										contentOfString = nil;
										
										
									}	
									
								}
	
								else 
									if([elementName isEqualToString:@"fileID"])
									{
										if(contentOfString)
										{
											obj.strfileID=contentOfString;
											[contentOfString release];
											contentOfString = nil;
										
											
										}		
										
									}
								else 
									 if([elementName isEqualToString:@"fileType"])
									{
										if(contentOfString)
										{
											obj.strfileType=contentOfString;
											[contentOfString release];
											contentOfString = nil;
											
											
										}		
										
									}
								
								
								else 
									if([elementName isEqualToString:@"filePath"])
									{
										if(contentOfString)
										{
											obj.strfilePath=contentOfString;
											[contentOfString release];
											contentOfString = nil;
											
											
										}		
										
									}
									else 
										if([elementName isEqualToString:@"fileSize"])
										{
											if(contentOfString)
											{
												obj.strfileSize=contentOfString;
												[contentOfString release];
												contentOfString = nil;
												
												
											}		
											
										}
										else 
											if([elementName isEqualToString:@"fileReceivedOn"])
											{
												if(contentOfString)
												{
													obj.strfileReceivedOn=contentOfString;
													[contentOfString release];
													contentOfString = nil;
													
													
												}		
												
											}
											else 
												if([elementName isEqualToString:@"OrigFileName"])
												{
													if(contentOfString)
													{
														obj.strOrigFileName=contentOfString;
														[contentOfString release];
														contentOfString = nil;
														
														
													}		
													
												}
												else 
													if([elementName isEqualToString:@"receiptImageDtls"])
													{
														if(obj)
														{
															
															[myimagesOBJ.arrshowimageDetail addObject:obj];
															[obj release];
															obj = nil;
															
															
														}		
														
													}
	
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
	if(contentOfString)
		[contentOfString appendString:string];
}

- (void)parserDidEndDocument:(NSXMLParser *)parse
{
	NSLog(@"**********%@",arrImages);
	
	NSLog(@" >>>>>>>>>%d",[myimagesOBJ.arrshowimageDetail count]);
}	
+(NSMutableArray *)imageARRresponce
{
	if (arrImages) {
		
		return arrImages;
	}
	else {
		return nil;
	}
	
}

+(NSMutableArray *)geterror_arr
{
	if (errordetails) {
		
		return errordetails;
	}
	else {
		return nil;
	}
	
}
+(BOOL)gethasMoreRecords_image
{
	if (hasMoreRecords_image) {
		
		return hasMoreRecords_image;
	}
	else {
		return NO;
	}
	
}


@end
