//
//  UnsubmittedclaimOBJ.h
//  Acclaris
//
//  Created by Subhojit on 01/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface UnsubmittedclaimOBJ : NSObject {

	
	NSString *strclaimid;
	NSString *streeID;
	NSString *stractpCD;
	NSString *strClaimCategory;
	NSString *strClaimType;
	NSString *strClaimAmt;
	NSString *strserviceBegins;
	NSString *strserviceEnds;
	NSString *strnote;
	NSString *strprevYearPlanInd;
	NSString *strpayeeID;
	NSString *strpaymentRef;
	NSString *strinvoiceNo;
	NSString *strcustomerNo;
	NSString *strproviderID;
	NSString *strproviderName;
	NSString *strelctID;
	NSString *straccountNo;
	NSString *strdpndtID;
	NSString *strreference;
	NSString *strrefNo;
	NSString *strtrxnID;
	NSString *strdescription;
	NSString *strreceiptMethod;
	NSString *strclaimBatchType;
	NSString *strforceReview;
	NSString *strhsaRealtimeBalance;
	NSString *strpayType;
}
@property(nonatomic,retain) NSString *strclaimid;
@property(nonatomic,retain) NSString *streeID;
@property(nonatomic,retain) NSString *stractpCD;
@property(nonatomic,retain) NSString *strpayType;
@property(nonatomic,retain) NSString *strClaimCategory;
@property(nonatomic,retain) NSString *strClaimType;
@property(nonatomic,retain) NSString *strClaimAmt;
@property(nonatomic,retain) NSString *strserviceBegins;
@property(nonatomic,retain) NSString *strserviceEnds;
@property(nonatomic,retain) NSString *strnote;
@property(nonatomic,retain) NSString *strprevYearPlanInd;
@property(nonatomic,retain) NSString *strpayeeID;
@property(nonatomic,retain) NSString *strpaymentRef;
@property(nonatomic,retain) NSString *strinvoiceNo;
@property(nonatomic,retain) NSString *strcustomerNo;
@property(nonatomic,retain) NSString *strproviderID;
@property(nonatomic,retain) NSString *strproviderName;
@property(nonatomic,retain) NSString *strelctID;
@property(nonatomic,retain) NSString *straccountNo;
@property(nonatomic,retain) NSString *strdpndtID;
@property(nonatomic,retain) NSString *strreference;
@property(nonatomic,retain) NSString *strrefNo;
@property(nonatomic,retain) NSString *strtrxnID;
@property(nonatomic,retain) NSString *strdescription;
@property(nonatomic,retain) NSString *strreceiptMethod;
@property(nonatomic,retain) NSString *strclaimBatchType;
@property(nonatomic,retain) NSString *strforceReview;
@property(nonatomic,retain) NSString *strhsaRealtimeBalance;
@end
