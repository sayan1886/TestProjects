//
//  ticketDescDetails.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 26/10/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AcclarisAppDelegate.h"
@class ticketOBJ;
@class ticket;
@class configurables;

@interface ticketDescDetails : UIViewController<UITableViewDelegate,UITableViewDataSource> {
	
	AcclarisAppDelegate *app;
	NSMutableArray *arr_celltytle;
	NSInteger selectedRow;
	NSArray *ticketTableArrlabel;
	NSArray *ticketTableArr;
	ticketOBJ *tickets;
	NSMutableArray *arrm_ticketLOGS;
	configurables *con;
}
-(void)signoutbt;
-(void)createtableview;
-(NSInteger)calculateLine:(NSString*)str fname:(NSString *)fontName fsize:(NSInteger)fontSize widthGiven:(NSInteger)allowedWidth;
@end
