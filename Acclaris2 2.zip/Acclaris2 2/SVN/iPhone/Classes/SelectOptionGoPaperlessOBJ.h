//
//  SelectOptionGoPaperlessOBJ.h
//  Acclaris
//
//  Created by Subhojit on 12/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface SelectOptionGoPaperlessOBJ : NSObject {

	NSString *strSublabel;
	NSString *strsSubvalue;
	NSString *strsubSelected;
	
}

@property(nonatomic,retain)NSString *strSublabel;
@property(nonatomic,retain)NSString *strsSubvalue;
@property(nonatomic,retain)	NSString *strsubSelected;
@end
