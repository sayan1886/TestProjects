//
//  accPerser.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 06/10/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import "accPerser.h"
#import "AccountsOBJ.h"
#import "electionOBJ.h"
#import "errorcodeOBJ.h"
NSMutableArray *arr_accounts;
NSMutableArray *errordetails;
@implementation accPerser

-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error
{

	arr_accounts = [[NSMutableArray alloc]init];
	NSXMLParser *parser;
	parser = [[NSXMLParser alloc] initWithData:data];
    [parser setDelegate:self];
	[parser setShouldProcessNamespaces:NO];
    [parser setShouldReportNamespacePrefixes:NO];
    [parser setShouldResolveExternalEntities:NO];
    [parser parse];
    NSError *parseError = [parser parserError];
    if (parseError && error) 
	{
        *error = parseError;
    }
	[parser release];
}

-(void)parserDidStartDocument:(NSXMLParser *)parser
{
	myerrorcodeOBJ=[[errorcodeOBJ alloc]init];
	errordetails=[[NSMutableArray alloc]init];
		
}		

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
	if (qName)
	{
		elementName = qName;
	}
	else 
		if([elementName isEqualToString:@"returnCode"])
		{
			
			contentOfString=[NSMutableString string];
			[contentOfString retain];
			return;		
			
		}
		else 
			if([elementName isEqualToString:@"errorText"])
			{
				
				contentOfString=[NSMutableString string];
				[contentOfString retain];
				return;		
				
			}
	
	
		else 
			if([elementName isEqualToString:@"account"])
			{
				myAccountsOBJ = [[AccountsOBJ alloc]init];
				myAccountsOBJ.elections=[[NSMutableArray alloc]init];
				return;		
		
				
			}
			else 
				if([elementName isEqualToString:@"accountTypeCode"])
				{
					contentOfString=[NSMutableString string];
					[contentOfString retain];
					return;		
					
				}
				else 
					if([elementName isEqualToString:@"accountDisplaySeq"])
					{
						contentOfString=[NSMutableString string];
						[contentOfString retain];
						return;		
						
					}
					else 
						if([elementName isEqualToString:@"accountShortName"])
						{
							contentOfString=[NSMutableString string];
							[contentOfString retain];
							return;	
							
						}
						else 
							if([elementName isEqualToString:@"accountDisplayName"])
							{
								contentOfString=[NSMutableString string];
								[contentOfString retain];
								return;	
								
							}
						else 
							if([elementName isEqualToString:@"balanceRelevant"])
							{
								contentOfString=[NSMutableString string];
								[contentOfString retain];
								return;		
								
							}
							else 
								if([elementName isEqualToString:@"investmentRelevant"])
								{
									contentOfString=[NSMutableString string];
									[contentOfString retain];
									return;		
									
								}
								else 
									if([elementName isEqualToString:@"electionListCount"])
									{
										contentOfString=[NSMutableString string];
										[contentOfString retain];
										return;		
										
									}
									else 
										if([elementName isEqualToString:@"planPeriodType"])
										{
											contentOfString=[NSMutableString string];
											[contentOfString retain];
											return;		
											
										}
									else 
										if([elementName isEqualToString:@"election"])
										{
											
											myelectionOBJ = [[electionOBJ alloc]init];
											return;			
											
										}
										else 
											if([elementName isEqualToString:@"electionID"])
											{
												contentOfString=[NSMutableString string];
												[contentOfString retain];
												return;		
												
											}
											else 
												if([elementName isEqualToString:@"planYearType"])
												{
													contentOfString=[NSMutableString string];
													[contentOfString retain];
													return;		
													
												}
												else 
													if([elementName isEqualToString:@"planPeriod"])
													{
														contentOfString=[NSMutableString string];
														[contentOfString retain];
														return;		
														
													}
													else 
														if([elementName isEqualToString:@"endDate"])
														{
															contentOfString=[NSMutableString string];
															[contentOfString retain];
															return;		
															
														}
														else 
															if([elementName isEqualToString:@"graceEndDate"])
															{
																contentOfString=[NSMutableString string];
																[contentOfString retain];
																return;		
																
															}
															else 
																if([elementName isEqualToString:@"runOutEndDate"])
																{
																	contentOfString=[NSMutableString string];
																	[contentOfString retain];
																	return;		
																	
																}
																else 
																	if([elementName isEqualToString:@"futureGraceEndDate"])
																	{
																		contentOfString=[NSMutableString string];
																		[contentOfString retain];
																		return;		
																		
																	}
																	else 
																		if([elementName isEqualToString:@"currentBalance"])
																		{
																			contentOfString=[NSMutableString string];
																			[contentOfString retain];
																			return;		
																			
																		}
	if([elementName isEqualToString:@"investmentBalance"])
	{
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
		
	}
	if([elementName isEqualToString:@"beginDate"])
	{
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
		
	}
	if([elementName isEqualToString:@"enrollmentStatus"])
	{
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
		
	}
	if([elementName isEqualToString:@"manageContribLink"])
	{
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
		
	}
	
		
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName     
{	
	if (qName)
	{
        elementName = qName;
		
    }
	else 
		if([elementName isEqualToString:@"returnCode"])
		{
			if(contentOfString)
			{
				myerrorcodeOBJ.returnCode=contentOfString;
				[contentOfString release];
				contentOfString = nil;
				
				
			}	
			
		}
		else 
			if([elementName isEqualToString:@"errorText"])
			{
				if(contentOfString)
				{
					myerrorcodeOBJ.errorText=contentOfString;
					[errordetails addObject:myerrorcodeOBJ];
					[contentOfString release];
					contentOfString = nil;
					
					
				}		
				
			}
	
	
		else 
			if([elementName isEqualToString:@"account"])
			{
				
					[arr_accounts addObject:myAccountsOBJ];
					[myAccountsOBJ release];
					 myAccountsOBJ = nil;
									
			}
			else 
				if([elementName isEqualToString:@"accountTypeCode"])
				{
					if(contentOfString)
					{
						NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
						myAccountsOBJ.accountTypeCode = [arrlocal1 objectAtIndex:1];	
						[contentOfString release];
						contentOfString=nil;

						
						
					}		
					
				}
				else 
					if([elementName isEqualToString:@"accountDisplaySeq"])
					{
						if(contentOfString)
						{
							NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
							myAccountsOBJ.accountDisplaySeq = [arrlocal1 objectAtIndex:1];
							[contentOfString release];
							contentOfString=nil;
							
							
						}	
						
					}
					else 
						if([elementName isEqualToString:@"accountShortName"])
						{
							if(contentOfString)
							{
								NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
								myAccountsOBJ.accountShortName= [arrlocal1 objectAtIndex:1];
								[contentOfString release];
								contentOfString=nil;
								
							}	
							
						}
						else 
							if([elementName isEqualToString:@"accountDisplayName"])
							{
								if(contentOfString)
								{
									
									NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
									myAccountsOBJ.accountDisplayName = [arrlocal1 objectAtIndex:1];
									[contentOfString release];
									contentOfString=nil;
									
									
								}	
								
							}
						else 
							if([elementName isEqualToString:@"balanceRelevant"])
							{
								if(contentOfString)
								{
									NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
									myAccountsOBJ.balanceRelevant= [arrlocal1 objectAtIndex:1];
									[contentOfString release];
									contentOfString=nil;
									
									
								}		
								
							}
							else 
								if([elementName isEqualToString:@"investmentRelevant"])
								{
									if(contentOfString)
									{
										NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
										myAccountsOBJ.investmentRelevant= [arrlocal1 objectAtIndex:1];
										[contentOfString release];
										contentOfString=nil;										
										
									}	
									
								}
								else 
									if([elementName isEqualToString:@"electionListCount"])
									{
										if(contentOfString)
										{
										
											myAccountsOBJ.electionListCount	= contentOfString;	
											[contentOfString release];
											contentOfString=nil;
																						
										}	
										
									}
									else 
										if([elementName isEqualToString:@"planPeriodType"])
										{
											if(contentOfString)
											{
												NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
												myAccountsOBJ.planPeriodType= [arrlocal1 objectAtIndex:1];	
												[contentOfString release];
												contentOfString=nil;
												
											}	
											
										}
	
									else 
										if([elementName isEqualToString:@"election"])
										{
											
												//NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
												[myAccountsOBJ.elections addObject:myelectionOBJ];
												[myelectionOBJ release];
												myelectionOBJ = nil;
												
												
												
											
										}
										else 
											if([elementName isEqualToString:@"electionID"])
											{
												if(contentOfString)
												{
													NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
													//NSRange r;
//													r.location=0;
//													r.length=[@"Election ID" length] + 2;
//													[contentOfString deleteCharactersInRange:r];
													myelectionOBJ.electionID=[arrlocal1 objectAtIndex:1];//contentOfString;
													[contentOfString release];
													contentOfString = nil;
													
													
												}	
												
											}
											else 
												if([elementName isEqualToString:@"planYearType"])
												{
													if(contentOfString)
													{
														NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
														myelectionOBJ.planYearType=[arrlocal1 objectAtIndex:1];
														[contentOfString release];
														contentOfString = nil;
														
														
														
													}	
													
												}
												else 
													if([elementName isEqualToString:@"planPeriod"])
													{
														if(contentOfString)
														{
															NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
															myelectionOBJ.planPeriod=[arrlocal1 objectAtIndex:1];
															[contentOfString release];
															contentOfString = nil;
															
															
														}		
														
													}
													else 
														if([elementName isEqualToString:@"endDate"])
														{
															if(contentOfString)
															{
																NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
																myelectionOBJ.endDate=[arrlocal1 objectAtIndex:1];
																[contentOfString release];
																contentOfString = nil;
																
																
															}	
															
														}
														else 
															if([elementName isEqualToString:@"graceEndDate"])
															{
																if(contentOfString)
																{
																	NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
																	myelectionOBJ.graceEndDate=[arrlocal1 objectAtIndex:1];
																	[contentOfString release];
																	contentOfString = nil;
																	
																	
																	
																}	
																
															}
															else 
																if([elementName isEqualToString:@"runOutEndDate"])
																{
																	if(contentOfString)
																	{
																		NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
																		myelectionOBJ.runOutEndDate=[arrlocal1 objectAtIndex:1];
																		[contentOfString release];
																		contentOfString = nil;
																		
																		
																		
																	}	
																	
																}
																else 
																	if([elementName isEqualToString:@"futureGraceEndDate"])
																	{
																		if(contentOfString)
																		{
																			NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
																			myelectionOBJ.futureGraceEndDate=[arrlocal1 objectAtIndex:1];
																			[contentOfString release];
																			contentOfString = nil;																			
																			
																		}		
																		
																	}
																	else 
																		if([elementName isEqualToString:@"currentBalance"])
																		{
																			if(contentOfString)
																			{
																				NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
																				myelectionOBJ.currentBalance=[arrlocal1 objectAtIndex:1];
																				[contentOfString release];
																				contentOfString = nil;
																				
																				
																			}	
																			
																		}
																		else 
																			if([elementName isEqualToString:@"investmentBalance"])
																			{
																				if(contentOfString)
																				{
																					NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
																					myelectionOBJ.investmentBalance=[arrlocal1 objectAtIndex:1];
																					[contentOfString release];
																					contentOfString = nil;																					
																					
																					
																				}	
																				
																			}
																			else 
																				if([elementName isEqualToString:@"beginDate"])
																				{
																					if(contentOfString)
																					{
																						NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
																						myelectionOBJ.beginDate=[arrlocal1 objectAtIndex:1];
																						[myelectionOBJ.electionID retain];
																						[contentOfString release];
																						contentOfString = nil;																						
																						
																						
																					}	
																					
																				}
																				else 
																					if([elementName isEqualToString:@"enrollmentStatus"])
																					{
																						if(contentOfString)
																						{
																							NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
																							myelectionOBJ.enrollmentStatus=[arrlocal1 objectAtIndex:1];
																							[myelectionOBJ.electionID retain];
																							[contentOfString release];
																							contentOfString = nil;																						
																							
																							
																						}	
																						
																					}
																					else 
																						if([elementName isEqualToString:@"manageContribLink"])
																						{
																							if(contentOfString)
																							{
																								NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
																								myAccountsOBJ.manageContribLink=[arrlocal1 objectAtIndex:1];
																								myAccountsOBJ.lblmanageContribLink=[arrlocal1 objectAtIndex:0];
																								[contentOfString release];
																								contentOfString = nil;																						
																								
																								
																							}	
																							
																						}
	
	
	
	
	
	
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
	if(contentOfString)
		[contentOfString appendString:string];
}

- (void)parserDidEndDocument:(NSXMLParser *)parse
{
	for(int i=0;i<[arr_accounts count];i++)
	{
		AccountsOBJ *ticket=(AccountsOBJ *)[arr_accounts objectAtIndex:i];
		NSLog(@"%@",ticket.accountDisplayName);
		NSLog(@"%@",ticket.accountTypeCode);
		for(int j=0;j<[ticket.elections count];j++)
		{
			electionOBJ *ticketlogs=(electionOBJ *)[ticket.elections objectAtIndex:j];
			NSLog(@"-----");
			NSLog(@"electionID  %@",ticketlogs.electionID);
		}
		
		NSLog(@"\n\n\n\n\n-------------------------------");
	}
	[arr_accounts retain];
}
+(NSMutableArray *)getAccounts_arr
{
	if (arr_accounts) {
		
		return arr_accounts;
	}
	else {
		return nil;
	}
	
}
+(NSMutableArray *)geterror_arr
{
	if (errordetails) {
		
		return errordetails;
	}
	else {
		return nil;
	}
	
}


@end
