    //
//  claim.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 06/10/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import "claim.h"
#import "claimActivity.h"
#import "configurables.h"
#import "claimPassthru.h"
#import "UserresponcePerser.h"
#import "Decode64.h"
#import "configurableParser.h"
#import "AcclarisViewController.h"

@implementation claim

@synthesize name;

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/
-(id)initWithTabBar:(NSString *)label
{
	if([self init])
	{
		//this is the label on tab button itself
		self.title=label;
		
		self.tabBarItem.image=[UIImage imageNamed:@"Claims.png"];
		self.name = [[NSString stringWithString:@"SAYAN"] retain];
		
	}
	return self;
}


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	tools=[[MyTools alloc]init];
	loadingView=[tools createActivityIndicator1];

	NSMutableArray *arr_myconfig=[AcclarisViewController staticarr_config];//[configurableParser getconfig_arr];//
	con=(configurables *)[arr_myconfig objectAtIndex:0];
	
	self.navigationController.navigationBar.tintColor=[UIColor colorWithRed:con.navbarRed/255.0f green:con.navbarGreen/255.0f blue:con.navbarBlue/255.0f alpha:1.0];
	self.view.backgroundColor = [UIColor colorWithRed:con.bgRed/255.0f green:con.bgGreen/255.0f blue:con.bgBlue/255.0f alpha:1.0];
	self.navigationItem.title=@"Back";
	
	//NSMutableArray *my_arrUserinfo=[UserresponcePerser userdesc];
	UIImageView *logo_img = [[UIImageView alloc]initWithFrame:CGRectMake(0, 2, 170, 40)];
	NSData *data=[Base64 decode:con.logoImgdata];
	logo_img.image=	[UIImage imageWithData:[NSData dataWithData:data]];
	self.navigationItem.titleView=logo_img;
	
	self.navigationItem.hidesBackButton = YES;
	
	NSMutableDictionary *roleDict=[passPerser getRolebaseDict];
	arr_celltytle=[[NSMutableArray alloc]init];
	
	if ([[roleDict valueForKey:@"CLMACTIVITY"]isEqualToString:@"Yes"]) {
		[arr_celltytle addObject:@"CLMACTIVITY"];
		[arr_celltytle addObject:[roleDict valueForKey:@"CLMACTIVITYLabel"]];
	}
	if ([[roleDict valueForKey:@"CLMPENDINGPASSTHRU"]isEqualToString:@"Yes"]) {
		[arr_celltytle addObject:@"CLMPENDINGPASSTHRU"];
		[arr_celltytle addObject:[roleDict valueForKey:@"CLMPENDINGPASSTHRULabel"]];
	}
	if ([[roleDict valueForKey:@"ONLNCLAIM"]isEqualToString:@"Yes"]) {
		[arr_celltytle addObject:@"ONLNCLAIM"];
		[arr_celltytle addObject:[roleDict valueForKey:@"ONLNCLAIMLabel"]];
	}
	if ([[roleDict valueForKey:@"SHOW_RECPT_REQUIRED_CLAIMS"]isEqualToString:@"Yes"]) {
		[arr_celltytle addObject:@"SHOW_RECPT_REQUIRED_CLAIMS"];
		[arr_celltytle addObject:[roleDict valueForKey:@"SHOW_RECPT_REQUIRED_CLAIMSLabel"]];
	}

	[self signoutbt];
	[self createtableview];
	
}
-(void)signoutbt
{
	UIBarButtonItem *signoutButton = [[UIBarButtonItem alloc]
									  initWithTitle:@"Sign Off"
									  style:UIBarButtonItemStyleBordered
									  target:self
									  action:@selector(signout)];
	self.navigationItem.rightBarButtonItem =signoutButton;
}

-(void)signout
{
	[((AcclarisAppDelegate *)[[UIApplication sharedApplication] delegate]) removeTabBar];
}
-(void)createtableview
{
	UITableView	*acctable=[[UITableView alloc] initWithFrame:CGRectMake(0,10,320,300) style:UITableViewStyleGrouped];
	acctable.delegate = self;
	acctable.dataSource = self;
	acctable.scrollEnabled = YES;
	acctable.autoresizesSubviews = YES;
	acctable.showsVerticalScrollIndicator=YES;
	acctable.showsHorizontalScrollIndicator=YES;
	acctable.backgroundColor=[UIColor clearColor];
	[self.view addSubview:acctable];	
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView  
{
	return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	
	return [arr_celltytle  count]/2;
	
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{  
	static NSString *CellIdentifier = @"Cell";
	static NSString *CellIdentifier1 = @"Cell1";
	UITableViewCell *cell;
	
	if(cell==nil)
	{
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier] autorelease];
	}
	else
	{
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier1];
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier1] autorelease];
		
	}
	cell.selectionStyle=UITableViewCellSelectionStyleNone;
	cell.backgroundColor=[UIColor whiteColor];
	
	cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;		
	
	UILabel *cellLabelText=[[UILabel alloc]initWithFrame:CGRectMake(19,17,250,20)];
	NSString *strFont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];
	cellLabelText.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
	cellLabelText.textColor =[UIColor colorWithRed:con.linkgnRed/255.0 green:con.linkgnGreen/255.0 blue:con.linkgnBlue/255.0 alpha:1.0];
	cellLabelText.backgroundColor=[UIColor clearColor];
	cellLabelText.text = [arr_celltytle objectAtIndex:indexPath.row*2+1];
	[cell.contentView addSubview:cellLabelText];
	
	
	return cell;
	
	
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return 55;
	
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	
	NSString *apiName=[arr_celltytle objectAtIndex:(indexPath.row*2)];
	
	if([apiName isEqualToString:@"CLMACTIVITY"])
	{
		NSArray *arr_recpt=[[NSArray alloc]initWithObjects:@"",@"",nil];
		claimActivity *myclaimActivity = [[claimActivity alloc] initWithArrayName:arr_recpt];
		[self.navigationController pushViewController:myclaimActivity animated:YES];
	}
	if([apiName isEqualToString:@"CLMPENDINGPASSTHRU"])
	{
		claimPassthru *myclaimPassthru = [[claimPassthru alloc] init];
		[self.navigationController pushViewController:myclaimPassthru animated:YES];
	}
	if([apiName isEqualToString:@"ONLNCLAIM"]) 
	{
		NSMutableArray *userinfo_arr=[passPerser passresponce];
		
		
		
		RequestPhase2 *objrequestPhase2=[[RequestPhase2 alloc] initWithTarget:self
									 SuccessAction:@selector(onSucceffulLogin)
									 FailureAction:@selector(onFailureLogin)];
		
		[objrequestPhase2 GetOnlnClaimCtrgyTypeMAService:[userinfo_arr objectAtIndex:2] uID:[userinfo_arr objectAtIndex:4] ];
		
		[objrequestPhase2 release];
		
		[tools startLoading:self.view childView:loadingView text:@"Loading your Claim activity. Wait…."];
		
	}
	if([apiName isEqualToString:@"SHOW_RECPT_REQUIRED_CLAIMS"])
	{
		NSArray *arr_recpt=[[NSArray alloc]initWithObjects:@"Yes",@"Online",nil];
		claimActivity *myclaimActivity = [[claimActivity alloc] initWithArrayName:arr_recpt];
		[self.navigationController pushViewController:myclaimActivity animated:YES];
		
	}
}
-(void)onSucceffulLogin
{
	[tools stopLoading:loadingView];
	
	arrDecide=[ClaimSubmitNewParser getarrm_passArray];
	
	if([[arrDecide objectAtIndex:3]isEqualToString:@"Yes"])
	{
				
		
		SubmitNewClaimThree *obj=[[[SubmitNewClaimThree alloc]init]autorelease];
		[self.navigationController pushViewController:obj animated:YES];
	
		
	}
	else if([[arrDecide objectAtIndex:3]isEqualToString:@"No"])
	{
		
		SubmitNewClaimone *obj=[[[SubmitNewClaimone alloc]init]autorelease];
		[self.navigationController pushViewController:obj animated:YES];
	}

	else {
		;
	}
	
}
-(void)onFailureLogin
{
	
	
	
}
-(void)viewWillAppear:(BOOL)animated
{
	
	
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
