    //
//  SubmitNewClaimThree.m
//  Acclaris
//
//  Created by Subhojit on 29/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "SubmitNewClaimThree.h"
#import "configurables.h"
#import "AcclarisViewController.h"
#import "SubmitNewClaimone.h"


@implementation SubmitNewClaimThree

- (void)viewDidLoad {
    [super viewDidLoad];
	

	self.navigationItem.hidesBackButton=YES;
	
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	tools=[[MyTools alloc]init];
	loadingView=[tools createActivityIndicator1];
	
	NSMutableArray *arr_myconfig=[AcclarisViewController staticarr_config];
	con=(configurables *)[arr_myconfig objectAtIndex:0];
	
	self.navigationController.navigationBar.tintColor=[UIColor colorWithRed:con.navbarRed/255.0f green:con.navbarGreen/255.0f blue:con.navbarBlue/255.0f alpha:1.0];
	
	self.view.backgroundColor = [UIColor colorWithRed:con.bgRed/255.0f green:con.bgGreen/255.0f blue:con.bgBlue/255.0f alpha:1.0];
	UIImageView *logo_img = [[UIImageView alloc]initWithFrame:CGRectMake(0, 2, 170, 40)];
	NSData *data=[Base64 decode:con.logoImgdata];
	logo_img.image=	[UIImage imageWithData:[NSData dataWithData:data]];
	self.navigationItem.titleView=logo_img;
	
	
	
	
	UIBarButtonItem *signoutButton = [[UIBarButtonItem alloc]
									  initWithTitle:@"Sign Off"
									  style:UIBarButtonItemStyleBordered
									  target:self
									  action:@selector(signout)];
    self.navigationItem.rightBarButtonItem =signoutButton;
	


	[self CreateConnection];
	
}
-(void)signout
{
	[((AcclarisAppDelegate *)[[UIApplication sharedApplication] delegate]) removeTabBar];
}
-(void)CreateConnection
{
	
	
		userinfo_arr=[passPerser passresponce];
		
		RequestPhase2 *objrequestPhase2=[[RequestPhase2 alloc] initWithTarget:self
																SuccessAction:@selector(onSuccesful)
																FailureAction:@selector(onFailure)];

		[objrequestPhase2 GetUnSubmittedClaim:[userinfo_arr objectAtIndex:2] uID:[userinfo_arr objectAtIndex:4] noOfRecord:@"10" startAftersid:@"0"];

		[objrequestPhase2 release];

		[tools startLoading:self.view childView:loadingView text:@"Loading your Claim activity. Wait…."];
	
}


-(void)onSuccesful
{
	
	[tools stopLoading:loadingView];
	
	arrunsubmittedClaimwork=[UnsubmittedClaimParser getarrgetunsubmittedClaim];
	//isback=[EditClaim getback];
	if([app.checkclassname isEqualToString:@"Selectpayee"])
	{
	   [self CreateView];
		
		
	}
	else if([strdeceide isEqualToString:@"Edit claim"])
	{
			
		[table reloadData];
		//isbackfromselectpayee=NO;
		
	}

	else 
	{
	  [self CreateView];
	}
}
-(void)onFailure
{
	
	[tools stopLoading:loadingView];
	
}

-(void)CreateView
{
	
	roleDict=[passPerser getRolebaseDict];
	NSData *data_btnimg=[Base64 decode:con.btnImgdata];
	strFont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];
	
	UIView *HeaderView=[[[UIView alloc]initWithFrame:CGRectMake(0, 0, 320, 50)]autorelease];
	HeaderView.backgroundColor=[UIColor colorWithRed:con.bgRed2/255.0 green:con.bgGreen2/255.0 blue:con.bgBlue2/255.0 alpha:1.0];
	[self.view addSubview:HeaderView];
	
	NSString *strViewTitle=@"Manage";
	strViewTitle=[strViewTitle stringByAppendingFormat:@"%@",@" Claims"];
	
	UILabel *lbltext=[[UILabel alloc]initWithFrame:CGRectMake(10, 2, 250, 40)];
	lbltext.text=strViewTitle;
	lbltext.backgroundColor=[UIColor clearColor];
	lbltext.textColor=[UIColor whiteColor];
	lbltext.numberOfLines=0;
	lbltext.font=[UIFont fontWithName:strFont size:con.headerImpfntsize];
	[HeaderView addSubview:lbltext];
	[lbltext release],lbltext=nil;
	
	
	NSDictionary *customMessageList_dict=[[NSUserDefaults standardUserDefaults] objectForKey:@"customMessageList"];
	
	
	NSString *strDesc=[[customMessageList_dict valueForKey:@"200076"]valueForKey:@"message"];
	
	UILabel *lblDesc=[[UILabel alloc]initWithFrame:CGRectMake(10, 62, 300, 55)];
	lblDesc.text=strDesc;
	lblDesc.backgroundColor=[UIColor clearColor];
	lblDesc.numberOfLines=0;
	lblDesc.font=[UIFont fontWithName:@"Helvetica"size:13];
	[self.view  addSubview:lblDesc];
	[lblDesc release],lblDesc=nil; 
	
	
		
	
	table=[[UITableView alloc]initWithFrame:CGRectMake(0, 135, 320, 175) style:UITableViewStylePlain];
	table.backgroundColor = [UIColor whiteColor];
	table.bounces = YES;
	table.delegate=self;
	table.dataSource=self;
	table.separatorColor=[UIColor blackColor];
	[self.view addSubview:table];
	
	
	
	if ([[roleDict valueForKey:@"ADD_MORECLAIM_IN_ONLN_CLAIM"]isEqualToString:@"Yes"])
	{
		UIButton *btnEnter=[UIButton buttonWithType:UIButtonTypeCustom];
		btnEnter.frame=CGRectMake(10, 315, 140, 40);
		[btnEnter setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
		[btnEnter setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
		 btnEnter.titleLabel.font = [UIFont fontWithName:con.btnfontname size:con.btnfontsize];
		[btnEnter setTitle:@"Enter another claim" forState:UIControlStateNormal];
		[btnEnter addTarget:self action:@selector(ClickbtnEnter) forControlEvents:UIControlEventTouchUpInside];					 
		[self.view addSubview:btnEnter];
		
	}
	else 
	{
		
		;
	}

		
	
	UIButton *btnSubmit=[UIButton buttonWithType:UIButtonTypeCustom];
	btnSubmit.frame=CGRectMake(170, 315, 140, 40);
	[btnSubmit setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
	[btnSubmit setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	btnSubmit.titleLabel.font = [UIFont fontWithName:con.btnfontname size:con.btnfontsize];
	[btnSubmit setTitle:@"Submit" forState:UIControlStateNormal];
	[btnSubmit addTarget:self action:@selector(ClickbtnSubmit) forControlEvents:UIControlEventTouchUpInside];					 
	[self.view addSubview:btnSubmit];
	
	
	
}
-(void)ClickbtnEnter
{
	
	
	SubmitNewClaimone *obj=[[SubmitNewClaimone alloc]init];
	[self.navigationController pushViewController:obj animated:YES];
	[obj release],obj=nil;
	
	
	
}
-(void)ClickbtnSubmit
{

	//isbackfromaftersubmit=YES;
	//NSMutableArray *userinfo_arr=[passPerser passresponce];
	
	RequestPhase2 *objrequestPhase2=[[RequestPhase2 alloc] initWithTarget:self
															SuccessAction:@selector(onSuccesfulsubmit)
															FailureAction:@selector(onFailuresubmit)];
	
	[objrequestPhase2 SubmitallClaim:[userinfo_arr objectAtIndex:2] uID:[userinfo_arr objectAtIndex:4]];
	
	[objrequestPhase2 release];
	
	[tools startLoading:self.view childView:loadingView text:@"Loading your Claim activity. Wait…."];
	
}
-(void)onSuccesfulsubmit
{
	
	[tools stopLoading:loadingView];
	
	
		
	NSString *strErrortext=[SubmitclaimParser getErrortxt];
	
	
	
	if(strErrortext.length > 0)
		
	{
		
		
		UIAlertView *alertview=[[UIAlertView alloc]initWithTitle:@"Info" message:strErrortext delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		alertview.delegate=self;
		[alertview show];
		[alertview release],alertview=nil;
	}
	else 
	{
		
		Aftersubmit *obj=[[[Aftersubmit alloc]init]autorelease];
		[self.navigationController pushViewController:obj animated:YES];
	}

	
	
}
-(void)onFailuresubmit
{
	
	[tools stopLoading:loadingView];
	
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
	
	return  50.0;
	
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section;
{

	
	NSString *Headerfont=@"";
	Headerfont=[Headerfont stringByAppendingString:con.fontname];
	Headerfont=[Headerfont stringByAppendingString:@"-Bold"];
	
	 UIView *secondView=[[UIView alloc]initWithFrame:CGRectMake(0,125, 320, 50)];
	 secondView.backgroundColor=[UIColor colorWithRed:con.bgRed2/255.0 green:con.bgGreen2/255.0 blue:con.bgBlue2/255.0 alpha:1.0];
	 
	 
	 NSString *strViewTitlesecond=@"Service";
	 strViewTitlesecond=[strViewTitlesecond stringByAppendingFormat:@"%@",@" Date"];
	 
	 UILabel *lbltextsecond=[[UILabel alloc]initWithFrame:CGRectMake(10,-3, 210, 35)];
	 lbltextsecond.text=strViewTitlesecond;
	 lbltextsecond.backgroundColor=[UIColor clearColor];
	 lbltextsecond.textColor=[UIColor whiteColor];
	 lbltextsecond.numberOfLines=0;
	 lbltextsecond.font=[UIFont fontWithName:Headerfont size:con.headerImpfntsize];
	 [secondView addSubview:lbltextsecond];
	 [lbltextsecond release],lbltextsecond=nil;
	
	
	
	UILabel *lblAccount=[[UILabel alloc]initWithFrame:CGRectMake(10, 25, 210, 25)];
	lblAccount.text=@"Account";
	lblAccount.backgroundColor=[UIColor clearColor];
	lblAccount.textColor=[UIColor whiteColor];
	lblAccount.numberOfLines=0;
	lblAccount.font=[UIFont fontWithName:Headerfont size:con.bodyfntsize];
	[secondView addSubview:lblAccount];
	[lblAccount release],lblAccount=nil;
	
	
	
	
	UILabel *lblAmount=[[UILabel alloc]initWithFrame:CGRectMake(212, 2, 210, 25)];
	lblAmount.text=@"Account";
	lblAmount.backgroundColor=[UIColor clearColor];
	lblAmount.textColor=[UIColor whiteColor];
	lblAmount.numberOfLines=0;
	lblAmount.font=[UIFont fontWithName:Headerfont size:con.headerImpfntsize];
	[secondView addSubview:lblAmount];
	[lblAmount release],lblAmount=nil;
	
	
	UILabel *lblCatagory=[[UILabel alloc]initWithFrame:CGRectMake(212, 25, 210, 25)];
	lblCatagory.text=@"Category";
	lblCatagory.backgroundColor=[UIColor clearColor];
	lblCatagory.textColor=[UIColor whiteColor];
	lblCatagory.numberOfLines=0;
	lblCatagory.font=[UIFont fontWithName:Headerfont size:con.bodyfntsize];
	[secondView addSubview:lblCatagory];
	[lblCatagory release],lblCatagory=nil;
	
	/*CGSize sizeHeader=[strHeader sizeWithFont:[UIFont fontWithName:Headerfont  size:con.headerImpfntsize]
	 constrainedToSize:CGSizeMake(250, 100) 
	 lineBreakMode:UILineBreakModeWordWrap];
	 if(sizeHeader.width>200)
	 {
	 secheader.frame=CGRectMake(0, 0, 320, 44);
	 headertitlelebel.frame=CGRectMake(9, 1, 180, 40);
	 headertitlelebel.numberOfLines=0;
	 }*/
	
	
	return [secondView autorelease];
	
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView  
{
	 return 1;
	
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	NSLog(@"%d",[arrunsubmittedClaimwork count]);
	
	 return [arrunsubmittedClaimwork count];
	
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{  
	static NSString *CellIdentifier = @"Cell";
	static NSString *CellIdentifier1 = @"Cell1";
	UITableViewCell *cell;
	
	if(cell==nil)
	{
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier] autorelease];
	}
	else
	{
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier1];
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier1] autorelease];
		
	}
	cell.selectionStyle=UITableViewCellSelectionStyleNone;
	cell.backgroundColor=[UIColor whiteColor];
	
	
	//cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;	
	
	strFont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];
	
	UILabel *cellLabelDate=[[UILabel alloc]initWithFrame:CGRectMake(10,2,250,25)];
	cellLabelDate.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
	cellLabelDate.textColor =[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
	cellLabelDate.backgroundColor=[UIColor clearColor];
	cellLabelDate.text = ((UnsubmittedclaimOBJ *)[arrunsubmittedClaimwork objectAtIndex:indexPath.row]).strserviceBegins;
	[cell.contentView addSubview:cellLabelDate];
	[cellLabelDate release],cellLabelDate=nil; 
	
	
	
	UILabel *cellLabelAmt=[[UILabel alloc]initWithFrame:CGRectMake(210,2,250,25)];
	cellLabelAmt.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
	cellLabelAmt.textColor =[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
	cellLabelAmt.backgroundColor=[UIColor clearColor];
	NSString *str=@"$";
	str=[str stringByAppendingFormat:@"%@",((UnsubmittedclaimOBJ *)[arrunsubmittedClaimwork objectAtIndex:indexPath.row]).strClaimAmt];
	cellLabelAmt.text =str; 
	[cell.contentView addSubview:cellLabelAmt];
	[cellLabelAmt release],cellLabelAmt=nil;
	
	
	
	UILabel *cellLabelactpCD=[[UILabel alloc]initWithFrame:CGRectMake(10,27,250,25)];
	cellLabelactpCD.font=[UIFont fontWithName:con.fontname size:con.bodyfntsize];
	cellLabelactpCD.textColor =[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
	cellLabelactpCD.backgroundColor=[UIColor clearColor];
	cellLabelactpCD.text =((UnsubmittedclaimOBJ *)[arrunsubmittedClaimwork objectAtIndex:indexPath.row]).stractpCD; 
	[cell.contentView addSubview:cellLabelactpCD];
	[cellLabelactpCD release],cellLabelactpCD=nil;
	
	
	UILabel *cellLabelclaimtype=[[UILabel alloc]initWithFrame:CGRectMake(210,27,250,25)];
	cellLabelclaimtype.font=[UIFont fontWithName:con.fontname size:con.bodyfntsize];
	cellLabelclaimtype.textColor =[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
	cellLabelclaimtype.backgroundColor=[UIColor clearColor];
	cellLabelclaimtype.text =((UnsubmittedclaimOBJ *)[arrunsubmittedClaimwork objectAtIndex:indexPath.row]).strClaimType; 
	[cell.contentView addSubview:cellLabelclaimtype];
	[cellLabelclaimtype release],cellLabelclaimtype=nil;
	
	
	
	if ([[roleDict valueForKey:@"EDIT_PROVIDER_IN_ONLINE"]isEqualToString:@"Yes"])
	{
	
	UIButton *btnEdit=[UIButton buttonWithType:UIButtonTypeCustom];
	btnEdit.frame=CGRectMake(265, 8, 25, 24);
	btnEdit.tag=indexPath.row;
	[btnEdit setBackgroundImage:[UIImage imageNamed:@"icon1.png"] forState:UIControlStateNormal];
	[btnEdit addTarget:self action:@selector(ClickbtnEdit:) forControlEvents:UIControlEventTouchUpInside];					 
	[cell.contentView addSubview:btnEdit];
		
		
	}
	
	if ([[roleDict valueForKey:@"DELETE_PROVIDER_IN_ONLINE"]isEqualToString:@"Yes"]) {
	
	UIButton *btncross=[UIButton buttonWithType:UIButtonTypeCustom];
	btncross.tag=indexPath.row;
	btncross.frame=CGRectMake(289, 8, 25, 24);
	[btncross setBackgroundImage:[UIImage imageNamed:@"icon2.png"] forState:UIControlStateNormal];
	[btncross addTarget:self action:@selector(Clickbtncross:) forControlEvents:UIControlEventTouchUpInside];					 
	[cell.contentView addSubview:btncross];
	
	}

		
	return cell;
	
	
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return 62.5;
	
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	
	
	
}	
-(void)ClickbtnEdit:(id)sender
{

	UIButton *btn=(UIButton *)sender;
	Selectedrow=btn.tag;

	EditClaim *obj=[[EditClaim alloc]initWithrow:Selectedrow target:self action:@selector(CreateConnection)];
	[self.navigationController pushViewController:obj animated:YES];
	[obj release],obj=nil;
	
					
	
	
}
-(void)Clickbtncross:(id)sender
{
	UIButton *btn=(UIButton *)sender;
	Selectedrow=btn.tag;
	
	NSDictionary *customMessageList_dict=[[NSUserDefaults standardUserDefaults] objectForKey:@"customMessageList"];
	
	
	NSString *strmessage=[[customMessageList_dict valueForKey:@"200063"]valueForKey:@"message"];
	
	
	NSString *strtype=[[customMessageList_dict valueForKey:@"200063"]valueForKey:@"type"];
	
	
	UIAlertView *alertview=[[UIAlertView alloc]initWithTitle:strtype message:strmessage delegate:self cancelButtonTitle:@"No" otherButtonTitles:@"Yes",nil];
	alertview.delegate=self;
	[alertview show];
	[alertview release],alertview=nil;
	
	

}

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	
	if(buttonIndex==1)
	{
		
		[self DeleteClaim];
	}
}
-(void)DeleteClaim
{
	
	
	RequestPhase2 *objrequestPhase2=[[RequestPhase2 alloc] initWithTarget:self
															SuccessAction:@selector(onSuccesfuldelete)
															FailureAction:@selector(onFailuredelete)];
	
	[objrequestPhase2 deleteClaim:[userinfo_arr objectAtIndex:2] uID:[userinfo_arr objectAtIndex:4] Claimid:((UnsubmittedclaimOBJ *)[arrunsubmittedClaimwork objectAtIndex:Selectedrow]).strclaimid ];
	
	[objrequestPhase2 release];
	
	[tools startLoading:self.view childView:loadingView text:@"Loading your Claim activity. Wait…."];
	[arrunsubmittedClaimwork removeObjectAtIndex:Selectedrow];
	
	
}
-(void)onSuccesfuldelete
{
	
	[tools stopLoading:loadingView];
	
	NSString *strErrortext=[Deleteparser getErrortxt];
	
	if(strErrortext.length > 0)
		
	{
		UIAlertView *alertview=[[UIAlertView alloc]initWithTitle:@"Info" message:strErrortext delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		alertview.delegate=self;
		[alertview show];
		[alertview release],alertview=nil;
	}
	
	else 
	{
		
		/*UIAlertView *alertview=[[UIAlertView alloc]initWithTitle:@"Info" message:@"Claim deleted successfully" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
		alertview.delegate=self;
		[alertview show];
		[alertview release],alertview=nil;*/
		
		
		[table reloadData];
		
	}
	
	
}
-(void)onFailuredelete
{
	
	
	[tools stopLoading:loadingView];

}
-(void)viewWillAppear:(BOOL)animated
{

	/*if(isbackfromaftersubmit==YES)
	{
		
		[self CreateConnection];
	}
	else 
	{
		;	
	}*/
	
	
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	
    [super dealloc];
}


@end
