    //
//  claimActivity.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 09/11/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import "claimActivity.h"
#import "request.h"
#import "claimactivityPerser.h"
#import "claimActivityOBJ.h"
#import "claimActivityDetails.h"
#import "passPerser.h"
#import "UserresponcePerser.h"
#import "Decode64.h"
#import "configurableParser.h"
#import "configurables.h"
#import "AcclarisViewController.h"
#import "claim.h"
NSInteger selectedclaimrow;
@implementation claimActivity

-(id)initWithArrayName:(NSArray *)arr
{
	self=[super init];
	arr_recpt=[[NSMutableArray alloc]init];
	arr_recpt=arr;
	return self;
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	NSMutableArray *arr_myconfig=[AcclarisViewController staticarr_config];//[configurableParser getconfig_arr];//
	con=(configurables *)[arr_myconfig objectAtIndex:0];
	
	self.view.backgroundColor = [UIColor colorWithRed:con.bgRed/255.0f green:con.bgGreen/255.0f blue:con.bgBlue/255.0f alpha:1.0];
    self.navigationItem.title=@"Back";
	tools=[[MyTools alloc]init];
	loadingView=[tools createActivityIndicator1];
	
	
	//NSMutableArray *my_arrUserinfo=[UserresponcePerser userdesc];
	
	UIImageView *logo_img = [[UIImageView alloc]initWithFrame:CGRectMake(0, 2, 170, 40)];
	NSData *data=[Base64 decode:con.logoImgdata];
	logo_img.image=	[UIImage imageWithData:[NSData dataWithData:data]];
	self.navigationItem.titleView=logo_img;
	
	[self signoutbt];
	
	
	UIButton *btn_back=[UIButton buttonWithType:UIButtonTypeCustom];
	btn_back.frame = CGRectMake(70, 308, 234-50, 47);
	NSData *data_btnimg=[Base64 decode:con.btnImgdata];
	[btn_back setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
	btn_back.titleLabel.font = [UIFont fontWithName:con.btnfontname size:15];
	[btn_back setTitle:@"Back to Claims" forState:UIControlStateNormal];
	[btn_back setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn_back addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
	[self.view addSubview:btn_back];
	
	
	/*bt_previous=[UIButton buttonWithType:UIButtonTypeCustom];
	bt_previous.frame = CGRectMake(0, 308+25, 70, 30);
	[bt_previous setBackgroundImage:[UIImage imageNamed: @"green-button.png"] forState:UIControlStateNormal];
	bt_previous.titleLabel.font = [UIFont fontWithName:con.btnfontname size:con.btnfontsize];
	[bt_previous setTitle:@"previous" forState:UIControlStateNormal];
	[bt_previous setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	[bt_previous addTarget:self action:@selector(previous) forControlEvents:UIControlEventTouchUpInside];
	//bt_previous.enabled=NO;
	bt_previous.hidden=YES;
	[self.view addSubview:bt_previous];
	
    bt_next=[UIButton buttonWithType:UIButtonTypeCustom];
    bt_next.frame = CGRectMake(320-70,308+25, 70, 30);
    [bt_next setBackgroundImage:[UIImage imageNamed: @"green-button.png"] forState:UIControlStateNormal];
	bt_next.titleLabel.font = [UIFont fontWithName:con.btnfontname size:con.btnfontsize];
    [bt_next setTitle:@"next" forState:UIControlStateNormal];
    [bt_next setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	[bt_next addTarget:self action:@selector(next) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:bt_next];
	bt_next.hidden=YES;*/
	
	bt_previous=[UIButton buttonWithType:UIButtonTypeCustom];
	data_btnimg=[Base64 decode:con.btnNavImgData];
	bt_previous.frame = CGRectMake(0, 308, 50, 30);
	[bt_previous setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
	bt_previous.titleLabel.font = [UIFont fontWithName:con.btnNavFontName size:con.btnNavFontSize];
	[bt_previous setTitle:@"<<" forState:UIControlStateNormal];
	[bt_previous setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	[bt_previous addTarget:self action:@selector(previous) forControlEvents:UIControlEventTouchUpInside];
	//bt_previous.enabled=NO;
	bt_previous.hidden=YES;
	[self.view addSubview:bt_previous];
	
    bt_next=[UIButton buttonWithType:UIButtonTypeCustom];
    bt_next.frame = CGRectMake(320-50,308, 50, 30);
    [bt_next setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
	bt_next.titleLabel.font = [UIFont fontWithName:con.btnNavFontName size:con.btnNavFontSize];
    [bt_next setTitle:@">>" forState:UIControlStateNormal];
    [bt_next setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	[bt_next addTarget:self action:@selector(next) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:bt_next];
	bt_next.hidden=YES;
	
	str_startID1=@"0";
	
	
	
	[self claimActivityReq];
	[self createHeader];
	
	
	
	
}
-(void)previous
{
	if (startID<=0)
	{
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Sorry" message:@"No Previous Records" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
		[alert show];
		[alert release];
		startID=0;
		return ;
	}
	if (startID<=5)
	{
		//bt_previous.enabled=NO;
		bt_previous.hidden=YES;
	}
	
	startID-=5;
	str_startID1=@"";
	str_startID1=[str_startID1 stringByAppendingFormat:@"%d",startID];
	[str_startID1 retain];
	[acctable removeFromSuperview];
	//bt_next.enabled=YES;
	bt_next.hidden=NO;
	[self claimActivityReq];;
	
}
-(void)next
{
	startID+=5;
	str_startID1=@"";
	str_startID1=[str_startID1 stringByAppendingFormat:@"%d",startID];
	[str_startID1 retain];
	[acctable removeFromSuperview];
	//bt_previous.enabled=YES;
	bt_previous.hidden=NO;
	[self claimActivityReq];
}

-(void)createHeader
{
	
	UIView *vw=[[UIView alloc]initWithFrame:CGRectMake(10, 0,300,75)];
	vw.backgroundColor=[UIColor colorWithRed:con.bgRed2/255.0 green:con.bgGreen2/255.0 blue:con.bgBlue2/255.0 alpha:1.0];
	[self.view addSubview:vw];
	
	       NSString *strFont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];
	
			UILabel *Labelclaimdate=[[UILabel alloc]initWithFrame:CGRectMake(5,3,120,20)];
			Labelclaimdate.font=[UIFont fontWithName:strFont size:con.headerImpfntsize];
			Labelclaimdate.backgroundColor=[UIColor clearColor];
			Labelclaimdate.text =@"Claim Date";
			Labelclaimdate.textColor=[UIColor whiteColor];
			[vw addSubview:Labelclaimdate];
			[Labelclaimdate release];
			
			UILabel *LabelAccount=[[UILabel alloc]initWithFrame:CGRectMake(5,26,120,20)];
			LabelAccount.font=[UIFont fontWithName:con.fontname size:con.headerfntsize];
			LabelAccount.backgroundColor=[UIColor clearColor];
			LabelAccount.text = @"Account";
			LabelAccount.textColor=[UIColor whiteColor];
			[vw addSubview:LabelAccount];
			[LabelAccount release];
			
			UILabel *Labeltype=[[UILabel alloc]initWithFrame:CGRectMake(5,49,120,20)];
			Labeltype.font=[UIFont fontWithName:con.fontname size:con.headerfntsize];
			Labeltype.backgroundColor=[UIColor clearColor];
			Labeltype.text = @"Type";
			Labeltype.textColor=[UIColor whiteColor];
			[vw addSubview:Labeltype];
			[Labeltype release];
			
			/////////////////////////////////////////////
			
			UILabel *LabelAmmount=[[UILabel alloc]initWithFrame:CGRectMake(150,3,145,20)];
			LabelAmmount.font=[UIFont fontWithName:strFont size:con.headerImpfntsize];
			LabelAmmount.backgroundColor=[UIColor clearColor];
			LabelAmmount.text = @"Amount";
			LabelAmmount.textColor=[UIColor whiteColor];
			LabelAmmount.textAlignment=UITextAlignmentRight;
			[vw addSubview:LabelAmmount];
			[LabelAmmount release];
			
			
			UILabel *LabelCatagory=[[UILabel alloc]initWithFrame:CGRectMake(150,26,145,20)];
			LabelCatagory.font=[UIFont fontWithName:con.fontname size:con.headerfntsize];
			LabelCatagory.backgroundColor=[UIColor clearColor];
			LabelCatagory.text = @"Category";
			LabelCatagory.textColor=[UIColor whiteColor];
			LabelCatagory.textAlignment=UITextAlignmentRight;
			[vw addSubview:LabelCatagory];
			[LabelCatagory release];
			
			
			UILabel *LabelStatus=[[UILabel alloc]initWithFrame:CGRectMake(150,49,145,20)];
			LabelStatus.font=[UIFont fontWithName:con.fontname size:con.headerfntsize];
			LabelStatus.backgroundColor=[UIColor clearColor];
			LabelStatus.text = @"Status";
			LabelStatus.textColor=[UIColor whiteColor];
			LabelStatus.textAlignment=UITextAlignmentRight;
			[vw addSubview:LabelStatus];
			[LabelStatus release];
			
	     [vw release];
}


-(void)back
{
	if ([[arr_recpt objectAtIndex:0] isEqualToString:@""])
	{
		[self.navigationController popViewControllerAnimated:YES];
	}
	else 
	{
		claim *myclaim=[[claim alloc]init];
		[self.navigationController pushViewController:myclaim animated:YES];
	}

	
}
-(void)signoutbt
{
	UIBarButtonItem *signoutButton = [[UIBarButtonItem alloc]
									  initWithTitle:@"Sign Off"
									  style:UIBarButtonItemStyleBordered
									  target:self
									  action:@selector(signout)];
    self.navigationItem.rightBarButtonItem =signoutButton;
}
-(void)signout
{
	[((AcclarisAppDelegate *)[[UIApplication sharedApplication] delegate]) removeTabBar];
	
}
-(void)claimActivityReq
{
	NSMutableArray *userinfo_arr=[passPerser passresponce];
	request *r=[[request alloc] initWithTarget:self
								 SuccessAction:@selector(onSucceffulLogin)
								 FailureAction:@selector(onFailureLogin)];
	[r claimactivityRequest:str_startID1 participentid:[userinfo_arr objectAtIndex:2] userid:[userinfo_arr objectAtIndex:4] receiptRequired:[arr_recpt objectAtIndex:0] receiptRequiredType:[arr_recpt objectAtIndex:1]];

	[r release];
	[tools startLoading:self.view childView:loadingView text:@"Loading your Claim activity. Wait…."];
	
}

-(void)onSucceffulLogin
{
	[tools stopLoading:loadingView];
	arr_celltytle=[claimactivityPerser claimactivityArr];
	BOOL morerec=[claimactivityPerser gethasMoreRecords_claim];
	if (!morerec)
	{
		//bt_next.enabled=NO;
		bt_next.hidden=YES;
	}
	else 
	{
		bt_next.hidden=NO;
	}

	
	
	[self createtableview];
}

-(void)onFailureLogin
{
	[tools stopLoading:loadingView];
}
-(void)createtableview
{
	acctable=[[UITableView alloc] initWithFrame:CGRectMake(0,78,320,290-65) style:UITableViewStyleGrouped];
	acctable.delegate = self;
	acctable.dataSource = self;
	acctable.scrollEnabled = YES;
	acctable.autoresizesSubviews = YES;
	acctable.showsVerticalScrollIndicator=YES;
	acctable.showsHorizontalScrollIndicator=YES;
	acctable.backgroundColor=[UIColor clearColor];
	[self.view addSubview:acctable];	
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView  
{
	return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	
	return [arr_celltytle  count];
	
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{  
	static NSString *CellIdentifier = @"Cell";
	static NSString *CellIdentifier1 = @"Cell1";
	UITableViewCell *cell;
	
	if(cell==nil)
	{
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier] autorelease];
	}
	else
	{
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier1];
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier1] autorelease];
		
	}
	cell.selectionStyle=UITableViewCellSelectionStyleNone;
	cell.backgroundColor=[UIColor whiteColor];
	
	
	//if (indexPath.row==0)//Header
//	{
//		cell.backgroundColor=[UIColor colorWithRed:con.bgRed2/255.0 green:con.bgGreen2/255.0 blue:con.bgBlue2/255.0 alpha:1.0];
//		
//		
//		UILabel *Labelclaimdate=[[UILabel alloc]initWithFrame:CGRectMake(5,3,120,20)];
//		Labelclaimdate.font=[UIFont fontWithName:con.fontname size:con.fontsize];
//		Labelclaimdate.backgroundColor=[UIColor clearColor];
//		Labelclaimdate.text =@"Claim Date";
//		Labelclaimdate.textColor=[UIColor whiteColor];
//		[cell.contentView addSubview:Labelclaimdate];
//		[Labelclaimdate release];
//		
//		UILabel *LabelAccount=[[UILabel alloc]initWithFrame:CGRectMake(5,26,120,20)];
//		LabelAccount.font=[UIFont fontWithName:con.fontname size:con.fontsize];
//		LabelAccount.backgroundColor=[UIColor clearColor];
//		LabelAccount.text = @"Account";
//		LabelAccount.textColor=[UIColor whiteColor];
//		[cell.contentView addSubview:LabelAccount];
//		[LabelAccount release];
//		
//		UILabel *Labeltype=[[UILabel alloc]initWithFrame:CGRectMake(5,49,120,20)];
//		Labeltype.font=[UIFont fontWithName:con.fontname size:con.fontsize];
//		Labeltype.backgroundColor=[UIColor clearColor];
//		Labeltype.text = @"Type";
//		Labeltype.textColor=[UIColor whiteColor];
//		[cell.contentView addSubview:Labeltype];
//		[Labeltype release];
//		
//		/////////////////////////////////////////////
//		
//		UILabel *LabelAmmount=[[UILabel alloc]initWithFrame:CGRectMake(150,3,145,20)];
//		LabelAmmount.font=[UIFont fontWithName:con.fontname size:con.fontsize];
//		LabelAmmount.backgroundColor=[UIColor clearColor];
//		LabelAmmount.text = @"Ammount";
//		LabelAmmount.textColor=[UIColor whiteColor];
//		LabelAmmount.textAlignment=UITextAlignmentRight;
//		[cell.contentView addSubview:LabelAmmount];
//		[LabelAmmount release];
//		
//		
//		UILabel *LabelCatagory=[[UILabel alloc]initWithFrame:CGRectMake(150,26,145,20)];
//		LabelCatagory.font=[UIFont fontWithName:con.fontname size:con.fontsize];
//		LabelCatagory.backgroundColor=[UIColor clearColor];
//		LabelCatagory.text = @"Catagory";
//		LabelCatagory.textColor=[UIColor whiteColor];
//		LabelCatagory.textAlignment=UITextAlignmentRight;
//		[cell.contentView addSubview:LabelCatagory];
//		[LabelCatagory release];
//		
//		
//		UILabel *LabelStatus=[[UILabel alloc]initWithFrame:CGRectMake(150,49,145,20)];
//		LabelStatus.font=[UIFont fontWithName:con.fontname size:con.fontsize];
//		LabelStatus.backgroundColor=[UIColor clearColor];
//		LabelStatus.text = @"Status";
//		LabelStatus.textColor=[UIColor whiteColor];
//		LabelStatus.textAlignment=UITextAlignmentRight;
//		[cell.contentView addSubview:LabelStatus];
//		[LabelStatus release];
//		
//	}
//	else//Grid
	
//	{
	
	
	   NSString *strFont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];
	
		cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;	
		
		UILabel *cellclaimdate=[[UILabel alloc]initWithFrame:CGRectMake(5,3,110,20)];
		cellclaimdate.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
		cellclaimdate.backgroundColor=[UIColor clearColor];
		cellclaimdate.text =((claimActivityOBJ *)[ arr_celltytle objectAtIndex:indexPath.row]).submitDate;
		cellclaimdate.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
		[cell.contentView addSubview:cellclaimdate];
		[cellclaimdate release];
	
		UILabel *cellclaimaccount=[[UILabel alloc]initWithFrame:CGRectMake(5,26,110,20)];
		cellclaimaccount.font=[UIFont fontWithName:con.fontname size:con.bodyImpfntsize];
		cellclaimaccount.backgroundColor=[UIColor clearColor];
		cellclaimaccount.text = ((claimActivityOBJ *)[ arr_celltytle objectAtIndex:indexPath.row]).accountType;
		cellclaimaccount.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
		[cell.contentView addSubview:cellclaimaccount];
		[cellclaimaccount release];
	
		UILabel *cellclaimtype=[[UILabel alloc]initWithFrame:CGRectMake(5,49,140,20)];
		cellclaimtype.font=[UIFont fontWithName:con.fontname size:con.bodyImpfntsize];
		cellclaimtype.backgroundColor=[UIColor clearColor];
		cellclaimtype.text = ((claimActivityOBJ *)[ arr_celltytle objectAtIndex:indexPath.row]).claimType;
		cellclaimtype.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
		[cell.contentView addSubview:cellclaimtype];
		[cellclaimtype release];
		
		
		///////////////////////////////////////////////////////////////
		
		UILabel *cellAmmount=[[UILabel alloc]initWithFrame:CGRectMake(120,3,150,20)];
		cellAmmount.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
		cellAmmount.backgroundColor=[UIColor clearColor];
		NSString *str=[self chkvalue:((claimActivityOBJ *)[ arr_celltytle objectAtIndex:indexPath.row]).amount];
		if (((claimActivityOBJ *)[ arr_celltytle objectAtIndex:indexPath.row]).amount<0)
		{
			
			cellAmmount.textColor=[UIColor colorWithRed:con.ngtvRed/255.0f green:con.ngtvGreen/255.0f blue:con.ngtvBlue/255.0f alpha:1.0];
		}
		else 
		{
			cellAmmount.textColor=[UIColor colorWithRed:con.posnumRed/255.0f green:con.posnumGreen/255.0f blue:con.posnumBlue/255.0f alpha:1.0];
		}		
		
		
		cellAmmount.text =str;
		cellAmmount.textAlignment=UITextAlignmentRight;
		[cell.contentView addSubview:cellAmmount];
		[cellAmmount release];
		
		UILabel *cellclaimcatagory=[[UILabel alloc]initWithFrame:CGRectMake(110,26,160,20)];
		cellclaimcatagory.font=[UIFont fontWithName:con.fontname size:con.bodyImpfntsize];
		cellclaimcatagory.backgroundColor=[UIColor clearColor];
		cellclaimcatagory.text = ((claimActivityOBJ *)[ arr_celltytle objectAtIndex:indexPath.row]).claimCategory;
		cellclaimcatagory.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
		cellclaimcatagory.textAlignment=UITextAlignmentRight;
		[cell.contentView addSubview:cellclaimcatagory];
		[cellclaimcatagory release];
		
		UILabel *cellclaimstatus=[[UILabel alloc]initWithFrame:CGRectMake(125,49,150,20)];
		cellclaimstatus.font=[UIFont fontWithName:con.fontname size:con.bodyImpfntsize];
		cellclaimstatus.backgroundColor=[UIColor clearColor];
		cellclaimstatus.text = ((claimActivityOBJ *)[ arr_celltytle objectAtIndex:indexPath.row]).status;
		cellclaimstatus.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
		cellclaimstatus.textAlignment=UITextAlignmentRight;
		[cell.contentView addSubview:cellclaimstatus];
		[cellclaimstatus release];
		
	//}
	
	return cell;
	
	
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return 75;
	
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	selectedclaimrow=indexPath.row;
	claimActivityDetails *myclaimActivityDetails = [[claimActivityDetails alloc] init];
	[self.navigationController pushViewController:myclaimActivityDetails animated:YES];	
}

+(NSInteger)getSelectedClaimRow
{
	if (selectedclaimrow) {
		return selectedclaimrow;
	}
	else {
		return 0;
	}
	
}
-(NSString *)chkvalue:(NSString *)value
{
	NSString *newvalue=@"";
	if([value intValue]>=0)
	{
		newvalue=[newvalue stringByAppendingString:con.ptvPrefix];
		newvalue=[newvalue stringByAppendingString:value];
	}
	else {
		value=[value substringFromIndex:1];
		newvalue=[newvalue stringByAppendingString:con.ngtvPrefix];
		newvalue=[newvalue stringByAppendingString:value];
		newvalue=[newvalue stringByAppendingString:con.ngtvSufix];
		
	}
	return newvalue;
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
