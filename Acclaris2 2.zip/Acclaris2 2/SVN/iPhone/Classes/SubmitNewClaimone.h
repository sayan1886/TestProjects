//
//  SubmitNewClaimone.h
//  Acclaris
//
//  Created by Subhojit on 21/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyTools.h"
#import "Decode64.h"
#import "SubmitNewClaimTwo.h"
#import "ClaimSubmitNewParser.h"
#import "ClaimSubmitNewOBJ.h"
#import "SubmitNewClaimThree.h"
@class configurables;



@interface SubmitNewClaimone : UIViewController<UITextFieldDelegate,UIPickerViewDelegate> {

	UITextField *txtCatagory;
	NSArray *pickerViewArray;
	UIPickerView *myPickerView;
	configurables *con;
	MyTools *tools;
	NSMutableArray *arrsubmitcatagory;
	NSInteger *rowcount;
	NSMutableArray *arrpicker;
	ClaimSubOBJ*  objClaimsub;
	ClaimSubmitNewOBJ*  objClaimsubmit;
	NSString *strPriorCheck;
	NSMutableArray *arrDecide;
	NSString *strselectclaimcatagory;
	NSMutableDictionary *dict;
}
-(void)signout;
-(void)CreateView;
-(void)CreatePickerView;
-(void)createbarbuttondone;
-(void)donecancel;
-(void)createbar_button;
-(void)Vanishpicker;
@property(nonatomic,retain)NSString *strPriorCheck;
@end
