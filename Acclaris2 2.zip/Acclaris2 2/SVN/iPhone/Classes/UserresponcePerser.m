//
//  UserresponcePerser.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 02/10/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import "UserresponcePerser.h"
#import "errorcodeOBJ.h"
NSMutableArray *arrUserinfo;

@implementation UserresponcePerser
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error
{
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	arrUserinfo = [[NSMutableArray alloc]init];
	NSXMLParser *parser;
	parser = [[NSXMLParser alloc] initWithData:data];
    [parser setDelegate:self];
	[parser setShouldProcessNamespaces:NO];
    [parser setShouldReportNamespacePrefixes:NO];
    [parser setShouldResolveExternalEntities:NO];
    [parser parse];
    NSError *parseError = [parser parserError];
    if (parseError && error) 
	{
        *error = parseError;
    }
	[parser release];
}

-(void)parserDidStartDocument:(NSXMLParser *)parser
{
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	myerrorcodeOBJ=[[errorcodeOBJ alloc]init];
	errordetails=[[NSMutableArray alloc]init];
}		

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
	if (qName)
	{
		elementName = qName;
	}
	
	
	else 
		if([elementName isEqualToString:@"returnCode"])
		{
			
			contentOfString=[NSMutableString string];
			[contentOfString retain];
			return;		
			
		}
		else 
			if([elementName isEqualToString:@"errorText"])
			{
				
				contentOfString=[NSMutableString string];
				[contentOfString retain];
				return;		
				
			}
			else 
				if([elementName isEqualToString:@"userName"])
				{
					contentOfString=[NSMutableString string];
					[contentOfString retain];
					return;		
					
				}
				else 
					if([elementName isEqualToString:@"logoURL"])
					{
						contentOfString=[NSMutableString string];
						[contentOfString retain];
						return;		
						
					}
					else 
						if([elementName isEqualToString:@"siteIDURL"])
						{
							contentOfString=[NSMutableString string];
							[contentOfString retain];
							return;		
							
						}
						else
							if([elementName isEqualToString:@"forgotSiteIDText"])
							{
								contentOfString=[NSMutableString string];
								[contentOfString retain];
								return;		
		
							}
						else 
							if([elementName isEqualToString:@"incorrectSiteIDText"])
							{
								contentOfString=[NSMutableString string];
								[contentOfString retain];
								return;		
								
							}
							else 
								if([elementName isEqualToString:@"forgotPasswordText"])
								{
									contentOfString=[NSMutableString string];
									[contentOfString retain];
									return;		
									
								}
								else 
									if([elementName isEqualToString:@"participantID"])
									{
										contentOfString=[NSMutableString string];
										[contentOfString retain];
										return;		
										
									}
									else 
										if([elementName isEqualToString:@"userID"])
										{
											contentOfString=[NSMutableString string];
											[contentOfString retain];
											return;		
											
										}
										else 
											if([elementName isEqualToString:@"configItemsLastChangeOn"])
											{
												contentOfString=[NSMutableString string];
												[contentOfString retain];
												return;		
												
											}
											else 
												if([elementName isEqualToString:@"buildInfo"])
												{
													buildinfo=[[NSMutableArray alloc]init];
												
													return;		
													
												}
												else 
													if([elementName isEqualToString:@"path"])
													{
														contentOfString=[NSMutableString string];
														[contentOfString retain];
														return;		
														
													}
													else 
														if([elementName isEqualToString:@"lastBuildOn"])
														{
															contentOfString=[NSMutableString string];
															[contentOfString retain];
															return;		
															
														}
														else 
															if([elementName isEqualToString:@"version"])
															{
																contentOfString=[NSMutableString string];
																[contentOfString retain];
																return;		
																
															}
															else 
																if([elementName isEqualToString:@"note"])
																{
																	contentOfString=[NSMutableString string];
																	[contentOfString retain];
																	return;		
																	
																}
																else 
																	if([elementName isEqualToString:@"customMessageLastChangeOn"])
																	{
																		contentOfString=[NSMutableString string];
																		[contentOfString retain];
																		return;		
																		
																	}
	
	
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName     
{	
	if (qName)
	{
        elementName = qName;
		
    }
	
	else 
		if([elementName isEqualToString:@"returnCode"])
		{
			if(contentOfString)
			{
				myerrorcodeOBJ.returnCode=contentOfString;
				[arrUserinfo addObject:contentOfString];
				[contentOfString release];
				contentOfString = nil;
				
				
			}	
			
		}
		else 
			if([elementName isEqualToString:@"errorText"])
			{
				if(contentOfString)
				{
					myerrorcodeOBJ.errorText=contentOfString;
					[errordetails addObject:myerrorcodeOBJ];
					[arrUserinfo addObject:contentOfString];
					[contentOfString release];
					contentOfString = nil;
					
					
				}		
				
			}
			else 
				if([elementName isEqualToString:@"userName"])
				{
					if(contentOfString)
					{
						[arrUserinfo addObject:contentOfString];
						[contentOfString release];
						contentOfString = nil;
						
						
					}		
					
				}
				else 
					if([elementName isEqualToString:@"logoURL"])
					{
						if(contentOfString)
						{
							//NSString *str=@"https://rhel-dev4.acclaris.net";
							//str=[str stringByAppendingString:contentOfString];
							[arrUserinfo addObject:contentOfString];
							[contentOfString release];
							contentOfString = nil;
							
							
						}	
						
					}
					else 
						if([elementName isEqualToString:@"siteIDURL"])
						{
							if(contentOfString)
							{
								//NSString *str=@"https://rhel-dev4.acclaris.net";
								//str=[str stringByAppendingString:contentOfString];
								[arrUserinfo addObject:contentOfString];
								[contentOfString release];
								contentOfString = nil;
								
								
							}	
							
						}
						else 
							if([elementName isEqualToString:@"forgotSiteIDText"])
							{
								if(contentOfString)
								{
									[arrUserinfo addObject:contentOfString];
									[contentOfString release];
									contentOfString = nil;
									
									
									
								}	
								
							}
						else 
							if([elementName isEqualToString:@"incorrectSiteIDText"])
							{
								if(contentOfString)
								{
									[arrUserinfo addObject:contentOfString];
									[contentOfString release];
									contentOfString = nil;
									
									
									
								}	
								
							}
							else 
								if([elementName isEqualToString:@"forgotPasswordText"])
								{
									if(contentOfString)
									{
										[arrUserinfo addObject:contentOfString];
										[contentOfString release];
										contentOfString = nil;
										
										
									}	
									
								}
								else 
									if([elementName isEqualToString:@"participantID"])
									{
										if(contentOfString)
										{
											[arrUserinfo addObject:contentOfString];
											[contentOfString release];
											contentOfString = nil;
											
											
										}	
										
									}
	

									else 
										if([elementName isEqualToString:@"userID"])
										{
											if(contentOfString)
											{
												[arrUserinfo addObject:contentOfString];
												[contentOfString release];
												contentOfString = nil;
												
												
											}	
											
										}
	
										else 
											if([elementName isEqualToString:@"configItemsLastChangeOn"])
											{
												if(contentOfString)
												{
													[arrUserinfo addObject:contentOfString];
													[contentOfString release];
													contentOfString = nil;
													
													
												}	
												
											}
											else 
												if([elementName isEqualToString:@"buildInfo"])
												{
													if(buildinfo)
													{
														[arrUserinfo addObject:buildinfo];
														[buildinfo release];
														buildinfo = nil;
														
														
														
													}	
													
												}
												else 
													if([elementName isEqualToString:@"path"])
													{
														if(contentOfString)
														{
															[buildinfo addObject:contentOfString];
															[contentOfString release];
															contentOfString = nil;
															
															
															
														}	
														
													}
													else 
														if([elementName isEqualToString:@"lastBuildOn"])
														{
															if(contentOfString)
															{
																[buildinfo addObject:contentOfString];
																[contentOfString release];
																contentOfString = nil;
																
																
															}	
															
														}
														else 
															if([elementName isEqualToString:@"version"])
															{
																if(contentOfString)
																{
																	[buildinfo addObject:contentOfString];
																	[contentOfString release];
																	contentOfString = nil;
																	
																	
																}	
																
															}
	
	
															else 
																if([elementName isEqualToString:@"note"])
																{
																	if(contentOfString)
																	{
																		[buildinfo addObject:contentOfString];
																		[contentOfString release];
																		contentOfString = nil;
																		
																		
																	}	
																	
																}
	
																else 
																	if([elementName isEqualToString:@"customMessageLastChangeOn"])
																	{
																		if(contentOfString)
																		{
																			[arrUserinfo addObject:contentOfString];
																			[contentOfString release];
																			contentOfString = nil;
																			
																			
																		}	
																		
																	}
	
	
							
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
	if(contentOfString)
		[contentOfString appendString:string];
}

- (void)parserDidEndDocument:(NSXMLParser *)parse
{
	myerrorcodeOBJ=(errorcodeOBJ *)[errordetails objectAtIndex:0];
	
	NSLog(@"**********\n\n\n\n\n\n%@\n\nreturnCode %@\nerrorText %@",arrUserinfo,myerrorcodeOBJ.returnCode,myerrorcodeOBJ.errorText);
}	
+(NSMutableArray *)userdesc
{
	if (arrUserinfo) {
		
		return arrUserinfo;
	}
	else {
		return nil;
	}

}

@end
