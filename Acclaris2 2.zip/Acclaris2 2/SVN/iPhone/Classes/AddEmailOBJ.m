//
//  AddEmailOBJ.m
//  Acclaris
//
//  Created by Subhojit on 18/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "AddEmailOBJ.h"


@implementation AddEmailOBJ
@synthesize strreturnCode,strerrorText,strresult;
@end
