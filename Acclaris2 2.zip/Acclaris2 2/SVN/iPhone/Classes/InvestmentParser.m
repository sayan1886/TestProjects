//
//  InvestmentParser.m
//  Acclaris
//
//  Created by Sumit Kr Prasad on 31/12/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "InvestmentParser.h"

NSMutableArray *arr_transaction1;
NSMutableArray *errordetails1;
BOOL hasMoreRecords_transaction1;
@implementation InvestmentParser

-(NSString *)demoResponse
{
	NSString *response=@"<env:Envelope xmlns:env='http://schemas.xmlsoap.org/soap/envelope/'><env:Header>"
	"</env:Header><env:Body><GetInvestmentActivityMAResponse xmlns=\"http://www.acclaris.com/servicetypesma\">"
	"<GetInvestmentActivityMADetails><returnCode>0</returnCode><errorText></errorText><participantID>993286</participantID>"
	"<participantCode></participantCode><invstActivityListCount>2</invstActivityListCount><invstActivityItems><activity>"
	"<date>Date|12/12/2010</date><transactionCode>Transaction Code|1234</transactionCode><investmentName>Investment Name|ABC</investmentName>"
	"<units>Num Of Units|12</units><price>Current Price|120</price><amount>Amount|10</amount><transactionStatus>Status|Processed</transactionStatus>"
	"<contributionType>Contribution Type|</contributionType><optyprDesc>Desc|ABC Fund.</optyprDesc><planID>Plan ID|12</planID><sequence>Sequence|1</sequence>"
	"<sourceNum>Source Num|</sourceNum><activityType>Activity Type|Buy</activityType><transactionType>Transaction Type|Buy</transactionType><value1 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:nil=\"true\"/>"
	"<value2 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:nil=\"true\"/><value3 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:nil=\"true\"/>"
	"<value4 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:nil=\"true\"/><value5 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:nil=\"true\"/>"
	"</activity><activity><date>Date|12/13/2010</date><transactionCode>Transaction Code|1234</transactionCode><investmentName>Investment Name|ABC</investmentName><units>Num Of Units|12</units>"
	"<price>Current Price|120.2</price><amount>Amount|10.2</amount><transactionStatus>Status|Processed</transactionStatus>"
	"<contributionType>Contribution Type|</contributionType><optyprDesc>Desc|ABC Fund.</optyprDesc><planID>Plan ID|13</planID><sequence>Sequence|2</sequence><sourceNum>Source Num|</sourceNum>"
	"<activityType>Activity Type|Sell</activityType><transactionType>Transaction Type|Sell</transactionType><value1 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:nil=\"true\"/>"
	"<value2 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:nil=\"true\"/>"
	"<value3 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:nil=\"true\"/><value4 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:nil=\"true\"/>"
	"<value5 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:nil=\"true\"/></activity></invstActivityItems><highestSequenceId xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:nil=\"true\"/>"
	"<hasMoreRecords>No</hasMoreRecords><value1 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:nil=\"true\"/>"
	"<value2 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:nil=\"true\"/><value3 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:nil=\"true\"/>"
	"<value4 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:nil=\"true\"/><value5 xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:nil=\"true\"/></GetInvestmentActivityMADetails></GetInvestmentActivityMAResponse></env:Body></env:Envelope>";
	
	NSLog(@"demo response: %@",response);
	return response;
}
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error
{
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	arr_transaction1 = [[NSMutableArray alloc]init];
	NSXMLParser *parser;
	parser = [[NSXMLParser alloc] initWithData:data];
    [parser setDelegate:self];
	[parser setShouldProcessNamespaces:NO];
    [parser setShouldReportNamespacePrefixes:NO];
    [parser setShouldResolveExternalEntities:NO];
    [parser parse];
    NSError *parseError = [parser parserError];
    if (parseError && error) 
	{
        *error = parseError;
    }
	[parser release];
}

-(void)parserDidStartDocument:(NSXMLParser *)parser
{
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	myerrorcodeOBJ=[[errorcodeOBJ alloc]init];
	errordetails1=[[NSMutableArray alloc]init];
}		

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
	if (qName)
	{
		elementName = qName;
	}
	else 
		if([elementName isEqualToString:@"returnCode"])
		{
			
			contentOfString=[NSMutableString string];
			[contentOfString retain];
			return;		
			
		}
		else 
			if([elementName isEqualToString:@"errorText"])
			{
				
				contentOfString=[NSMutableString string];
				[contentOfString retain];
				return;		
				
			}
			else 
				if([elementName isEqualToString:@"hasMoreRecords"])
				{
					contentOfString=[NSMutableString string];
					[contentOfString retain];
					return;		
					
				}
				else 
					if([elementName isEqualToString:@"activity"])
					{
						myInvestmentObj=[[InvestmentObj alloc]init];
						return;			
						
					}
					else 
						if([elementName isEqualToString:@"date"])
						{
							contentOfString=[NSMutableString string];
							[contentOfString retain];
							return;		
							
						}
						else 
							if([elementName isEqualToString:@"investmentName"])
							{
								contentOfString=[NSMutableString string];
								[contentOfString retain];
								return;		
								
							}
							else 
								if([elementName isEqualToString:@"units"])
								{
									contentOfString=[NSMutableString string];
									[contentOfString retain];
									return;		
									
								}
								else 
									if([elementName isEqualToString:@"price"])
									{
										contentOfString=[NSMutableString string];
										[contentOfString retain];
										return;		
										
									}
									else 
										if([elementName isEqualToString:@"amount"])
										{
											contentOfString=[NSMutableString string];
											[contentOfString retain];
											return;		
											
										}
										else 
											if([elementName isEqualToString:@"transactionType"])
											{
												contentOfString=[NSMutableString string];
												[contentOfString retain];
												return;	
												
											}
											else 
												if([elementName isEqualToString:@"transactionCode"])
												{
													contentOfString=[NSMutableString string];
													[contentOfString retain];
													return;	
													
												}
												else 
													if([elementName isEqualToString:@"optyprDesc"])
													{
														contentOfString=[NSMutableString string];
														[contentOfString retain];
														return;		
														
													}
													else 
														if([elementName isEqualToString:@"contributionType"])
														{
															contentOfString=[NSMutableString string];
															[contentOfString retain];
															return;		
															
														}
														else 
															if([elementName isEqualToString:@"planID"])
															{
																contentOfString=[NSMutableString string];
																[contentOfString retain];
																return;		
																
															}
															else 
																if([elementName isEqualToString:@"transactionStatus"])
																{
																	contentOfString=[NSMutableString string];
																	[contentOfString retain];
																	return;			
																	
																}
																else 
																	if([elementName isEqualToString:@"sequence"])
																	{
																		contentOfString=[NSMutableString string];
																		[contentOfString retain];
																		return;		
																		
																	}
																	else 
																		if([elementName isEqualToString:@"sourceNum"])
																		{
																			contentOfString=[NSMutableString string];
																			[contentOfString retain];
																			return;		
																			
																		}
																		else 
																			if([elementName isEqualToString:@"activityType"])
																			{
																				contentOfString=[NSMutableString string];
																				[contentOfString retain];
																				return;		
																				
																			}
																				
	
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName     
{	
	if (qName)
	{
        elementName = qName;
		
    }
	else 
		if([elementName isEqualToString:@"returnCode"])
		{
			if(contentOfString)
			{
				myerrorcodeOBJ.returnCode=contentOfString;
				[contentOfString release];
				contentOfString = nil;
				
				
			}	
			
		}
		else 
			if([elementName isEqualToString:@"errorText"])
			{
				if(contentOfString)
				{
					myerrorcodeOBJ.errorText=contentOfString;
					[errordetails1 addObject:myerrorcodeOBJ];
					[contentOfString release];
					contentOfString = nil;
					
					
				}		
				
			}
			else 
				if([elementName isEqualToString:@"hasMoreRecords"])
				{
					if(contentOfString)
					{
						if ([contentOfString isEqualToString:@"Yes"])
						{
							hasMoreRecords_transaction1=YES;
						}
						else {
							hasMoreRecords_transaction1=NO;	
						}
						
					}		
					
				}
	
				else 
					if([elementName isEqualToString:@"activity"])
					{
						
						[arr_transaction1 addObject:myInvestmentObj];
						[myInvestmentObj release];
						myInvestmentObj = nil;
						
					}
					else 
						if([elementName isEqualToString:@"date"])
						{
							if(contentOfString)
							{
								NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
								if ([arrlocal1 count]>1)
								{
									myInvestmentObj.date=[arrlocal1 objectAtIndex:1];
									myInvestmentObj.lblDate=[arrlocal1 objectAtIndex:0];
								}
								else {
									myInvestmentObj.date=[arrlocal1 objectAtIndex:0];
								}
								
								
								[contentOfString release];
								contentOfString = nil;
								
								
							}		
							
						}
						else 
							if([elementName isEqualToString:@"investmentName"])
							{
								if(contentOfString)
								{
									NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
									if ([arrlocal1 count]>1)
									{
										myInvestmentObj.investmentName=[arrlocal1 objectAtIndex:1];
										myInvestmentObj.lblInvestmentName=[arrlocal1 objectAtIndex:0];
									}
									else {
										myInvestmentObj.investmentName=[arrlocal1 objectAtIndex:0];
									}
									
									[contentOfString release];
									contentOfString = nil;
									
									
								}	
								
							}
							else 
								if([elementName isEqualToString:@"units"])
								{
									if(contentOfString)
									{
										NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
										if ([arrlocal1 count]>1)
										{
											myInvestmentObj.units=[arrlocal1 objectAtIndex:1];
											myInvestmentObj.lblUnits=[arrlocal1 objectAtIndex:0];
										}
										else {
											myInvestmentObj.units=[arrlocal1 objectAtIndex:0];
										}
										
										[contentOfString release];
										contentOfString = nil;
										
										
										
									}	
									
								}
								else 
									if([elementName isEqualToString:@"price"])
									{
										if(contentOfString)
										{
											
											NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
											if ([arrlocal1 count]>1)
											{
												myInvestmentObj.price=[arrlocal1 objectAtIndex:1];
												myInvestmentObj.lblPrice=[arrlocal1 objectAtIndex:0];
											}
											else {
												myInvestmentObj.price=[arrlocal1 objectAtIndex:0];
											}
											
											[contentOfString release];
											contentOfString = nil;
											
											
											
										}	
										
									}
									else 
										if([elementName isEqualToString:@"amount"])
										{
											if(contentOfString)
											{
												NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
												if ([arrlocal1 count]>1)
												{
													myInvestmentObj.amount=[arrlocal1 objectAtIndex:1];
													myInvestmentObj.lblAmount=[arrlocal1 objectAtIndex:0];
												}
												else {
													myInvestmentObj.amount=[arrlocal1 objectAtIndex:0];
												}
												
												[contentOfString release];
												contentOfString = nil;
												
												
											}		
											
										}
										else 
											if([elementName isEqualToString:@"transactionType"])
											{
												if(contentOfString)
												{
													
													NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
													if ([arrlocal1 count]>1)
													{
														myInvestmentObj.transactionType=[arrlocal1 objectAtIndex:1];
														myInvestmentObj.lblTransactionType=[arrlocal1 objectAtIndex:0];
													}
													else
														myInvestmentObj.transactionType=[arrlocal1 objectAtIndex:0];	
													
													
													[contentOfString release];
													contentOfString = nil;
													
													
												}	
												
											}
											else 
												if([elementName isEqualToString:@"transactionCode"])
												{
													if(contentOfString)
													{
														NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
														if ([arrlocal1 count]>1)
														{
															myInvestmentObj.transactionCode=[arrlocal1 objectAtIndex:1];
															myInvestmentObj.lblTransactionCode=[arrlocal1 objectAtIndex:0];
														}
														else
														{
															myInvestmentObj.transactionCode=[arrlocal1 objectAtIndex:0];
														}
														[contentOfString release];
														contentOfString = nil;
														
													}	
													
												}
	
												else 
													if([elementName isEqualToString:@"optyprDesc"])
													{
														if(contentOfString)
														{
															NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
															if ([arrlocal1 count]>1)
															{
																myInvestmentObj.optyprDesc=[arrlocal1 objectAtIndex:1];
																myInvestmentObj.lblOptyprDesc=[arrlocal1 objectAtIndex:0];
															}
															else {
																myInvestmentObj.optyprDesc=[arrlocal1 objectAtIndex:0];
															}
															
															[contentOfString release];
															contentOfString = nil;
															
														}
														
													}
													else 
														if([elementName isEqualToString:@"contributionType"])
														{
															if(contentOfString)
															{
																NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
																if ([arrlocal1 count]>1)
																{
																	myInvestmentObj.contributionType=[arrlocal1 objectAtIndex:1];
																	myInvestmentObj.lblContributionType=[arrlocal1 objectAtIndex:0];
																	
																}
																else
																	myInvestmentObj.contributionType=[arrlocal1 objectAtIndex:0];
																[contentOfString release];
																contentOfString = nil;
																
																
															}	
															
														}
														else 
															if([elementName isEqualToString:@"planID"])
															{
																if(contentOfString)
																{
																	NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
																	if ([arrlocal1 count]>1)
																	{
																		myInvestmentObj.planID=[arrlocal1 objectAtIndex:1];
																		myInvestmentObj.lblPlanID=[arrlocal1 objectAtIndex:0];
																	}
																	else 
																		myInvestmentObj.planID=[arrlocal1 objectAtIndex:0];
																	[contentOfString release];
																	contentOfString = nil;
																	
																	
																	
																}	
																
															}
															else 
																if([elementName isEqualToString:@"transactionStatus"])
																{
																	if(contentOfString)
																	{
																		NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
																		if ([arrlocal1 count]>1)
																		{
																			myInvestmentObj.transactionStatus=[arrlocal1 objectAtIndex:1];
																			myInvestmentObj.lblTransactionStatus=[arrlocal1 objectAtIndex:0];
																		}
																		else {
																			myInvestmentObj.transactionStatus=[arrlocal1 objectAtIndex:0];
																		}
																		
																		[contentOfString release];
																		contentOfString = nil;
																		
																		
																	}		
																	
																}
																else 
																	if([elementName isEqualToString:@"sequence"])
																	{
																		if(contentOfString)
																		{
																			NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
																			if ([arrlocal1 count]>1)
																			{
																				myInvestmentObj.sequence=[arrlocal1 objectAtIndex:1];
																				myInvestmentObj.lblSequence=[arrlocal1 objectAtIndex:0];
																			}
																			else 
																				myInvestmentObj.sequence=[arrlocal1 objectAtIndex:0];
																			[contentOfString release];
																			contentOfString = nil;
																			
																			
																		}	
																		
																	}
																	else 
																		if([elementName isEqualToString:@"sourceNum"])
																		{
																			if(contentOfString)
																			{
																				NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
																				if ([arrlocal1 count]>1)
																				{
																					myInvestmentObj.sourceNum=[arrlocal1 objectAtIndex:1];
																					myInvestmentObj.lblSourceNum=[arrlocal1 objectAtIndex:0];
																				}
																				
																				else 
																					myInvestmentObj.sourceNum=[arrlocal1 objectAtIndex:0];
																				[contentOfString release];
																				contentOfString = nil;
																				
																				
																			}	
																			
																		}
																		else 
																			if([elementName isEqualToString:@"activityType"])
																			{
																				if(contentOfString)
																				{
																					NSArray *arrlocal1=[contentOfString componentsSeparatedByString:@"|"];
																					if ([arrlocal1 count]>1)
																					{
																						myInvestmentObj.activityType=[arrlocal1 objectAtIndex:1];
																						myInvestmentObj.lblActivityType=[arrlocal1 objectAtIndex:0];
																					}
																					
																					else 
																						myInvestmentObj.activityType=[arrlocal1 objectAtIndex:0];
																					[contentOfString release];
																					contentOfString = nil;
																					
																					
																				}	
																				
																			}
																				
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
	if(contentOfString)
		[contentOfString appendString:string];
}

- (void)parserDidEndDocument:(NSXMLParser *)parse
{
	NSLog(@"**********%@",arr_transaction1);
}	
+(NSMutableArray *)get_arr_investment
{
	if (arr_transaction1) {
		
		return arr_transaction1;
	}
	else {
		return nil;
	}
	
}
+(NSMutableArray *)geterror_arr
{
	if (errordetails1) {
		
		return errordetails1;
	}
	else {
		return nil;
	}
	
}
+(BOOL)gethasMoreRecords_investment
{
	if (hasMoreRecords_transaction1) {
		
		return hasMoreRecords_transaction1;
	}
	else {
		return NO;
	}
	
}

@end
