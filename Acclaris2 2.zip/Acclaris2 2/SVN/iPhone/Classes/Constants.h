/*
 *  Constants.h
 *  Acclaris
 *
 *  Created by Subhojit on 25/03/11.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */

//#define urllink  @"https://rhel-dev4.acclaris.net/benefits/webservices/";

//#define urllink @"https://bddev5.acclaris.net/bensol/webservices/";

//#define urllink  @"https://bdqap1.acclaris.com/bensol/webservices/";//UAT

#define urllink  @"https://qa.participantportal.com/benefits/webservices/";//UAT NON BANK
