//
//  ticketPerser.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 26/10/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import "ticketPerser.h"
#import "errorcodeOBJ.h"
NSMutableArray *errordetails;
NSMutableArray *ticketArray;
BOOL hasMoreRecords;
@implementation ticketPerser
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error
{
	
	NSXMLParser *parser;
	parser = [[NSXMLParser alloc] initWithData:data];
    [parser setDelegate:self];
	[parser setShouldProcessNamespaces:NO];
    [parser setShouldReportNamespacePrefixes:NO];
    [parser setShouldResolveExternalEntities:NO];
    [parser parse];
    NSError *parseError = [parser parserError];
    if (parseError && error) 
	{
        *error = parseError;
    }
	[parser release];
}

-(void)parserDidStartDocument:(NSXMLParser *)parser
{
	
	arrItem=[[NSMutableArray alloc]init];
	myerrorcodeOBJ=[[errorcodeOBJ alloc]init];
	errordetails=[[NSMutableArray alloc]init];
}		

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
	if(qName)
	{
        elementName = qName;
    }	
	else 
		if([elementName isEqualToString:@"returnCode"])
		{
			
			contentOfString=[NSMutableString string];
			[contentOfString retain];
			return;		
			
		}
		else 
			if([elementName isEqualToString:@"errorText"])
			{
				
				contentOfString=[NSMutableString string];
				[contentOfString retain];
				return;		
				
			}
			else 
				if([elementName isEqualToString:@"hasMoreRecords"])
				{
					contentOfString=[NSMutableString string];
					[contentOfString retain];
					return;		
					
				}
	
	
	
	
	if([elementName isEqualToString:@"ticket"])
	{	
		tickets=[[ticketOBJ alloc]init];
		ticketID_persed=NO;
		return;		
	}
	else if([elementName isEqualToString:@"ticketID"] && !ticketID_persed)
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		ticketID_persed=YES;
		return;		
	}	
	else if([elementName isEqualToString:@"causeNote"])
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}	
	else if([elementName isEqualToString:@"ticketType"])
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}	
	else if([elementName isEqualToString:@"ticketCategory"])
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}
	else if([elementName isEqualToString:@"createdBy"])
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}	
	else if([elementName isEqualToString:@"createdOn"])
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}	
	else if([elementName isEqualToString:@"resolvedBy"])
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}	
	else if([elementName isEqualToString:@"resolvedOn"])
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}	
	else if([elementName isEqualToString:@"resolutionNote"])
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}	
	else if([elementName isEqualToString:@"status"])
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}	
	else if([elementName isEqualToString:@"priority"])
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}	
	else if([elementName isEqualToString:@"source"])
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}	
	else if([elementName isEqualToString:@"privacyLabel"])
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}
	else if([elementName isEqualToString:@"ticketLogsCount"])
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}
	/////////////////////////////////LOGS///////////////////////////////////
	else if([elementName isEqualToString:@"ticketLogs"])
	{
			tickets.arrm_logs=[[NSMutableArray alloc]init];		
	}
	if([elementName isEqualToString:@"log"])
	{	
		ticketLogs=[[ticketLogsOBJ alloc]init];
		return;		
	}
	else if([elementName isEqualToString:@"logID"])
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}
	//else if([elementName isEqualToString:@"ticketID"])
//	{
//		
//		contentOfString=[NSMutableString string];
//		[contentOfString retain];
//		return;		
//	}
	else if([elementName isEqualToString:@"action"])
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}
	else if([elementName isEqualToString:@"loggedBy"])
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}
	else if([elementName isEqualToString:@"loggedThru"])
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}
	else if([elementName isEqualToString:@"note"])
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}
	else if([elementName isEqualToString:@"isPrivate"])
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}
	else if([elementName isEqualToString:@"minutesSpent"])
	{
		
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;		
	}
	else
	{
		;
	}
	
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName     
{	
	if(qName)
	{
        elementName = qName;
		
    }	
	else 
		if([elementName isEqualToString:@"returnCode"])
		{
			if(contentOfString)
			{
				myerrorcodeOBJ.returnCode=contentOfString;
				[contentOfString release];
				contentOfString = nil;
				
				
			}	
			
		}
		else 
			if([elementName isEqualToString:@"errorText"])
			{
				if(contentOfString)
				{
					myerrorcodeOBJ.errorText=contentOfString;
					[errordetails addObject:myerrorcodeOBJ];
					[contentOfString release];
					contentOfString = nil;
					
					
				}		
				
			}
	
			else 
				if([elementName isEqualToString:@"hasMoreRecords"])
				{
					if(contentOfString)
					{
						if ([contentOfString isEqualToString:@"Yes"])
						{
							hasMoreRecords=YES;
						}
						else {
							hasMoreRecords=NO;	
						}

											
						
					}		
					
				}
	
	
	if([elementName isEqualToString:@"ticket"])
	{
		[arrItem addObject:tickets];
		tickets=nil;			
	}	
	else if([elementName isEqualToString:@"ticketID"])
	{
		if(contentOfString)
		{
			NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
			if([tempArr count]==2)
			{
				tickets.LBLticketID=[tempArr objectAtIndex:0];
				tickets.ticketID = [tempArr objectAtIndex:1];	
			}
			else {
				tickets.LBLticketID=@"TicketID";
				tickets.ticketID=contentOfString;
			}
			
			
					
			contentOfString=nil;
		}		
	}	
	else if([elementName isEqualToString:@"causeNote"])
	{
		if(contentOfString)
		{
			NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
			if([tempArr count]==2)
			{
				tickets.LBLcauseNote=[tempArr objectAtIndex:0];
				tickets.causeNote = [tempArr objectAtIndex:1];	
			}
			else {
				tickets.LBLcauseNote=@"Cause Note";
				tickets.causeNote=contentOfString;
			}
					
			contentOfString=nil;
		}		
	}
	else if([elementName isEqualToString:@"ticketType"])
	{
		if(contentOfString)
		{
			
			NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
			if([tempArr count]==2)
			{
				tickets.LBLticketType=[tempArr objectAtIndex:0];
				tickets.ticketType = [tempArr objectAtIndex:1];
			}
			else {
				tickets.LBLticketType=@"TType";
				tickets.ticketType=contentOfString;
			}
					
			contentOfString=nil;
		}		
	}
	else if([elementName isEqualToString:@"ticketCategory"])
	{
		if(contentOfString)
		{
			tickets.ticketCategory = contentOfString;			
			contentOfString=nil;
		}		
	}
		else if([elementName isEqualToString:@"createdBy"])
	{
		if(contentOfString)
		{
			tickets.createdBy = contentOfString;			
			contentOfString=nil;
		}		
	}
	else if([elementName isEqualToString:@"createdOn"])
	{
		if(contentOfString)
		{
			NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
			if([tempArr count]==2)
			{
			tickets.LBLcreatedOn=[tempArr objectAtIndex:0];
			tickets.createdOn = [tempArr objectAtIndex:1];
			}
			else {
				tickets.LBLcreatedOn=@"Open date";
				tickets.createdOn=contentOfString;
			}

			contentOfString=nil;
		}		
	}
	else if([elementName isEqualToString:@"resolvedBy"])
	{
		if(contentOfString)
		{
			tickets.resolvedBy = contentOfString;			
			contentOfString=nil;
		}		
	}
	else if([elementName isEqualToString:@"resolvedOn"])
	{
		if(contentOfString)
		{
			tickets.resolvedOn = contentOfString;			
			contentOfString=nil;
		}		
	}
	else if([elementName isEqualToString:@"resolutionNote"])
	{
		if(contentOfString)
		{
			tickets.resolutionNote = contentOfString;			
			contentOfString=nil;
		}		
	}
	else if([elementName isEqualToString:@"status"])
	{
		if(contentOfString)
		{
			NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
			if([tempArr count]==2)
			{
				tickets.LBLstatus=[tempArr objectAtIndex:0];
				tickets.status = [tempArr objectAtIndex:1];
			}
			else {
				tickets.LBLstatus=@"Status";
				tickets.status=contentOfString;
			}
			contentOfString=nil;
		}		
	}
	else if([elementName isEqualToString:@"priority"])
	{
		if(contentOfString)
		{
			tickets.priority = contentOfString;			
			contentOfString=nil;
		}		
	}
	else if([elementName isEqualToString:@"source"])
	{
		if(contentOfString)
		{
			tickets.source = contentOfString;			
			contentOfString=nil;
		}		
	}
	else if([elementName isEqualToString:@"privacyLabel"])
	{
		if(contentOfString)
		{
			tickets.privacyLabel = contentOfString;			
			contentOfString=nil;
		}		
	}
	else if([elementName isEqualToString:@"ticketLogsCount"])
	{
		if(contentOfString)
		{
			tickets.ticketLogsCount = contentOfString;			
			contentOfString=nil;
		}		
	}

	/////////////////////////////////LOGS///////////////////////////////////
	else if([elementName isEqualToString:@"ticketLogs"])
	{
	
		
	}
	else if([elementName isEqualToString:@"log"])
	{
		[tickets.arrm_logs addObject: ticketLogs];
		//[arrLogs addObject:ticketLogs];
		[tickets.arrm_logs retain];
		ticketLogs=nil;			
	}
	else if([elementName isEqualToString:@"logID"])
	{
		if(contentOfString)
		{
			ticketLogs.logID = contentOfString;			
			contentOfString=nil;
		}		
	}
		else if([elementName isEqualToString:@"action"])
	{
		if(contentOfString)
		{
			NSArray *temp=[contentOfString componentsSeparatedByString:@"|"];
			ticketLogs.action = [temp objectAtIndex:1];			
			contentOfString=nil;
		}		
	}
	else if([elementName isEqualToString:@"loggedBy"])
	{
		if(contentOfString)
		{
			NSArray *temp=[contentOfString componentsSeparatedByString:@"|"];
			ticketLogs.loggedBy = [temp objectAtIndex:1];			
			contentOfString=nil;
		}		
	}
	else if([elementName isEqualToString:@"loggedThru"])
	{
		if(contentOfString)
		{
			ticketLogs.loggedThru = contentOfString;			
			contentOfString=nil;
		}		
	}
	else if([elementName isEqualToString:@"note"])
	{
		if(contentOfString)
		{
			NSArray *temp=[contentOfString componentsSeparatedByString:@"|"];
			ticketLogs.note = [temp objectAtIndex:1];			
			contentOfString=nil;
		}		
	}
	else if([elementName isEqualToString:@"isPrivate"])
	{
		if(contentOfString)
		{
			ticketLogs.isPrivate = contentOfString;			
			contentOfString=nil;
		}		
	}
	else if([elementName isEqualToString:@"minutesSpent"])
	{
		if(contentOfString)
		{
			ticketLogs.minutesSpent = contentOfString;			
			contentOfString=nil;
		}		
	}
	
	else
	{
		;
	}
	
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
	if(contentOfString)
		[contentOfString appendString:string];
}

- (void)parserDidEndDocument:(NSXMLParser *)parse
{
	ticketArray=arrItem;
	for(int i=0;i<[arrItem count];i++)
	{
		ticketOBJ *ticket=(ticketOBJ *)[arrItem objectAtIndex:i];
		NSLog(@"%@",ticket.ticketID);
		NSLog(@"%@",ticket.LBLticketID);
		NSLog(@"%@",ticket.causeNote);
		NSLog(@"%@",ticket.LBLcauseNote);
		NSLog(@"%@",ticket.ticketType);
		NSLog(@"%@",ticket.LBLticketType);
		NSLog(@"%@",ticket.ticketCategory);
		NSLog(@"%d",ticket.createdBy);
		NSLog(@"%@",ticket.createdOn);
		NSLog(@"%@",ticket.LBLcreatedOn);
		NSLog(@"%@",ticket.resolvedBy);
		NSLog(@"%@",ticket.resolvedOn);
		NSLog(@"%@",ticket.resolutionNote);
		NSLog(@"%@",ticket.status);
		NSLog(@"%@",ticket.LBLstatus);
		NSLog(@"%@",ticket.priority);
		NSLog(@"%@",ticket.source);
		NSLog(@"%@",ticket.privacyLabel);
		NSLog(@"%@",ticket.ticketLogsCount);
		NSLog(@"%@",ticket.ticketLogs);
		
		for(int j=0;j<[ticket.arrm_logs count];j++)
		{
			ticketLogsOBJ *ticketlogs=(ticketLogsOBJ *)[ticket.arrm_logs objectAtIndex:j];
			NSLog(@"\n\n-");
			NSLog(@"%@",ticketlogs.logID);
			NSLog(@"%@",ticketlogs.ticketID);
			NSLog(@"%@",ticketlogs.action);
			NSLog(@"%@",ticketlogs.loggedBy);
			NSLog(@"%@",ticketlogs.loggedThru);
			NSLog(@"%@",ticketlogs.note);
			NSLog(@"%@",ticketlogs.isPrivate);
			NSLog(@"%@",ticketlogs.minutesSpent);
		}
		
		NSLog(@"\n\n\n\n\n-------------------------------");
	}
	[ticketArray retain];
}	
+(NSMutableArray *)ticketArr
{
	if (ticketArray) {
		
		return ticketArray;
	}
	else {
		return nil;
	}
	
}
+(NSMutableArray *)geterror_arr
{
	if (errordetails) {
		
		return errordetails;
	}
	else {
		return nil;
	}
	
}
+(BOOL)gethasMoreRecords
{
	if (hasMoreRecords) {
		
		return hasMoreRecords;
	}
	else {
		return NO;
	}
	
}

@end
