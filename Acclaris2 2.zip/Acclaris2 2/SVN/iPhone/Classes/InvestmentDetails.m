//
//  InvestmentDetails.m
//  Acclaris
//
//  Created by Sumit Kr Prasad on 31/12/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "InvestmentDetails.h"


@implementation InvestmentDetails
-(id)initWithInvestmentArr:(NSMutableArray *)investmentArr
{
	self=[super init];
		
	
	return self;
}
@end
