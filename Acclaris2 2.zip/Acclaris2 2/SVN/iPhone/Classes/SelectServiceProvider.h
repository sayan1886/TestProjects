//
//  SelectServiceProvider.h
//  Acclaris
//
//  Created by Subhojit on 25/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyTools.h"
#import "Decode64.h"
#import "AcclarisAppDelegate.h"
#import "RequestPhase2.h"
#import "passPerser.h"
#import "GetProviderListOBJ.h"
#import "GetProviderListParser.h"
#import "AddProvider.h"
#import "EditProviderdetail.h"
#import "SubmitNewClaimThree.h"
#import "ClaimonlineSaveOBJ.h"
#import "Claimonlineserviceparser.h"
#import "MultipleAccountView.h"
#import "MyScrollView.h"
#import "PaynowClaimsuccess.h"
#import "PaynowcontinueParser.h"


@class configurables;

@interface SelectServiceProvider : UIViewController<UITextFieldDelegate,UITableViewDelegate,UITableViewDataSource> {

	configurables *con;
	MyTools *tools;
	AcclarisAppDelegate *app;
	UIView *loadingView;
	UITextField *txtinvoice;
	UITextField *txtAcount;
	UITextField *txtpaymentreff;
	UITableView *table;
	int Selectedrow;
	NSMutableArray *arrgetProviderdetails;
	NSMutableArray	*userinfo_arr;
	BOOL isprovider;
	BOOL isEdit;
	NSMutableDictionary *Dictclaim;
	int selectedIndex;
	MyScrollView *scroll;
	NSMutableArray *arrclaimsave;
	NSMutableDictionary *roleDict;
	id type;
	NSString *strAddress;
	int he;
	NSMutableArray *arrtabcontent;
	
}

-(void)Deletepayee;
-(void)createView;
-(void)signout;
-(void)createConnectionforAddprovider;
//-(id)initwithDict:(NSMutableDictionary *)dict;
-(void)Saveclaimfrompaynow;
-(id)initwithDict:(NSMutableDictionary *)dict withtype:(id)typ;

-(void)Saveclaim;


@end
