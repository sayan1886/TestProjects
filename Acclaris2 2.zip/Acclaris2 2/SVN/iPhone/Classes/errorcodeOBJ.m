//
//  errorcodeOBJ.m
//  Acclaris
//
//  Created by Sayan banerjee on 21/11/10.
//  Copyright 2010 Objectsol. All rights reserved.
//

#import "errorcodeOBJ.h"


@implementation errorcodeOBJ
@synthesize returnCode;
@synthesize errorText;
@end
