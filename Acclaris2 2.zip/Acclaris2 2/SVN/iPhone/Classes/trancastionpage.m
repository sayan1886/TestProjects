    //
//  trancastion.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 19/10/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import "trancastionpage.h"
#import "transactionDetailsPage.h"
#import "configurables.h"
#import "transactionOBJ.h"
#import "transactionPerser.h"
#import "InvestmentParser.h"
#import "InvestmentObj.h"
#import "UserresponcePerser.h"
#import "configurableParser.h"
#import "Decode64.h"
#import "AcclarisViewController.h"
NSInteger transactionselectedRow;
@implementation trancastionpage
-(id)initWithArrayName:(NSMutableArray *)arr
{
	self=[super init];
	transaction_info=[[NSMutableArray alloc]init];
	transaction_info=arr;
	return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
	
	tools=[[MyTools alloc]init];
	loadingView=[tools createActivityIndicator1];
	
	
	NSMutableArray *arr_myconfig=[AcclarisViewController staticarr_config];//[configurableParser getconfig_arr];//
	[arr_myconfig retain];
	con=(configurables *)[arr_myconfig objectAtIndex:0];
	[con retain];
	self.view.backgroundColor = [UIColor colorWithRed:con.bgRed/255.0f green:con.bgGreen/255.0f blue:con.bgBlue/255.0f alpha:1.0];
	
	mytransactionOBJ=[[transactionOBJ alloc]init];
	
	
	//NSMutableArray *my_arrUserinfo=[UserresponcePerser userdesc];
	UIImageView *logo_img = [[UIImageView alloc]initWithFrame:CGRectMake(0, 2, 170, 40)];
	NSData *data=[Base64 decode:con.logoImgdata];
	logo_img.image=	[UIImage imageWithData:[NSData dataWithData:data]];
	self.navigationItem.titleView=logo_img;
	
	
	
	/*bt_previous=[UIButton buttonWithType:UIButtonTypeCustom];
	 bt_previous.frame = CGRectMake(0,308+25, 70, 30);
	 [bt_previous setBackgroundImage:[UIImage imageNamed: @"green-button.png"] forState:UIControlStateNormal];
	 bt_previous.titleLabel.font = [UIFont fontWithName:con.btnfontname size:con.btnfontsize];
	 [bt_previous setTitle:@"previous" forState:UIControlStateNormal];
	 [bt_previous setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	 [bt_previous addTarget:self action:@selector(previous) forControlEvents:UIControlEventTouchUpInside];
	 //bt_previous.enabled=NO;
	bt_previous.hidden=YES;
	 [self.view addSubview:bt_previous];
	 
	 bt_next=[UIButton buttonWithType:UIButtonTypeCustom];
	 bt_next.frame = CGRectMake(320-70,308+25, 70, 30);
	 [bt_next setBackgroundImage:[UIImage imageNamed: @"green-button.png"] forState:UIControlStateNormal];
	 bt_next.titleLabel.font = [UIFont fontWithName:con.btnfontname size:con.btnfontsize];
	 [bt_next setTitle:@"next" forState:UIControlStateNormal];
	 [bt_next setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	 [bt_next addTarget:self action:@selector(next) forControlEvents:UIControlEventTouchUpInside];
	 [self.view addSubview:bt_next];
	bt_next.hidden=YES;*/
	
	bt_previous=[UIButton buttonWithType:UIButtonTypeCustom];
	bt_previous.frame = CGRectMake(0,308+25, 50, 30);
	NSData *data_btnimg=[Base64 decode:con.btnNavImgData];
	[bt_previous setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
	bt_previous.titleLabel.font = [UIFont fontWithName:con.btnNavFontName size:con.btnNavFontSize];
	[bt_previous setTitle:@"<<" forState:UIControlStateNormal];
	[bt_previous setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	[bt_previous addTarget:self action:@selector(previous) forControlEvents:UIControlEventTouchUpInside];
	//bt_previous.enabled=NO;
	bt_previous.hidden=YES;
	[self.view addSubview:bt_previous];
	
	bt_next=[UIButton buttonWithType:UIButtonTypeCustom];
	bt_next.frame = CGRectMake(320-50,308+25, 50, 30);
	[bt_next setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
	bt_next.titleLabel.font = [UIFont fontWithName:con.btnNavFontName size:con.btnNavFontSize];
	[bt_next setTitle:@">>" forState:UIControlStateNormal];
	[bt_next setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	[bt_next addTarget:self action:@selector(next) forControlEvents:UIControlEventTouchUpInside];
	[self.view addSubview:bt_next];
	bt_next.hidden=YES;
	
	str_startID1=@"0";
	
	
	
	[self fetchTransaction];
	[self signoutbt];
	[self createtableview];
		
}
-(void)fetchTransaction
{
	
	 NSMutableArray *userinfo_arr=[passPerser passresponce];
	 [tools startLoading:self.view childView:loadingView text:@"Fetching Transaction. Wait…."];
	 request *r=[[request alloc] initWithTarget:self
	 SuccessAction:@selector(onSucceffulLogin)
	 FailureAction:@selector(onFailureLogin)];
	
	if ([[transaction_info objectAtIndex:2]isEqualToString:@"Investment" ])///If investment Of HSA call this webservice (FOR SUMIT)
	{
		isInvestment=YES;
		[r sendHSA_InvestmenttransactionRequest:[userinfo_arr objectAtIndex:2] userid:[userinfo_arr objectAtIndex:4] election:[transaction_info objectAtIndex:0] actype:[transaction_info objectAtIndex:1] startid:str_startID1];

	}
	else {
		isInvestment=NO;
		[r sendtransactionRequest:[userinfo_arr objectAtIndex:2] userid:[userinfo_arr objectAtIndex:4] election:[transaction_info objectAtIndex:0] actype:[transaction_info objectAtIndex:1] startid:str_startID1];

	}

	
	 [r release];
}
-(void)onSucceffulLogin
{
	if (isInvestment)
	{
		arr_alltransaction=[InvestmentParser get_arr_investment];
	}
	else 
	{
		arr_alltransaction=[transactionPerser get_arr_transaction];
	}
		
	
	if ([arr_alltransaction count]==0)
	{
		
		//Suvo Paglu
		NSDictionary *customMessageList_dict=[[NSUserDefaults standardUserDefaults] objectForKey:@"customMessageList"];
		
		NSString *strmessage=[[customMessageList_dict valueForKey:@"200003"]valueForKey:@"message"];
		NSString *strtype=[[customMessageList_dict valueForKey:@"200003"]valueForKey:@"type"];
		
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:strtype message:strmessage delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
		[alert show];
		[alert release];
		return ;
	}
	BOOL morerec=NO;
	if(isInvestment)
	{
		morerec=[InvestmentParser gethasMoreRecords_investment];
	}
	else {
		morerec=[transactionPerser gethasMoreRecords_transaction];
	}

	
	if (!morerec)
	{
		//bt_next.enabled=NO;
		bt_next.hidden=YES;
	}
	else {
		
		bt_next.hidden=NO;
	}

	
	[acctable reloadData];
	[tools stopLoading:loadingView];
}
-(void)onFailureLogin
{
	[tools stopLoading:loadingView];
}
-(void)previous
{
	if (startID<=0)
	{
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Sorry" message:@"No Previous Records" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
		[alert show];
		[alert release];
		startID=0;
		return ;
	}
	if (startID<=5)
	{
		//bt_previous.enabled=NO;
		bt_previous.hidden=YES;
	}
	
	startID-=5;
	str_startID1=@"";
	str_startID1=[str_startID1 stringByAppendingFormat:@"%d",startID];
	[str_startID1 retain];
	//bt_next.enabled=YES;
	bt_next.hidden=NO;
	[self fetchTransaction]; 
	
}
-(void)next
{
	startID+=5;
	str_startID1=@"";
	str_startID1=[str_startID1 stringByAppendingFormat:@"%d",startID];
	[str_startID1 retain];
	//bt_previous.enabled=YES;
	bt_previous.hidden=NO;
	[self fetchTransaction];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	if (buttonIndex==0)
	{
		[self.navigationController popViewControllerAnimated:YES];
	}
	
}

-(void)signoutbt
{
	UIBarButtonItem *signoutButton = [[UIBarButtonItem alloc]
									  initWithTitle:@"Sign Off"
									  style:UIBarButtonItemStyleBordered
									  target:self
									  action:@selector(signout)];
    self.navigationItem.rightBarButtonItem =signoutButton;
}
-(void)signout
{
	[((AcclarisAppDelegate *)[[UIApplication sharedApplication] delegate]) removeTabBar];
}

-(void)createtableview
{
	acctable=[[UITableView alloc] initWithFrame:CGRectMake(0,0,320,320) style:UITableViewStyleGrouped];
	acctable.delegate = self;
	acctable.dataSource = self;
	acctable.scrollEnabled = YES;
	acctable.autoresizesSubviews = YES;
	acctable.showsVerticalScrollIndicator=YES;
	acctable.showsHorizontalScrollIndicator=YES;
	acctable.backgroundColor=[UIColor clearColor];
	
	[self.view addSubview:acctable];	
}
#pragma mark tableView delegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView  
{
	return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	
	return [arr_alltransaction  count];
	
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{  
	static NSString *CellIdentifier = @"Cell";
	static NSString *CellIdentifier1 = @"Cell1";
	UITableViewCell *cell;
	
	if(cell==nil)
	{
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier] autorelease];
	}
	else
	{
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier1];
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier1] autorelease];
		
	}
	cell.selectionStyle=UITableViewCellSelectionStyleBlue;
	cell.backgroundColor=[UIColor whiteColor];
	
	cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;		
	
	if(isInvestment)
	{
		UILabel *cellTransactionTypeText=[[UILabel alloc]initWithFrame:CGRectMake(15,5,150,20)];
		cellTransactionTypeText.font=[UIFont fontWithName:con.fontname size:con.fontsize];
		cellTransactionTypeText.backgroundColor=[UIColor clearColor];
		cellTransactionTypeText.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
		cellTransactionTypeText.text =((InvestmentObj *)[arr_alltransaction objectAtIndex:indexPath.row]).transactionType ;
		[cell addSubview:cellTransactionTypeText];
		cellTransactionTypeText.text=[cellTransactionTypeText.text stringByAppendingString:@":"];
	}
	
	UILabel *cellLabelText=[[UILabel alloc]initWithFrame:CGRectMake(9,5,150,20)];
	NSString *strFont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];
	cellLabelText.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
	cellLabelText.backgroundColor=[UIColor clearColor];
	cellLabelText.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
	if(isInvestment)
	{
		cellLabelText.frame=CGRectMake(40, 5, 150, 20);
		cellLabelText.text =((InvestmentObj *)[arr_alltransaction objectAtIndex:indexPath.row]).optyprDesc ;
	}
	else {
		cellLabelText.text =((transactionOBJ *)[arr_alltransaction objectAtIndex:indexPath.row]).transactionDescription ;
	}

	//[[app.arr_transaction objectAtIndex:indexPath.row] objectAtIndex:2];
	[cell.contentView addSubview:cellLabelText];
	
	UILabel *cellLabeldate=[[UILabel alloc]initWithFrame:CGRectMake(9,30,150,20)];
	
	cellLabeldate.font=[UIFont fontWithName:con.fontname size:con.bodyfntsize];
	cellLabeldate.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];

	cellLabeldate.backgroundColor=[UIColor clearColor];
	if(isInvestment)
	{
		cellLabeldate.text = ((InvestmentObj *)[arr_alltransaction objectAtIndex:indexPath.row]).date;
	}
	else 
	{
		cellLabeldate.text = ((transactionOBJ *)[arr_alltransaction objectAtIndex:indexPath.row]).transactionDate;
	}
	[cell.contentView addSubview:cellLabeldate];
	
	
	UILabel *cellLabelammount=[[UILabel alloc]initWithFrame:CGRectMake(205,20,80,20)];
//	NSString *strFont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];
	cellLabelammount.font=[UIFont fontWithName:strFont size:con.bodyfntsize];
	
	cellLabelammount.backgroundColor=[UIColor clearColor];

	NSString *str=nil;
	if(isInvestment)
	{
		str=[self chkvalue:((InvestmentObj *)[arr_alltransaction objectAtIndex:indexPath.row]).amount];
	}
	else {
		str=[self chkvalue:((transactionOBJ *)[arr_alltransaction objectAtIndex:indexPath.row]).transactionAmount];
	}

	
	cellLabelammount.text = str;
	if(isInvestment)
	{
		if([((InvestmentObj *)[arr_alltransaction objectAtIndex:indexPath.row]).amount floatValue]<0)
		{
			
			cellLabelammount.textColor=[UIColor colorWithRed:con.ngtvRed/255.0f green:con.ngtvGreen/255.0f blue:con.ngtvBlue/255.0f alpha:1.0];
		}
		else 
		{
			cellLabelammount.textColor=[UIColor colorWithRed:con.posnumRed/255.0f green:con.posnumGreen/255.0f blue:con.posnumBlue/255.0f alpha:1.0];
		}
	}
	else 
	{
		if([((transactionOBJ *)[arr_alltransaction objectAtIndex:indexPath.row]).transactionAmount floatValue]<0)
		{
			
			cellLabelammount.textColor=[UIColor colorWithRed:con.ngtvRed/255.0f green:con.ngtvGreen/255.0f blue:con.ngtvBlue/255.0f alpha:1.0];
		}
		else 
		{
			cellLabelammount.textColor=[UIColor colorWithRed:con.posnumRed/255.0f green:con.posnumGreen/255.0f blue:con.posnumBlue/255.0f alpha:1.0];
		}
	}
	[cell.contentView addSubview:cellLabelammount];
	
	return cell;
	
	
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return 65;
	
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	transactionselectedRow=indexPath.row;
	if(isInvestment)
	{
		transactionDetailsPage *mytrancastion = [[transactionDetailsPage alloc] initWithInvestment:YES];
		[self.navigationController pushViewController:mytrancastion animated:YES];
	}
	else 
	{
		transactionDetailsPage *mytrancastion = [[transactionDetailsPage alloc] init];
		[self.navigationController pushViewController:mytrancastion animated:YES];	
	}
}
+(NSInteger)getSelectedRow
{
	if (transactionselectedRow) {
		return transactionselectedRow;
	}
	else {
		return 0;
	}

}
-(NSString *)chkvalue:(NSString *)value
{
	NSString *newvalue=@"";
	if([value intValue]>=0)
	{
		newvalue=[newvalue stringByAppendingString:con.ptvPrefix];
		newvalue=[newvalue stringByAppendingString:value];
	}
	else {
		value=[value substringFromIndex:1];
		newvalue=[newvalue stringByAppendingString:con.ngtvPrefix];
		newvalue=[newvalue stringByAppendingString:value];
		newvalue=[newvalue stringByAppendingString:con.ngtvSufix];
		
	}
	return newvalue;
}


- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
