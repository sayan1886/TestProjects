//
//  denialReasonShow.h
//  Acclaris
//
//  Created by Ayon on 16/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AcclarisAppDelegate.h"
#import "MyTools.h"
@class configurables;

@interface denialReasonShow : UIViewController<UITableViewDelegate,UITableViewDataSource>
{
	MyTools *tools;
	AcclarisAppDelegate *app;
	UIView *loadingView;
	configurables *con;
	NSMutableArray *arr_celltytle;
	NSArray *arr_celltext;
	NSInteger selectedrow;
}
-(void)backbt;
-(void)signoutbt;
-(void)createtableview;
-(void)createHeader;
@end
