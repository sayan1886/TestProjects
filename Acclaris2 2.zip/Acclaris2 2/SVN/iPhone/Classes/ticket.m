    //
//  ticket.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 06/10/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import "ticket.h"
#import "request.h"
#import "ticketPerser.h"
#import "ticketOBJ.h"
#import "ticketDetails.h"
#import "ticketNew.h"
#import "configurables.h"
#import "UserresponcePerser.h"
#import "Decode64.h"
#import "passPerser.h"
#import "configurableParser.h"
#import "AcclarisViewController.h"

NSInteger ticketselectedRow;
NSString *str_startID;
@implementation ticket

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/
-(id)initWithTabBar:(NSString *)label
{
	if([self init])
	{
		//this is the label on tab button itself
		self.title=label;
		
		self.tabBarItem.image=[UIImage imageNamed:@"Messages.png"];
		
	}
	return self;
}


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	self.view.backgroundColor=[UIColor whiteColor];
	tools=[[MyTools alloc]init];
	loadingView=[tools createActivityIndicator1];
	

	
	NSMutableArray *arr_myconfig=[AcclarisViewController staticarr_config];//[configurableParser getconfig_arr];//
	con=(configurables *)[arr_myconfig objectAtIndex:0];
	
	self.navigationController.navigationBar.tintColor=[UIColor colorWithRed:con.navbarRed/255.0f green:con.navbarGreen/255.0f blue:con.navbarBlue/255.0f alpha:1.0];
	self.view.backgroundColor = [UIColor colorWithRed:con.bgRed/255.0f green:con.bgGreen/255.0f blue:con.bgBlue/255.0f alpha:1.0];
		
	arr_celltytle=[[NSMutableArray alloc]init];
	
	self.navigationItem.title=@"Back";
	
	[self signoutbt];
	startID=0;
	str_startID=@"0";
	
	
	
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	
	
	
	UITabBarItem *tbi = (UITabBarItem *)[app.tabBarController.viewControllers objectAtIndex:2];
	tbi.badgeValue = @"2";
	
	
	
	//NSMutableArray *my_arrUserinfo=[UserresponcePerser userdesc];
	UIImageView *logo_img = [[UIImageView alloc]initWithFrame:CGRectMake(0, 2, 170, 40)];
	NSData *data=[Base64 decode:con.logoImgdata];
	logo_img.image=	[UIImage imageWithData:[NSData dataWithData:data]];
	self.navigationItem.titleView=logo_img;
	NSData *data_btnimg=[Base64 decode:con.btnImgdata];
	NSMutableDictionary *roleDict=[passPerser getRolebaseDict];
	
	if ([[roleDict valueForKey:@"NEWMESSAGE"]isEqualToString:@"Yes"]) {

		UIButton *btn_sendBack=[UIButton buttonWithType:UIButtonTypeCustom];
		btn_sendBack.frame = CGRectMake(70, 308, 234-50, 47);
		
		
		[btn_sendBack setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
		btn_sendBack.titleLabel.font = [UIFont fontWithName:con.btnfontname size:con.btnfontsize];
		[btn_sendBack setTitle:[roleDict valueForKey:@"NEWMESSAGELabel"] forState:UIControlStateNormal];
		[btn_sendBack setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
		[btn_sendBack addTarget:self action:@selector(sendMsg) forControlEvents:UIControlEventTouchUpInside];
		[self.view addSubview:btn_sendBack];
	
	}
	
	/*bt_previous=[UIButton buttonWithType:UIButtonTypeCustom];
	bt_previous.frame = CGRectMake(0, 308-35, 70, 30);
	[bt_previous setBackgroundImage:[UIImage imageNamed: @"green-button.png"] forState:UIControlStateNormal];
	bt_previous.titleLabel.font = [UIFont fontWithName:con.btnNavFontName size:con.btnNavFontSize];
	[bt_previous setTitle:@"previous" forState:UIControlStateNormal];
	[bt_previous setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	[bt_previous addTarget:self action:@selector(previous) forControlEvents:UIControlEventTouchUpInside];
	//bt_previous.enabled=NO;
	bt_previous.hidden=YES;
	[self.view addSubview:bt_previous];

    bt_next=[UIButton buttonWithType:UIButtonTypeCustom];
    bt_next.frame = CGRectMake(320-70,308-35, 70, 30);
    [bt_next setBackgroundImage:[UIImage imageNamed: @"green-button.png"] forState:UIControlStateNormal];
	bt_next.titleLabel.font = [UIFont fontWithName:con.btnNavFontName size:con.btnNavFontSize];
    [bt_next setTitle:@"next" forState:UIControlStateNormal];
    [bt_next setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	[bt_next addTarget:self action:@selector(next) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:bt_next];
	bt_next.hidden=YES;
	 */
	bt_previous=[UIButton buttonWithType:UIButtonTypeCustom];
	bt_previous.frame = CGRectMake(3, 318, 50, 30);
	data_btnimg=[Base64 decode:con.btnNavImgData];
	[bt_previous setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
	bt_previous.titleLabel.font = [UIFont fontWithName:con.btnNavFontName size:con.btnNavFontSize];
	[bt_previous setTitle:@"<<" forState:UIControlStateNormal];
	[bt_previous setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	[bt_previous addTarget:self action:@selector(previous) forControlEvents:UIControlEventTouchUpInside];
	//bt_previous.enabled=NO;
	bt_previous.hidden=YES;
	[self.view addSubview:bt_previous];
	
    bt_next=[UIButton buttonWithType:UIButtonTypeCustom];
    bt_next.frame = CGRectMake(265,318, 50, 30);
    [bt_next setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
	bt_next.titleLabel.font = [UIFont fontWithName:con.btnNavFontName size:con.btnNavFontSize];
    [bt_next setTitle:@">>" forState:UIControlStateNormal];
    [bt_next setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	[bt_next addTarget:self action:@selector(next) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:bt_next];
	bt_next.hidden=YES;
	
	
	[self reqTicket];
	
	
	 
}
-(void)sendMsg
{
	ticketNew *myticketNew = [[ticketNew alloc] init];
	[self.navigationController pushViewController:myticketNew animated:YES];
}
-(void)previous
{
	if (startID<=0)
	{
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Sorry" message:@"No Previous Records" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
		[alert show];
		[alert release];
		startID=0;
		return ;
	}
	if (startID<=5)
	{
		//bt_previous.enabled=NO;
		bt_previous.hidden=YES;
	}
	

			
	startID-=5;
	str_startID=@"";
	str_startID=[str_startID stringByAppendingFormat:@"%d",startID];
	[str_startID retain];
	[acctable removeFromSuperview];
	//bt_next.enabled=YES;
	bt_next.hidden=NO;
	[self reqTicket];
	
}
-(void)next
{
	startID+=5;
	str_startID=@"";
	str_startID=[str_startID stringByAppendingFormat:@"%d",startID];
	[str_startID retain];
	[acctable removeFromSuperview];
	//bt_previous.enabled=YES;
	bt_previous.hidden=NO;
	[self reqTicket];
}


-(void)reqTicket
{
	NSMutableArray *userinfo_arr=[passPerser passresponce];//static method fired
	request *r=[[request alloc] initWithTarget:self
								 SuccessAction:@selector(onSucceffulLogin)
								 FailureAction:@selector(onFailureLogin)];
	[r sendticketRequest:str_startID participentid:[userinfo_arr objectAtIndex:2] userid:[userinfo_arr objectAtIndex:4]];
	[r release];
	[tools startLoading:self.view childView:loadingView text:@"Loading your Messages. Wait…."];
	
}

-(void)onSucceffulLogin
{
	[tools stopLoading:loadingView];
	arr_celltytle=[ticketPerser ticketArr];
	
	
	BOOL morerec=[ticketPerser gethasMoreRecords];
	if (!morerec)
	{
		bt_next.hidden=YES;
		//bt_previous.hidden=YES;
		
	}
	else {
		bt_next.hidden=NO;
	}

	if ([arr_celltytle count]==0) 
	{
		/*UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Sorry" message:@"“Currently no data available, please visit again later”" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
		[alert show];
		[alert release];*/
		
		UIView	*view_rounded = [[UIView alloc]initWithFrame:CGRectMake(18, 14, 280, 270)];
		view_rounded.backgroundColor = [UIColor whiteColor];
		view_rounded.layer.cornerRadius=19;
		view_rounded.layer.borderWidth=1.5;
		CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();	
		float grayComponents[4] = { 0.3, 0.3, 0.3, 1.0 };
		view_rounded.layer.borderColor=CGColorCreate(colorSpace, grayComponents);
		//view_rounded.backgroundColor=[UIColor colorWithRed:con.bgRed2/255.0f green:con.bgGreen2/255.0f blue:con.bgBlue2/255.0f alpha:1.0];
		[self.view addSubview:view_rounded];
		
		NSDictionary *customMessageList_dict=[[NSUserDefaults standardUserDefaults] objectForKey:@"customMessageList"];
		NSString *strmessage=[[customMessageList_dict valueForKey:@"200003"]valueForKey:@"message"];
		
		UILabel *lblNoData=[[[UILabel alloc] initWithFrame:CGRectMake(0, 20, 280, 30)]autorelease];
		lblNoData.text=strmessage;
		lblNoData.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
		lblNoData.font=[UIFont fontWithName:con.fontname size:con.fontsize];
		lblNoData.textAlignment=UITextAlignmentCenter;
		lblNoData.backgroundColor=[UIColor clearColor];
		[view_rounded addSubview:lblNoData];
		 
		return ;
		
	}
	
	[self createtableview];
	

}

-(void)onFailureLogin
{
	[tools stopLoading:loadingView];
}


-(void)signoutbt
{
	UIBarButtonItem *signoutButton = [[UIBarButtonItem alloc]
									  initWithTitle:@"Sign Off"
									  style:UIBarButtonItemStyleBordered
									  target:self
									  action:@selector(signout)];
    self.navigationItem.rightBarButtonItem =signoutButton;
}
-(void)signout
{
	[((AcclarisAppDelegate *)[[UIApplication sharedApplication] delegate]) removeTabBar];
}
-(void)createtableview
{
	acctable=[[UITableView alloc] initWithFrame:CGRectMake(0,0,320,270+20) style:UITableViewStyleGrouped];
	acctable.delegate = self;
	acctable.dataSource = self;
	acctable.scrollEnabled = YES;
	acctable.autoresizesSubviews = YES;
	acctable.showsVerticalScrollIndicator=YES;
	acctable.showsHorizontalScrollIndicator=YES;
	acctable.backgroundColor=[UIColor clearColor];
	[self.view addSubview:acctable];	
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView  
{
	return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	
	return [arr_celltytle  count];
	
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{  
	static NSString *CellIdentifier = @"Cell";
	static NSString *CellIdentifier1 = @"Cell1";
	UITableViewCell *cell;
	
	if(cell==nil)
	{
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier] autorelease];
	}
	else
	{
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier1];
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier1] autorelease];
		
	}
	cell.selectionStyle=UITableViewCellSelectionStyleNone;
	cell.backgroundColor=[UIColor whiteColor];
	
	cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;		
	
	UILabel *cellLabelText=[[UILabel alloc]initWithFrame:CGRectMake(10,10,300,20)];
	NSString *strFont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];
	cellLabelText.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
	cellLabelText.backgroundColor=[UIColor clearColor];
	cellLabelText.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
	cellLabelText.text =((ticketOBJ *)[ arr_celltytle objectAtIndex:indexPath.row]).causeNote;
	[cell.contentView addSubview:cellLabelText];
	[cellLabelText release];
		
	UILabel *cellLabelcreatedOn=[[UILabel alloc]initWithFrame:CGRectMake(19,40,150,20)];
    strFont=con.fontname;
	cellLabelcreatedOn.font=[UIFont fontWithName:strFont size:con.bodyfntsize];
	cellLabelcreatedOn.backgroundColor=[UIColor clearColor];
	cellLabelcreatedOn.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
	cellLabelcreatedOn.text = ((ticketOBJ *)[ arr_celltytle objectAtIndex:indexPath.row]).createdOn;
	[cell.contentView addSubview:cellLabelcreatedOn];
	[cellLabelcreatedOn release];
	
	UILabel *cellLabelstatus=[[UILabel alloc]initWithFrame:CGRectMake(200,30,80,20)];
    strFont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];
	cellLabelstatus.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
	cellLabelstatus.backgroundColor=[UIColor clearColor];
	
	cellLabelstatus.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
	cellLabelstatus.text = ((ticketOBJ *)[ arr_celltytle objectAtIndex:indexPath.row]).status;
	[cell.contentView addSubview:cellLabelstatus];
	[cellLabelstatus release];
	
	
	return cell;
	
	
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	
	return 70;
	
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	ticketselectedRow=indexPath.row;
	ticketDetails *myticketDetails = [[ticketDetails alloc] init];
	[self.navigationController pushViewController:myticketDetails animated:YES];
	
}
-(void)viewWillAppear:(BOOL)animated
{
	arr_celltytle=[ticketPerser ticketArr];
	[acctable reloadData];
}

+(NSInteger)getSelectedRow
{
	if (ticketselectedRow) {
		return ticketselectedRow;
	}
	else {
		return 0;
	}
	
}
+(NSString *)getSelectedpage
{
	if (str_startID) {
		return str_startID;
	}
	else {
		return 0;
	}
	
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
    [super dealloc];
}


@end
