    //
//  ticketDescDetails.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 26/10/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import "ticketDescDetails.h"
#import "ticket.h"
#import "ticketPerser.h"
#import "ticketLogsOBJ.h"
#import "UserresponcePerser.h"
#import "Decode64.h"
#import "configurables.h"
#import "configurableParser.h"
#import "AcclarisViewController.h"
@implementation ticketDescDetails

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	
	NSMutableArray *my_arrUserinfo=[UserresponcePerser userdesc];
	UIImageView *logo_img = [[UIImageView alloc]initWithFrame:CGRectMake(0, 2, 170, 40)];
	//NSData *data=[Base64 decode:[my_arrUserinfo objectAtIndex:3]];
	logo_img.image=	[UIImage imageWithData:con.logoImgdata];
	self.navigationItem.titleView=logo_img;
	
	NSMutableArray *arr_myconfig=[AcclarisViewController staticarr_config];//[configurableParser getconfig_arr];//
	con=(configurables *)[arr_myconfig objectAtIndex:0];	
	self.view.backgroundColor = [UIColor colorWithRed:con.bgRed/255.0f green:con.bgGreen/255.0f blue:con.bgBlue/255.0f alpha:1.0];	
	self.navigationItem.title=@"Back";

	
	selectedRow=[ticket getSelectedRow];
	arr_celltytle=[ticketPerser ticketArr];
	[arr_celltytle retain];
	
	//ticketTableArrlabel=[[NSArray alloc]initWithObjects:@"Created By",@"Resolved By",nil];
	//ticketTableArr=[[NSArray alloc]initWithObjects:((ticketOBJ *)[ arr_celltytle objectAtIndex:selectedRow]).createdBy,((ticketOBJ *)[ arr_celltytle objectAtIndex:selectedRow]).resolvedBy,((ticketOBJ *)[ arr_celltytle objectAtIndex:selectedRow]).resolutionNote,nil];
	
	tickets=((ticketOBJ *)[ arr_celltytle objectAtIndex:selectedRow]);
	arrm_ticketLOGS=tickets.arrm_logs;
	
	
	
	UIButton *btn_backtoMSG=[UIButton buttonWithType:UIButtonTypeRoundedRect];
	btn_backtoMSG.frame = CGRectMake(43, 308, 234, 47);
	NSData *data_btnimg=[Base64 decode:con.btnImgdata];
	[btn_backtoMSG setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
	btn_backtoMSG.titleLabel.font = [UIFont fontWithName:con.fontname size:con.fontsize];
	[btn_backtoMSG setTitle:@"Back to message" forState:UIControlStateNormal];
	[btn_backtoMSG setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn_backtoMSG addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];
	[self.view addSubview:btn_backtoMSG];
	
	
	[self signoutbt];

	
	[self createtableview];
		
}
-(void)signoutbt
{
	UIBarButtonItem *signoutButton = [[UIBarButtonItem alloc]
									  initWithTitle:@"Sign Off"
									  style:UIBarButtonItemStyleBordered
									  target:self
									  action:@selector(signout)];
    self.navigationItem.rightBarButtonItem =signoutButton;
}
-(void)signout
{
	[((AcclarisAppDelegate *)[[UIApplication sharedApplication] delegate]) removeTabBar];
}
-(void)backAction
{
	[self.navigationController popToRootViewControllerAnimated:YES];
}
-(void)createtableview
{
	UITableView	*acctable=[[UITableView alloc] initWithFrame:CGRectMake(0,0,320,300) style:UITableViewStyleGrouped];
	acctable.delegate = self;
	acctable.dataSource = self;
	acctable.scrollEnabled = YES;
	acctable.autoresizesSubviews = YES;
	acctable.showsVerticalScrollIndicator=YES;
	acctable.showsHorizontalScrollIndicator=YES;
	acctable.backgroundColor=[UIColor clearColor];
	[self.view addSubview:acctable];	
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView  
{
	return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	
	
	if (arrm_ticketLOGS && [arrm_ticketLOGS count]>0) {
		//NSLog(@"%d\n",[arrm_ticketLOGS count]);
		//NSLog(@"%@",arrm_ticketLOGS);
		return [arrm_ticketLOGS count];
	}
	else {
		
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Sorry" message:@"“Currently no data available, please visit again later”" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
		[alert show];
		[alert release];
		return 0;
	}

}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{  
	static NSString *CellIdentifier = @"Cell";
	static NSString *CellIdentifier1 = @"Cell1";
	UITableViewCell *cell;
	
	if(cell==nil)
	{
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier] autorelease];
	}
	else
	{
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier1];
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier1] autorelease];
		
	}
	cell.selectionStyle=UITableViewCellSelectionStyleNone;
	cell.backgroundColor=[UIColor whiteColor];
	
	
	ticketLogsOBJ *ticketLogs=(ticketLogsOBJ *)[arrm_ticketLOGS objectAtIndex:indexPath.row];
	NSString *str=@"";
	
	str=[str stringByAppendingString:ticketLogs.action];
	str=[str stringByAppendingString:@" By: "];
    
	
	int x=[str length];
	UILabel *cellLabelText=[[UILabel alloc]initWithFrame:CGRectMake(19,5,x*10,20)];
	NSString *strFont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];
	cellLabelText.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
	cellLabelText.text =str;
	cellLabelText.backgroundColor=[UIColor clearColor];
	[cell.contentView addSubview:cellLabelText];
	[cellLabelText release];
	
	
	UILabel	*cellLabelName=[[UILabel alloc]init];
	cellLabelName.frame=CGRectMake(19+x*8, 5, 100, 20);//100
	cellLabelName.text=ticketLogs.loggedBy;
	cellLabelName.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
	cellLabelName.font=[UIFont fontWithName:con.fontname size:con.bodyfntsize];
	[cell.contentView addSubview:cellLabelName];
	[cellLabelName release];
	
	
	float hight=[self calculateLine:ticketLogs.note fname:con.fontname fsize:con.bodyfntsize widthGiven:260];	

	UILabel *cellLabelstatus=[[UILabel alloc]initWithFrame:CGRectMake(15,40,260,hight*20)];
	cellLabelstatus.font=[UIFont fontWithName:con.fontname size:con.bodyfntsize];
	cellLabelstatus.textAlignment=UITextAlignmentLeft;
	cellLabelstatus.backgroundColor=[UIColor clearColor];
	cellLabelstatus.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
	cellLabelstatus.numberOfLines=0;
	//NSString *newStringmsg = [ticketLogs.note stringByTrimmingCharactersInSet: [NSCharacterSet whitespaceCharacterSet]];
	cellLabelstatus.text =ticketLogs.note; 
	[cell.contentView addSubview:cellLabelstatus];
	[cellLabelstatus release];
	
	
	return cell;
	
	
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	ticketLogsOBJ *ticketLogs=(ticketLogsOBJ *)[arrm_ticketLOGS objectAtIndex:indexPath.row];
	float hight=[self calculateLine:ticketLogs.note fname:con.fontname fsize:con.bodyImpfntsize widthGiven:260];		
	return hight*20+50;
	
}


#pragma mark labelHight

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	if (buttonIndex==0)
	{
		[self.navigationController popViewControllerAnimated:YES];
	}
	
}
//-(int)checkLableLength:(NSString *)str fname:(NSString *)fontName fsize:(NSInteger)fontSize widthGiven:(NSInteger)allowedWidth
//{
//	CGSize stringSize=[str sizeWithFont:[UIFont fontWithName:fontName size:fontSize]];
//	
//	return (stringSize.width/allowedWidth);
//}
//
-(NSInteger)calculateLine:(NSString*)str fname:(NSString *)fontName fsize:(NSInteger)fontSize widthGiven:(NSInteger)allowedWidth
{
	NSInteger index=0;
	NSInteger withValue=0;
	NSInteger lineCounter=0;
	NSInteger withOfLine = 0;
	int l = 0;
	for(;index<str.length;index++)
	{
		withValue++;
		NSString *tmp = [str substringWithRange:NSMakeRange(index, 1)];
		NSString *strCopy;
		if(withValue<str.length-l)
		{
			strCopy = [str substringWithRange:NSMakeRange(l, withValue)];
		}
		CGSize strSize=[strCopy sizeWithFont:[UIFont fontWithName:fontName size:fontSize]];
		int cursorX=strSize.width;
		if([tmp isEqual:@"\n"] || cursorX>=allowedWidth)
		{
			l=index;
			withValue = 0;	
			lineCounter++;
		}
	}
	if(!withOfLine)
	{
		withOfLine = 16;
	}
	if(!lineCounter)
	{
		withOfLine = withValue;
	}
	lineCounter++;
	return lineCounter;
}
/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
