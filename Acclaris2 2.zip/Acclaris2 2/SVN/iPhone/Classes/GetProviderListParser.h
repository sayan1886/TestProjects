//
//  GetProviderListParser.h
//  Acclaris
//
//  Created by Subhojit on 16/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GetProviderListOBJ.h"


@interface GetProviderListParser : NSObject<NSXMLParserDelegate> {

	GetProviderListOBJ *objgetprovobj;
	NSMutableString *contentOfString;
}
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error;
+(NSMutableArray *)arrgetarrproviderlist;
@end
