    //
//  ImageShow.m
//  Acclaris
//
//  Created by Subhojit on 19/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ImageShow.h"
#import "configurables.h"
#import "configurableParser.h"
#import "UserresponcePerser.h"
#import "AcclarisViewController.h"

@implementation ImageShow
-(id)initwitFileid:(NSString *)str
{
	

		self=[super init];
		if(self==nil)
		{
			
			return nil;
		}
		else 
		{
			
			strFileid=str;
			NSLog(@"%@",strFileid);
			
		}
		return self;
		

}
- (void)viewDidLoad {
    [super viewDidLoad];
	
	
	tools=[[MyTools alloc]init];
	loadingView=[tools createActivityIndicator1];
	NSMutableArray *arr_myconfig=[AcclarisViewController staticarr_config];//[configurableParser getconfig_arr];//
	con=(configurables *)[arr_myconfig objectAtIndex:0];
	
	self.navigationController.navigationBar.tintColor=[UIColor colorWithRed:con.navbarRed/255.0f green:con.navbarGreen/255.0f blue:con.navbarBlue/255.0f alpha:1.0];
	self.view.backgroundColor = [UIColor colorWithRed:con.bgRed/255.0f green:con.bgGreen/255.0f blue:con.bgBlue/255.0f alpha:1.0];
	
	//NSMutableArray *my_arrUserinfo=[UserresponcePerser userdesc];
	UIImageView *logo_img = [[UIImageView alloc]initWithFrame:CGRectMake(0, 2, 170, 40)];
	
	NSData *data=[Base64 decode:con.logoImgdata];
	logo_img.image=	[UIImage imageWithData:[NSData dataWithData:data]];
	self.navigationItem.titleView=logo_img;
	
	UIBarButtonItem *signoutButton = [[UIBarButtonItem alloc]
									  initWithTitle:@"Sign Off"
									  style:UIBarButtonItemStyleBordered
									  target:self
									  action:@selector(signout)];
    self.navigationItem.rightBarButtonItem =signoutButton;
	
	
	[self LoadImage];
	
}
-(void)signout
{
	 [((AcclarisAppDelegate *)[[UIApplication sharedApplication] delegate]) removeTabBar];
}
-(void)LoadImage

{
	NSMutableArray *userinfo_arr=[passPerser passresponce];
	RequestPhase2_2 *objrequestPhase2=[[RequestPhase2_2 alloc] initWithTarget:self
															SuccessAction:@selector(onSuccefful)
															FailureAction:@selector(onFailure)];
	
	[objrequestPhase2 ShowImage:[userinfo_arr objectAtIndex:2] uID:[userinfo_arr objectAtIndex:4] fileID:strFileid];
							
	
	[objrequestPhase2 release];
	
	
	
	[tools startLoading:self.view childView:loadingView text:@"Loading your Claim activity. Wait…."];
	
}
-(void)onSuccefful
{
	
	[tools stopLoading:loadingView];
	
	NSMutableArray *arr=[ReceiptShowParser getarrReceipt];
	
	UIImageView *imgv=[[UIImageView alloc]initWithFrame:CGRectMake(0, 30, 350, 320)];
	NSData *data=[Base64 decode:((ReceiptShowOBJ *)[arr objectAtIndex:0]).strimageData];
	imgv.image=[UIImage imageWithData:data];
	[self.view addSubview:imgv];
	
	
}
-(void)onFailure
{
	
	[tools stopLoading:loadingView];
	
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
