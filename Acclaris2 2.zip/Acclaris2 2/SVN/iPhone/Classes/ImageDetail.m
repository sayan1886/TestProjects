    //
//  ImageDetail.m
//  Acclaris
//
//  Created by Subhojit on 19/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ImageDetail.h"
#import "passPerser.h"
#import "request.h"
#import "imagePerser.h"
#import "configurables.h"
#import "configurableParser.h"
#import "UserresponcePerser.h"
#import "Decode64.h"
#import "AcclarisViewController.h"


@implementation ImageDetail

-(id)initWithrowno:(int)row
{
	
	self=[super init];
	if(self==nil)
	{
		
		return nil;
	}
	else 
	{
		
		Selectedrow=row;
		NSLog(@"%d",Selectedrow);
		
	}
	return self;
	
	
	
}
- (void)viewDidLoad {
    [super viewDidLoad];
	
	tools=[[MyTools alloc]init];
	loadingView=[tools createActivityIndicator1];
	NSMutableArray *arr_myconfig=[AcclarisViewController staticarr_config];//[configurableParser getconfig_arr];//
	con=(configurables *)[arr_myconfig objectAtIndex:0];
	
	self.navigationController.navigationBar.tintColor=[UIColor colorWithRed:con.navbarRed/255.0f green:con.navbarGreen/255.0f blue:con.navbarBlue/255.0f alpha:1.0];
	self.view.backgroundColor = [UIColor colorWithRed:con.bgRed/255.0f green:con.bgGreen/255.0f blue:con.bgBlue/255.0f alpha:1.0];
	
	//NSMutableArray *my_arrUserinfo=[UserresponcePerser userdesc];
	UIImageView *logo_img = [[UIImageView alloc]initWithFrame:CGRectMake(0, 2, 170, 40)];
	
	NSData *data=[Base64 decode:con.logoImgdata];
	logo_img.image=	[UIImage imageWithData:[NSData dataWithData:data]];
	self.navigationItem.titleView=logo_img;
	
	arrdetailImageInfo=[imagePerser imageARRresponce];
	
	
	
	

		my=(imagesOBJ *)[arrdetailImageInfo objectAtIndex:Selectedrow];
		
		for (int j=0; j<[my.arrshowimageDetail count]; j++) 
		{
			myShow=(ShowImageDetailsOBJ *)[my.arrshowimageDetail objectAtIndex:j];
			
			NSLog(@"%@",myShow.strfileID);
			NSLog(@"%@",myShow.strfileReceivedOn);
		}
		
	
	[self CreateView];
	[self signoutbt];
	
}
-(void)signoutbt
{
	
	
	UIBarButtonItem *signoutButton = [[UIBarButtonItem alloc]
									  initWithTitle:@"Sign Off"
									  style:UIBarButtonItemStyleBordered
									  target:self
									  action:@selector(signout)];
    self.navigationItem.rightBarButtonItem =signoutButton;
}
-(void)signout
{
	[((AcclarisAppDelegate *)[[UIApplication sharedApplication] delegate]) removeTabBar];
}
-(void)CreateView
{
	
	NSString *strFont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];
	//NSData *data_btnimg=[Base64 decode:con.btnImgdata];//btn background image
	
	table=[[UITableView alloc]initWithFrame:CGRectMake(0, 65, 320, 250+50) style:UITableViewStylePlain];
	table.backgroundColor =[UIColor whiteColor];
	table.bounces =YES;
	table.delegate=self;
	table.dataSource=self;
	table.separatorColor=[UIColor blackColor];
	[self.view addSubview:table];
	
	UIView *HeaderView=[[[UIView alloc]initWithFrame:CGRectMake(0, 0, 320, 60)]autorelease];
	HeaderView.backgroundColor=[UIColor colorWithRed:con.bgRed2/255.0 green:con.bgGreen2/255.0 blue:con.bgBlue2/255.0 alpha:1.0];
	[self.view addSubview:HeaderView];
	
	NSString *strViewTitle=@"File Received on";
	//strViewTitle=[strViewTitle stringByAppendingString:@"\n"];
	//strViewTitle=[strViewTitle stringByAppendingFormat:@"%@",@"Paperless"];
	
	UILabel *lbltext=[[UILabel alloc]initWithFrame:CGRectMake(10, 5, 190, 60)];
	lbltext.text=strViewTitle;
	lbltext.backgroundColor=[UIColor clearColor];
	lbltext.textColor=[UIColor whiteColor];
	lbltext.numberOfLines=0;
	lbltext.font=[UIFont fontWithName:strFont size:con.headerImpfntsize];
	[HeaderView addSubview:lbltext];
	[lbltext release],lbltext=nil;
	
	
	UILabel *lbltextfileid=[[UILabel alloc]initWithFrame:CGRectMake(230, 5, 190, 60)];
	lbltextfileid.text=@"File Id";
	lbltextfileid.backgroundColor=[UIColor clearColor];
	lbltextfileid.textColor=[UIColor whiteColor];
	lbltextfileid.numberOfLines=0;
	lbltextfileid.font=[UIFont fontWithName:strFont size:con.headerImpfntsize];
	[HeaderView addSubview:lbltextfileid];
	[lbltextfileid release],lbltextfileid=nil;
	
	
	
}
/*- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{

	
	return 40.0;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
	
	
	
}*/
	
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView  
{
	
	
	return 1;
	
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	
	return [my.arrshowimageDetail count];
	
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	
	return 55.0;
	
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{  
		static NSString *CellIdentifier = @"Cell";
		static NSString *CellIdentifier1 = @"Cell1";
		UITableViewCell *cell;
		
		if(cell==nil)
		{
			cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
			
			cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier] autorelease];
		}
		else
		{
			cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier1];
			cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier1] autorelease];
			
		}
	
	cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;

	cell.selectionStyle=UITableViewCellSelectionStyleNone;
	cell.contentView.backgroundColor=[UIColor whiteColor];

	NSString  *strFont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];

	UILabel *cellLabeldate=[[UILabel alloc]initWithFrame:CGRectMake(10,3,200,40)];
	cellLabeldate.font=[UIFont fontWithName:strFont size:con.bodyfntsize];
	cellLabeldate.textColor =[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
	cellLabeldate.backgroundColor=[UIColor clearColor];
	cellLabeldate.text =((ShowImageDetailsOBJ *)[my.arrshowimageDetail objectAtIndex:indexPath.row]).strfileReceivedOn;
	//cellLabelclaim.numberOfLines=0;
	[cell.contentView addSubview:cellLabeldate];
	[cellLabeldate release],cellLabeldate=nil; 
	
	
	UILabel *cellLabelFileId=[[UILabel alloc]initWithFrame:CGRectMake(230,3,200,40)];
	cellLabelFileId.font=[UIFont fontWithName:strFont size:con.bodyfntsize];
	cellLabelFileId.textColor =[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
	cellLabelFileId.backgroundColor=[UIColor clearColor];
	cellLabelFileId.text =((ShowImageDetailsOBJ *)[my.arrshowimageDetail objectAtIndex:indexPath.row]).strfileID;
	//cellLabelclaim.numberOfLines=0;
	[cell.contentView addSubview:cellLabelFileId];
	[cellLabelFileId release],cellLabelFileId=nil; 
	

	return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	
	
	ImageShow *obj=[[ImageShow alloc]initwitFileid:((ShowImageDetailsOBJ *)[my.arrshowimageDetail objectAtIndex:indexPath.row]).strfileID];
	[self.navigationController pushViewController:obj animated:YES];
	[obj release],obj=nil;
	
	
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
