//
//  RoleSubOBJ.m
//  Acclaris
//
//  Created by Subhojit on 22/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "RoleSubOBJ.h"


@implementation RoleSubOBJ
@synthesize strsubName,strsubDisplayseq,strsublabel,displayable;
@end
