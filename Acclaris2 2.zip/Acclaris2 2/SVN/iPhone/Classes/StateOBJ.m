//
//  StateOBJ.m
//  Acclaris
//
//  Created by Subhojit on 26/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "StateOBJ.h"


@implementation StateOBJ

@synthesize strstate,strvalue1,strvalue2,strvalue3,strreturnCode,strerrorText;
@end
