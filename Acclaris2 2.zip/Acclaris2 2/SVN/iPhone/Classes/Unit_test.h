//
//  Unit_test.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 04/11/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AcclarisAppDelegate.h"


@interface Unit_test : UIViewController <UITextViewDelegate,UIPickerViewDelegate>{

	UITextView *txtv_msgCloseNotes;
	NSString *whichservice;
	NSInteger service;
	NSInteger testcase;
	NSArray *testname;
	UIView *viewself;
	AcclarisAppDelegate *app;
	
}
-(void)onSucceffulLogin:(NSMutableArray*)arr arr2:(NSMutableArray *)arr2;
-(void)test_login1;
-(void)test_login2;
-(void)test_reqTicket;
-(void)test_sendaccountRequest;

@end
