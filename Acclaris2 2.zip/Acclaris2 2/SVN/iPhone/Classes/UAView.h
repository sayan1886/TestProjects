#import <UIKit/UIKit.h>

@interface UAView : UIView
{

}

@end
