//
//  MultipleAccountView.m
//  Acclaris
//
//  Created by Subhojit on 15/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MultipleAccountView.h"


@implementation MultipleAccountView
 @synthesize Interesteddelegate;

- (id)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        arrMultipleAcc=[Claimonlineserviceparser getarrMultipleAccdata];
		
		
		[self CreateView];
		
				
    }
    return self;
}
-(void)CreateView

{
	
	
	table=[[UITableView alloc]initWithFrame:CGRectMake(13, 40, 260, 150) style:UITableViewStylePlain];
	table.backgroundColor = [UIColor clearColor];
	CALayer * l = [table layer];
	[l setMasksToBounds:YES];
	[l setCornerRadius:10.0];
	table.bounces = YES;
	table.delegate=self;
	table.dataSource=self;
	table.separatorColor=[UIColor grayColor];
	[self addSubview:table];
	
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	
	return [arrMultipleAcc count];
	
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath 
{
		
	static NSString *CellIdentifier = @"Cell";
	static NSString *CellIdentifier1 = @"Cell1";
	UITableViewCell *cell;
	
	if(cell==nil)
	{
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier] autorelease];
	}
	else
	{
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier1];
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier1] autorelease];
		
	}
	
	//cell.selectionStyle=UITableViewCellSelectionStyleNone;
	//cell.backgroundColor=[UIColor whiteColor];
	
	//cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;		
	
	
	UILabel *celldatalbl=[[UILabel alloc]initWithFrame:CGRectMake(0, 0, 280, 49)];
	celldatalbl.text=((MultipleAccountOBJ *	)[arrMultipleAcc objectAtIndex:indexPath.row]).	straccountTypeDesc;	
	celldatalbl.font=[UIFont fontWithName:@"Helvetica" size:12];
	cell.backgroundColor=[UIColor clearColor];
	[cell.contentView addSubview:celldatalbl];
					   
		
		return cell;
		
}
	
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
		
		
		return 50.0;
		
}
	
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
	
{
		
	strAccValue=((MultipleAccountOBJ *)[arrMultipleAcc objectAtIndex:indexPath.row]).strlabelAssociatedValue;
	
	NSLog(@" associated valueb: %@",strAccValue);
	
	if(self.Interesteddelegate){
		if([self.Interesteddelegate respondsToSelector:@selector(whichSelected:)])
		{
			
			//[self removeFromSuperview];
			[self.Interesteddelegate whichSelected:strAccValue];
		}
	}
	
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code.
}
*/

- (void)dealloc {
    [super dealloc];
}


@end
