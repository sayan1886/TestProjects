//
//  ReceiptShowParser.h
//  Acclaris
//
//  Created by Subhojit on 19/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ReceiptShowOBJ.h"
#import "Decode64.h"


@interface ReceiptShowParser : NSObject<NSXMLParserDelegate> {

	ReceiptShowOBJ *obj;
	NSMutableString *contentOfString;
	
}
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error;
+(NSMutableArray *)getarrReceipt;
@end
