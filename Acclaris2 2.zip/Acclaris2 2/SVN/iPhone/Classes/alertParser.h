//
//  alertParser.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 07/12/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>

@class alertsOBJ;
@interface alertParser : NSObject <NSXMLParserDelegate>{

	NSMutableString *contentOfString;
	alertsOBJ *myalertsOBJ;
}

-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error;
+(NSMutableArray *)alertARRresponce;
+(BOOL)gethasMoreRecords_alert;
@end
