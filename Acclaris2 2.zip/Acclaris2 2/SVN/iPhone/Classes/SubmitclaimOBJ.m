//
//  SubmitclaimOBJ.m
//  Acclaris
//
//  Created by Subhojit on 08/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "SubmitclaimOBJ.h"


@implementation SubmitclaimOBJ
@synthesize strreturnCode,strerrorText,strtrxnID,strclmID,strclmAmount,strclmCategory,strclmType,stractpCD,strprovider,strserviceBegins,strpaymentRef,strinvoiceNo,strcustomerNo,strpayeeID,strservicePeriod,strtext,strdeniedOn,strdeniedBy,strisInvalidACHInfo;
@end
