    //
//  denialReasonShow.m
//  Acclaris
//
//  Created by Ayon on 16/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "denialReasonShow.h"
#import "claimActivity.h"
#import "configurables.h"
#import "claimactivityPerser.h"
#import "claimActivityOBJ.h"
#import "UserresponcePerser.h"
#import "Decode64.h"
#import "configurableParser.h"
#import "AcclarisViewController.h"
#import "claimActivityDetails.h"
#import "denialReasonOBJ.h"


@implementation denialReasonShow

 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	
	//self.navigationItem.hidesBackButton=YES;
	
	NSMutableArray *arr_myconfig=[AcclarisViewController staticarr_config];//[configurableParser getconfig_arr];//
	con=(configurables *)[arr_myconfig objectAtIndex:0];
	
	self.view.backgroundColor = [UIColor colorWithRed:con.bgRed/255.0f green:con.bgGreen/255.0f blue:con.bgBlue/255.0f alpha:1.0];
	
	tools=[[MyTools alloc]init];
	loadingView=[tools createActivityIndicator1];
	
	selectedrow=[claimActivity getSelectedClaimRow];
	
	[self signoutbt];
	arr_celltytle=[claimactivityPerser claimactivityArr];
	
	
	
	//NSMutableArray *my_arrUserinfo=[UserresponcePerser userdesc];
	UIImageView *logo_img = [[UIImageView alloc]initWithFrame:CGRectMake(0, 2, 170, 40)];
	NSData *data=[Base64 decode:con.logoImgdata];
	logo_img.image=	[UIImage imageWithData:[NSData dataWithData:data]];
	 self.navigationItem.titleView=logo_img;
	
	UIImageView *img=[[UIImageView alloc]init];
	img.frame=CGRectMake(0, 0, 168, 32);
	img.image=[UIImage imageNamed:@"logo.png"];
	self.navigationItem.titleView=img;
	
	
	UIButton *btn_imgUp=[UIButton buttonWithType:UIButtonTypeCustom];
	btn_imgUp.frame = CGRectMake(43, 308, 234, 47);
	NSData *data_btnimg=[Base64 decode:con.btnImgdata];
	[btn_imgUp setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
	btn_imgUp.titleLabel.font = [UIFont fontWithName:con.btnfontname size:15];
	[btn_imgUp setTitle:@"Back to Claim Details" forState:UIControlStateNormal];
	[btn_imgUp setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn_imgUp addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
	[self.view addSubview:btn_imgUp];
	
	[self createHeader];
	[self createtableview];
}

-(void)createHeader
{
	
	UIView *vw=[[UIView alloc]initWithFrame:CGRectMake(10, 0,300,50)];
	
	
	vw.backgroundColor=[UIColor colorWithRed:con.bgRed2/255.0 green:con.bgGreen2/255.0 blue:con.bgBlue2/255.0 alpha:1.0];
	[self.view addSubview:vw];
	
	
	
	NSString *strFont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];
	
	UILabel *Labeldenialreason=[[UILabel alloc]initWithFrame:CGRectMake(10,10,300,20)];
	Labeldenialreason.font=[UIFont fontWithName:strFont size:con.headerImpfntsize];
	Labeldenialreason.backgroundColor=[UIColor clearColor];
	Labeldenialreason.text =@"Denial Reason(s)";
	Labeldenialreason.textColor=[UIColor whiteColor];
	[vw addSubview:Labeldenialreason];
	[Labeldenialreason release];
		
	[vw release];
	
}	
-(void)back
{
	[self.navigationController popViewControllerAnimated:YES];
}
-(void)signoutbt
{
	UIButton *signoutButton = [UIButton buttonWithType:UIButtonTypeCustom];
	signoutButton.backgroundColor = [UIColor clearColor];
	signoutButton.frame = CGRectMake(0.0,0.0,66,33);
	[signoutButton setBackgroundImage:[UIImage imageNamed:@"signoff_button.png"] forState:UIControlStateNormal];
	[signoutButton addTarget:self action:@selector(signout) forControlEvents:UIControlEventTouchUpInside];
	
	UIBarButtonItem *signinBarButton = [[UIBarButtonItem alloc] initWithCustomView:signoutButton];        
	self.navigationItem.rightBarButtonItem = signinBarButton;
	
	/*UIBarButtonItem *signoutButton = [[UIBarButtonItem alloc]
	 initWithTitle:@"Sign Off"
	 style:UIBarButtonItemStyleBordered
	 target:self
	 action:@selector(signout)];
	 self.navigationItem.rightBarButtonItem =signoutButton;*/
}
-(void)signout
{
	[((AcclarisAppDelegate *)[[UIApplication sharedApplication] delegate]) removeTabBar];

}	
#pragma mark tableViewDeligate
-(void)createtableview
{
	UITableView	*acctable=[[UITableView alloc] initWithFrame:CGRectMake(0,45,320,250) style:UITableViewStyleGrouped];
	acctable.delegate = self;
	acctable.dataSource = self;
	acctable.scrollEnabled = YES;
	acctable.autoresizesSubviews = YES;
	acctable.showsVerticalScrollIndicator=YES;
	acctable.showsHorizontalScrollIndicator=YES;
	acctable.backgroundColor=[UIColor clearColor];
	acctable.separatorColor=[UIColor whiteColor];
	acctable.layer.opacity=0.7;
	[self.view addSubview:acctable];	
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView  
{
	return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	NSInteger noofRow=[((claimActivityOBJ *)[ arr_celltytle objectAtIndex:selectedrow]).arrdenialReason count];
	return noofRow;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{  
	static NSString *CellIdentifier = @"Cell";
	static NSString *CellIdentifier1 = @"Cell1";
	UITableViewCell *cell;
	
	if(cell==nil)
	{
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier] autorelease];
	}
	else
	{
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier1];
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier1] autorelease];
		
	}
	cell.selectionStyle=UITableViewCellSelectionStyleNone;
	cell.backgroundColor=[UIColor whiteColor];
	//cell.backgroundColor=[UIColor colorWithRed:170.0/255.0 green:189.0/255.0 blue:212.0/255.0 alpha:1.0];
	
	//NSString *strFont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];
	
	UILabel *cellLabelText=[[UILabel alloc]init];//WithFrame:CGRectMake(5,13,300,85)];
	cellLabelText.font=[UIFont fontWithName:con.fontname size:con.bodyImpfntsize];
	cellLabelText.backgroundColor=[UIColor clearColor];
	cellLabelText.numberOfLines=0;
	claimActivityOBJ *objclaim=(claimActivityOBJ *)[arr_celltytle objectAtIndex:selectedrow];
	NSMutableArray *arr=objclaim.arrdenialReason;
	denialReasonOBJ *mydenialOBJ=(denialReasonOBJ *)[arr objectAtIndex:indexPath.row];
	NSString *str =@"       ";
						
	str=[str stringByAppendingString:mydenialOBJ.text];						
	CGSize constraint = CGSizeMake(300 - (10 * 2), 20000.0f);
	CGSize size = [str sizeWithFont:[UIFont fontWithName:con.fontname size:con.bodyImpfntsize] constrainedToSize:constraint lineBreakMode:UILineBreakModeWordWrap];
	CGFloat height = MAX(size.height, 10.0f);
	
	cellLabelText.frame=CGRectMake(5,10,290, height);
	
	cellLabelText.text=str;
	cellLabelText.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
	[cell.contentView addSubview:cellLabelText];
	[cellLabelText release];
		
	
	UIImageView *imgBullet=[[UIImageView alloc]initWithFrame:CGRectMake(5,10,13,13)];
	imgBullet.image=[UIImage imageNamed:@"bullet-2.png"];
	[cell.contentView addSubview:imgBullet];
	return cell;
	
	
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	;	
	
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	
	//return 90;
	
	claimActivityOBJ *objclaim=(claimActivityOBJ *)[arr_celltytle objectAtIndex:selectedrow];
	NSMutableArray *arr=objclaim.arrdenialReason;
	denialReasonOBJ *mydenialOBJ=(denialReasonOBJ *)[arr objectAtIndex:indexPath.row];
	
	NSString *text = @"       ";
	text=[text stringByAppendingString:mydenialOBJ.text];
	CGSize constraint = CGSizeMake(300 - (10 * 2), 20000.0f);
	CGSize size = [text sizeWithFont:[UIFont fontWithName:con.fontname size:con.bodyImpfntsize] constrainedToSize:constraint lineBreakMode:UILineBreakModeWordWrap];
	CGFloat height = MAX(size.height, 10.0);
	return height + (10 * 2);
	
}


/*- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Overriden to allow any orientation.
    return YES;
}*/


- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}


- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
