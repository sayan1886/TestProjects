//
//  eCommunicationOBJ.m
//  Acclaris
//
//  Created by Subhojit on 16/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "eCommunicationOBJ.h"


@implementation eCommunicationOBJ

@synthesize strreturnCode,strerrorText,stragreementText;
@end
