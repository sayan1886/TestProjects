    //
//  SelectServiceProvider.m
//  Acclaris
//
//  Created by Subhojit on 25/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "SelectServiceProvider.h"
#import "configurables.h"
#import "AcclarisViewController.h"
#import "Paynow.h"
#define FONT_SIZE 15.0f
#define CELL_CONTENT_WIDTH 250.0f
#define CELL_CONTENT_MARGIN 10.0f

@implementation SelectServiceProvider
-(id)initwithDict:(NSMutableDictionary *)dict withtype:(id)typ

{
	self=[super init];
	if(self==nil)
	{
		
		return nil;
	}
	else 
	{
		type =typ;
		Dictclaim=[[NSMutableDictionary alloc]init];
		Dictclaim=dict;
		NSLog(@" Dictclaim %@",[Dictclaim description]);
	}
	
	return self;
	
}
- (void)viewDidLoad {
    [super viewDidLoad];
	
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	tools=[[MyTools alloc]init];
	NSMutableArray *arr_myconfig=[AcclarisViewController staticarr_config];
	con=(configurables *)[arr_myconfig objectAtIndex:0];
	self.view.backgroundColor = [UIColor colorWithRed:con.bgRed/255.0f green:con.bgGreen/255.0f blue:con.bgBlue/255.0f alpha:1.0];
	loadingView=[tools createActivityIndicator1];
	self.navigationController.navigationBar.tintColor=[UIColor colorWithRed:con.navbarRed/255.0f green:con.navbarGreen/255.0f blue:con.navbarBlue/255.0f alpha:1.0];
	
	UIImageView *logo_img = [[UIImageView alloc]initWithFrame:CGRectMake(0, 2, 170, 40)];
	NSData *data=[Base64 decode:con.logoImgdata];
	logo_img.image=	[UIImage imageWithData:[NSData dataWithData:data]];
	self.navigationItem.titleView=logo_img;
	
	
	
	
	UIBarButtonItem *signoutButton = [[UIBarButtonItem alloc]
									  initWithTitle:@"Sign Off"
									  style:UIBarButtonItemStyleBordered
									  target:self
									  action:@selector(signout)];
    self.navigationItem.rightBarButtonItem =signoutButton;
	
	[self createConnectionforAddprovider];
		
}
-(void)signout
{
	[((AcclarisAppDelegate *)[[UIApplication sharedApplication] delegate]) removeTabBar];
}
-(void)createConnectionforAddprovider
{
	
	
    userinfo_arr=[passPerser passresponce];
	
	
	RequestPhase2 *objrequestPhase2=[[RequestPhase2 alloc] initWithTarget:self
															SuccessAction:@selector(onSuccesful)
															FailureAction:@selector(onFailure)];
	
	[objrequestPhase2 GetProviderList:[userinfo_arr objectAtIndex:2] userid:[userinfo_arr objectAtIndex:4]];
	
	[objrequestPhase2 release];
	
	[tools startLoading:self.view childView:loadingView text:@"Loading your Claim activity. Wait…."];
	
}
-(void)onSuccesful
{
	
	   [tools stopLoading:loadingView];
	
	    arrgetProviderdetails=[GetProviderListParser arrgetarrproviderlist];
	  arrtabcontent=[[NSMutableArray alloc]init];
	for (int i=0; i<[arrgetProviderdetails count]; i++)
	{
		strAddress=((GetProviderListOBJ *)[arrgetProviderdetails  objectAtIndex:i]).strline1;
		strAddress=[strAddress stringByAppendingString:@","];
		if([((GetProviderListOBJ *)[arrgetProviderdetails  objectAtIndex:i]).strline2 length]==0)
		{
			
		}
		else 
			strAddress=[strAddress stringByAppendingFormat:@"%@",((GetProviderListOBJ *)[arrgetProviderdetails  objectAtIndex:i]).strline2];
		//strAddress=[strAddress stringByAppendingString:@","];
		
		if([((GetProviderListOBJ *)[arrgetProviderdetails  objectAtIndex:i]).strline3 length]==0)
		{
			
		}
		else 
			strAddress=[strAddress stringByAppendingFormat:@"%@",((GetProviderListOBJ *)[arrgetProviderdetails  objectAtIndex:i]).strline3];
		
		
		
		
		//strAddress=[strAddress stringByAppendingString:@","];
		strAddress=[strAddress stringByAppendingFormat:@"%@",((GetProviderListOBJ *)[arrgetProviderdetails  objectAtIndex:i]).strcity];
		strAddress=[strAddress stringByAppendingString:@","];
		strAddress=[strAddress stringByAppendingFormat:@"%@",((GetProviderListOBJ *)[arrgetProviderdetails  objectAtIndex:i]).strstate];
		strAddress=[strAddress stringByAppendingString:@","];
		strAddress=[strAddress stringByAppendingFormat:@"%@",((GetProviderListOBJ *)[arrgetProviderdetails  objectAtIndex:i]).strzip];
		strAddress=[strAddress stringByAppendingString:@","];
		strAddress=[strAddress stringByAppendingFormat:@"%@",((GetProviderListOBJ *)[arrgetProviderdetails  objectAtIndex:i]).strcountry];
		
		[arrtabcontent addObject:strAddress];
	}

	if(isEdit==YES)
		{
			
			[table reloadData];
			isEdit=NO;
		}
	
	else if(isprovider==YES)
	   {
		
		   [table reloadData];
		   isprovider=NO;
	   }

	else 
	{
		
		[self createView];
		 
	}

		
}
-(void)onFailure

{
	
	[tools stopLoading:loadingView];

	
}


-(void)createView
{
	
	scroll=[[MyScrollView alloc]initWithFrame:CGRectMake(0,0,320,318)];
	
	scroll.delegate=self;
	[scroll setContentSize:CGSizeMake(0,[arrgetProviderdetails count]*55.0+195+10+10)];
	//[scroll setPagingEnabled:YES];
	[scroll setContentOffset:CGPointMake(0,0)];
	scroll.directionalLockEnabled=YES;
	scroll.showsVerticalScrollIndicator = YES;
	
	[self.view addSubview:scroll];
	
	
	
	NSData *data_btnimg=[Base64 decode:con.btnImgdata];//btn background image

	UIView *HeaderView=[[[UIView alloc]initWithFrame:CGRectMake(0, 0, 320, 60)]autorelease];
	HeaderView.backgroundColor=[UIColor colorWithRed:con.bgRed2/255.0 green:con.bgGreen2/255.0 blue:con.bgBlue2/255.0 alpha:1.0];
	[self.view addSubview:HeaderView];
	
	NSString *strViewTitle=@"Select Service Provider";
	//strViewTitle=[strViewTitle stringByAppendingString:@"\n"];
	//strViewTitle=[strViewTitle stringByAppendingFormat:@"%@",@"Provider"];
	
	UILabel *lbltext=[[UILabel alloc]initWithFrame:CGRectMake(10, 5, 250, 60)];
	lbltext.text=strViewTitle;
	lbltext.backgroundColor=[UIColor clearColor];
	lbltext.textColor=[UIColor whiteColor];
	//lbltext.numberOfLines=0;
	lbltext.font=[UIFont fontWithName:@"Helvetica" size:18];
	[HeaderView addSubview:lbltext];
	[lbltext release],lbltext=nil;
	
	UILabel *lblinvoice = [[UILabel alloc]initWithFrame:CGRectMake(10,70,80,35)];
	lblinvoice.backgroundColor = [UIColor clearColor];
	lblinvoice.text=@"Invoice No#";
	lblinvoice.font = [UIFont fontWithName:con.fontname size:con.bodyfntsize];
	lblinvoice.textAlignment = UITextAlignmentLeft;
	lblinvoice.textColor=[UIColor blackColor];
	[scroll addSubview:lblinvoice];
	[lblinvoice release], lblinvoice = nil;	
	
	txtinvoice = [[UITextField alloc]initWithFrame:CGRectMake(135,73,170,25)];
	txtinvoice.backgroundColor = [UIColor whiteColor];
	txtinvoice.autocorrectionType = UITextAutocorrectionTypeNo;
	txtinvoice.text=@"";
	txtinvoice.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	txtinvoice.keyboardType=UIKeyboardTypeDefault;
	txtinvoice.returnKeyType=UIReturnKeyDone;
	txtinvoice.delegate=self;
	txtinvoice.borderStyle = UITextBorderStyleLine;
	[scroll addSubview:txtinvoice];			
	
	
	UILabel *lblAcount = [[UILabel alloc]initWithFrame:CGRectMake(10,115,80,35)];
	lblAcount.backgroundColor = [UIColor clearColor];
	lblAcount.text=@"Account#";
	lblAcount.font = [UIFont fontWithName:con.fontname size:con.bodyfntsize];
	lblAcount.textAlignment = UITextAlignmentLeft;
	lblAcount.textColor=[UIColor blackColor];
	[scroll addSubview:lblAcount];
	[lblAcount release], lblAcount = nil;	
	
	
	txtAcount = [[UITextField alloc]initWithFrame:CGRectMake(135,113,170,25)];
	txtAcount.backgroundColor = [UIColor whiteColor];
	txtAcount.autocorrectionType = UITextAutocorrectionTypeNo;
	txtAcount.text=@"";
	txtAcount.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	txtAcount.keyboardType=UIKeyboardTypeDefault;
	txtAcount.returnKeyType=UIReturnKeyDone;
	txtAcount.delegate=self;
	txtAcount.borderStyle = UITextBorderStyleLine;
	[scroll addSubview:txtAcount];			
	
	
	UILabel *lblpaymentreff = [[UILabel alloc]initWithFrame:CGRectMake(10,156,130,40)];
	lblpaymentreff.backgroundColor = [UIColor clearColor];
	lblpaymentreff.text=@"Payment Reference";
	lblpaymentreff.font = [UIFont fontWithName:con.fontname size:con.bodyfntsize];
	lblpaymentreff.textAlignment = UITextAlignmentLeft;
	lblpaymentreff.textColor=[UIColor blackColor];
	[scroll addSubview:lblpaymentreff];
	[lblpaymentreff release], lblpaymentreff = nil;
	
	txtpaymentreff = [[UITextField alloc]initWithFrame:CGRectMake(135,157,170,25)];
	txtpaymentreff.backgroundColor = [UIColor whiteColor];
	txtpaymentreff.autocorrectionType = UITextAutocorrectionTypeNo;
	txtpaymentreff.text=@"";
	txtpaymentreff.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	txtpaymentreff.keyboardType=UIKeyboardTypeDefault;
	txtpaymentreff.returnKeyType=UIReturnKeyDone;
	txtpaymentreff.delegate=self;
	txtpaymentreff.borderStyle = UITextBorderStyleLine;
	[scroll addSubview:txtpaymentreff];	
	
	
    roleDict=[passPerser getRolebaseDict];
	
	if ([[roleDict valueForKey:@"ADD_PROVIDER_IN_ONLINE"]isEqualToString:@"Yes"] && [type isKindOfClass:[SubmitNewClaimTwo class]] || [[roleDict valueForKey:@"ADD_PROVIDER_IN_ONLINE"]isEqualToString:@"Yes"] && [type isKindOfClass:[EditClaim class]])
	{

		UIButton *btnprovider=[UIButton buttonWithType:UIButtonTypeCustom];
		btnprovider.frame=CGRectMake(30, 320, 260, 40);
		[btnprovider setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
		[btnprovider setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
		btnprovider.titleLabel.font = [UIFont fontWithName:con.btnfontname size:con.btnfontsize];
		[btnprovider setTitle:@"Add provider" forState:UIControlStateNormal];
		[btnprovider addTarget:self action:@selector(Clickbtnbtnprovider) forControlEvents:UIControlEventTouchUpInside];	
		[self.view addSubview:btnprovider];
	}
	else if([[roleDict valueForKey:@"ADD_PROVIDER_IN_PASSTHRU"]isEqualToString:@"Yes"] && [type isKindOfClass:[Paynow class]] || [[roleDict valueForKey:@"ADD_PROVIDER_IN_PASSTHRU"]isEqualToString:@"Yes"] && [type isKindOfClass:[EditClaim class]])

	{
		
		UIButton *btnprovider=[UIButton buttonWithType:UIButtonTypeCustom];
		btnprovider.frame=CGRectMake(30, 320, 260, 40);
		[btnprovider setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
		[btnprovider setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
		btnprovider.titleLabel.font = [UIFont fontWithName:con.btnfontname size:con.btnfontsize];
		[btnprovider setTitle:@"Add provider" forState:UIControlStateNormal];
		[btnprovider addTarget:self action:@selector(Clickbtnbtnprovider) forControlEvents:UIControlEventTouchUpInside];	
		[self.view addSubview:btnprovider];
	}

	else 
	{
		
		;
	}

	table=[[UITableView alloc]initWithFrame:CGRectMake(0, 195, 320, [arrgetProviderdetails count]*55.0+10+10) style:UITableViewStyleGrouped];
	table.backgroundColor = [UIColor clearColor];
	table.bounces = NO;
	table.delegate=self;
	table.dataSource=self;
	table.separatorColor=[UIColor blackColor];
	[scroll addSubview:table];
	
}
-(void)Clickbtnbtnprovider
{
	isprovider=YES;
	AddProvider *obj=[[[AddProvider alloc]init]autorelease];
	[self.navigationController pushViewController:obj animated:YES];
	
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	
	
    return 1;
	
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	
	
	return [arrgetProviderdetails count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	
   	static NSString *CellIdentifier = @"Cell";
	static NSString *CellIdentifier1 = @"Cell1";
	UITableViewCell *cell;
	if(cell==nil)
	{
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier] autorelease];
	}
	else
	{
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier1];
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier1] autorelease];
	}
	cell.selectionStyle = UITableViewCellSelectionStyleNone;
	cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;

	NSString *strfont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];
	UILabel *Labelprovidername=[[UILabel alloc]initWithFrame:CGRectMake(5,3,180,20)];
	Labelprovidername.font=[UIFont fontWithName:strfont size:con.bodyImpfntsize];
	Labelprovidername.backgroundColor=[UIColor clearColor];
	Labelprovidername.text =((GetProviderListOBJ *)[arrgetProviderdetails  objectAtIndex:indexPath.row]).strname;
	Labelprovidername.textColor=[UIColor blackColor];
	[cell.contentView addSubview:Labelprovidername];
	[Labelprovidername release];
	
	strAddress=((GetProviderListOBJ *)[arrgetProviderdetails  objectAtIndex:indexPath.row]).strline1;
	strAddress=[strAddress stringByAppendingString:@","];
	if([((GetProviderListOBJ *)[arrgetProviderdetails  objectAtIndex:indexPath.row]).strline2 length]==0)
	{
	   
	}
	else 
	   strAddress=[strAddress stringByAppendingFormat:@"%@",((GetProviderListOBJ *)[arrgetProviderdetails  objectAtIndex:indexPath.row]).strline2];
	   //strAddress=[strAddress stringByAppendingString:@","];

	if([((GetProviderListOBJ *)[arrgetProviderdetails  objectAtIndex:indexPath.row]).strline3 length]==0)
	{
		
	}
	else 
		strAddress=[strAddress stringByAppendingFormat:@"%@",((GetProviderListOBJ *)[arrgetProviderdetails  objectAtIndex:indexPath.row]).strline3];

	

	
	//strAddress=[strAddress stringByAppendingString:@","];
	strAddress=[strAddress stringByAppendingFormat:@"%@",((GetProviderListOBJ *)[arrgetProviderdetails  objectAtIndex:indexPath.row]).strcity];
	strAddress=[strAddress stringByAppendingString:@","];
	strAddress=[strAddress stringByAppendingFormat:@"%@",((GetProviderListOBJ *)[arrgetProviderdetails  objectAtIndex:indexPath.row]).strstate];
	strAddress=[strAddress stringByAppendingString:@","];
	strAddress=[strAddress stringByAppendingFormat:@"%@",((GetProviderListOBJ *)[arrgetProviderdetails  objectAtIndex:indexPath.row]).strzip];
	strAddress=[strAddress stringByAppendingString:@","];
	strAddress=[strAddress stringByAppendingFormat:@"%@",((GetProviderListOBJ *)[arrgetProviderdetails  objectAtIndex:indexPath.row]).strcountry];
	
	UILabel *Adresslbl=[[UILabel alloc]initWithFrame:CGRectMake(5,26,250,27)];
	Adresslbl.font=[UIFont fontWithName:con.fontname size:con.bodyfntsize];
	
	NSLog(@"%d %@",indexPath.row ,strAddress);
	CGSize constraint = CGSizeMake(CELL_CONTENT_WIDTH - (CELL_CONTENT_MARGIN * 2), 20000.0f);
	CGSize size = [strAddress sizeWithFont:[UIFont fontWithName:con.fontname size:con.bodyfntsize] constrainedToSize:constraint lineBreakMode:UILineBreakModeWordWrap];
	CGFloat height = MAX(size.height, 10.0f);
	
	Adresslbl.frame=CGRectMake(5,26,250,height);
	
	
	Adresslbl.backgroundColor=[UIColor clearColor];
	Adresslbl.text =strAddress;
	Adresslbl.numberOfLines=0;
	Adresslbl.textColor=[UIColor blackColor];
	[cell.contentView addSubview:Adresslbl];
	[Adresslbl release],Adresslbl=nil;
	
	if([[roleDict valueForKey:@"EDIT_PROVIDER_IN_ONLINE"]isEqualToString:@"Yes"] && [type isKindOfClass:[SubmitNewClaimTwo class]])
	{
	
			UIButton *btnEdit=[UIButton buttonWithType:UIButtonTypeCustom];
			btnEdit.frame=CGRectMake(225, 8, 25, 24);
			btnEdit.tag=indexPath.row;
			[btnEdit setBackgroundImage:[UIImage imageNamed:@"icon1.png"] forState:UIControlStateNormal];
			[btnEdit addTarget:self action:@selector(ClickbtnEdit:) forControlEvents:UIControlEventTouchUpInside];					 
			[cell.contentView addSubview:btnEdit];
		
	}
  else if([[roleDict valueForKey:@"EDIT_PROVIDER_IN_ONLINE"]isEqualToString:@"Yes"] && [type isKindOfClass:[Paynow class]]  || [[roleDict valueForKey:@"EDIT_PROVIDER_IN_ONLINE"]isEqualToString:@"Yes"] && [type isKindOfClass:[EditClaim class]])
	{
		
		UIButton *btnEdit=[UIButton buttonWithType:UIButtonTypeCustom];
		btnEdit.frame=CGRectMake(225, 8, 25, 24);
		btnEdit.tag=indexPath.row;
		[btnEdit setBackgroundImage:[UIImage imageNamed:@"icon1.png"] forState:UIControlStateNormal];
		[btnEdit addTarget:self action:@selector(ClickbtnEdit:) forControlEvents:UIControlEventTouchUpInside];					 
		[cell.contentView addSubview:btnEdit];
		
	}
			
   if([[roleDict valueForKey:@"DELETE_PROVIDER_IN_ONLINE"]isEqualToString:@"Yes"] && [type isKindOfClass:[SubmitNewClaimTwo class]]|| [[roleDict valueForKey:@"DELETE_PROVIDER_IN_ONLINE"]isEqualToString:@"Yes"] && [type isKindOfClass:[EditClaim class]])
	{
		    UIButton *btncross=[UIButton buttonWithType:UIButtonTypeCustom];
			btncross.tag=indexPath.row;
			btncross.frame=CGRectMake(250, 8, 25, 24);
			[btncross setBackgroundImage:[UIImage imageNamed:@"icon2.png"] forState:UIControlStateNormal];
			[btncross addTarget:self action:@selector(Clickbtncross:) forControlEvents:UIControlEventTouchUpInside];					 
			[cell.contentView addSubview:btncross];
	}
	
  else	if([[roleDict valueForKey:@"DELETE_PROVIDER_IN_ONLINE"]isEqualToString:@"Yes"] && [type isKindOfClass:[Paynow class]])
  {
	  
		  UIButton *btncross=[UIButton buttonWithType:UIButtonTypeCustom];
		  btncross.tag=indexPath.row;
		  btncross.frame=CGRectMake(250, 8, 25, 24);
		  [btncross setBackgroundImage:[UIImage imageNamed:@"icon2.png"] forState:UIControlStateNormal];
		  [btncross addTarget:self action:@selector(Clickbtncross:) forControlEvents:UIControlEventTouchUpInside];					 
		  [cell.contentView addSubview:btncross];
  }
	
		
    return cell;
	
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	
		//return 44.0;
		
		//dynamic height for each row
		
		NSString *text =[arrtabcontent objectAtIndex:indexPath.row];
		CGSize constraint = CGSizeMake(CELL_CONTENT_WIDTH - (CELL_CONTENT_MARGIN * 2), 20000.0f);
	    CGSize size = [text sizeWithFont:[UIFont fontWithName:con.fontname size:con.bodyfntsize] constrainedToSize:constraint lineBreakMode:UILineBreakModeWordWrap];
		CGFloat height = MAX(size.height, 10.0f);
		return height + (CELL_CONTENT_MARGIN * 2)+22;

	
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath

{
	selectedIndex=indexPath.row;
	if([type isKindOfClass:[Paynow class]])
	{
		
		
		[self Saveclaimfrompaynow];
		
		
	}
	else 
	{
		
	   [self Saveclaim];
	}
	
		
}
-(void)Saveclaimfrompaynow

{
	
	
	userinfo_arr=[passPerser passresponce];
	
	
	RequestPhase2 *objrequestPhase2=[[RequestPhase2 alloc] initWithTarget:self
															SuccessAction:@selector(onSuccesfulsaveclaimpaynow)
															FailureAction:@selector(onFailuresaveclaimpaynow)];
	
	[objrequestPhase2 ClaimsToPaySubmit:[userinfo_arr objectAtIndex:2] userid:[userinfo_arr objectAtIndex:4] claimID:[Dictclaim valueForKey:@"claimid"] payMode:[Dictclaim valueForKey:@"paystatus"] actpCD:[Dictclaim valueForKey:@"Account"] PayeeId:((GetProviderListOBJ *)[arrgetProviderdetails  objectAtIndex:selectedIndex]).strpayeeId];
	
	[objrequestPhase2 release];
	
	[tools startLoading:self.view childView:loadingView text:@"Loading your Claim activity. Wait…."];
	
}
-(void)Saveclaim

{
	
		
	
	//accountvalue:strAccValue PayeeId:@"" allowDuplicateClaim:strallowDuplicateClaim opcode:stropcodevalue

	RequestPhase2 *objrequestPhase2=[[RequestPhase2 alloc] initWithTarget:self
															SuccessAction:@selector(onSuccesfulsave)
															FailureAction:@selector(onFailuresave)];
	
	[objrequestPhase2 callfromSelectpayee:[userinfo_arr objectAtIndex:2] uID:[userinfo_arr objectAtIndex:4] claimCaty:(NSString*)[Dictclaim  valueForKey:@"catagory"] claimtpe:(NSString*)[Dictclaim  valueForKey:@"Type"]  amt:(NSString*)[Dictclaim  valueForKey:@"Amount"] SerBedt:(NSString*)[Dictclaim  valueForKey:@"Servocefrom"]
								  SerEedt:(NSString*)[Dictclaim  valueForKey:@"Serviveto"]   Note:(NSString*)[Dictclaim  valueForKey:@"Note"] isPrYr:(NSString*)[Dictclaim  valueForKey:@"Checkbox"] payMode:(NSString*)[Dictclaim  valueForKey:@"paystatus"] providerName:(NSString*)[Dictclaim  valueForKey:@"Provider"] accountvalue:(NSString*)[Dictclaim  valueForKey:@"Accounttype"] claimID:[Dictclaim valueForKey:@"claimid"]  PayeeId:((GetProviderListOBJ *)[arrgetProviderdetails  objectAtIndex:selectedIndex]).strpayeeId allowDuplicateClaim:(NSString*)[Dictclaim  valueForKey:@"duplicateclaim"]   opcode:@"5003"];
	
	[objrequestPhase2 release];
	
	[tools startLoading:self.view childView:loadingView text:@"Loading your Claim activity. Wait…."];
	
}

-(void)onSuccesfulsave
{
	
	
	[tools stopLoading:loadingView];

	arrclaimsave=[Claimonlineserviceparser getarrClaimonlinesave];
	if([((ClaimonlineSaveOBJ *)[arrclaimsave objectAtIndex:0]).strreturnCode isEqualToString:@"0"])
	{
		
		app.checkclassname=@"Selectpayee";
		SubmitNewClaimThree *obj=[[SubmitNewClaimThree alloc]init];
		[self.navigationController pushViewController:obj animated:YES];
		
		
	}
	
	else 
	{
		
		UIAlertView *alertview=[[UIAlertView alloc]initWithTitle:@"Info" message:((ClaimonlineSaveOBJ *)[arrclaimsave objectAtIndex:0]).strerrorText delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		alertview.delegate=self;
		[alertview show];
		[alertview release],alertview=nil;
		return ;
		
	}
	
	
}
-(void)onFailuresave
{
	
	
	[tools stopLoading:loadingView];

	
}
-(void)onSuccesfulsaveclaimpaynow
{
	
	[tools stopLoading:loadingView];
	
	NSString *str=[PaynowcontinueParser  getErrortext];
	NSString *strreturncode=[PaynowcontinueParser getreturncode];
	
	if([strreturncode isEqualToString:@"0"])
	{
		
		PaynowClaimsuccess *obj=[[[PaynowClaimsuccess alloc]init]autorelease];
		[self.navigationController pushViewController:obj animated:YES];
		
	}
	else
	{
		UIAlertView *alertview=[[UIAlertView alloc]initWithTitle:@"Info" message:str delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		alertview.delegate=self;
		[alertview show];
		[alertview release],alertview=nil;
	}

	
}
-(void)onFailuresaveclaimpaynow
{
	
	[tools stopLoading:loadingView];
	
}
/*- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex

{
	
	
	if(buttonIndex==1)
		
	{
		
		
		
		///call for multiple account with opcode 5002///
		
		RequestPhase2 *objrequestPhase2=[[RequestPhase2 alloc] initWithTarget:self
																SuccessAction:@selector(onSuccesfull2)
																FailureAction:@selector(onFailure2)];
		
		[objrequestPhase2 ClaimOnlineServiceSave:[userinfo_arr objectAtIndex:2] uID:[userinfo_arr objectAtIndex:4] claimCaty:(NSString*)[Dictclaim  valueForKey:@"catagory"] claimtpe:(NSString*)[Dictclaim  valueForKey:@"Type"]  amt:(NSString*)[Dictclaim  valueForKey:@"Amount"] SerBedt:(NSString*)[Dictclaim  valueForKey:@"Servocefrom"]
										 SerEedt:(NSString*)[Dictclaim  valueForKey:@"Serviveto"]   Note:(NSString*)[Dictclaim  valueForKey:@"Note"] isPrYr:(NSString*)[Dictclaim  valueForKey:@"Checkbox"] payMode:(NSString*)[Dictclaim  valueForKey:@"paystatus"] providerName:(NSString*)[Dictclaim  valueForKey:@"Provider"] PayeeId:((GetProviderListOBJ *)[arrgetProviderdetails  objectAtIndex:selectedIndex]).strpayeeId];
		
		[objrequestPhase2 release];
		
		[tools startLoading:self.view childView:loadingView text:@"Loading your Claim activity. Wait…."];
		
		
	}
}
-(void)onSuccesfull2
{
	
	[tools stopLoading:loadingView];
	
	

		SubmitNewClaimThree *obj=[[[SubmitNewClaimThree alloc]init]autorelease];
		[self.navigationController pushViewController:obj animated:YES];
	
	
	
}
-(void)onFailure2

{
	
	[tools stopLoading:loadingView];
	
}*/

-(void)ClickbtnEdit:(id)sender
{
	isEdit=YES;
	UIButton *btn=(UIButton *)sender;
	Selectedrow=btn.tag;
	
	EditProviderdetail *obj=[[EditProviderdetail alloc]initWithrow:Selectedrow target:self action:@selector(createConnectionforAddprovider)];
	[self.navigationController pushViewController:obj animated:YES];
	[obj release],obj=nil;
	
}

-(void)Clickbtncross:(id)sender
{
	UIButton *btn=(UIButton *)sender;
	Selectedrow=btn.tag;
	
	UIAlertView *alertview=[[UIAlertView alloc]initWithTitle:@"Alert" message:@"Are you sure to delete this provider?" delegate:self cancelButtonTitle:@"No" otherButtonTitles:@"Yes",nil];
	alertview.delegate=self;
	[alertview show];
	[alertview release],alertview=nil;
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	
	if(buttonIndex==1)
	{
		
		[self Deletepayee];
	}
}
-(void)Deletepayee
{
	
	
	RequestPhase2 *objrequestPhase2=[[RequestPhase2 alloc] initWithTarget:self
															SuccessAction:@selector(onSuccesfuldelete)
															FailureAction:@selector(onFailuredelete)];
	
	[objrequestPhase2 DeletePayee:[userinfo_arr objectAtIndex:2] uID:[userinfo_arr objectAtIndex:4] payeeID:((GetProviderListOBJ *)[arrgetProviderdetails objectAtIndex:Selectedrow]).strpayeeId];
	
	[objrequestPhase2 release];
	
	[tools startLoading:self.view childView:loadingView text:@"Loading your Claim activity. Wait…."];
	[arrgetProviderdetails removeObjectAtIndex:Selectedrow];
	
	
}
-(void)onSuccesfuldelete
{
	
	[tools stopLoading:loadingView];
	
	NSString *strErrortext=[Deleteparser getErrortxt];
	
	if(strErrortext.length > 0)
		
	{
		UIAlertView *alertview=[[UIAlertView alloc]initWithTitle:@"Info" message:strErrortext delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		alertview.delegate=self;
		[alertview show];
		[alertview release],alertview=nil;
	}
	
	else 
	{
		
		UIAlertView *alertview=[[UIAlertView alloc]initWithTitle:@"Info" message:@"Provider deleted successfully" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
		alertview.delegate=self;
		[alertview show];
		[alertview release],alertview=nil;
		[table reloadData];
		
	}
	
	
}
-(void)onFailuredelete
{
	
	
	[tools stopLoading:loadingView];
	
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
	
	return YES;
}

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField
{
		
		return YES;
		
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
		
		[textField resignFirstResponder];
		return YES;
		
}
-(void)viewWillAppear:(BOOL)animated

{

	
	if(isprovider==YES)
		
	{
		
			[self createConnectionforAddprovider];
		
		
	}
	else 
	{
		
		
	}

}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
	txtinvoice=nil;
	
	txtAcount=nil;
	txtpaymentreff=nil;
}


- (void)dealloc {
	
	[txtinvoice release];
	[txtAcount release];
	[txtpaymentreff release];
	
	
    [super dealloc];
}


@end
