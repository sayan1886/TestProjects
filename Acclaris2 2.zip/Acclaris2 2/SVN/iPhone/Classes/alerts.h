//
//  alerts.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 07/10/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyTools.h"
#import "GopaperLess.h"
#import "ElectronicDeposit.h"
#import "AddPhoneNumber.h"
#import "EmailInput.h"
#import "VerifyEmailAddress.h"
#import "GopaperLess.h"
#import "ElectronicDeposit.h"
@class configurables;

@interface alerts : UIViewController<UITableViewDelegate,UITableViewDataSource> {

	configurables *con;
	MyTools *tools;
	UIView *loadingView;
	NSMutableArray *arr_celltytle;
	UITableView *acctable;
	
	NSInteger startID;
	NSString *str_startID1;
	UIButton *bt_previous;
	UIButton *bt_next;

}
-(id)initWithTabBar:(NSString *)label;
-(void)reqAlerts;
-(void)createtableview;
-(void)signoutbt;
-(NSArray *)sortAlertForSeverity:(NSArray *)unsorted;
-(void)Test;

@end
