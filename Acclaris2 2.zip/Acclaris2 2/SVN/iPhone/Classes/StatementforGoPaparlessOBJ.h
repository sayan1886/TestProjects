//
//  StatementforGoPaparlessOBJ.h
//  Acclaris
//
//  Created by Subhojit on 12/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface StatementforGoPaparlessOBJ : NSObject {

	NSString *strname;
	NSString *strlabel;
	
	NSMutableArray *arrselectoption;
}
@property(nonatomic,retain)NSString *strname;
@property(nonatomic,retain)NSString *strlabel;

@property(nonatomic,retain)	NSMutableArray *arrselectoption;
@end
