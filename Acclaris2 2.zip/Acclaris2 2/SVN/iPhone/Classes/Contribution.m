    //
//  Contribution.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 08/04/11.
//  Copyright 2011 ObjectSol Technologies. All rights reserved.
//

#import "Contribution.h"
#import "Decode64.h"
#import "configurableParser.h"
#import "AcclarisViewController.h"
#import "configurables.h"
#import "ActiveSchedule.h"
@implementation Contribution
-(id)initWithArrayName:(NSMutableArray *)arr
{
	self=[super init];
	transaction_info=[[NSMutableArray alloc]init];
	transaction_info=arr;
	[transaction_info addObject:@""];
	return self;
}

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	self.view.backgroundColor=[UIColor whiteColor];
	
	NSMutableArray *arr_myconfig=[AcclarisViewController staticarr_config];
	con=(configurables *)[arr_myconfig objectAtIndex:0];
	
	
	arr_celltytle=[[NSArray alloc]initWithObjects:@"Active Schedule",@"Inactive Schedule",nil];
	
	self.navigationController.navigationBar.tintColor=[UIColor colorWithRed:con.navbarRed/255.0f green:con.navbarGreen/255.0f blue:con.navbarBlue/255.0f alpha:1.0];
	self.view.backgroundColor = [UIColor colorWithRed:con.bgRed/255.0f green:con.bgGreen/255.0f blue:con.bgBlue/255.0f alpha:1.0];
	UIImageView *logo_img = [[UIImageView alloc]initWithFrame:CGRectMake(0, 2, 170, 40)];
	NSData *data=[Base64 decode:con.logoImgdata];
	logo_img.image=	[UIImage imageWithData:[NSData dataWithData:data]];
	self.navigationItem.titleView=logo_img;
	
	[self createtableview];
	[self signoutbt];
}
-(void)signoutbt
{
	
	
	UIBarButtonItem *signoutButton = [[UIBarButtonItem alloc]
									  initWithTitle:@"Sign Off"
									  style:UIBarButtonItemStyleBordered
									  target:self
									  action:@selector(signout)];
    self.navigationItem.rightBarButtonItem =signoutButton;
}
-(void)signout
{
	[((AcclarisAppDelegate *)[[UIApplication sharedApplication] delegate]) removeTabBar];
}

-(void)createtableview
{
	UITableView	*acctable=[[UITableView alloc] initWithFrame:CGRectMake(0,10,320,300) style:UITableViewStyleGrouped];
	acctable.delegate = self;
	acctable.dataSource = self;
	acctable.scrollEnabled = YES;
	acctable.autoresizesSubviews = YES;
	acctable.showsVerticalScrollIndicator=YES;
	acctable.showsHorizontalScrollIndicator=YES;
	acctable.backgroundColor=[UIColor clearColor];
	[self.view addSubview:acctable];	
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView  
{
	return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	
	return [arr_celltytle count] ;
	
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{  
	static NSString *CellIdentifier = @"Cell";
	static NSString *CellIdentifier1 = @"Cell1";
	UITableViewCell *cell;
	
	if(cell==nil)
	{
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier] autorelease];
	}
	else
	{
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier1];
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier1] autorelease];
		
	}
	cell.selectionStyle=UITableViewCellSelectionStyleNone;
	cell.backgroundColor=[UIColor whiteColor];
	
	cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;		
	
	UILabel *cellLabelText=[[UILabel alloc]initWithFrame:CGRectMake(19,17,250,20)];
	NSString *strFont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];
	cellLabelText.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
	cellLabelText.textColor =[UIColor colorWithRed:con.linkgnRed/255.0 green:con.linkgnGreen/255.0 blue:con.linkgnBlue/255.0 alpha:1.0];
	cellLabelText.backgroundColor=[UIColor clearColor];
	cellLabelText.text = [arr_celltytle objectAtIndex:indexPath.row];
	[cell.contentView addSubview:cellLabelText];
	
	
	return cell;
	
	
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return 55;
	
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	if (indexPath.row==0)
	{
		[transaction_info replaceObjectAtIndex:3 withObject:@"GetActiveSchedules"];
		ActiveSchedule *myactiveSchedule=[[ActiveSchedule alloc]initWithArray:transaction_info];
		[self.navigationController pushViewController:myactiveSchedule animated:YES];
	}
	if (indexPath.row==1)
	{
		[transaction_info replaceObjectAtIndex:3 withObject:@"GetInActiveSchedules"];
		ActiveSchedule *myactiveSchedule=[[ActiveSchedule alloc]initWithArray:transaction_info];
		[self.navigationController pushViewController:myactiveSchedule animated:YES];
	}
	
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
