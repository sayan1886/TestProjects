    //
//  EditClaim.m
//  Acclaris
//
//  Created by Subhojit on 07/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "EditClaim.h"
#import "configurables.h"
#import "AcclarisViewController.h"
BOOL back;
@implementation EditClaim

-(id)initWithrow:(int)row target:(id)target action:(SEL)action

{
	
	self=[super init];
	if(self==nil)
	{
		
		return nil;
	}
	else 
	{
		actionTarget=target;
		actionHandler=action;
	   Selectedrow=row;
				
	}
	return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
	
	
	
	arrunsubmittedClaimwork=[UnsubmittedClaimParser getarrgetunsubmittedClaim];
	strallowDuplicateClaim=@"";
	strAccValue=@"";
	
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	tools=[[MyTools alloc]init];
	loadingView=[tools createActivityIndicator1];
	
	arrDecide=[ClaimSubmitNewParser getarrm_passArray];
	   
	customMessageList_dict=[[NSUserDefaults standardUserDefaults] objectForKey:@"customMessageList"];
	arrsubmitcatagory=[ClaimSubmitNewParser getarrCatagory];
	
	NSString *strmaincatagory=((UnsubmittedclaimOBJ *)[arrunsubmittedClaimwork objectAtIndex:Selectedrow]).strClaimCategory;
	
	for(int i=0;i<[arrsubmitcatagory count];i++)
	{
		objClaimsubmit=(ClaimSubmitNewOBJ*)[arrsubmitcatagory objectAtIndex:i];

		
		if([objClaimsubmit.strlabel isEqualToString:strmaincatagory])
		{
			
			arrsubcatagory=objClaimsubmit.arrclaimsubtype;
			strisprior=objClaimsubmit.strpriorYearActivePlan;
			NSLog(@">>>>>>.%@",strisprior);
			for(int j=0;j<[arrsubcatagory count];j++)
			{
				
				//ClaimSubOBJ*  myrole1=(ClaimSubOBJ*)[arrsubcatagory objectAtIndex:j];
				
	
		   }
			
			break;
			
		}
	}
		
	
	NSMutableArray *arr_myconfig=[AcclarisViewController staticarr_config];
	con=(configurables *)[arr_myconfig objectAtIndex:0];
	strFront=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];
	self.navigationController.navigationBar.tintColor=[UIColor colorWithRed:con.navbarRed/255.0f green:con.navbarGreen/255.0f blue:con.navbarBlue/255.0f alpha:1.0];
	
	self.view.backgroundColor = [UIColor colorWithRed:con.bgRed/255.0f green:con.bgGreen/255.0f blue:con.bgBlue/255.0f alpha:1.0];
	UIImageView *logo_img = [[UIImageView alloc]initWithFrame:CGRectMake(0, 2, 170, 40)];
	NSData *data=[Base64 decode:con.logoImgdata];
	logo_img.image=	[UIImage imageWithData:[NSData dataWithData:data]];
	self.navigationItem.titleView=logo_img;
	
	[self createbar_button];
	
	
	[self CreateView];
	
}
-(void)createbar_button
{
	
	UIBarButtonItem *signoutButton = [[UIBarButtonItem alloc]
									  initWithTitle:@"Sign Off"
									  style:UIBarButtonItemStyleBordered
									  target:self
									  action:@selector(signout)];
    self.navigationItem.rightBarButtonItem =signoutButton;
	
}
-(void)signout
{
	
	[((AcclarisAppDelegate *)[[UIApplication sharedApplication] delegate]) removeTabBar];
}

-(void)CreateView
{
	
	strFont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];
	
	NSData *data_btnimg=[Base64 decode:con.btnImgdata];
	
	table=[[UITableView alloc]initWithFrame:CGRectMake(0, 60, 320, 240) style:UITableViewStylePlain];
	table.backgroundColor = [UIColor clearColor];
	table.bounces = YES;
	table.delegate=self;
	table.dataSource=self;
	table.separatorColor=[UIColor clearColor];
	[self.view addSubview:table];
	
	UIView *HeaderView=[[[UIView alloc]initWithFrame:CGRectMake(0, 0, 320, 40)]autorelease];
	HeaderView.backgroundColor=[UIColor colorWithRed:con.bgRed2/255.0 green:con.bgGreen2/255.0 blue:con.bgBlue2/255.0 alpha:1.0];
	[self.view addSubview:HeaderView];
	
	NSString *strViewTitle=@"Claim Details";
	
	UILabel *lbltext=[[UILabel alloc]initWithFrame:CGRectMake(10, 5, 240, 35)];
	lbltext.text=strViewTitle;
	lbltext.backgroundColor=[UIColor clearColor];
	lbltext.textColor=[UIColor whiteColor];
	lbltext.numberOfLines=0;
	lbltext.font=[UIFont fontWithName:strFont size:con.headerImpfntsize];
	[HeaderView addSubview:lbltext];
	[lbltext release],lbltext=nil;
	
	
	
	/*if([[arrDecide objectAtIndex:2]isEqualToString:@"Both"])
	{
		
		UIView *secondView=[[[UIView alloc]initWithFrame:CGRectMake(0,241, 320, 40)]autorelease];
		secondView.backgroundColor=[UIColor colorWithRed:con.bgRed2/255.0 green:con.bgGreen2/255.0 blue:con.bgBlue2/255.0 alpha:1.0];
		[self.view addSubview:secondView];
		
		NSString *strViewTitlesecond=@"Select";
				
		UILabel *lbltextsecond=[[UILabel alloc]initWithFrame:CGRectMake(10, 3, 210, 35)];
		lbltextsecond.text=strViewTitlesecond;
		lbltextsecond.backgroundColor=[UIColor clearColor];
		lbltextsecond.textColor=[UIColor whiteColor];
		lbltextsecond.numberOfLines=0;
		lbltextsecond.font=[UIFont fontWithName:strFont size:con.headerImpfntsize];
		[secondView addSubview:lbltextsecond];
		[lbltextsecond release],lbltextsecond=nil;
		
		btnRadio=[UIButton buttonWithType:UIButtonTypeCustom];
		btnRadio.frame=CGRectMake(10, 290, 25, 20);
		
		//[btnRadio setBackgroundImage:[UIImage imageNamed:@"rdo_btn.png"] forState:UIControlStateNormal];
		[btnRadio addTarget:self action:@selector(ClickbtnRadio:) forControlEvents:UIControlEventTouchUpInside];
		[self.view addSubview:btnRadio];
		
		UILabel *lblPayself=[[UILabel alloc]initWithFrame:CGRectMake(43, 282, 60, 35)];
		lblPayself.text=@"Pay Self";
		lblPayself.backgroundColor=[UIColor clearColor];
		lblPayself.textColor=[UIColor blackColor];
		lblPayself.font=[UIFont fontWithName:@"Helvetica-Bold" size:13];
		[self.view addSubview:lblPayself];
		[lblPayself release],lblPayself=nil;
		
		
		btnRadio1=[UIButton buttonWithType:UIButtonTypeCustom];
		btnRadio1.frame=CGRectMake(210, 290, 25, 20);
		
		[btnRadio1 addTarget:self action:@selector(ClickbtnRadio1:) forControlEvents:UIControlEventTouchUpInside];
		[self.view addSubview:btnRadio1];
		//strPaystatus=@"Self";
		
		if([((UnsubmittedclaimOBJ *)[arrunsubmittedClaimwork objectAtIndex:Selectedrow]).strpayType isEqualToString:@"Self"])
			
		{
			
			[btnRadio setBackgroundImage:[UIImage imageNamed:@"rdo_btn_ckd.png"] forState:UIControlStateNormal];
			strPaystatus=@"Self";
		}
		else 
		{
			
			[btnRadio1 setBackgroundImage:[UIImage imageNamed:@"rdo_btn_ckd.png"] forState:UIControlStateNormal];
			strPaystatus=@"Other";
		}

		
		UILabel *lblother=[[UILabel alloc]initWithFrame:CGRectMake(245, 282, 70, 35)];
		lblother.text=@"Pay Others";
		lblother.backgroundColor=[UIColor clearColor];
		lblother.textColor=[UIColor blackColor];
		lblother.font=[UIFont fontWithName:@"Helvetica-Bold" size:13];
		[self.view addSubview:lblother];
		[lblother release],lblother=nil;
		
		
	}*/
	 if([[arrDecide objectAtIndex:2]isEqualToString:@"Self"])
	{
		table.frame=CGRectMake(0, 60, 320, 250);
		strPaystatus=@"Self";
		
	}
	 else if([[arrDecide objectAtIndex:2]isEqualToString:@"Other"])
	 {

	
		table.frame=CGRectMake(0, 60, 320, 250);
		strPaystatus=@"Other";
		
	}
	
	
	UIButton *btnContinue=[UIButton buttonWithType:UIButtonTypeCustom];
	btnContinue.frame=CGRectMake(30, 320, 260, 40);
	[btnContinue setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
	[btnContinue setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	btnContinue.titleLabel.font = [UIFont fontWithName:con.btnfontname size:con.btnfontsize];
	[btnContinue setTitle:@"Continue" forState:UIControlStateNormal];
	[btnContinue addTarget:self action:@selector(ClickbtnContinue) forControlEvents:UIControlEventTouchUpInside];					 
	[self.view addSubview:btnContinue];
	
	if([strisprior isEqualToString:@"Yes"])
	{
		
		icheckbox=@"";
		[self constructTableCell];
		
	}
	else
	{
		icheckbox=@"No";
		[icheckbox retain];
		[self constructTableCellnew];
		
	}
	
}	

-(void)ClickbtnRadio:(id)sender
{
	
	if(btnRadio.currentBackgroundImage==[UIImage imageNamed:@"rdo_btn.png"])
	{
		
		strPaystatus=@"Self";
		[btnRadio setBackgroundImage:[UIImage imageNamed:@"rdo_btn_ckd.png"] forState:UIControlStateNormal];
	    [btnRadio1 setBackgroundImage:[UIImage imageNamed:@"rdo_btn.png"] forState:UIControlStateNormal];
	}
	
	else 
	{
		
		//[btnRadio setBackgroundImage:[UIImage imageNamed:@"rdo_btn.png"] forState:UIControlStateNormal];
		
	}
	
}

-(void)ClickbtnRadio1:(id)sender
{
	
	
	if(btnRadio1.currentBackgroundImage==[UIImage imageNamed:@"rdo_btn.png"])
	{
		strPaystatus=@"Other";
		[btnRadio1 setBackgroundImage:[UIImage imageNamed:@"rdo_btn_ckd.png"] forState:UIControlStateNormal];
	    [btnRadio setBackgroundImage:[UIImage imageNamed:@"rdo_btn.png"] forState:UIControlStateNormal];
	}
	
	else 
	{
		
		//[btnRadio1 setBackgroundImage:[UIImage imageNamed:@"rdo_btn.png"] forState:UIControlStateNormal];
		
	}
	
}
-(void)ClickbtnContinue
{
	
	if([txttype.text isEqualToString:@""])
	{
		NSString *strmessage=[[customMessageList_dict valueForKey:@"200044"]valueForKey:@"message"];
		NSString *strtype=[[customMessageList_dict valueForKey:@"200044"]valueForKey:@"type"];
		
		
		
		UIAlertView *alertview=[[UIAlertView alloc]initWithTitle:strtype message:strmessage delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		alertview.delegate=self;
		[alertview show];
		alertview.tag=333;
		[alertview release],alertview=nil;
		return ;
		
		
	}
	
	else if([txtAmount.text isEqualToString:@""])
	{
		NSString *strmessage=[[customMessageList_dict valueForKey:@"200045"]valueForKey:@"message"];
		NSString *strtype=[[customMessageList_dict valueForKey:@"200045"]valueForKey:@"type"];
		
		
		
		UIAlertView *alertview=[[UIAlertView alloc]initWithTitle:strtype message:strmessage delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		alertview.delegate=self;
		[alertview show];
		alertview.tag=333;
		[alertview release],alertview=nil;
		return ;
		
	}
	
	else if([txtProvider.text isEqualToString:@""])
	{
		NSString *strmessage=[[customMessageList_dict valueForKey:@"200046"]valueForKey:@"message"];
		NSString *strtype=[[customMessageList_dict valueForKey:@"200046"]valueForKey:@"type"];
		
		UIAlertView *alertview=[[UIAlertView alloc]initWithTitle:strtype message:strmessage delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		alertview.delegate=self;
		[alertview show];
		alertview.tag=333;
		[alertview release],alertview=nil;
		return ;
		
		
	}
	else if([txtserviceFrom.text isEqualToString:@""])
	{
		
		NSString *strmessage=[[customMessageList_dict valueForKey:@"200047"]valueForKey:@"message"];
		NSString *strtype=[[customMessageList_dict valueForKey:@"200047"]valueForKey:@"type"];
		UIAlertView *alertview=[[UIAlertView alloc]initWithTitle:strtype message:strmessage delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		alertview.delegate=self;
		[alertview show];
		alertview.tag=333;
		[alertview release],alertview=nil;
		return ;
		
	}
	
	else if ([txtserviceTo.text isEqualToString:@""])
	{
		
		txtserviceTo.text=txtserviceFrom.text;
		
	}
	
   if(btnRadio.currentBackgroundImage==[UIImage imageNamed:@"rdo_btn.png"] && btnRadio1.currentBackgroundImage==[UIImage imageNamed:@"rdo_btn.png"])
	{
		NSString *strmessage=[[customMessageList_dict valueForKey:@"200048"]valueForKey:@"message"];
		NSString *strtype=[[customMessageList_dict valueForKey:@"200048"]valueForKey:@"type"];
		
		UIAlertView *alertview=[[UIAlertView alloc]initWithTitle:strtype message:strmessage delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		alertview.delegate=self;
		alertview.tag=333;
		[alertview show];
		[alertview release],alertview=nil;
		return ;
		
	}
	
	
	back=YES;
	[self Save];
	NSString *strAmount=@"$";
	[strAmount stringByAppendingFormat:@"%@",txtAmount.text];
	
	
     userinfo_arr=[passPerser passresponce];
	
	[self ClaimSave];
	
		
	
}
-(void)onSuccesful
{
	

	[tools stopLoading:loadingView];
	
	
	
	arrclaimsave=[Claimonlineserviceparser getarrClaimonlinesave];
	strAccValue=@"";
	
	if([strPaystatus isEqualToString:@"Self"] && ((ClaimonlineSaveOBJ *)[arrclaimsave objectAtIndex:0]).strerrorText.length==0)
		
	{
		
		//back=NO;
		app.checkclassname=@"Edit claim";
		[actionTarget performSelector:actionHandler withObject:nil];
		
		[self.navigationController popViewControllerAnimated:YES];
	}
	else if([strPaystatus isEqualToString:@"Other"] && ((ClaimonlineSaveOBJ *)[arrclaimsave objectAtIndex:0]).strerrorText.length==0)
		
	{
		
		SubmitNewClaimThree *obj=[[[SubmitNewClaimThree alloc]init]autorelease];
		[self.navigationController pushViewController:obj animated:YES];
		
		//SelectServiceProvider *obj=[[SelectServiceProvider alloc]initwithDict:DictSavedSubmitclaimInfo withtype:type];
		//[self.navigationController pushViewController:obj animated:YES];
	}
	
	else if([((ClaimonlineSaveOBJ *)[arrclaimsave objectAtIndex:0]).strreturnCode isEqualToString:@"76"])
	{
		
		isfirstmultiple=YES;
		MultipleAccountView *obj=[[MultipleAccountView alloc]initWithFrame:CGRectMake(0, 0, 320, 175)];
		obj.Interesteddelegate=self;		
		UIAlertView *alertview=[[UIAlertView alloc]initWithTitle:@"Please specify Account Type" message:@"\n\n\n\n\n\n\n" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Continue",nil];
		alertview.delegate=self;
		alertview.tag=112;
		[alertview show];
		
		
		[alertview addSubview:obj];
		
		
	}
	
	else if([((ClaimonlineSaveOBJ *)[arrclaimsave objectAtIndex:0]).strreturnCode isEqualToString:@"89"]) ///select payee slist
	{
		
		type=self;
		
		UIAlertView *alertview=[[UIAlertView alloc]initWithTitle:@"Info" message:((ClaimonlineSaveOBJ *)[arrclaimsave objectAtIndex:0]).strerrorText delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
		alertview.delegate=self;
		alertview.tag=333;
		[alertview show];
		[alertview release],alertview=nil;	
		
		SelectServiceProvider *obj=[[SelectServiceProvider alloc]initwithDict:DictSavedSubmitclaimInfo withtype:type];
		[self.navigationController pushViewController:obj animated:YES];
		
		
	}
	else if([((ClaimonlineSaveOBJ *)[arrclaimsave objectAtIndex:0]).strreturnCode isEqualToString:@"90"]) ///Duplicate claim
	{
		
		UIAlertView *alertview=[[UIAlertView alloc]initWithTitle:@"Info" message:((ClaimonlineSaveOBJ *)[arrclaimsave objectAtIndex:0]).strerrorText delegate:self cancelButtonTitle:@"No" otherButtonTitles:@"Yes",nil];
		alertview.delegate=self;
		alertview.tag=100;
		[alertview show];
		[alertview release],alertview=nil;	
		
	}
	
	else 
	{
		
		
		UIAlertView *alertview=[[UIAlertView alloc]initWithTitle:@"Info" message:((ClaimonlineSaveOBJ *)[arrclaimsave objectAtIndex:0]).strerrorText delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		alertview.delegate=self;
		[alertview show];
		alertview.tag=333;
		[alertview release],alertview=nil;
		return ;
		
	}
	

}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex

{
	
   if(alertView.tag==100)
	{
		
		if(buttonIndex==0)
		{
			
			[self.navigationController popViewControllerAnimated:YES];
		}
		
		else if(buttonIndex==1)
			
		 {
			
			strallowDuplicateClaim=@"Yes";
			 [DictSavedSubmitclaimInfo setObject:strallowDuplicateClaim forKey:@"duplicateclaim"];
			NSString *strAmount=@"$";
			strAmount=[strAmount stringByAppendingFormat:@"%@",txtAmount.text];
			
			
			///call for multiple account with opcode 5002///
			 if(isfirstmultiple==YES)
			 {
				 stropcodevalue=@"5003";
				 isfirstmultiple=NO;
			 }
			 else 
			 {
				 stropcodevalue=@"5001";
			 }
			 
			[self ClaimSave2];
			
			
			}
		
	  }
	
			else if(alertView.tag==333)
			{
				
				if(buttonIndex==0)
				{
					
					;
				}
				
				else 
				{
					;
				}
				
				
			}
				
			else if(alertView.tag==999)
			{
				
				if(buttonIndex==0)
				{
					
					
					/*NSString *strAmount=@"$";
					 strAmount=[strAmount stringByAppendingFormat:@"%@",txtAmount.text];
					 
					 [strselectclaimcatagory retain];
					 
					 //////call for multiple account with opcode 5002/////
					 
					 stropcodevalue=@"5002";*/
					
					[self ClaimSave];
					
				}
				
				else 
				{
					;
				}
				
				
			}

			else if(alertView.tag==112)
				
			{
				
				if(buttonIndex==0)
				{
					
					
				}
				
				else 
				{
					if([strAccValue length]==0)
					{
						
						NSString *strmessage=[[customMessageList_dict valueForKey:@"200018"]valueForKey:@"message"];
						NSString *strtype=[[customMessageList_dict valueForKey:@"200018"]valueForKey:@"type"];
						
						UIAlertView *alertview=[[UIAlertView alloc]initWithTitle:strtype message:strmessage delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
						alertview.delegate=self;
						[alertview show];
						alertview.tag=999;
						[alertview release],alertview=nil;
						return ;
						
						
					}
					else 
					{
						
						NSString *strAmount=@"$";
						strAmount=[strAmount stringByAppendingFormat:@"%@",txtAmount.text];
						
						[strselectclaimcatagory retain];
						
						//////call for multiple account with opcode 5002/////
						
						stropcodevalue=@"5002";
						
						[self ClaimSave2];
						
						
					}
					
				}
				
			}
	
	
		/*else  if(buttonIndex==0)
					
				 {
					 if([strAccValue length]==0)
						 
					 {
						 
						 
						 UIAlertView *alertview=[[UIAlertView alloc]initWithTitle:@"Info" message:@"Please select Account type" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
						 alertview.delegate=self;
						 [alertview show];
						 alertview.tag=999;
						 [alertview release],alertview=nil;
						 return ;
						 
					 }
					 
					 else 
					 {
						 
					 
					
						NSString *strAmount=@"$";
						strAmount=[strAmount stringByAppendingFormat:@"%@",txtAmount.text];
						
						
						///call for multiple account with opcode 5002///
						stropcodevalue=@"5002";
						 [self ClaimSave2];		
					
				}
		}*/
}

-(void)whichSelected:(NSString	*)str
{
	
	strAccValue=str;
	
	NSLog(@"strAccValue %@",strAccValue);
	[DictSavedSubmitclaimInfo setObject:strAccValue forKey:@"Accounttype"];

}

-(void)onSuccesfull2
{
	
	[tools stopLoading:loadingView];
	
	arrclaimsave=[Claimonlineserviceparser getarrClaimonlinesave];
	
	if([((ClaimonlineSaveOBJ *)[arrclaimsave objectAtIndex:0]).strreturnCode isEqualToString:@"90"])
		
	{
		
		UIAlertView *alertview=[[UIAlertView alloc]initWithTitle:@"Duplicate claim confirmation" message:((ClaimonlineSaveOBJ *)[arrclaimsave objectAtIndex:0]).strerrorText delegate:self cancelButtonTitle:@"No" otherButtonTitles:@"Yes",nil];
		alertview.delegate=self;
		alertview.tag=100;
		[alertview show];
		[alertview release],alertview=nil;
		
		
	}
	else if([((ClaimonlineSaveOBJ *)[arrclaimsave objectAtIndex:0]).strreturnCode isEqualToString:@"89"])/// select payye list
	{
		
		type=self;
		SelectServiceProvider *obj=[[SelectServiceProvider alloc]initwithDict:DictSavedSubmitclaimInfo withtype:type];
		[self.navigationController pushViewController:obj animated:YES];
		
	}
	else if([((ClaimonlineSaveOBJ *)[arrclaimsave objectAtIndex:0]).strreturnCode isEqualToString:@"88"])
	{
	
		
		UIAlertView *alertview=[[UIAlertView alloc]initWithTitle:@"Info" message:((ClaimonlineSaveOBJ *)[arrclaimsave objectAtIndex:0]).strerrorText delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		alertview.delegate=self;
		alertview.tag=333;
		[alertview show];
		[alertview release],alertview=nil;
		
		
	}
	else 
	{
		
		app.checkclassname=@"Edit claim";
		[actionTarget performSelector:actionHandler withObject:nil];
		[self.navigationController popViewControllerAnimated:YES];
	}

	

	
	/*if([strPaystatus isEqualToString:@"Self"] && ((ClaimonlineSaveOBJ *)[arrclaimsave objectAtIndex:0]).strerrorText.length==0)
	 
	 {
	 
	 SubmitNewClaimThree *obj=[[[SubmitNewClaimThree alloc]init]autorelease];
	 [self.navigationController pushViewController:obj animated:YES];
	 }
	 else if([strPaystatus isEqualToString:@"Other"] && ((ClaimonlineSaveOBJ *)[arrclaimsave objectAtIndex:0]).strerrorText.length==0)
	 {
	 //SelectServiceProvider *obj=[[[SelectServiceProvider alloc]init] autorelease];
	 //[self.navigationController pushViewController:obj animated:YES];
	 
	 
	 SubmitNewClaimThree *obj=[[[SubmitNewClaimThree alloc]init]autorelease];
	 [self.navigationController pushViewController:obj animated:YES];
	 
	 
	 }*/
	
	
}
-(void)onFailure2

{
	
	[tools stopLoading:loadingView];
	
}
-(void)onFailure
{
	
	[tools stopLoading:loadingView];
	
}

-(void)constructTableCell
{
	arrAllSection = [[NSMutableArray alloc] init];
	
#pragma mark --First Section
	NSMutableArray *arrFirstSection = [[NSMutableArray alloc]init];
	
	UITableViewCell *cell00 = [[UITableViewCell alloc] init];
	[self TypeInput:cell00];
	[arrFirstSection addObject:cell00];
	[cell00 release];
	
	UITableViewCell *cell01 = [[UITableViewCell alloc] init];
	[self AmountInput:cell01];
	[arrFirstSection addObject:cell01];
	[cell01 release];
	
	UITableViewCell *cell02 = [[UITableViewCell alloc] init];
	[self ProviderInput:cell02];
	[arrFirstSection addObject:cell02];
	[cell02 release];
	
	UITableViewCell *cell03 = [[UITableViewCell alloc] init];
	[self ServiceFromInput:cell03];
	[arrFirstSection addObject:cell03];
	[cell03 release];
	
	
	UITableViewCell *cell10 = [[UITableViewCell alloc] init];
	[self ServiceToInput:cell10];
	[arrFirstSection addObject:cell10];
	[cell10 release];
	
	UITableViewCell *cell11 = [[UITableViewCell alloc] init];
	[self PriorInput:cell11];
	[arrFirstSection addObject:cell11];
	[cell11 release];
	
	UITableViewCell *cell12 = [[UITableViewCell alloc] init];
	[self NoteInput:cell12];
	[arrFirstSection addObject:cell12];
	[cell12 release];
	
	UITableViewCell *cell13 = [[UITableViewCell alloc] init];
	[self HeadertypeInput:cell13];
	[arrFirstSection addObject:cell13];
	[cell13 release];
	
	
	UITableViewCell *cell14= [[UITableViewCell alloc] init];
	[self PaytypeInput:cell14];
	[arrFirstSection addObject:cell14];
	[cell14 release];
	
	
	[arrAllSection addObject:arrFirstSection];
	[arrFirstSection release];
	
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	
    return 1;
}


// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	
	
	if([strisprior isEqualToString:@"Yes"])
	{
		
		return 9;
	}
	else 
	{
		
		return 8;
	}
	
	
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
   	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
	if(nil == cell)
	{
		NSLog(@"%@",[[arrAllSection objectAtIndex:0] objectAtIndex:indexPath.row]);
		cell = [[arrAllSection objectAtIndex:0] objectAtIndex:indexPath.row];
		
	}
	
	cell.selectionStyle = UITableViewCellSelectionStyleNone;
	
    return cell;
	
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	
	
	return 50.0;
	
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath

{
	
	;
	
	
}
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
	
	NSString *str=@"";
	txttype.text=[str stringByAppendingFormat:@"%@",((ClaimSubOBJ *)[arrsubcatagory objectAtIndex:[pickerView selectedRowInComponent:0]]).strsubname];
	
		
	
}
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
	
	
		objClaimsub=(ClaimSubOBJ*)[arrsubcatagory  objectAtIndex:row];
	
	
	    return objClaimsub.strsubname;
	
	
}

- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component
{
	// first column size is wider to hold names
	
	return 150.0;                     // second column is narrower to show numbers
	
	
}

- (CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component
{
	return 40.0;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
	
	return [arrsubcatagory count];
	
	//return [pickerViewArray count];
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
	
	return 1;
}
-(void)CreatePickerView
{
	
	
	myPickerView = [[UIPickerView alloc] initWithFrame:CGRectMake(0, 100, 200, 150)];
	myPickerView.showsSelectionIndicator = YES;
	myPickerView.dataSource=self;
	myPickerView.delegate = self;
	[self.view addSubview:myPickerView];
	
	
}
-(void)datePickerCreate
{		
	//NSDateFormatter *df = [[NSDateFormatter alloc] init];
	//df.dateStyle = NSDateFormatterFullStyle;
	//df setDateFormat:@" MM-dd-yyyy"];
	//[df release];
	//strdDate=[df stringFromDate:datePicker.date]; 
	
	datePicker = [[UIDatePicker alloc] initWithFrame:CGRectMake(0, 240, 60, 60)];
	
	//datePicker.transform = CGAffineTransformMake(0.6, 0, 0, 0.7, -80, 0);
	
	
	datePicker.datePickerMode = UIDatePickerModeDate;
	datePicker.hidden = NO;
	datePicker.date = [NSDate date];
	//datePicker.maximumDate=[NSDate date];
	[datePicker addTarget:self
				   action:@selector(changeDateInLabel:)
		 forControlEvents:UIControlEventValueChanged];
	
	[self.view addSubview:datePicker];
	//[datePick release];
}
- (void)changeDateInLabel:(id)sender
{	
	NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
	[dateFormat setDateFormat:@"MM/dd/yyyy"];
	NSString	*strDate1=[dateFormat stringFromDate:datePicker.date]; 
	
	if([strTxtNm isEqualToString:@"txtserviceTo"])
	{
		
		
		txtserviceTo.text=strDate1;
		
	}
	
	else if([strTxtNm isEqualToString:@"txtserviceFrom"])
		
		txtserviceFrom.text=strDate1;
	
	
}
-(void)constructTableCellnew
{
	arrAllSection = [[NSMutableArray alloc] init];
	
#pragma mark --First Section
	NSMutableArray *arrFirstSection = [[NSMutableArray alloc]init];
	
	UITableViewCell *cell00 = [[UITableViewCell alloc] init];
	[self TypeInput:cell00];
	[arrFirstSection addObject:cell00];
	[cell00 release];
	
	UITableViewCell *cell01 = [[UITableViewCell alloc] init];
	[self AmountInput:cell01];
	[arrFirstSection addObject:cell01];
	[cell01 release];
	
	UITableViewCell *cell02 = [[UITableViewCell alloc] init];
	[self ProviderInput:cell02];
	[arrFirstSection addObject:cell02];
	[cell02 release];
	
	UITableViewCell *cell03 = [[UITableViewCell alloc] init];
	[self ServiceFromInput:cell03];
	[arrFirstSection addObject:cell03];
	[cell03 release];
	
	
	UITableViewCell *cell10 = [[UITableViewCell alloc] init];
	[self ServiceToInput:cell10];
	[arrFirstSection addObject:cell10];
	[cell10 release];
	
	/*UITableViewCell *cell11 = [[UITableViewCell alloc] init];
	 [self PriorInput:cell11];
	 [arrFirstSection addObject:cell11];
	 [cell11 release];*/
	
	UITableViewCell *cell11 = [[UITableViewCell alloc] init];
	[self NoteInput:cell11];
	[arrFirstSection addObject:cell11];
	[cell11 release];
	
	
	UITableViewCell *cell12 = [[UITableViewCell alloc] init];
	[self HeadertypeInput:cell12];
	[arrFirstSection addObject:cell12];
	[cell12 release];
	
	
	UITableViewCell *cell13 = [[UITableViewCell alloc] init];
	[self PaytypeInput:cell13];
	[arrFirstSection addObject:cell13];
	[cell13 release];
	
	
	[arrAllSection addObject:arrFirstSection];
	[arrFirstSection release];
	
}
#pragma mark -
#pragma mark TypeInput Method
-(void)TypeInput:(UITableViewCell *)cell
{
	UILabel *lblType=[[UILabel alloc]initWithFrame:CGRectMake(10, 0, 70, 35)];
	lblType.text=@"Type";
	lblType.backgroundColor=[UIColor clearColor];
	lblType.textColor=[UIColor blackColor];
	lblType.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
	[cell.contentView addSubview:lblType];
	[lblType release],lblType=nil;
	
	txttype=[[UITextField alloc]initWithFrame:CGRectMake(95, 0, 210, 35)];
	txttype.delegate=self;
	txttype.backgroundColor=[UIColor whiteColor];
	NSString *strtype=((UnsubmittedclaimOBJ *)[arrunsubmittedClaimwork objectAtIndex:Selectedrow]).strClaimType;
	if(strtype.length==0)
		
	       txttype.text=@"";
	else 
		txttype.text=strtype;
	

	txttype.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	txttype.borderStyle=UITextBorderStyleLine;
	txttype.returnKeyType=UIReturnKeyDone;
	txttype.textAlignment=UITextAlignmentLeft;
	txttype.autocorrectionType =UITextAutocorrectionTypeNo;
	txttype.userInteractionEnabled=YES;
	
	[cell.contentView addSubview:txttype];			
	
}

#pragma mark -
#pragma mark AmountInput Method

-(void)AmountInput:(UITableViewCell *)cell
{
	
	UILabel *lblAmount=[[UILabel alloc]initWithFrame:CGRectMake(10, 0, 70, 35)];
	lblAmount.text=@"Amount";
	lblAmount.backgroundColor=[UIColor clearColor];
	lblAmount.textColor=[UIColor blackColor];
	//lblType.numberOfLines=0;
	lblAmount.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
	[cell.contentView addSubview:lblAmount];
	[lblAmount release],lblAmount=nil;
	
	
	txtAmount=[[UITextField alloc]initWithFrame:CGRectMake(95, 0, 210, 35)];
	txtAmount.delegate=self;
	txtAmount.backgroundColor=[UIColor whiteColor];
	NSString *strAmount=((UnsubmittedclaimOBJ *)[arrunsubmittedClaimwork objectAtIndex:Selectedrow]).strClaimAmt;
	if(strAmount.length==0)
		
		txtAmount.text=@"";
	else 
		txtAmount.text=strAmount;
	
	txtAmount.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	txtAmount.keyboardType=UIKeyboardTypeNumbersAndPunctuation;
	txtAmount.borderStyle=UITextBorderStyleLine;
	txtAmount.returnKeyType=UIReturnKeyDone;
	txtAmount.textAlignment=UITextAlignmentLeft;
	txtAmount.autocorrectionType =UITextAutocorrectionTypeNo;
	txtAmount.userInteractionEnabled=YES;
	
	
	
	[cell.contentView addSubview:txtAmount];
}

#pragma mark -
#pragma mark ProviderInput Method

-(void)ProviderInput:(UITableViewCell *)cell
{
	UILabel *lblProvider=[[UILabel alloc]initWithFrame:CGRectMake(10, 0, 75, 35)];
	lblProvider.text=@"Provider";
	lblProvider.backgroundColor=[UIColor clearColor];
	lblProvider.textColor=[UIColor blackColor];
	//lblType.numberOfLines=0;
	lblProvider.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
	[cell.contentView addSubview:lblProvider];
	[lblProvider release],lblProvider=nil;
	
	
	txtProvider=[[UITextField alloc]initWithFrame:CGRectMake(95, 0, 210, 35)];
	txtProvider.delegate=self;
	txtProvider.backgroundColor=[UIColor whiteColor];
	NSString *strprovidername=((UnsubmittedclaimOBJ *)[arrunsubmittedClaimwork objectAtIndex:Selectedrow]).strproviderName;
	
	     if (strprovidername.length == 0 )
		
		       txtProvider.text=@"";
	   else
				txtProvider.text=strprovidername;
	
	txtProvider.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	txtProvider.borderStyle=UITextBorderStyleLine;
	txtProvider.returnKeyType=UIReturnKeyDone;
	txtProvider.textAlignment=UITextAlignmentLeft;
	txtProvider.autocorrectionType =UITextAutocorrectionTypeNo;
	txtProvider.userInteractionEnabled=YES;
	[cell.contentView addSubview:txtProvider];	
	
	
}

#pragma mark -
#pragma mark ServiceFromInput Method

-(void)ServiceFromInput:(UITableViewCell *)cell
{
	UILabel *lblServiceFrom=[[UILabel alloc]initWithFrame:CGRectMake(10, 0, 70, 40)];
	lblServiceFrom.text=@"Service From";
	lblServiceFrom.backgroundColor=[UIColor clearColor];
	lblServiceFrom.textColor=[UIColor blackColor];
	lblServiceFrom.numberOfLines=0;
	lblServiceFrom.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
	[cell.contentView addSubview:lblServiceFrom];
	[lblServiceFrom release],lblServiceFrom=nil;
	
	txtserviceFrom=[[UITextField alloc]initWithFrame:CGRectMake(95, 0, 100, 35)];
	txtserviceFrom.delegate=self;
	txtserviceFrom.backgroundColor=[UIColor whiteColor];
	txtserviceFrom.text=((UnsubmittedclaimOBJ *)[arrunsubmittedClaimwork objectAtIndex:Selectedrow]).strserviceBegins;
	txtserviceFrom.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	txtserviceFrom.font=[UIFont fontWithName:@"Helvetica" size:12];
	txtserviceFrom.borderStyle=UITextBorderStyleLine;
	txtserviceFrom.returnKeyType=UIReturnKeyDone;
	txtserviceFrom.textAlignment=UITextAlignmentLeft;
	txtserviceFrom.autocorrectionType =UITextAutocorrectionTypeNo;
	txtserviceFrom.userInteractionEnabled=YES;
	[cell.contentView addSubview:txtserviceFrom];
}

#pragma mark -
#pragma mark ServiceToInput Method

-(void)ServiceToInput:(UITableViewCell *)cell
{
	UILabel *lblServiceTo=[[UILabel alloc]initWithFrame:CGRectMake(10, 0, 70, 40)];
	lblServiceTo.text=@"Service To";
	lblServiceTo.backgroundColor=[UIColor clearColor];
	lblServiceTo.textColor=[UIColor blackColor];
	lblServiceTo.numberOfLines=0;
	lblServiceTo.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
	[cell.contentView addSubview:lblServiceTo];
	[lblServiceTo release],lblServiceTo=nil;
	
	
	txtserviceTo=[[UITextField alloc]initWithFrame:CGRectMake(95, 0, 100, 35)];
	txtserviceTo.delegate=self;	
	txtserviceTo.backgroundColor=[UIColor whiteColor];
	txtserviceTo.text=((UnsubmittedclaimOBJ *)[arrunsubmittedClaimwork objectAtIndex:Selectedrow]).strserviceEnds;
	txtserviceTo.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	txtserviceTo.font=[UIFont fontWithName:@"Helvetica" size:12];
	txtserviceTo.borderStyle=UITextBorderStyleLine;
	txtserviceTo.returnKeyType=UIReturnKeyDone;
	txtserviceTo.textAlignment=UITextAlignmentLeft;
	txtserviceTo.autocorrectionType =UITextAutocorrectionTypeNo;
	txtserviceTo.userInteractionEnabled=YES;
	[cell.contentView addSubview:txtserviceTo];
	
	
}

#pragma mark -
#pragma mark PriorInput Method

-(void)PriorInput:(UITableViewCell *)cell
{
	UILabel *lblPrior=[[UILabel alloc]initWithFrame:CGRectMake(10, 0,110, 40)];
	lblPrior.text=@"Use Prior Year Fund?";
	lblPrior.backgroundColor=[UIColor clearColor];
	lblPrior.textColor=[UIColor blackColor];
	lblPrior.numberOfLines=0;
	lblPrior.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize]; 
	[cell.contentView addSubview:lblPrior];
	[lblPrior release],lblPrior=nil;
	
	
	UIButton *btnCheck=[UIButton buttonWithType:UIButtonTypeCustom];
	btnCheck.frame=CGRectMake(150, 5, 23, 23);
	
	
	if([((UnsubmittedclaimOBJ *)[arrunsubmittedClaimwork objectAtIndex:Selectedrow]).strprevYearPlanInd isEqualToString:@"No"])
		
	          [btnCheck setBackgroundImage:[UIImage imageNamed:@"uncheck_box.png"] forState:UIControlStateNormal];
	else 
		
	        [btnCheck setBackgroundImage:[UIImage imageNamed:@"check-box.png"] forState:UIControlStateNormal];

	[btnCheck addTarget:self action:@selector(ChkUnchk:) forControlEvents:UIControlEventTouchUpInside];
	[cell.contentView addSubview:btnCheck];
	
	
}
-(void)ChkUnchk:(id)sender
{
	UIButton *myButton = (UIButton *)sender;
	
	if(myButton.currentBackgroundImage==[UIImage imageNamed:@"uncheck_box.png"])
	{
		
		icheckbox=@"Yes";
		[myButton setBackgroundImage:[UIImage imageNamed:@"check-box.png"]forState:UIControlStateNormal];
	}
	else
	{
		icheckbox=@"No";
		[myButton setBackgroundImage:[UIImage imageNamed:@"uncheck_box.png"]forState:UIControlStateNormal];
	}
	
}
#pragma mark -
#pragma mark NoteInput Method

-(void)NoteInput:(UITableViewCell *)cell
{
	
	UILabel *lblNote=[[UILabel alloc]initWithFrame:CGRectMake(10, 0, 70, 35)];
	lblNote.text=@"Note";
	lblNote.backgroundColor=[UIColor clearColor];
	lblNote.textColor=[UIColor blackColor];
	lblNote.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
	[cell.contentView addSubview:lblNote];
	[lblNote release],lblNote=nil;
	
	
	txtViewNote=[[UITextView alloc]initWithFrame:CGRectMake(95, 0, 210, 35)];
	NSString *strnote=((UnsubmittedclaimOBJ *)[arrunsubmittedClaimwork objectAtIndex:Selectedrow]).strnote;
	if(strnote.length==0)
		
	      txtViewNote.text=@"";
	else
		txtViewNote.text=strnote;
	
	txtViewNote.delegate=self;	
	txtViewNote.backgroundColor=[UIColor whiteColor];
	[[txtViewNote layer] setBorderColor:[[UIColor blackColor] CGColor]];
	[[txtViewNote layer] setBorderWidth:1.0];
	[[txtViewNote layer] setCornerRadius:2.0];
	[txtViewNote setClipsToBounds: YES];
	txtViewNote.returnKeyType=UIReturnKeyDone;
	txtViewNote.textAlignment=UITextAlignmentLeft;
	UIEdgeInsets contentInset = txtViewNote.contentInset; 
	contentInset.bottom = 10.0; 
	txtViewNote.contentInset = contentInset; 
	txtViewNote.autocorrectionType =UITextAutocorrectionTypeNo;
	txtViewNote.userInteractionEnabled=YES;
	
	[cell.contentView addSubview:txtViewNote];
	
}
#pragma mark -
#pragma mark HeadertypeInput Method

-(void)HeadertypeInput:(UITableViewCell *)cell
{
	
	
		UIView *secondView=[[[UIView alloc]initWithFrame:CGRectMake(0,0, 320, 40)]autorelease];
		secondView.backgroundColor=[UIColor colorWithRed:con.bgRed2/255.0 green:con.bgGreen2/255.0 blue:con.bgBlue2/255.0 alpha:1.0];
		[cell.contentView addSubview:secondView];
		
		
		NSString *strViewTitlesecond=@"Select Payee";//@"Select pay type";
		//strViewTitle=[strViewTitle stringByAppendingString:@"\n"];
		//strViewTitle=[strViewTitle stringByAppendingFormat:@"%@",@"Claim"];
		
		
		UILabel *lbltextsecond=[[UILabel alloc]initWithFrame:CGRectMake(10, 3, 250, 35)];
		lbltextsecond.text=strViewTitlesecond;
		lbltextsecond.backgroundColor=[UIColor clearColor];
		lbltextsecond.textColor=[UIColor whiteColor];
		lbltextsecond.numberOfLines=0;
		lbltextsecond.font=[UIFont fontWithName:strFont size:con.headerImpfntsize];
		[cell.contentView addSubview:lbltextsecond];
		[lbltextsecond release],lbltextsecond=nil;
	
}
#pragma mark -
#pragma mark PaytypeInput Method

-(void)PaytypeInput:(UITableViewCell *)cell

{
	
	
		btnRadio=[UIButton buttonWithType:UIButtonTypeCustom];
		btnRadio.frame=CGRectMake(10, 10, 25, 25);
		//[btnRadio setBackgroundImage:[UIImage imageNamed:@"rdo_btn.png"] forState:UIControlStateNormal];
		[btnRadio addTarget:self action:@selector(ClickbtnRadio:) forControlEvents:UIControlEventTouchUpInside];
		[cell.contentView addSubview:btnRadio];
		
		UILabel *lblPayself=[[UILabel alloc]initWithFrame:CGRectMake(43, 3, 60, 35)];
		lblPayself.text=@"Pay Self";
		lblPayself.backgroundColor=[UIColor clearColor];
		lblPayself.textColor=[UIColor blackColor];
		lblPayself.font=[UIFont fontWithName:@"Helvetica-Bold" size:13];
		[cell.contentView addSubview:lblPayself];
		[lblPayself release],lblPayself=nil;
		
		
		btnRadio1=[UIButton buttonWithType:UIButtonTypeCustom];
		btnRadio1.frame=CGRectMake(180, 10, 25, 25);
		//[btnRadio1 setBackgroundImage:[UIImage imageNamed:@"rdo_btn.png"] forState:UIControlStateNormal];
		[btnRadio1 addTarget:self action:@selector(ClickbtnRadio1:) forControlEvents:UIControlEventTouchUpInside];
		[cell.contentView addSubview:btnRadio1];
	
	
	if([((UnsubmittedclaimOBJ *)[arrunsubmittedClaimwork objectAtIndex:Selectedrow]).strpayType isEqualToString:@"Self"])
		
	{
		
		[btnRadio setBackgroundImage:[UIImage imageNamed:@"rdo_btn_ckd.png"] forState:UIControlStateNormal];
		[btnRadio1 setBackgroundImage:[UIImage imageNamed:@"rdo_btn.png"] forState:UIControlStateNormal];
		strPaystatus=@"Self";
		
	}
	else 
	{
		[btnRadio setBackgroundImage:[UIImage imageNamed:@"rdo_btn.png"] forState:UIControlStateNormal];
		[btnRadio1 setBackgroundImage:[UIImage imageNamed:@"rdo_btn_ckd.png"] forState:UIControlStateNormal];
		strPaystatus=@"Other";
	}
	
	UILabel *lblother=[[UILabel alloc]initWithFrame:CGRectMake(215,3, 70, 35)];
	lblother.text=@"Pay Others";
	lblother.backgroundColor=[UIColor clearColor];
	lblother.textColor=[UIColor blackColor];
	lblother.font=[UIFont fontWithName:@"Helvetica-Bold" size:13];
	[cell.contentView addSubview:lblother];
	[lblother release],lblother=nil;
	
	
}

-(void)Save
{
	
	
	strselectclaimcatagory=((UnsubmittedclaimOBJ *)[arrunsubmittedClaimwork objectAtIndex:Selectedrow]).strClaimCategory;
	DictSavedSubmitclaimInfo=[[NSMutableDictionary alloc]init];
	
	[DictSavedSubmitclaimInfo setObject:txttype.text forKey:@"Type"];
	
	[DictSavedSubmitclaimInfo setObject:strselectclaimcatagory forKey:@"catagory"];

	
	[DictSavedSubmitclaimInfo setObject:txtAmount.text forKey:@"Amount"];
	
	[DictSavedSubmitclaimInfo setObject:txtProvider.text forKey:@"Provider"];
	
	[DictSavedSubmitclaimInfo setObject:txtserviceTo.text forKey:@"Serviveto"];
	
	[DictSavedSubmitclaimInfo setObject:txtserviceFrom.text forKey:@"Servocefrom"];
	
	[DictSavedSubmitclaimInfo setObject:txtViewNote.text forKey:@"Note"];
	
	[DictSavedSubmitclaimInfo setObject:icheckbox forKey:@"Checkbox"];
	
	[DictSavedSubmitclaimInfo setObject:strPaystatus forKey:@"paystatus"];
	
	[DictSavedSubmitclaimInfo setObject:strAccValue forKey:@"Accounttype"];
	
	[DictSavedSubmitclaimInfo setObject:strallowDuplicateClaim forKey:@"duplicateclaim"];
	
	[DictSavedSubmitclaimInfo setObject:((UnsubmittedclaimOBJ *)[arrunsubmittedClaimwork objectAtIndex:Selectedrow]).strclaimid forKey:@"claimid"];
	
	
	
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
	
	if(textField==txttype)
	{
		
		[self Vanishpicker];
		[self createbarbuttondone];
		[self CreatePickerView];
		return NO;
	}
	
	else if(textField==txtserviceFrom)
	{
		[textField resignFirstResponder];
		strTxtNm=@"txtserviceFrom";
		[self Vanishpicker];
		txtserviceTo.text=@"";
		[self createbarbuttondone];
		[self datePickerCreate];
		return NO;
		
		
	}
	else if(textField==txtserviceTo)
	{
		
		if(txtserviceFrom.text.length==0)
		{
			
			
			UIAlertView *alertview=[[UIAlertView alloc]initWithTitle:@"Info" message:@"Enter valid 'Service From' date" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
			alertview.delegate=self;
			alertview.tag=333;
			[alertview show];
			[alertview release],alertview=nil;
			return NO;
			
			
		}
		else 
		{
			
			[textField resignFirstResponder];
			
			strTxtNm=@"txtserviceTo";
			[self Vanishpicker];
			[self createbarbuttondone];
			[self datePickerCreate];
			
			NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
			[dateFormat setDateFormat:@"MM/dd/yyyy"];
			NSDate	*dt=[dateFormat dateFromString:txtserviceFrom.text]; 
			datePicker.minimumDate=dt;
			
			return NO;
			
		}
		
		
		
	}
	
	return YES;
}

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField
{
	
	
	
	return YES;
	
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
	
	[textField resignFirstResponder];
	return YES;
	
	
}		
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string 
{
	
	
	if(textField==txtAmount)
		
	{
		NSString *newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
		NSString *sepStr;
		NSArray *sep = [newString componentsSeparatedByString:@"."];
		if([sep count]>=2)
		{
			sepStr=[NSString stringWithFormat:@"%@",[sep objectAtIndex:1]];
			[sepStr retain];
			
			if([sepStr length]>2)
				return NO;
			
			
			
			
		}
		if([string isEqualToString:@"E"])
		{
			
			
			return NO;
		}
		
		else if ([string isEqualToString:@"e"]) 
		{
			return NO;
		}
		
		else if([string isEqualToString:@" "])
		{
			
			return NO;
		}
		
		else 
		
		{
			
	
		NSString *resultingString = [textField.text stringByReplacingCharactersInRange:range withString: string];
		
		if ([resultingString length] == 0) 
			
		{
			
		    return true;
			
		}
		
		NSDecimal holder;
		
		NSScanner *scan = [NSScanner scannerWithString: resultingString];
		
		return [scan scanDecimal:&holder] && [scan isAtEnd];
		
		
	
	    }
	}
	
	return YES;
	
		
}

-(void)Vanishpicker
{
	if(myPickerView)
	{
		[myPickerView removeFromSuperview];
	    [myPickerView release],myPickerView=nil;
	}
	else if(datePicker)
	{
		[datePicker removeFromSuperview];
		[datePicker release], datePicker = nil;
		
	}
	
}
- (BOOL)textViewShouldBeginEditing:(UITextView *)textView
{
	
	if(textView==txtViewNote)
	{
		
		[UIView beginAnimations:nil context:nil];
		[UIView setAnimationDuration:0.3];
		self.view.frame=CGRectMake(0, -55, 320, 410);
		[UIView commitAnimations];
		
		
	}
	
	return YES;
}

- (BOOL)textViewShouldEndEditing:(UITextView *)textView
{
	
	if(textView==txtViewNote)
	{
		
		[UIView beginAnimations:nil context:nil];
		[UIView setAnimationDuration:0.3];
		self.view.frame=CGRectMake(0, 0, 320, 410);
		[UIView commitAnimations];
		
	}
	
	return YES;
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
	if([text isEqualToString:@"\n"])
	{
		
		[textView resignFirstResponder];
	}
	
	/*BOOL flag = NO;
	 NSLog(@"the text is %@",text);
	 NSLog(@"the length is %i",[text length]);
	 
	 
	 if([text length] == 0)
	 {
	 if([textView.text length] != 0)
	 {
	 flag = YES;
	 
	 ////NSString *Temp = charbutton.title;
	 //int j = [Temp intValue];
	 //j = j +1 ;
	 //charbutton.title = [[NSString alloc] initWithFormat:@"%i",j];
	 
	 return YES;
	 } 
	 else 
	 {
	 return NO;
	 }
	 
	 
	 } 
	 else if([[textView text] length] > 65)
	 {
	 UIAlertView *alertview=[[UIAlertView alloc]initWithTitle:@"Info" message:@"you can enter maximam 65 charecters" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
	 alertview.delegate=self;
	 [alertview show];
	 [alertview release],alertview=nil;
	 
	 return NO;
	 }
	 if(flag == NO)
	 {
	 
	 //charbutton.title = [[NSString alloc] initWithFormat:@"%i",139-[textView.text length]];
	 
	 
	 }*/
	return YES;
	
}

- (void)textViewDidChange:(UITextView *)textView
{	
	if(textView.text.length>=65)
	{
		
		
		textView.text = [textView.text substringToIndex:65];
		
		UIAlertView *alertview=[[UIAlertView alloc]initWithTitle:@"" message:@"You can enter maximam 65 charecters" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		alertview.delegate=self;
		[alertview show];
		alertview.tag=555;
		[alertview release],alertview=nil;
		return;
		
		
	}
	
}
-(void)createbarbuttondone
{
	UIBarButtonItem *doneButton = [[UIBarButtonItem alloc]
								   initWithTitle:@"Done"
								   style:UIBarButtonItemStyleBordered
								   target:self
								   action:@selector(donecancel)];
	
	
	
    self.navigationItem.rightBarButtonItem =doneButton;
	
}

-(void)donecancel
{
	[self  createbar_button];
	
	[self Vanishpicker];
	
	
}
+(BOOL)getback
{

	return back;
}

-(void)ClaimSave
{
	
	
	RequestPhase2 *objrequestPhase2=[[RequestPhase2 alloc] initWithTarget:self
															SuccessAction:@selector(onSuccesful)
															FailureAction:@selector(onFailure)];
	
	[objrequestPhase2 EditUnSubmittedClaim:[userinfo_arr objectAtIndex:2] uID:[userinfo_arr objectAtIndex:4] claimCaty:((UnsubmittedclaimOBJ *)[arrunsubmittedClaimwork objectAtIndex:Selectedrow]).strClaimCategory claimtpe:txttype.text  amt:txtAmount.text SerBedt:txtserviceFrom.text
								   SerEedt:txtserviceTo.text   Note:txtViewNote.text isPrYr:icheckbox  payMode:strPaystatus providerName:txtProvider.text  Claimid:((UnsubmittedclaimOBJ *)[arrunsubmittedClaimwork objectAtIndex:Selectedrow]).strclaimid allowDuplicateClaim:strallowDuplicateClaim opcode:@"5001"];
	
	[objrequestPhase2 release];
	
	
	[tools startLoading:self.view childView:loadingView text:@"Loading your Claim activity. Wait…."];
	
	
	
	
	
}
///call for multiple account with opcode 5002///
-(void)ClaimSave2
{
	
	RequestPhase2 *objrequestPhase2=[[RequestPhase2 alloc] initWithTarget:self
															SuccessAction:@selector(onSuccesfull2)
															FailureAction:@selector(onFailure2)];
	
	[objrequestPhase2 EditUnSubmittedClaim2:[userinfo_arr objectAtIndex:2] uID:[userinfo_arr objectAtIndex:4] claimCaty:((UnsubmittedclaimOBJ *)[arrunsubmittedClaimwork objectAtIndex:Selectedrow]).strClaimCategory claimtpe:txttype.text  amt:txtAmount.text SerBedt:txtserviceFrom.text
									SerEedt:txtserviceTo.text   Note:txtViewNote.text isPrYr:icheckbox  payMode:strPaystatus providerName:txtProvider.text  Claimid:((UnsubmittedclaimOBJ *)[arrunsubmittedClaimwork objectAtIndex:Selectedrow]).strclaimid accountvalue:strAccValue allowDuplicateClaim:strallowDuplicateClaim opcode:stropcodevalue];
	
	[objrequestPhase2 release];
	
	
	
	[tools startLoading:self.view childView:loadingView text:@"Loading your Claim activity. Wait…."];
	
	
	
	
}

/*
 // Override to allow orientations other than the default portrait orientation.
 - (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
 // Return YES for supported orientations.
 return (interfaceOrientation == UIInterfaceOrientationPortrait);
 }
 */

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
	txttype=nil;
	txtAmount=nil;
	txtProvider=nil;
	txtserviceFrom=nil;
	txtserviceTo=nil;
	txtPriorYear=nil;
	txtViewNote=nil;
	datePicker=nil;
	myPickerView=nil;
	table=nil;
	DictSavedSubmitclaimInfo=nil;
}


- (void)dealloc {
	[txttype release];
	[txtAmount release];
	[txtProvider release];
	[txtserviceFrom release];
	[txtserviceTo release];
	[txtPriorYear release];
	[txtViewNote release];
	[datePicker release];
	[myPickerView release];
	[table release];
	[DictSavedSubmitclaimInfo release];
	
    [super dealloc];
}



/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/




@end
