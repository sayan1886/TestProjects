    //
//  tickitUpdate.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 03/11/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import "ticketUpdate.h"
#import <QuartzCore/CALayer.h>
#import "ticket.h"
#import "ticketPerser.h"
#import "request.h"
#import "ticketupdatePerser.h"
#import "passPerser.h"
#import "UserresponcePerser.h"
#import "Decode64.h"
#import "AcclarisViewController.h"
#import "configurables.h"
@implementation ticketUpdate

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	
	NSMutableArray *arr_myconfig=[AcclarisViewController staticarr_config];//[configurableParser getconfig_arr];//
	
	con=(configurables *)[arr_myconfig objectAtIndex:0];
	tools=[[MyTools alloc]init];
	self.view.backgroundColor = [UIColor colorWithRed:con.bgRed/255.0f green:con.bgGreen/255.0f blue:con.bgBlue/255.0f alpha:1.0];
	loadingView=[tools createActivityIndicator1];

	//NSMutableArray *my_arrUserinfo=[UserresponcePerser userdesc];
	UIImageView *logo_img = [[UIImageView alloc]initWithFrame:CGRectMake(0, 2, 170, 40)];
	NSData *data=[Base64 decode:con.logoImgdata];
	logo_img.image=	[UIImage imageWithData:[NSData dataWithData:data]];
	self.navigationItem.titleView=logo_img;
	
	
	selectedRow=[ticket getSelectedRow];
	arr_celltytle=[ticketPerser ticketArr];
	
	UIView	*view_messageID = [[UIView alloc]initWithFrame:CGRectMake(10, 10, 300, 30)];
	view_messageID.backgroundColor = [UIColor purpleColor];
	view_messageID.layer.cornerRadius=4;
	view_messageID.layer.borderWidth=1.5;
	CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();	
	float grayComponents[4] = { 0.3, 0.3, 0.3, 1.0 };
	view_messageID.layer.borderColor=CGColorCreate(colorSpace, grayComponents);
	[self.view addSubview:view_messageID];
	
	
	UILabel	*lbl_messageID_text = [[UILabel alloc]initWithFrame:CGRectMake(5, 5, 180, 20)];
	lbl_messageID_text.backgroundColor = [UIColor clearColor];
	lbl_messageID_text.text = @"Updating Message ID";
	NSString *strFont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];
	lbl_messageID_text.font = [UIFont fontWithName:strFont size:con.bodyImpfntsize];
	
	lbl_messageID_text.textColor=[UIColor whiteColor];
	[view_messageID addSubview:lbl_messageID_text];
	
	UILabel	*lbl_messageID = [[UILabel alloc]initWithFrame:CGRectMake(185, 5, 90, 20)];
	lbl_messageID.backgroundColor = [UIColor clearColor];
	lbl_messageID.textAlignment=UITextAlignmentRight;
	lbl_messageID.textColor=[UIColor whiteColor];
	lbl_messageID.text = ((ticketOBJ *)[ arr_celltytle objectAtIndex:selectedRow]).ticketID;
	[view_messageID addSubview:lbl_messageID];
	
	
	
	UIView	*view_message_textview = [[UIView alloc]initWithFrame:CGRectMake(10, 50, 300, 250)];
	view_message_textview.backgroundColor = [UIColor whiteColor];
	view_message_textview.layer.cornerRadius=4;
	view_message_textview.layer.borderWidth=1.5;
	view_message_textview.layer.borderColor=CGColorCreate(colorSpace, grayComponents);
	[self.view addSubview:view_message_textview];
	
	
	txtv_msgCloseNotes=[[UITextView alloc] initWithFrame:CGRectMake(5, 5, 290, 240)];
    txtv_msgCloseNotes.textColor = [UIColor blackColor];
	txtv_msgCloseNotes.font = [UIFont fontWithName:con.fontname size:con.fontsize];
	txtv_msgCloseNotes.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];

	txtv_msgCloseNotes.returnKeyType = UIReturnKeyDefault;
	txtv_msgCloseNotes.autocorrectionType=NO;
	txtv_msgCloseNotes.keyboardType = UIKeyboardTypeDefault;
	txtv_msgCloseNotes.backgroundColor=[UIColor whiteColor];
	txtv_msgCloseNotes.keyboardAppearance=UIKeyboardAppearanceAlert;
	txtv_msgCloseNotes.delegate=self;
	[view_message_textview addSubview:txtv_msgCloseNotes];
	
	
	
	btn_submitcloseMSG=[UIButton buttonWithType:UIButtonTypeCustom];
	btn_submitcloseMSG.frame = CGRectMake(43, 308, 234, 47);
	NSData *data_btnimg=[Base64 decode:con.btnImgdata];
	[btn_submitcloseMSG setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
	btn_submitcloseMSG.titleLabel.font = [UIFont fontWithName:con.btnfontname size:con.btnfontsize];
	[btn_submitcloseMSG setTitle:@"Update" forState:UIControlStateNormal];
	[btn_submitcloseMSG setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn_submitcloseMSG addTarget:self action:@selector(closeMSG) forControlEvents:UIControlEventTouchUpInside];
	[self.view addSubview:btn_submitcloseMSG];
	
	[self signoutbt];
	[self donebt];
}

-(void)signoutbt
{
	signoutButton = [[UIBarButtonItem alloc]
					 initWithTitle:@"Sign Off"
					 style:UIBarButtonItemStyleBordered
					 target:self
					 action:@selector(signout)];
    self.navigationItem.rightBarButtonItem =signoutButton;
}
-(void)donebt
{
	doneButton = [[UIBarButtonItem alloc]
				  initWithTitle:@"Done"
				  style:UIBarButtonItemStyleBordered
				  target:self
				  action:@selector(done)];
}
#pragma mark textview delegate
- (BOOL)textViewShouldBeginEditing:(UITextView *)textView;
{
	self.navigationItem.rightBarButtonItem =doneButton;
	return YES;
}
#pragma mark -
-(void)signout
{
	[((AcclarisAppDelegate *)[[UIApplication sharedApplication] delegate]) removeTabBar];
}

-(void)done
{
	[txtv_msgCloseNotes resignFirstResponder];
	self.navigationItem.rightBarButtonItem =signoutButton;
}

-(void)closeMSG
{
	NSString *strTextMessage=[txtv_msgCloseNotes.text stringByTrimmingCharactersInSet: [NSCharacterSet whitespaceAndNewlineCharacterSet]];
	if(strTextMessage.length>0)
	{
	[tools startLoading:self.view childView:loadingView text:@"Updating message. Wait…."];
	self.navigationItem.hidesBackButton = YES;
	request *r=[[request alloc] initWithTarget:self
								 SuccessAction:@selector(onSucceffulLogin)
								 FailureAction:@selector(onFailureLogin)];
	[r sendupdateMSGRequest:((ticketOBJ *)[ arr_celltytle objectAtIndex:selectedRow]).ticketType description:txtv_msgCloseNotes.text tickitcatagory:((ticketOBJ *)[ arr_celltytle objectAtIndex:selectedRow]).ticketCategory tid:((ticketOBJ *)[ arr_celltytle objectAtIndex:selectedRow]).ticketID];
	[r release];
	btn_submitcloseMSG.enabled=NO;
	}
	else {
		
		NSDictionary *customMessageList_dict=[[NSUserDefaults standardUserDefaults] objectForKey:@"customMessageList"];
		
		
		NSString *strmessage=[[customMessageList_dict valueForKey:@"200075"]valueForKey:@"message"];
		NSString *strtype=[[customMessageList_dict valueForKey:@"200075"]valueForKey:@"type"];
		
		UIAlertView *alrtNoMessage=[[UIAlertView alloc] initWithTitle:strtype message:strmessage delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		[alrtNoMessage show];
		alrtNoMessage.tag=101;
		[alrtNoMessage release];
		return ;
	}

}
-(void)onSucceffulLogin
{
	
	[tools stopLoading:loadingView];
	NSMutableArray *arr= [ticketupdatePerser updateresponse];
	if ([[arr objectAtIndex:0] isEqualToString:@"0"])
	{
		/*UIAlertView *alert= [[UIAlertView alloc] initWithTitle:@"Info" message:@"Successfully updated"
														delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		[alert show];    
		alert.tag=200;
		[alert release];*/
		[self reqTicket];
	}
}

- (void)alertView:(UIAlertView *)alertView willDismissWithButtonIndex:(NSInteger)buttonIndex
{
	if(alertView.tag=200)
	{
	self.navigationItem.hidesBackButton = NO;
	btn_submitcloseMSG.enabled=YES;
	}
}



-(void)onFailureLogin
{
	[tools stopLoading:loadingView];
	self.navigationItem.hidesBackButton = NO;
	
}
-(void)reqTicket
{
	NSMutableArray *userinfo_arr=[passPerser passresponce];//static method fired
	[tools startLoading:self.view childView:loadingView text:@"Updating your Message List. Wait…."];
	request *r=[[request alloc] initWithTarget:self
								 SuccessAction:@selector(onSucceffulreq)
								 FailureAction:@selector(onFailurereq)];
	[r sendticketRequest:@"0" participentid:[userinfo_arr objectAtIndex:2] userid:[userinfo_arr objectAtIndex:4]];
	[r release];
	//[tools startLoading:self.view childView:loadingView text:@"Updating your Messages. Wait…."];
	
}
-(void)onSucceffulreq
{
	[tools stopLoading:loadingView];
	[self.navigationController popViewControllerAnimated:YES];
}
-(void)onFailurereq
{
	[tools stopLoading:loadingView];
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
