//
//  ActiveSchedule.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 08/04/11.
//  Copyright 2011 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
@class configurables;
@class MyTools;
@class ScheduleOBJ;
@interface ActiveSchedule : UIViewController<UITableViewDelegate, UITableViewDataSource> {

	NSMutableArray *transaction_info,*arr_scheduleInfo;
	MyTools *tools;
	UIView *loadingView;
	UITableView *acctable;
	configurables *con;
	ScheduleOBJ *myScheduleOBJ;
}
-(void)requestActiveSchedule;
-(NSString *)chkvalue:(NSString *)value;
-(void)createHeader;
-(void)createtableview;
+(NSInteger)getscheduleselectedRow;
-(void)signoutbt;
@end
