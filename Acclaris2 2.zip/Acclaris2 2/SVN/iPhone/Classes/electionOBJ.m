//
//  electionOBJ.m
//  Acclaris
//
//  Created by Sayan banerjee on 19/11/10.
//  Copyright 2010 Objectsol. All rights reserved.
//

#import "electionOBJ.h"


@implementation electionOBJ;
@synthesize electionID;
@synthesize planYearType;
@synthesize planPeriod;
@synthesize endDate;
@synthesize graceEndDate;
@synthesize runOutEndDate;
@synthesize futureGraceEndDate;
@synthesize currentBalance;
@synthesize investmentBalance;
@synthesize beginDate;
@synthesize dpstType;
@synthesize enrollmentStatus;
@end
