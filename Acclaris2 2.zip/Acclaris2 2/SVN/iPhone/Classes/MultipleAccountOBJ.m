//
//  MultipleAccountOBJ.m
//  Acclaris
//
//  Created by Subhojit on 15/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MultipleAccountOBJ.h"


@implementation MultipleAccountOBJ

@synthesize straccountTypeCD,straccountTypeDesc,strelctID,straccountNO,strpurseType,strlabelAssociatedValue;
@end
