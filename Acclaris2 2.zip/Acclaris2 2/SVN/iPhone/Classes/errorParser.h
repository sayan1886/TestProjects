//
//  errorParser.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 28/04/11.
//  Copyright 2011 ObjectSol Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>

@class errorcodeOBJ;
@interface errorParser : NSObject<NSXMLParserDelegate> {

	NSMutableString *contentOfString;
	errorcodeOBJ *myerrorcodeOBJ;
	
}
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error;
+(NSMutableArray *)getmyerror_arr;
@end
