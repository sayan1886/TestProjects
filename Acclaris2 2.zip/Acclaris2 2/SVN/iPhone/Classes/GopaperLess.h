//
//  GopaperLess.h
//  Acclaris
//
//  Created by Subhojit on 22/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyTools.h"
#import "Decode64.h"
#import "RequestPhase2_2.h"
#import "passPerser.h"
#import "GoPaperlessOBJ.h"
#import "GopaperlessParser.h"
#import "eCommunicationDisclosure.h"
#import "StatementforGoPaparlessOBJ.h"
#import "SelectOptionGoPaperlessOBJ.h"
#import "PaynowcontinueParser.h"

@class configurables;


@interface GopaperLess : UIViewController<UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate,UIPickerViewDelegate> {

	
	UITableView *table;
	UITextField *txtEmail;
	UITextField *txtRenterEmail;
	UITextField *txtInvesmentStatement;
	UITextField *txtAccountStatement;
	UITextField *txtOther;
	NSMutableArray  *arrAllSection;
	NSMutableArray *pickerViewArrayH;
		NSMutableArray *pickerViewArrayA;
		NSMutableArray *pickerViewArrayO;
	UIPickerView *myPickerView;
	NSString *strTxtNm;	
	configurables *con;
	MyTools *tools;
	UIView *loadingView;
	NSMutableArray *arrGopaperless;
	NSMutableArray *arrStatementInfo;
	StatementforGoPaparlessOBJ *myStatementforGoPaparless;
	int Indexnumber;
	int O,H,A;
	NSMutableDictionary *dict;
	
	NSString *strOther;
	NSString *strHSA;
	NSString *strAccount;
	
	NSMutableArray *arrSelectedlabelO;
	NSMutableArray *arrSelectedlabelH;
	NSMutableArray *arrSelectedlabelA;
	
	NSDictionary *customMessageList_dict;
	
	NSString *strtitlecheckH;
	NSString *strtitlecheckA;
	NSString *strtitlecheckO;
}
-(void)createbarbuttondone;
-(void)donecancel;
-(void)CreateView;
-(void)constructTableCell;
-(void)EmailInput:(UITableViewCell *)cell;
-(void)RenterEmailInput:(UITableViewCell *)cell;
-(void)InvesmentStatementInput:(UITableViewCell *)cell;
-(void)AccountStatementFromInput:(UITableViewCell *)cell;
-(void)OtherToInput:(UITableViewCell *)cell;
-(void)CreateConnectionforsummery;
-(BOOL)validateEmail:(NSString *)email; 
-(void)createbar_button;
-(void)signout;
-(void)Vanishpicker;
-(void)Saveinfo;

@end
