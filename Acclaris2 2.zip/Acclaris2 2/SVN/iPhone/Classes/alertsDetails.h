//
//  alertsDetails.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 13/12/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
@class configurables;


@interface alertsDetails : UIViewController<UITextViewDelegate> {

	configurables *con;
	NSString *genericDescription;
	
	UITextView *txtv_msgNewNotes;
}
-(void)signoutbt;
-(id)initWithString:(NSString *)str;
-(void)createview;
@end
