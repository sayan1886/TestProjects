//
//  Contribution.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 08/04/11.
//  Copyright 2011 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
@class configurables;


@interface Contribution : UIViewController<UITableViewDelegate,UITableViewDataSource>{

	configurables *con;
	NSMutableArray *transaction_info;
	NSArray *arr_celltytle;
}
-(void)signoutbt;
-(void)signout;
-(void)createtableview;
@end
