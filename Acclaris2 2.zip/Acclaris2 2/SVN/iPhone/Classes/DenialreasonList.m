    //
//  DenialreasonList.m
//  Acclaris
//
//  Created by Subhojit on 13/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "DenialreasonList.h"
#import "configurables.h"
#import "AcclarisViewController.h"

@implementation DenialreasonList

-(id)initWithtext:(NSString *)str
{

	
	self=[super init];
	if(self==nil)
	{
		
		return nil;
	}
	
	else 
	{
		strReasontext=str;
		
	}
	return self;
	
}
- (void)viewDidLoad {
    [super viewDidLoad];
	
	
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	tools=[[MyTools alloc]init];
	//loadingView=[tools createActivityIndicator1];
	
	NSMutableArray *arr_myconfig=[AcclarisViewController staticarr_config];
	con=(configurables *)[arr_myconfig objectAtIndex:0];
	
	self.navigationController.navigationBar.tintColor=[UIColor colorWithRed:con.navbarRed/255.0f green:con.navbarGreen/255.0f blue:con.navbarBlue/255.0f alpha:1.0];
	
	self.view.backgroundColor = [UIColor colorWithRed:con.bgRed/255.0f green:con.bgGreen/255.0f blue:con.bgBlue/255.0f alpha:1.0];
	UIImageView *logo_img = [[UIImageView alloc]initWithFrame:CGRectMake(0, 2, 170, 40)];
	NSData *data=[Base64 decode:con.logoImgdata];
	logo_img.image=	[UIImage imageWithData:[NSData dataWithData:data]];
	self.navigationItem.titleView=logo_img;
	
	
	
	
	UIBarButtonItem *signoutButton = [[UIBarButtonItem alloc]
									  initWithTitle:@"Sign Off"
									  style:UIBarButtonItemStyleBordered
									  target:self
									  action:@selector(signout)];
    self.navigationItem.rightBarButtonItem =signoutButton;
	
	[self Createview];
}
-(void)Createview
{
	
	
   NSString	*strFont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];
	
	NSData *data_btnimg=[Base64 decode:con.btnImgdata];
	
	UIView *HeaderView=[[[UIView alloc]initWithFrame:CGRectMake(0, 0, 320, 60)]autorelease];
	HeaderView.backgroundColor=[UIColor colorWithRed:con.bgRed2/255.0 green:con.bgGreen2/255.0 blue:con.bgBlue2/255.0 alpha:1.0];
	[self.view addSubview:HeaderView];
	
	NSString *strViewTitle=@"Denial Reason(s)";
	
	UILabel *lbltext=[[UILabel alloc]initWithFrame:CGRectMake(10, 5, 240, 60)];
	lbltext.text=strViewTitle;
	lbltext.backgroundColor=[UIColor clearColor];
	lbltext.textColor=[UIColor whiteColor];
	//lbltext.numberOfLines=0;
	lbltext.font=[UIFont fontWithName:strFont size:con.headerImpfntsize];
	[HeaderView addSubview:lbltext];
	[lbltext release],lbltext=nil;
	
	
	UILabel *lblreasontext=[[[UILabel alloc]init]autorelease];
	lblreasontext.frame=CGRectMake(10, 70, 300, 200);
	lblreasontext.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
	lblreasontext.text=strReasontext;
	lblreasontext.backgroundColor=[UIColor clearColor];
	lblreasontext.numberOfLines=0;
	lblreasontext.font=[UIFont fontWithName:con.fontname size:con.bodyfntsize];
	[self.view addSubview:lblreasontext];
	
	UIButton *btnBackclaim=[UIButton buttonWithType:UIButtonTypeCustom];
	btnBackclaim.frame=CGRectMake(90, 315, 140, 40);
	[btnBackclaim setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
	[btnBackclaim setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	btnBackclaim.titleLabel.font = [UIFont fontWithName:con.btnfontname size:con.btnfontsize];
	[btnBackclaim setTitle:@"Back to claims " forState:UIControlStateNormal];
	[btnBackclaim addTarget:self action:@selector(ClickbtnBackclaim) forControlEvents:UIControlEventTouchUpInside];					 
	[self.view addSubview:btnBackclaim];
	
	
}
-(void)ClickbtnBackclaim
{

	
	[self.navigationController popToRootViewControllerAnimated:YES];
	
}
-(void)signout
{
	[((AcclarisAppDelegate *)[[UIApplication sharedApplication] delegate]) removeTabBar];
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
