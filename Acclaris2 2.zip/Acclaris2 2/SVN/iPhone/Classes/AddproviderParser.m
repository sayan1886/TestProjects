//
//  AddproviderParser.m
//  Acclaris
//
//  Created by Subhojit on 19/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "AddproviderParser.h"
NSString *straddprovidererrortext;


@implementation AddproviderParser
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error
{
	
	
	NSXMLParser *parser;
	parser = [[NSXMLParser alloc] initWithData:data];
    [parser setDelegate:self];
	[parser setShouldProcessNamespaces:NO];
    [parser setShouldReportNamespacePrefixes:NO];
    [parser setShouldResolveExternalEntities:NO];
    [parser parse];
    NSError *parseError = [parser parserError];
    if (parseError && error) 
	{
        *error = parseError;
    }
	[parser release];
}

-(void)parserDidStartDocument:(NSXMLParser *)parser
{
	
	 
}		

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
	if (qName)
	{
		elementName = qName;
	}
	else 
		if([elementName isEqualToString:@"returnCode"])
		{
			
			
			contentOfString=[NSMutableString string];
			[contentOfString retain];
			return;		
			
		}
		else 
			if([elementName isEqualToString:@"errorText"])
			{
				
				contentOfString=[NSMutableString string];
				[contentOfString retain];
				return;		
				
			}
}
- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName     
{	
	if (qName)
	{
        elementName = qName;
		
    }
	else 
		if([elementName isEqualToString:@"returnCode"])
		{
			if(contentOfString)
			{
				
				[contentOfString release];
				contentOfString = nil;
				
				
			}	
			
		}
		else 
			if([elementName isEqualToString:@"errorText"])
			{
				if(contentOfString)
				{
					
					
					straddprovidererrortext=contentOfString;
					[contentOfString release];
					contentOfString = nil;
					
					
				}		
				
			}
}	
- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
	if(contentOfString)
		[contentOfString appendString:string];
}

- (void)parserDidEndDocument:(NSXMLParser *)parse
{
	
	
}
+(NSString *)getstraddprovidererrortext
{
	
	return straddprovidererrortext;
}
@end
