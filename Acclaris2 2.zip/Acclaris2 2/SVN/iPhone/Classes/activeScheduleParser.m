//
//  activeScheduleParser.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 08/04/11.
//  Copyright 2011 ObjectSol Technologies. All rights reserved.
//

#import "activeScheduleParser.h"
#import "ActiveScheduleOBJ.h"
#import "ScheduleOBJ.h"
NSMutableArray *arrSchudule;
NSMutableArray *errorCodeSchedule;

@implementation activeScheduleParser
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error
{
	
	NSXMLParser *parser;
	parser = [[NSXMLParser alloc] initWithData:data];
    [parser setDelegate:self];
	[parser setShouldProcessNamespaces:NO];
    [parser setShouldReportNamespacePrefixes:NO];
    [parser setShouldResolveExternalEntities:NO];
    [parser parse];
    NSError *parseError = [parser parserError];
    if (parseError && error) 
	{
        *error = parseError;
    }
	[parser release];
}

-(void)parserDidStartDocument:(NSXMLParser *)parser
{
	
	arrSchudule=[[NSMutableArray alloc]init];
	errorCodeSchedule=[[NSMutableArray alloc]init];
}		

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
	if (qName)
	{
		elementName = qName;
	}
	else 
		if([elementName isEqualToString:@"GetActiveSchedulesDetails"]||[elementName isEqualToString:@"GetInActiveSchedulesDetails"])
		{
			myScheduleOBJ=[[ScheduleOBJ alloc]init];
			myScheduleOBJ.scheduleArr=[[NSMutableArray alloc]init];
			return;		
			
		}
		else 
			if([elementName isEqualToString:@"hasMoreRecords"])
			{
				contentOfString=[NSMutableString string];
				[contentOfString retain];
				return;			
				
			}
			
	else 
		if([elementName isEqualToString:@"returnCode"])
		{
			contentOfString=[NSMutableString string];
			[contentOfString retain];
			return;		
			
		}
		else 
			if([elementName isEqualToString:@"errorText"])
			{
				contentOfString=[NSMutableString string];
				[contentOfString retain];
				return;		
				
			}
			else 
				if([elementName isEqualToString:@"schedule"])
				{
					myActiveScheduleOBJ=[[ActiveScheduleOBJ alloc]init];
					
					return;		
					
				}
				else 
					if([elementName isEqualToString:@"ID"])
					{
						contentOfString=[NSMutableString string];
						[contentOfString retain];
						return;		
						
					}
					else 
						if([elementName isEqualToString:@"transferSchedule"])
						{
							contentOfString=[NSMutableString string];
							[contentOfString retain];
							return;		
							
						}
						else 
							if([elementName isEqualToString:@"transferAmount"])
							{
								contentOfString=[NSMutableString string];
								[contentOfString retain];
								return;		
								
							}else 
								if([elementName isEqualToString:@"initTransferDate"])
								{
									contentOfString=[NSMutableString string];
									[contentOfString retain];
									return;		
									
								}else 
									if([elementName isEqualToString:@"lastTransferDate"])
									{
										contentOfString=[NSMutableString string];
										[contentOfString retain];
										return;		
										
									}else 
										if([elementName isEqualToString:@"endDate"])
										{
											contentOfString=[NSMutableString string];
											[contentOfString retain];
											return;		
											
										}else 
											if([elementName isEqualToString:@"inactiveDate"])
											{
												contentOfString=[NSMutableString string];
												[contentOfString retain];
												return;		
												
											}else 
												if([elementName isEqualToString:@"actHolderName"])
												{
													contentOfString=[NSMutableString string];
													[contentOfString retain];
													return;		
													
												}else 
													if([elementName isEqualToString:@"actType"])
													{
														contentOfString=[NSMutableString string];
														[contentOfString retain];
														return;		
														
													}else 
														if([elementName isEqualToString:@"actNumber"])
														{
															contentOfString=[NSMutableString string];
															[contentOfString retain];
															return;		
															
														}else 
															if([elementName isEqualToString:@"bankRoutingNumber"])
															{
																contentOfString=[NSMutableString string];
																[contentOfString retain];
																return;		
																
															}else 
																if([elementName isEqualToString:@"priorPlan"])
																{
																	contentOfString=[NSMutableString string];
																	[contentOfString retain];
																	return;		
																	
																}else 
																	if([elementName isEqualToString:@"electionId"])
																	{
																		contentOfString=[NSMutableString string];
																		[contentOfString retain];
																		return;		
																		
																	}else 
																		if([elementName isEqualToString:@"lastStatus"])
																		{
																			contentOfString=[NSMutableString string];
																			[contentOfString retain];
																			return;		
																			
																		}
	
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName     
{	
	if (qName)
	{
        elementName = qName;
		
    }
	
	else 
		if([elementName isEqualToString:@"returnCode"])
		{
			if(contentOfString)
			{
				[errorCodeSchedule addObject:contentOfString];
				[contentOfString release];
				contentOfString = nil;
				
				
			}	
			
		}
		else 
			if([elementName isEqualToString:@"errorText"])
			{
				
				if(contentOfString)
				{
					[errorCodeSchedule addObject:contentOfString];
					[contentOfString release];
					contentOfString = nil;
					
					
				}	
			}
			else 
				if([elementName isEqualToString:@"GetActiveSchedulesDetails"]||[elementName isEqualToString:@"GetInActiveSchedulesDetails"])
				{
					[arrSchudule addObject: myScheduleOBJ];
					
				}
				else 
					if([elementName isEqualToString:@"hasMoreRecords"])
					{
						if(contentOfString)
						{
							myScheduleOBJ.hasMoreRecords=contentOfString;						
						}		
						
					}
	
	
			else 
				if([elementName isEqualToString:@"schedule"])
				{
					[myScheduleOBJ.scheduleArr addObject: myActiveScheduleOBJ];
					
				}
				else 
					if([elementName isEqualToString:@"ID"])
					{
						if(contentOfString)
						{
							NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
							if([tempArr count]==2)
							{
								myActiveScheduleOBJ.lbl_srtID=[tempArr objectAtIndex:0];
								myActiveScheduleOBJ.srtID=[tempArr objectAtIndex:1];
							}
							else {
								myActiveScheduleOBJ.srtID=contentOfString;
							}
						}		
						
					}
					else 
						if([elementName isEqualToString:@"transferSchedule"])
						{
							if(contentOfString)
							{
								NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
								if([tempArr count]==2)
								{
									myActiveScheduleOBJ.lbl_transferSchedule=[tempArr objectAtIndex:0];
									myActiveScheduleOBJ.transferSchedule=[tempArr objectAtIndex:1];
								}
								else {
								myActiveScheduleOBJ.transferSchedule=contentOfString;
								}
							}		
							
						}
						else 
							if([elementName isEqualToString:@"transferAmount"])
							{
								if(contentOfString)
								{
									NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
									if([tempArr count]==2)
									{
										myActiveScheduleOBJ.lbl_transferAmount=[tempArr objectAtIndex:0];
										myActiveScheduleOBJ.transferAmount=[tempArr objectAtIndex:1];
									}
									else {
									myActiveScheduleOBJ.transferAmount=contentOfString;
									}
								}		
								
							}
							else 
								if([elementName isEqualToString:@"initTransferDate"])
								{
									if(contentOfString)
									{
										NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
										if([tempArr count]==2)
										{
											myActiveScheduleOBJ.lbl_initTransferDate=[tempArr objectAtIndex:0];
											myActiveScheduleOBJ.initTransferDate=[tempArr objectAtIndex:1];
										}
										else {
										myActiveScheduleOBJ.initTransferDate=contentOfString;	
										}
									}		
									
								}
	
								else 
									if([elementName isEqualToString:@"lastTransferDate"])
									{
										if(contentOfString)
										{
											NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
											if([tempArr count]==2)
											{
												myActiveScheduleOBJ.lbl_lastTransferDate=[tempArr objectAtIndex:0];
												myActiveScheduleOBJ.lastTransferDate=[tempArr objectAtIndex:1];
											}
											else {
											myActiveScheduleOBJ.lastTransferDate=contentOfString;	
											}
										}		
										
									}
									else 
										if([elementName isEqualToString:@"endDate"])
										{
											if(contentOfString)
											{
												NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
												if([tempArr count]==2)
												{
													myActiveScheduleOBJ.lbl_endDate=[tempArr objectAtIndex:0];
													myActiveScheduleOBJ.endDate=[tempArr objectAtIndex:1];
												}
												else {
												myActiveScheduleOBJ.endDate=contentOfString;	
												}
											}		
											
										}
										else 
											if([elementName isEqualToString:@"inactiveDate"])
											{
												if(contentOfString)
												{
													NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
													if([tempArr count]==2)
													{
														myActiveScheduleOBJ.lbl_inactiveDate=[tempArr objectAtIndex:0];
														myActiveScheduleOBJ.inactiveDate=[tempArr objectAtIndex:1];
													}
													else {
													myActiveScheduleOBJ.inactiveDate=contentOfString;	
													}
												}		
												
											}
											else 
												if([elementName isEqualToString:@"actHolderName"])
												{
													if(contentOfString)
													{
														NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
														if([tempArr count]==2)
														{
															myActiveScheduleOBJ.lbl_actHolderName=[tempArr objectAtIndex:0];
															myActiveScheduleOBJ.actHolderName=[tempArr objectAtIndex:1];
														}
														else {
														myActiveScheduleOBJ.actHolderName=contentOfString;	
														}
													}		
													
												}
												else 
													if([elementName isEqualToString:@"actType"])
													{
														if(contentOfString)
														{
															NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
															if([tempArr count]==2)
															{
																myActiveScheduleOBJ.lbl_actType=[tempArr objectAtIndex:0];
																myActiveScheduleOBJ.actType=[tempArr objectAtIndex:1];

															}
															else {
															myActiveScheduleOBJ.actType=contentOfString;
															}
														}		
														
													}
													else 
														if([elementName isEqualToString:@"actNumber"])
														{
															if(contentOfString)
															{
																NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
																if([tempArr count]==2)
																{
																	myActiveScheduleOBJ.lbl_actNumber=[tempArr objectAtIndex:0];
																	myActiveScheduleOBJ.actNumber=[tempArr objectAtIndex:1];
																}
																else {
																myActiveScheduleOBJ.actNumber=contentOfString;	
																}
															}		
															
														}
														else 
															if([elementName isEqualToString:@"bankRoutingNumber"])
															{
																if(contentOfString)
																{
																	NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
																	if([tempArr count]==2)
																	{
																		myActiveScheduleOBJ.lbl_bankRoutingNumber=[tempArr objectAtIndex:0];
																		myActiveScheduleOBJ.bankRoutingNumber=[tempArr objectAtIndex:1];
																	}
																	else {
																	myActiveScheduleOBJ.bankRoutingNumber=contentOfString;	
																	}
																}		
																
															}else 
																if([elementName isEqualToString:@"priorPlan"])
																{
																	if(contentOfString)
																	{
																		NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
																		if([tempArr count]==2)
																		{
																			myActiveScheduleOBJ.lbl_priorPlan=[tempArr objectAtIndex:0];
																			myActiveScheduleOBJ.priorPlan=[tempArr objectAtIndex:1];
																		}
																		else {
																		myActiveScheduleOBJ.priorPlan=contentOfString;	
																		}
																	}		
																	
																}else 
																	if([elementName isEqualToString:@"electionId"])
																	{
																		if(contentOfString)
																		{
																			NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
																			if([tempArr count]==2)
																			{
																				myActiveScheduleOBJ.lbl_electionId=[tempArr objectAtIndex:0];
																				myActiveScheduleOBJ.electionId=[tempArr objectAtIndex:1];
																			}
																			else {
																			myActiveScheduleOBJ.electionId=contentOfString;	
																			}
																		}		
																		
																	}
																	else 
																		if([elementName isEqualToString:@"lastStatus"])
																		{
																			if(contentOfString)
																			{
																				NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
																				if([tempArr count]==2)
																				{
																					myActiveScheduleOBJ.lbl_lastStatus=[tempArr objectAtIndex:0];
																					myActiveScheduleOBJ.lastStatus=[tempArr objectAtIndex:1];
																				}
																				else {
																				myActiveScheduleOBJ.lastStatus=contentOfString;	
																				}
																			}		
																			
																		}
	
	
	
	
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
	if(contentOfString)
		[contentOfString appendString:string];
}

- (void)parserDidEndDocument:(NSXMLParser *)parse
{
	NSLog(@"Get Error code: %@",errorCodeSchedule);
	/*ScheduleOBJ *my1ScheduleOBJ=(ScheduleOBJ *)[arrSchudule objectAtIndex:0];
	NSLog(@"%@",my1ScheduleOBJ.hasMoreRecords);
	for(int i=0;i<[my1ScheduleOBJ.scheduleArr count];i++)
	{
		ActiveScheduleOBJ *my1ActiveScheduleOBJ=(ActiveScheduleOBJ *)[my1ScheduleOBJ.scheduleArr objectAtIndex:i];
		NSLog(@"%@",my1ActiveScheduleOBJ.srtID);
		NSLog(@"---------------------------\n\n");
	}*/
}
+(NSMutableArray *)getscheduleArr
{
	
	return arrSchudule;
}
+(NSMutableArray *)get_errorCodeSchedule
{
	return errorCodeSchedule;
}	

@end
