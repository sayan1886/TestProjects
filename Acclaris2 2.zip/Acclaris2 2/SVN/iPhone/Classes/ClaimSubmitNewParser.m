//
//  ClaimSubmitNewParser.m
//  Acclaris
//
//  Created by Subhojit on 25/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ClaimSubmitNewParser.h"
NSMutableArray *arrCatagory;
NSMutableArray *arrDetail;
NSMutableArray *arrsubcatagory;
@implementation ClaimSubmitNewParser
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error
{
	
	NSXMLParser *parser;
	parser = [[NSXMLParser alloc] initWithData:data];
    [parser setDelegate:self];
	[parser setShouldProcessNamespaces:NO];
    [parser setShouldReportNamespacePrefixes:NO];
    [parser setShouldResolveExternalEntities:NO];
    [parser parse];
    NSError *parseError = [parser parserError];
    if (parseError && error) 
	{
        *error = parseError;
    }
	[parser release];
}

-(void)parserDidStartDocument:(NSXMLParser *)parser
{
	
	arrCatagory=[[NSMutableArray alloc]init];
	arrDetail=[[NSMutableArray alloc]init];
	arrsubcatagory=[[NSMutableArray alloc]init];
	
}		

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
	if (qName)
	{
		elementName = qName;
	}
	

		else 
			if([elementName isEqualToString:@"returnCode"])
			{
				contentOfString=[NSMutableString string];
				[contentOfString retain];
				return;		
				
			}
			else 
				if([elementName isEqualToString:@"errorText"])
				{
					contentOfString=[NSMutableString string];
					[contentOfString retain];
					return;		
					
				}
				else 
					if([elementName isEqualToString:@"payMode"])
					{
						contentOfString=[NSMutableString string];
						[contentOfString retain];
						return;		
						
					}
				else 
					if([elementName isEqualToString:@"pendingClaimExists"])
					{
							contentOfString=[NSMutableString string];
							[contentOfString retain];
							return;		
							
					}
		else 
			if([elementName isEqualToString:@"category"])
			{
				
				objclaimsubmitnewOBJ=[[ClaimSubmitNewOBJ alloc]init];
				objclaimsubmitnewOBJ.arrclaimsubtype=[[NSMutableArray alloc]init];
				return;
		
				
			}
			else 
				if([elementName isEqualToString:@"type"])
				{
					istype=YES;
					objClaimSubOBJ=[[ClaimSubOBJ alloc]init];
					return;
					
					
				}
			else 
				if([elementName isEqualToString:@"name"])
				{
					contentOfString=[NSMutableString string];
					[contentOfString retain];
					return;		
					
				}
				else 
					if([elementName isEqualToString:@"label"])
					{
						contentOfString=[NSMutableString string];
						[contentOfString retain];
						return;		
						
					}
					else 
						if([elementName isEqualToString:@"dispSeq"])
						{
							contentOfString=[NSMutableString string];
							[contentOfString retain];
							return;		
							
						}
						else 
							if([elementName isEqualToString:@"priorYearActivePlan"])
							{
								contentOfString=[NSMutableString string];
								[contentOfString retain];
								return;		
								
							}
	
	}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName     
{	
	if (qName)
	{
        elementName = qName;
		
    }
	
	else 
		if([elementName isEqualToString:@"returnCode"])
		{
			if(contentOfString)
			{
				[arrDetail addObject:contentOfString];
				[contentOfString release];
				contentOfString = nil;
				
				
			}	
			
		}
		else 
			if([elementName isEqualToString:@"errorText"])
			{
				if(contentOfString)
				{
					[arrDetail addObject:contentOfString];
					[contentOfString release];
					contentOfString = nil;
					
					
				}		
				
			}
		else 
			if([elementName isEqualToString:@"category"])
			{
				if(objclaimsubmitnewOBJ)
				{
					
					[arrCatagory addObject:objclaimsubmitnewOBJ];
					[objclaimsubmitnewOBJ release],objclaimsubmitnewOBJ=nil;
					
				}		
				
			}
			else 
				if([elementName isEqualToString:@"name"])
				{
					if(contentOfString)
					{
						if(istype==NO)
						        objclaimsubmitnewOBJ.strname=contentOfString;
						else 
							
							objClaimSubOBJ.strsubname=contentOfString;
							
						

						[contentOfString release];
						contentOfString = nil;
						
						
					}		
					
				}
				else 
					if([elementName isEqualToString:@"label"])
					{
						if(contentOfString)
						{
							if(istype==NO)
						        objclaimsubmitnewOBJ.strlabel=contentOfString;
							else 
								
								objClaimSubOBJ.strsublabel=contentOfString;
								
							[contentOfString release];
							contentOfString = nil;
							
						}	
						
					}
					else 
						if([elementName isEqualToString:@"dispSeq"])
						{
							if(contentOfString)
							{
								if(istype==NO)
									objclaimsubmitnewOBJ.strDisplayseq=contentOfString;
								else 
									
									objClaimSubOBJ.strsubDisplayseq=contentOfString;
								
								[contentOfString release];
								contentOfString = nil;
								
							}	
							
						}
						else 
							if([elementName isEqualToString:@"priorYearActivePlan"])
							{
								if(contentOfString)
								{
									
									objclaimsubmitnewOBJ.strpriorYearActivePlan=contentOfString;  
									[contentOfString release];
									contentOfString = nil;
									
								}	
								
							}
							else 
								if([elementName isEqualToString:@"payMode"])
								{
									if(contentOfString)
									{
										
										[arrDetail addObject:contentOfString];  
										[contentOfString release];
										contentOfString = nil;
										
									}	
									
								}
								else 
									if([elementName isEqualToString:@"pendingClaimExists"])
									{
										if(contentOfString)
										{
											
											[arrDetail addObject:contentOfString];   
											[contentOfString release];
											contentOfString = nil;
											
										}	
										
									}
	if([elementName isEqualToString:@"type"])
	{
		if(objClaimSubOBJ)
		{
			istype=NO;
			[objclaimsubmitnewOBJ.arrclaimsubtype addObject:objClaimSubOBJ];
			[objClaimSubOBJ release];
			 objClaimSubOBJ = nil;
			
			
		}		
	}
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
	if(contentOfString)
		[contentOfString appendString:string];
}

- (void)parserDidEndDocument:(NSXMLParser *)parse
{
	NSLog(@"**arrDetail %@",arrDetail);
	
	
	/*for(int i=0;i<[arrCatagory count];i++)
	{
		ClaimSubmitNewOBJ*  myrole=(ClaimSubmitNewOBJ*)[arrCatagory objectAtIndex:i];
		NSLog(@">>>>>>%@",myrole.strname);
		
		NSLog(@">strpriorYearActivePlan%@",myrole.strpriorYearActivePlan);
		
		NSLog(@">strpendingClaimExists%@",myrole.strpendingClaimExists);
		
		for(int j=0;j<[myrole.arrclaimsubtype count];j++)
		{
			ClaimSubOBJ*  myrole1=(ClaimSubOBJ*)[myrole.arrclaimsubtype objectAtIndex:j];
			//NSLog(@">>>>>>...........%@",myrole1.strsubname);
			
			//NSLog(@">>>>>>............%@",myrole1.strsublabel);
			
			
			
		}
		
	}*/
}
+(NSMutableArray *)getarrCatagory
{

	
	if(arrCatagory){
		
		return arrCatagory;
	}
	else {
		return nil;
	}

}

+(NSMutableArray *)getarrm_passArray
{
	if (arrDetail) {
		
		return arrDetail;
	}
	else {
		return nil;
	}
	
}
+(NSMutableArray *)getarrsubCatagory
{
	
if(arrsubcatagory)
	{
		
		return arrsubcatagory;
	}
	else {
		return nil;
	}
	
}

@end
