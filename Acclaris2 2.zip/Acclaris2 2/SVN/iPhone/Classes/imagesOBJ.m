//
//  imagesOBJ.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 07/12/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import "imagesOBJ.h"


@implementation imagesOBJ

@synthesize receiptDate;
@synthesize accountShortName;
@synthesize receiptStatus;
@synthesize receiptPurpose;
@synthesize receiptID;

@synthesize LBLreceiptDate;
@synthesize LBLaccountShortName;
@synthesize LBLreceiptStatus;
@synthesize LBLreceiptPurpose;
@synthesize LBLreceiptID;
@synthesize arrshowimageDetail;

@end
