//
//  transactionOBJ.m
//  Acclaris
//
//  Created by Sayan banerjee on 21/11/10.
//  Copyright 2010 Objectsol. All rights reserved.
//

#import "transactionOBJ.h"


@implementation transactionOBJ

@synthesize transactionDate,lbltransactionDate;
@synthesize transactionAmount,lbltransactionAmount;
@synthesize transactionType,lbltransactionType;
@synthesize transactionCode,lbltransactionCode;
@synthesize transactionDescription,lbltransactionDescription;
@synthesize From,lblFrom;
@synthesize serviceDate,lblserviceDate;
@synthesize account,lblaccount;
@synthesize category,lblcategory;
@synthesize status,lblstatus;
@synthesize note,lblnote;
@synthesize effectiveDate,lbleffectiveDate;
@synthesize dpstType,lbldpstType;

@end
