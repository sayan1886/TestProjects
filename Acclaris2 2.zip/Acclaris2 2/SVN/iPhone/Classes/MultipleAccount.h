//
//  MultipleAccount.h
//  Acclaris
//
//  Created by Subhojit on 15/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MultipleAccountView.h"



@interface MultipleAccount : UIViewController {

	
}

@end
