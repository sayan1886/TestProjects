//
//  SubmitclaimOBJ.h
//  Acclaris
//
//  Created by Subhojit on 08/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface SubmitclaimOBJ : NSObject {
	
	NSString *strreturnCode;
	NSString *strerrorText;
	
	NSString *strtrxnID;
	NSString *strclmID;
	NSString *strclmAmount;
	NSString *strclmCategory;
	NSString *strclmType;
	NSString *stractpCD;
	NSString *strprovider;
	NSString *strserviceBegins;
	NSString *strpaymentRef;
	NSString *strinvoiceNo;
	NSString *strcustomerNo;
	NSString *strpayeeID;
	NSString *strservicePeriod;
	NSString *strtext;
	NSString *strdeniedOn;
	NSString *strdeniedBy;
	NSString *strisInvalidACHInfo;
	
	
	
}

@property(nonatomic,retain)NSString *strreturnCode;
@property(nonatomic,retain)NSString *strerrorText;
@property(nonatomic,retain)NSString *strtrxnID;
@property(nonatomic,retain)NSString *strclmID;
@property(nonatomic,retain)NSString *strclmAmount;
@property(nonatomic,retain)NSString *strclmCategory;

@property(nonatomic,retain)NSString *strclmType;
@property(nonatomic,retain)NSString *stractpCD;
@property(nonatomic,retain)NSString *strprovider;
@property(nonatomic,retain)NSString *strserviceBegins;
@property(nonatomic,retain)NSString *strpaymentRef;

@property(nonatomic,retain)NSString *strinvoiceNo;
@property(nonatomic,retain)NSString *strcustomerNo;
@property(nonatomic,retain)NSString *strpayeeID;
@property(nonatomic,retain)NSString *strservicePeriod;
@property(nonatomic,retain)NSString *strtext;
@property(nonatomic,retain)NSString *strdeniedOn;
@property(nonatomic,retain)NSString *strdeniedBy;
@property(nonatomic,retain)NSString *strisInvalidACHInfo;
@end
