//
//  PaynowcontinueParser.h
//  Acclaris
//
//  Created by Subhojit on 26/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface PaynowcontinueParser : NSObject<NSXMLParserDelegate> {

	
	
	NSMutableString *contentOfString;
	
}

-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error;
+(NSString *)getErrortext;
+(NSString *)getreturncode;

@end
