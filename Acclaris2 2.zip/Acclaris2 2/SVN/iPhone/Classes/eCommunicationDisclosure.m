    //
//  eCommunicationDisclosure.m
//  Acclaris
//
//  Created by Subhojit on 11/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "eCommunicationDisclosure.h"
#import "configurables.h"
#import "configurableParser.h"
#import "AcclarisViewController.h"


@implementation eCommunicationDisclosure

-(id)initWithDict:(NSMutableDictionary *)dict

{
	self=[super init];
	if(self==nil)
	{
		
		return nil;
	}
	else 
	{
		dictvalue=[[NSMutableDictionary alloc]init];
		dictvalue=dict;
		NSLog(@"dictvalue>>>  %@ ",[dictvalue description]);
	}
		
	return self;
	
	
}
- (void)viewDidLoad {
    [super viewDidLoad];
	
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	
	NSMutableArray *arr_myconfig=[AcclarisViewController staticarr_config];//[configurableParser getconfig_arr];//
	con=(configurables *)[arr_myconfig objectAtIndex:0];
	tools=[[MyTools alloc]init];
	loadingView=[tools createActivityIndicator1];
	self.view.backgroundColor = [UIColor colorWithRed:con.bgRed/255.0f green:con.bgGreen/255.0f blue:con.bgBlue/255.0f alpha:1.0];
	NSData *data_btnimg=[Base64 decode:con.btnImgdata];

    NSString	*strFont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];
	UILabel *lbl=[[UILabel alloc]init];
	lbl.backgroundColor=[UIColor clearColor];
	lbl.frame=CGRectMake(10, 20, 300, 40);

	lbl.text=@"eCommunications Disclosure";
	lbl.textAlignment=UITextAlignmentCenter;
	lbl.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
	[self.view addSubview:lbl];
	[lbl release],lbl=nil;
	
	
	
	
	
	btn_Remember_Me=[UIButton buttonWithType:UIButtonTypeCustom];
	btn_Remember_Me.frame = CGRectMake(10,295,22,22);
	[btn_Remember_Me setBackgroundImage:[UIImage imageNamed:@"uncheck_box.png"] forState:UIControlStateNormal];
   //[btn_Remember_Me setBackgroundImage:[UIImage imageNamed:@"check-box.png"] forState:UIControlStateNormal];
    [btn_Remember_Me addTarget:self action:@selector(btn_RememberMe_Clicked:) forControlEvents:UIControlEventTouchUpInside];
    [btn_Remember_Me setTag:1];
	[self.view addSubview:btn_Remember_Me];
	
	
	UILabel *lblsave=[[UILabel alloc]initWithFrame:CGRectMake(35,292, 250, 30)];
	lblsave.text=@"I accept the terms and agreement outlined above";
	lblsave.textColor=[UIColor blackColor];
	lblsave.font=[UIFont fontWithName:@"Helvetica" size:11];
	lblsave	.backgroundColor=[UIColor clearColor];
	[self.view addSubview:lblsave];
	[lblsave release],lblsave=nil;
	
	UIButton *btnSubmit=[UIButton buttonWithType:UIButtonTypeCustom];
	btnSubmit.frame=CGRectMake(30, 320, 260, 40);
	[btnSubmit setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
	[btnSubmit setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	btnSubmit.titleLabel.font = [UIFont fontWithName:con.btnfontname size:con.btnfontsize];
	[btnSubmit setTitle:@"Submit" forState:UIControlStateNormal];
	[btnSubmit addTarget:self action:@selector(ClickbtnSubmit) forControlEvents:UIControlEventTouchUpInside];					 
	[self.view addSubview:btnSubmit];
	
	
	[self GetText];


}
-(void)GetText
{


			NSMutableArray *userinfo_arr=[passPerser passresponce];
			RequestPhase2_2 *objrequestPhase2_2=[[RequestPhase2_2 alloc] initWithTarget:self
																		  SuccessAction:@selector(onSucceffulGettext)
																		  FailureAction:@selector(onFailure)];
			
			[objrequestPhase2_2 GetCustomText:[userinfo_arr objectAtIndex:2] uID:[userinfo_arr objectAtIndex:4]];
			 [objrequestPhase2_2 release];
			 [tools startLoading:self.view childView:loadingView text:@"Loading your Claim activity. Wait…."];
	
	 
	
}
-(void)onSucceffulGettext
{
	
	[tools stopLoading:loadingView];
	
	NSMutableArray *arrtxt=[eCommunicationParser getarrText];
	
	//NSData *Data=[[NSData alloc]initWithData:((eCommunicationOBJ *)[arrtxt objectAtIndex:0]).stragreementText];
	//NSData *Data =(NSData *)((eCommunicationOBJ *)[arrtxt objectAtIndex:0]).stragreementText;
	NSString *str=((eCommunicationOBJ *)[arrtxt objectAtIndex:0]).stragreementText;
	
	txtview=[[UITextView alloc]init];
	txtview.frame=CGRectMake(10, 65, 300, 220);
	//txtview.text=@"As part of your online application, certain laws require us to provide certain account information to you, and you have a right to receive it on paper. We may provide such information to you electronically if we first present this disclosure and obtain your consent to receiving electronic notices. If you do not wish to consent, you may apply via phone by calling us at 1-866-791-0250. Your consent to receiving account information electronically covers, but is not limited to, the Health Savings Account (HSA) Schedule of Fees, the HSA Custodial Agreement and the Online Service Agreement provided in this online application and other communications regarding your application or any resulting account. Your consent to receiving account information electronically also covers Healthcare Reimbursement Arrangements (HRA) or Flexible Spending Accounts (FSA), or other employer- sponsored benefit accounts. Additionally, your consent will apply to subsequent disclosures and information that we are required or otherwise choose to provide from time to time. These include (without limitation) change-in-terms notices; periodic, annual,monthly or other statements; copies of your consent for preauthorized transfers from your account; notices about variances in the amount of preauthorized transfers; opt-out notices regarding affiliate or other marketing; privacy notices; and conclusions concerning errors that you report (collectively, eCommunications).Email Addresses. Electronic Communications will be provided to you online or sent to the email address you or any co-applicant provided in your application, and you agree to pass-on notices to other applicants. If an eCommunication is sent via email and is returned as undelivered, we may use any other email address that we have for you or a co-applicant. We also reserve the right to use postal addresses. You must notify us of any change in your email address by calling  1-866-791-0250 or updating your information directly through our online banking service. Unless otherwise required by law, you agree that any Electronic Communications will be deemed received by you when sent by any means set forth above.Withdrawal of Consent. You may withdraw your consent to receiving the Electronic Communications by calling 1-866-791-0250; withdrawal by any co-applicant will be effective for all applicants. Your consent will remain effective throughout this transaction (but you may end the transaction by withdrawing your application or closing any resulting account). Withdrawal will not apply to actions already taken or initiated in reliance on your consent. You will not be charged any fee for your withdrawal of consent.Consent Coverage; Notices From You Are Not Covered. Applicable law or contracts sometimes require you to give us written notices, and your consent does not relate to those items. In order to coordinate our processing, you must still provide us notice on paper.Copies. You may print or make a copy of the Legal Documents by using the Print button or saving a PDF copy - do this when you first review the documents, because after submission we do not keep them all in a place that you can access. If you would like a free paper copy from us, you may call 1-866-791-0250.System Requirements. In order to properly access and retain your Electronic Communications you must have the following hardware and software (collectively, System Requirements):- A personal computer (including a monitor) capable of accessing the Internet and sending andreceiving email and a printer capable of printing copies of website information for your records (if you desire paper records);- Internet access;- A computer hard drive capable of storing data, if you wish to store Electronic Communications;- An Internet browser that supports 128-bit encryption, including any of the following:Supported Browsers   PC Windows XP   Supported Browser Microsoft Internet Explorer 6.0 and higher Most eCommunications provided within Bank of America websites are provided either in HTML and/or PDF format. For eCommunications provided in PDF format, Adobe Acrobat Reader 6.0 or later versions is required  A free copy of Adobe Acrobat Reader may be obtained from the Adobe website at www.adobe.com.";
	[[txtview layer] setBorderColor:[[UIColor blackColor] CGColor]];
	[[txtview layer] setBorderWidth:1.0];
	[[txtview layer] setCornerRadius:2.0];
	[txtview setClipsToBounds: YES];
	txtview.delegate=self;
	//[self.view addSubview:txtview];
	txtview.text=str;
	
	
	UIWebView *webView=[[UIWebView alloc]initWithFrame:CGRectMake(10, 65, 300, 220)];
	[[webView layer] setBorderColor:[[UIColor blackColor] CGColor]];
	[[webView layer] setBorderWidth:1.0];
	
	[[webView layer] setCornerRadius:2.0];
	[webView setClipsToBounds: YES];
	[webView loadHTMLString:str baseURL:nil];
	[self.view addSubview:webView];
	

	
}
  

-(void)btn_RememberMe_Clicked:(id)sender
{
	
	if(btn_Remember_Me.currentBackgroundImage==[UIImage imageNamed:@"uncheck_box.png"])
		
	{		
		[btn_Remember_Me setBackgroundImage:[UIImage imageNamed:@"check-box.png"]forState:UIControlStateNormal];
		
	}
	
	else
	{
		[btn_Remember_Me setBackgroundImage:[UIImage imageNamed:@"uncheck_box.png"]forState:UIControlStateNormal];
		
		
	}
	
	
}

-(void)ClickbtnSubmit
{
	

	if(btn_Remember_Me.currentBackgroundImage==[UIImage imageNamed:@"uncheck_box.png"])
	{
		
		
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Accept terms and conditions" delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
		[alert show];
		[alert release];
		return ;
		
		
	}
	else 
	{
	
		NSMutableArray *userinfo_arr=[passPerser passresponce];
		RequestPhase2_2 *objrequestPhase2_2=[[RequestPhase2_2 alloc] initWithTarget:self
																	  SuccessAction:@selector(onSuccefful)
																	  FailureAction:@selector(onFailure)];
		
		[objrequestPhase2_2 SubmitforeCommunication:[userinfo_arr objectAtIndex:2] uID:[userinfo_arr objectAtIndex:4] email:[dictvalue valueForKey:@"Email"] reenterEmail:[dictvalue valueForKey:@"EmailRe"] hsaStatement:[dictvalue valueForKey:@"HSA"] accountStatement:[dictvalue valueForKey:@"ACCOUNT"] otherCommunication:[dictvalue valueForKey:@"OTHER"]];
		[objrequestPhase2_2 release];
		
		[tools startLoading:self.view childView:loadingView text:@"Loading your Claim activity. Wait…."];
		
	}
	
	
}

	
-(void)onSuccefful
{
	
	
	[tools stopLoading:loadingView];
	
	NSString *strerror=[PaynowcontinueParser getErrortext];
	NSString *strreturncode=[PaynowcontinueParser getreturncode];
	
	if([strreturncode isEqualToString:@"0"])
	{
		
		[self.navigationController popToRootViewControllerAnimated:YES];
	}

	else
	{
		UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:@"Info" 
															  message:strerror
															 delegate:self 
													cancelButtonTitle:@"OK" 
													otherButtonTitles:nil];
		alertWarning.tag=111;
		[alertWarning show];
		[alertWarning release];
		
		
	}	
	
	
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	
 
	
}
-(void)onFailure
{
		
	[tools stopLoading:loadingView];
}
- (BOOL)textViewShouldBeginEditing:(UITextView *)textView
{
	
	return NO;
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
