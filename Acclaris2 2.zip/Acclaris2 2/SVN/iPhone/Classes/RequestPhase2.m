//
//  RequestPhase2.m
//  Acclaris
//
//  Created by Subhojit on 25/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "RequestPhase2.h"
#import "SSCrypto.h"
#import "ClaimSubmitNewParser.h"
#import "Claimonlineserviceparser.h"
#import "UnsubmittedClaimParser.h"
#import "activeScheduleParser.h"
#import "errorParser.h"
@implementation RequestPhase2
-(id)initWithTarget:(id)actionTarget
	  SuccessAction:(SEL)successAction 
	  FailureAction:(SEL)failureAction
{
	self=[super init];
	if(self==nil)
	{
		return nil;
	}
	
	target=actionTarget;
	successHandler=successAction;
	failureHandler=failureAction;
	
	
	return self;
}
#pragma mark CREATE HEADER
-(NSMutableString *)createHeader
{
	NSMutableString *header=[[NSMutableString alloc] init];
	[header appendString:@"<?xml version=\"1.0\" encoding=\"utf-8\" ?>"];
	[header appendString:@"<soapenv:Envelope xmlns:ser=\"http://www.acclaris.com/servicetypesma_p2\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">"];
	
	//[header appendString:@"<soapenv:Envelope xmlns:ser=\"http://www.acclaris.com/servicetypesma_p2\" xmlns:ser1="http://www.acclaris.com/servicetypesma" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
	
	
	
	
	[header appendString:@"<soapenv:Header><wsse:Security soapenv:mustUnderstand=\"1\" xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\">"];
	[header appendString:@"<wsse:UsernameToken wsu:Id=\"UsernameToken-28376915\" xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">"];
	[header appendString:@"<wsse:Username>objectsolwsuser</wsse:Username>"];
	[header appendString:@"<wsse:Password Type=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordDigest\">"];
	
	SSCrypto *crypto = [ [ SSCrypto alloc ] init ];
	
	NSTimeInterval t = [ [ NSDate date ] timeIntervalSince1970 ];
	NSString * nonce = [ [ NSNumber numberWithDouble:t ] stringValue ];
	
	[ crypto setClearTextWithString:nonce ];
	NSString *base64nonce = [ [ crypto clearTextAsData ] encodeBase64WithNewlines:NO ];
	
	//NSString *created = [ DateFormate stringFromDate:[ NSDate date ] ];
	
	
	NSString *created =[self getUTCFormateDate:[ NSDate date]];
	
	
	NSString *combined = [ NSString stringWithFormat:@"%@%@%@", nonce, created, @"local123" ];
	[ crypto setClearTextWithString:combined ];
	NSString *passwordDigest = [ [crypto digest:@"SHA1" ] encodeBase64WithNewlines:NO ];
	[header appendString:passwordDigest];
	[header appendString:@"</wsse:Password><wsse:Nonce>"];
	[header appendString:base64nonce];
	[header appendString:@"</wsse:Nonce><wsu:Created>"];
	[header appendString:created];
	[header appendString:@"</wsu:Created></wsse:UsernameToken></wsse:Security></soapenv:Header>"];
	
	return header;
}
#pragma mark CREATE HEADER
-(NSMutableString *)createHeader1
{
	NSMutableString *header=[[NSMutableString alloc] init];
	[header appendString:@"<?xml version=\"1.0\" encoding=\"utf-8\" ?>"];
	//[header appendString:@"<soapenv:Envelope xmlns:ser=\"http://www.acclaris.com/servicetypesma_p2\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">"];

	
	//[header appendString:@"<soapenv:Envelope xmlns:ser=\"http://www.acclaris.com/servicetypesma_p2\" xmlns:ser1=\"http://www.acclaris.com/servicetypesma\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">"];
	 
	 
	 [header appendString:@"<soapenv:Envelope xmlns:ser=\"http://www.acclaris.com/servicetypesma_p2\" xmlns:ser1=\"http://www.acclaris.com/servicetypesma\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">"];
	 
	 [header appendString:@"<soapenv:Header><wsse:Security soapenv:mustUnderstand=\"1\" xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\">"];
	 [header appendString:@"<wsse:UsernameToken wsu:Id=\"UsernameToken-28376915\" xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">"];
	 [header appendString:@"<wsse:Username>objectsolwsuser</wsse:Username>"];
	 [header appendString:@"<wsse:Password Type=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordDigest\">"];
	 
	 SSCrypto *crypto = [ [ SSCrypto alloc ] init ];
	 
	 NSTimeInterval t = [ [ NSDate date ] timeIntervalSince1970 ];
	 NSString * nonce = [ [ NSNumber numberWithDouble:t ] stringValue ];
	 
	 [ crypto setClearTextWithString:nonce ];
	 NSString *base64nonce = [ [ crypto clearTextAsData ] encodeBase64WithNewlines:NO ];
	 
	 //NSString *created = [ DateFormate stringFromDate:[ NSDate date ] ];
	 
	 
	 NSString *created =[self getUTCFormateDate:[ NSDate date]];
	 
	 
	 NSString *combined = [ NSString stringWithFormat:@"%@%@%@", nonce, created, @"local123" ];
	 [ crypto setClearTextWithString:combined ];
	 NSString *passwordDigest = [ [crypto digest:@"SHA1" ] encodeBase64WithNewlines:NO ];
	 [header appendString:passwordDigest];
	 [header appendString:@"</wsse:Password><wsse:Nonce>"];
	 [header appendString:base64nonce];
	 [header appendString:@"</wsse:Nonce><wsu:Created>"];
	 [header appendString:created];
	 [header appendString:@"</wsu:Created></wsse:UsernameToken></wsse:Security></soapenv:Header>"];
	 
	 return header;
 }
 
-(NSString *)getUTCFormateDate:(NSDate *)localDate
{
	NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
	NSTimeZone *timeZone = [NSTimeZone timeZoneWithName:@"UTC"];
	[dateFormatter setTimeZone:timeZone];
	[dateFormatter setDateFormat:@"YYYY-MM-dd'T'HH:mm:ss.S"];
	NSString *dateString = [dateFormatter stringFromDate:localDate];
	
	return dateString;
}

#pragma mark -
#pragma mark serverconnection

-(void)GetOnlnClaimCtrgyTypeMAService:(NSString *)participantID uID:(NSString *)userID
{
	
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	else
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	whichAPI=@"OnlnClaimCtrgy";
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader];
	[sRequest appendString:@"<soapenv:Body><ser:GetOnlineClaimSetupMA><ser:participantID>"];
	[sRequest appendString:	participantID];
	
	[sRequest appendString:@"</ser:participantID><ser:participantCode/><ser:userID>"];
	[sRequest appendString:userID];
	
	[sRequest appendString:@  "</ser:userID><ser:userType>EE</ser:userType><ser:clientName>Mobile</ser:clientName><ser:param1/><ser:param2/><ser:param3/><ser:param4/></ser:GetOnlineClaimSetupMA></soapenv:Body></soapenv:Envelope>"];
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	link=[link stringByAppendingString:@"GetOnlineClaimSetupMAService"];
	[self callPostMethod:sRequest Action:@"GetOnlineClaimSetupMA" API:link];
	
	
}

-(void)ClaimOnlineServiceSave:(NSString *)participantID uID:(NSString *)userID claimCaty:(NSString *)claimCategory claimtpe:(NSString *)claimtype  amt:(NSString *)amount 
				 SerBedt:(NSString *)serviceBeginDt 
				 SerEedt:(NSString *)serviceEndDt
				 Note:(NSString *)note
				 isPrYr:(NSString *)isPriorYear
                 payMode:(NSString *)payMode
				 providerName:(NSString *) providerName
				PayeeId:(NSString *)PayeeId allowDuplicateClaim:(NSString *)allowDuplicateClaim
               opcode:(NSString *)opcode
{

	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	else
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	whichAPI=@"ClaimOnlineService_Save";
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader];
	[sRequest appendString:@"<soapenv:Body><ser:SaveClaim><ser:participantID>"];
	[sRequest appendString:participantID];
	//[sRequest appendString:@"2480516"];
	[sRequest appendString:@"</ser:participantID><ser:participantCode/><ser:userID>"];
	[sRequest appendString:userID];
	//[sRequest appendString:@"794102"];
	
	[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType><ser:clientName>Mobile</ser:clientName><ser:clmDtlsIPDto><ser:claimCategory>"];
	[sRequest appendString:claimCategory];
	//[sRequest appendString:@"Medical"];
	[sRequest appendString:@"</ser:claimCategory><ser:claimType>"];
	[sRequest appendString:claimtype];
	//[sRequest appendString:@"DOCTOR"];
	[sRequest appendString:@"</ser:claimType><ser:amount>"];
	[sRequest appendString:amount];
	[sRequest appendString:@"</ser:amount><ser:serviceBeginDt>"];
	[sRequest appendString:serviceBeginDt];
	[sRequest appendString:@"</ser:serviceBeginDt><ser:serviceEndDt>"];
	[sRequest appendString:serviceEndDt];
	[sRequest appendString:@"</ser:serviceEndDt><ser:note>"];
	[sRequest appendString:note];
	[sRequest appendString:@"</ser:note><ser:isPriorYear>"];
	[sRequest appendString:isPriorYear];
	[sRequest appendString:@"</ser:isPriorYear><ser:payMode>"];
	[sRequest appendString:payMode];
	[sRequest appendString:@"</ser:payMode><ser:payeeID>"];
	[sRequest appendString:PayeeId];
	[sRequest appendString:@"</ser:payeeID><ser:providerName>"];
	[sRequest appendString:providerName];
	[sRequest appendString:@"</ser:providerName><ser:providerID/><ser:dependentID/><ser:elctID/><ser:actpCD/><ser:invoiceNO/><ser:claimID/><ser:account/><ser:payRef/><ser:RefNo/></ser:clmDtlsIPDto><ser:opCode>"];
	[sRequest appendString:opcode];
	[sRequest appendString:@"</ser:opCode><ser:allowDuplicateClaim>"];
	[sRequest appendString:allowDuplicateClaim];
	[sRequest appendString:@"</ser:allowDuplicateClaim><ser:param1>?</ser:param1><ser:param2>?</ser:param2><ser:param3>?</ser:param3><ser:param4>?</ser:param4></ser:SaveClaim></soapenv:Body></soapenv:Envelope>"];
	
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	link=[link stringByAppendingString:@"OnlineClaimService"];
	[self callPostMethod:sRequest Action:@"SaveClaim" API:link];
	
	
}

-(void)ClaimOnlineServiceSave2:(NSString *)participantID uID:(NSString *)userID claimCaty:(NSString *)claimCategory claimtpe:(NSString *)claimtype  amt:(NSString *)amount 

					   SerBedt:(NSString *)serviceBeginDt 

					   SerEedt:(NSString *)serviceEndDt

						  Note:(NSString *)note

						isPrYr:(NSString *)isPriorYear

					   payMode:(NSString *)payMode

				  providerName:(NSString *) providerName

				  accountvalue:(NSString *)actpCD

					   PayeeId:(NSString *)PayeeId allowDuplicateClaim:(NSString *)allowDuplicateClaim

						opcode:(NSString *)opcode

{
	
	
	if([AcclarisAppDelegate isNetworkAvailable])
		
	{
		
		;
		
	}
	
	else
		
	{   [target performSelector:failureHandler];
		
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		
		[alert show];
		
		return;
		
	}
	
	
	whichAPI=@"ClaimOnlineService_Save2";
	
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	
	
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	
	sRequest=[self createHeader];
	
	[sRequest appendString:@"<soapenv:Body><ser:SaveClaim><ser:participantID>"];
	
	[sRequest appendString:participantID];
	
	//[sRequest appendString:@"2480516"];
	
	[sRequest appendString:@"</ser:participantID><ser:participantCode/><ser:userID>"];
	
	[sRequest appendString:userID];
	
	//[sRequest appendString:@"794102"];
	
	[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType><ser:clientName>Mobile</ser:clientName><ser:clmDtlsIPDto><ser:claimCategory>"];
	
	[sRequest appendString:claimCategory];
	
	[sRequest appendString:@"</ser:claimCategory><ser:claimType>"];
	
	[sRequest appendString:claimtype];
	
	[sRequest appendString:@"</ser:claimType><ser:amount>"];
	
	[sRequest appendString:amount];
	
	[sRequest appendString:@"</ser:amount><ser:serviceBeginDt>"];
	
	[sRequest appendString:serviceBeginDt];
	
	[sRequest appendString:@"</ser:serviceBeginDt><ser:serviceEndDt>"];
	
	[sRequest appendString:serviceEndDt];
	
	[sRequest appendString:@"</ser:serviceEndDt><ser:note>"];
	
	[sRequest appendString:note];
	
	[sRequest appendString:@"</ser:note><ser:isPriorYear>"];
	
	[sRequest appendString:isPriorYear];
	
	[sRequest appendString:@"</ser:isPriorYear><ser:payMode>"];
	
	[sRequest appendString:payMode];
	
	[sRequest appendString:@"</ser:payMode><ser:payeeID>"];
	
	[sRequest appendString:PayeeId];
	
	[sRequest appendString:@"</ser:payeeID>"];
	
	[sRequest appendString:@"<ser:providerName>"];
	
	[sRequest appendString:providerName];
	
	[sRequest appendString:@"</ser:providerName><ser:providerID/><ser:dependentID/><ser:elctID/><ser:actpCD>"];
	
	[sRequest appendString:actpCD];
	
	[sRequest appendString:@"</ser:actpCD><ser:invoiceNO/><ser:claimID/><ser:account/><ser:payRef/><ser:RefNo/></ser:clmDtlsIPDto><ser:opCode>"];
	
	[sRequest appendString:opcode];
	
	[sRequest appendString:@"</ser:opCode><ser:allowDuplicateClaim>"];
	
	[sRequest appendString:allowDuplicateClaim];
	
	[sRequest appendString:@"</ser:allowDuplicateClaim><ser:param1>?</ser:param1><ser:param2>?</ser:param2><ser:param3>?</ser:param3><ser:param4>?</ser:param4></ser:SaveClaim></soapenv:Body></soapenv:Envelope>"];
	
	
	NSLog(@"request string: %@",sRequest);
	
	NSString *link=urllink;
	
	link=[link stringByAppendingString:@"OnlineClaimService"];
	
	[self callPostMethod:sRequest Action:@"SaveClaim" API:link];
	
	
	
}


-(void)callfromSelectpayee:(NSString *)participantID uID:(NSString *)userID claimCaty:(NSString *)claimCategory claimtpe:(NSString *)claimtype  amt:(NSString *)amount 
					  SerBedt:(NSString *)serviceBeginDt 
					  SerEedt:(NSString *)serviceEndDt
						 Note:(NSString *)note
					   isPrYr:(NSString *)isPriorYear
					  payMode:(NSString *)payMode
				 providerName:(NSString *) providerName
                 accountvalue:(NSString *)actpCD
				   claimID:(NSString *)claimID
                 PayeeId:(NSString *)PayeeId allowDuplicateClaim:(NSString *)allowDuplicateClaim
                 opcode:(NSString *)opcode
{
	
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	else
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	whichAPI=@"ClaimOnlineService_Save2";
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader];
	[sRequest appendString:@"<soapenv:Body><ser:SaveClaim><ser:participantID>"];
	[sRequest appendString:participantID];
	//[sRequest appendString:@"2480516"];
	[sRequest appendString:@"</ser:participantID><ser:participantCode/><ser:userID>"];
	[sRequest appendString:userID];
	//[sRequest appendString:@"794102"];
	[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType><ser:clientName>Mobile</ser:clientName><ser:clmDtlsIPDto><ser:claimCategory>"];
	[sRequest appendString:claimCategory];
	[sRequest appendString:@"</ser:claimCategory><ser:claimType>"];
	[sRequest appendString:claimtype];
	[sRequest appendString:@"</ser:claimType><ser:amount>"];
	[sRequest appendString:amount];
	[sRequest appendString:@"</ser:amount><ser:serviceBeginDt>"];
	[sRequest appendString:serviceBeginDt];
	[sRequest appendString:@"</ser:serviceBeginDt><ser:serviceEndDt>"];
	[sRequest appendString:serviceEndDt];
	[sRequest appendString:@"</ser:serviceEndDt><ser:note>"];
	[sRequest appendString:note];
	[sRequest appendString:@"</ser:note><ser:isPriorYear>"];
	[sRequest appendString:isPriorYear];
	[sRequest appendString:@"</ser:isPriorYear><ser:payMode>"];
	[sRequest appendString:payMode];
	[sRequest appendString:@"</ser:payMode><ser:payeeID>"];
	[sRequest appendString:PayeeId];
	[sRequest appendString:@"</ser:payeeID>"];
	[sRequest appendString:@"<ser:providerName>"];
	[sRequest appendString:providerName];
	[sRequest appendString:@"</ser:providerName><ser:providerID/><ser:dependentID/><ser:elctID/><ser:actpCD>"];
	[sRequest appendString:actpCD];
	[sRequest appendString:@"</ser:actpCD><ser:invoiceNO/><ser:claimID>"];
	[sRequest appendString:claimID];
	[sRequest appendString:@"</ser:claimID><ser:account/><ser:payRef/><ser:RefNo/></ser:clmDtlsIPDto><ser:opCode>"];
	[sRequest appendString:opcode];
	[sRequest appendString:@"</ser:opCode><ser:allowDuplicateClaim>"];
	[sRequest appendString:allowDuplicateClaim];
	[sRequest appendString:@"</ser:allowDuplicateClaim><ser:param1>?</ser:param1><ser:param2>?</ser:param2><ser:param3>?</ser:param3><ser:param4>?</ser:param4></ser:SaveClaim></soapenv:Body></soapenv:Envelope>"];
	
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	link=[link stringByAppendingString:@"OnlineClaimService"];
	[self callPostMethod:sRequest Action:@"SaveClaim" API:link];
	
	
}

-(void)GetUnSubmittedClaim:(NSString *)participantID uID:(NSString *)userID  
				noOfRecord:(NSString *)noOfRecords  
			   startAftersid:(NSString *)startAfterSeqID
{

	
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	else
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	whichAPI=@"GetUnsubmiited_claim";
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader];
	[sRequest appendString:@" <soapenv:Body><ser:GetUnsubmittedClaimsMA><ser:participantID>"];
	[sRequest appendString:participantID];
	[sRequest appendString:@"</ser:participantID><ser:participantCode/><ser:userID>"];
	[sRequest appendString:userID];
	[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType><ser:clientName>Mobile</ser:clientName>"];
	[sRequest appendString:@"<ser:noOfRecords>"];
	[sRequest appendString:noOfRecords];
	[sRequest appendString:@"</ser:noOfRecords><ser:startAfterSeqID>"];
	[sRequest appendString:startAfterSeqID];
	[sRequest appendString:@"</ser:startAfterSeqID><ser:param1/><ser:param2/><ser:param3/><ser:param4/></ser:GetUnsubmittedClaimsMA></soapenv:Body></soapenv:Envelope>"];
	
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	link=[link stringByAppendingString:@"GetUnsubmittedClaimsMAService"];
	[self callPostMethod:sRequest Action:@"ser:GetUnsubmittedClaimsMA" API:link];
	
	
}
-(void)EditUnSubmittedClaim:(NSString *)participantID uID:(NSString *)userID claimCaty:(NSString *)claimCategory claimtpe:(NSString *)claimtype  amt:(NSString *)amount 
					  SerBedt:(NSString *)serviceBeginDt 
					  SerEedt:(NSString *)serviceEndDt
						 Note:(NSString *)note
					   isPrYr:(NSString *)isPriorYear
					  payMode:(NSString *)payMode
				 providerName:(NSString *) providerName Claimid:(NSString *)claimID allowDuplicateClaim:(NSString *)allowDuplicateClaim
                 opcode:(NSString *)opcode 
{
	
	
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	else
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	whichAPI=@"EditUnSubmittedClaim";
	
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader];
	[sRequest appendString:@"<soapenv:Body><ser:SaveClaim><ser:participantID>"];
	[sRequest appendString:participantID];
	[sRequest appendString:@"</ser:participantID><ser:participantCode/><ser:userID>"];
	[sRequest appendString:userID];
	[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType><ser:clientName>Mobile</ser:clientName><ser:clmDtlsIPDto><ser:claimCategory>"];
	[sRequest appendString:claimCategory];
	[sRequest appendString:@"</ser:claimCategory><ser:claimType>"];
	[sRequest appendString:claimtype];
	[sRequest appendString:@"</ser:claimType><ser:amount>"];
	[sRequest appendString:amount];
	[sRequest appendString:@"</ser:amount><ser:serviceBeginDt>"];
	[sRequest appendString:serviceBeginDt];
	[sRequest appendString:@"</ser:serviceBeginDt><ser:serviceEndDt>"];
	[sRequest appendString:serviceEndDt];
	[sRequest appendString:@"</ser:serviceEndDt><ser:note>"];
	[sRequest appendString:note];
	[sRequest appendString:@"</ser:note><ser:isPriorYear>"];
	[sRequest appendString:isPriorYear];
	[sRequest appendString:@"</ser:isPriorYear><ser:payMode>"];
	[sRequest appendString:payMode];
	[sRequest appendString:@"</ser:payMode><ser:payeeID/>"];
	[sRequest appendString:@"<ser:providerName>"];
	[sRequest appendString:providerName];
	[sRequest appendString:@"</ser:providerName><ser:dependentID/><ser:elctID/><ser:actpCD/><ser:invoiceNO/><ser:claimID>"];
		
	[sRequest appendString:claimID];
	[sRequest appendString:@"</ser:claimID><ser:account/><ser:payRef/><ser:RefNo/></ser:clmDtlsIPDto><ser:opCode>"];
	[sRequest appendString:opcode];
	[sRequest appendString:@"</ser:opCode><ser:allowDuplicateClaim>"];
	[sRequest appendString:allowDuplicateClaim];
	[sRequest appendString:@"</ser:allowDuplicateClaim><ser:param1>?</ser:param1><ser:param2>?</ser:param2><ser:param3>?</ser:param3><ser:param4>?</ser:param4></ser:SaveClaim></soapenv:Body></soapenv:Envelope>"];
	
	
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	link=[link stringByAppendingString:@"OnlineClaimService"];
	[self callPostMethod:sRequest Action:@"SaveClaim" API:link];
	
	
}
-(void)EditUnSubmittedClaim2:(NSString *)participantID uID:(NSString *)userID claimCaty:(NSString *)claimCategory claimtpe:(NSString *)claimtype  amt:(NSString *)amount 
					SerBedt:(NSString *)serviceBeginDt 
					SerEedt:(NSString *)serviceEndDt
					   Note:(NSString *)note
					 isPrYr:(NSString *)isPriorYear
					payMode:(NSString *)payMode
			   providerName:(NSString *) providerName Claimid:(NSString *)claimID

				accountvalue:(NSString *)actpCD allowDuplicateClaim:(NSString *)allowDuplicateClaim
               opcode:(NSString *)opcode 

{
	
	
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	else
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	whichAPI=@"EditUnSubmittedClaim_2";
	
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader];
	[sRequest appendString:@"<soapenv:Body><ser:SaveClaim><ser:participantID>"];
	[sRequest appendString:participantID];
	[sRequest appendString:@"</ser:participantID><ser:participantCode/><ser:userID>"];
	[sRequest appendString:userID];
	[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType><ser:clientName>Mobile</ser:clientName><ser:clmDtlsIPDto><ser:claimCategory>"];
	[sRequest appendString:claimCategory];
	[sRequest appendString:@"</ser:claimCategory><ser:claimType>"];
	[sRequest appendString:claimtype];
	[sRequest appendString:@"</ser:claimType><ser:amount>"];
	[sRequest appendString:amount];
	[sRequest appendString:@"</ser:amount><ser:serviceBeginDt>"];
	[sRequest appendString:serviceBeginDt];
	[sRequest appendString:@"</ser:serviceBeginDt><ser:serviceEndDt>"];
	[sRequest appendString:serviceEndDt];
	[sRequest appendString:@"</ser:serviceEndDt><ser:note>"];
	[sRequest appendString:note];
	[sRequest appendString:@"</ser:note><ser:isPriorYear>"];
	[sRequest appendString:isPriorYear];
	[sRequest appendString:@"</ser:isPriorYear><ser:payMode>"];
	[sRequest appendString:payMode];
	[sRequest appendString:@"</ser:payMode><ser:payeeID/>"];
	[sRequest appendString:@"<ser:providerName>"];
	[sRequest appendString:providerName];
	[sRequest appendString:@"</ser:providerName><ser:dependentID/><ser:elctID/><ser:actpCD>"];
	[sRequest appendString:actpCD];
	[sRequest appendString:@"</ser:actpCD><ser:invoiceNO/><ser:claimID>"];
	[sRequest appendString:claimID];
	[sRequest appendString:@"</ser:claimID><ser:account/><ser:payRef/><ser:RefNo/></ser:clmDtlsIPDto><ser:opCode>"];
	[sRequest appendString:opcode];
	 [sRequest appendString:@"</ser:opCode><ser:allowDuplicateClaim>"];
	[sRequest appendString:allowDuplicateClaim];
	[sRequest appendString:@"</ser:allowDuplicateClaim><ser:param1>?</ser:param1><ser:param2>?</ser:param2><ser:param3>?</ser:param3><ser:param4>?</ser:param4></ser:SaveClaim></soapenv:Body></soapenv:Envelope>"];
	
	
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	link=[link stringByAppendingString:@"OnlineClaimService"];
	[self callPostMethod:sRequest Action:@"SaveClaim" API:link];
	
	
}

-(void)SubmitallClaim:(NSString *)participantID uID:(NSString *)userID
{
	
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	else
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	whichAPI=@"Submitall_Claim";
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader];
	[sRequest appendString:@"<soapenv:Body><ser:SubmitClaim><ser:participantID>"];
	[sRequest appendString:participantID];
	[sRequest appendString:@"</ser:participantID><ser:participantCode/><ser:userID>"];
	[sRequest appendString:userID];
	[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType><ser:clientName>Mobile</ser:clientName><ser:param1/><ser:param2/><ser:param3/><ser:param4/></ser:SubmitClaim></soapenv:Body></soapenv:Envelope>"];
	
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	link=[link stringByAppendingString:@"OnlineClaimService"];
	[self callPostMethod:sRequest Action:@"SubmitClaim" API:link];
	
}
-(void)deleteClaim:(NSString *)participantID uID:(NSString *)userID Claimid:(NSString *)claimID
{
	
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	else
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	whichAPI=@"delete_Claim";
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader];
	[sRequest appendString:@"<soapenv:Body><ser:DeleteClaim><ser:participantID>"];
	[sRequest appendString:participantID];
	[sRequest appendString:@"</ser:participantID><ser:participantCode/><ser:userID>"];
	[sRequest appendString:userID];
	[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType><ser:clientName>Mobile</ser:clientName><ser:pendingClmID>"];
	[sRequest appendString:claimID];
	[sRequest appendString:@"</ser:pendingClmID><ser:param1/><ser:param2/><ser:param3/><ser:param4/></ser:DeleteClaim></soapenv:Body></soapenv:Envelope>"];

	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	link=[link stringByAppendingString:@"OnlineClaimService"];
	[self callPostMethod:sRequest Action:@"DeleteClaim" API:link];
	
	
}

-(void)sendActiveScheduleRequest:(NSString *)participantID userid:(NSString *)userID 
							 Eid:(NSString *)E_id
						 startId:(NSString *)start_id
						 noOfRec:(NSString *)no_ofRec
					scheduletype:(NSString *)s_type;

{
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	else
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	whichAPI=@"ActiveScheduleRequest";
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader];
	[sRequest appendString:@"<soapenv:Body><ser:"];
	[sRequest appendString:s_type];
	[sRequest appendString:@"><ser:participantId>"];
	[sRequest appendString:participantID];
	[sRequest appendString:@"</ser:participantId><ser:participantCode/><ser:userID>"];
	[sRequest appendString:userID];
	[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType><ser:clientName>Mobile</ser:clientName><ser:elctID>"];
	[sRequest appendString:E_id];
	[sRequest appendString:@"</ser:elctID><ser:noOfRecords>"];
	[sRequest appendString:no_ofRec];
	[sRequest appendString:@"</ser:noOfRecords><ser:startAfterSeqID>"];
	[sRequest appendString:start_id];
	[sRequest appendString:@"</ser:startAfterSeqID><ser:param1/><ser:param2/><ser:param3/><ser:param4/></ser:"];
	[sRequest appendString:s_type]; 
	[sRequest appendString:@"></soapenv:Body></soapenv:Envelope>"];
	
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	link=[link stringByAppendingString:@"GetEESchContributionsMAService"];//To b changed
	[self callPostMethod:sRequest Action:@"GetActiveSchedules" API:link];//To b changed
	
}
-(void)sendInActiveScheduleRequest:(NSString *)participantID userid:(NSString *)userID 
							 Eid:(NSString *)E_id
						 startId:(NSString *)start_id
						 noOfRec:(NSString *)no_ofRec
					scheduletype:(NSString *)s_type

{
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	else
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	whichAPI=@"ActiveScheduleRequest";
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader];
	[sRequest appendString:@"<soapenv:Body><ser:GetInActiveSchedules>"];
	[sRequest appendString:@"<ser:participantId>"];
	[sRequest appendString:participantID];
	[sRequest appendString:@"</ser:participantId><ser:participantCode/><ser:userID>"];
	[sRequest appendString:userID];
	[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType><ser:clientName>Mobile</ser:clientName><ser:elctID>"];
	[sRequest appendString:E_id];
	[sRequest appendString:@"</ser:elctID><ser:noOfRecords>"];
	[sRequest appendString:no_ofRec];
	[sRequest appendString:@"</ser:noOfRecords><ser:startAfterSeqID>"];
	[sRequest appendString:start_id];
	[sRequest appendString:@"</ser:startAfterSeqID><ser:param1/><ser:param2/><ser:param3/><ser:param4/></ser:GetInActiveSchedules>"];
	[sRequest appendString:@"</soapenv:Body></soapenv:Envelope>"];
	
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	link=[link stringByAppendingString:@"GetEESchContributionsMAService"];//To b changed
	[self callPostMethod:sRequest Action:@"GetInActiveSchedules" API:link];//To b changed
	
}

-(void)GetProviderList:(NSString *)participantID userid:(NSString *)userID 

{
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	else
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	whichAPI=@"GetProvider_List";
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader];
	[sRequest appendString:@"<soapenv:Body><ser:GetPayees><ser:participantId>"];
	[sRequest appendString:participantID];
	[sRequest appendString:@"</ser:participantId><ser:participantCode/><ser:userID>"];
	[sRequest appendString:userID];
	[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType><ser:clientName>Mobile</ser:clientName><ser:startAfterSeqID>?</ser:startAfterSeqID><ser:param1>?</ser:param1><ser:param2>?</ser:param2><ser:param3>?</ser:param3><ser:param4>?</ser:param4></ser:GetPayees></soapenv:Body></soapenv:Envelope>"];
	
	
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	
	link=[link stringByAppendingString:@"GetPayeeDetailsMAService"];//To b changed
	[self callPostMethod:sRequest Action:@"GetPayees" API:link];//To b changed
	
	
}	
-(void)AddProvider:(NSString *)participantID uID:(NSString *)userID name:(NSString *)name nickName:(NSString *)nickName  firstName:(NSString *)firstName 
										 middleName:(NSString *)middleName 
										 lastName:(NSString *)lastName
											email:(NSString *)email
										  phone:(NSString *)phone
										 line1:(NSString *)line1
									line2:(NSString *)line2
									line3:(NSString *)line3
									city:(NSString *)city
									state:(NSString *)state
									zip:(NSString *)zip
		                           country:(NSString *)country

{
	
	
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	else
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	whichAPI=@"AddProvider";
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader1];
	[sRequest appendString:@"<soapenv:Body><ser:Add><ser:participantId>"];
	[sRequest appendString:participantID];
	[sRequest appendString:@"</ser:participantId><ser:participantCode/><ser:userID>"];
	[sRequest appendString:userID];
	[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType><ser:clientName>Mobile</ser:clientName><ser:payeeBn><ser:ID></ser:ID><ser:eeID></ser:eeID><ser:name>"];
	[sRequest appendString:name];
	[sRequest appendString:@"</ser:name><ser:nickName>"];
	[sRequest appendString:nickName];
	[sRequest appendString:@"</ser:nickName><ser:prefix></ser:prefix><ser:firstName>"];
	[sRequest appendString:firstName];
	[sRequest appendString:@"</ser:firstName><ser:middleName>"];
	[sRequest appendString:middleName];
	[sRequest appendString:@"</ser:middleName><ser:lastName>"];
	[sRequest appendString:lastName];
	[sRequest appendString:@"</ser:lastName><ser:email>"];
	[sRequest appendString:email];
	[sRequest appendString:@"</ser:email><ser:phone>"];
	[sRequest appendString:phone];
	[sRequest appendString:@"</ser:phone><ser:forFutureUse>Yes</ser:forFutureUse><ser:isActive></ser:isActive><ser:paymentReference></ser:paymentReference><ser:providerIdentifier></ser:providerIdentifier><ser:address><ser1:line1>"];
	[sRequest appendString:line1];
	[sRequest appendString:@"</ser1:line1><ser1:line2>"];
	[sRequest appendString:line2];
	[sRequest appendString:@"</ser1:line2><ser1:line3>"];
	[sRequest appendString:line3];
	[sRequest appendString:@"</ser1:line3><ser1:city>"];
	[sRequest appendString:city];
	[sRequest appendString:@"</ser1:city><ser1:state>"];
	[sRequest appendString:state];
	[sRequest appendString:@"</ser1:state><ser1:zip>"];
	[sRequest appendString:zip];
	[sRequest appendString:@"</ser1:zip><ser1:country>"];
	[sRequest appendString:country];
	[sRequest appendString:@"</ser1:country><ser1:addressType>M</ser1:addressType></ser:address></ser:payeeBn><ser:param1></ser:param1><ser:param2></ser:param2><ser:param3></ser:param3><ser:param4></ser:param4></ser:Add></soapenv:Body></soapenv:Envelope>"];
	
	
	 
	 NSLog(@"request string: %@",sRequest);
	 NSString *link=urllink;
	 
	 link=[link stringByAppendingString:@"PayeeDetailsMAService"];//To b changed
	 [self callPostMethod:sRequest Action:@"Add" API:link];//To b changed
	 
}
-(void)AddProvider2:(NSString *)participantID uID:(NSString *)userID name:(NSString *)name nickName:(NSString *)nickName  firstName:(NSString *)firstName 
		middleName:(NSString *)middleName 
		  lastName:(NSString *)lastName
			 email:(NSString *)email
			 phone:(NSString *)phone
			 line1:(NSString *)line1
			 line2:(NSString *)line2
			 line3:(NSString *)line3
			  city:(NSString *)city
			 state:(NSString *)state
			   zip:(NSString *)zip
		   country:(NSString *)country
                ID:(NSString *)ID


{
	
	
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	else
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	whichAPI=@"AddProvider_2";
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader1];
	[sRequest appendString:@"<soapenv:Body><ser:Save><ser:participantId>"];
	[sRequest appendString:participantID];
	[sRequest appendString:@"</ser:participantId><ser:participantCode/><ser:userID>"];
	[sRequest appendString:userID];
	[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType><ser:clientName>Mobile</ser:clientName><ser:payeeBn><ser:ID>"];
	[sRequest appendString:ID];
	[sRequest appendString:@"</ser:ID><ser:eeID></ser:eeID><ser:name>"];
	[sRequest appendString:name];
	[sRequest appendString:@"</ser:name><ser:nickName>"];
	[sRequest appendString:nickName];
	[sRequest appendString:@"</ser:nickName><ser:prefix></ser:prefix><ser:firstName>"];
	[sRequest appendString:firstName];
	[sRequest appendString:@"</ser:firstName><ser:middleName>"];
	[sRequest appendString:middleName];
	[sRequest appendString:@"</ser:middleName><ser:lastName>"];
	[sRequest appendString:lastName];
	[sRequest appendString:@"</ser:lastName><ser:email>"];
	[sRequest appendString:email];
	[sRequest appendString:@"</ser:email><ser:phone>"];
	[sRequest appendString:phone];
	[sRequest appendString:@"</ser:phone><ser:forFutureUse>Yes</ser:forFutureUse><ser:isActive></ser:isActive><ser:paymentReference></ser:paymentReference><ser:providerIdentifier></ser:providerIdentifier><ser:address><ser1:line1>"];
	[sRequest appendString:line1];
	[sRequest appendString:@"</ser1:line1><ser1:line2>"];
	[sRequest appendString:line2];
	[sRequest appendString:@"</ser1:line2><ser1:line3>"];
	[sRequest appendString:line3];
	[sRequest appendString:@"</ser1:line3><ser1:city>"];
	[sRequest appendString:city];
	[sRequest appendString:@"</ser1:city><ser1:state>"];
	[sRequest appendString:state];
	[sRequest appendString:@"</ser1:state><ser1:zip>"];
	[sRequest appendString:zip];
	[sRequest appendString:@"</ser1:zip><ser1:country>"];
	[sRequest appendString:country];
	[sRequest appendString:@"</ser1:country><ser1:addressType>M</ser1:addressType></ser:address></ser:payeeBn><ser:param1></ser:param1><ser:param2></ser:param2><ser:param3></ser:param3><ser:param4></ser:param4></ser:Save></soapenv:Body></soapenv:Envelope>"];
	
	
	
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	
	link=[link stringByAppendingString:@"PayeeDetailsMAService"];//To b changed
	[self callPostMethod:sRequest Action:@"Save" API:link];//To b changed
	
}

-(void)DeletePayee:(NSString *)participantID uID:(NSString *)userID payeeID:(NSString *)payeeID
{
	
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	else
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	whichAPI=@"DeletePayee";
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader1];
	
	[sRequest appendString:@"<soapenv:Body><ser:Delete><ser:participantId>"];
	[sRequest appendString:participantID];
	[sRequest appendString:@"</ser:participantId><ser:participantCode/><ser:userID>"];
	[sRequest appendString:userID];
	[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType><ser:clientName>Mobile</ser:clientName><ser:payeeID>"];
	[sRequest appendString:payeeID];
	[sRequest appendString:@"</ser:payeeID><ser:param1/><ser:param2/><ser:param3/><ser:param4/></ser:Delete></soapenv:Body></soapenv:Envelope>"];
	
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	
	link=[link stringByAppendingString:@"PayeeDetailsMAService"];//To b changed
	[self callPostMethod:sRequest Action:@"Delete" API:link];//To b changed
	
	
	
}
-(void)IgnoreAllclaim:(NSString *)participantID uID:(NSString *)userID
{
	
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	else
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	whichAPI=@"IgnoreAllclaim";
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader1];
	
	[sRequest appendString:@"<soapenv:Body><ser:IgnoreAllClaimToPayClaims><ser:participantId>"];
	[sRequest appendString:participantID];
	[sRequest appendString:@"</ser:participantId><ser:participantCode/><ser:userID>"];
	[sRequest appendString:userID];
	[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType><ser:clientName>Mobile</ser:clientName>"];
	[sRequest appendString:@"<ser:param1/><ser:param2/><ser:param3/><ser:param4/></ser:IgnoreAllClaimToPayClaims></soapenv:Body></soapenv:Envelope>"];
	
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	
	link=[link stringByAppendingString:@"ClaimsToPayService"];
	[self callPostMethod:sRequest Action:@"IgnoreAllClaimToPayClaims" API:link];
	
	
	
}
-(void)Ignoreclaim:(NSString *)participantID uID:(NSString *)userID pendingClmID:(NSString *)pendingClaimID
{
	
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	else
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	whichAPI=@"Ignoreclaim";
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader1];
	
	[sRequest appendString:@"<soapenv:Body><ser:IgnoreClaimToPayClaim><ser:participantId>"];
	[sRequest appendString:participantID];
	[sRequest appendString:@"</ser:participantId><ser:participantCode/><ser:userID>"];
	[sRequest appendString:userID];
	[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType><ser:clientName>Mobile</ser:clientName><ser:pendingClmID>"];
	[sRequest appendString:pendingClaimID];
	[sRequest appendString:@"</ser:pendingClmID><ser:param1/><ser:param2/><ser:param3/><ser:param4/></ser:IgnoreClaimToPayClaim></soapenv:Body></soapenv:Envelope>"];
	
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	
	link=[link stringByAppendingString:@"ClaimsToPayService"];
	[self callPostMethod:sRequest Action:@"IgnoreClaimToPayClaim" API:link];
	
	
	
}

-(void)Paynow:(NSString *)pId userid:(NSString *)uId pendingClmID:(NSString *)cId 
{
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	else
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	whichAPI=@"Paynow";
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	//NSMutableArray *userinfo_arr=[passPerser passresponce];//static method fired
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader];
	[sRequest appendString:@"<soapenv:Body><ser:GetClaimsToPayDetails><ser:participantId>"];
	[sRequest appendString:pId];
	[sRequest appendString:@"</ser:participantId><ser:userID>"];
	[sRequest appendString:uId];
	[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType><ser:clientName>Mobile</ser:clientName><ser:pendingClmID>"];
	[sRequest appendString:cId];
	[sRequest appendString:@"</ser:pendingClmID><ser:param1/><ser:param2/><ser:param3/><ser:param4/></ser:GetClaimsToPayDetails></soapenv:Body></soapenv:Envelope>"];
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	link=[link stringByAppendingString:@"ClaimsToPayService"];
	[self callPostMethod:sRequest Action:@"ser:GetClaimsToPayDetails" API:link];
	
}


-(void)ShowAllIgnoreclaim:(NSString *)participantID uID:(NSString *)userID
{
	
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	else
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	whichAPI=@"ShowAllIgnoreclaim";
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader1];
	
	[sRequest appendString:@"<soapenv:Body><ser:ShowAllIgnoreClaimToPayClaim><ser:participantId>"];
	[sRequest appendString:participantID];
	[sRequest appendString:@"</ser:participantId><ser:participantCode/><ser:userID>"];
	[sRequest appendString:userID];
	[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType><ser:clientName>Mobile</ser:clientName>"];
	[sRequest appendString:@"<ser:param1/><ser:param2/><ser:param3/><ser:param4/></ser:ShowAllIgnoreClaimToPayClaim></soapenv:Body></soapenv:Envelope>"];
	
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	
	link=[link stringByAppendingString:@"ClaimsToPayService"];
	[self callPostMethod:sRequest Action:@"ShowAllIgnoreClaimToPayClaim" API:link];
	
		
}

-(void)GetState:(NSString *)pId userid:(NSString *)uId countryCode:(NSString *)countryCode
{
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	
	else
	{   [target performSelector:failureHandler];
		 UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	whichAPI=@"GetState";
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader];
	[sRequest appendString:@"<soapenv:Body><ser:GetStateListMA><ser:participantID>"];
	[sRequest appendString:pId];
	[sRequest appendString:@"</ser:participantID><ser:participantCode/><ser:userID>"];
	[sRequest appendString:uId];
	[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType><ser:clientName>Mobile</ser:clientName><ser:stateForUsaOnly>No</ser:stateForUsaOnly><ser:countryCode>"];
	[sRequest appendString:countryCode];
	[sRequest appendString:@"</ser:countryCode><ser:param1/><ser:param2/><ser:param3/><ser:param4/></ser:GetStateListMA></soapenv:Body></soapenv:Envelope>"];
	
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	link=[link stringByAppendingString:@"GetEEPrflSmryMAService"];
	[self callPostMethod:sRequest Action:@"GetStateListMA" API:link];
		
	
}
-(void)GetCountry:(NSString *)pId userid:(NSString *)uId 

{
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	else
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	
	whichAPI=@"GetCountry";
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader];
	[sRequest appendString:@"<soapenv:Body><ser:GetCountryListMA><ser:participantID>"];
	[sRequest appendString:pId];
	[sRequest appendString:@"</ser:participantID><ser:participantCode/><ser:userID>"];
	[sRequest appendString:uId];
	[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType><ser:clientName>Mobile</ser:clientName><ser:allowForeignAddress>No</ser:allowForeignAddress>"];
	[sRequest appendString:@"<ser:param1/><ser:param2/><ser:param3/><ser:param4/></ser:GetCountryListMA></soapenv:Body></soapenv:Envelope>"];
	
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	link=[link stringByAppendingString:@"GetEEPrflSmryMAService"];
	[self callPostMethod:sRequest Action:@"GetCountryListMA" API:link];
	
	
}
-(void)UploadImage:(NSString *)pId userid:(NSString *)uId imgData:(NSString *)Imagedata imgName:(NSString *)ImageName trxnID:(NSString *)trxn_ID clmID:(NSString *)clm_ID

{
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	else
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	whichAPI=@"UploadImage";
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader];
	[sRequest appendString:@"<soapenv:Body><ser:UploadImage><ser:participantID>"];
	[sRequest appendString:pId];
	[sRequest appendString:@"</ser:participantID><ser:participantCode/><ser:userID>"];
	[sRequest appendString:uId];
	[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType><ser:clientName>Mobile</ser:clientName><ser:imageUploadIPDto><ser:data>"];
	[sRequest appendString:Imagedata];
	[sRequest appendString:@"</ser:data><ser:fileName>"];
	[sRequest appendString:ImageName];
	[sRequest appendString:@"</ser:fileName><ser:trxnID>"];
	[sRequest appendString:trxn_ID];
	[sRequest appendString:@"</ser:trxnID><ser:clmID>"];
	[sRequest appendString:clm_ID];
	[sRequest appendString:@"</ser:clmID><ser:doCompression>Yes</ser:doCompression><ser:doVirusCheck>Yes</ser:doVirusCheck><ser:size>234</ser:size></ser:imageUploadIPDto><ser:param1/><ser:param2/><ser:param3/><ser:param4/></ser:UploadImage></soapenv:Body></soapenv:Envelope>"];
	
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	link=[link stringByAppendingString:@"ImageUploadMAService?"];
	[self callPostMethod:sRequest Action:@"UploadImage" API:link];
	
	
}

-(void)ClaimsToPaySubmit:(NSString *)pId userid:(NSString *)uId  claimID:(NSString *)claimID  payMode:(NSString *)payMode actpCD:(NSString *)actpCD PayeeId:(NSString *)PayeeId

{
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	else
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	whichAPI=@"ClaimsToPaySubmit";
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader];
	[sRequest appendString:@"<soapenv:Body><ser:SubmitClaimsToPayClaim><ser:participantId>"];
	[sRequest appendString:pId];
	[sRequest appendString:@"</ser:participantId><ser:participantCode/><ser:userID>"];
	[sRequest appendString:uId];
	[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType><ser:clientName>Mobile</ser:clientName><ser:claimsToPayIPDto><ser:claimID>"];
	[sRequest appendString:claimID];
	[sRequest appendString:@"</ser:claimID><ser:actpCD>"];
	[sRequest appendString:actpCD];
	[sRequest appendString:@"</ser:actpCD><ser:payeeID>"];
	[sRequest appendString:PayeeId];
	[sRequest appendString:@"</ser:payeeID><ser:invoiceNo/><ser:accountNo/><ser:paymentRef/><ser:payMode>"];
	[sRequest appendString:payMode];
	[sRequest appendString:@"</ser:payMode></ser:claimsToPayIPDto>"];
	[sRequest appendString:@"<ser:param1/><ser:param2/><ser:param3/><ser:param4/></ser:SubmitClaimsToPayClaim></soapenv:Body></soapenv:Envelope>"];
	
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	link=[link stringByAppendingString:@"ClaimsToPayService"];
	[self callPostMethod:sRequest Action:@"SubmitClaimsToPayClaim" API:link];
	
	
}


#pragma mark -
-(void)callPostMethod:(NSMutableString *)sRequest Action:(NSString *)action API:(NSString *)api
{
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
	
	NSData *postBody;
	postBody=[sRequest dataUsingEncoding:NSUTF8StringEncoding];
	NSURL *apiURL=[NSURL URLWithString:api];
	NSMutableURLRequest *request=[NSMutableURLRequest requestWithURL:apiURL];
	[request addValue:@"text/xml" forHTTPHeaderField:@"Content-Type"];
	[request addValue:action forHTTPHeaderField:@"SOAPAction"];
	[request setHTTPMethod:@"POST"];
	[request setHTTPBody:postBody];
	NSURLConnection *conn=[[NSURLConnection alloc] initWithRequest:request delegate:self];
	if (conn)
	{
		;
	}
}

#pragma mark -
#pragma mark Connection Deligate
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
	NSLog(@"HERE RESPONSE: %d",[(NSHTTPURLResponse*) response statusCode]);
	
		if([(NSHTTPURLResponse*) response statusCode]!=200)
		{
			isstatus=YES;
			errorResponseAlert *myerrorResponseAlert=[[errorResponseAlert alloc]init];
			[myerrorResponseAlert showAlert];
			[target performSelector:failureHandler withObject:nil withObject:nil];
			[myerrorResponseAlert release],myerrorResponseAlert=nil;
			return;
			
		}

	if(d2)
		[d2 release];
	d2=[[NSMutableData alloc]init];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
	[d2 appendData:data];	
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{  
	
	
	if(isstatus==YES)
	{
		isstatus=NO;
		return;
	}
	
	else
	{
		
		
	NSString *data_Response = [[NSString alloc] initWithData:d2 encoding:NSUTF8StringEncoding];
	NSLog(@"Response_of_submit =%@",data_Response);
	
	NSString *XHTMLsearchForWarning = @"XHTML";
	NSRange rangeXHTMLWarning = [data_Response rangeOfString : XHTMLsearchForWarning];
	
	NSString *HTMLsearchForWarning = @"HTML";
	NSRange rangeHTMLWarning = [data_Response rangeOfString : HTMLsearchForWarning];
	if (rangeXHTMLWarning.location != NSNotFound || rangeHTMLWarning.location != NSNotFound)
	{
		[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
		[target performSelector:failureHandler];
		NSDictionary *customMessageList_dict=[[NSUserDefaults standardUserDefaults] objectForKey:@"customMessageList"];
		
		
		NSString *strmessage=[[customMessageList_dict valueForKey:@"200004"]valueForKey:@"message"];
		
		
		NSString *strtype=[[customMessageList_dict valueForKey:@"200004"]valueForKey:@"type"];
		
		
		UIAlertView *alert=[[UIAlertView alloc] initWithTitle:strtype message:strmessage delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		[alert show];
		[alert release];
		return ;
	}
	if ([whichAPI isEqualToString:@"OnlnClaimCtrgy"]) {
		
		
		NSError *parseError = nil;
		
		//for testing config files
		//NSString* filePath = [[NSBundle mainBundle] pathForResource:@"ClaimSetup" ofType:@"xml"];
		//NSString* fileContents = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
		//NSMutableData *data=((NSMutableData *)[fileContents dataUsingEncoding:NSUTF8StringEncoding]);
		/*for testing config files*/
		
		ClaimSubmitNewParser *objClaimSubmitNewParser = [[ClaimSubmitNewParser alloc] init];
		[objClaimSubmitNewParser parseXMLFileAtData:d2 parseError:&parseError];	
		[objClaimSubmitNewParser release];
		[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
			
		[target performSelector:successHandler withObject:nil withObject:nil];
		
		
		
	}
	
	if ([whichAPI isEqualToString:@"ClaimOnlineService_Save"] || [whichAPI isEqualToString:@"ClaimOnlineService_Save2"]) {
		
		
		NSError *parseError = nil;
		//for testing config files
		//NSString* filePath = [[NSBundle mainBundle] pathForResource:@"multiple" ofType:@"xml"];
		//NSString* fileContents = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
		//NSMutableData *data=((NSMutableData *)[fileContents dataUsingEncoding:NSUTF8StringEncoding]);
		/*for testing config files*/
		Claimonlineserviceparser *objClaimonlineSaveparser = [[Claimonlineserviceparser alloc] init];
		[objClaimonlineSaveparser parseXMLFileAtData:d2 parseError:&parseError];	
		[objClaimonlineSaveparser release];
		[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
		
		[target performSelector:successHandler withObject:nil withObject:nil];
	
	}
	
	
	if([whichAPI isEqualToString:@"GetUnsubmiited_claim"])
	   {
		   
		   NSError *parseError = nil;
		   UnsubmittedClaimParser *objUnsubmittedClaimParser = [[UnsubmittedClaimParser alloc] init];
		   [objUnsubmittedClaimParser parseXMLFileAtData:d2 parseError:&parseError];	
		   [objUnsubmittedClaimParser release];
		   
		   
		   [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
		   [target performSelector:successHandler withObject:nil withObject:nil];
		   
	   }
	
	if([whichAPI isEqualToString:@"Submitall_Claim"])
	{
		
		NSError *parseError = nil;
		
		//for testing config files
	    // NSString* filePath = [[NSBundle mainBundle] pathForResource:@"submit" ofType:@"xml"];
	    // NSString* fileContents = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
		// NSMutableData *data=((NSMutableData *)[fileContents dataUsingEncoding:NSUTF8StringEncoding]);
		/*for testing config files*/
		
		
		SubmitclaimParser *objSubmitclaimParser = [[SubmitclaimParser alloc] init];
		[objSubmitclaimParser parseXMLFileAtData:d2 parseError:&parseError];	
		[objSubmitclaimParser release];
		
		
		[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
		[target performSelector:successHandler withObject:nil withObject:nil];
		
	}
	if([whichAPI isEqualToString:@"delete_Claim"])
	{
		
		 NSError *parseError = nil;
		 Deleteparser *objDeleteparser = [[Deleteparser alloc] init];
		 [objDeleteparser parseXMLFileAtData:d2 parseError:&parseError];	
		 [objDeleteparser release];
		 
		
		[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
		[target performSelector:successHandler withObject:nil withObject:nil];
		
	}
	if([whichAPI isEqualToString:@"EditUnSubmittedClaim"] ||[whichAPI isEqualToString:@"EditUnSubmittedClaim_2"] )
	{
		
		  NSError *parseError = nil;
		 Claimonlineserviceparser *objClaimonlineSaveparser = [[Claimonlineserviceparser alloc] init];
		 [objClaimonlineSaveparser parseXMLFileAtData:d2 parseError:&parseError];	
		 [objClaimonlineSaveparser release];
		 [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
		 
		 
		[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
		[target performSelector:successHandler withObject:nil withObject:nil];
		
	}
	if([whichAPI isEqualToString:@"ActiveScheduleRequest"])
	{
		
		//for testing config files
		//NSString* filePath = [[NSBundle mainBundle] pathForResource:@"ActiveSshedule" ofType:@"xml"];
//		NSString* fileContents = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
//		NSMutableData *data=((NSMutableData *)[fileContents dataUsingEncoding:NSUTF8StringEncoding]);
		/*for testing config files*/
		
		//NSString *data_Response = [[NSString alloc] initWithData:d2 encoding:NSUTF8StringEncoding];
//		NSLog(@"\n\n\n\n\n\nResponse_of_submit =%@",data_Response);
		
		NSError *parseError = nil;
		activeScheduleParser *myactiveScheduleParser = [[activeScheduleParser alloc] init];
		[myactiveScheduleParser parseXMLFileAtData:d2 parseError:&parseError];	
		[myactiveScheduleParser release];
		
		
		[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
		[target performSelector:successHandler withObject:nil withObject:nil];
		
	}
	if([whichAPI isEqualToString:@"GetProvider_List"])
	{
		
		//for testing config files
		//NSString* filePath = [[NSBundle mainBundle] pathForResource:@"ActiveSshedule" ofType:@"xml"];
		//NSString* fileContents = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
		//NSMutableData *data=((NSMutableData *)[fileContents dataUsingEncoding:NSUTF8StringEncoding]);
		/*for testing config files*/
		
		//NSString *data_Response = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
		//NSLog(@"\n\n\n\n\n\nResponse_of_submit =%@",data_Response);
		
		NSError *parseError = nil;
		GetProviderListParser *objGetProviderListParser = [[GetProviderListParser alloc] init];
		[objGetProviderListParser parseXMLFileAtData:d2 parseError:&parseError];	
		[objGetProviderListParser release];
		
		
		[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
		[target performSelector:successHandler withObject:nil withObject:nil];
		
	}
	if([whichAPI isEqualToString:@"AddProvider"])
	{
		
		//for testing config files
		//NSString* filePath = [[NSBundle mainBundle] pathForResource:@"ActiveSshedule" ofType:@"xml"];
		//NSString* fileContents = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
		//NSMutableData *data=((NSMutableData *)[fileContents dataUsingEncoding:NSUTF8StringEncoding]);
		/*for testing config files*/
		
		//NSString *data_Response = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
		//NSLog(@"\n\n\n\n\n\nResponse_of_submit =%@",data_Response);
		
		NSError *parseError = nil;
		AddproviderParser *objGetProviderListParser = [[AddproviderParser alloc] init];
		[objGetProviderListParser parseXMLFileAtData:d2 parseError:&parseError];	
		[objGetProviderListParser release];
		
		
		[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
		[target performSelector:successHandler withObject:nil withObject:nil];
		
	}
	if([whichAPI isEqualToString:@"DeletePayee"])
	{
		
		//for testing config files
		//NSString* filePath = [[NSBundle mainBundle] pathForResource:@"ActiveSshedule" ofType:@"xml"];
		//NSString* fileContents = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
		//NSMutableData *data=((NSMutableData *)[fileContents dataUsingEncoding:NSUTF8StringEncoding]);
		/*for testing config files*/
		
		//NSString *data_Response = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
		//NSLog(@"\n\n\n\n\n\nResponse_of_submit =%@",data_Response);
		
		/*NSError *parseError = nil;
		 GetProviderListParser *objGetProviderListParser = [[GetProviderListParser alloc] init];
		 [objGetProviderListParser parseXMLFileAtData:d2 parseError:&parseError];	
		 [objGetProviderListParser release];*/
		
		
		
		[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
		[target performSelector:successHandler withObject:nil withObject:nil];
		
	}
	if([whichAPI isEqualToString:@"AddProvider_2"])
	{
		
		//for testing config files
		//NSString* filePath = [[NSBundle mainBundle] pathForResource:@"ActiveSshedule" ofType:@"xml"];
		//NSString* fileContents = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
		//NSMutableData *data=((NSMutableData *)[fileContents dataUsingEncoding:NSUTF8StringEncoding]);
		/*for testing config files*/
		
		//NSString *data_Response = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
		//NSLog(@"\n\n\n\n\n\nResponse_of_submit =%@",data_Response);
		
		/*NSError *parseError = nil;
		 GetProviderListParser *objGetProviderListParser = [[GetProviderListParser alloc] init];
		 [objGetProviderListParser parseXMLFileAtData:d2 parseError:&parseError];	
		 [objGetProviderListParser release];*/
		
		
		
		[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
		[target performSelector:successHandler withObject:nil withObject:nil];
		
	}
	if([whichAPI isEqualToString:@"Ignoreclaim"])
	{
		NSError *parseError = nil;
		errorParser *myerrorParser = [[errorParser alloc] init];
		[myerrorParser parseXMLFileAtData:d2 parseError:&parseError];	
		[myerrorParser release];
		[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
		
		
		[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
		[target performSelector:successHandler];
	}
	if([whichAPI isEqualToString:@"IgnoreAllclaim"])
	{
		NSError *parseError = nil;
		errorParser *myerrorParser = [[errorParser alloc] init];
		[myerrorParser parseXMLFileAtData:d2 parseError:&parseError];	
		[myerrorParser release];
		
		[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
		[target performSelector:successHandler];
	}
	if([whichAPI isEqualToString:@"Paynow1"])
	{
	}
	if([whichAPI isEqualToString:@"ShowAllIgnoreclaim"])
	{
		
		NSError *parseError = nil;
		errorParser *myerrorParser = [[errorParser alloc] init];
		[myerrorParser parseXMLFileAtData:d2 parseError:&parseError];	
		[myerrorParser release];
		[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
		
		
		[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
		[target performSelector:successHandler];
	}
	if ([whichAPI isEqualToString:@"Paynow"]) 
	{
		//NSString* filePath = [[NSBundle mainBundle] pathForResource:@"paynow" ofType:@"xml"];
		//NSString* fileContents = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
		//NSMutableData *data=((NSMutableData *)[fileContents dataUsingEncoding:NSUTF8StringEncoding]);
		//for testing config files*/
		
		//NSString *data_Response = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
		//NSLog(@"\n\n\n\n\n\nResponse_of_submit =%@",data_Response);
		
		 NSError *parseError = nil;
		 PaynowParser *objPaynowParser= [[PaynowParser alloc] init];
		 [objPaynowParser parseXMLFileAtData:d2 parseError:&parseError];	
		 [objPaynowParser release];
		
		[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
		[target performSelector:successHandler withObject:nil withObject:nil];
		
	}
	if ([whichAPI isEqualToString:@"GetState"]) 
	{
		
		NSError *parseError = nil;
		StateParser *objStateParserr= [[StateParser alloc] init];
		[objStateParserr parseXMLFileAtData:d2 parseError:&parseError];	
		[objStateParserr release];
		
		[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
		[target performSelector:successHandler withObject:nil withObject:nil];
		
	}
	
	if ([whichAPI isEqualToString:@"GetCountry"]) 
	{
		
        NSError *parseError = nil;
		CountryParser *objCountryParser= [[CountryParser alloc] init];
		[objCountryParser parseXMLFileAtData:d2 parseError:&parseError];	
		[objCountryParser release];
		
		[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
		[target performSelector:successHandler withObject:nil withObject:nil];
		
	}
	if ([whichAPI isEqualToString:@"ClaimsToPaySubmit"]) 
	{
		
       
		NSError *parseError = nil;
		PaynowcontinueParser *objPaynowcontinueParser= [[PaynowcontinueParser alloc] init];
		[objPaynowcontinueParser parseXMLFileAtData:d2 parseError:&parseError];	
		[objPaynowcontinueParser release];
		
		[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
		[target performSelector:successHandler withObject:nil withObject:nil];
		
	}
	if ([whichAPI isEqualToString:@"UploadImage"]) 
	{
		
		
		NSError *parseError = nil;
		errorParser *myerrorParser = [[errorParser alloc] init];
		[myerrorParser parseXMLFileAtData:d2 parseError:&parseError];	
		[myerrorParser release];
		
		[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
		[target performSelector:successHandler];
		
	}
}
	
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Sorry" message:[error localizedDescription] delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
	[alert show];
	[alert release];
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
	[target performSelector:failureHandler];
	
	
}

@end
