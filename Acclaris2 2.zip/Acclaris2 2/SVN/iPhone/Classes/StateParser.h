//
//  StateParser.h
//  Acclaris
//
//  Created by Subhojit on 26/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "StateOBJ.h"


@interface StateParser : NSObject<NSXMLParserDelegate> {

	StateOBJ *objstate;
	NSMutableString *contentOfString;
}
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error;
+(NSMutableArray *)getarrState;
@end
