//
//  PaynowParser.m
//  Acclaris
//
//  Created by Subhojit on 22/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "PaynowParser.h"
NSMutableArray *arrpaynowdetail;
NSMutableArray *arrpaynowAccountdetail;


@implementation PaynowParser
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error
{
	
	NSXMLParser *parser;
	parser = [[NSXMLParser alloc] initWithData:data];
    [parser setDelegate:self];
	[parser setShouldProcessNamespaces:NO];
    [parser setShouldReportNamespacePrefixes:NO];
    [parser setShouldResolveExternalEntities:NO];
    [parser parse];
    NSError *parseError = [parser parserError];
    if (parseError && error) 
	{
        *error = parseError;
    }
	[parser release];
}

-(void)parserDidStartDocument:(NSXMLParser *)parser
{
	arrpaynowdetail=[[NSMutableArray alloc]init];
	arrpaynowAccountdetail=[[NSMutableArray alloc]init];
	
	//objpaynow=[[PaynowOBJ alloc]init];	
	
	
}		

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
	if (qName)
	{
		elementName = qName;
	}
	
	
	else 
		if([elementName isEqualToString:@"GetClaimsToPayDetails"])
		{
			objpaynow=[[PaynowOBJ alloc]init];	
			objpaynow.arr=[[NSMutableArray alloc]init];
		}
	else 
		if([elementName isEqualToString:@"returnCode"])
		{
			contentOfString=[NSMutableString string];
			[contentOfString retain];
			return;		
			
		}
		else 
			if([elementName isEqualToString:@"errorText"])
			{
				contentOfString=[NSMutableString string];
				[contentOfString retain];
				return;		
				
			}
			else 
				if([elementName isEqualToString:@"id"])
				{
					contentOfString=[NSMutableString string];
					[contentOfString retain];
					return;		
					
				}
				else 
					if([elementName isEqualToString:@"eeID"])
					{
						contentOfString=[NSMutableString string];
						[contentOfString retain];
						return;		
						
					}
					else 
						if([elementName isEqualToString:@"ClaimCategory"])
						{
							contentOfString=[NSMutableString string];
							[contentOfString retain];
							return;		
							
						}
						else 
							if([elementName isEqualToString:@"ClaimType"])
							{
								contentOfString=[NSMutableString string];
								[contentOfString retain];
								return;		
								
							}
							else 
								if([elementName isEqualToString:@"ClaimAmt"])
								{
									contentOfString=[NSMutableString string];
									[contentOfString retain];
									return;		
									
								}
								else 
									if([elementName isEqualToString:@"serviceBegins"])
									{
										contentOfString=[NSMutableString string];
										[contentOfString retain];
										return;		
										
									}
									else 
										if([elementName isEqualToString:@"serviceEnds"])
										{
											contentOfString=[NSMutableString string];
											[contentOfString retain];
											return;		
											
										}
										else 
											if([elementName isEqualToString:@"providerID"])
											{
												contentOfString=[NSMutableString string];
												[contentOfString retain];
												return;		
												
											}
											else 
												if([elementName isEqualToString:@"providerName"])
												{
													contentOfString=[NSMutableString string];
													[contentOfString retain];
													return;		
													
												}
												else 
													if([elementName isEqualToString:@"externalCode"])
													{
														contentOfString=[NSMutableString string];
														[contentOfString retain];
														return;		
														
													}
													else 
														if([elementName isEqualToString:@"externalID"])
														{
															contentOfString=[NSMutableString string];
															[contentOfString retain];
															return;		
															
														}
														else 
															if([elementName isEqualToString:@"account"])
															{
																objpaynowAcc=[[PaynowAccountOBJ alloc]init];
																//objpaynow.arr=[[NSMutableArray alloc]init];
															}
															else 
																if([elementName isEqualToString:@"accountTypeCD"])
																{
																	contentOfString=[NSMutableString string];
																	[contentOfString retain];
																	return;		
																	
																}
																else 
																	if([elementName isEqualToString:@"accountTypeDesc"])
																	{
																		contentOfString=[NSMutableString string];
																		[contentOfString retain];
																		return;		
																		
																	}
																	else 
																		if([elementName isEqualToString:@"elctID"])
																		{
																			contentOfString=[NSMutableString string];
																			[contentOfString retain];
																			return;		
																			
																		}
																		else 
																			if([elementName isEqualToString:@"accountNO"])
																			{
																				contentOfString=[NSMutableString string];
																				[contentOfString retain];
																				return;		
																				
																			}
																			else 
																				if([elementName isEqualToString:@"purseType"])
																				{
																					contentOfString=[NSMutableString string];
																					[contentOfString retain];
																					return;		
																					
																				}
																				else 
																					if([elementName isEqualToString:@"labelAssociatedValue"])
																					{
																						contentOfString=[NSMutableString string];
																						[contentOfString retain];
																						return;		
																						
																					}
	
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName     
{	
	if (qName)
	{
        elementName = qName;
		
    }
	
	else 
		if([elementName isEqualToString:@"GetClaimsToPayDetails"])
       {
		   
			if(objpaynow)
			{
				
				[arrpaynowdetail addObject:objpaynow];
				[objpaynow release],objpaynow=nil;
			}
			
		}
	else 
		if([elementName isEqualToString:@"returnCode"])
		{
			
			
			if(contentOfString)
			{
				objpaynow.strreturnCode=contentOfString;
				[contentOfString release];
				contentOfString = nil;
				
				
			}		
		}
		else 
			if([elementName isEqualToString:@"errorText"])
			{
				if(contentOfString)
				{
					objpaynow.strerrorText=contentOfString;
					[contentOfString release];
					contentOfString = nil;
					
					
				}			
				
			}
			else 
				if([elementName isEqualToString:@"id"])
				{
					if(contentOfString)
					{
						objpaynow.strid=contentOfString;
						[contentOfString release];
						contentOfString = nil;
						
						
					}
					
				}
				else 
					if([elementName isEqualToString:@"eeID"])
					{
						
						if(contentOfString)
						{
							objpaynow.streeID=contentOfString;
							[contentOfString release];
							contentOfString = nil;
							
							
						}		
						
					}
					else 
						if([elementName isEqualToString:@"ClaimCategory"])
						{
							if(contentOfString)
							{
								objpaynow.strClaimCategory=contentOfString;
								[contentOfString release];
								contentOfString = nil;
								
								
							}	
							
						}
						else 
							if([elementName isEqualToString:@"ClaimType"])
							{
								if(contentOfString)
								{
									objpaynow.strClaimType=contentOfString;
									[contentOfString release];
									contentOfString = nil;
									
									
								}			
								
							}
							else 
								if([elementName isEqualToString:@"ClaimAmt"])
								{if(contentOfString)
								{
									objpaynow.strClaimAmt=contentOfString;
									[contentOfString release];
									contentOfString = nil;
									
									
								}		
									
								}
								else 
									if([elementName isEqualToString:@"serviceBegins"])
									{
										if(contentOfString)
										{
											objpaynow.strserviceBegins=contentOfString;
											[contentOfString release];
											contentOfString = nil;
											
											
										}		
										
									}
									else 
										if([elementName isEqualToString:@"serviceEnds"])
										{
											if(contentOfString)
											{
												objpaynow.strserviceEnds=contentOfString;
												[contentOfString release];
												contentOfString = nil;
												
												
											}		
											
										}
										else 
											if([elementName isEqualToString:@"providerID"])
											{
												if(contentOfString)
												{
													objpaynow.strproviderID=contentOfString;
													[contentOfString release];
													contentOfString = nil;
													
													
												}		
												
											}
											else 
												if([elementName isEqualToString:@"providerName"])
												{
													if(contentOfString)
													{
														objpaynow.strproviderName=contentOfString;
														[contentOfString release];
														contentOfString = nil;
														
														
													}		
													
												}
												else 
													if([elementName isEqualToString:@"externalCode"])
													{
														if(contentOfString)
														{
															objpaynow.strexternalCode=contentOfString;
															[contentOfString release];
															contentOfString = nil;
															
															
														}		
														
													}
													else 
														if([elementName isEqualToString:@"externalID"])
														{
															if(contentOfString)
															{
																objpaynow.strexternalID=contentOfString;
																[contentOfString release];
																contentOfString = nil;
																
																
															}		
															
														}
														else 
															if([elementName isEqualToString:@"account"])
															{
																if(objpaynowAcc)
																{
																	
																   [objpaynow.arr addObject:objpaynowAcc];
																
																	[objpaynowAcc release],objpaynowAcc=nil;
																}
															}
															else 
																if([elementName isEqualToString:@"accountTypeCD"])
																{
																	if(contentOfString)
																	{
																		objpaynowAcc.straccountTypeCD=contentOfString;
																		[contentOfString release];
																		contentOfString = nil;
																		
																		
																	}		
																	
																	
																}
																else 
																	if([elementName isEqualToString:@"accountTypeDesc"])
																	{
																		if(contentOfString)
																		{
																			objpaynowAcc.straccountTypeDesc=contentOfString;
																			[contentOfString release];
																			contentOfString = nil;
																			
																			
																		}			
																		
																	}
																	else 
																		if([elementName isEqualToString:@"elctID"])
																		{
																			if(contentOfString)
																			{
																				objpaynowAcc.strelctID=contentOfString;
																				[contentOfString release];
																				contentOfString = nil;
																				
																				
																			}			
																			
																		}
																		else 
																			if([elementName isEqualToString:@"accountNO"])
																			{
																				if(contentOfString)
																				{
																					objpaynowAcc.straccountNO=contentOfString;
																					[contentOfString release];
																					contentOfString = nil;
																					
																					
																				}	
																			}
																			else 
																				if([elementName isEqualToString:@"purseType"])
																				{
																					if(contentOfString)
																					{
																						objpaynowAcc.strpurseType=contentOfString;
																						[contentOfString release];
																						contentOfString = nil;
																						
																						
																					}			
																					
																				}
																				else 
																					if([elementName isEqualToString:@"labelAssociatedValue"])
																					{
																						if(contentOfString)
																						{
																							objpaynowAcc.strlabelAssociatedValue=contentOfString;
																							[contentOfString release];
																							contentOfString = nil;
																							
																							
																						}		
																						
																					}

}
	
- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
	if(contentOfString)
		[contentOfString appendString:string];
}

- (void)parserDidEndDocument:(NSXMLParser *)parse
{
	
	//NSLog(@"arrpaynowAccountdetail  %@",arrpaynowAccountdetail);
	NSLog(@"arrpaynowdetail %@",arrpaynowdetail);
	PaynowOBJ *mypaynow=(PaynowOBJ *)[arrpaynowdetail objectAtIndex:0];
	NSLog(@"%@",mypaynow.strreturnCode);
	
	
}
/*+(NSMutableArray *)getarrpaynowAccountdetail
{
	
	//return arrpaynowAccountdetail;
}*/
+(NSMutableArray *)getarrpaynowdetail
{
	
	return arrpaynowdetail;
}

@end
