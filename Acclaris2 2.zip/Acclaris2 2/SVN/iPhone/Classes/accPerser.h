//
//  accPerser.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 06/10/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>


@class AccountsOBJ;
@class electionOBJ;
@class errorcodeOBJ;
@interface accPerser : NSObject<NSXMLParserDelegate> {
	
	
	NSMutableString *contentOfString;
	
	
	AccountsOBJ *myAccountsOBJ;
	electionOBJ *myelectionOBJ;
	
	errorcodeOBJ *myerrorcodeOBJ;
	
	
	
}
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error;
+(NSMutableArray *)getAccounts_arr;
+(NSMutableArray *)geterror_arr;

@end
