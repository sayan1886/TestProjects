//
//  AcclarisAppDelegate.m
//  Acclaris
//
//  Created by Subhojit on 29/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "AcclarisAppDelegate.h"
#import "AcclarisViewController.h"
#import "AccountDetails.h"
#import "claim.h"
#import "ticket.h"
#import "images.h"
#import "alerts.h"
#import "Unit_test.h"
//12/01/2010 00:15:00

@implementation AcclarisAppDelegate
@synthesize checkclassname;
@synthesize window;
@synthesize viewController;
@synthesize tabBarController;


//@synthesize arr_accInfo,arr_transaction;
//@synthesize incorrectSiteIDText,forgotPasswordText;
//@synthesize logoIMG;
NetworkStatus    remoteHostStatus;
#pragma mark -
#pragma mark Application lifecycle

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {    
    
    // Override point for customization after application launch.
	
    // Add the view controller's view to the window and display.
	// [self setupNetworkCheck];
	//====================================================================================
	//To run Test program///
	
	//[self testing];
	
	//To run build program///
	//---Initializing a Navigation Controller---
	[self createNavigation];
	//====================================================================================
	
    [window makeKeyAndVisible];
    [self setupNetworkCheck];
    return YES;
}
-(void)testing
{
	Unit_test *unit=[[Unit_test alloc]init];
	[window addSubview:unit.view];
}
-(void)createNavigation
{
	
	UINavigationController *navOne=[[UINavigationController alloc]init];
	[navOne initWithRootViewController:viewController];
	navOne.navigationBar.tintColor = [UIColor colorWithRed:39.0/255.0f green:39.0/255.0f blue:39.0/255.0f alpha:1.0];
	[window addSubview:navOne.view];
}
-(void)removeTabBar
{
	[tabBarController.view removeFromSuperview];
	[self createNavigation];
}

-(void)createTabBar
{
	NSMutableArray *localControllerArray=[[NSMutableArray alloc] init];
	tabBarController=[[UITabBarController alloc] init];
	
	
	NSMutableDictionary *roleDict=[passPerser getRolebaseDict];
	
	
	if ([[roleDict objectForKey:@"ACCOUNT"] isEqualToString:@"Yes"]) {
	
	AccountDetails *myAcdetails=[[AccountDetails alloc] initWithTabBar:[roleDict objectForKey:@"ACCOUNTLabel"]];
	MyNavigationController=[[UINavigationController alloc] initWithRootViewController:myAcdetails];
	MyNavigationController.navigationBar.barStyle=UIBarStyleBlackTranslucent;
	//localNavigationController.navigationBar.tintColor=[UIColor colorWithRed:219.0/255 green:112.0/255 blue:58.0/255 alpha:1.0] ;
	[localControllerArray addObject:MyNavigationController];
	//MyNavigationController.navigationBar.tintColor=[UIColor colorWithRed:0.0/255 green:98.0/255 blue:166.0/255 alpha:1.0]   ;
	[MyNavigationController release];
	[myAcdetails release];
	
	}
	
	if ([[roleDict objectForKey:@"CLAIM"] isEqualToString:@"Yes"]) {

	claim *myclm=[[claim alloc] initWithTabBar:[roleDict objectForKey:@"CLAIMLabel"]];
	MyNavigationController=[[UINavigationController alloc] initWithRootViewController:myclm];
	MyNavigationController.navigationBar.barStyle=UIBarStyleBlackTranslucent;
	//localNavigationController.navigationBar.tintColor=[UIColor colorWithRed:219.0/255 green:112.0/255 blue:58.0/255 alpha:1.0] ;
	[localControllerArray addObject:MyNavigationController];
	//MyNavigationController.navigationBar.tintColor=[UIColor colorWithRed:0.0/255 green:98.0/255 blue:166.0/255 alpha:1.0] ;
	[MyNavigationController release];
	[myclm release];
	}
	
	if ([[roleDict objectForKey:@"MESSAGE"] isEqualToString:@"Yes"]) {

	ticket *myticket=[[ticket alloc] initWithTabBar:[roleDict objectForKey:@"MESSAGELabel"]];
	MyNavigationController=[[UINavigationController alloc] initWithRootViewController:myticket];
	MyNavigationController.navigationBar.barStyle=UIBarStyleBlackTranslucent;
	//localNavigationController.navigationBar.tintColor=[UIColor colorWithRed:219.0/255 green:112.0/255 blue:58.0/255 alpha:1.0] ;
	[localControllerArray addObject:MyNavigationController];
	//MyNavigationController.navigationBar.tintColor=[UIColor colorWithRed:0.0/255 green:98.0/255 blue:166.0/255 alpha:1.0]  ;
	[MyNavigationController release];
	[myticket release];
	
	}
	
	
	if ([[roleDict objectForKey:@"RECEIPT"] isEqualToString:@"Yes"]) {

	images *myimages=[[images alloc] initWithTabBar:[roleDict objectForKey:@"RECEIPTLabel"]];
	MyNavigationController=[[UINavigationController alloc] initWithRootViewController:myimages];
	MyNavigationController.navigationBar.barStyle=UIBarStyleBlackTranslucent;
	//localNavigationController.navigationBar.tintColor=[UIColor colorWithRed:219.0/255 green:112.0/255 blue:58.0/255 alpha:1.0] ;
	[localControllerArray addObject:MyNavigationController];
	//MyNavigationController.navigationBar.tintColor=[UIColor colorWithRed:0.0/255 green:98.0/255 blue:166.0/255 alpha:1.0]  ;
	[MyNavigationController release];
	[myimages release];
	
	}
	
	if ([[roleDict objectForKey:@"ALERT"] isEqualToString:@"Yes"]) {
		
	alerts *myalerts=[[alerts alloc] initWithTabBar:[roleDict objectForKey:@"ALERTLabel"]];
	MyNavigationController=[[UINavigationController alloc] initWithRootViewController:myalerts];
	MyNavigationController.navigationBar.barStyle=UIBarStyleBlackTranslucent;
	//localNavigationController.navigationBar.tintColor=[UIColor colorWithRed:219.0/255 green:112.0/255 blue:58.0/255 alpha:1.0] ;
	[localControllerArray addObject:MyNavigationController];
	//MyNavigationController.navigationBar.tintColor=[UIColor colorWithRed:0.0/255 green:98.0/255 blue:166.0/255 alpha:1.0]  ;
	[MyNavigationController release];
	[myalerts release];
	}
	
	tabBarController.viewControllers=localControllerArray;
	tabBarController.delegate=self;
	
	[localControllerArray release];
	
	
    // Override point for customization after app launch    
    [window addSubview:tabBarController.view];
    [window makeKeyAndVisible];
	
}
- (BOOL)tabBarController:(UITabBarController *)tabBarController shouldSelectViewController:(UIViewController *)viewController1
{
	return YES;
}
- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UINavigationController *)viewController1
{
	
	
	[viewController1.visibleViewController.navigationController popToRootViewControllerAnimated:NO];
}


- (void)applicationWillResignActive:(UIApplication *)application {
    /*
     Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
     Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
     */
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    /*
     Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
     If your application supports background execution, called instead of applicationWillTerminate: when the user quits.
     */
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    /*
     Called as part of  transition from the background to the inactive state: here you can undo many of the changes made on entering the background.
     */
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    /*
     Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
     */
}


- (void)applicationWillTerminate:(UIApplication *)application {
    /*
     Called when the application is about to terminate.
     See also applicationDidEnterBackground:.
     */
}


#pragma mark -
#pragma mark Memory management

- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application {
    /*
     Free up as much memory as possible by purging cached data objects that can be recreated (or reloaded from disk) later.
     */
}

-(void)push
{
	
	[viewController pusttoPassscreen];
	[viewController release];
}
- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}
#pragma mark reachibility 

-(void)setupNetworkCheck
{
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reachabilityChanged:) name:@"kNetworkReachabilityChangedNotification" object:nil];
	[[Reachability sharedReachability] setHostName:@"www.google.com"];
	[AcclarisAppDelegate updateStatus];
}

-(void)reachabilityChanged:(NSNotification*)notification
{        
	[AcclarisAppDelegate updateStatus];        
}

+(void)updateStatus
{
	remoteHostStatus   = [[Reachability sharedReachability] remoteHostStatus];
}
+(BOOL)isNetworkAvailable
{
	[AcclarisAppDelegate updateStatus];
	if(remoteHostStatus == NotReachable)
		return NO;
	else 
		return YES;
}


@end
