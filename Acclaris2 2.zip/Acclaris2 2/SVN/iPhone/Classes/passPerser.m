//
//  passPerser.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 25/10/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import "passPerser.h"
NSMutableArray *arrm_passArray;
NSMutableArray *arrRoleBased;
NSMutableDictionary *rolebaseDict;

@implementation passPerser
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error
{
	arrm_passArray = [[NSMutableArray alloc]init];
	NSXMLParser *parser;
	parser = [[NSXMLParser alloc] initWithData:data];
    [parser setDelegate:self];
	[parser setShouldProcessNamespaces:NO];
    [parser setShouldReportNamespacePrefixes:NO];
    [parser setShouldResolveExternalEntities:NO];
    [parser parse];
    NSError *parseError = [parser parserError];
    if (parseError && error) 
	{
        *error = parseError;
    }
	[parser release];
}

-(void)parserDidStartDocument:(NSXMLParser *)parser
{
	
	arrRoleBased=[[NSMutableArray alloc]init];
	count=0;
}		

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
	if (qName)
	{
		elementName = qName;
	}
	
	
	else 
		if([elementName isEqualToString:@"returnCode"])
		{
			contentOfString=[NSMutableString string];
			[contentOfString retain];
			return;		
			
		}
		else 
			if([elementName isEqualToString:@"errorText"])
			{
				contentOfString=[NSMutableString string];
				[contentOfString retain];
				return;		
				
			}
			else 
				if([elementName isEqualToString:@"userName"])
				{
					contentOfString=[NSMutableString string];
					[contentOfString retain];
					return;		
					
				}
				else 
					if([elementName isEqualToString:@"participantID"])
					{
						contentOfString=[NSMutableString string];
						[contentOfString retain];
						return;		
					
					}
					else 
						if([elementName isEqualToString:@"userID"])
						{
							contentOfString=[NSMutableString string];
							[contentOfString retain];
							return;		
										
						}
						else 
							if([elementName isEqualToString:@"tab"])
							{
								
									
							   objrole=[[RollBasecOBJ alloc]init];
								objrole.arrSubRole=[[NSMutableArray alloc]init];
							
								return;
								
							}
							else 
								if([elementName isEqualToString:@"subtab"])
								{
										
										objsubrole=[[RoleSubOBJ alloc]init];
										
										
									
									return;
									
								}
	
	
							else 
								if([elementName isEqualToString:@"name"])
								{
									
									contentOfString=[NSMutableString string];
									[contentOfString retain];
									return;
								}
								else 
									if([elementName isEqualToString:@"displaySeq"])
									{
										
										contentOfString=[NSMutableString string];
										[contentOfString retain];
										return;
									}
									else 
										if([elementName isEqualToString:@"label"])
										{
											
											contentOfString=[NSMutableString string];
											[contentOfString retain];
											return;
										}
										else 
											if([elementName isEqualToString:@"displayable"])
											{
												
												contentOfString=[NSMutableString string];
												[contentOfString retain];
												return;
											}
	else if([elementName isEqualToString:@"subTabList"])
	{
		count++;
		
		
		return;
	}
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName     
{	
	if (qName)
	{
        elementName = qName;
		
    }
	
	else 
		if([elementName isEqualToString:@"returnCode"])
		{
			if(contentOfString)
			{
				[arrm_passArray addObject:contentOfString];
				[contentOfString release];
				contentOfString = nil;
				
				
			}	
			
		}
		else 
			if([elementName isEqualToString:@"errorText"])
			{
				if(contentOfString)
				{
					[arrm_passArray addObject:contentOfString];
					[contentOfString release];
					contentOfString = nil;
					
					
				}		
				
			}
			else 
				if([elementName isEqualToString:@"userName"])
				{
					if(contentOfString)
					{
						NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
						if ([tempArr count]>1) {
							[arrm_passArray addObject:[tempArr objectAtIndex:1]];
						}
						
						[contentOfString release];
						contentOfString = nil;
						
						
					}		
					
				}
				else 
					if([elementName isEqualToString:@"participantID"])
					{
						if(contentOfString)
						{
							NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
							if ([tempArr count]>1)
							{
								[arrm_passArray addObject:[tempArr objectAtIndex:1]];
							}							
							[contentOfString release];
							contentOfString = nil;
																				
						}	
										
					}
					else 
						if([elementName isEqualToString:@"userID"])
						{
							if(contentOfString)
							{
								NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
								if ([tempArr count]>1) {
									[arrm_passArray addObject:[tempArr objectAtIndex:1]];
								}								
								[contentOfString release];
								contentOfString = nil;
												
												
							}	
											  
						}
						else 
							if([elementName isEqualToString:@"tab"])
							{
								
							
							
									[arrRoleBased addObject:objrole];
							

							
								
							}
							else 
								if([elementName isEqualToString:@"subtab"])
								{
									
										
										[objrole.arrSubRole addObject:objsubrole];
								
									
									
								}
							else 
								if([elementName isEqualToString:@"name"])
								{
									
									if(contentOfString)
									{
										if(count>0)
										{
										
											objsubrole.strsubName=contentOfString;
											
										}
										else 
										{
											 objrole.strName=contentOfString;
										}

										  
									    [contentOfString release];
									    contentOfString = nil;
									}

									
								}
								else 
									if([elementName isEqualToString:@"displaySeq"])
									{
										
										if(contentOfString)
										{
											if(count>0)
											{
												objsubrole.strsubDisplayseq=contentOfString;

											}
											else 
											{
												objrole.strDisplayseq=contentOfString;
											}

											
											[contentOfString release];
											contentOfString = nil;
										}
										
										
									}
									else 
										if([elementName isEqualToString:@"label"])
										{
											
											if(contentOfString)
											{
												if(count>0)
												{
												
													objsubrole.strsublabel=contentOfString;
												}
												else {
													objrole.strlabel=contentOfString;
												}

												
												[contentOfString release];
												contentOfString = nil;
											}
											
											
										}
	
										else 
											if([elementName isEqualToString:@"displayable"])
											{
												
												if(contentOfString)
												{
													if(count>0)
													{
														
														objsubrole.displayable=contentOfString;
													}
													else {
														objrole.displayable=contentOfString;
													}
													
													
													[contentOfString release];
													contentOfString = nil;
												}
												
												
											}
	
	else if([elementName isEqualToString:@"subTabList"])
	{
		
		count--;
		
				
	}
	
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
	if(contentOfString)
		[contentOfString appendString:string];
}

- (void)parserDidEndDocument:(NSXMLParser *)parse

{
	
	rolebaseDict=[[NSMutableDictionary alloc]init];
	
	NSLog(@"**********%@",arrm_passArray);
	
	
	for(int i=0;i<[arrRoleBased count];i++)
		
	{
		
		RollBasecOBJ*  myrole=(RollBasecOBJ*)[arrRoleBased objectAtIndex:i];
		
		NSLog(@">>>>>>%@",myrole.strName);
		
		NSLog(@">>>>>>%@",myrole.strlabel);
		
		NSLog(@">>>>>>%@",myrole.displayable);
		
		
		[rolebaseDict setValue:myrole.displayable forKey:myrole.strName];
		[rolebaseDict setValue:myrole.strlabel forKey:[myrole.strName stringByAppendingString:@"Label"]];
		
		
		
		for(int j=0;j<[myrole.arrSubRole count];j++)
			
		{
			
			RoleSubOBJ*  myrole1=(RoleSubOBJ*)[myrole.arrSubRole objectAtIndex:j];
			
			NSLog(@"_________________");
			
			NSLog(@">>>>>>...........%@",myrole1.strsubName);
			
			NSLog(@">>>>>>............%@",myrole1.strsublabel);
			
			NSLog(@">>>>>>............%@",myrole1.displayable);
			
			
			[rolebaseDict setValue:myrole1.displayable forKey:myrole1.strsubName];
			[rolebaseDict setValue:myrole1.strsublabel forKey:[myrole1.strsubName stringByAppendingString:@"Label"]];
			
			
			
			
			
		}
		
		
		NSLog(@"_________________");
		
		NSLog(@"_________________");
		
		
		
		
		
	}
	
	
	NSLog(@"Final Dict %@",rolebaseDict);
	
	
}
+(NSMutableArray *)passresponce
{
	if (arrm_passArray) {
		
		return arrm_passArray;
	}
	else {
		return nil;
	}
	
}
+(NSMutableDictionary *)getRolebaseDict
{
	if (rolebaseDict) {
		return rolebaseDict;
		
	}
	else {
		return nil;
	}

}
@end
