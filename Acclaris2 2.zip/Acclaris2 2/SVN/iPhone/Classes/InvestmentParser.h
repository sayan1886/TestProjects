//
//  InvestmentParser.h
//  Acclaris
//
//  Created by Sumit Kr Prasad on 31/12/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AcclarisAppDelegate.h"
//#import "transactionOBJ.h"
#import "InvestmentObj.h"
#import "errorcodeOBJ.h"

@interface InvestmentParser : NSObject <NSXMLParserDelegate>
{
	AcclarisAppDelegate *app;
	NSMutableArray *arrLocal;
	//transactionOBJ *mytransactionOBJ;
	InvestmentObj *myInvestmentObj;
	NSMutableString *contentOfString;
	errorcodeOBJ *myerrorcodeOBJ;
	
}
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error;
+(NSMutableArray *)get_arr_investment;
+(NSMutableArray *)geterror_arr;
+(BOOL)gethasMoreRecords_investment;
@end
