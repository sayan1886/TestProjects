//
//  transactionOBJ.h
//  Acclaris
//
//  Created by Sayan banerjee on 21/11/10.
//  Copyright 2010 Objectsol. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface transactionOBJ : NSObject {

	NSString *transactionDate,*lbltransactionDate;
	NSString *transactionAmount,*lbltransactionAmount;
	NSString *transactionType,*lbltransactionType;
	NSString *transactionCode,*lbltransactionCode;
	NSString *transactionDescription,*lbltransactionDescription;
	NSString *From,*lblFrom;
	NSString *serviceDate,*lblserviceDate;
	NSString *account,*lblaccount;
	NSString *category,*lblcategory;
	NSString *status,*lblstatus;
	NSString *note,*lblnote;
	NSString *effectiveDate,*lbleffectiveDate;
	NSString *dpstType,*lbldpstType;
	
	
}
@property(nonatomic,retain)NSString *transactionDate,*lbltransactionDate;
@property(nonatomic,retain)NSString *transactionAmount,*lbltransactionAmount;
@property(nonatomic,retain)NSString *transactionType,*lbltransactionType;
@property(nonatomic,retain)NSString *transactionCode,*lbltransactionCode;
@property(nonatomic,retain)NSString *transactionDescription,*lbltransactionDescription;
@property(nonatomic,retain)NSString *From,*lblFrom;
@property(nonatomic,retain)NSString *serviceDate,*lblserviceDate;
@property(nonatomic,retain)NSString *account,*lblaccount;
@property(nonatomic,retain)NSString *category,*lblcategory;
@property(nonatomic,retain)NSString *status,*lblstatus;
@property(nonatomic,retain)NSString *note,*lblnote;
@property(nonatomic,retain)NSString *effectiveDate,*lbleffectiveDate;
@property(nonatomic,retain)NSString *dpstType,*lbldpstType;


@end
