//
//  ActiveScheduleOBJ.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 08/04/11.
//  Copyright 2011 ObjectSol Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface ActiveScheduleOBJ : NSObject {

	NSString *srtID,*transferSchedule,*transferAmount,*initTransferDate,*lastTransferDate,*endDate,*inactiveDate;
	NSString *actHolderName,*actType,*actNumber,*bankRoutingNumber,*priorPlan,*electionId,*lastStatus;
	
	
	NSString *lbl_srtID,*lbl_transferSchedule,*lbl_transferAmount,*lbl_initTransferDate,*lbl_lastTransferDate,*lbl_endDate,*lbl_inactiveDate;
	NSString *lbl_actHolderName,*lbl_actType,*lbl_actNumber,*lbl_bankRoutingNumber,*lbl_priorPlan,*lbl_electionId,*lbl_lastStatus;
}
@property (nonatomic,retain)NSString *srtID,*transferSchedule,*transferAmount,*initTransferDate,*lastTransferDate,*endDate,*inactiveDate;
@property (nonatomic,retain)NSString *actHolderName,*actType,*actNumber,*bankRoutingNumber,*priorPlan,*electionId,*lastStatus;

@property (nonatomic,retain)NSString *lbl_srtID,*lbl_transferSchedule,*lbl_transferAmount,*lbl_initTransferDate,*lbl_lastTransferDate,*lbl_endDate,*lbl_inactiveDate;
@property (nonatomic,retain)NSString *lbl_actHolderName,*lbl_actType,*lbl_actNumber,*lbl_bankRoutingNumber,*lbl_priorPlan,*lbl_electionId,*lbl_lastStatus;
@end
