    //
//  AccountDetails.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 06/10/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import "AccountDetails.h"
#import "request.h"
#import "passPerser.h"
#import "trancastionpage.h"
#import "AccountsOBJ.h"
#import "accPerser.h"
#import "UAView.h"
#import "configurables.h"
#import "configurableParser.h"
#import "UserresponcePerser.h"
#import "Decode64.h"
#import "electionOBJ.h"
#import "AcclarisViewController.h"
#import "Contribution.h"

NSString *electionid;
NSString *accounttype;
@implementation AccountDetails


+(NSString *)electionID
{
	if (electionid) {
		return electionid;
	}
	else {
		return nil;
	}
	
}
+(NSString *)acType
{
	if (accounttype) {
		return accounttype;
	}
	else {
		return nil;
	}
	
}

-(id)initWithTabBar:(NSString *)label
{
	if([self init])
	{
		//this is the label on tab button itself
		self.title=label;
		
		self.tabBarItem.image=[UIImage imageNamed:@"Accounts.png"];
		
	}
	return self;
}
-(void)viewWillAppear:(BOOL)animated
{
	
}


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	tools=[[MyTools alloc]init];
	loadingView=[tools createActivityIndicator1];
	
	NSMutableArray *arr_myconfig=[AcclarisViewController staticarr_config];//[configurableParser getconfig_arr];//
	con=(configurables *)[arr_myconfig objectAtIndex:0];
	
	self.navigationController.navigationBar.tintColor=[UIColor colorWithRed:con.navbarRed/255.0f green:con.navbarGreen/255.0f blue:con.navbarBlue/255.0f alpha:1.0];
	self.view.backgroundColor = [UIColor colorWithRed:con.bgRed/255.0f green:con.bgGreen/255.0f blue:con.bgBlue/255.0f alpha:1.0];
	self.navigationItem.title=@"Back";
	
	//NSMutableArray *my_arrUserinfo=[UserresponcePerser userdesc];
	arr_acc=[accPerser getAccounts_arr];
	[arr_acc retain];
	
	UIImageView *logo_img = [[UIImageView alloc]initWithFrame:CGRectMake(0, 2, 170, 40)];
	//NSData *data=[Base64 decode:[my_arrUserinfo objectAtIndex:3]];
	NSData *data=[Base64 decode:con.logoImgdata];
	logo_img.image=	[UIImage imageWithData:[NSData dataWithData:data]];
	self.navigationItem.titleView=logo_img;
	
	
	[self signoutbt];
	
	if ([arr_acc count]==0) 
	{
		/////////adding rounded rect view///////////////////
		UIView	*view_rounded = [[UIView alloc]initWithFrame:CGRectMake(18, 14, 280, 340)];
		view_rounded.backgroundColor = [UIColor whiteColor];
		view_rounded.layer.cornerRadius=19;
		view_rounded.layer.borderWidth=1.5;
		//view_rounded.backgroundColor=[UIColor whiteColor];//[UIColor colorWithRed:con.bgRed2/255.0f green:con.bgGreen2/255.0f blue:con.bgBlue2/255.0f alpha:1.0];
		CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();	
		float grayComponents[4] = { 0.3, 0.3, 0.3, 1.0 };
		view_rounded.layer.borderColor=CGColorCreate(colorSpace, grayComponents);
		[self.view addSubview:view_rounded];
		[view_rounded release];
		
		NSDictionary *customMessageList_dict=[[NSUserDefaults standardUserDefaults] objectForKey:@"customMessageList"];

		NSString *strmessage=[[customMessageList_dict valueForKey:@"200003"]valueForKey:@"message"];
		
		
		UILabel *lblNoData=[[UILabel alloc] initWithFrame:CGRectMake(0, 20, 280, 30)];
		lblNoData.text=strmessage;
		lblNoData.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
		lblNoData.font=[UIFont fontWithName:con.fontname size:con.fontsize];
		lblNoData.textAlignment=UITextAlignmentCenter;
		lblNoData.backgroundColor=[UIColor clearColor];
		[view_rounded addSubview:lblNoData];
		[lblNoData release];
		/*UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Sorry" message:@"“Currently no data available, please visit again later”" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
		[alert show];
		[alert release];*/
		return ;
		
		
	}
		
	
	[self createtableview];
	
	
}

-(void)signoutbt
{
	
	
	UIBarButtonItem *signoutButton = [[UIBarButtonItem alloc]
									  initWithTitle:@"Sign Off"
									  style:UIBarButtonItemStyleBordered
									  target:self
									  action:@selector(signout)];
    self.navigationItem.rightBarButtonItem =signoutButton;
}
-(void)signout
{
	[((AcclarisAppDelegate *)[[UIApplication sharedApplication] delegate]) removeTabBar];
}

-(void)createtableview
{
	UITableView	*acctable=[[UITableView alloc] initWithFrame:CGRectMake(0,0,320,390) style:UITableViewStylePlain];
	acctable.delegate = self;
	acctable.dataSource = self;
	acctable.scrollEnabled = YES;
	acctable.autoresizesSubviews = YES;
	acctable.showsVerticalScrollIndicator=YES;
	acctable.showsHorizontalScrollIndicator=YES;
	acctable.backgroundColor=[UIColor clearColor];
	acctable.separatorColor=[UIColor clearColor];
	
	[self.view addSubview:acctable];	
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView  
{
	return [arr_acc count];
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	AccountsOBJ *myAccountsOBJ=(AccountsOBJ *)[arr_acc objectAtIndex:section];
	NSInteger norow=[myAccountsOBJ.electionListCount intValue];
	
		
	if ([myAccountsOBJ.accountShortName isEqualToString:@"HSA"])
	{
		electionOBJ *myelectionOBJ2=(electionOBJ *)[myAccountsOBJ.elections objectAtIndex:0];
		if ([myelectionOBJ2.enrollmentStatus isEqualToString:@"Pending"]||[myelectionOBJ2.enrollmentStatus isEqualToString:@"closed"]) {
			norow=0;
		}
		else if([myAccountsOBJ.manageContribLink isEqualToString:@"Yes"]){
			norow=norow*3;
		}
		else
		{
			norow=norow*2;
		}
	}
	
	return norow;
	
	
		
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
	AccountsOBJ *myAccountsOBJ1=(AccountsOBJ *)[arr_acc objectAtIndex:section];
	NSString *strHeader=myAccountsOBJ1.accountDisplayName ;
	
	NSString *Headerfont=@"";
	Headerfont=[Headerfont stringByAppendingString:con.fontname];
	Headerfont=[Headerfont stringByAppendingString:@"-Bold"];
	
	
	CGSize sizeHeader=[strHeader sizeWithFont:[UIFont fontWithName:Headerfont size:con.headerfntsize]
							constrainedToSize:CGSizeMake(220, 100) 
								lineBreakMode:UILineBreakModeWordWrap];
	if(sizeHeader.width>170)
	{
		return 46.0;
	}
	else {
		return 30.0;     
	}

	
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section;
{
	UIView *secheader=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 320, 26)];
	secheader.backgroundColor=[UIColor colorWithRed:con.bgRed2/255.0 green:con.bgGreen2/255.0 blue:con.bgBlue2/255.0 alpha:1.0];
	
	UIView *borderview=[[UIView alloc]initWithFrame:CGRectMake(0,0,320,3)];
	borderview.backgroundColor=[UIColor whiteColor];
	[secheader addSubview:borderview ];
	
	NSString *Headerfont=@"";
	Headerfont=[Headerfont stringByAppendingString:con.fontname];
	Headerfont=[Headerfont stringByAppendingString:@"-Bold"];
	
	
	AccountsOBJ *myAccountsOBJ1=(AccountsOBJ *)[arr_acc objectAtIndex:section];
	//int x=[myAccountsOBJ1.accountDisplayName length];
	NSString *strHeader=myAccountsOBJ1.accountDisplayName;
	UILabel *headertitlelebel=[[UILabel alloc]initWithFrame:CGRectMake(9,4,230,25)];
	
	
	/*CGSize sizeHeader=[strHeader sizeWithFont:[UIFont fontWithName:Headerfont size:con.headerfntsize]
							constrainedToSize:CGSizeMake(220, 100) 
								lineBreakMode:UILineBreakModeWordWrap];
	if (sizeHeader.width>220) 
	{
		secheader.frame=CGRectMake(0, 0, 320, 46);
		headertitlelebel.frame=CGRectMake(9, 4, 220, 40);
		headertitlelebel.numberOfLines=2;
	}*/

	
	
	headertitlelebel.font=[UIFont fontWithName:Headerfont size:con.headerfntsize];
	headertitlelebel.backgroundColor=[UIColor clearColor];
	headertitlelebel.lineBreakMode=UILineBreakModeWordWrap;
	
	headertitlelebel.text = strHeader;
	
	headertitlelebel.textColor=[UIColor whiteColor];
	[secheader addSubview:headertitlelebel ];
	[headertitlelebel release];
	
	CGSize sizeHeader=[strHeader sizeWithFont:[UIFont fontWithName:Headerfont  size:con.headerfntsize]
							constrainedToSize:CGSizeMake(220, 100) 
								lineBreakMode:UILineBreakModeWordWrap];
	if(sizeHeader.width>170)
	{
		secheader.frame=CGRectMake(0, 0, 320, 44);
		headertitlelebel.frame=CGRectMake(9, 4, 220, 40);
		headertitlelebel.numberOfLines=2;
	}
	
	if ([myAccountsOBJ1.balanceRelevant isEqualToString:@"Yes"]) {//business logis to show balance lable in grid header  or not
		
	
	UILabel *headertitlelebelbl=[[UILabel alloc]initWithFrame:CGRectMake(240,4,100,25)];
	headertitlelebelbl.font=[UIFont fontWithName:Headerfont size:con.headerfntsize];
	headertitlelebelbl.backgroundColor=[UIColor clearColor];
	headertitlelebelbl.text = @"Balance";
	headertitlelebelbl.textColor=[UIColor whiteColor];
	[secheader addSubview:headertitlelebelbl ];
	[headertitlelebelbl release];
	}	
	return [secheader autorelease];
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{  
	static NSString *CellIdentifier = @"Cell";
	static NSString *CellIdentifier1 = @"Cell1";
	UITableViewCell *cell;
	
	if(cell==nil)
	{
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier] autorelease];
	}
	else
	{
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier1];
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier1] autorelease];
		
	}
	
	
	UIView *CellView=[[UIView alloc]init];
	CellView.frame=CGRectMake(0, 0, 320, 45);
	CellView.backgroundColor=[UIColor whiteColor];
	[cell addSubview:CellView];
	//[CellView release],CellView=nil;
	
	AccountsOBJ *myAccountsOBJ2=(AccountsOBJ *)[ arr_acc objectAtIndex:indexPath.section];
	
	
	
	cell.selectionStyle=UITableViewCellSelectionStyleBlue;
	//cell.contentView.backgroundColor=[UIColor whiteColor];
	//cell.accessoryView.backgroundColor=[UIColor whiteColor];
	
	
	if ([myAccountsOBJ2.accountShortName isEqualToString:@"HSA"])
	{
		electionOBJ *myelectionOBJ2=(electionOBJ *)[myAccountsOBJ2.elections objectAtIndex:indexPath.row/3];	
		UILabel *cellLabelText=[[UILabel alloc]initWithFrame:CGRectMake(9,5,150,20)];
		cellLabelText.numberOfLines=0;
		cellLabelText.font=[UIFont fontWithName:con.fontname size:con.fontsize];
		cellLabelText.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
		
		cellLabelText.backgroundColor=[UIColor clearColor];
		if (indexPath.row%3==0)//business logis to show plan period or not
			cellLabelText.text =@"Cash";
		else if (indexPath.row%3==1) {
			cellLabelText.text =@"Investment";
		}
		else if (indexPath.row%3==2) {
			cellLabelText.text =myAccountsOBJ2.lblmanageContribLink;
		}
		
		[CellView addSubview:cellLabelText];
		[cellLabelText release];
		
		if ([myAccountsOBJ2.balanceRelevant isEqualToString:@"Yes"]) 
		{//business logis to show balance or not
			
			UILabel *cellLabelammount=[[UILabel alloc]initWithFrame:CGRectMake(225,5,80,20)];
			cellLabelammount.font=[UIFont fontWithName:con.fontname size:con.bodyImpfntsize];
			cellLabelammount.backgroundColor=[UIColor clearColor];
			if (indexPath.row%3==0)
			{
				NSString *str=[self chkvalue:myelectionOBJ2.currentBalance];
				//NSLog(@"%d",[myelectionOBJ2.currentBalance floatValue]);
				if([myelectionOBJ2.currentBalance floatValue]<0)
				{
					
					cellLabelammount.textColor=[UIColor colorWithRed:con.ngtvRed/255.0f green:con.ngtvGreen/255.0f blue:con.ngtvBlue/255.0f alpha:1.0];
				}
				else 
				{
					cellLabelammount.textColor=[UIColor colorWithRed:con.posnumRed/255.0f green:con.posnumGreen/255.0f blue:con.posnumBlue/255.0f alpha:1.0];
				}
				
				cellLabelammount.text = str;   
				cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;	
			}
			else if (indexPath.row%3==1){
				NSString *str=[self chkvalue:myelectionOBJ2.investmentBalance];
				if([myelectionOBJ2.investmentBalance floatValue]<0)
				{
					
					cellLabelammount.textColor=[UIColor colorWithRed:con.ngtvRed/255.0f green:con.ngtvGreen/255.0f blue:con.ngtvBlue/255.0f alpha:1.0];
				}
				else 
				{
					cellLabelammount.textColor=[UIColor colorWithRed:con.posnumRed/255.0f green:con.posnumGreen/255.0f blue:con.posnumBlue/255.0f alpha:1.0];
				}
				
				cellLabelammount.text = str;
				cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
			}
			else if (indexPath.row%3==2){
				cellLabelammount.text = @"";
				cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
			}
			
			[CellView addSubview:cellLabelammount];
			[cellLabelammount release];
		}
		
	}
		else {
		
		electionOBJ *myelectionOBJ2=(electionOBJ *)[myAccountsOBJ2.elections objectAtIndex:indexPath.row];	
		cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;	
		
		UILabel *cellLabelText=[[UILabel alloc]initWithFrame:CGRectMake(9,5,220,20)];
		cellLabelText.font=[UIFont fontWithName:con.fontname size:con.bodyImpfntsize];
		cellLabelText.numberOfLines=0;
		cellLabelText.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
		cellLabelText.backgroundColor=[UIColor clearColor];
		if ([myAccountsOBJ2.planPeriodType isEqualToString:@"Annual"])//business logis to show plan period or not
			cellLabelText.text =myelectionOBJ2.planPeriod; 
		[CellView addSubview:cellLabelText];
		[cellLabelText release];
		
		if ([myAccountsOBJ2.balanceRelevant isEqualToString:@"Yes"]) {//business logis to show balance or not
			
			UILabel *cellLabelammount=[[UILabel alloc]initWithFrame:CGRectMake(200,5,90,20)];
			cellLabelammount.font=[UIFont fontWithName:con.fontname size:con.bodyImpfntsize];
			cellLabelammount.backgroundColor=[UIColor clearColor];
			cellLabelammount.textAlignment=UITextAlignmentRight;
			NSString *str=[self chkvalue:myelectionOBJ2.currentBalance];
			cellLabelammount.text = str;
			if([myelectionOBJ2.currentBalance floatValue]<0)
			{
				
				cellLabelammount.textColor=[UIColor colorWithRed:con.ngtvRed/255.0f green:con.ngtvGreen/255.0f blue:con.ngtvBlue/255.0f alpha:1.0];
			}
			else 
			{
				cellLabelammount.textColor=[UIColor colorWithRed:con.posnumRed/255.0f green:con.posnumGreen/255.0f blue:con.posnumBlue/255.0f alpha:1.0];
			}
			
			[CellView addSubview:cellLabelammount];
			[cellLabelammount release];
		}
		
	}
		//cell.backgroundColor=[UIColor whiteColor];
	return cell;
	
	
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
		return 40;
	
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	
	[[tableView cellForRowAtIndexPath: indexPath] setSelected:NO animated:YES];        
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
	NSString *transactionfor;
	
	AccountsOBJ *myAccountsOBJ2=(AccountsOBJ *)[ arr_acc objectAtIndex:indexPath.section];
	if ([myAccountsOBJ2.accountShortName isEqualToString:@"HSA"])
	{
		if (indexPath.row%3==0)
		{
			electionOBJ *myelectionOBJ2=(electionOBJ *)[myAccountsOBJ2.elections objectAtIndex:indexPath.row/3];
			electionid=myelectionOBJ2.electionID;
			transactionfor=@"normal";
		}
		else if (indexPath.row%3==1){
			
			//Write code here for HSA investment W/S accessing.
			electionOBJ *myelectionOBJ2=(electionOBJ *)[myAccountsOBJ2.elections objectAtIndex:indexPath.row/3];
			electionid=myelectionOBJ2.electionID;
			transactionfor=@"Investment";
		}
		else if (indexPath.row%3==2){
		
			electionOBJ *myelectionOBJ2=(electionOBJ *)[myAccountsOBJ2.elections objectAtIndex:indexPath.row/3];
			electionid=myelectionOBJ2.electionID;
			transactionfor=@"Contribution";
		}
	}
	else {
		
		electionOBJ *myelectionOBJ2=(electionOBJ *)[myAccountsOBJ2.elections objectAtIndex:indexPath.row];
		electionid=myelectionOBJ2.electionID;
		transactionfor=@"normal";
	}

	
	accounttype=myAccountsOBJ2.accountTypeCode;
	
	NSMutableArray *accountinfor=[[NSMutableArray alloc]init];
	[accountinfor addObject:electionid];
	[accountinfor addObject:accounttype];
	[accountinfor addObject:transactionfor];
	
	
	if ([[accountinfor objectAtIndex:2]isEqualToString:@"Contribution"]) {
		
		Contribution *myContribution = [[Contribution alloc] initWithArrayName:accountinfor];
		[self.navigationController pushViewController:myContribution animated:YES];
	}
	else {
		
		trancastionpage *mytrancastion = [[trancastionpage alloc] initWithArrayName:accountinfor];
		[self.navigationController pushViewController:mytrancastion animated:YES];

	}
	
	
}
-(void)onSucceffulLogin
{
	trancastionpage *mytrancastion = [[trancastionpage alloc] init];
	[self.navigationController pushViewController:mytrancastion animated:YES];
	[tools stopLoading:loadingView];
}

-(void)onFailureLogin
{
	[tools stopLoading:loadingView];
}
-(NSString *)chkvalue:(NSString *)value
{
	NSString *newvalue=@"";
	if([value intValue]>=0)
	{
		newvalue=[newvalue stringByAppendingString:con.ptvPrefix];
		newvalue=[newvalue stringByAppendingString:value];
	}
	else {
		value=[value substringFromIndex:1];
		newvalue=[newvalue stringByAppendingString:con.ngtvPrefix];
		newvalue=[newvalue stringByAppendingString:value];
		newvalue=[newvalue stringByAppendingString:con.ngtvSufix];
		
	}
	return newvalue;
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
