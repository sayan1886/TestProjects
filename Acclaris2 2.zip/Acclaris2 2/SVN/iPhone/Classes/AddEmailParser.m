//
//  AddEmailParser.m
//  Acclaris
//
//  Created by Subhojit on 18/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "AddEmailParser.h"

NSMutableArray *arrAddemail;
@implementation AddEmailParser
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error
{
	
	NSXMLParser *parser;
	parser = [[NSXMLParser alloc] initWithData:data];
    [parser setDelegate:self];
	[parser setShouldProcessNamespaces:NO];
    [parser setShouldReportNamespacePrefixes:NO];
    [parser setShouldResolveExternalEntities:NO];
    [parser parse];
    NSError *parseError = [parser parserError];
    if (parseError && error) 
	{
        *error = parseError;
    }
	[parser release];
}

-(void)parserDidStartDocument:(NSXMLParser *)parser
{
	arrAddemail=[[NSMutableArray alloc]init];
	
}		

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
	if (qName)
	{
		elementName = qName;
	}
	
	else 
		if([elementName isEqualToString:@"AddEmailMADetails"] || [elementName isEqualToString:@"VerifyEmailMADetails"] || [elementName isEqualToString:@"AddPhoneMADetails"])

		{
			obj=[[AddEmailOBJ alloc]init];	
			
		}
	else 
		if([elementName isEqualToString:@"returnCode"])
		{
			contentOfString=[NSMutableString string];
			[contentOfString retain];
			return;		
			
		}
	
	else 
		if([elementName isEqualToString:@"errorText"])
		{
			contentOfString=[NSMutableString string];
			[contentOfString retain];
			return;		
			
		}
		else 
			if([elementName isEqualToString:@"result"])
			{
				contentOfString=[NSMutableString string];
				[contentOfString retain];
				return;		
				
			}
	
}


- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName     
{	
	if (qName)
	{
        elementName = qName;
		
    }
	else 
		if([elementName isEqualToString:@"AddEmailMADetails"] || [elementName isEqualToString:@"VerifyEmailMADetails"] || [elementName isEqualToString:@"AddPhoneMADetails"])
		{
			if(obj)
			{
				[arrAddemail addObject:obj];
				[obj release],obj=nil;
				
			}		
			
		}
	else 
		if([elementName isEqualToString:@"returnCode"])
		{
			if(contentOfString)
			{
				obj.strreturnCode=contentOfString;
				[contentOfString release];
				contentOfString = nil;
				
				
			}		
			
		}
		else 
			if([elementName isEqualToString:@"errorText"])
			{
				if(contentOfString)
				{
					obj.strerrorText=contentOfString;
					[contentOfString release];
					contentOfString = nil;
					
					
				}		
				
			}
			else 
				if([elementName isEqualToString:@"result"])
				{
					if(contentOfString)
					{
						obj.strresult=contentOfString;
						[contentOfString release];
						contentOfString = nil;
						
						
					}		
					
				}
}
- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
	if(contentOfString)
		[contentOfString appendString:string];
}

- (void)parserDidEndDocument:(NSXMLParser *)parse
{
	
	
}
+(NSMutableArray *)getarrAddemail

{
	
	return arrAddemail;
}

@end
