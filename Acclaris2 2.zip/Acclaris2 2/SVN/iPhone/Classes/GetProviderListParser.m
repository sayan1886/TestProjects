//
//  GetProviderListParser.m
//  Acclaris
//
//  Created by Subhojit on 16/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "GetProviderListParser.h"
NSMutableArray *arrproviderlist;

@implementation GetProviderListParser
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error
{
	
	NSXMLParser *parser;
	parser = [[NSXMLParser alloc] initWithData:data];
    [parser setDelegate:self];
	[parser setShouldProcessNamespaces:NO];
    [parser setShouldReportNamespacePrefixes:NO];
    [parser setShouldResolveExternalEntities:NO];
    [parser parse];
    NSError *parseError = [parser parserError];
    if (parseError && error) 
	{
        *error = parseError;
    }
	[parser release];
}

-(void)parserDidStartDocument:(NSXMLParser *)parser
{
	
	arrproviderlist=[[NSMutableArray alloc]init];
	
}		

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
	if (qName)
	{
		elementName = qName;
	}
	
	
	else 
		if([elementName isEqualToString:@"returnCode"])
		{
			contentOfString=[NSMutableString string];
			[contentOfString retain];
			return;		
			
		}
		else 
			if([elementName isEqualToString:@"errorText"])
			{
				contentOfString=[NSMutableString string];
				[contentOfString retain];
				return;		
				
			}
			else 
				if([elementName isEqualToString:@"payee"])
				{
					objgetprovobj=[[GetProviderListOBJ alloc]init];
					
				}
				else 
					if([elementName isEqualToString:@"ID"])
					{
						contentOfString=[NSMutableString string];
						[contentOfString retain];
						return;		
						
					}
					else 
						if([elementName isEqualToString:@"eeID"])
						{
							contentOfString=[NSMutableString string];
							[contentOfString retain];
							return;		
							
						}
						else 
							if([elementName isEqualToString:@"name"])
							{
								
								
								contentOfString=[NSMutableString string];
								[contentOfString retain];
								return;	
								
								
								
							}
							else 
								if([elementName isEqualToString:@"nickName"])
								{
									
									contentOfString=[NSMutableString string];
									[contentOfString retain];
									return;	
								}
	
	
								else 
									if([elementName isEqualToString:@"prefix"])
									{
										
										contentOfString=[NSMutableString string];
										[contentOfString retain];
										return;
									}
									else 
										if([elementName isEqualToString:@"firstName"])
										{
											
											contentOfString=[NSMutableString string];
											[contentOfString retain];
											return;
										}
										else 
											if([elementName isEqualToString:@"middleName"])
											{
												
												contentOfString=[NSMutableString string];
												[contentOfString retain];
												return;
											}
											else 
												if([elementName isEqualToString:@"lastName"])
												{
													
													contentOfString=[NSMutableString string];
													[contentOfString retain];
													return;
												}
												else if([elementName isEqualToString:@"email"])
												{
													
													contentOfString=[NSMutableString string];
													[contentOfString retain];
													return;
													
												}
												else if([elementName isEqualToString:@"phone"])
												{
													
													contentOfString=[NSMutableString string];
													[contentOfString retain];
													return;
													
												}
												else if([elementName isEqualToString:@"forFutureUse"])
												{
													
													contentOfString=[NSMutableString string];
													[contentOfString retain];
													return;
													
												}
												else if([elementName isEqualToString:@"isActive"])
												{
													
													contentOfString=[NSMutableString string];
													[contentOfString retain];
													return;
													
												}
												else if([elementName isEqualToString:@"paymentReference"])
												{
													
													contentOfString=[NSMutableString string];
													[contentOfString retain];
													return;
													
												}
												else if([elementName isEqualToString:@"providerIdentifier"])
												{
													
													contentOfString=[NSMutableString string];
													[contentOfString retain];
													return;
													
												}
												else if([elementName isEqualToString:@"ns2:line1"])
												{
													
													contentOfString=[NSMutableString string];
													[contentOfString retain];
													return;
													
												}
												else if([elementName isEqualToString:@"ns2:line3"])
												{
													
													contentOfString=[NSMutableString string];
													[contentOfString retain];
													return;
													
												}
												else if([elementName isEqualToString:@"ns2:line3"])
												{
													
													contentOfString=[NSMutableString string];
													[contentOfString retain];
													return;
													
												}
												else if([elementName isEqualToString:@"ns2:city"])
												{
													
													contentOfString=[NSMutableString string];
													[contentOfString retain];
													return;
													
												}
												else if([elementName isEqualToString:@"ns2:state"])
												{
													
													contentOfString=[NSMutableString string];
													[contentOfString retain];
													return;
													
												}
												else if([elementName isEqualToString:@"ns2:zip"])
												{
													
													contentOfString=[NSMutableString string];
													[contentOfString retain];
													return;
													
												}
												else if([elementName isEqualToString:@"ns2:country"])
												{
													
													contentOfString=[NSMutableString string];
													[contentOfString retain];
													return;
													
												}
												else if([elementName isEqualToString:@"ns2:addressType"])
												{
													
													contentOfString=[NSMutableString string];
													[contentOfString retain];
													return;
													
												}
												
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName     
{	
	if (qName)
	{
        elementName = qName;
		
    }
	
	else 
		if([elementName isEqualToString:@"returnCode"])
		{
			if(contentOfString)
			{
								
			}	
			
		}
		else 
			if([elementName isEqualToString:@"errorText"])
			{
				if(contentOfString)
				{
					
					
					
				}		
				
			}
			else 
				if([elementName isEqualToString:@"payee"])
				{
					if(objgetprovobj)
					{
						[arrproviderlist addObject:objgetprovobj];
					    [objgetprovobj release],objgetprovobj=nil;
					
				   }
				}
				else 
					if([elementName isEqualToString:@"ID"])
					{
							
						objgetprovobj.strpayeeId=contentOfString;
						[contentOfString release];
						contentOfString = nil;
					}
					else 
						if([elementName isEqualToString:@"eeID"])
						{
							objgetprovobj.streeID=contentOfString;
							[contentOfString release];
							contentOfString = nil;	
							
						}
						else 
							if([elementName isEqualToString:@"name"])
							{
								
								
								objgetprovobj.strname=contentOfString;
								[contentOfString release];
								contentOfString = nil;
								
								
								
							}
							else 
								if([elementName isEqualToString:@"nickName"])
								{
									
									objgetprovobj.strnickName=contentOfString;
									[contentOfString release];
									contentOfString = nil;
								}
	
	
								else 
									if([elementName isEqualToString:@"prefix"])
									{
										
										objgetprovobj.strprefix=contentOfString;
										[contentOfString release];
										contentOfString = nil;
									}
									else 
										if([elementName isEqualToString:@"firstName"])
										{
											
											objgetprovobj.strfirstName=contentOfString;
											[contentOfString release];
											contentOfString = nil;
										}
										else 
											if([elementName isEqualToString:@"middleName"])
											{
												
												objgetprovobj.strmiddleName=contentOfString;
												[contentOfString release];
												contentOfString = nil;
											}
											else 
												if([elementName isEqualToString:@"lastName"])
												{
													
													objgetprovobj.strlastName=contentOfString;
													[contentOfString release];
													contentOfString = nil;
												}
												else if([elementName isEqualToString:@"email"])
												{
													
													objgetprovobj.stremail=contentOfString;
													[contentOfString release];
													contentOfString = nil;
													
												}
												else if([elementName isEqualToString:@"phone"])
												{
													
													objgetprovobj.strphone=contentOfString;
													[contentOfString release];
													contentOfString = nil;
													
												}
												else if([elementName isEqualToString:@"forFutureUse"])
												{
													
													objgetprovobj.strforFutureUse=contentOfString;
													[contentOfString release];
													contentOfString = nil;
													
												}
												else if([elementName isEqualToString:@"isActive"])
												{
													
													objgetprovobj.strisActive=contentOfString;
													[contentOfString release];
													contentOfString = nil;
													
												}
												else if([elementName isEqualToString:@"paymentReference"])
												{
													
													objgetprovobj.strpaymentReference=contentOfString;
													[contentOfString release];
													contentOfString = nil;													
												}
												else if([elementName isEqualToString:@"providerIdentifier"])
												{
													
													objgetprovobj.strproviderIdentifier=contentOfString;
													[contentOfString release];
													contentOfString = nil;													
												}
												else if([elementName isEqualToString:@"ns2:line1"])
												{
													
													objgetprovobj.strline1=contentOfString;
													[contentOfString release];
													contentOfString = nil;													
												}
												else if([elementName isEqualToString:@"ns2:line3"])
												{
													
													objgetprovobj.strline2=contentOfString;
													[contentOfString release];
													contentOfString = nil;													
												}
												else if([elementName isEqualToString:@"ns2:line3"])
												{
													
													objgetprovobj.strline3=contentOfString;
													[contentOfString release];
													contentOfString = nil;													
												}
												else if([elementName isEqualToString:@"ns2:city"])
												{
													
													objgetprovobj.strcity=contentOfString;
													[contentOfString release];
													contentOfString = nil;													
												}
												else if([elementName isEqualToString:@"ns2:state"])
												{
													
													objgetprovobj.strstate=contentOfString;
													[contentOfString release];
													contentOfString = nil;
												}
												else if([elementName isEqualToString:@"ns2:zip"])
												{
													
													objgetprovobj.strzip=contentOfString;
													[contentOfString release];
													contentOfString = nil;
													
												}
												else if([elementName isEqualToString:@"ns2:country"])
												{
													
													objgetprovobj.strcountry=contentOfString;
													[contentOfString release];
													contentOfString = nil;
													
												}
												else if([elementName isEqualToString:@"ns2:addressType"])
												{
													
													objgetprovobj.straddressType=contentOfString;
													[contentOfString release];
													contentOfString = nil;
													
												}
}
	
	
- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
	if(contentOfString)
		[contentOfString appendString:string];
}

- (void)parserDidEndDocument:(NSXMLParser *)parse

{
	
	
	
	
}
	
+(NSMutableArray *)arrgetarrproviderlist

{
	
	
	return arrproviderlist;
}
	
@end
