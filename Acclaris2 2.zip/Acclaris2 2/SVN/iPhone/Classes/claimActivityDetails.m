    //
//  claimActivityDetails.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 12/11/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import "claimActivityDetails.h"
#import "claimActivity.h"
#import "configurables.h"
#import "claimactivityPerser.h"
#import "claimActivityOBJ.h"
#import "UserresponcePerser.h"
#import "Decode64.h"
#import "configurableParser.h"
#import "AcclarisViewController.h"
#import "AddImage.h"
#import "denialReasonShow.h"
#import "passPerser.h"
#define FONT_SIZE 15.0f
#define CELL_CONTENT_WIDTH 120.0f
#define CELL_CONTENT_MARGIN 10.0f
NSString *transaction_id;
@implementation claimActivityDetails



// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	

	NSMutableArray *arr_myconfig=[AcclarisViewController staticarr_config];//[configurableParser getconfig_arr];//
	con=(configurables *)[arr_myconfig objectAtIndex:0];
	
	self.view.backgroundColor = [UIColor colorWithRed:con.bgRed/255.0f green:con.bgGreen/255.0f blue:con.bgBlue/255.0f alpha:1.0];

	
	tools=[[MyTools alloc]init];
	loadingView=[tools createActivityIndicator1];
	
	selectedrow=[claimActivity getSelectedClaimRow];
	
	[self signoutbt];
	arr_celltytle=[claimactivityPerser claimactivityArr];
	
	
	//NSMutableArray *my_arrUserinfo=[UserresponcePerser userdesc];
	UIImageView *logo_img = [[UIImageView alloc]initWithFrame:CGRectMake(0, 2, 170, 40)];
	NSData *data=[Base64 decode:con.logoImgdata];
	logo_img.image=	[UIImage imageWithData:[NSData dataWithData:data]];
	self.navigationItem.titleView=logo_img;
	
	NSString *lbltransaction_id=@"";
	lbltransaction_id=[lbltransaction_id stringByAppendingString:((claimActivityOBJ *)[ arr_celltytle objectAtIndex:selectedrow]).LBLtrxnID];
	lbltransaction_id=[lbltransaction_id stringByAppendingString:@"/"];
	lbltransaction_id=[lbltransaction_id stringByAppendingString:((claimActivityOBJ *)[ arr_celltytle objectAtIndex:selectedrow]).LBLclaimID];
	
	transaction_id=@"";
	transaction_id=[transaction_id stringByAppendingString:((claimActivityOBJ *)[ arr_celltytle objectAtIndex:selectedrow]).trxnID];
	transaction_id=[transaction_id stringByAppendingString:@"/"];
	transaction_id=[transaction_id stringByAppendingString:((claimActivityOBJ *)[ arr_celltytle objectAtIndex:selectedrow]).claimID];

	arr_celllabel=[[NSArray alloc]initWithObjects:((claimActivityOBJ *)[ arr_celltytle objectAtIndex:selectedrow]).LBLserviceDate,((claimActivityOBJ *)[ arr_celltytle objectAtIndex:selectedrow]).LBLaccountType,((claimActivityOBJ *)[ arr_celltytle objectAtIndex:selectedrow]).LBLprovider,((claimActivityOBJ *)[ arr_celltytle objectAtIndex:selectedrow]).LBLclaimType,lbltransaction_id,((claimActivityOBJ *)[ arr_celltytle objectAtIndex:selectedrow]).LBLstatus,((claimActivityOBJ *)[ arr_celltytle objectAtIndex:selectedrow]).LBLpaymentStatus,((claimActivityOBJ *)[ arr_celltytle objectAtIndex:selectedrow]).LBLcheckNo,nil];
	arr_cellstatus=[[NSArray alloc]initWithObjects:((claimActivityOBJ *)[ arr_celltytle objectAtIndex:selectedrow]).serviceDate,((claimActivityOBJ *)[ arr_celltytle objectAtIndex:selectedrow]).accountType,((claimActivityOBJ *)[ arr_celltytle objectAtIndex:selectedrow]).provider,((claimActivityOBJ *)[ arr_celltytle objectAtIndex:selectedrow]).claimType,transaction_id,((claimActivityOBJ *)[ arr_celltytle objectAtIndex:selectedrow]).status,((claimActivityOBJ *)[ arr_celltytle objectAtIndex:selectedrow]).paymentStatus,((claimActivityOBJ *)[ arr_celltytle objectAtIndex:selectedrow]).checkNo,nil];
	//arr_celllabel=[[NSArray alloc]initWithObjects:((claimActivityOBJ *)[ arr_celltytle objectAtIndex:selectedrow]).LBLserviceDate,((claimActivityOBJ *)[ arr_celltytle objectAtIndex:selectedrow]).LBLaccountType,((claimActivityOBJ *)[ arr_celltytle objectAtIndex:selectedrow]).LBLprovider,((claimActivityOBJ *)[ arr_celltytle objectAtIndex:selectedrow]).LBLclaimType,lbltransaction_id,((claimActivityOBJ *)[ arr_celltytle objectAtIndex:selectedrow]).LBLpaymentStatus,((claimActivityOBJ *)[ arr_celltytle objectAtIndex:selectedrow]).LBLcheckNo,nil];
	//arr_cellstatus=[[NSArray alloc]initWithObjects:((claimActivityOBJ *)[ arr_celltytle objectAtIndex:selectedrow]).serviceDate,((claimActivityOBJ *)[ arr_celltytle objectAtIndex:selectedrow]).accountType,((claimActivityOBJ *)[ arr_celltytle objectAtIndex:selectedrow]).provider,((claimActivityOBJ *)[ arr_celltytle objectAtIndex:selectedrow]).claimType,transaction_id,((claimActivityOBJ *)[ arr_celltytle objectAtIndex:selectedrow]).paymentStatus,((claimActivityOBJ *)[ arr_celltytle objectAtIndex:selectedrow]).checkNo,nil];
	
	NSMutableDictionary *roleDict=[passPerser getRolebaseDict];
	if ([[roleDict valueForKey:@"IMAGE_UPLOAD"]isEqualToString:@"Yes"]) {
			
		UIButton *btn_imgUp=[UIButton buttonWithType:UIButtonTypeCustom];
		btn_imgUp.frame = CGRectMake(43, 308, 234, 47);
		NSData *data_btnimg=[Base64 decode:con.btnImgdata];
		[btn_imgUp setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
		btn_imgUp.titleLabel.font = [UIFont fontWithName:con.btnfontname size:15];
		[btn_imgUp setTitle:[roleDict valueForKey:@"IMAGE_UPLOADLabel"] forState:UIControlStateNormal];
		[btn_imgUp setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
		[btn_imgUp addTarget:self action:@selector(imgUp) forControlEvents:UIControlEventTouchUpInside];
		[self.view addSubview:btn_imgUp];
	}
	
	
	[self createtableview];
}
-(void)imgUp
{
	int row= -1;
	AddImage *obj=[[AddImage alloc]initWithindex:row];
	[self.navigationController pushViewController:obj animated:YES];
}
-(void)signoutbt
{
	UIBarButtonItem *signoutButton = [[UIBarButtonItem alloc]
									  initWithTitle:@"Sign Off"
									  style:UIBarButtonItemStyleBordered
									  target:self
									  action:@selector(signout)];
    self.navigationItem.rightBarButtonItem =signoutButton;
}
-(void)signout
{
	[((AcclarisAppDelegate *)[[UIApplication sharedApplication] delegate]) removeTabBar];
}
#pragma mark tableViewDeligate
-(void)createtableview
{
	UITableView	*acctable=[[UITableView alloc] initWithFrame:CGRectMake(0,0,320,330-40) style:UITableViewStyleGrouped];
	acctable.delegate = self;
	acctable.dataSource = self;
	acctable.scrollEnabled = YES;
	acctable.autoresizesSubviews = YES;
	acctable.showsVerticalScrollIndicator=YES;
	acctable.showsHorizontalScrollIndicator=YES;
	acctable.backgroundColor=[UIColor clearColor];
	[self.view addSubview:acctable];	
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView  
{
	return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	return [arr_celllabel count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{  
	static NSString *CellIdentifier = @"Cell";
	static NSString *CellIdentifier1 = @"Cell1";
	UITableViewCell *cell;
	
	if(cell==nil)
	{
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier] autorelease];
	}
	else
	{
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier1];
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier1] autorelease];
		
	}
	cell.selectionStyle=UITableViewCellSelectionStyleNone;
	cell.backgroundColor=[UIColor whiteColor];
	
	strFont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];
	
	UILabel *cellLabelText=[[UILabel alloc]initWithFrame:CGRectMake(19,13,150,20)];
	cellLabelText.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
	cellLabelText.backgroundColor=[UIColor clearColor];
	cellLabelText.text =[arr_celllabel objectAtIndex:indexPath.row];
	cellLabelText.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
	[cell.contentView addSubview:cellLabelText];
	[cellLabelText release];
	
	


	
	UILabel *cellLabelstatus=[[UILabel alloc]initWithFrame:CGRectMake(170,13,120,20)];
	cellLabelstatus.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
	cellLabelstatus.backgroundColor=[UIColor clearColor];
	NSString *text =[arr_cellstatus objectAtIndex:indexPath.row];
	CGSize constraint = CGSizeMake(CELL_CONTENT_WIDTH - (CELL_CONTENT_MARGIN * 2), 20000.0f);
	CGSize size = [text sizeWithFont:[UIFont fontWithName:strFont size:con.bodyImpfntsize] constrainedToSize:constraint lineBreakMode:UILineBreakModeWordWrap];
	CGFloat height = MAX(size.height, 10.0f);
	cellLabelstatus.frame=CGRectMake(170,13,120,height);
		
	cellLabelstatus.numberOfLines=0;
	cellLabelstatus.text = [arr_cellstatus objectAtIndex:indexPath.row];
	cellLabelstatus.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];

	[cell.contentView addSubview:cellLabelstatus];
	[cellLabelstatus release];
	
	
	if(indexPath.row==5 && [((claimActivityOBJ *)[ arr_celltytle objectAtIndex:selectedrow]).status isEqualToString:@"Denied"])
	{
		cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
	}
	
	
	return cell;
	
	
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	if (indexPath.row==5 && [((claimActivityOBJ *)[ arr_celltytle objectAtIndex:selectedrow]).status isEqualToString:@"Denied"])
	{
		denialReasonShow *mydenialReasonShow=[[denialReasonShow alloc]init];
		[self.navigationController pushViewController:mydenialReasonShow animated:YES];
		
	}
	
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	
	//return 45.0;
	
	//dynamic height for each row
	strFont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];

	NSString *text =[arr_cellstatus objectAtIndex:indexPath.row];
	CGSize constraint = CGSizeMake(CELL_CONTENT_WIDTH - (CELL_CONTENT_MARGIN * 2), 20000.0f);
	CGSize size = [text sizeWithFont:[UIFont fontWithName:strFont size:con.bodyImpfntsize] constrainedToSize:constraint lineBreakMode:UILineBreakModeWordWrap];
	CGFloat height = MAX(size.height, 10.0f);
	
	
	return height + (CELL_CONTENT_MARGIN * 2);
	
	
}



+(NSString *)getTranClaimID
{
	return transaction_id;
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
