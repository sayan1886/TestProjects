//
//  configurables.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 11/11/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import "configurables.h"


@implementation configurables
@synthesize fontname,btnfontname;
@synthesize fontsize,btnfontsize;
@synthesize bgRed,bgGreen,bgBlue,bgRed2,bgGreen2,bgBlue2;
@synthesize navbarRed,navbarGreen,navbarBlue;
@synthesize ngtvRed,ngtvGreen,ngtvBlue;
@synthesize ngtvSufix,ngtvPrefix,ptvPrefix;
@synthesize posnumRed,posnumGreen,posnumBlue,txtRed,txtGreen,txtBlue;
@synthesize linkimpRed,linkimpGreen,linkimpBlue;
@synthesize linkgnRed,linkgnGreen,linkgnBlue;
@synthesize btnImgdata;
@synthesize logoImgdata;

@synthesize headerImpfntsize;
@synthesize headerfntsize;
@synthesize bodyImpfntsize;
@synthesize bodyfntsize;

@synthesize btnNavFontName,btnNavFontSize,btnNavImgData;

- (id)init{
	self=[super init];
	if(self==nil)
		return nil;
	//self.fontname=@"AmericanTypewriter";
	//self.fontsize=12;
	//////////////////////
	//self.bgRed=10.0;
	//self.bgGreen=111.0;
	//self.bgBlue=122.0;
	//////////////////////
	
	
	//self.bgRed2=96.0;
	//self.bgGreen2=85.0;
	//self.bgBlue2=191.0;
	//////////////////////
	self.navbarRed=39.0;
	self.navbarGreen=39.0;
	self.navbarBlue=39.0;
	//////////////////////
	
	
	
	return self;
	
}
@end
