//
//  ticketLogsOBJ.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 27/10/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface ticketLogsOBJ : NSObject {
	NSString	*logID;
	NSString	*ticketID;
	NSString	*action;
	NSString	*loggedBy;
	NSString	*loggedThru;
	NSString	*note;
	NSString	*isPrivate;
	NSString	*minutesSpent;
}
@property(nonatomic,retain)NSString *logID;
@property(nonatomic,retain)NSString *ticketID;
@property(nonatomic,retain)NSString *action;
@property(nonatomic,retain)NSString *loggedBy;
@property(nonatomic,retain)NSString *loggedThru;
@property(nonatomic,retain)NSString *note;
@property(nonatomic,retain)NSString *isPrivate;
@property(nonatomic,retain)NSString *minutesSpent;
@end
