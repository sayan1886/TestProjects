//
//  AccountDetails.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 06/10/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyTools.h"

@class trancastionpage;
@class request;
@class UAView;
@class configurables;

@interface AccountDetails : UIViewController<UITableViewDelegate,UITableViewDataSource> {

	MyTools *tools;
	configurables *con;
	NSMutableArray *arr_acc;
	UIView *loadingView;
}
-(void)signoutbt;
-(void)createtableview;
+(NSString *)electionID;
+(NSString *)acType;
-(NSString *)chkvalue:(NSString *)value;
@end
