    //
//  SubmitNewClaimone.m
//  Acclaris
//
//  Created by Subhojit on 21/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "SubmitNewClaimone.h"
#import "configurables.h"
#import "AcclarisViewController.h"

@implementation SubmitNewClaimone
@synthesize strPriorCheck;
- (void)viewDidLoad {
    [super viewDidLoad];
	
	self.navigationItem.hidesBackButton=YES;
	arrDecide=[ClaimSubmitNewParser getarrm_passArray];
	arrsubmitcatagory=[ClaimSubmitNewParser getarrCatagory];
	
	
	/*UIButton *btnBack = [UIButton buttonWithType:101];
	[btnBack setTitle:@"hhhh" forState:UIControlStateNormal];
	[btnBack addTarget:self action:@selector(callback) forControlEvents:UIControlEventTouchUpInside];
	UIBarButtonItem *barBack1 = [[UIBarButtonItem alloc]initWithCustomView:btnBack];
	self.navigationItem.leftBarButtonItem =barBack1;*/
	
	UIButton *btnBack=[UIButton buttonWithType:UIButtonTypeCustom];
	btnBack.frame=CGRectMake(0,0 ,60 , 32);
	
	NSString* filePath = [[NSBundle mainBundle] pathForResource:@"back_button.png"
												 ofType:nil]; 
	
	UIImage* image = [UIImage imageWithContentsOfFile:filePath];
	
	[btnBack setBackgroundImage:image forState:UIControlStateNormal];
	[btnBack setTitle:@"  Back" forState:UIControlStateNormal];
	btnBack.font=[UIFont fontWithName:@"Arial-BoldMT" size:14];
	[btnBack addTarget:self action:@selector(callback) forControlEvents:UIControlEventTouchUpInside];
	
	UIBarButtonItem *barBack = [[UIBarButtonItem alloc]initWithCustomView:btnBack];
	self.navigationItem.leftBarButtonItem =barBack;
	
	
	
	
	
	NSMutableArray *arr_myconfig=[AcclarisViewController staticarr_config];
	con=(configurables *)[arr_myconfig objectAtIndex:0];
	self.view.backgroundColor = [UIColor colorWithRed:con.bgRed/255.0f green:con.bgGreen/255.0f blue:con.bgBlue/255.0f alpha:1.0];
	self.navigationController.navigationBar.tintColor=[UIColor colorWithRed:con.navbarRed/255.0f green:con.navbarGreen/255.0f blue:con.navbarBlue/255.0f alpha:1.0];
	
	UIImageView *logo_img = [[UIImageView alloc]initWithFrame:CGRectMake(0, 2, 170, 40)];
	NSData *data=[Base64 decode:con.logoImgdata];
	logo_img.image=	[UIImage imageWithData:[NSData dataWithData:data]];
	self.navigationItem.titleView=logo_img;
	
	
	[self createbar_button];
	
	
	[self CreateView];
	
}
-(void)signout
{
	[((AcclarisAppDelegate *)[[UIApplication sharedApplication] delegate]) removeTabBar];
}
-(void)createbar_button
{
	
	UIBarButtonItem *signoutButton = [[UIBarButtonItem alloc]
									  initWithTitle:@"Sign Off"
									  style:UIBarButtonItemStyleBordered
									  target:self
									  action:@selector(signout)];
    self.navigationItem.rightBarButtonItem =signoutButton;
	
}
-(void)callback
{
	
	
	[self.navigationController popToRootViewControllerAnimated:YES];
}
-(void)CreateView
{
	
	NSString *strFont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];

	arrpicker=[[NSMutableArray alloc]init];
	NSData *data_btnimg=[Base64 decode:con.btnImgdata];//btn background image

	UIView *HeaderView=[[[UIView alloc]initWithFrame:CGRectMake(0, 0, 320, 60)]autorelease];
	HeaderView.backgroundColor=[UIColor colorWithRed:con.bgRed2/255.0 green:con.bgGreen2/255.0 blue:con.bgBlue2/255.0 alpha:1.0];
	[self.view addSubview:HeaderView];
	
	NSString *strViewTitle=@"Claim Category";
	//strViewTitle=[strViewTitle stringByAppendingString:@"\n"];
	//strViewTitle=[strViewTitle stringByAppendingFormat:@"%@",@"Catagory"];
	
	UILabel *lbltext=[[UILabel alloc]initWithFrame:CGRectMake(10, 5, 250, 60)];
	lbltext.text=strViewTitle;
	lbltext.backgroundColor=[UIColor clearColor];
	lbltext.textColor=[UIColor whiteColor];
	//lbltext.numberOfLines=0;
	lbltext.font=[UIFont fontWithName:strFont size:con.headerImpfntsize];
	[HeaderView addSubview:lbltext];
	[lbltext release],lbltext=nil;
	

	
	txtCatagory=[[UITextField alloc]initWithFrame:CGRectMake(5, 110, 310, 40)];
	txtCatagory.delegate=self;	
	txtCatagory.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	txtCatagory.borderStyle=UITextBorderStyleLine;
	txtCatagory.returnKeyType=UIReturnKeyDone;
	txtCatagory.text=@"";
	txtCatagory.backgroundColor=[UIColor whiteColor];
	txtCatagory.textAlignment=UITextAlignmentLeft;
	txtCatagory.autocorrectionType =UITextAutocorrectionTypeNo;
	txtCatagory.userInteractionEnabled=YES;
	//txtPCode.clearButtonMode = UITextFieldViewModeWhileEditing;
	[self.view addSubview:txtCatagory];
	
	
	UIButton *btnContinue=[UIButton buttonWithType:UIButtonTypeCustom];
	btnContinue.frame=CGRectMake(30, 290, 260, 40);
	[btnContinue setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
	[btnContinue setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	btnContinue.titleLabel.font = [UIFont fontWithName:con.btnfontname size:con.btnfontsize];
	[btnContinue setTitle:@"Continue" forState:UIControlStateNormal];
	[btnContinue addTarget:self action:@selector(ClickbtnContinue) forControlEvents:UIControlEventTouchUpInside];					 
	[self.view addSubview:btnContinue];
	
	
	
}
-(void)ClickbtnContinue
{
	
	if([txtCatagory.text isEqualToString:@""])
	{
		
		NSDictionary *customMessageList_dict=[[NSUserDefaults standardUserDefaults] objectForKey:@"customMessageList"];
		
		
		NSString *strmessage=[[customMessageList_dict valueForKey:@"200043"]valueForKey:@"message"];
		NSString *strtype=[[customMessageList_dict valueForKey:@"200043"]valueForKey:@"type"];

		UIAlertView *alertview=[[UIAlertView alloc]initWithTitle:strtype message:strmessage delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		alertview.delegate=self;
		[alertview show];
		[alertview release],alertview=nil;
		return;
		
		
	}
	else 
	{
		
		SubmitNewClaimTwo *obj=[[SubmitNewClaimTwo alloc]initWitharr:objClaimsubmit.arrclaimsubtype str:self.strPriorCheck catagory:dict];
		[self.navigationController pushViewController:obj animated:YES];
		//[obj release],obj=nil;
	}


}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{

	[self Vanishpicker];	
	[self createbarbuttondone];
	
	if([arrsubmitcatagory count]==0)
	{
		
		return NO;
		
	}
	else 
	{
		[self CreatePickerView];
	}

	
	return NO;
}
- (BOOL)textFieldShouldEndEditing:(UITextField *)textField
{

	
	return YES;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
	return YES;
}

-(void)createbarbuttondone
{
	UIBarButtonItem *doneButton = [[UIBarButtonItem alloc]
				  initWithTitle:@"Done"
				  style:UIBarButtonItemStyleBordered
				  target:self
				  action:@selector(donecancel)];

	
	
    self.navigationItem.rightBarButtonItem =doneButton;
	
}

-(void)donecancel
{
	[self  createbar_button];
	
	
	[self Vanishpicker];	
}

-(void)Vanishpicker
{
	if(myPickerView)
	{
		[myPickerView removeFromSuperview];
	    [myPickerView release],myPickerView=nil;
	}
	
}
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component;
{
	
	NSString *str=@"";
	txtCatagory.text=[str stringByAppendingFormat:@"%@",((ClaimSubmitNewOBJ *)[arrsubmitcatagory objectAtIndex:[pickerView selectedRowInComponent:0]]).strname];
	strselectclaimcatagory=[str stringByAppendingFormat:@"%@",((ClaimSubmitNewOBJ *)[arrsubmitcatagory objectAtIndex:[pickerView selectedRowInComponent:0]]).strname];;
	NSLog(@"%@",strselectclaimcatagory);
	dict=[[NSMutableDictionary alloc]init];

	[dict setObject:strselectclaimcatagory  forKey:@"cat"];
	 
	
	
	  objClaimsubmit=(ClaimSubmitNewOBJ*)[arrsubmitcatagory objectAtIndex:row];
	for(int j=0;j<[objClaimsubmit.arrclaimsubtype count];j++)
	{
		objClaimsub=(ClaimSubOBJ*)[objClaimsubmit.arrclaimsubtype objectAtIndex:j];
				
		
	}
    	
	if([((ClaimSubmitNewOBJ *)[arrsubmitcatagory objectAtIndex:row]).strpriorYearActivePlan isEqualToString:@"Yes"])
		{
		
			self.strPriorCheck=@"Yes";
			
		}
		else
		{
			
			self.strPriorCheck=@"No";
		}
		
}
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
	
	objClaimsubmit=(ClaimSubmitNewOBJ*)[arrsubmitcatagory objectAtIndex:row];
	return objClaimsubmit.strname;	
}

- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component
{
	// first column size is wider to hold names
	
	return 200.0;                     // second column is narrower to show numbers
	
}

- (CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component
{
	return 60.0;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
	
	return [arrsubmitcatagory count];
	
	
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
	return 1;
}
-(void)CreatePickerView
{

	myPickerView = [[UIPickerView alloc] initWithFrame:CGRectMake(0, 155, 200, 150)];
	myPickerView.showsSelectionIndicator = YES;
	myPickerView.delegate = self;
	[self.view addSubview:myPickerView];
	
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
	//myPickerView=nil;
	//txtCatagory=nil;
}


- (void)dealloc {
	//[pickerViewArray release];
	//[myPickerView release];
	//[txtCatagory release];
    [super dealloc];
}


@end
