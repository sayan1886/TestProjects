//
//  ticketOBJ.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 26/10/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface ticketOBJ : NSObject {
	
	NSString *ticketID;
	NSString *LBLticketID;
	NSString *causeNote;
	NSString *LBLcauseNote;
	NSString *ticketType;
	NSString *LBLticketType;
	NSString *ticketCategory;
	NSString *createdBy;
	NSString *createdOn;
	NSString *LBLcreatedOn;
	NSString *resolvedBy;
	NSString *resolvedOn;
	NSString *resolutionNote;
	NSString *status;
	NSString *LBLstatus;
	NSString *priority;
	NSString *source;
	NSString *privacyLabel;
	NSString *ticketLogsCount;
	NSString *ticketLogs;
	NSMutableArray *arrm_logs;
	
}
@property(nonatomic,retain)NSString *ticketID,*LBLticketID;
@property(nonatomic,retain)NSString *causeNote,*LBLcauseNote;
@property(nonatomic,retain)NSString *ticketType,*LBLticketType;
@property(nonatomic,retain)NSString *ticketCategory;
@property(nonatomic,retain)NSString *createdBy;
@property(nonatomic,retain)NSString *createdOn,*LBLcreatedOn;
@property(nonatomic,retain)NSString *resolvedBy;
@property(nonatomic,retain)NSString *resolvedOn;
@property(nonatomic,retain)NSString *resolutionNote;
@property(nonatomic,retain)NSString *status,*LBLstatus;
@property(nonatomic,retain)NSString *priority;
@property(nonatomic,retain)NSString *source;
@property(nonatomic,retain)NSString *privacyLabel;
@property(nonatomic,retain)NSString *ticketLogsCount;
@property(nonatomic,retain)NSString *ticketLogs;
@property(nonatomic,retain)NSMutableArray *arrm_logs;
@end
