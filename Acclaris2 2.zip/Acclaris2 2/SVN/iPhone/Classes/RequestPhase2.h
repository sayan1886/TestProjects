//
//  RequestPhase2.h
//  Acclaris
//
//  Created by Subhojit on 25/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AcclarisAppDelegate.h"
#import "Constants.h"
#import "MyTools.h"
#import "SubmitclaimParser.h"
#import "Deleteparser.h"
#import "GetProviderListParser.h"
#import "AddproviderParser.h"
#import "PaynowParser.h"
#import "StateParser.h"
#import "CountryParser.h"
#import "PaynowcontinueParser.h"]
#import "errorResponseAlert.h"
@class ClaimSubmitNewParser;
@class Claimonlineserviceparser;
@class UnsubmittedClaimParser;
@interface RequestPhase2 : NSObject {

	AcclarisAppDelegate *app;
	NSString *whichAPI;
	MyTools *tools;
	id target;
	SEL successHandler;
	SEL failureHandler;
	NSMutableData *d2;
	
	BOOL isstatus;
}
-(id)initWithTarget:(id)actionTarget
	  SuccessAction:(SEL)successAction 
	  FailureAction:(SEL)failureAction;
-(void)callPostMethod:(NSMutableString *)sRequest Action:(NSString *)action API:(NSString *)api;
-(NSString *)getUTCFormateDate:(NSDate *)localDate;
-(void)GetOnlnClaimCtrgyTypeMAService:(NSString *)participantID uID:(NSString *)userID;

-(void)ClaimOnlineServiceSave:(NSString *)participantID uID:(NSString *)userID claimCaty:(NSString *)claimCategory claimtpe:(NSString *)claimtype  amt:(NSString *)amount 
					  SerBedt:(NSString *)serviceBeginDt 
					  SerEedt:(NSString *)serviceEndDt
						 Note:(NSString *)note
					   isPrYr:(NSString *)isPriorYear
					  payMode:(NSString *)payMode
				 providerName:(NSString *) providerName
					  PayeeId:(NSString *)PayeeId allowDuplicateClaim:(NSString *)allowDuplicateClaim
					   opcode:(NSString *)opcode;


-(void)GetUnSubmittedClaim:(NSString *)participantID uID:(NSString *)userID  
				noOfRecord:(NSString *)noOfRecords  
			 startAftersid:(NSString *)startAfterSeqID;


-(void)SubmitallClaim:(NSString *)participantID uID:(NSString *)userID;


-(void)deleteClaim:(NSString *)participantID uID:(NSString *)userID Claimid:(NSString *)claimID;


-(void)EditUnSubmittedClaim:(NSString *)participantID uID:(NSString *)userID claimCaty:(NSString *)claimCategory claimtpe:(NSString *)claimtype  amt:(NSString *)amount 
					SerBedt:(NSString *)serviceBeginDt 
					SerEedt:(NSString *)serviceEndDt
					   Note:(NSString *)note
					 isPrYr:(NSString *)isPriorYear
					payMode:(NSString *)payMode
			   providerName:(NSString *) providerName Claimid:(NSString *)claimID allowDuplicateClaim:(NSString *)allowDuplicateClaim
					 opcode:(NSString *)opcode ;

-(void)sendActiveScheduleRequest:(NSString *)participantID userid:(NSString *)userID 
							 Eid:(NSString *)E_id
						 startId:(NSString *)start_id
						 noOfRec:(NSString *)no_ofRec
					scheduletype:(NSString *)s_type;

-(void)sendInActiveScheduleRequest:(NSString *)participantID userid:(NSString *)userID 
							   Eid:(NSString *)E_id
						   startId:(NSString *)start_id
						   noOfRec:(NSString *)no_ofRec
					  scheduletype:(NSString *)s_type;


-(void)ClaimOnlineServiceSave2:(NSString *)participantID uID:(NSString *)userID claimCaty:(NSString *)claimCategory claimtpe:(NSString *)claimtype  amt:(NSString *)amount 
					   SerBedt:(NSString *)serviceBeginDt 
					   SerEedt:(NSString *)serviceEndDt
						  Note:(NSString *)note
						isPrYr:(NSString *)isPriorYear
					   payMode:(NSString *)payMode
				  providerName:(NSString *) providerName
				  accountvalue:(NSString *)actpCD
					   PayeeId:(NSString *)PayeeId allowDuplicateClaim:(NSString *)allowDuplicateClaim
						opcode:(NSString *)opcode;

-(void)GetProviderList:(NSString *)participantID userid:(NSString *)userID;



-(void)AddProvider:(NSString *)participantID uID:(NSString *)userID name:(NSString *)name nickName:(NSString *)nickName  firstName:(NSString *)firstName 
		middleName:(NSString *)middleName 
		  lastName:(NSString *)lastName
			 email:(NSString *)email
			 phone:(NSString *)phone
			 line1:(NSString *)line1
			 line2:(NSString *)line2
			 line3:(NSString *)line3
			  city:(NSString *)city
			 state:(NSString *)state
			   zip:(NSString *)zip
		   country:(NSString *)country;



-(void)DeletePayee:(NSString *)participantID uID:(NSString *)userID payeeID:(NSString *)payeeID;



-(void)AddProvider2:(NSString *)participantID uID:(NSString *)userID name:(NSString *)name nickName:(NSString *)nickName  firstName:(NSString *)firstName 
		 middleName:(NSString *)middleName 
		   lastName:(NSString *)lastName
			  email:(NSString *)email
			  phone:(NSString *)phone
			  line1:(NSString *)line1
			  line2:(NSString *)line2
			  line3:(NSString *)line3
			   city:(NSString *)city
			  state:(NSString *)state
				zip:(NSString *)zip
			country:(NSString *)country
				 ID:(NSString *)ID;



-(void)EditUnSubmittedClaim2:(NSString *)participantID uID:(NSString *)userID claimCaty:(NSString *)claimCategory claimtpe:(NSString *)claimtype  amt:(NSString *)amount 
					 SerBedt:(NSString *)serviceBeginDt 
					 SerEedt:(NSString *)serviceEndDt
						Note:(NSString *)note
					  isPrYr:(NSString *)isPriorYear
					 payMode:(NSString *)payMode
				providerName:(NSString *) providerName Claimid:(NSString *)claimID

				accountvalue:(NSString *)actpCD allowDuplicateClaim:(NSString *)allowDuplicateClaim
					  opcode:(NSString *)opcode ;


-(void)GetState:(NSString *)pId userid:(NSString *)uId countryCode:(NSString *)countryCode;
-(void)GetCountry:(NSString *)pId userid:(NSString *)uId;

-(void)ClaimsToPaySubmit:(NSString *)pId userid:(NSString *)uId  claimID:(NSString *)claimID  payMode:(NSString *)payMode actpCD:(NSString *)actpCD PayeeId:(NSString *)PayeeId;


-(void)IgnoreAllclaim:(NSString *)participantID uID:(NSString *)userID;
-(void)Ignoreclaim:(NSString *)participantID uID:(NSString *)userID pendingClmID:(NSString *)pendingClaimID;
-(void)Paynow:(NSString *)pId userid:(NSString *)uId pendingClmID:(NSString *)cId;
-(void)ShowAllIgnoreclaim:(NSString *)participantID uID:(NSString *)userID;
-(void)UploadImage:(NSString *)pId 
			userid:(NSString *)uId 
		   imgData:(NSString *)Imagedata 
		   imgName:(NSString *)ImageName 
			trxnID:(NSString *)trxn_ID 
			 clmID:(NSString *)clm_ID;


-(void)callfromSelectpayee:(NSString *)participantID uID:(NSString *)userID claimCaty:(NSString *)claimCategory claimtpe:(NSString *)claimtype  amt:(NSString *)amount 
				   SerBedt:(NSString *)serviceBeginDt 
				   SerEedt:(NSString *)serviceEndDt
					  Note:(NSString *)note
					isPrYr:(NSString *)isPriorYear
				   payMode:(NSString *)payMode
			  providerName:(NSString *) providerName
			  accountvalue:(NSString *)actpCD
				   claimID:(NSString *)claimID
				   PayeeId:(NSString *)PayeeId allowDuplicateClaim:(NSString *)allowDuplicateClaim
					opcode:(NSString *)opcode;


@end
