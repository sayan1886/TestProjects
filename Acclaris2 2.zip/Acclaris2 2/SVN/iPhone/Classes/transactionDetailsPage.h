//
//  transactionDetailsPage.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 20/10/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@class configurables;
@interface transactionDetailsPage : UIViewController<UITableViewDelegate,UITableViewDataSource> {

	NSInteger selectedRow;
	NSArray *arr_celltytle,*arr_celldetails;
	configurables *con;
	NSMutableArray *arr_alltransaction;
	BOOL isInvestment;
	NSString *strFont;
}
-(id)initWithInvestment:(BOOL)value;
-(void)signoutbt;
-(void)createtableview;
-(NSString *)chkvalue:(NSString *)value;
@end
