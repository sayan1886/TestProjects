//
//  alertParser.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 07/12/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import "alertParser.h"
#import "alertsOBJ.h"
NSMutableArray *alertarray;
BOOL hasMoreRecords_alert;
@implementation alertParser
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error
{
	
	NSXMLParser *parser;
	parser = [[NSXMLParser alloc] initWithData:data];
    [parser setDelegate:self];
	[parser setShouldProcessNamespaces:NO];
    [parser setShouldReportNamespacePrefixes:NO];
    [parser setShouldResolveExternalEntities:NO];
    [parser parse];
    NSError *parseError = [parser parserError];
    if (parseError && error) 
	{
        *error = parseError;
    }
	[parser release];
}

-(void)parserDidStartDocument:(NSXMLParser *)parser
{
	alertarray=[[NSMutableArray alloc]init];
	
}		

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
	if (qName)
	{
		elementName = qName;
	}
	
	
	else 
		if([elementName isEqualToString:@"returnCode"])
		{
			contentOfString=[NSMutableString string];
			[contentOfString retain];
			return;		
			
		}
		else 
			if([elementName isEqualToString:@"errorText"])
			{
				contentOfString=[NSMutableString string];
				[contentOfString retain];
				return;		
				
			}
			else 
				if([elementName isEqualToString:@"hasMoreRecords"])
				{
					contentOfString=[NSMutableString string];
					[contentOfString retain];
					return;		
					
				}
			else 
				if([elementName isEqualToString:@"item"])
				{
					myalertsOBJ=[[alertsOBJ alloc]init];
					return;		
					
				}
				else 
					if([elementName isEqualToString:@"label"])
					{
						contentOfString=[NSMutableString string];
						[contentOfString retain];
						return;		
						
					}
					else 
						if([elementName isEqualToString:@"severity"])
						{
							contentOfString=[NSMutableString string];
							[contentOfString retain];
							return;		
							
						}
						else 
							if([elementName isEqualToString:@"imagePath"])
							{
								contentOfString=[NSMutableString string];
								[contentOfString retain];
								return;		
								
							}
							else 
								if([elementName isEqualToString:@"priority"])
								{
									contentOfString=[NSMutableString string];
									[contentOfString retain];
									return;		
									
								}
								else 
									if([elementName isEqualToString:@"genericDescription"])
									{
										contentOfString=[NSMutableString string];
										[contentOfString retain];
										return;		
										
									}
									else 
										if([elementName isEqualToString:@"name"])
										{
											contentOfString=[NSMutableString string];
											[contentOfString retain];
											return;		
											
										}
	
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName     
{	
	if (qName)
	{
        elementName = qName;
		
    }
	
	else 
		if([elementName isEqualToString:@"returnCode"])
		{
			if(contentOfString)
			{
				//[arrm_passArray addObject:contentOfString];
				[contentOfString release];
				contentOfString = nil;
				
				
			}	
			
		}
		else 
			if([elementName isEqualToString:@"errorText"])
			{
				if(contentOfString)
				{
					//[arrm_passArray addObject:contentOfString];
					[contentOfString release];
					contentOfString = nil;
					
					
				}		
				
			}
	
			else 
				if([elementName isEqualToString:@"hasMoreRecords"])
				{
					if(contentOfString)
					{
						if ([contentOfString isEqualToString:@"Yes"])
						{
							hasMoreRecords_alert=YES;
						}
						else {
							hasMoreRecords_alert=NO;	
						}
												
					}		
					
				}
	
			else 
				if([elementName isEqualToString:@"item"])
				{
					
					[alertarray addObject:myalertsOBJ];
					
					
				}
	
				else 
					if([elementName isEqualToString:@"label"])
					{
						if(contentOfString)
						{
							NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
							if ([tempArr count]>1) {
								myalertsOBJ.label=[tempArr objectAtIndex:1];
								myalertsOBJ.label=[tempArr objectAtIndex:0];
							}
							else {
								myalertsOBJ.label=[tempArr objectAtIndex:0];
							}
							
							[contentOfString release];
							contentOfString = nil;
							
							
						}		
						
					}
					else 
						if([elementName isEqualToString:@"severity"])
						{
							if(contentOfString)
							{
								NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
								if ([tempArr count]>1) {
									myalertsOBJ.severity=[tempArr objectAtIndex:1];
									myalertsOBJ.severity=[tempArr objectAtIndex:0];
								}
								else {
									myalertsOBJ.severity=[tempArr objectAtIndex:0];
								}

								[contentOfString release];
								contentOfString = nil;
								
							}	
							
						}
						else 
							if([elementName isEqualToString:@"imagePath"])
							{
								if(contentOfString)
								{
									NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
									if ([tempArr count]>1) {
										myalertsOBJ.imagePath=[tempArr objectAtIndex:1];
										myalertsOBJ.imagePath=[tempArr objectAtIndex:0];
									}
									else {
										myalertsOBJ.imagePath=[tempArr objectAtIndex:0];
									}
									[contentOfString release];
									contentOfString = nil;
									
									
								}	
								
							}
							else 
								if([elementName isEqualToString:@"priority"])
								{
									if(contentOfString)
									{
										NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
										if ([tempArr count]>1) {
											myalertsOBJ.priority=[tempArr objectAtIndex:1];
											myalertsOBJ.priority=[tempArr objectAtIndex:0];
										}
										else {
											myalertsOBJ.priority=[tempArr objectAtIndex:0];
										}
										[contentOfString release];
										contentOfString = nil;
										
										
									}	
									
								}
								else 
									if([elementName isEqualToString:@"genericDescription"])
									{
										if(contentOfString)
										{
											NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
											if ([tempArr count]>1) {
												myalertsOBJ.genericDescription=[tempArr objectAtIndex:1];
												myalertsOBJ.genericDescription=[tempArr objectAtIndex:0];
											}
											else {
												myalertsOBJ.genericDescription=[tempArr objectAtIndex:0];
											}
											[contentOfString release];
											contentOfString = nil;
											
											
										}	
										
									}
									else 
										if([elementName isEqualToString:@"name"])
										{
											if(contentOfString)
											{
												NSArray *tempArr=[contentOfString componentsSeparatedByString:@"|"];
												if ([tempArr count]>1) {
													myalertsOBJ.name=[tempArr objectAtIndex:1];
													myalertsOBJ.name=[tempArr objectAtIndex:0];
												}
												else {
													myalertsOBJ.name=[tempArr objectAtIndex:0];
												}
												[contentOfString release];
												contentOfString = nil;
												
												
											}	
											
										}
	
	
	
	
	
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
	if(contentOfString)
		[contentOfString appendString:string];
}

- (void)parserDidEndDocument:(NSXMLParser *)parse
{
	NSLog(@"**********%@",alertarray);
}	
+(NSMutableArray *)alertARRresponce
{
	if (alertarray) {
		
		return alertarray;
	}
	else {
		return nil;
	}
	
}
+(BOOL)gethasMoreRecords_alert
{
	if (hasMoreRecords_alert) {
		
		return hasMoreRecords_alert;
	}
	else {
		return NO;
	}
	
}
@end
