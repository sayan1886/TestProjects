//
//  ticketTypeOBJ.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 08/11/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import "ticketTypeOBJ.h"


@implementation ticketTypeOBJ
@synthesize category;
@synthesize label;
@synthesize note;
@end
