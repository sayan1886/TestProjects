//
//  denialReasonOBJ.m
//  Acclaris
//
//  Created by Ayon on 16/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "denialReasonOBJ.h"


@implementation denialReasonOBJ
@synthesize sequence;
@synthesize text;
@synthesize deniedOn;
@synthesize deniedBy;
@end
