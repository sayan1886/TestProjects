//
//  SelectOptionGoPaperlessOBJ.m
//  Acclaris
//
//  Created by Subhojit on 12/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "SelectOptionGoPaperlessOBJ.h"


@implementation SelectOptionGoPaperlessOBJ
@synthesize strSublabel,strsSubvalue,strsubSelected;
@end
