//
//  passPerser.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 25/10/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RollBasecOBJ.h"
#import "RoleSubOBJ.h"




@interface passPerser : NSObject<NSXMLParserDelegate> {

	NSMutableString *contentOfString;
	RollBasecOBJ *objrole;
	RoleSubOBJ *objsubrole;
	BOOL isSubTab;
	NSInteger count;
	
}
+(NSMutableArray *)passresponce;
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error;
+(NSMutableDictionary *)getRolebaseDict;
@end
