//
//  eCommunicationOBJ.h
//  Acclaris
//
//  Created by Subhojit on 16/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface eCommunicationOBJ : NSObject {

	NSString *strreturnCode;
	NSString *strerrorText;
	NSString *stragreementText;
}
@property(nonatomic,retain)NSString *strreturnCode;
@property(nonatomic,retain)NSString *strerrorText;
@property(nonatomic,retain)NSString *stragreementText;
@end
