    //
//  AddProvider.m
//  Acclaris
//
//  Created by Subhojit on 23/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "AddProvider.h"
#import "configurables.h"
#import "AcclarisViewController.h"


@implementation AddProvider


- (void)viewDidLoad {
    [super viewDidLoad];
	
	isalert=YES;
	
	tools=[[MyTools alloc]init];
	loadingView=[tools createActivityIndicator1];

	userinfo_arr=[passPerser passresponce];
	NSMutableArray *arr_myconfig=[AcclarisViewController staticarr_config];
	con=(configurables *)[arr_myconfig objectAtIndex:0];
	self.view.backgroundColor = [UIColor colorWithRed:con.bgRed/255.0f green:con.bgGreen/255.0f blue:con.bgBlue/255.0f alpha:1.0];
	
	self.navigationController.navigationBar.tintColor=[UIColor colorWithRed:con.navbarRed/255.0f green:con.navbarGreen/255.0f blue:con.navbarBlue/255.0f alpha:1.0];
	customMessageList_dict=[[NSUserDefaults standardUserDefaults] objectForKey:@"customMessageList"];

	UIImageView *logo_img = [[UIImageView alloc]initWithFrame:CGRectMake(0, 2, 170, 40)];
	NSData *data=[Base64 decode:con.logoImgdata];
	logo_img.image=	[UIImage imageWithData:[NSData dataWithData:data]];
	self.navigationItem.titleView=logo_img;
	
	
	[self createbar_button];
	
	
	
	/*userinfo=[[NSMutableArray alloc]init];
	NSArray *arrnickcheck=[[NSUserDefaults standardUserDefaults] objectForKey:@"nickname"];
	
	NSLog(@"  USER DETAILS    %@",arrnickcheck);
	
	
	if ([arrnickcheck count]>0)
	{
		txtNickName.text=[arrnickcheck objectAtIndex:0];
		if([[arrnickcheck objectAtIndex:1]isEqualToString:@"yes"])
			[btn_Remember_Me setBackgroundImage:[UIImage imageNamed:@"check-box.png"] forState:UIControlStateNormal];
		else
			[btn_Remember_Me setBackgroundImage:[UIImage imageNamed:@"uncheck_box.png"] forState:UIControlStateNormal];
	}
	else
		[btn_Remember_Me setBackgroundImage:[UIImage imageNamed:@"uncheck_box.png"] forState:UIControlStateNormal];*/
	
	
	[self GetCountryRequest];
	
	
	
}

-(void)GetStateRequest

{
	
	
	RequestPhase2 *objrequestPhase2=[[RequestPhase2 alloc] initWithTarget:self
															SuccessAction:@selector(onSuccesfulstate)
															FailureAction:@selector(onFailurestate)];
	
	[objrequestPhase2 GetState:[userinfo_arr objectAtIndex:2] userid:[userinfo_arr objectAtIndex:4] countryCode:((CountryOBJ *)[arrCountrydetail objectAtIndex:SelectedRowcountry]).strvalue1];
	
	[objrequestPhase2 release];
	
	[tools startLoading:self.view childView:loadingView text:@"Loading your Claim activity. Wait…."];
	
}
-(void)GetCountryRequest

{
	
	RequestPhase2 *objrequestPhase2=[[RequestPhase2 alloc] initWithTarget:self
															SuccessAction:@selector(onSuccesfulcountry)
															FailureAction:@selector(onFailurestate)];
	
	[objrequestPhase2 GetCountry:[userinfo_arr objectAtIndex:2] userid:[userinfo_arr objectAtIndex:4]];
	
	[objrequestPhase2 release];
	
	[tools startLoading:self.view childView:loadingView text:@"Loading your Claim activity. Wait…."];
	
}

-(void)onSuccesfulcountry

{
 
    [tools stopLoading:loadingView];
	
	arrCountrydetail=[CountryParser getarrCountry];
	arrCountryPicker=[[NSMutableArray alloc]init];
	for(int i=0;i<[arrCountrydetail count];i++)
	{
		[arrCountryPicker addObject:((CountryOBJ *)[arrCountrydetail objectAtIndex:i]).strvalue2];			
		
	}
	
	NSLog(@"arrCountryPicker %@",arrCountryPicker);
	
	[self CreateView];
	
 
}
-(void)onSuccesfulstate
{
	
	[tools stopLoading:loadingView];
	
	arrStatedetail=[StateParser getarrState];
	arrStatePicker=[[NSMutableArray alloc]init];
	for(int i=0;i<[arrStatedetail count];i++)
	{
		[arrStatePicker addObject:((StateOBJ *)[arrStatedetail objectAtIndex:i]).strvalue2];			
		
	}
	iscountry=YES;
	NSLog(@"arrStatePicker %@",arrStatePicker);
	
	[self Vanishpicker];
	[self createbarbuttondone];
	[self CreatePickerView];
	
	
}

-(void)onFailurestate
{
	
	[tools stopLoading:loadingView];
	
}


-(void)createbar_button
{
	
	UIBarButtonItem *signoutButton = [[UIBarButtonItem alloc]
									  initWithTitle:@"Sign Off"
									  style:UIBarButtonItemStyleBordered
									  target:self
									  action:@selector(signout)];
	self.navigationItem.rightBarButtonItem =signoutButton;
	
	
}



-(void)signout
{
	[((AcclarisAppDelegate *)[[UIApplication sharedApplication] delegate]) removeTabBar];
}
-(void)CreateView
{
	
	NSString *strFont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];
	NSData *data_btnimg=[Base64 decode:con.btnImgdata];//btn background image

	UIView *HeaderView=[[[UIView alloc]initWithFrame:CGRectMake(0, 0, 320, 60)]autorelease];
	HeaderView.backgroundColor=[UIColor colorWithRed:con.bgRed2/255.0 green:con.bgGreen2/255.0 blue:con.bgBlue2/255.0 alpha:1.0];
	[self.view addSubview:HeaderView];
	
	NSString *strViewTitle=@"Add Service Provider";//@"Enter Details for New Payee";
	//strViewTitle=[strViewTitle stringByAppendingString:@"\n"];
	//strViewTitle=[strViewTitle stringByAppendingFormat:@"%@",@"Payee"];
	
	UILabel *lbltext=[[UILabel alloc]initWithFrame:CGRectMake(10, 5, 290, 60)];
	lbltext.text=strViewTitle;
	lbltext.backgroundColor=[UIColor clearColor];
	lbltext.textColor=[UIColor whiteColor];
	//lbltext.numberOfLines=0;
	lbltext.font=[UIFont fontWithName:strFont size:con.headerImpfntsize];
	[HeaderView addSubview:lbltext];
	[lbltext release],lbltext=nil;
	
	
	
		
	
	table=[[UITableView alloc]initWithFrame:CGRectMake(0, 65, 320, 250) style:UITableViewStylePlain];
	table.backgroundColor = [UIColor clearColor];
	table.bounces = YES;
	table.delegate=self;
	table.dataSource=self;
	table.separatorColor=[UIColor clearColor];
	[self.view addSubview:table];
	
	
	
	UIButton *btnContinue=[UIButton buttonWithType:UIButtonTypeCustom];
	btnContinue.frame=CGRectMake(30, 320, 260, 40);
	[btnContinue setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
	[btnContinue setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	btnContinue.titleLabel.font = [UIFont fontWithName:con.btnfontname size:con.btnfontsize];
	[btnContinue setTitle:@"Continue" forState:UIControlStateNormal];
	[btnContinue addTarget:self action:@selector(ClickbtnContinue) forControlEvents:UIControlEventTouchUpInside];					 
	[self.view addSubview:btnContinue];
	
	
	
	[self constructTableCell];
	
	
}
-(void)ClickbtnContinue

{
	/*if([txtNickName.text isEqualToString:@""])
	{
		UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:@"Info!" 
															  message:@"Enter Nickname" 
															 delegate:self 
													cancelButtonTitle:@"OK" 
													otherButtonTitles:nil];
		[alertWarning show];
		[alertWarning release];
		
	}*/
	
	 if([txtName.text isEqualToString:@""])
	{
		
		NSString *strmessage=[[customMessageList_dict valueForKey:@"200065"]valueForKey:@"message"];
		NSString *strtype=[[customMessageList_dict valueForKey:@"200065"]valueForKey:@"type"];
		
		UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:strtype
															  message:strmessage
															 delegate:self 
													cancelButtonTitle:@"OK" 
													otherButtonTitles:nil];
		[alertWarning show];
		[alertWarning release];
		return;
		
	}
	else if([txtEmail.text isEqualToString:@""])
	{
		NSString *strmessage=[[customMessageList_dict valueForKey:@"200050"]valueForKey:@"message"];
		NSString *strtype=[[customMessageList_dict valueForKey:@"200050"]valueForKey:@"type"];
		
		UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:strtype
															  message:strmessage
															 delegate:self 
													cancelButtonTitle:@"OK" 
													otherButtonTitles:nil];
		[alertWarning show];
		[alertWarning release];
		return;
	}
	else  if([txtLine1.text isEqualToString:@""])
	{
		NSString *strmessage=[[customMessageList_dict valueForKey:@"200066"]valueForKey:@"message"];
		NSString *strtype=[[customMessageList_dict valueForKey:@"200066"]valueForKey:@"type"];
		
		UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:strtype
															  message:strmessage
															 delegate:self 
													cancelButtonTitle:@"OK" 
													otherButtonTitles:nil];
		[alertWarning show];
		[alertWarning release];
		return;
		
		
	}
	 else if(txtCity.text.length==0)
	
	
	{
		
		NSString *strmessage=[[customMessageList_dict valueForKey:@"200067"]valueForKey:@"message"];
		NSString *strtype=[[customMessageList_dict valueForKey:@"200067"]valueForKey:@"type"];
		
		UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:strtype
															  message:strmessage
															 delegate:self 
													cancelButtonTitle:@"OK" 
													otherButtonTitles:nil];
		[alertWarning show];
		[alertWarning release];
		return;
		
		
	}
	else if([txtState.text isEqualToString:@""])
		 
		 
	 {
		 NSString *strmessage=[[customMessageList_dict valueForKey:@"200068"]valueForKey:@"message"];
		 NSString *strtype=[[customMessageList_dict valueForKey:@"200068"]valueForKey:@"type"];
		 
		 UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:strtype
															   message:strmessage
															  delegate:self 
													 cancelButtonTitle:@"OK" 
													 otherButtonTitles:nil];
		 [alertWarning show];
		 [alertWarning release];
		 return;
		 
		 
	 }
	
	 else if([txtZip.text isEqualToString:@""])
		 
		 
	 {
		 
		 NSString *strmessage=[[customMessageList_dict valueForKey:@"200069"]valueForKey:@"message"];
		 NSString *strtype=[[customMessageList_dict valueForKey:@"200069"]valueForKey:@"type"];
		 
		 UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:strtype
															   message:strmessage
															  delegate:self 
													 cancelButtonTitle:@"OK" 
													 otherButtonTitles:nil];
		 [alertWarning show];
		 [alertWarning release];
		 return;
		 
	 }
	
	else if([txtcountry.text isEqualToString:@""])
		
		
	{
		
		UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:@"Info!" 
															  message:@"Select Country" 
															 delegate:self 
													cancelButtonTitle:@"OK" 
													otherButtonTitles:nil];
		[alertWarning show];
		[alertWarning release];
		
	}
		
	
	else
		
		{
		
	
		   RequestPhase2 *objrequestPhase2=[[RequestPhase2 alloc] initWithTarget:self
																SuccessAction:@selector(onSuccesful)
																FailureAction:@selector(onFailure)];
		
		  [objrequestPhase2 AddProvider:[userinfo_arr objectAtIndex:2] uID:[userinfo_arr objectAtIndex:4] name:txtName.text	nickName:txtNickName.text firstName:@"" middleName:@""
							   lastName:@""  email:txtEmail.text phone:@"" line1:txtLine1.text line2:txtLine2.text line3:txtLine3.text city:txtCity.text  state:((StateOBJ *)[arrStatedetail objectAtIndex:SelectedRowstate]).strvalue1 zip:txtZip.text country:((CountryOBJ *)[arrCountrydetail objectAtIndex:SelectedRowcountry]).strvalue1];
		
		  [objrequestPhase2 release];
		
		   [tools startLoading:self.view childView:loadingView text:@"Loading your Claim activity. Wait…."];
			
			
		}
	
	
}
-(void)onSuccesful
{
	
	[tools stopLoading:loadingView];
	
	NSString *errortext=[AddproviderParser getstraddprovidererrortext];
	
	if(errortext.length >0)
	{
		UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:@"Sorry!" 
															  message:errortext 
															 delegate:self 
													cancelButtonTitle:@"Ok" 
													otherButtonTitles:nil];
		[alertWarning show];
		[alertWarning release];
		
	}
	else 
	{
		[self.navigationController popViewControllerAnimated:YES];
	}

}
-(void)onFailure
{
	
	
	[tools stopLoading:loadingView];

	
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	
    return 1;
}



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	
	
	return 10;
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	
   	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
	if(nil == cell)
	{
		NSLog(@"%@",[[arrAllSection objectAtIndex:0] objectAtIndex:indexPath.row]);
		cell = [[arrAllSection objectAtIndex:0] objectAtIndex:indexPath.row];
		
	}
	
	
	cell.selectionStyle = UITableViewCellSelectionStyleNone;
	
    return cell;
	
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	
	
	return 45.0;
	
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath

{
	
	
	
}

-(void)constructTableCell
{
	arrAllSection = [[NSMutableArray alloc] init];
	
#pragma mark --First Section
	NSMutableArray *arrFirstSection = [[NSMutableArray alloc]init];
	
	UITableViewCell *cell00 = [[UITableViewCell alloc] init];
	[self NickNameInput:cell00];
	[arrFirstSection addObject:cell00];
	[cell00 release];
	
	UITableViewCell *cell01 = [[UITableViewCell alloc] init];
	[self NameInput:cell01];
	[arrFirstSection addObject:cell01];
	[cell01 release];
	
	UITableViewCell *cell02 = [[UITableViewCell alloc] init];
	[self EmailInput:cell02];
	[arrFirstSection addObject:cell02];
	[cell02 release];
	
	UITableViewCell *cell03 = [[UITableViewCell alloc] init];
	[self Line1Input:cell03];
	[arrFirstSection addObject:cell03];
	[cell03 release];
	
	
	UITableViewCell *cell10 = [[UITableViewCell alloc] init];
	[self Line2Input:cell10];
	[arrFirstSection addObject:cell10];
	[cell10 release];
	
	UITableViewCell *cell11 = [[UITableViewCell alloc] init];
	[self Line3Input:cell11];
	[arrFirstSection addObject:cell11];
	[cell11 release];
	
	
	UITableViewCell *cell12 = [[UITableViewCell alloc] init];
	[self CityInput:cell12];
	[arrFirstSection addObject:cell12];
	[cell12 release];
	
	
	UITableViewCell *cell13 = [[UITableViewCell alloc] init];
	[self StateInput:cell13];
	[arrFirstSection addObject:cell13];
	[cell13 release];
	
	UITableViewCell *cell14 = [[UITableViewCell alloc] init];
	[self ZipInput:cell14];
	[arrFirstSection addObject:cell14];
	[cell14 release];
		
		
	
	UITableViewCell *cell15 = [[UITableViewCell alloc] init];
	[self CountryInput:cell15];
	[arrFirstSection addObject:cell15];
	[cell15 release];
	
	
	[arrAllSection addObject:arrFirstSection];
	[arrFirstSection release];
	
}
-(void)NickNameInput:(UITableViewCell *)cell
{
	UILabel *lblNickName = [[UILabel alloc]initWithFrame:CGRectMake(10,0,85,35)];
	lblNickName.backgroundColor = [UIColor clearColor];
	lblNickName.text=@"NickName";
	lblNickName.font = [UIFont fontWithName:@"Helvetica-Bold" size:15];
	lblNickName.textAlignment = UITextAlignmentLeft;
	lblNickName.textColor=[UIColor blackColor];
	[cell.contentView addSubview:lblNickName];
	[lblNickName release], lblNickName = nil;	
	
	txtNickName = [[UITextField alloc]initWithFrame:CGRectMake(100,5,90,27)];
	txtNickName.backgroundColor = [UIColor whiteColor];
	txtNickName.autocorrectionType = UITextAutocorrectionTypeNo;
	txtNickName.text=@"";
	txtNickName.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	txtNickName.keyboardType=UIKeyboardTypeDefault;
	txtNickName.delegate=self;
	txtNickName.borderStyle = UITextBorderStyleLine;
	[focusArray addObject:txtNickName];
	
	btn_Remember_Me=[UIButton buttonWithType:UIButtonTypeCustom];
	btn_Remember_Me.frame = CGRectMake(195,8,22,22);
	//[btn_Remember_Me setBackgroundImage:[UIImage imageNamed:@"uncheck_box.png"] forState:UIControlStateNormal];check-box.png
	[btn_Remember_Me setBackgroundImage:[UIImage imageNamed:@"check-box.png"] forState:UIControlStateNormal];
    [btn_Remember_Me addTarget:self action:@selector(btn_RememberMe_Clicked:) forControlEvents:UIControlEventTouchUpInside];
    [btn_Remember_Me setTag:1];
	[focusArray addObject:btn_Remember_Me];
	
	
	UILabel *lblsave=[[UILabel alloc]initWithFrame:CGRectMake(222,0, 100, 40)];
	lblsave.text=@"save for future use";
	lblsave.font=[UIFont fontWithName:@"Helvetica" size:11];
	lblsave	.backgroundColor=[UIColor clearColor]; 
	[cell.contentView addSubview:lblsave];		 
	
	[cell.contentView addSubview:btn_Remember_Me];
	
	
	
	[cell.contentView addSubview:txtNickName];			
	
}

#pragma mark -
#pragma mark emailInput Method

-(void)NameInput:(UITableViewCell *)cell
{
	
	UILabel *lblName2 = [[UILabel alloc]initWithFrame:CGRectMake(10,5,85,35)];
	lblName2.backgroundColor = [UIColor clearColor];
	lblName2.text=@"Name";
	lblName2.font = [UIFont fontWithName:@"Helvetica-Bold" size:15];
	lblName2.textAlignment = UITextAlignmentLeft;
	lblName2.textColor=[UIColor blackColor];
	[cell.contentView addSubview:lblName2];
	[lblName2 release], lblName2 = nil;	
	
	txtName = [[UITextField alloc]initWithFrame:CGRectMake(100,5,200,27)];
	txtName.backgroundColor = [UIColor whiteColor];
	txtName.autocorrectionType = UITextAutocorrectionTypeNo;
	txtName.text=@"";
	txtName.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	txtName.keyboardType=UIKeyboardTypeDefault;
	txtName.delegate=self;
	txtName.borderStyle = UITextBorderStyleLine;
	[focusArray addObject:txtName];
	
	[cell.contentView addSubview:txtName];
}
-(void)EmailInput:(UITableViewCell *)cell
{
	UILabel *lblEmail = [[UILabel alloc]initWithFrame:CGRectMake(10,5,85,35)];
	lblEmail.backgroundColor = [UIColor clearColor];
	lblEmail.text=@"Email";
	lblEmail.font = [UIFont fontWithName:@"Helvetica-Bold" size:15];
	lblEmail.textAlignment = UITextAlignmentLeft;
	lblEmail.textColor=[UIColor blackColor];
	[cell.contentView addSubview:lblEmail];
	[lblEmail release], lblEmail = nil;
	
	
	txtEmail = [[UITextField alloc]initWithFrame:CGRectMake(100,5,200,27)];
	txtEmail.backgroundColor = [UIColor whiteColor];
	txtEmail.autocorrectionType = UITextAutocorrectionTypeNo;
	txtEmail.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	txtEmail.text=@"";
	txtEmail.keyboardType=UIKeyboardTypeEmailAddress;
	txtEmail.delegate=self;
	txtEmail.borderStyle = UITextBorderStyleLine;
	[focusArray addObject:txtEmail];
	
	[cell.contentView addSubview:txtEmail];
	
	
}
-(void)Line1Input:(UITableViewCell *)cell
{
	UILabel *lblLine1 = [[UILabel alloc]initWithFrame:CGRectMake(10,5,85,35)];
	lblLine1.backgroundColor = [UIColor clearColor];
	lblLine1.text=@"Line1";
	lblLine1.font = [UIFont fontWithName:@"Helvetica-Bold" size:15];
	lblLine1.textAlignment = UITextAlignmentLeft;
	lblLine1.textColor=[UIColor blackColor];
	[cell.contentView addSubview:lblLine1];
	[lblLine1 release], lblLine1 = nil;
	
	
	txtLine1 = [[UITextField alloc]initWithFrame:CGRectMake(100,5,200,27)];
	txtLine1.backgroundColor = [UIColor whiteColor];
	txtLine1.autocorrectionType = UITextAutocorrectionTypeNo;
	txtLine1.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	txtLine1.text=@"";
	txtLine1.keyboardType=UIKeyboardTypeDefault;
	txtLine1.delegate=self;
	txtLine1.borderStyle = UITextBorderStyleLine;
	[focusArray addObject:txtLine1];
	
	[cell.contentView addSubview:txtLine1];
	
	
}

-(void)Line2Input:(UITableViewCell *)cell
{
	UILabel *lblLine2 = [[UILabel alloc]initWithFrame:CGRectMake(10,5,85,35)];
	lblLine2.backgroundColor = [UIColor clearColor];
	lblLine2.text=@"Line2";
	lblLine2.font = [UIFont fontWithName:@"Helvetica-Bold" size:15];
	lblLine2.textAlignment = UITextAlignmentLeft;
	lblLine2.textColor=[UIColor blackColor];
	[cell.contentView addSubview:lblLine2];
	[lblLine2 release], lblLine2 = nil;
	
	
	txtLine2 = [[UITextField alloc]initWithFrame:CGRectMake(100,5,200,27)];
	txtLine2.backgroundColor = [UIColor whiteColor];
	txtLine2.autocorrectionType = UITextAutocorrectionTypeNo;
	txtLine2.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	txtLine2.text=@"";
	txtLine2.keyboardType=UIKeyboardTypeDefault;
	txtLine2.delegate=self;
	txtLine2.borderStyle = UITextBorderStyleLine;
	[focusArray addObject:txtLine2];
	
	[cell.contentView addSubview:txtLine2];
	
	
}
-(void)Line3Input:(UITableViewCell *)cell
{
	UILabel *lblLine3 = [[UILabel alloc]initWithFrame:CGRectMake(10,5,85,35)];
	lblLine3.backgroundColor = [UIColor clearColor];
	lblLine3.text=@"Line3";
	lblLine3.font = [UIFont fontWithName:@"Helvetica-Bold" size:15];
	lblLine3.textAlignment = UITextAlignmentLeft;
	lblLine3.textColor=[UIColor blackColor];
	[cell.contentView addSubview:lblLine3];
	[lblLine3 release], lblLine3 = nil;
	
	
	txtLine3 = [[UITextField alloc]initWithFrame:CGRectMake(100,5,200,27)];
	txtLine3.backgroundColor = [UIColor whiteColor];
	txtLine3.autocorrectionType = UITextAutocorrectionTypeNo;
	txtLine3.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	txtLine3.text=@"";
	txtLine3.keyboardType=UIKeyboardTypeDefault;
	txtLine3.delegate=self;
	txtLine3.borderStyle = UITextBorderStyleLine;
	[focusArray addObject:txtLine3];
	
	[cell.contentView addSubview:txtLine3];
	
	
}


#pragma mark -
#pragma mark DOBInput Method

-(void)CountryInput:(UITableViewCell *)cell
{
	UILabel *lblcountry = [[UILabel alloc]initWithFrame:CGRectMake(10,5,85,35)];
	lblcountry.backgroundColor = [UIColor clearColor];
	lblcountry.text=@"Country";
	lblcountry.font = [UIFont fontWithName:@"Helvetica-Bold" size:15];
	lblcountry.textAlignment = UITextAlignmentLeft;
	lblcountry.textColor=[UIColor blackColor];
	[cell.contentView addSubview:lblcountry];
	[lblcountry release], lblcountry = nil;	
	
	txtcountry = [[UITextField alloc]initWithFrame:CGRectMake(100,5,200,27)];
	txtcountry.backgroundColor = [UIColor whiteColor];
	txtcountry.autocorrectionType = UITextAutocorrectionTypeNo;
	
	

	txtcountry.text=[arrCountryPicker objectAtIndex:0];	
	txtcountry.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	txtcountry.keyboardType=UIKeyboardTypeDefault;
	txtcountry.delegate=self;
	txtcountry.borderStyle = UITextBorderStyleLine;
	[focusArray addObject:txtcountry];
	
	[cell.contentView addSubview:txtcountry];
}


-(void)CityInput:(UITableViewCell *)cell
{
	UILabel *lblCity = [[UILabel alloc]initWithFrame:CGRectMake(10,5,85,35)];
	lblCity.backgroundColor = [UIColor clearColor];
	lblCity.text=@"City";
	lblCity.font = [UIFont fontWithName:@"Helvetica-Bold" size:15];
	lblCity.textAlignment = UITextAlignmentLeft;
	lblCity.textColor=[UIColor blackColor];
	[cell.contentView addSubview:lblCity];
	[lblCity release], lblCity = nil;
	
	txtCity = [[UITextField alloc]initWithFrame:CGRectMake(100,5,200,27)];
	txtCity.backgroundColor = [UIColor whiteColor];
	txtCity.autocorrectionType = UITextAutocorrectionTypeNo;
	txtCity.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	txtCity.text=@"";
	txtCity.keyboardType=UIKeyboardTypeDefault;
	txtCity.delegate=self;
	txtCity.borderStyle = UITextBorderStyleLine;
	[focusArray addObject:txtCity];
	
	[cell.contentView addSubview:txtCity];
}

#pragma mark -
#pragma mark ageUpperInput Method

-(void)StateInput:(UITableViewCell *)cell
{
	UILabel *lblState = [[UILabel alloc]initWithFrame:CGRectMake(10,5,85,35)];
	lblState.backgroundColor = [UIColor clearColor];
	lblState.text=@"State";
	lblState.font = [UIFont fontWithName:@"Helvetica-Bold" size:15];
	lblState.textAlignment = UITextAlignmentLeft;
	lblState.textColor=[UIColor blackColor];
	[cell.contentView addSubview:lblState];
	[lblState release], lblState = nil;
	
	txtState = [[UITextField alloc]initWithFrame:CGRectMake(100,5,200,27)];
	txtState.backgroundColor = [UIColor whiteColor];
	txtState.autocorrectionType = UITextAutocorrectionTypeNo;
	txtState.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	txtState.text=@"";
	txtState.keyboardType=UIKeyboardTypeDefault;
	txtState.delegate=self;
	txtState.borderStyle = UITextBorderStyleLine;
	[focusArray addObject:txtState];
	
	[cell.contentView addSubview:txtState];
	
}

#pragma mark -
#pragma mark AgeLowerInput Method

-(void)ZipInput:(UITableViewCell *)cell
{
	UILabel *lblZip = [[UILabel alloc]initWithFrame:CGRectMake(10,5,85,35)];
	lblZip.backgroundColor = [UIColor clearColor];
	lblZip.text=@"Zip";
	lblZip.font = [UIFont fontWithName:@"Helvetica-Bold" size:15];
	lblZip.textAlignment = UITextAlignmentLeft;
	lblZip.textColor=[UIColor blackColor];
	[cell.contentView addSubview:lblZip];
	[lblZip release], lblZip = nil;
	
	txtZip = [[UITextField alloc]initWithFrame:CGRectMake(100,5,200,27)];
	txtZip.backgroundColor = [UIColor whiteColor];
	txtZip.autocorrectionType = UITextAutocorrectionTypeNo;
	txtZip.text=@"";
	txtZip.keyboardType=UIKeyboardTypeNumbersAndPunctuation;
	txtZip.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	txtZip.keyboardType=UIKeyboardTypeNumbersAndPunctuation;
	txtZip.delegate=self;
	txtZip.borderStyle = UITextBorderStyleLine;
	
	[focusArray addObject:txtZip];
	
	[cell.contentView addSubview:txtZip];
	
}
-(void)btn_RememberMe_Clicked:(id)sender
{
	//UIButton *myButton = (UIButton *)sender;
	if(btn_Remember_Me.currentBackgroundImage==[UIImage imageNamed:@"uncheck_box.png"])
		
	{		
		[btn_Remember_Me setBackgroundImage:[UIImage imageNamed:@"check-box.png"]forState:UIControlStateNormal];
		
		
		
		/*[userinfo removeAllObjects];
		 [userinfo addObject:txtNickName.text];
		 
		 [userinfo addObject:@"yes"];
		 [[NSUserDefaults standardUserDefaults] setObject:(NSArray*)userinfo forKey:@"nickname"];
		 [[NSUserDefaults standardUserDefaults] synchronize];*/
	}
	
	else
	{
		[btn_Remember_Me setBackgroundImage:[UIImage imageNamed:@"uncheck_box.png"]forState:UIControlStateNormal];
		
        
		/*[userinfo removeAllObjects];
		 [userinfo addObject:@""];
		 [userinfo addObject:@""];
		 [userinfo addObject:@"no"];
		 [[NSUserDefaults standardUserDefaults] setObject:(NSArray*)userinfo forKey:@"nickname"];
		 [[NSUserDefaults standardUserDefaults] synchronize];*/
		
	}
	
	
}
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component;
{
	
	NSString *str=@"";
	
	if([strTxtNm isEqualToString:@"txtState"])
	{
		txtState.text=[str stringByAppendingFormat:@"%@",[arrStatePicker objectAtIndex:[pickerView selectedRowInComponent:0]]];
		SelectedRowstate=row;

	}
	else 
	{
		txtcountry.text=[str stringByAppendingFormat:@"%@",[arrCountryPicker objectAtIndex:[pickerView selectedRowInComponent:0]]];
	
        SelectedRowcountry=row;
		
		
		
		
	}
	
	//[pickerView removeFromSuperview];
	
	
}
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
	
	if([strTxtNm isEqualToString:@"txtState"])
		
	       return [arrStatePicker objectAtIndex:row];
	else 
	    
		 return [arrCountryPicker objectAtIndex:row];

	
}

- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component
{
	// first column size is wider to hold names
	
	return 150.0;                     // second column is narrower to show numbers
	
}

- (CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component
{
	return 40.0;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
	
	if([strTxtNm isEqualToString:@"txtState"])
		
	        return [arrStatePicker count];
	else 
		
	      return [arrCountryPicker count];

	
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
	return 1;
	
}
-(void)CreatePickerView
{
	
	
	myPickerView = [[UIPickerView alloc] initWithFrame:CGRectMake(0, 210, 180, 150)];
	myPickerView.showsSelectionIndicator = YES;
	myPickerView.delegate = self;
	[self.view addSubview:myPickerView];
	
}
-(void)Vanishpicker
{
	if(myPickerView)
	{
		[myPickerView removeFromSuperview];
	    [myPickerView release],myPickerView=nil;
	}
	else 
	{
		;
	}
	
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
	

	
	if(textField==txtState && isalert==YES)
	{
		if(txtcountry.text.length==0)
		{
			[txtLine3 resignFirstResponder];
			strTxtNm=@"txtState";
			UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:@"Info!" 
																  message:@"First select country" 
																 delegate:self 
														cancelButtonTitle:@"Ok" 
														otherButtonTitles:nil];
			[alertWarning show];
			[alertWarning release];
			return NO;
			isalert=NO;
			
		}
		else 
		{
			
			[txtLine3 resignFirstResponder]; 
			strTxtNm=@"txtState";
			if(iscountry==NO)
			{
			   [self GetStateRequest];
				
			}
			else 
			{
				[self Vanishpicker];
				[self createbarbuttondone];
				[self CreatePickerView];
			}

			return NO;
			
		}
	}
	
	else if(textField==txtcountry)
	{
		iscountry=NO;
		[txtLine3 resignFirstResponder];
		txtState.text=@"";
		strTxtNm=@"txtcountry";
		[self Vanishpicker];
		[self  createbarbuttondone];
		[self CreatePickerView];
		table.frame=CGRectMake(0, 65, 320, 200);
		[table scrollRectToVisible:CGRectMake(0, 65, 320, 480) animated:YES];
		return NO;
	}
	else if(textField==txtEmail)
	{
		
		[table scrollRectToVisible:CGRectMake(0, 65, 320, 290) animated:YES];
	}
	else if(textField==txtLine2)
	{
		[table scrollRectToVisible:CGRectMake(0, 65, 320, 350) animated:YES];
	}
	else if(textField==txtLine3)
	{
		[table scrollRectToVisible:CGRectMake(0, 65, 320, 400) animated:YES];
	}
	else if(textField==txtZip)
	{
		[self Vanishpicker];
		table.frame=CGRectMake(0, 65, 320,140);
		[table scrollRectToVisible:CGRectMake(0, 65, 320, 480) animated:YES];
	}
	
	//[table scrollRectToVisible:CGRectMake(0, 65, 320, 300) animated:YES];
	return YES;
}
- (void)textFieldDidEndEditing:(UITextField *)textField
{
	
	if(textField==txtcountry)
	   
	   {
		   
		   UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:@"Info!" 
																 message:@"Now select the State" 
																delegate:self 
													   cancelButtonTitle:@"OK" 
													   otherButtonTitles:nil];
		   [alertWarning show];
		   [alertWarning release];
		   
	   }
	
}
- (BOOL)textFieldShouldEndEditing:(UITextField *)textField
{
	if(textField==txtcountry)
	   
	   {
		   
		   UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:@"Info!" 
																 message:@"Now select the State" 
																delegate:self 
													   cancelButtonTitle:@"OK" 
													   otherButtonTitles:nil];
		   [alertWarning show];
		   [alertWarning release];
		   
	   }
	   
	[textField resignFirstResponder];
	return YES;
	
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
	if(textField==txtEmail)
	{
		
		
		BOOL check=[self validateEmail:txtEmail.text];
		if(!check)
		{
			
			NSString *strmessage=[[customMessageList_dict valueForKey:@"200052"]valueForKey:@"message"];
			NSString *strtype=[[customMessageList_dict valueForKey:@"200052"]valueForKey:@"type"];
			
			UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:strtype 
																  message:strmessage 
																 delegate:self 
														cancelButtonTitle:@"OK" 
														otherButtonTitles:nil];
			[alertWarning show];
			[alertWarning release];
			
		}

		else 
		{
			NSArray *arr=[textField.text componentsSeparatedByString:@".@"];
			if([arr	 count]==2)
			{
				NSString *strmessage=[[customMessageList_dict valueForKey:@"200052"]valueForKey:@"message"];
				NSString *strtype=[[customMessageList_dict valueForKey:@"200052"]valueForKey:@"type"];
				UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:strtype 
																	  message:strmessage 
																	 delegate:self 
															cancelButtonTitle:@"OK" 
															otherButtonTitles:nil];
				[alertWarning show];
				[alertWarning release];
				
				
			}
			else 
			{
				
			}

		}
		
	}
		
	[textField resignFirstResponder];
	table.frame=CGRectMake(0, 65, 320, 255);
	return YES;
	
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string 
{
	
	
	
	if(textField==txtZip)
		
	{
		NSString *newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
		if([newString length]>5)
		   {
			   
			   return NO;
		   }
		else if([string isEqualToString:@"E"])
		{
			
			return NO;
		}
		else if([string isEqualToString:@"."])
		{
			return NO;
		}

		else if ([string isEqualToString:@"e"]) 
		{
			return NO;
		}
		
		else if([string isEqualToString:@" "])
		{
			
			return NO;
		}
				
		else 
			
		{
			
			NSString *resultingString = [textField.text stringByReplacingCharactersInRange:range withString: string];
			
			if ([resultingString length] == 0) 
				
			{
				
				return true;
				
			}
			
			NSDecimal holder;
			
			NSScanner *scan = [NSScanner scannerWithString: resultingString];
			
			return [scan scanDecimal:&holder] && [scan isAtEnd];
			
			
	    }
	}
	
	return YES;
	
	
}

-(void)createbarbuttondone
{
	
	UIBarButtonItem *doneButton = [[UIBarButtonItem alloc]
								   initWithTitle:@"Done"
								   style:UIBarButtonItemStyleBordered
								   target:self
								   action:@selector(donecancel)];
	
	
    self.navigationItem.rightBarButtonItem =doneButton;
	
	
}

-(void)donecancel
{
	table.frame=CGRectMake(0, 65, 320, 250);
	[self  createbar_button];
	[self Vanishpicker];
		
}

-(BOOL)validateEmail:(NSString *)email
{ 
	BOOL stricterFilter = YES; // Discussion http://blog.logichigh.com/2010/09/02/validating-an-e-mail-address/
	NSString *stricterFilterString = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
	NSString *laxString = @".+@.+\\.[A-Za-z]{2}[A-Za-z]*";
	NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
	NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
	return [emailTest evaluateWithObject:email];
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
	txtNickName=nil;
	txtName=nil;
	txtAddress=nil;
	txtCity=nil;
	txtState=nil;
	txtStreet=nil;
	txtZip=nil;
	txtEmail=nil;
	myPickerView=nil;
}


- (void)dealloc {
	[txtNickName release];
	[txtName release];
	[txtAddress release];
	[txtCity release];
	[txtState release];
	[txtStreet release];
	[txtZip release];
	[txtEmail release];
	[myPickerView release];
    [super dealloc];
}


@end
