//
//  InvestmentObj.h
//  Acclaris
//
//  Created by Sumit Kr Prasad on 31/12/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface InvestmentObj : NSObject 
{
	NSString *date, *lblDate;
	NSString *transactionCode, *lblTransactionCode;
	NSString *investmentName, *lblInvestmentName;
	NSString *units, *lblUnits;
	NSString *price, *lblPrice;
	NSString *amount, *lblAmount;
	NSString *transactionStatus, *lblTransactionStatus;
	NSString *contributionType , *lblContributionType;
	NSString *optyprDesc, *lblOptyprDesc;
	NSString *planID ,*lblPlanID;
	NSString *sequence, *lblSequence;
	NSString *sourceNum, *lblSourceNum;
	NSString *activityType, *lblActivityType;
	NSString *transactionType, *lblTransactionType;
}
@property (retain, nonatomic) NSString *date;
@property (retain, nonatomic) NSString *lblDate;
@property (retain, nonatomic) NSString *transactionCode;
@property (retain, nonatomic) NSString *lblTransactionCode;
@property (retain, nonatomic) NSString *investmentName;
@property (retain, nonatomic) NSString *lblInvestmentName;
@property (retain, nonatomic) NSString *units;
@property (retain, nonatomic) NSString *lblUnits;
@property (retain, nonatomic) NSString *price;
@property (retain, nonatomic) NSString *lblPrice;
@property (retain, nonatomic) NSString *amount;
@property (retain, nonatomic) NSString *lblAmount;
@property (retain, nonatomic) NSString *transactionStatus;
@property (retain, nonatomic) NSString *lblTransactionStatus;
@property (retain, nonatomic) NSString *contributionType;
@property (retain, nonatomic) NSString *lblContributionType;
@property (retain, nonatomic) NSString *optyprDesc;
@property (retain, nonatomic) NSString *lblOptyprDesc;
@property (retain, nonatomic) NSString *planID;
@property (retain, nonatomic) NSString *lblPlanID;
@property (retain, nonatomic) NSString *sequence;
@property (retain, nonatomic) NSString *lblSequence;
@property (retain, nonatomic) NSString *sourceNum;
@property (retain, nonatomic) NSString *lblSourceNum;
@property (retain, nonatomic) NSString *activityType;
@property (retain, nonatomic) NSString *lblActivityType;
@property (retain, nonatomic) NSString *transactionType;
@property (retain, nonatomic) NSString *lblTransactionType;
@end
