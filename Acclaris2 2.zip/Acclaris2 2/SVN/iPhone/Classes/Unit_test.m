    //
//  Unit_test.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 04/11/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import "Unit_test.h"
#import "request.h"
#import <QuartzCore/CALayer.h>
#import "UserresponcePerser.h"
#import "passPerser.h"
#import "ticketPerser.h"
#import "transactionPerser.h"
#import "claimactivityPerser.h"
#import "imagePerser.h"
#import "errorcodeOBJ.h"
#import "accPerser.h"
#import "ClaimSubmitNewParser.h"
#import "Claimonlineserviceparser.h"
#import "UnsubmittedClaimParser.h"
#import "SubmitclaimParser.h"
#import "errorParser.h"
#import "PaynowParser.h"
#import "PaynowcontinueParser.h"
#import "Deleteparser.h"
#import "activeScheduleParser.h"
#import "RequestPhase2.h"
#import "RequestPhase2_2.h"
#import "AddEmailParser.h"
#import "GopaperlessParser.h"
#import "eCommunicationParser.h"
#import "ReceiptShowParser.h"

//change here --------------
#define user_name @"prabirkr"
#define user_pass @"prabirmj"
#define participent_id @"2480516"//1477123//2480510//2480516
#define user_id @"794102"//297413//794102
#define election_id @"2318004"//2318003//2994827
#define user_actype @"HCRA"//HCRA
#define start_id @"0"

#define claim_Category @"Medical"
#define claim_type @"DOCTOR"
#define aMount @"0.01"
#define service_BeginDt @"10/20/2010"
#define service_EndDt @"05/25/2011"
#define nOte @"SELF"
#define isPrior_Year @"No"
#define pay_Mode @"Self"
#define provider_Name @"IISSS"
#define account_value @""
#define Payee_Id @""
#define allowDuplicate_Claim @""
#define oPcode @"5001"
#define pending_ClmID @"265510"//265510
#define Claim_id @"77310"//77310
#define no_Of_Record @"10"

#define e_mail @"santanu@gmail.com"

//change here --------------
@implementation Unit_test


/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];

	testname=[[NSArray alloc]initWithObjects:@"test_login1",@"test_login2",@"test_sendaccountRequest",@"test_sendtransactionRequest",@"test_reqTicket",@"test_claimActivityReq",@"test_images",@"test_claimCatagories",@"test_ClaimOnlineServiceSave",@"test_ClaimOnlineServiceSave2",@"test_GetUnSubmittedClaim",@"test_EditUnSubmittedClaim",@"test_EditUnSubmittedClaim2",@"test_SubmitallClaim",@"test_IgnoreAllclaim",@"test_Ignoreclaim",@"test_Paynow",@"test_ShowAllIgnoreclaim",@"test_UploadImage",@"test_ClaimsToPaySubmit",@"test_AddEmail",@"test_AddPhoneNumber",@"test_VerifyEmail",@"test_GetPrimarySummery",@"test_SubmitforeCommunication",@"test_EditAchRequest",@"test_GetCustomText",@"test_ShowImage",@"test_deleteClaim",@"test_sendActiveScheduleRequest",@"test_sendInActiveScheduleRequest",nil];

	
	UIView	*view_message_textview = [[UIView alloc]initWithFrame:CGRectMake(10, 10, 300, 440)];
	view_message_textview.backgroundColor = [UIColor whiteColor];
	view_message_textview.layer.cornerRadius=4;
	view_message_textview.layer.borderWidth=1.5;
	CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();	
	float grayComponents[4] = { 0.3, 0.3, 0.3, 1.0 };
	view_message_textview.layer.borderColor=CGColorCreate(colorSpace, grayComponents);
	[self.view addSubview:view_message_textview];
	
	
	txtv_msgCloseNotes=[[UITextView alloc] initWithFrame:CGRectMake(5, 5, 290, 430)];
    txtv_msgCloseNotes.textColor = [UIColor blackColor];
	txtv_msgCloseNotes.font = [UIFont fontWithName:@"Verdana" size:12];
	txtv_msgCloseNotes.returnKeyType = UIReturnKeyDefault;
	txtv_msgCloseNotes.autocorrectionType=NO;
	txtv_msgCloseNotes.keyboardType = UIKeyboardTypeDefault;
	txtv_msgCloseNotes.backgroundColor=[UIColor whiteColor];
	txtv_msgCloseNotes.keyboardAppearance=UIKeyboardAppearanceAlert;
	txtv_msgCloseNotes.delegate=self;
	[view_message_textview addSubview:txtv_msgCloseNotes];
	
	
	UIButton *test=[UIButton buttonWithType:UIButtonTypeRoundedRect];
	test.frame = CGRectMake(125, 420, 70, 30);
	[test setBackgroundImage:[UIImage imageNamed: @"green-button.png"] forState:UIControlStateNormal];
	test.titleLabel.font = [UIFont fontWithName:@"Verdana" size:10];
	[test setTitle:@"test" forState:UIControlStateNormal];
	[test setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [test addTarget:self action:@selector(populateRadiusPicker) forControlEvents:UIControlEventTouchUpInside];
	[self.view addSubview:test];
	
	viewself=[[UIView alloc]initWithFrame:CGRectMake(0, 460, 320, 240)];
	
		
}
-(void)test_login1
{
	service=0;
	request *r=[[request alloc] initWithTarget:self
								 SuccessAction:@selector(onSucceffulLogin)
								 FailureAction:@selector(onFailureLogin)];
	
	
	
	[r senduserRequest:user_name];
	[r release];
	
	
}
-(void)test_login2
{
	service=1;
	request *r=[[request alloc] initWithTarget:self
								 SuccessAction:@selector(onSucceffulLogin)
								 FailureAction:@selector(onFailureLogin)];
	
	
	
	[r sendpassRequest:user_name pass:user_pass];
	[r release];
	
	
}
-(void)test_sendaccountRequest
{
	service=2;
	request *r=[[request alloc] initWithTarget:self
								 SuccessAction:@selector(onSucceffulLogin)
								 FailureAction:@selector(onFailureLogin)];
	
	
	
	[r sendaccountRequest:participent_id userid:user_id];
	[r release];
	
	
}
-(void)test_sendtransactionRequest
{
	service=3;
	request *r=[[request alloc] initWithTarget:self
								 SuccessAction:@selector(onSucceffulLogin)
								 FailureAction:@selector(onFailureLogin)];
	
	
	
	[r sendtransactionRequest:participent_id userid:user_id election:election_id actype:user_actype];
	[r release];
	
	
}
-(void)test_reqTicket
{
	service=4;
	request *r=[[request alloc] initWithTarget:self
								 SuccessAction:@selector(onSucceffulLogin)
								 FailureAction:@selector(onFailureLogin)];
	[r sendticketRequest:@"0" participentid:participent_id userid:user_id];
	[r release];
}
-(void)test_claimActivityReq
{
	service=5;
	request *r=[[request alloc] initWithTarget:self
								 SuccessAction:@selector(onSucceffulLogin)
								 FailureAction:@selector(onFailureLogin)];
	[r claimactivityRequest:@"0" participentid:participent_id userid:user_id];
	[r release];
		
}

-(void)test_images
{
	service=6;
	request *r=[[request alloc] initWithTarget:self
								 SuccessAction:@selector(onSucceffulLogin)
								 FailureAction:@selector(onFailureLogin)];
	[r req_images:participent_id userid:user_id startid:start_id];
	[r release];
	
}
-(void)test_claimCatagories
{
	service=7;
	RequestPhase2 *r=[[RequestPhase2 alloc] initWithTarget:self
								 SuccessAction:@selector(onSucceffulLogin)
								 FailureAction:@selector(onFailureLogin)];
	[r GetOnlnClaimCtrgyTypeMAService:participent_id uID:user_id];
	[r release];
	
}
-(void)test_ClaimOnlineServiceSave
{
	service=8;
	RequestPhase2 *r=[[RequestPhase2 alloc] initWithTarget:self
											 SuccessAction:@selector(onSucceffulLogin)
											 FailureAction:@selector(onFailureLogin)];
	[r ClaimOnlineServiceSave:participent_id uID:user_id 
					claimCaty:claim_Category 
					 claimtpe:claim_type  
						  amt:aMount
					  SerBedt:service_BeginDt 
					  SerEedt:service_EndDt
						 Note:nOte
					   isPrYr:isPrior_Year
					  payMode:pay_Mode
				 providerName:provider_Name
					  PayeeId:Payee_Id 
		  allowDuplicateClaim:allowDuplicate_Claim
					   opcode:oPcode];
	 
	[r release];
	
}
-(void)test_ClaimOnlineServiceSave2
{
	service=9;
	RequestPhase2 *r=[[RequestPhase2 alloc] initWithTarget:self
											 SuccessAction:@selector(onSucceffulLogin)
											 FailureAction:@selector(onFailureLogin)];
	
	[r ClaimOnlineServiceSave2:participent_id uID:user_id 
					 claimCaty:claim_Category 
					  claimtpe:claim_type
						   amt:aMount
					   SerBedt:service_BeginDt 
					   SerEedt:service_EndDt
						  Note:nOte
						isPrYr:isPrior_Year
					   payMode:pay_Mode
				  providerName:provider_Name
				  accountvalue:account_value
					   PayeeId:Payee_Id 
		   allowDuplicateClaim:allowDuplicate_Claim
						opcode:oPcode];
	[r release];
}
-(void)test_GetUnSubmittedClaim
{
	service=10;
	RequestPhase2 *r=[[RequestPhase2 alloc] initWithTarget:self
											 SuccessAction:@selector(onSucceffulLogin)
											 FailureAction:@selector(onFailureLogin)];
	
	[r GetUnSubmittedClaim:participent_id uID:user_id  
				noOfRecord:no_Of_Record  
			 startAftersid:@""];
	
	[r release];
}
-(void)test_EditUnSubmittedClaim
{
	service=11;
	RequestPhase2 *r=[[RequestPhase2 alloc] initWithTarget:self
											 SuccessAction:@selector(onSucceffulLogin)
											 FailureAction:@selector(onFailureLogin)];
	
	[r EditUnSubmittedClaim:participent_id uID:user_id
				  claimCaty:claim_Category 
				   claimtpe:claim_type  
						amt:aMount 
					SerBedt:service_BeginDt 
					SerEedt:service_EndDt
					   Note:nOte
					 isPrYr:isPrior_Year
					payMode:pay_Mode
			   providerName:provider_Name
					Claimid:Claim_id
		allowDuplicateClaim:allowDuplicate_Claim
					 opcode:oPcode];
	[r release];
}
-(void)test_EditUnSubmittedClaim2
{
	service=12;
	RequestPhase2 *r=[[RequestPhase2 alloc] initWithTarget:self
											 SuccessAction:@selector(onSucceffulLogin)
											 FailureAction:@selector(onFailureLogin)];
	
	[r EditUnSubmittedClaim2:participent_id uID:user_id 
				   claimCaty:claim_Category 
					claimtpe:claim_type  
						 amt:aMount 
					 SerBedt:service_BeginDt 
					 SerEedt:service_EndDt
						Note:nOte
					  isPrYr:isPrior_Year
					 payMode:pay_Mode
				providerName:provider_Name 
					 Claimid:Claim_id
				accountvalue:@""
		 allowDuplicateClaim:allowDuplicate_Claim
					  opcode:oPcode];
	[r release];
}
-(void)test_SubmitallClaim
{
	service=13;
	RequestPhase2 *r=[[RequestPhase2 alloc] initWithTarget:self
											 SuccessAction:@selector(onSucceffulLogin)
											 FailureAction:@selector(onFailureLogin)];
	
	[r SubmitallClaim:participent_id uID:user_id];
	[r release];
}
-(void)test_IgnoreAllclaim
{
	service=14;
	RequestPhase2 *r=[[RequestPhase2 alloc] initWithTarget:self
											 SuccessAction:@selector(onSucceffulLogin)
											 FailureAction:@selector(onFailureLogin)];
	
	[r IgnoreAllclaim:participent_id uID:user_id];
	[r release];
	
}
-(void)test_Ignoreclaim
{
	service=15;
	RequestPhase2 *r=[[RequestPhase2 alloc] initWithTarget:self
											 SuccessAction:@selector(onSucceffulLogin)
											 FailureAction:@selector(onFailureLogin)];
	
		
	[r Ignoreclaim:participent_id uID:user_id 
					pendingClmID:pending_ClmID];
	[r release];
}
-(void)test_Paynow
{
	service=16;
	RequestPhase2 *r=[[RequestPhase2 alloc] initWithTarget:self
											 SuccessAction:@selector(onSucceffulLogin)
											 FailureAction:@selector(onFailureLogin)];
	
	[r Paynow:participent_id userid:user_id 
					pendingClmID:pending_ClmID];
	[r release];
}
-(void)test_ShowAllIgnoreclaim
{
	service=17;
	RequestPhase2 *r=[[RequestPhase2 alloc] initWithTarget:self
											 SuccessAction:@selector(onSucceffulLogin)
											 FailureAction:@selector(onFailureLogin)];
	
		
	[r ShowAllIgnoreclaim:participent_id uID:user_id];
	[r release];
}
-(void)test_UploadImage
{
	service=18;
	RequestPhase2 *r=[[RequestPhase2 alloc] initWithTarget:self
											 SuccessAction:@selector(onSucceffulLogin)
											 FailureAction:@selector(onFailureLogin)];
	
		
	[r UploadImage:participent_id userid:user_id 
		   imgData:@"" 
		   imgName:@"" 
			 trxnID:@"" 
			 clmID:@""];
	
	[r release];
}
-(void)test_ClaimsToPaySubmit
{
	service=19;
	RequestPhase2 *r=[[RequestPhase2 alloc] initWithTarget:self
											 SuccessAction:@selector(onSucceffulLogin)
											 FailureAction:@selector(onFailureLogin)];
	
	[r ClaimsToPaySubmit:participent_id userid:user_id 
				 claimID:Claim_id  
				 payMode:pay_Mode 
				  actpCD:@""
				 PayeeId:Payee_Id];
	[r release];
}
-(void)test_AddEmail
{
	service=20;
	RequestPhase2_2 *r=[[RequestPhase2_2 alloc] initWithTarget:self
											 SuccessAction:@selector(onSucceffulLogin)
											 FailureAction:@selector(onFailureLogin)];
	
	[r AddEmail:participent_id uID:user_id
		  email:e_mail];
	
	[r release];
}
-(void)test_AddPhoneNumber
{
	service=21;
	RequestPhase2_2 *r=[[RequestPhase2_2 alloc] initWithTarget:self
												 SuccessAction:@selector(onSucceffulLogin)
												 FailureAction:@selector(onFailureLogin)];
	
	[r AddPhoneNumber:participent_id uID:user_id  
				areaP:@"123" 
				restP:@"4567890" 
				extnP:@""
				areaS:@""
				restS:@"" 
				extnS:@""];
	
	[r release];
}
-(void)test_VerifyEmail
{
	service=22;
	RequestPhase2_2 *r=[[RequestPhase2_2 alloc] initWithTarget:self
												 SuccessAction:@selector(onSucceffulLogin)
												 FailureAction:@selector(onFailureLogin)];
	
	[r VerifyEmail:participent_id uID:user_id  
			 email:e_mail];
	[r release];
	
}
-(void)test_GetPrimarySummery
{
	service=23;
	RequestPhase2_2 *r=[[RequestPhase2_2 alloc] initWithTarget:self
												 SuccessAction:@selector(onSucceffulLogin)
												 FailureAction:@selector(onFailureLogin)];
	
	[r GetPrimarySummery:participent_id uID:user_id];
	[r release];
}
-(void)test_SubmitforeCommunication
{
	service=24;
	RequestPhase2_2 *r=[[RequestPhase2_2 alloc] initWithTarget:self
												 SuccessAction:@selector(onSucceffulLogin)
												 FailureAction:@selector(onFailureLogin)];
	
	[r SubmitforeCommunication:participent_id uID:user_id 
						 email:e_mail  
				  reenterEmail:@"" 
				  hsaStatement:@""
			  accountStatement:@"" 
			otherCommunication:@""];
	
	[r release];
}
-(void)test_EditAchRequest
{
	service=25;
	RequestPhase2_2 *r=[[RequestPhase2_2 alloc] initWithTarget:self
												 SuccessAction:@selector(onSucceffulLogin)
												 FailureAction:@selector(onFailureLogin)];
	
	[r EditAchRequest:participent_id uID:user_id  
		  accountType:@""
			accountNo:@"" 
		  reAccountNo:@""
			routingNo:@""   
		  reRoutingNo:@""   
			   status:@"" 
				  dob:@""  
				email:e_mail];
	[r release];
}
-(void)test_GetCustomText
{
	service=26;
	RequestPhase2_2 *r=[[RequestPhase2_2 alloc] initWithTarget:self
												 SuccessAction:@selector(onSucceffulLogin)
												 FailureAction:@selector(onFailureLogin)];
	
	[r GetCustomText:participent_id uID:user_id];
	[r release];
}
-(void)test_ShowImage
{
	service=27;
	RequestPhase2_2 *r=[[RequestPhase2_2 alloc] initWithTarget:self
												 SuccessAction:@selector(onSucceffulLogin)
												 FailureAction:@selector(onFailureLogin)];
	
	[r ShowImage:participent_id uID:user_id 
		  fileID:@""];
	[r release];
}
-(void)test_deleteClaim
{
	service=28;
	RequestPhase2 *r=[[RequestPhase2 alloc] initWithTarget:self
											 SuccessAction:@selector(onSucceffulLogin)
											 FailureAction:@selector(onFailureLogin)];
	
	[r deleteClaim:participent_id uID:user_id 
		   Claimid:Claim_id];
	[r release];
}
-(void)test_sendActiveScheduleRequest
{
	service=29;
	RequestPhase2 *r=[[RequestPhase2 alloc] initWithTarget:self
											 SuccessAction:@selector(onSucceffulLogin)
											 FailureAction:@selector(onFailureLogin)];
	
	[r sendActiveScheduleRequest:participent_id userid:user_id 
							 Eid:election_id
						 startId:start_id
						 noOfRec:no_Of_Record
					scheduletype:@"GetActiveSchedules"];
	[r release];
}
-(void)test_sendInActiveScheduleRequest
{
	service=30;
	RequestPhase2 *r=[[RequestPhase2 alloc] initWithTarget:self
											 SuccessAction:@selector(onSucceffulLogin)
											 FailureAction:@selector(onFailureLogin)];
	
	[r sendInActiveScheduleRequest:participent_id userid:user_id 
							   Eid:election_id
						   startId:start_id
						   noOfRec:no_Of_Record
					  scheduletype:@"GetInActiveSchedules"];
	[r release];
}
-(void)onSucceffulLogin
{
	switch (service) {
		case 0:
		{
			NSMutableArray *arr=[UserresponcePerser userdesc];
			if ([[arr objectAtIndex:0]intValue]==0)
			{
				txtv_msgCloseNotes.text=@"login1:	Success";
			}
			else 
			{
				txtv_msgCloseNotes.text=@"login1:	Failure";
			}
		}
			
			break;
		case 1:
		{
			NSMutableArray *arr=[passPerser passresponce];
			if ([[arr objectAtIndex:0]intValue]==0)
			{
				txtv_msgCloseNotes.text=@"login2:	Success";
			}
			else 
			{
				txtv_msgCloseNotes.text=@"login2:	Failure";
			}
		}
			
			break;
		case 2:
		{
					
			NSMutableArray *err=[accPerser geterror_arr];
			
			if ([((errorcodeOBJ *)[ err objectAtIndex:0]).returnCode isEqualToString:@"0"])
			{
				txtv_msgCloseNotes.text=@"sendaccountRequest:	Success";
			}
			else 
			{
				txtv_msgCloseNotes.text=@"sendaccountRequest:	Failure";
			}
		}
			
			break;
		case 3:
		{
			NSMutableArray *err=[transactionPerser geterror_arr];
			
			if ([((errorcodeOBJ *)[ err objectAtIndex:0]).returnCode isEqualToString:@"0"])
			{
				txtv_msgCloseNotes.text=@"sendtransactionRequest:	Success";
			}
			else 
			{
				txtv_msgCloseNotes.text=@"sendtransactionRequest:	Failure";
			}
		}
			
			break;
		case 4:
		{
			NSMutableArray *err=[ticketPerser geterror_arr];
			
			if ([((errorcodeOBJ *)[ err objectAtIndex:0]).returnCode isEqualToString:@"0"])
			{
				txtv_msgCloseNotes.text=@"sendMessageRequest:	Success";
			}
			else 
			{
				txtv_msgCloseNotes.text=@"sendMessageRequest:	Failure";
			}
		}
			
			break;
		case 5:
		{
			NSMutableArray *err=[claimactivityPerser geterror_arr];
			
			if ([((errorcodeOBJ *)[ err objectAtIndex:0]).returnCode isEqualToString:@"0"])
				
			{
				txtv_msgCloseNotes.text=@"sendClaimRequest:	Success";
			}
			else 
			{
				txtv_msgCloseNotes.text=@"sendClaimRequest:	Failure";
			}
		}
			
			break;
		case 6:
		{
			NSMutableArray *err=[imagePerser geterror_arr];
			
			if ([((errorcodeOBJ *)[ err objectAtIndex:0]).returnCode isEqualToString:@"0"])
				
			{
				txtv_msgCloseNotes.text=@"sendImageRequest:	Success";
			}
			else 
			{
				txtv_msgCloseNotes.text=@"sendImageRequest:	Failure";
			}
		}
			
			break;
			
		case 7:
		{
			NSMutableArray *err=[ClaimSubmitNewParser getarrm_passArray];
			
			
			if (([err count]>0)&&[[err objectAtIndex:0] isEqualToString:@"0"])
			{
				txtv_msgCloseNotes.text=@"sendClaimCatagoryRequest:	Success";
			}
			else 
			{
				txtv_msgCloseNotes.text=@"sendClaimCatagoryRequest:	Failure";
			}
		}
			
			break;
			
		case 8:
		{
			NSMutableArray *err=[Claimonlineserviceparser getarrClaimonlinesave];
			
			if ([((ClaimonlineSaveOBJ *)[ err objectAtIndex:0]).strreturnCode isEqualToString:@"74"])
			{
				txtv_msgCloseNotes.text=@"sendclaimOnlineServiceSaveRequest:	Success";
			}
			else 
			{
				txtv_msgCloseNotes.text=@"sendclaimOnlineServiceSaveRequest:	Failure";
			}
		}
			
			break;
			
		case 9:
		{
			NSMutableArray *err=[Claimonlineserviceparser getarrClaimonlinesave];
			
			if ([((ClaimonlineSaveOBJ *)[ err objectAtIndex:0]).strreturnCode isEqualToString:@"74"])
			{
				txtv_msgCloseNotes.text=@"sendclaimOnlineServiceSave2Request:	Success";
			}
			else 
			{
				txtv_msgCloseNotes.text=@"sendclaimOnlineServiceSave2Request:	Failure";
			}
		}
			
			break;	
		
		case 10:
		{
			NSMutableArray *err=[UnsubmittedClaimParser getarrgetunsubmittedClaim];
			
			
			if (([err count]>0)&&[[err objectAtIndex:0] isEqualToString:@"0"])
			{
				txtv_msgCloseNotes.text=@"sendGetUnSubmittedClaimRequest:	Success";
			}
			else 
			{
				txtv_msgCloseNotes.text=@"sendGetUnSubmittedClaimRequest:	Failure";
			}
		}
			
			break;	
			
		case 11:
		{
			NSMutableArray *err=[Claimonlineserviceparser getarrClaimonlinesave];
			
			if ([((ClaimonlineSaveOBJ *)[ err objectAtIndex:0]).strreturnCode isEqualToString:@"76"])
			{
				txtv_msgCloseNotes.text=@"sendEditUnSubmittedClaimRequest:	Success";
			}
			else 
			{
				txtv_msgCloseNotes.text=@"sendEditUnSubmittedClaimRequest:	Failure";
			}
		}
			
			break;
			
		case 12:
		{
			NSMutableArray *err=[Claimonlineserviceparser getarrClaimonlinesave];
			
			if ([((ClaimonlineSaveOBJ *)[ err objectAtIndex:0]).strreturnCode isEqualToString:@"76"])
			{
				txtv_msgCloseNotes.text=@"sendEditUnSubmittedClaim2Request:	Success";
			}
			else 
			{
				txtv_msgCloseNotes.text=@"sendEditUnSubmittedClaim2Request:	Failure";
			}
		}
			
			break;
			
		case 13:
		{
			NSMutableArray *err=[SubmitclaimParser getarrdenydetail];
			
			if ([((SubmitclaimOBJ *)[ err objectAtIndex:0]).strreturnCode isEqualToString:@"0"])
			{
				txtv_msgCloseNotes.text=@"sendSubmitallClaimRequest:	Success";
			}
			else 
			{
				txtv_msgCloseNotes.text=@"sendSubmitallClaimRequest:	Failure";
			}
		}
			
			break;	
			
		case 14:
		{
			NSMutableArray *err=[errorParser getmyerror_arr];
			
			if ([((errorcodeOBJ *)[ err objectAtIndex:0]).returnCode isEqualToString:@"203"]||[((errorcodeOBJ *)[ err objectAtIndex:0]).returnCode isEqualToString:@"0"])
			{
				txtv_msgCloseNotes.text=@"sendIgnoreAllclaimRequest:	Success";
			}
			else 
			{
				txtv_msgCloseNotes.text=@"sendIgnoreAllclaimRequest:	Failure";
			}
		}
			
			break;	
			
		case 15:
		{
			NSMutableArray *err=[errorParser getmyerror_arr];
			
			if ([((errorcodeOBJ *)[ err objectAtIndex:0]).returnCode isEqualToString:@"0"])
			{
				txtv_msgCloseNotes.text=@"sendIgnoreclaimRequest:	Success";
			}
			else 
			{
				txtv_msgCloseNotes.text=@"sendIgnoreclaimRequest:	Failure";
			}
		}
			
			break;	
			
		case 16:
		{
			NSMutableArray *err=[PaynowParser getarrpaynowdetail];
			
			if ([((PaynowOBJ *)[ err objectAtIndex:0]).strreturnCode isEqualToString:@"0"])
			{
				txtv_msgCloseNotes.text=@"sendPaynowRequest:	Success";
			}
			else 
			{
				txtv_msgCloseNotes.text=@"sendPaynowRequest:	Failure";
			}
		}
			
			break;
			
		case 17:
		{
			NSMutableArray *err=[errorParser getmyerror_arr];
			
			if ([((errorcodeOBJ *)[ err objectAtIndex:0]).returnCode isEqualToString:@"0"]||[((errorcodeOBJ *)[ err objectAtIndex:0]).returnCode isEqualToString:@"220"])
			{
				txtv_msgCloseNotes.text=@"sendShowAllIgnoreclaimRequest:	Success";
			}
			else 
			{
				txtv_msgCloseNotes.text=@"sendShowAllIgnoreclaimRequest:	Failure";
			}
		}
			
			break;
			
		case 18:
		{
			NSMutableArray *err=[errorParser getmyerror_arr];
			
			if ([((errorcodeOBJ *)[ err objectAtIndex:0]).returnCode isEqualToString:@"404"])
			{
				txtv_msgCloseNotes.text=@"sendUploadImageRequest:	Success";
			}
			else 
			{
				txtv_msgCloseNotes.text=@"sendUploadImageRequest:	Failure";
			}
		}
			
			break;	
			
		case 19:
		{
			NSString *str=[PaynowcontinueParser getreturncode];
			
			if([str isEqualToString:@"201"])	
			{
				txtv_msgCloseNotes.text=@"sendClaimsToPaySubmitRequest:	Success";
			}
			else 
			{
				txtv_msgCloseNotes.text=@"sendClaimsToPaySubmitRequest:	Failure";
			}
		}
			
			break;	
			
		case 20:
		{
			NSMutableArray *err=[AddEmailParser getarrAddemail];
			
			if ([((AddEmailOBJ *)[ err objectAtIndex:0]).strreturnCode isEqualToString:@"0"])
			{
				txtv_msgCloseNotes.text=@"sendAddEmailRequest:	Success";
			}
			else 
			{
				txtv_msgCloseNotes.text=@"sendAddEmailRequest:	Failure";
			}
		}
			
			break;
			
		case 21:
		{
			NSMutableArray *err=[AddEmailParser getarrAddemail];
			
			if ([((AddEmailOBJ *)[ err objectAtIndex:0]).strreturnCode isEqualToString:@"0"])
			{
				txtv_msgCloseNotes.text=@"sendAddPhoneNumberRequest:	Success";
			}
			else 
			{
				txtv_msgCloseNotes.text=@"sendAddPhoneNumberRequest:	Failure";
			}
		}
			
			break;	
			
		case 22:
		{
			NSMutableArray *err=[AddEmailParser getarrAddemail];
			
			if ([((AddEmailOBJ *)[ err objectAtIndex:0]).strreturnCode isEqualToString:@"0"])
			{
				txtv_msgCloseNotes.text=@"sendVerifyEmailRequest:	Success";
			}
			else 
			{
				txtv_msgCloseNotes.text=@"sendVerifyEmailRequest:	Failure";
			}
		}
			
			break;
			
		case 23:
		{
			NSMutableArray *err=[GopaperlessParser getarrgoPaperlessinfo];
			
			if ([((GoPaperlessOBJ *)[ err objectAtIndex:0]).strreturnCode isEqualToString:@"0"])
			{
				txtv_msgCloseNotes.text=@"sendGetPrimarySummeryRequest:	Success";
			}
			else 
			{
				txtv_msgCloseNotes.text=@"sendGetPrimarySummeryRequest:	Failure";
			}
		}
			
			break;
			
		case 24:
		{
			NSString *str=[PaynowcontinueParser getreturncode];
			
			if([str isEqualToString:@"0"])	
			{
				txtv_msgCloseNotes.text=@"sendSubmitforeCommunicationRequest:	Success";
			}
			else 
			{
				txtv_msgCloseNotes.text=@"sendSubmitforeCommunicationRequest:	Failure";
			}
		}
			
			break;	
			
		case 25:
		{
			NSString *str=[PaynowcontinueParser getreturncode];
			
			if([str isEqualToString:@"0"])	
			{
				txtv_msgCloseNotes.text=@"sendEditAchRequestRequest:	Success";
			}
			else 
			{
				txtv_msgCloseNotes.text=@"sendEditAchRequestRequest:	Failure";
			}
		}
			
			break;
			
		case 26:
		{
			
			NSMutableArray *err=[eCommunicationParser getarrText];
			
			if ([((eCommunicationOBJ *)[ err objectAtIndex:0]).strreturnCode isEqualToString:@"0"])	
			{
				txtv_msgCloseNotes.text=@"sendGetCustomTextRequest:	Success";
			}
			else 
			{
				txtv_msgCloseNotes.text=@"sendGetCustomTextRequest:	Failure";
			}
		}
			
			break;	
			
		case 27:
		{
			
			NSMutableArray *err=[ReceiptShowParser getarrReceipt];
			
			if ([((ReceiptShowOBJ *)[ err objectAtIndex:0]).strreturnCode isEqualToString:@"0"])	
			{
				txtv_msgCloseNotes.text=@"sendShowImageRequest:	Success";
			}
			else 
			{
				txtv_msgCloseNotes.text=@"sendShowImageRequest:	Failure";
			}
		}
			
			break;	
			
			
		case 28:
		{
			NSString *str=[Deleteparser getReturncode];
			
			if([str isEqualToString:@"0"])	
			{
				txtv_msgCloseNotes.text=@"senddeleteClaimRequest:	Success";
			}
			else 
			{
				txtv_msgCloseNotes.text=@"senddeleteClaimRequest:	Failure";
			}
		}
			
			break;
			
		case 29:
		{
			
			NSMutableArray *err=[activeScheduleParser get_errorCodeSchedule];
			
			if([[err objectAtIndex:0] isEqualToString:@"0"])	
			{
				txtv_msgCloseNotes.text=@"sendsendActiveScheduleRequestRequest:	Success";
			}
			else 
			{
				txtv_msgCloseNotes.text=@"sendsendActiveScheduleRequestRequest:	Failure";
			}
		}
			
			break;	
		
		case 30:
		{
			
			NSMutableArray *err=[activeScheduleParser get_errorCodeSchedule];
			
			if([[err objectAtIndex:0] isEqualToString:@"0"])
			 {
			 txtv_msgCloseNotes.text=@"sendsendInActiveScheduleRequestRequest:	Success";
			 }
			 else 
			 {
			 txtv_msgCloseNotes.text=@"sendsendInActiveScheduleRequestRequest:	Failure";
			 }
		}
			
			break;
			
		default:
			break;
	}
	
}

-(void)onFailureLogin
{
	txtv_msgCloseNotes.text=@"Failure";	
	
}
#pragma mark picker
-(void)populateRadiusPicker
{
	
	NSArray *arrayOfViews=[viewself subviews];
	
	if([arrayOfViews count]>0)
		
	{
		
		for(int i=0;i<[arrayOfViews count];i++)
			
		{
			
			[[arrayOfViews objectAtIndex:i] removeFromSuperview];
			
		}
		
	} 
	
	
	viewself.backgroundColor=[UIColor colorWithRed:160.0/255 green:161.0/255.0 blue:166.0/255.0 alpha:1.0 ];
	
	[self.view addSubview:viewself]; 
	
	
	UIPickerView *radiusPickerView= [[UIPickerView alloc] initWithFrame:CGRectZero];
	
	radiusPickerView.autoresizingMask = UIViewAutoresizingFlexibleWidth;
	
	CGSize pickerSize = [radiusPickerView sizeThatFits:CGSizeZero];
	
	radiusPickerView.frame = CGRectMake(0.0,30.0, pickerSize.width,180);
	
	radiusPickerView.delegate = self;
	
	radiusPickerView.showsSelectionIndicator = YES;
	
	[viewself addSubview:radiusPickerView];
	
	[radiusPickerView release],nil; 
	
	
	UIButton *btnCancel=[UIButton buttonWithType:UIButtonTypeCustom];
	
	//[btnCancel setBackgroundImage:[UIImage imageNamed:@"done_active.png"] forState:UIControlStateNormal];
	
	[btnCancel setTitle:@"DONE" forState:UIControlStateNormal];
	
	btnCancel.frame=CGRectMake(242,4,70,25);
	
	[btnCancel setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	
	btnCancel.backgroundColor=[UIColor clearColor];
	
	btnCancel.showsTouchWhenHighlighted=NO;
	
	[btnCancel addTarget:self action:@selector(dismisPopulateActionSheet:) forControlEvents:UIControlEventTouchUpInside];
	
	[viewself addSubview:btnCancel];
	
	
	
	[UIView beginAnimations:nil context:nil];
	
	[UIView setAnimationDuration:0.3];
	
	viewself.frame=CGRectMake(0, 250, 320, 240);
	
	[UIView commitAnimations]; 
	
	
	
}
-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
	//txt_messageType_text.text = ((ticketTypeOBJ *)[ tktType objectAtIndex:row]).label;
	testcase=row;
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
	return [testname objectAtIndex:row];
}
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
	return 1;
}
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
	return [testname count];
}
- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component
{
	CGFloat componentWidth;
	componentWidth = 270.0;	// first column size is wider to hold names
	return componentWidth;
}
-(void)dismisPopulateActionSheet:(id)sender

{
	
	
	viewself.frame=CGRectMake(0, 220, 320, 240);
	
	[UIView beginAnimations:nil context:nil];
	
	[UIView setAnimationDuration:0.3];
	
	viewself.frame=CGRectMake(0, 460, 320, 240);
	
	[UIView commitAnimations];
	
	[self performSelector:@selector(removeSuperView) withObject:nil afterDelay:0.3];
	
	switch (testcase) {
		case 0:
			[self test_login1];
			break;
		case 1:
			[self test_login2];
			break;
		case 2:
			[self test_sendaccountRequest];
			break;		
		case 3:
			[self test_sendtransactionRequest];
			break;		
		case 4:
			[self test_reqTicket];
			break;		
		case 5:
			[self test_claimActivityReq];
			break;	
		case 6:
			[self test_images];
			break;
		case 7:
			[self test_claimCatagories];
			break;
		case 8:
			[self test_ClaimOnlineServiceSave];
			break;
		case 9:
			[self test_ClaimOnlineServiceSave2];
			break;
		case 10:
			[self test_GetUnSubmittedClaim];
			break;
		case 11:
			[self test_EditUnSubmittedClaim];
			break;
		case 12:
			[self test_EditUnSubmittedClaim2];
			break;
		case 13:
			[self test_SubmitallClaim];
			break;
		case 14:
			[self test_IgnoreAllclaim];
			break;
		case 15:
			[self test_Ignoreclaim];
			break;
		case 16:
			[self test_Paynow];
			break;
		case 17:
			[self test_ShowAllIgnoreclaim];
			break;
		case 18:
			[self test_UploadImage];
			break;
		case 19:
			[self test_ClaimsToPaySubmit];
			break;
		case 20:
			[self test_AddEmail];
			break;
		case 21:
			[self test_AddPhoneNumber];
			break;
		case 22:
			[self test_VerifyEmail];
			break;
		case 23:
			[self test_GetPrimarySummery];
			break;
		case 24:
			[self test_SubmitforeCommunication];
			break;
		case 25:
			[self test_EditAchRequest];
			break;
		case 26:
			[self test_GetCustomText];
			break;
		case 27:
			[self test_ShowImage];
			break;
		case 28:
			[self test_deleteClaim];
			break;
		case 29:
			[self test_sendActiveScheduleRequest];
			break;
		case 30:
			[self test_sendInActiveScheduleRequest];
			break;
		default:
			break;
	}
	
	txtv_msgCloseNotes.text=@"";

	
} 

-(void)removeSuperView

{
	
	NSArray *arrayOfViews=[viewself subviews];
	
	if([arrayOfViews count]>0)
		
	{
		
		for(int i=0;i<[arrayOfViews count];i++)
			
		{
			
			[[arrayOfViews objectAtIndex:i] removeFromSuperview];
			
			//[[arrayOfViews objectAtIndex:i] release];
			
		}
		
	}
	
} 
#pragma mark -


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/
- (BOOL)textViewShouldBeginEditing:(UITextView *)textView;
{
	
	return NO;
}
- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
