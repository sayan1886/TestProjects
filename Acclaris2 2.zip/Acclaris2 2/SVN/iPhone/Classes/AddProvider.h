//
//  AddProvider.h
//  Acclaris
//
//  Created by Subhojit on 23/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyTools.h"
#import "Decode64.h"
#import "RequestPhase2.h"
#import "passPerser.h"
#import "AcclarisAppDelegate.h"
#import "AddproviderParser.h"
#import "StateOBJ.h"
#import "StateParser.h"
#import "CountryOBJ.h"
#import "CountryParser.h"
#import "passPerser.h"
@class configurables;

@interface AddProvider : UIViewController<UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate,UIPickerViewDelegate> {

	configurables *con;
	MyTools *tools;
	AcclarisAppDelegate *app;
	UITableView *table;
	UITextField *txtNickName;
	UITextField *txtName;
	UITextField *txtAddress;
	UITextField *txtCity;
	UITextField *txtState;
	UITextField *txtStreet;
	UITextField *txtZip; 
	UITextField *txtEmail;
	UITextField *txtcountry;
	UITextField *txtLine1;
	UITextField *txtLine3;
	UITextField *txtLine2;
	NSMutableArray *focusArray;
	NSMutableArray *arrAllSection;
	NSArray *pickerViewArray;
	UIPickerView *myPickerView;
    NSString *strTxtNm;
	UIView *loadingView;
	int Selectedrow;
	
	
	UIButton *btn_Remember_Me;
	NSMutableArray *userinfo;
	
	NSMutableArray *arrStatedetail;
	NSMutableArray *arrStatePicker;
	StateOBJ *objstate;
	CountryOBJ *objcountry;
	
	NSMutableArray *arrCountrydetail;
	NSMutableArray *arrCountryPicker;
	NSMutableArray *userinfo_arr;
	int SelectedRowstate;
	int SelectedRowcountry;
	BOOL isalert;
	BOOL iscountry;
	NSDictionary *customMessageList_dict;
	
		

}
-(void)CreatePickerView;
-(void)CreateView;
-(void)Line1Input:(UITableViewCell *)cell;
-(void)GetStateRequest;
-(void)GetCountryRequest;
-(void)signout;
-(void)CreateView;
-(void)constructTableCell;
-(void)NickNameInput:(UITableViewCell *)cell;
-(void)NameInput:(UITableViewCell *)cell;
-(void)EmailInput:(UITableViewCell *)cell;
-(void)CityInput:(UITableViewCell *)cell;
-(void)StateInput:(UITableViewCell *)cell;
-(void)ZipInput:(UITableViewCell *)cell;
-(void)Line2Input:(UITableViewCell *)cell;
-(void)Line3Input:(UITableViewCell *)cell;
-(void)CountryInput:(UITableViewCell *)cell;
-(void)CityInput:(UITableViewCell *)cell;
-(BOOL)validateEmail:(NSString *)email;
-(void)createbar_button;
-(void)donecancel;
-(void)Vanishpicker;
-(void)createbarbuttondone;

@end
