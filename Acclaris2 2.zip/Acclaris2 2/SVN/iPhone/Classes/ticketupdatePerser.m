//
//  ticketupdatePerser.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 04/11/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import "ticketupdatePerser.h"
NSMutableArray *arrupdateresponse;

@implementation ticketupdatePerser
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error
{
	
	NSXMLParser *parser;
	parser = [[NSXMLParser alloc] initWithData:data];
    [parser setDelegate:self];
	[parser setShouldProcessNamespaces:NO];
    [parser setShouldReportNamespacePrefixes:NO];
    [parser setShouldResolveExternalEntities:NO];
    [parser parse];
    NSError *parseError = [parser parserError];
    if (parseError && error) 
	{
        *error = parseError;
    }
	[parser release];
}

-(void)parserDidStartDocument:(NSXMLParser *)parser
{
	
	arrupdateresponse=[[NSMutableArray alloc]init];
}		

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
	if(qName)
	{
        elementName = qName;
    }	
	
	if([elementName isEqualToString:@"returnCode"])
	{	
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;				
	}
		else
	{
		;
	}
	
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName     
{	
	if(qName)
	{
        elementName = qName;
		
    }	
	
	if([elementName isEqualToString:@"returnCode"])
	{
		if(contentOfString)
		{
			[arrupdateresponse addObject:contentOfString];
			[contentOfString release];
			contentOfString = nil;
			
			
		}			
	}	
	
	
		else
	{
		;
	}
	
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
	if(contentOfString)
		[contentOfString appendString:string];
}

- (void)parserDidEndDocument:(NSXMLParser *)parse
{

}	
+(NSMutableArray *)updateresponse
{
	if (arrupdateresponse) {
		
		return arrupdateresponse;
	}
	else {
		return nil;
	}
	
}

@end
