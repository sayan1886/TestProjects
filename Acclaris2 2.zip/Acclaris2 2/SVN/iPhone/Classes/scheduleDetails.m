    //
//  scheduleDetails.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 26/04/11.
//  Copyright 2011 ObjectSol Technologies. All rights reserved.
//

#import "scheduleDetails.h"
#import "activeScheduleParser.h"
#import "ActiveSchedule.h"
#import "Decode64.h"
#import "AcclarisViewController.h"
#import "configurables.h"
#import "ActiveScheduleOBJ.h"
#import "ScheduleOBJ.h"

#define FONT_SIZE 15.0f
#define CELL_CONTENT_WIDTH 80.0f
#define CELL_CONTENT_MARGIN 10.0f

@implementation scheduleDetails

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	[super viewDidLoad];
	self.view.backgroundColor=[UIColor whiteColor];
	
	NSMutableArray *arr_myconfig=[AcclarisViewController staticarr_config];//[configurableParser getconfig_arr];//
	con=(configurables *)[arr_myconfig objectAtIndex:0];
	self.view.backgroundColor = [UIColor colorWithRed:con.bgRed/255.0f green:con.bgGreen/255.0f blue:con.bgBlue/255.0f alpha:1.0];
	
	//NSMutableArray *my_arrUserinfo=[UserresponcePerser userdesc];
	UIImageView *logo_img = [[UIImageView alloc]initWithFrame:CGRectMake(0, 2, 170, 40)];
	NSData *data=[Base64 decode:con.logoImgdata];
	logo_img.image=	[UIImage imageWithData:[NSData dataWithData:data]];
	self.navigationItem.titleView=logo_img;
	
	selectedRow=[ActiveSchedule getscheduleselectedRow];
	
	arr_alltransaction=[activeScheduleParser getscheduleArr];
	ScheduleOBJ *myScheduleOBJ=(ScheduleOBJ *)[arr_alltransaction objectAtIndex:0];
	
	
	NSString *strAccno=((ActiveScheduleOBJ *)[myScheduleOBJ.scheduleArr objectAtIndex:selectedRow]).actNumber;
	NSString *strmaskAccno=[self formatString:strAccno];
	
	
	NSString *strRoutingno=((ActiveScheduleOBJ *)[myScheduleOBJ.scheduleArr objectAtIndex:selectedRow]).bankRoutingNumber;

	NSString *strmaskRoutingno=[self formatString:strRoutingno];
	
	arr_celltytle=[[NSArray alloc]initWithObjects:((ActiveScheduleOBJ *)[myScheduleOBJ.scheduleArr objectAtIndex:selectedRow]).lbl_actHolderName,((ActiveScheduleOBJ *)[myScheduleOBJ.scheduleArr objectAtIndex:selectedRow]).lbl_actNumber,((ActiveScheduleOBJ *)[myScheduleOBJ.scheduleArr objectAtIndex:selectedRow]).lbl_bankRoutingNumber,((ActiveScheduleOBJ *)[myScheduleOBJ.scheduleArr objectAtIndex:selectedRow]).lbl_initTransferDate,((ActiveScheduleOBJ *)[myScheduleOBJ.scheduleArr objectAtIndex:selectedRow]).lbl_endDate,((ActiveScheduleOBJ *)[myScheduleOBJ.scheduleArr objectAtIndex:selectedRow]).lbl_lastStatus,((ActiveScheduleOBJ *)[myScheduleOBJ.scheduleArr objectAtIndex:selectedRow]).lbl_actType,nil];
	arr_celldetails=[[NSArray alloc]initWithObjects:((ActiveScheduleOBJ *)[myScheduleOBJ.scheduleArr objectAtIndex:selectedRow]).actHolderName,strmaskAccno,strmaskRoutingno,((ActiveScheduleOBJ *)[myScheduleOBJ.scheduleArr objectAtIndex:selectedRow]).initTransferDate,((ActiveScheduleOBJ *)[myScheduleOBJ.scheduleArr objectAtIndex:selectedRow]).endDate,((ActiveScheduleOBJ *)[myScheduleOBJ.scheduleArr objectAtIndex:selectedRow]).lastStatus,((ActiveScheduleOBJ *)[myScheduleOBJ.scheduleArr objectAtIndex:selectedRow]).actType,nil];


	/*UIButton *btn_back=[UIButton buttonWithType:UIButtonTypeRoundedRect];
	btn_back.frame = CGRectMake(43, 308, 234, 47);
	NSData *data_btnimg=[Base64 decode:con.btnImgdata];
	[btn_back setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
	btn_back.titleLabel.font = [UIFont fontWithName:con.btnfontname size:con.btnfontsize];
	[btn_back setTitle:@"Back To Transaction" forState:UIControlStateNormal];
	[btn_back setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	[btn_back addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];
	[self.view addSubview:btn_back];*/


	[self signoutbt];
	[self createtableview];

}
-(void)backAction
{
	[self.navigationController popViewControllerAnimated:YES];
}
-(void)signoutbt
{
	UIBarButtonItem *signoutButton = [[UIBarButtonItem alloc]
									  initWithTitle:@"Sign Off"
									  style:UIBarButtonItemStyleBordered
									  target:self
									  action:@selector(signout)];
    self.navigationItem.rightBarButtonItem =signoutButton;
}
-(void)signout
{
	[((AcclarisAppDelegate *)[[UIApplication sharedApplication] delegate]) removeTabBar];
}


-(void)createtableview
{
	UITableView	*acctable=[[UITableView alloc] initWithFrame:CGRectMake(0,0,320,350) style:UITableViewStyleGrouped];
	acctable.delegate = self;
	acctable.dataSource = self;
	acctable.scrollEnabled = YES;
	acctable.autoresizesSubviews = YES;
	acctable.showsVerticalScrollIndicator=YES;
	acctable.showsHorizontalScrollIndicator=YES;
	acctable.backgroundColor=[UIColor clearColor];
	[self.view addSubview:acctable];	
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView  
{
	return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	
	return [arr_celltytle  count];
	
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{  
	static NSString *CellIdentifier = @"Cell";
	static NSString *CellIdentifier1 = @"Cell1";
	UITableViewCell *cell;
	
	if(cell==nil)
	{
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier] autorelease];
	}
	else
	{
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier1];
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier1] autorelease];
		
	}
	cell.selectionStyle=UITableViewCellSelectionStyleNone;
	cell.backgroundColor=[UIColor whiteColor];
	
	strFont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];

	UILabel *cellLabelText=[[UILabel alloc]initWithFrame:CGRectMake(10,13,180,20)];
	cellLabelText.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
	cellLabelText.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
	cellLabelText.backgroundColor=[UIColor clearColor];
	cellLabelText.text = [arr_celltytle objectAtIndex:indexPath.row];
	[cell.contentView addSubview:cellLabelText];
	
	
	
	UILabel *cellLabelammount=[[UILabel alloc]initWithFrame:CGRectMake(220,13,80,20)];
	cellLabelammount.backgroundColor=[UIColor clearColor];
	
	cellLabelammount.text = [arr_celldetails objectAtIndex:indexPath.row];
	cellLabelammount.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
	cellLabelammount.font=[UIFont fontWithName:con.fontname size:con.bodyfntsize];
	cellLabelammount.numberOfLines=0;
	CGSize constraint = CGSizeMake(CELL_CONTENT_WIDTH - (CELL_CONTENT_MARGIN * 2), 20000.0f);
	CGSize size = [[arr_celldetails objectAtIndex:indexPath.row] sizeWithFont:[UIFont fontWithName:con.fontname size:con.bodyfntsize] constrainedToSize:constraint lineBreakMode:UILineBreakModeWordWrap];
	CGFloat height = MAX(size.height, 10.0f);
	cellLabelammount.frame=CGRectMake(220,13,80,height);
	[cell.contentView addSubview:cellLabelammount];
	
	
	return cell;
	
	
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	strFont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];

	//return 48;
	
	NSString *text =[arr_celldetails objectAtIndex:indexPath.row];
	CGSize constraint = CGSizeMake(CELL_CONTENT_WIDTH - (CELL_CONTENT_MARGIN * 2), 20000.0f);
	CGSize size = [text sizeWithFont:[UIFont fontWithName:con.fontname size:con.bodyfntsize] constrainedToSize:constraint lineBreakMode:UILineBreakModeWordWrap];
	CGFloat height = MAX(size.height, 10.0f);
	return height + (CELL_CONTENT_MARGIN * 2)+2;
	
	
}

-(NSString *)chkvalue:(NSString *)value
{
	NSString *newvalue=@"";
	if([value intValue]>=0)
	{
		newvalue=[newvalue stringByAppendingString:con.ptvPrefix];
		newvalue=[newvalue stringByAppendingString:value];
	}
	else {
		value=[value substringFromIndex:1];
		newvalue=[newvalue stringByAppendingString:con.ngtvPrefix];
		newvalue=[newvalue stringByAppendingString:value];
		newvalue=[newvalue stringByAppendingString:con.ngtvSufix];
		
	}
	return newvalue;
}

-(NSString *)formatString:(NSString *)Uname
{
	if ([Uname length]>0) {
		NSString *formatedText=@"";//[Uname substringFromIndex:4];//
		for(int i=0;i<=[Uname length]-4;i++)
		{
			formatedText=[formatedText stringByAppendingString:@"*"];
		}
		
		formatedText=[formatedText stringByAppendingString:[Uname substringFromIndex:[Uname length]-4]];
		
		return formatedText;
	}
	
	else {
		return @"";
	}
	
	
			
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
