    //
//  claimPassthru.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 30/11/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import "claimPassthru.h"
#import "passPerser.h"
#import "Decode64.h"
#import "configurableParser.h"
#import "request.h"
#import "configurables.h"
#import "claimactivityPerser.h"
#import "claimActivityOBJ.h"
#import "UserresponcePerser.h"
#import "AcclarisViewController.h"
#import "claim.h"
#import "RequestPhase2.h"
#import "Paynow.h"
#import "errorParser.h"
#import "errorcodeOBJ.h"
#import "confirmationPage.h"
#import "showMessage.h"

#define CELL_CONTENT_WIDTH 145.0f
#define CELL_CONTENT_MARGIN 10.0f
@implementation claimPassthru

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/
-(id)initWithstring:(NSString *)str
{
	whichclass=str;
	return self;
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	
	NSMutableArray *arr_myconfig=[AcclarisViewController staticarr_config];//[configurableParser getconfig_arr];//
	con=(configurables *)[arr_myconfig objectAtIndex:0];
	
	self.view.backgroundColor = [UIColor colorWithRed:con.bgRed/255.0f green:con.bgGreen/255.0f blue:con.bgBlue/255.0f alpha:1.0];
	tools=[[MyTools alloc]init];
	loadingView=[tools createActivityIndicator1];
	
	//NSMutableArray *my_arrUserinfo=[UserresponcePerser userdesc];
	UIImageView *logo_img = [[UIImageView alloc]initWithFrame:CGRectMake(0, 2, 170, 40)];
	NSData *data=[Base64 decode:con.logoImgdata];
	logo_img.image=	[UIImage imageWithData:[NSData dataWithData:data]];
	self.navigationItem.titleView=logo_img;
	
	customMessageList_dict=[[NSUserDefaults standardUserDefaults] objectForKey:@"customMessageList"];
	
	UIButton *btn_back=[UIButton buttonWithType:UIButtonTypeCustom];
	btn_back.frame = CGRectMake(43, 308, 234, 47);
	NSData *data_btnimg=[Base64 decode:con.btnImgdata];
	[btn_back setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
	btn_back.titleLabel.font = [UIFont fontWithName:@"Arial" size:15];
	[btn_back setTitle:@"Back to Claims" forState:UIControlStateNormal];
	[btn_back setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn_back addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
	[self.view addSubview:btn_back];
	
	/*bt_previous=[UIButton buttonWithType:UIButtonTypeCustom];
	bt_previous.frame = CGRectMake(0, 308+25, 70, 30);
	[bt_previous setBackgroundImage:[UIImage imageNamed: @"green-button.png"] forState:UIControlStateNormal];
	bt_previous.titleLabel.font = [UIFont fontWithName:con.btnfontname size:con.btnfontsize];
	[bt_previous setTitle:@"previous" forState:UIControlStateNormal];
	[bt_previous setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	[bt_previous addTarget:self action:@selector(previous) forControlEvents:UIControlEventTouchUpInside];
	//bt_previous.enabled=NO;
	bt_previous.hidden=YES;
	[self.view addSubview:bt_previous];
	
    bt_next=[UIButton buttonWithType:UIButtonTypeCustom];
    bt_next.frame = CGRectMake(320-70,308+25, 70, 30);
    [bt_next setBackgroundImage:[UIImage imageNamed: @"green-button.png"] forState:UIControlStateNormal];
	bt_next.titleLabel.font = [UIFont fontWithName:con.btnfontname size:con.btnfontsize];
    [bt_next setTitle:@"next" forState:UIControlStateNormal];
    [bt_next setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	[bt_next addTarget:self action:@selector(next) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:bt_next];
	bt_next.hidden=YES;*/
	
	bt_previous=[UIButton buttonWithType:UIButtonTypeCustom];
	bt_previous.frame = CGRectMake(0, 308+25, 50, 30);
	data_btnimg=[Base64 decode:con.btnImgdata];
	[bt_previous setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]]  forState:UIControlStateNormal];
	bt_previous.titleLabel.font = [UIFont fontWithName:con.btnNavFontName size:con.btnNavFontSize];
	[bt_previous setTitle:@"<<" forState:UIControlStateNormal];
	[bt_previous setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	[bt_previous addTarget:self action:@selector(previous) forControlEvents:UIControlEventTouchUpInside];
	//bt_previous.enabled=NO;
	bt_previous.hidden=YES;
	[self.view addSubview:bt_previous];
	
    bt_next=[UIButton buttonWithType:UIButtonTypeCustom];
    bt_next.frame = CGRectMake(320-50,308+25, 50, 30);
    [bt_next setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
	bt_next.titleLabel.font = [UIFont fontWithName:con.btnNavFontName size:con.btnNavFontSize];
    [bt_next setTitle:@">>" forState:UIControlStateNormal];
    [bt_next setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	[bt_next addTarget:self action:@selector(next) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:bt_next];
	bt_next.hidden=YES;
	
	str_startID1=@"0";
	
	[self signoutbt];
	[self claimPassthruReq];	
	
	
	
	
	
}
-(void)previous
{
	if (startID<=0)
	{
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Sorry" message:@"No Previous Records" delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
		[alert show];
		[alert release];
		startID=0;
		return ;
	}
	if (startID<=5)
	{
		//bt_previous.enabled=NO;
		bt_previous.hidden=YES;
	}
	
	startID-=5;
	str_startID1=@"";
	str_startID1=[str_startID1 stringByAppendingFormat:@"%d",startID];
	[str_startID1 retain];
	[acctable removeFromSuperview];
	//bt_next.enabled=YES;
	bt_next.hidden=NO;
	[btnRadio1 removeFromSuperview];
	[btnRadio removeFromSuperview];
	[btnRadiotext removeFromSuperview];
	[btnRadio1text removeFromSuperview];
	[self claimPassthruReq];;
	
}
-(void)next
{
	startID+=5;
	str_startID1=@"";
	str_startID1=[str_startID1 stringByAppendingFormat:@"%d",startID];
	[str_startID1 retain];
	[acctable removeFromSuperview];
	//bt_previous.enabled=YES;
	bt_previous.hidden=NO;
	[btnRadio1 removeFromSuperview];
	[btnRadio removeFromSuperview];
	[btnRadiotext removeFromSuperview];
	[btnRadio1text removeFromSuperview];
	[self claimPassthruReq];
}

-(void)back
{
	if ([whichclass isEqualToString:@"fromAlert"])
	{
		//claim *myclaim=[[claim alloc]init];
//		[self.navigationController pushViewController:myclaim animated:YES];
		
		self.tabBarController.selectedIndex=1;
		[self.navigationController popToRootViewControllerAnimated:YES];

	}
	else 
	{
		[self.navigationController popViewControllerAnimated:YES];
	}

	
}
-(void)signoutbt
{
	UIBarButtonItem *signoutButton = [[UIBarButtonItem alloc]
									  initWithTitle:@"Sign Off"
									  style:UIBarButtonItemStyleBordered
									  target:self
									  action:@selector(signout)];
    self.navigationItem.rightBarButtonItem =signoutButton;
}
-(void)signout
{
	[((AcclarisAppDelegate *)[[UIApplication sharedApplication] delegate]) removeTabBar];
}
-(void)claimPassthruReq
{
	NSMutableArray *userinfo_arr=[passPerser passresponce];
	request *r=[[request alloc] initWithTarget:self
								 SuccessAction:@selector(onSucceffulLogin)
								 FailureAction:@selector(onFailureLogin)];
	[r pendingpassthru:[userinfo_arr objectAtIndex:2] userid:[userinfo_arr objectAtIndex:4] startid:str_startID1];
	
	[r release];
	[tools startLoading:self.view childView:loadingView text:@"Loading your passthrough claims. Wait…."];
	
}
-(void)onSucceffulLogin
{
	[tools stopLoading:loadingView];
	NSMutableDictionary *roleDict=[passPerser getRolebaseDict];
	arr_celltytle=[claimactivityPerser claimactivityArr];
	if([arr_celltytle count]>0)
	{
	BOOL morerec=[claimactivityPerser gethasMoreRecords_claim];
	if (!morerec)
	{
		//bt_next.enabled=NO;
		bt_next.hidden=YES;
	}
	else {
		bt_next.hidden=NO;
	}

	
	[self createtableview];
		
		btnRadio=[UIButton buttonWithType:UIButtonTypeCustom];
		btnRadio.frame=CGRectMake(10, 240, 25, 25);
		[btnRadio setBackgroundImage:[UIImage imageNamed:@"rdo_btn.png"] forState:UIControlStateNormal];
		[btnRadio setBackgroundImage:[UIImage imageNamed:@"rdo_btn_ckd.png"] forState:UIControlStateHighlighted];
		[btnRadio addTarget:self action:@selector(ClickbtnRadio:) forControlEvents:UIControlEventTouchUpInside];
		[self.view addSubview:btnRadio];
		
		btnRadio1=[UIButton buttonWithType:UIButtonTypeCustom];
		btnRadio1.frame=CGRectMake(10, 270, 25, 25);
		[btnRadio1 setBackgroundImage:[UIImage imageNamed:@"rdo_btn.png"] forState:UIControlStateNormal];
		[btnRadio1 setBackgroundImage:[UIImage imageNamed:@"rdo_btn_ckd.png"] forState:UIControlStateHighlighted];
		[btnRadio1 addTarget:self action:@selector(ClickbtnRadio1:) forControlEvents:UIControlEventTouchUpInside];
		[self.view addSubview:btnRadio1];
		
		btnRadiotext=[[UILabel alloc]initWithFrame:CGRectMake(45,240,240,20)];
		btnRadiotext.text=@"Show All Ignored Claims";
		[self.view addSubview:btnRadiotext];
		btnRadiotext.backgroundColor=[UIColor clearColor];
		[btnRadiotext release];
		
		
		btnRadio1text=[[UILabel alloc]initWithFrame:CGRectMake(45,270,240,20)];
		btnRadio1text.text=@"Ignore All Claims";
		[self.view addSubview:btnRadio1text];
		btnRadio1text.backgroundColor=[UIColor clearColor];
		[btnRadio1text release];
	}
	else {
		/////////adding rounded rect view///////////////////
		view_rounded = [[UIView alloc]initWithFrame:CGRectMake(18, 14, 280, 200)];
		view_rounded.backgroundColor = [UIColor whiteColor];
		view_rounded.layer.cornerRadius=19;
		view_rounded.layer.borderWidth=1.5;
		CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();	
		float grayComponents[4] = { 0.3, 0.3, 0.3, 1.0 };
		view_rounded.layer.borderColor=CGColorCreate(colorSpace, grayComponents);
		//view_rounded.backgroundColor=[UIColor colorWithRed:con.bgRed2/255.0f green:con.bgGreen2/255.0f blue:con.bgBlue2/255.0f alpha:1.0];
		[self.view addSubview:view_rounded];
		
	    customMessageList_dict=[[NSUserDefaults standardUserDefaults] objectForKey:@"customMessageList"];
		
		NSString *strmessage=[[customMessageList_dict valueForKey:@"200003"]valueForKey:@"message"];
		UILabel *lblNoData=[[[UILabel alloc] initWithFrame:CGRectMake(0, 20, 280, 30)]autorelease];
		lblNoData.text=strmessage;
		lblNoData.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
		lblNoData.font=[UIFont fontWithName:con.fontname size:con.fontsize];
		lblNoData.textAlignment=UITextAlignmentCenter;
		lblNoData.backgroundColor=[UIColor clearColor];
		//[lblNoData release];
		//lblNoData=nil;
		[view_rounded addSubview:lblNoData];
		
		//[view_rounded release];
		//view_rounded=nil;
			
		if ([[roleDict objectForKey:@"SHOWALL_PASSTHRU_IGNORED_CLAIM"] isEqualToString:@"Yes"])
		{
			btnRadio=[UIButton buttonWithType:UIButtonTypeCustom];
			btnRadio.frame=CGRectMake(10, 240, 25, 25);
			[btnRadio setBackgroundImage:[UIImage imageNamed:@"rdo_btn.png"] forState:UIControlStateNormal];
			[btnRadio setBackgroundImage:[UIImage imageNamed:@"rdo_btn_ckd.png"] forState:UIControlStateHighlighted];
			[btnRadio addTarget:self action:@selector(ClickbtnRadio:) forControlEvents:UIControlEventTouchUpInside];
			[self.view addSubview:btnRadio];
			
			btnRadiotext=[[UILabel alloc]initWithFrame:CGRectMake(45,240,240,20)];
			btnRadiotext.text=@"Show All Ignored Claims";
			[self.view addSubview:btnRadiotext];
			btnRadiotext.backgroundColor=[UIColor clearColor];
			[btnRadiotext release];
		}
		else
		{
			
			
		}
		
		
		return ;
	}

}


#pragma mark radioButton
-(void)ClickbtnRadio:(id)sender
{
	[self showIgnoredClaims];
	/*if(btnRadio.currentBackgroundImage==[UIImage imageNamed:@"rdo_btn.png"])
	{
		
		
		[btnRadio setBackgroundImage:[UIImage imageNamed:@"rdo_btn_ckd.png"] forState:UIControlStateNormal];
		[btnRadio1 setBackgroundImage:[UIImage imageNamed:@"rdo_btn.png"] forState:UIControlStateNormal];
	}
	
	else 
	{
		
		[btnRadio setBackgroundImage:[UIImage imageNamed:@"rdo_btn.png"] forState:UIControlStateNormal];
		
	}*/
	
}

-(void)ClickbtnRadio1:(id)sender
{

	[self ignoreAllclaim];
	/*if(btnRadio1.currentBackgroundImage==[UIImage imageNamed:@"rdo_btn.png"])
	{
		[self ignoreAllclaim];
		[btnRadio1 setBackgroundImage:[UIImage imageNamed:@"rdo_btn_ckd.png"] forState:UIControlStateNormal];
		[btnRadio setBackgroundImage:[UIImage imageNamed:@"rdo_btn.png"] forState:UIControlStateNormal];
	}
	
	else {
		
		[btnRadio1 setBackgroundImage:[UIImage imageNamed:@"rdo_btn.png"] forState:UIControlStateNormal];
		
	}*/
	
}
#pragma mark Ignoreclaim
-(void)ignoreClaim:(id)sender
{
	UIButton *btn=(UIButton *)sender;
	pclaimid=@"";
	pclaimid=[pclaimid stringByAppendingFormat:@"%d", btn.tag];
	[pclaimid retain];
	
	NSString *message=@"Claims No. ";
	message=[message stringByAppendingString:((claimActivityOBJ *)[ arr_celltytle objectAtIndex:[pclaimid intValue]]).claimID];
	message=[message stringByAppendingString:@" has been ignored for future payments. To confirm, please Click \"Continue.\"." ];
	
	confirmationPage *confirmIgnore=[[confirmationPage alloc]initWithstring:message Target:self
															  SuccessAction:@selector(oncontinue)
															  FailureAction:@selector(onCancel)];
	[self.navigationController pushViewController:confirmIgnore animated:YES];
}
-(void)oncontinue
{
	NSMutableArray *userinfo_arr=[passPerser passresponce];
	RequestPhase2 *r=[[RequestPhase2 alloc] initWithTarget:self
											 SuccessAction:@selector(onSucceffulIgnore)
											 FailureAction:@selector(onFailureIgnoreAll)];
	NSLog(@"%@",pclaimid);
	[r Ignoreclaim:[userinfo_arr objectAtIndex:2] uID:[userinfo_arr objectAtIndex:4] pendingClmID:((claimActivityOBJ *)[ arr_celltytle objectAtIndex:[pclaimid intValue]]).claimID];
	[r release];
	[tools startLoading:self.view childView:loadingView text:@"Ignoring claims. Wait…."];
	
}
-(void)onSucceffulIgnore
{
	NSArray *error=[errorParser getmyerror_arr];
	[tools stopLoading:loadingView];
	
	errorcodeOBJ *myerrorcodeOBJ=(errorcodeOBJ *)[error objectAtIndex:0];
	if ([myerrorcodeOBJ.returnCode isEqualToString:@"0"])
	{
		NSString *message=@"Claims No. ";
		message=[message stringByAppendingString:((claimActivityOBJ *)[ arr_celltytle objectAtIndex:[pclaimid intValue]]).claimID];
		message=[message stringByAppendingString:@"has been ignored for future payments." ];
		
		showMessage *confirmIgnore=[[showMessage alloc]initWithstring:message];
		[self.navigationController pushViewController:confirmIgnore animated:YES];
		
	}
	else {
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Failure" message:myerrorcodeOBJ.errorText delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
		[alert show];
		[alert release];
	}

		
}
-(void)ignoreAllclaim
{
	
	NSString *message=[[customMessageList_dict valueForKey:@"200071"]valueForKey:@"message"];
	confirmationPage *confirmIgnore=[[confirmationPage alloc]initWithstring:message Target:self
															  SuccessAction:@selector(oncontinueAll)
															   FailureAction:@selector(onCancel)];
	[self.navigationController pushViewController:confirmIgnore animated:YES];

}
-(void)oncontinueAll
{
	NSMutableArray *userinfo_arr=[passPerser passresponce];
	RequestPhase2 *r=[[RequestPhase2 alloc] initWithTarget:self
											 SuccessAction:@selector(onSucceffulIgnoreAll)
											 FailureAction:@selector(onFailureIgnoreAll)];
	[r IgnoreAllclaim:[userinfo_arr objectAtIndex:2] uID:[userinfo_arr objectAtIndex:4]];
	[r release];
	[tools startLoading:self.view childView:loadingView text:@"Ignoring claims. Wait…."];
}
								 
-(void)showIgnoredClaims
{
	[view_rounded removeFromSuperview];
	NSMutableArray *userinfo_arr=[passPerser passresponce];
	RequestPhase2 *r=[[RequestPhase2 alloc] initWithTarget:self
											 SuccessAction:@selector(onSucceffulshowAll)
											 FailureAction:@selector(onFailureIgnoreAll)];
	[r ShowAllIgnoreclaim:[userinfo_arr objectAtIndex:2] uID:[userinfo_arr objectAtIndex:4]];
	[r release];
	[tools startLoading:self.view childView:loadingView text:@"Showing Ignored claims. Wait…."];
	
}

-(void)onFailureLogin
{
	[tools stopLoading:loadingView];
}

-(void)onSucceffulshowAll
{
	[tools stopLoading:loadingView];
	 
	NSArray *error=[errorParser getmyerror_arr];
	errorcodeOBJ *myerrorcodeOBJ=(errorcodeOBJ *)[error objectAtIndex:0];
	if ([myerrorcodeOBJ.returnCode isEqualToString:@"220"])
	{
		
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:myerrorcodeOBJ.errorText delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
		[alert show];
		[alert release];
	}
	else {
		
		[self claimPassthruReq];
		[acctable removeFromSuperview];
		
		[btnRadio removeFromSuperview];
		[btnRadiotext removeFromSuperview];
		if([arr_celltytle count]>0)
		{
			[btnRadio1 removeFromSuperview];
			[btnRadio1text removeFromSuperview];
		}
		
	}
	
	
}
	
-(void)onSucceffulIgnoreAll
{
	
		
	NSArray *error=[errorParser getmyerror_arr];
	errorcodeOBJ *myerrorcodeOBJ=(errorcodeOBJ *)[error objectAtIndex:0];
	[tools stopLoading:loadingView];
	
	
	if ([myerrorcodeOBJ.returnCode isEqualToString:@"0"])
	{
		
		NSString *message=[[customMessageList_dict valueForKey:@"200072"]valueForKey:@"message"];

		showMessage *confirmIgnore=[[showMessage alloc]initWithstring:message];
		[self.navigationController pushViewController:confirmIgnore animated:YES];
		
	}
	else {
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Failure" message:myerrorcodeOBJ.errorText delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
		[alert show];
		[alert release];
	}
	
	
		
}
-(void)onFailureIgnoreAll
{
	[tools stopLoading:loadingView];
}
#pragma mark -
#pragma mark payNow



-(void)PayNow:(id)sender

{
	UIButton *btn=(UIButton *)sender;
	NSMutableArray *userinfo_arr=[passPerser passresponce];
	RequestPhase2 *r=[[RequestPhase2 alloc] initWithTarget:self
											 SuccessAction:@selector(onSucceffulPayNow)
											 FailureAction:@selector(onFailurePayNow)];
	[r Paynow:[userinfo_arr objectAtIndex:2] userid:[userinfo_arr objectAtIndex:4] pendingClmID:((claimActivityOBJ *)[ arr_celltytle objectAtIndex:btn.tag]).claimID ];
	[r release];
	[tools startLoading:self.view childView:loadingView text:@"pay Now claims Wait…..."];
	
	
}
-(void)onSucceffulPayNow
{
	[tools stopLoading:loadingView];

	
	arrpaynow=[PaynowParser getarrpaynowdetail];
	
	if([((PaynowOBJ *)[arrpaynow objectAtIndex:0]).strreturnCode isEqualToString:@"0"])
	{
		Paynow *myPaynow=[[Paynow alloc]init];
		[self.navigationController pushViewController:myPaynow animated:YES];
		
	}
	
	else 
	{
		NSLog(@" ERROR TEST %@",((PaynowOBJ*)[arrpaynow objectAtIndex:0]).strerrorText);
		UIAlertView *alertview=[[UIAlertView alloc]initWithTitle:@"Info" message:((PaynowOBJ*)[arrpaynow objectAtIndex:0]).strerrorText delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		alertview.delegate=self;
		[alertview show];
		[alertview release],alertview=nil;
		
		
	}

	
	/*[self claimPassthruReq];
=======
	Paynow *myPaynow=[[Paynow alloc]init];
	[self.navigationController pushViewController:myPaynow animated:YES];
	/*[self claimPassthruReq];
>>>>>>> .r27
	[acctable removeFromSuperview];
	[btnRadio1 removeFromSuperview];
	[btnRadio removeFromSuperview];
	[btnRadiotext removeFromSuperview];
	[btnRadio1text removeFromSuperview];*/
	
}
-(void)onFailurePayNow
{
	[tools stopLoading:loadingView];
}

#pragma mark -


-(void)createtableview
{
	acctable=[[UITableView alloc] initWithFrame:CGRectMake(0,0,320,227) style:UITableViewStyleGrouped];
	acctable.delegate = self;
	acctable.dataSource = self;
	acctable.scrollEnabled = YES;
	acctable.autoresizesSubviews = YES;
	acctable.showsVerticalScrollIndicator=YES;
	acctable.showsHorizontalScrollIndicator=YES;
	acctable.backgroundColor=[UIColor clearColor];
	[self.view addSubview:acctable];	
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView  
{
	return [arr_celltytle  count];
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	
	return 5;
	
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{  
	static NSString *CellIdentifier = @"Cell";
	static NSString *CellIdentifier1 = @"Cell1";
	UITableViewCell *cell;
	
	if(cell==nil)
	{
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier] autorelease];
	}
	else
	{
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier1];
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier1] autorelease];
		
	}
	cell.selectionStyle=UITableViewCellSelectionStyleNone;
	cell.backgroundColor=[UIColor whiteColor];
	
	strFont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];
	if (indexPath.row==0)
	{
		cell.backgroundColor=[UIColor colorWithRed:con.bgRed2/255.0 green:con.bgGreen2/255.0 blue:con.bgBlue2/255.0 alpha:1.0];
		
		
		UILabel *Labelclaimdate=[[UILabel alloc]initWithFrame:CGRectMake(5,3,120,20)];
		Labelclaimdate.font=[UIFont fontWithName:strFont size:con.bodyfntsize];
		Labelclaimdate.backgroundColor=[UIColor clearColor];
		Labelclaimdate.text =((claimActivityOBJ *)[ arr_celltytle objectAtIndex:indexPath.section]).LBLpassthruClaimDate;
		Labelclaimdate.textColor=[UIColor whiteColor];
		[cell.contentView addSubview:Labelclaimdate];
		[Labelclaimdate release];
		
				
		UILabel *LabelAmmount=[[UILabel alloc]initWithFrame:CGRectMake(150,3,145,20)];
		LabelAmmount.font=[UIFont fontWithName:strFont size:con.bodyfntsize];
		LabelAmmount.backgroundColor=[UIColor clearColor];
		LabelAmmount.text = ((claimActivityOBJ *)[ arr_celltytle objectAtIndex:indexPath.section]).passthruClaimDate;
		LabelAmmount.textColor=[UIColor whiteColor];
		LabelAmmount.textAlignment=UITextAlignmentRight;
		[cell.contentView addSubview:LabelAmmount];
		[LabelAmmount release];
		
	}
	else if (indexPath.row==1)
	{
		
		
		UILabel *cellclaimdate=[[UILabel alloc]initWithFrame:CGRectMake(5,3,120,20)];
		cellclaimdate.font=[UIFont fontWithName:strFont size:con.bodyfntsize];
		cellclaimdate.backgroundColor=[UIColor clearColor];
		cellclaimdate.text =((claimActivityOBJ *)[ arr_celltytle objectAtIndex:indexPath.section]).LBLclaimID;
		cellclaimdate.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
		//cellclaimdate.textAlignment=UITextAlignmentRight;
		[cell.contentView addSubview:cellclaimdate];
		[cellclaimdate release];
		
		UILabel *cellclaimaccount=[[UILabel alloc]initWithFrame:CGRectMake(150,3,145,20)];
		cellclaimaccount.font=[UIFont fontWithName:strFont size:con.bodyfntsize];
		cellclaimaccount.backgroundColor=[UIColor clearColor];
		NSString *str=((claimActivityOBJ *)[ arr_celltytle objectAtIndex:indexPath.section]).claimID;
		cellclaimaccount.text = str;
		cellclaimaccount.textAlignment=UITextAlignmentRight;
		[cell.contentView addSubview:cellclaimaccount];
		[cellclaimaccount release];
		
		
	}
	else if (indexPath.row==2)
	{
		
		
		UILabel *cellclaimdate=[[UILabel alloc]initWithFrame:CGRectMake(5,3,120,20)];
		cellclaimdate.font=[UIFont fontWithName:strFont size:con.bodyfntsize];
		cellclaimdate.backgroundColor=[UIColor clearColor];
		cellclaimdate.text =((claimActivityOBJ *)[ arr_celltytle objectAtIndex:indexPath.section]).LBLprovider;
		cellclaimdate.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
		//cellclaimdate.textAlignment=UITextAlignmentRight;
		[cell.contentView addSubview:cellclaimdate];
		[cellclaimdate release];
		
		UILabel *cellclaimaccount=[[UILabel alloc]initWithFrame:CGRectMake(145,3,145,20)];
		cellclaimaccount.font=[UIFont fontWithName:strFont size:con.bodyfntsize];
		cellclaimaccount.backgroundColor=[UIColor clearColor];
		NSString *text =((claimActivityOBJ *)[ arr_celltytle objectAtIndex:indexPath.section]).provider;;
		CGSize constraint = CGSizeMake(CELL_CONTENT_WIDTH - (CELL_CONTENT_MARGIN * 2), 20000.0f);
		CGSize size = [text sizeWithFont:[UIFont fontWithName:strFont size:con.bodyfntsize] constrainedToSize:constraint lineBreakMode:UILineBreakModeWordWrap];
		CGFloat height = MAX(size.height, 10.0f);
		cellclaimaccount.frame=CGRectMake(145,3,145,height);
		cellclaimaccount.numberOfLines=0;
		
		NSString *str=((claimActivityOBJ *)[ arr_celltytle objectAtIndex:indexPath.section]).provider;
		cellclaimaccount.text = str;
		cellclaimaccount.textAlignment=UITextAlignmentRight;
		[cell.contentView addSubview:cellclaimaccount];
		[cellclaimaccount release];
		
		
	}
	
	else if (indexPath.row==3)
	{
		
		
		UILabel *cellclaimdate=[[UILabel alloc]initWithFrame:CGRectMake(5,3,120,20)];
		cellclaimdate.font=[UIFont fontWithName:strFont size:con.bodyfntsize];
		cellclaimdate.backgroundColor=[UIColor clearColor];
		cellclaimdate.text =((claimActivityOBJ *)[ arr_celltytle objectAtIndex:indexPath.section]).LBLamount;
		cellclaimdate.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
		[cell.contentView addSubview:cellclaimdate];
		[cellclaimdate release];
		
		UILabel *cellclaimaccount=[[UILabel alloc]initWithFrame:CGRectMake(150,3,145,20)];
		cellclaimaccount.font=[UIFont fontWithName:strFont size:con.bodyfntsize];
		cellclaimaccount.backgroundColor=[UIColor clearColor];

		NSString *str=[self chkvalue:((claimActivityOBJ *)[ arr_celltytle objectAtIndex:indexPath.section]).amount];
		cellclaimaccount.text = str;
		if (((claimActivityOBJ *)[ arr_celltytle objectAtIndex:indexPath.section]).amount<0)
		{
			
			cellclaimaccount.textColor=[UIColor colorWithRed:con.ngtvRed/255.0f green:con.ngtvGreen/255.0f blue:con.ngtvBlue/255.0f alpha:1.0];
		}
		else 
		{
			cellclaimaccount.textColor=[UIColor colorWithRed:con.posnumRed/255.0f green:con.posnumGreen/255.0f blue:con.posnumBlue/255.0f alpha:1.0];
		}		
		cellclaimaccount.textAlignment=UITextAlignmentRight;
		[cell.contentView addSubview:cellclaimaccount];
		[cellclaimaccount release];
		
				
	}
	else if (indexPath.row==4)
	{
		
		UIButton *btPaynow=[UIButton buttonWithType:UIButtonTypeCustom];
		btPaynow.tag=indexPath.section;
		[btPaynow setTitle:@"Pay Now" forState:UIControlStateNormal];
		btPaynow.tag=indexPath.section;
		
		btPaynow.titleLabel.font=[UIFont fontWithName:con.btnfontname size:con.btnfontsize];
		[btPaynow setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
		[btPaynow setTitleColor:[UIColor grayColor] forState:UIControlStateHighlighted];
		[btPaynow addTarget:self action:@selector(PayNow:) forControlEvents:UIControlEventTouchUpInside];
		btPaynow.frame=CGRectMake(7,2,70,36);
		[cell.contentView addSubview:btPaynow];
		
		UIButton *btndisclosure=[UIButton buttonWithType:UIButtonTypeCustom];
		btndisclosure.tag=indexPath.section;
		[btndisclosure setBackgroundImage:[UIImage imageNamed:@"arrow.png"] forState:UIControlStateNormal];
		[btndisclosure addTarget:self action:@selector(PayNow:) forControlEvents:UIControlEventTouchUpInside];
		btndisclosure.frame=CGRectMake(75,14,9,13);
		[cell.contentView addSubview:btndisclosure];
		
		
		
		UIButton *btIgnore=[UIButton buttonWithType:UIButtonTypeCustom];
		[btIgnore setTitle:@"Ignore" forState:UIControlStateNormal];
		btIgnore.titleLabel.font=[UIFont fontWithName:con.btnfontname size:con.btnfontsize];
		[btIgnore setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
		[btIgnore setTitleColor:[UIColor grayColor] forState:UIControlStateHighlighted];
		[btIgnore addTarget:self action:@selector(ignoreClaim:) forControlEvents:UIControlEventTouchUpInside];
		btIgnore.tag=indexPath.section;
		btIgnore.frame=CGRectMake(212,2,80,36);
		[cell.contentView addSubview:btIgnore];
		
		
		
		UIButton *btndisclosureignore=[UIButton buttonWithType:UIButtonTypeCustom];
		btndisclosureignore.tag=indexPath.section;
		[btndisclosureignore setBackgroundImage:[UIImage imageNamed:@"arrow.png"] forState:UIControlStateNormal];
		[btndisclosureignore addTarget:self action:@selector(ignoreClaim:) forControlEvents:UIControlEventTouchUpInside];
		btndisclosureignore.frame=CGRectMake(277,14,9,13);
		[cell.contentView addSubview:btndisclosureignore];
		
		
	}
	
	return cell;
	
	
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	//return 40;
	
	if(indexPath.row==2)
	{
		strFont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];

		NSString *text =((claimActivityOBJ *)[ arr_celltytle objectAtIndex:indexPath.section]).provider;;
		CGSize constraint = CGSizeMake(CELL_CONTENT_WIDTH - (CELL_CONTENT_MARGIN * 2), 20000.0f);
		CGSize size = [text sizeWithFont:[UIFont fontWithName:strFont size:con.bodyfntsize] constrainedToSize:constraint lineBreakMode:UILineBreakModeWordWrap];
		CGFloat height = MAX(size.height, 10.0f);
		return height + (CELL_CONTENT_MARGIN * 2);
	}
	else 
	{
		return 40;
		
	}

	
	
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
}
-(NSString *)chkvalue:(NSString *)value
{
	NSString *newvalue=@"";
	if([value intValue]>=0)
	{
		newvalue=[newvalue stringByAppendingString:con.ptvPrefix];
		newvalue=[newvalue stringByAppendingString:value];
	}
	else {
		value=[value substringFromIndex:1];
		newvalue=[newvalue stringByAppendingString:con.ngtvPrefix];
		newvalue=[newvalue stringByAppendingString:value];
		newvalue=[newvalue stringByAppendingString:con.ngtvSufix];
		
	}
	return newvalue;
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
