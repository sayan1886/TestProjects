//
//  scheduleDetails.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 26/04/11.
//  Copyright 2011 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@class configurables;
@interface scheduleDetails : UIViewController<UITableViewDelegate,UITableViewDataSource>  {

	NSInteger selectedRow;
	NSArray *arr_celltytle,*arr_celldetails;
	configurables *con;
	NSMutableArray *arr_alltransaction;
	NSString *strFont;
}
-(id)initWithInvestment:(BOOL)value;
-(void)signoutbt;
-(void)createtableview;
-(NSString *)chkvalue:(NSString *)value;
-(NSString *)formatString:(NSString *)Uname;
@end
