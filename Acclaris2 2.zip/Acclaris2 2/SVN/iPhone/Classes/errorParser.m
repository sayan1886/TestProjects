//
//  errorParser.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 28/04/11.
//  Copyright 2011 ObjectSol Technologies. All rights reserved.
//

#import "errorParser.h"
#import "errorcodeOBJ.h"

@implementation errorParser
NSMutableArray *myerrordetails;
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error
{
	
	
	NSXMLParser *parser;
	parser = [[NSXMLParser alloc] initWithData:data];
    [parser setDelegate:self];
	[parser setShouldProcessNamespaces:NO];
    [parser setShouldReportNamespacePrefixes:NO];
    [parser setShouldResolveExternalEntities:NO];
    [parser parse];
    NSError *parseError = [parser parserError];
    if (parseError && error) 
	{
        *error = parseError;
    }
	[parser release];
}

-(void)parserDidStartDocument:(NSXMLParser *)parser
{
	myerrorcodeOBJ=[[errorcodeOBJ alloc]init];
	myerrordetails=[[NSMutableArray alloc]init];
	
}		
- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
	if (qName)
	{
		elementName = qName;
	}
	else 
		if([elementName isEqualToString:@"returnCode"])
		{
			
			contentOfString=[NSMutableString string];
			[contentOfString retain];
			return;		
			
		}
		else 
			if([elementName isEqualToString:@"errorText"])
			{
				
				contentOfString=[NSMutableString string];
				[contentOfString retain];
				return;		
				
			}
	
}
- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName     
{	
	if (qName)
	{
        elementName = qName;
		
    }
	else 
		if([elementName isEqualToString:@"returnCode"])
		{
			if(contentOfString)
			{
				myerrorcodeOBJ.returnCode=contentOfString;
				[contentOfString release];
				contentOfString = nil;
				
				
			}	
			
		}
		else 
			if([elementName isEqualToString:@"errorText"])
			{
				if(contentOfString)
				{
					myerrorcodeOBJ.errorText=contentOfString;
					[contentOfString release];
					contentOfString = nil;
					
					
				}		
				
			}
	
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
	if(contentOfString)
		[contentOfString appendString:string];
}

- (void)parserDidEndDocument:(NSXMLParser *)parse
{
	[myerrordetails addObject:myerrorcodeOBJ];
	
	myerrorcodeOBJ=(errorcodeOBJ *)[myerrordetails objectAtIndex:0];
	NSLog(@"------%@",myerrorcodeOBJ.returnCode);
	NSLog(@"------%@",myerrorcodeOBJ.errorText);
}
+(NSMutableArray *)getmyerror_arr
{
	if (myerrordetails) {
		
		return myerrordetails;
	}
	else {
		return nil;
	}
	
}

@end
