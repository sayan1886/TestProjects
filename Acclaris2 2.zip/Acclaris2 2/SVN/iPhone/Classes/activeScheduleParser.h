//
//  activeScheduleParser.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 08/04/11.
//  Copyright 2011 ObjectSol Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>

@class ActiveScheduleOBJ;
@class ScheduleOBJ;
@interface activeScheduleParser : NSObject<NSXMLParserDelegate> {

	NSMutableString *contentOfString;
	ActiveScheduleOBJ *myActiveScheduleOBJ;
	ScheduleOBJ *myScheduleOBJ;
}
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error;
+(NSMutableArray *)get_errorCodeSchedule;
+(NSMutableArray *)getscheduleArr;
@end
