//
//  ticketLogsOBJ.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 27/10/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import "ticketLogsOBJ.h"


@implementation ticketLogsOBJ

@synthesize logID;
@synthesize	ticketID;
@synthesize	action;
@synthesize	loggedBy;
@synthesize	loggedThru;
@synthesize	note;
@synthesize	isPrivate;
@synthesize	minutesSpent;
@end
