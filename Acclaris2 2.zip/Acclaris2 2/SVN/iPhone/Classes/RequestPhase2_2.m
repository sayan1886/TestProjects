//
//  RequestPhase2_2.m
//  Acclaris
//
//  Created by Subhojit on 09/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "RequestPhase2_2.h"
#import "SSCrypto.h"
#import  "GopaperlessParser.h"

@implementation RequestPhase2_2
-(id)initWithTarget:(id)actionTarget
	  SuccessAction:(SEL)successAction 
	  FailureAction:(SEL)failureAction
{
	self=[super init];
	if(self==nil)
	{
		return nil;
	}
	
	target=actionTarget;
	successHandler=successAction;
	failureHandler=failureAction;
	
	
	return self;
}
#pragma mark CREATE HEADER
-(NSMutableString *)createHeader
{
	NSMutableString *header=[[NSMutableString alloc] init];
	[header appendString:@"<?xml version=\"1.0\" encoding=\"utf-8\" ?>"];
	[header appendString:@"<soapenv:Envelope xmlns:ser=\"http://www.acclaris.com/servicetypesma_p2\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">"];
	
	//[header appendString:@"<soapenv:Envelope xmlns:ser=\"http://www.acclaris.com/servicetypesma_p2\" xmlns:ser1="http://www.acclaris.com/servicetypesma" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
	
	
	
	
	[header appendString:@"<soapenv:Header><wsse:Security soapenv:mustUnderstand=\"1\" xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\">"];
	[header appendString:@"<wsse:UsernameToken wsu:Id=\"UsernameToken-28376915\" xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">"];
	[header appendString:@"<wsse:Username>objectsolwsuser</wsse:Username>"];
	[header appendString:@"<wsse:Password Type=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordDigest\">"];
	
	SSCrypto *crypto = [[SSCrypto alloc ]init];
	
	NSTimeInterval t = [[NSDate date]timeIntervalSince1970];
	NSString * nonce = [[NSNumber numberWithDouble:t]stringValue];
	
	[crypto setClearTextWithString:nonce];
	NSString *base64nonce = [[crypto clearTextAsData] encodeBase64WithNewlines:NO ];
	
	//NSString *created = [ DateFormate stringFromDate:[ NSDate date ] ];
	
	
	NSString *created =[self getUTCFormateDate:[ NSDate date]];
	
	
	NSString *combined = [ NSString stringWithFormat:@"%@%@%@", nonce, created, @"local123" ];
	[ crypto setClearTextWithString:combined ];
	NSString *passwordDigest = [ [crypto digest:@"SHA1" ] encodeBase64WithNewlines:NO ];
	[header appendString:passwordDigest];
	[header appendString:@"</wsse:Password><wsse:Nonce>"];
	[header appendString:base64nonce];
	[header appendString:@"</wsse:Nonce><wsu:Created>"];
	[header appendString:created];
	[header appendString:@"</wsu:Created></wsse:UsernameToken></wsse:Security></soapenv:Header>"];
	
	return header;
}
#pragma mark CREATE HEADER
-(NSMutableString *)createHeader1
{
	NSMutableString *header=[[NSMutableString alloc] init];
	[header appendString:@"<?xml version=\"1.0\" encoding=\"utf-8\" ?>"];
	//[header appendString:@"<soapenv:Envelope xmlns:ser=\"http://www.acclaris.com/servicetypesma_p2\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">"];
	
	
	//[header appendString:@"<soapenv:Envelope xmlns:ser=\"http://www.acclaris.com/servicetypesma_p2\" xmlns:ser1=\"http://www.acclaris.com/servicetypesma\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">"];
	
	
	[header appendString:@"<soapenv:Envelope xmlns:ser=\"http://www.acclaris.com/servicetypesma_p2\" xmlns:ser1=\"http://www.acclaris.com/servicetypesma\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">"];
	
	[header appendString:@"<soapenv:Header><wsse:Security soapenv:mustUnderstand=\"1\" xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\">"];
	[header appendString:@"<wsse:UsernameToken wsu:Id=\"UsernameToken-28376915\" xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">"];
	[header appendString:@"<wsse:Username>objectsolwsuser</wsse:Username>"];
	[header appendString:@"<wsse:Password Type=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordDigest\">"];
	
	SSCrypto *crypto = [ [ SSCrypto alloc ] init ];
	
	NSTimeInterval t = [ [ NSDate date ] timeIntervalSince1970 ];
	NSString * nonce = [ [ NSNumber numberWithDouble:t ] stringValue ];
	
	[ crypto setClearTextWithString:nonce ];
	NSString *base64nonce = [ [ crypto clearTextAsData ] encodeBase64WithNewlines:NO ];
	
	//NSString *created = [ DateFormate stringFromDate:[ NSDate date ] ];
	
	
	NSString *created =[self getUTCFormateDate:[ NSDate date]];
	
	
	NSString *combined = [ NSString stringWithFormat:@"%@%@%@", nonce, created, @"local123" ];
	[ crypto setClearTextWithString:combined ];
	NSString *passwordDigest = [ [crypto digest:@"SHA1" ] encodeBase64WithNewlines:NO ];
	[header appendString:passwordDigest];
	[header appendString:@"</wsse:Password><wsse:Nonce>"];
	[header appendString:base64nonce];
	[header appendString:@"</wsse:Nonce><wsu:Created>"];
	[header appendString:created];
	[header appendString:@"</wsu:Created></wsse:UsernameToken></wsse:Security></soapenv:Header>"];
	
	return header;
}

-(NSString *)getUTCFormateDate:(NSDate *)localDate
{
	NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
	NSTimeZone *timeZone = [NSTimeZone timeZoneWithName:@"UTC"];
	[dateFormatter setTimeZone:timeZone];
	[dateFormatter setDateFormat:@"YYYY-MM-dd'T'HH:mm:ss.S"];
	NSString *dateString = [dateFormatter stringFromDate:localDate];
	
	return dateString;
}

#pragma mark -
#pragma mark serverconnection
#pragma mark -


-(void)AddEmail:(NSString *)participantID uID:(NSString *)userID  email:(NSString *)email
				 
{

		if([AcclarisAppDelegate isNetworkAvailable])
		{
			;
		}
		else
		{   [target performSelector:failureHandler];
			UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
			[alert show];
			return;
		}
		
		whichAPI=@"AddEmail";
		app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
		
		NSMutableString *sRequest=[[NSMutableString alloc] init];
		sRequest=[self createHeader];
		[sRequest appendString:@" <soapenv:Body><ser:AddEmailMA><ser:participantID>"];
		[sRequest appendString:participantID];
		[sRequest appendString:@"</ser:participantID><ser:participantCode/><ser:userID>"];
		[sRequest appendString:userID];
		[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType><ser:clientName>Mobile</ser:clientName><ser:email>"];
		[sRequest appendString:email];
		[sRequest appendString:@"</ser:email><ser:param1/><ser:param2/><ser:param3/><ser:param4/></ser:AddEmailMA></soapenv:Body></soapenv:Envelope>"];
	
		NSLog(@"request string: %@",sRequest);
		NSString *link=urllink;
		link=[link stringByAppendingString:@"GetEEPrflSmryMAService"];
		[self callPostMethod:sRequest Action:@"AddEmailMA" API:link];
		
		
}

-(void)AddPhoneNumber:(NSString *)participantID uID:(NSString *)userID  areaP:(NSString *)areaP restP:(NSString *)restP extnP:(NSString *)extnP
        
				areaS:(NSString *)areaS	restS:(NSString *)restS  extnS:(NSString *)extnS
{
	
	
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	
	else
		
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	whichAPI=@"AddPhoneNumber";
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader];
	[sRequest appendString:@" <soapenv:Body><ser:AddPhoneMA><ser:participantID>"];
	[sRequest appendString:participantID];
	[sRequest appendString:@"</ser:participantID><ser:participantCode/><ser:userID>"];
	[sRequest appendString:userID];
	[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType><ser:clientName>Mobile</ser:clientName><ser:primaryPhoneBn><ser:type/><ser:area>"];
	[sRequest appendString:areaP];
	[sRequest appendString:@"</ser:area><ser:rest>"];
	[sRequest appendString:restP];
	[sRequest appendString:@"</ser:rest><ser:extn>"];
	[sRequest appendString:extnP];
	[sRequest appendString:@"</ser:extn></ser:primaryPhoneBn><ser:secondaryPhoneBn><ser:type>?</ser:type><ser:area>"];
	[sRequest appendString:areaS];
	[sRequest appendString:@"</ser:area><ser:rest>"];
	[sRequest appendString:restS];
	[sRequest appendString:@"</ser:rest><ser:extn>"];
	[sRequest appendString:extnS];
	[sRequest appendString:@"</ser:extn></ser:secondaryPhoneBn><ser:param1>?</ser:param1><ser:param2>?</ser:param2><ser:param3>?</ser:param3><ser:param4>?</ser:param4></ser:AddPhoneMA></soapenv:Body></soapenv:Envelope>"];
	
	
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	link=[link stringByAppendingString:@"GetEEPrflSmryMAService"];
	[self callPostMethod:sRequest Action:@"AddPhoneMA" API:link];
	
	
}
-(void)VerifyEmail:(NSString *)participantID uID:(NSString *)userID  email:(NSString *)email
{
	
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	
	else
		
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	whichAPI=@"VerifyEmail";
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader];
	[sRequest appendString:@" <soapenv:Body><ser:VerifyEmailMA><ser:participantID>"];
	[sRequest appendString:participantID];
	[sRequest appendString:@"</ser:participantID><ser:participantCode/><ser:userID>"];
	[sRequest appendString:userID];
	[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType><ser:clientName>Mobile</ser:clientName><ser:email>"];
	[sRequest appendString:email];
	[sRequest appendString:@"</ser:email><ser:verifiedOn>?</ser:verifiedOn><ser:param1/><ser:param2/><ser:param3/><ser:param4/></ser:VerifyEmailMA></soapenv:Body></soapenv:Envelope>"];
	
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	link=[link stringByAppendingString:@"GetEEPrflSmryMAService"];
	[self callPostMethod:sRequest Action:@"VerifyEmailMA" API:link];
	
		
}
-(void)GetPrimarySummery:(NSString *)participantID uID:(NSString *)userID  
{
	
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	
	else
		
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	whichAPI=@"GetPrimarySummery";
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader];
	[sRequest appendString:@"<soapenv:Body><ser:GetEEPrflSmryMA><ser:participantID>"];
	[sRequest appendString:participantID];
	[sRequest appendString:@"</ser:participantID><ser:participantCode/><ser:userID>"];
	[sRequest appendString:userID];
	[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType><ser:clientName>Mobile</ser:clientName><ser:param1>?</ser:param1><ser:param2>?</ser:param2><ser:param3>?</ser:param3><ser:param4>?</ser:param4></ser:GetEEPrflSmryMA></soapenv:Body></soapenv:Envelope>"];
	 
		
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	link=[link stringByAppendingString:@"GetEEPrflSmryMAService"];
	[self callPostMethod:sRequest Action:@"GetEEPrflSmryMA" API:link];
	
	
}

-(void)SubmitforeCommunication:(NSString *)participantID uID:(NSString *)userID email:(NSString *)email  reenterEmail:(NSString *)reenterEmail hsaStatement:(NSString *)hsaStatement
			  accountStatement:(NSString *)accountStatement otherCommunication:(NSString *)otherCommunication
{
	
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	
	else
		
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	whichAPI=@"SubmitforeCommunication";
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader];
	[sRequest appendString:@"<soapenv:Body><ser:GoPaperLessMA><ser:participantID>"];
	[sRequest appendString:participantID];
	[sRequest appendString:@"</ser:participantID><ser:participantCode/><ser:userID>"];
	[sRequest appendString:userID];
	[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType><ser:clientName>Mobile</ser:clientName><ser:goPaperLessIPDto><ser:email>"];
	[sRequest appendString:email];
	[sRequest appendString:@"</ser:email><ser:reenterEmail>"];
	[sRequest appendString:reenterEmail];
	[sRequest appendString:@"</ser:reenterEmail><ser:hsaStatement>"];
	[sRequest appendString:hsaStatement];
	[sRequest appendString:@"</ser:hsaStatement><ser:accountStatement>"];
	[sRequest appendString:accountStatement];
	[sRequest appendString:@"</ser:accountStatement><ser:otherCommunication>"];
	[sRequest appendString:otherCommunication];
	[sRequest appendString:@"</ser:otherCommunication></ser:goPaperLessIPDto><ser:param1>?</ser:param1><ser:param2>?</ser:param2><ser:param3>?</ser:param3><ser:param4>?</ser:param4></ser:GoPaperLessMA></soapenv:Body></soapenv:Envelope>"];
	
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	link=[link stringByAppendingString:@"GetEEPrflSmryMAService"];
	[self callPostMethod:sRequest Action:@"VerifyEmailMA" API:link];
	
	
}
-(void)EditAchRequest:(NSString *)participantID uID:(NSString *)userID  accountType:(NSString *)accountType accountNo:(NSString *)accountNo reAccountNo:(NSString *)reAccountNo
			routingNo:(NSString *)routingNo   reRoutingNo:(NSString *)reRoutingNo   status:(NSString *)status dob:(NSString *)dob  
				email:(NSString *)email
{
	
	
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	
	else
		
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	whichAPI=@"EditAchRequest";
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader];
	[sRequest appendString:@"<soapenv:Body><ser:EditACHMA><ser:participantID>"];
	[sRequest appendString:participantID];
	[sRequest appendString:@"</ser:participantID><ser:participantCode/><ser:userID>"];
	[sRequest appendString:userID];
	[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType><ser:clientName>Mobile</ser:clientName><ser:achIPBean><ser:accountType>"];
	[sRequest appendString:accountType];
	[sRequest appendString:@"</ser:accountType><ser:accountNo>"];
	[sRequest appendString:accountNo];
	[sRequest appendString:@"</ser:accountNo><ser:reAccountNo>"];
	[sRequest appendString:reAccountNo];
	[sRequest appendString:@"</ser:reAccountNo><ser:routingNo>"];
	[sRequest appendString:routingNo];
	[sRequest appendString:@"</ser:routingNo><ser:reRoutingNo>"];
	[sRequest appendString:reRoutingNo];
	[sRequest appendString:@"</ser:reRoutingNo><ser:status>"];
	[sRequest appendString:status];
	[sRequest appendString:@"</ser:status><ser:dob>"];
	[sRequest appendString:dob];
	[sRequest appendString:@"</ser:dob><ser:email>"];
	[sRequest appendString:email];
	[sRequest appendString:@"</ser:email></ser:achIPBean><ser:param1>?</ser:param1><ser:param2>?</ser:param2><ser:param3>?</ser:param3><ser:param4>?</ser:param4></ser:EditACHMA></soapenv:Body></soapenv:Envelope>"];
	
	
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	link=[link stringByAppendingString:@"GetEEPrflSmryMAService"];
	[self callPostMethod:sRequest Action:@"EditACHMA" API:link];
	
	
}	
-(void)GetCustomText:(NSString *)participantID uID:(NSString *)userID  

{
	
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	
	else
		
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	whichAPI=@"GetCustomText";
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader];
	[sRequest appendString:@"<soapenv:Body><ser:GetCustomTextMA><ser:participantID>"];
	[sRequest appendString:participantID];
	[sRequest appendString:@"</ser:participantID><ser:participantCode/><ser:userID>"];
	[sRequest appendString:userID];
	[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType><ser:clientName>Mobile</ser:clientName><ser:objectName>HSAECOMMAGREE</ser:objectName><ser:objectType>Section</ser:objectType><ser:param1>?</ser:param1><ser:param2>?</ser:param2><ser:param3>?</ser:param3><ser:param4>?</ser:param4></ser:GetCustomTextMA></soapenv:Body></soapenv:Envelope>"];
	
	
	
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	link=[link stringByAppendingString:@"GetCustomTextMAService"];
	[self callPostMethod:sRequest Action:@"GetCustomTextMA" API:link];
	
	
}
-(void)ShowImage:(NSString *)participantID uID:(NSString *)userID  fileID:(NSString *)fileID
{
	
	
	if([AcclarisAppDelegate isNetworkAvailable])
	{
		;
	}
	
	else
		
	{   [target performSelector:failureHandler];
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Network not available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
		[alert show];
		return;
	}
	
	whichAPI=@"ShowImage";
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	
	NSMutableString *sRequest=[[NSMutableString alloc] init];
	sRequest=[self createHeader];
	[sRequest appendString:@"<soapenv:Body><ser:GetReceiptImageMA><ser:participantID>"];
	[sRequest appendString:participantID];
	[sRequest appendString:@"</ser:participantID><ser:participantCode/><ser:userID>"];
	[sRequest appendString:userID];
	[sRequest appendString:@"</ser:userID><ser:userType>EE</ser:userType><ser:fileID>"];
	[sRequest appendString:fileID];
	[sRequest appendString:@"</ser:fileID><ser:width>123</ser:width><ser:height>123</ser:height><ser:quality/><ser:clientName>Mobile</ser:clientName><ser:param1/><ser:param2/><ser:param3/><ser:param4/></ser:GetReceiptImageMA></soapenv:Body></soapenv:Envelope>"];
	
	NSLog(@"request string: %@",sRequest);
	NSString *link=urllink;
	link=[link stringByAppendingString:@"GetReceiptImageMAService"];
	[self callPostMethod:sRequest Action:@"GetReceiptImageMA" API:link];
}
-(void)callPostMethod:(NSMutableString *)sRequest Action:(NSString *)action API:(NSString *)api
{
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
	
	NSData *postBody;
	postBody=[sRequest dataUsingEncoding:NSUTF8StringEncoding];
	NSURL *apiURL=[NSURL URLWithString:api];
	NSMutableURLRequest *request=[NSMutableURLRequest requestWithURL:apiURL];
	[request addValue:@"text/xml" forHTTPHeaderField:@"Content-Type"];
	[request addValue:action forHTTPHeaderField:@"SOAPAction"];
	[request setHTTPMethod:@"POST"];
	[request setHTTPBody:postBody];
	NSURLConnection *conn=[[NSURLConnection alloc] initWithRequest:request delegate:self];
	if (conn)
	{
		;
	}
}

#pragma mark -
#pragma mark Connection Deligate
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
	NSLog(@"HERE RESPONSE: %d",[(NSHTTPURLResponse*) response statusCode]);
	if([(NSHTTPURLResponse*) response statusCode]!=200)
	{
		isstatus=YES;
		errorResponseAlert *myerrorResponseAlert=[[errorResponseAlert alloc]init];
		[myerrorResponseAlert showAlert];
		[target performSelector:failureHandler withObject:nil withObject:nil];
		[myerrorResponseAlert release],myerrorResponseAlert=nil;

		return;
		
	}
	if(d2)
		[d2 release];
	d2=[[NSMutableData alloc]init];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
	[d2 appendData:data];	
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{  
	
	if(isstatus==YES)
	{
		isstatus=NO;
		return;
	}
	
	else
	{
		
	NSString *data_Response = [[NSString alloc] initWithData:d2 encoding:NSUTF8StringEncoding];
	NSLog(@"Response_of_submit =%@",data_Response);
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
	NSString *XHTMLsearchForWarning = @"XHTML";
	NSRange rangeXHTMLWarning = [data_Response rangeOfString : XHTMLsearchForWarning];
	
	NSString *HTMLsearchForWarning = @"HTML";
	NSRange rangeHTMLWarning = [data_Response rangeOfString : HTMLsearchForWarning];
	if (rangeXHTMLWarning.location != NSNotFound || rangeHTMLWarning.location != NSNotFound)
	{
		
		[target performSelector:failureHandler];
		
		NSDictionary *customMessageList_dict=[[NSUserDefaults standardUserDefaults] objectForKey:@"customMessageList"];

		NSString *strmessage=[[customMessageList_dict valueForKey:@"200004"]valueForKey:@"message"];
		
		
		NSString *strtype=[[customMessageList_dict valueForKey:@"200004"]valueForKey:@"type"];
		
		
		UIAlertView *alert=[[UIAlertView alloc] initWithTitle:strtype message:strmessage delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		[alert show];
		[alert release];
		return ;
	}
	else if ([whichAPI isEqualToString:@"AddEmail"]) 
	{
		
		
		NSError *parseError = nil;
		AddEmailParser *obj= [[AddEmailParser alloc] init];
		[obj parseXMLFileAtData:d2 parseError:&parseError];	
		[obj release];
		[target performSelector:successHandler withObject:nil withObject:nil];
		
	
	}
	
	else if ([whichAPI isEqualToString:@"AddPhoneNumber"]) 
	{
		
		NSError *parseError = nil;
		AddEmailParser *obj= [[AddEmailParser alloc] init];
		[obj parseXMLFileAtData:d2 parseError:&parseError];	
		[obj release];
		[target performSelector:successHandler withObject:nil withObject:nil];
		
		
	}
	else if([whichAPI isEqualToString:@"VerifyEmail"])
	{
		
		
		NSError *parseError = nil;
		AddEmailParser *obj= [[AddEmailParser alloc] init];
		[obj parseXMLFileAtData:d2 parseError:&parseError];	
		[obj release];
		[target performSelector:successHandler withObject:nil withObject:nil];
		
	}
	
	else if([whichAPI isEqualToString:@"GetPrimarySummery"])
	 {
		
		 NSError *parseError = nil;
		 
		//NSString* filePath = [[NSBundle mainBundle] pathForResource:@"Gopaperless" ofType:@"xml"];
		// NSString* fileContents = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
		// NSMutableData *data=((NSMutableData *)[fileContents dataUsingEncoding:NSUTF8StringEncoding]);
		 //for testing config files*/
		 
		//NSString *data_Response = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
		//NSLog(@"\n\n\n\n\n\nResponse_of_submit =%@",data_Response);
		 
		 GopaperlessParser *obj= [[GopaperlessParser alloc] init];
		 [obj parseXMLFileAtData:d2 parseError:&parseError];	
		 [obj release];
		 
		[target performSelector:successHandler withObject:nil withObject:nil];
		
	 }
	
	else if([whichAPI isEqualToString:@"SubmitforeCommunication"])
	{
		
		NSError *parseError = nil;
		PaynowcontinueParser *objPaynowcontinueParser= [[PaynowcontinueParser alloc] init];
		[objPaynowcontinueParser parseXMLFileAtData:d2 parseError:&parseError];	
		[objPaynowcontinueParser release];
		
		
		[target performSelector:successHandler withObject:nil withObject:nil];
		
	}
	else if([whichAPI isEqualToString:@"EditAchRequest"])
		
	{
		
		
		NSError *parseError = nil;
		PaynowcontinueParser *objPaynowcontinueParser= [[PaynowcontinueParser alloc] init];
		[objPaynowcontinueParser parseXMLFileAtData:d2 parseError:&parseError];	
		[objPaynowcontinueParser release];
		
		[target performSelector:successHandler withObject:nil withObject:nil];
		
	}
	
	else if([whichAPI isEqualToString:@"GetCustomText"])
		
	{
		
		NSError *parseError = nil;
		eCommunicationParser *obj=[[eCommunicationParser alloc] init];
		[obj parseXMLFileAtData:d2 parseError:&parseError];	
		[obj release];
		
		[target performSelector:successHandler withObject:nil withObject:nil];
		
	}
	
	else if([whichAPI isEqualToString:@"ShowImage"])
		
	{
		
		NSError *parseError = nil;
		ReceiptShowParser *obj=[[ReceiptShowParser alloc] init];
		[obj parseXMLFileAtData:d2 parseError:&parseError];	
		[obj release];
		
		
		[target performSelector:successHandler withObject:nil withObject:nil];
		
	}
 }

	
}	
@end
