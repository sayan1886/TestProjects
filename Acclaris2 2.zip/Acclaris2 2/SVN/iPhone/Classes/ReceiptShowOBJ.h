//
//  ReceiptShowOBJ.h
//  Acclaris
//
//  Created by Subhojit on 19/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface ReceiptShowOBJ : NSObject {

	NSString *strreturnCode;
	NSString *strerrorText;
	NSString *strimageData;
}
@property(nonatomic,retain)NSString * strreturnCode;
@property(nonatomic,retain)NSString * strerrorText;
@property(nonatomic,retain)NSString * strimageData;
@end
