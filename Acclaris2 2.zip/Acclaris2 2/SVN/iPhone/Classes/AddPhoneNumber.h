//
//  AddPhoneNumber.h
//  Acclaris
//
//  Created by Subhojit on 18/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyTools.h"
#import "Decode64.h"
#import "RequestPhase2_2.h"
#import "passPerser.h"
#import "AddEmailOBJ.h"
#import "AddEmailParser.h"

@class configurables;

@interface AddPhoneNumber : UIViewController<UITextFieldDelegate> {

	UITextField *txtPCode;
	UITextField *txtPphno;
	UITextField *txtExtPno;
	
	UITextField  *txtSCode;
	UITextField	 *txtSphno;
	UITextField   *txtSExtPno;
	MyTools       *tools;
	configurables  *con;
	UIView *loadingView;
	NSDictionary *customMessageList_dict;
}
-(void)CreateView;
@end
