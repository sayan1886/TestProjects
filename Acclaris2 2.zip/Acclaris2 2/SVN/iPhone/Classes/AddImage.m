    //
//  AddImage.m
//  Acclaris
//
//  Created by Subhojit on 24/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "AddImage.h"
#import "configurables.h"
#import "AcclarisViewController.h"
#import "imageUploadForClaim.h"
#import "errorParser.h"
#import "errorcodeOBJ.h"
NSMutableArray  *arrImage,*arrImage1;

@implementation AddImage
-(id)initWithindex:(int)row
{
	
	
	
	self=[super init];
	if(self==nil)
	{
		return nil;
	}
	else 
	{
		
	  rowSelected=row;
	
	}
	return self;
}


- (void)viewDidLoad {
    [super viewDidLoad];
	
	NSMutableArray *arr_myconfig=[AcclarisViewController staticarr_config];
	con=(configurables *)[arr_myconfig objectAtIndex:0];
	tools=[[MyTools alloc]init];
	loadingView=[tools createActivityIndicator1];
	self.view.backgroundColor = [UIColor colorWithRed:con.bgRed/255.0f green:con.bgGreen/255.0f blue:con.bgBlue/255.0f alpha:1.0];
	
	self.navigationController.navigationBar.tintColor=[UIColor colorWithRed:con.navbarRed/255.0f green:con.navbarGreen/255.0f blue:con.navbarBlue/255.0f alpha:1.0];
	
	UIImageView *logo_img = [[UIImageView alloc]initWithFrame:CGRectMake(0, 2, 170, 40)];
	NSData *data=[Base64 decode:con.logoImgdata];
	logo_img.image=	[UIImage imageWithData:[NSData dataWithData:data]];
	self.navigationItem.titleView=logo_img;
		
	UIBarButtonItem *signoutButton = [[UIBarButtonItem alloc]
									  initWithTitle:@"Sign Off"
									  style:UIBarButtonItemStyleBordered
									  target:self
									  action:@selector(signout)];
    self.navigationItem.rightBarButtonItem =signoutButton;
	arrImage=[[NSMutableArray alloc]init];
	noOfFail=0;
	[self CreateView];
}

-(void)signout
{
	
	[((AcclarisAppDelegate *)[[UIApplication sharedApplication] delegate]) removeTabBar];
	
}
-(void)CreateView
{
	NSData *data_btnimg=[Base64 decode:con.btnImgdata];//btn background image
			
	UIView *HeaderView=[[[UIView alloc]initWithFrame:CGRectMake(0, 0, 320, 60)]autorelease];
	HeaderView.backgroundColor=[UIColor colorWithRed:con.bgRed2/255.0 green:con.bgGreen2/255.0 blue:con.bgBlue2/255.0 alpha:1.0];
	[self.view addSubview:HeaderView];
	
	NSString *strViewTitle=@"Upload Image for claim";
	//strViewTitle=[strViewTitle stringByAppendingString:@"\n"];
	//strViewTitle=[strViewTitle stringByAppendingFormat:@"%@",@"claim"];
	
	UILabel *lbltext=[[UILabel alloc]initWithFrame:CGRectMake(10, 5, 250, 60)];
	lbltext.text=strViewTitle;
	lbltext.backgroundColor=[UIColor clearColor];
	lbltext.textColor=[UIColor whiteColor];
	//lbltext.numberOfLines=0;
	lbltext.font=[UIFont fontWithName:@"Helvetica-Bold" size:18];
	[HeaderView addSubview:lbltext];
	[lbltext release],lbltext=nil;
	
	
	UIButton *btnAddPhoto=[UIButton buttonWithType:UIButtonTypeCustom];
	btnAddPhoto.frame=CGRectMake(75, 270, 170, 40);
	[btnAddPhoto setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
	[btnAddPhoto setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	btnAddPhoto.titleLabel.font = [UIFont fontWithName:con.btnfontname size:con.btnfontsize];
	[btnAddPhoto setTitle:@"Add Image" forState:UIControlStateNormal];
	[btnAddPhoto addTarget:self action:@selector(ClickbtnAddPhoto) forControlEvents:UIControlEventTouchUpInside];	
	[self.view addSubview:btnAddPhoto];
	
	
	UIButton *btnUploadPhoto=[UIButton buttonWithType:UIButtonTypeCustom];
	btnUploadPhoto.frame=CGRectMake(30, 325, 260, 40);
	[btnUploadPhoto setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
	[btnUploadPhoto setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	btnUploadPhoto.titleLabel.font = [UIFont fontWithName:con.btnfontname size:con.btnfontsize];
	[btnUploadPhoto setTitle:@"Upload Image" forState:UIControlStateNormal];
	[btnUploadPhoto addTarget:self action:@selector(ClickUploadPhoto) forControlEvents:UIControlEventTouchUpInside];	
	[self.view addSubview:btnUploadPhoto];
	
	Imageno=0;
	
	
}
-(void)ClickUploadPhoto
{
	if ([arrImage count]<=0) {
		
		UIAlertView *alertview=[[UIAlertView alloc]initWithTitle:@"Alert" message:@"Nothing to Upload" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		alertview.delegate=self;
		[alertview show];
		[alertview release],alertview=nil;
	}
	else {
		[tools startLoading:self.view childView:loadingView text:@"Uploading Image. Wait…."];
		arrImage1=arrImage;
		[self performSelector:@selector(UploadPhoto) withObject:nil afterDelay:0.1];
	}
	

}
-(void)UploadPhoto
{
	[tools stopLoading:loadingView];
	[tools startLoading:self.view childView:loadingView text:@"Uploading Image. Wait…."];
	
	
		imageUploadForClaim *myimageUploadForClaim=[[imageUploadForClaim alloc]initWithTarget:self
																				SuccessAction:@selector(onSuccesful)
																				FailureAction:@selector(onFailure) rowno:rowSelected];
		
	
	[myimageUploadForClaim uploadImage:Imageno];
	
	
	
}
-(void)onSuccesful
{
	[tools stopLoading:loadingView];
	NSArray *error=[errorParser getmyerror_arr];
	errorcodeOBJ *myerrorcodeOBJ=(errorcodeOBJ *)[error objectAtIndex:0];
	if ([arrImage count]>noOfFail+1)
	{
		
		if ([myerrorcodeOBJ.returnCode isEqualToString:@"0"])
		{
		
			[arrImage removeObjectAtIndex:noOfFail];
		}
		else {
			noOfFail++;
		}

		[self albumDetails];
		[self performSelector:@selector(UploadPhoto) withObject:nil afterDelay:0.1];
		[tools startLoading:self.view childView:loadingView text:@"Uploading Image. Wait…."];
		
	}
	else {
		if ([myerrorcodeOBJ.returnCode isEqualToString:@"0"])
		{
			
			[arrImage removeObjectAtIndex:noOfFail];
		}
		else {
			noOfFail++;
		}
		
		[self albumDetails];
		if ([arrImage count]==0) {
			[self.navigationController popViewControllerAnimated:YES];
		}
		else {
				UIAlertView *alertview=[[UIAlertView alloc]initWithTitle:@"Alert" message:@"Following Images can not be Uploaded at this moment please try again later" delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:nil];
				alertview.delegate=self;
				[alertview show];
				[alertview release],alertview=nil;
		}

		
		
		
	}
	
}
-(void)onFailure
{
	[tools stopLoading:loadingView];
}
-(void)ClickbtnAddPhoto
{

	[self getImage];
	
}
-(void)getImage
{
	UIActionSheet *AC = [[UIActionSheet alloc]initWithTitle:@"ADD IMAGE\n" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"BROWSE IMAGE",@"TAKE FROM CAMERA",nil];
    AC.actionSheetStyle =UIActionSheetStyleBlackTranslucent;
    AC.delegate = self;
    [AC  showInView:self.view];
    [AC release];
}

-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
	if(buttonIndex == 0)
	{
		[self PickImageForIndex];
	}
	if(buttonIndex == 1)
	{
		[self captureImage];
	}
}
-(void)captureImage
{
	if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) 
	{		
		
		UIImagePickerController *camerapicker = [[UIImagePickerController alloc] init];
		
		camerapicker.delegate = self;
		camerapicker.sourceType = UIImagePickerControllerSourceTypeCamera;
		[camerapicker parentViewController];
		[self presentModalViewController:camerapicker animated:YES];
		
	}
	else 
	{
		UIAlertView *alert1;
		alert1 = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"There is no Camera in the Device" delegate:self cancelButtonTitle:nil otherButtonTitles:@"Ok",nil];
		alert1.tag=2;
		[alert1 show];
		
	}
}

   
#pragma mark imagePicker delegate

- (void)PickImageForIndex
{
	UIImagePickerControllerSourceType imgCtrlType;
    if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary])
	{
		imgCtrlType = UIImagePickerControllerSourceTypePhotoLibrary;
	}
	else if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeSavedPhotosAlbum])
	{
		imgCtrlType = UIImagePickerControllerSourceTypeSavedPhotosAlbum;
	}
	UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init]; 
	
	imagePicker.sourceType = imgCtrlType;
	imagePicker.delegate = self;
	
	[self presentModalViewController:imagePicker animated:YES];
	
	
	[imagePicker release];
}


#pragma mark PhotoGalary Delegate Method
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
	NSLog(@"%@",[info description]);
	[[picker parentViewController] dismissModalViewControllerAnimated:YES];
	UIImage *image=[self scaleAndRotateImage:[info valueForKey:@"UIImagePickerControllerOriginalImage"]];
	[self saveImage:image];
	[self albumDetails ];
	
	NSString *imageName=[[[[[[[info valueForKey:@"UIImagePickerControllerReferenceURL"] absoluteString]componentsSeparatedByString:@"id="]objectAtIndex:1]componentsSeparatedByString:@"&"]objectAtIndex:0] stringByAppendingString:@".JPG"] ;
						  NSLog(@"%@",imageName);
	
	
}
//this delegate is not fired.
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo
{ 
	
	
	[[picker parentViewController] dismissModalViewControllerAnimated:YES];
	
	NSLog(@"%@",[editingInfo description]);
	
	image=[self scaleAndRotateImage:image];
	[self saveImage:image];
	[self albumDetails ];
	
}

-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
	
 	[[picker parentViewController] dismissModalViewControllerAnimated:YES];
} 

-(void)saveImage:(UIImage *)image{
	
	NSData *imageData;
	
	UIImage *imageToSave;	
	imageToSave = image;
	imageData=nil;
	if(imageData)
		[imageData release];
	
	imageData = UIImagePNGRepresentation(imageToSave);
	CGFloat a = [imageData length]/1024;
	NSLog(@"%f",a);
	[imageData retain];
	dataImage = [[NSData dataWithData:imageData]retain];
	
	
	if([imageData length] >(1024*1024*2))  /// == LIMITTING TO 550 KB
	{
		
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@" " message:@"Picked image is too big in Size.\n That may hang your phone during upload."
							  
													   delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];                
		[alert show];                
		[alert release];    
		return;
	}
	
	[arrImage addObject:dataImage];
	NSLog(@"arrImage%d",[arrImage count]);
	
	
}

- (UIImage*)scaleAndRotateImage:(UIImage *)image
{
	int kMaxResolution; // Or whatever
	
	kMaxResolution=600;
	
	
	
	CGImageRef imgRef = image.CGImage;
	
	CGFloat width = CGImageGetWidth(imgRef);
	CGFloat height = CGImageGetHeight(imgRef);
	
	CGAffineTransform transform = CGAffineTransformIdentity;
	CGRect bounds = CGRectMake(0, 0, width, height);
	if (width > kMaxResolution || height > kMaxResolution) {
		CGFloat ratio = width/height;
		if (ratio > 1) {
			bounds.size.width = kMaxResolution;
			bounds.size.height = bounds.size.width / ratio;
		}
		else {
			bounds.size.height = kMaxResolution;
			bounds.size.width = bounds.size.height * ratio;
		}
	}
	
	CGFloat scaleRatio = bounds.size.width / width;
	CGSize imageSize = CGSizeMake(CGImageGetWidth(imgRef), CGImageGetHeight(imgRef));
	CGFloat boundHeight;
	UIImageOrientation orient = image.imageOrientation;
	switch(orient) {
			
		case UIImageOrientationUp: //EXIF = 1
			transform = CGAffineTransformIdentity;
			break;
			
		case UIImageOrientationUpMirrored: //EXIF = 2
			transform = CGAffineTransformMakeTranslation(imageSize.width, 0.0);
			transform = CGAffineTransformScale(transform, -1.0, 1.0);
			break;
			
		case UIImageOrientationDown: //EXIF = 3
			transform = CGAffineTransformMakeTranslation(imageSize.width, imageSize.height);
			transform = CGAffineTransformRotate(transform, M_PI);
			break;
			
		case UIImageOrientationDownMirrored: //EXIF = 4
			transform = CGAffineTransformMakeTranslation(0.0, imageSize.height);
			transform = CGAffineTransformScale(transform, 1.0, -1.0);
			break;
			
		case UIImageOrientationLeftMirrored: //EXIF = 5
			boundHeight = bounds.size.height;
			bounds.size.height = bounds.size.width;
			bounds.size.width = boundHeight;
			transform = CGAffineTransformMakeTranslation(imageSize.height, imageSize.width);
			transform = CGAffineTransformScale(transform, -1.0, 1.0);
			transform = CGAffineTransformRotate(transform, 3.0 * M_PI / 2.0);
			break;
			
		case UIImageOrientationLeft: //EXIF = 6
			boundHeight = bounds.size.height;
			bounds.size.height = bounds.size.width;
			bounds.size.width = boundHeight;
			transform = CGAffineTransformMakeTranslation(0.0, imageSize.width);
			transform = CGAffineTransformRotate(transform, 3.0 * M_PI / 2.0);
			break;
			
		case UIImageOrientationRightMirrored: //EXIF = 7
			boundHeight = bounds.size.height;
			bounds.size.height = bounds.size.width;
			bounds.size.width = boundHeight;
			transform = CGAffineTransformMakeScale(-1.0, 1.0);
			transform = CGAffineTransformRotate(transform, M_PI / 2.0);
			break;
			
		case UIImageOrientationRight: //EXIF = 8
			boundHeight = bounds.size.height;
			bounds.size.height = bounds.size.width;
			bounds.size.width = boundHeight;
			transform = CGAffineTransformMakeTranslation(imageSize.height, 0.0);
			transform = CGAffineTransformRotate(transform, M_PI / 2.0);
			break;
			
		default:
			[NSException raise:NSInternalInconsistencyException format:@"Invalid image orientation"];
			
	}
	
	UIGraphicsBeginImageContext(bounds.size);
	
	CGContextRef context = UIGraphicsGetCurrentContext();
	
	if (orient == UIImageOrientationRight || orient == UIImageOrientationLeft) {
		CGContextScaleCTM(context, -scaleRatio, scaleRatio);
		CGContextTranslateCTM(context, -height, 0);
	}
	else {
		CGContextScaleCTM(context, scaleRatio, -scaleRatio);
		CGContextTranslateCTM(context, 0, -height);
	}
	
	CGContextConcatCTM(context, transform);
	
	CGContextDrawImage(UIGraphicsGetCurrentContext(), CGRectMake(0, 0, width, height), imgRef);
	UIImage *imageCopy = UIGraphicsGetImageFromCurrentImageContext();
	UIGraphicsEndImageContext();
	
	//[self setRotatedImage:imageCopy];
	return imageCopy;
}
-(void)albumDetails
{
	
	scroll=[[MyScrollView alloc]initWithFrame:CGRectMake(0,60,320,200)];
	scroll.delegate=self;
	[scroll setContentSize:CGSizeMake(0,205*5)];
	[scroll setPagingEnabled:YES];
	[scroll setContentOffset:CGPointMake(0,0)];
	scroll.directionalLockEnabled=YES;
	scroll.backgroundColor=[UIColor colorWithRed:con.bgRed/255.0f green:con.bgGreen/255.0f blue:con.bgBlue/255.0f alpha:1.0];//[UIColor whiteColor];
	scroll.showsVerticalScrollIndicator = YES;
	[self.view addSubview:scroll];
	
	
	NSInteger cnt=[arrImage count];
	if(cnt%4==0)
	{
		scroll.contentSize =CGSizeMake(320,(cnt/4)*78);
	}
	else
	{
		scroll.contentSize =CGSizeMake(320,(cnt/4)*78+180);
	}
	
	[self createPage];
}

-(void)createPage
{
	
	NSInteger j=1;
	
	for(int i=0;i<[arrImage count];i++)
	{
		NSInteger x=(i%4)*70;
		NSInteger y=20+(i/4)*70;
		NSInteger q=i/4;
		if(j>4)
		{
			j=1;
		}
		
	
		UIImageView *imgvProfile=imgvProfile=[[UIImageView alloc]initWithFrame:CGRectMake(j*8+x,q*8+y,70,70)];
		imgvProfile.image=	[UIImage imageWithData:[NSData dataWithData:[arrImage objectAtIndex:i]]];
		imgvProfile.userInteractionEnabled = YES;
		imgvProfile.tag=i;
		
		//CALayer * imgLayer = [imgvProfile layer];
		//[imgLayer setMasksToBounds:YES];
		//[imgLayer setCornerRadius:10.0];
		[scroll addSubview:imgvProfile];
		[imgvProfile release];
		
		[scroll scrollRectToVisible:CGRectMake(j*8+x,q*8+y,70,70) animated:YES];
		
		j++;
		
		UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(imageTapped:)];
		[imgvProfile addGestureRecognizer:tap];
		[tap release];
	} 
}
-(void)imageTapped:(id)sender {
	
	
	UIImageView *aImageView = (UIImageView *)((UITapGestureRecognizer *)sender).view;
	
	
	Tag=aImageView.tag;
	
	SelectedImageBig *obj=[[SelectedImageBig alloc]initWithImgView:aImageView target:self action:@selector(Clickdelete)];

    [self.navigationController pushViewController:obj animated:YES];
	[obj release],obj=nil;
}
	
-(void)Clickdelete
{
	
	[arrImage removeObjectAtIndex:Tag];
	[scroll removeFromSuperview];
		
	
    [self albumDetails];
	
}
+(NSMutableArray *)getImageDataArr
{
	
	return arrImage1;
}
/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
