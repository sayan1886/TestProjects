//
//  claimActivityOBJ.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 09/11/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface claimActivityOBJ : NSObject {

	NSString *claimID;
	NSString *trxnID;
	NSString *serviceDate;
	NSString *accountType;
	NSString *claimType;
	NSString *claimCategory;
	NSString *amount;
	NSString *status;
	NSString *provider;
	NSString *paymentStatus;
	NSString *checkNo;
	NSString *paymentAmount;
	NSString *paymentMethod;
	NSString *paymentDate;
	NSString *isPreTax;
	NSString *claimSubType;
	NSString *submitDate;
	NSString *passthruClaimDate;
	
	
	NSString *LBLclaimID;
	NSString *LBLtrxnID;
	NSString *LBLserviceDate;
	NSString *LBLaccountType;
	NSString *LBLclaimType;
	NSString *LBLclaimCategory;
	NSString *LBLamount;
	NSString *LBLstatus;
	NSString *LBLprovider;
	NSString *LBLpaymentStatus;
	NSString *LBLcheckNo;
	NSString *LBLpaymentAmount;
	NSString *LBLpaymentMethod;
	NSString *LBLpaymentDate;
	NSString *LBLisPreTax;
	NSString *LBLclaimSubType;
	NSString *LBLsubmitDate;
	NSString *LBLpassthruClaimDate;
	
	NSMutableArray *arrdenialReason;
	
}
@property(nonatomic,retain)NSString *claimID;
@property(nonatomic,retain)NSString *trxnID;
@property(nonatomic,retain)NSString *serviceDate;
@property(nonatomic,retain)NSString *accountType;
@property(nonatomic,retain)NSString *claimType;
@property(nonatomic,retain)NSString *claimCategory;
@property(nonatomic,retain)NSString *amount;
@property(nonatomic,retain)NSString *status;
@property(nonatomic,retain)NSString *provider;
@property(nonatomic,retain)NSString *paymentStatus;
@property(nonatomic,retain)NSString *checkNo;
@property(nonatomic,retain)NSString *paymentAmount;
@property(nonatomic,retain)NSString *paymentMethod;
@property(nonatomic,retain)NSString *paymentDate;
@property(nonatomic,retain)NSString *isPreTax;
@property(nonatomic,retain)NSString *claimSubType;
@property(nonatomic,retain)NSString *submitDate;
@property(nonatomic,retain)NSString *passthruClaimDate;

@property(nonatomic,retain)NSString *LBLclaimID;
@property(nonatomic,retain)NSString *LBLtrxnID;
@property(nonatomic,retain)NSString *LBLserviceDate;
@property(nonatomic,retain)NSString *LBLaccountType;
@property(nonatomic,retain)NSString *LBLclaimType;
@property(nonatomic,retain)NSString *LBLclaimCategory;
@property(nonatomic,retain)NSString *LBLamount;
@property(nonatomic,retain)NSString *LBLstatus;
@property(nonatomic,retain)NSString *LBLprovider;
@property(nonatomic,retain)NSString *LBLpaymentStatus;
@property(nonatomic,retain)NSString *LBLcheckNo;
@property(nonatomic,retain)NSString *LBLpaymentAmount;
@property(nonatomic,retain)NSString *LBLpaymentMethod;
@property(nonatomic,retain)NSString *LBLpaymentDate;
@property(nonatomic,retain)NSString *LBLisPreTax;
@property(nonatomic,retain)NSString *LBLclaimSubType;
@property(nonatomic,retain)NSString *LBLsubmitDate;
@property(nonatomic,retain)NSString *LBLpassthruClaimDate;
@property(nonatomic,retain)NSMutableArray *arrdenialReason;
@end
