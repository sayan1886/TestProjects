//
//  ticketTypePerser.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 08/11/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "ticketTypeOBJ.h"
@interface ticketTypePerser : NSObject<NSXMLParserDelegate> {

	ticketTypeOBJ *ticketType;
	NSMutableString *contentOfString;
	

}
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error;
+(NSMutableArray *)tickettypeArr;
@end
