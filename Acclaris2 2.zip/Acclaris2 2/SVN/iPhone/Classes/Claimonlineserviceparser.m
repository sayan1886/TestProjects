//
//  Claimonlineserviceparser.m
//  Acclaris
//
//  Created by Subhojit on 31/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Claimonlineserviceparser.h"
NSMutableArray *arrClaimonlinesave;
NSMutableArray *arrMultipleAccdata;


@implementation Claimonlineserviceparser
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error
{
	
	
	NSXMLParser *parser;
	parser = [[NSXMLParser alloc] initWithData:data];
    [parser setDelegate:self];
	[parser setShouldProcessNamespaces:NO];
    [parser setShouldReportNamespacePrefixes:NO];
    [parser setShouldResolveExternalEntities:NO];
    [parser parse];
    NSError *parseError = [parser parserError];
    if (parseError && error) 
	{
        *error = parseError;
    }
	[parser release];
}

-(void)parserDidStartDocument:(NSXMLParser *)parser
{
	
	arrClaimonlinesave = [[NSMutableArray alloc]init];
	arrMultipleAccdata=[[NSMutableArray alloc]init];
}		

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
	if (qName)
	{
		elementName = qName;
	}
	
	else 
		if([elementName isEqualToString:@"SaveClaimDetails"])
		{
			
			objclaimonlinesave=[[ClaimonlineSaveOBJ alloc]init];
			
			return;
			
			
		}
		else 
			if([elementName isEqualToString:@"returnCode"])
			{
				
				contentOfString=[NSMutableString string];
				[contentOfString retain];
				return;	
				
				
			}
		else 
			if([elementName isEqualToString:@"errorText"])
			{
				
				contentOfString=[NSMutableString string];
				[contentOfString retain];
				return;	
				
				
			}
	else 
		if([elementName isEqualToString:@"claimCategory"])
		{
			contentOfString=[NSMutableString string];
			[contentOfString retain];
			return;		
			
		}
		else 
			if([elementName isEqualToString:@"claimType"])
			{
				contentOfString=[NSMutableString string];
				[contentOfString retain];
				return;		
				
			}
			else 
				if([elementName isEqualToString:@"amount"])
				{
					contentOfString=[NSMutableString string];
					[contentOfString retain];
					return;		
					
				}
				else 
					if([elementName isEqualToString:@"serviceBeginDt"])
					{
						contentOfString=[NSMutableString string];
						[contentOfString retain];
						return;		
						
					}
					else 
						if([elementName isEqualToString:@"serviceEndDt"])
						{
							contentOfString=[NSMutableString string];
							[contentOfString retain];
							return;		
							
						}
						else 
							if([elementName isEqualToString:@"note"])
							{
								contentOfString=[NSMutableString string];
								[contentOfString retain];
								return;		
								
							}
	
							else 
								if([elementName isEqualToString:@"isPriorYear"])
								{
									contentOfString=[NSMutableString string];
									[contentOfString retain];
									return;		
									
								}
								else 
									if([elementName isEqualToString:@"payMode"])
									{
										contentOfString=[NSMutableString string];
										[contentOfString retain];
										return;		
										
									}
									else 
										if([elementName isEqualToString:@"multipleAcct"])
										{
											contentOfString=[NSMutableString string];
											[contentOfString retain];
											return;		
											
										}
	
										else 
											if([elementName isEqualToString:@"account"])
											{
													
												objmultipleAcc=[[MultipleAccountOBJ alloc]init];
											}
											else 
												if([elementName isEqualToString:@"accountTypeCD"])
												{
													contentOfString=[NSMutableString string];
													[contentOfString retain];
													return;		
													
												}
												else 
													if([elementName isEqualToString:@"accountTypeDesc"])
													{
														contentOfString=[NSMutableString string];
														[contentOfString retain];
														return;		
														
													}
													else 
														if([elementName isEqualToString:@"elctID"])
														{
															contentOfString=[NSMutableString string];
															[contentOfString retain];
															return;		
															
														}
														else 
															if([elementName isEqualToString:@"accountNO"])
															{
																contentOfString=[NSMutableString string];
																[contentOfString retain];
																return;		
																
															}
															else 
																if([elementName isEqualToString:@"purseType"])
																{
																	contentOfString=[NSMutableString string];
																	[contentOfString retain];
																	return;		
																	
																}
																else 
																	if([elementName isEqualToString:@"labelAssociatedValue"])
																	{
																		contentOfString=[NSMutableString string];
																		[contentOfString retain];
																		return;		
																		
																	}
																	
}
	- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName     
	{	
		if (qName)
		{
			elementName = qName;
			
		}
		
		else 
			if([elementName isEqualToString:@"SaveClaimDetails"])
			{
				if(objclaimonlinesave)
				{
					
					[arrClaimonlinesave addObject:objclaimonlinesave];
					[objclaimonlinesave release],objclaimonlinesave=nil;
					
				}	
				
			}
			else 
				if([elementName isEqualToString:@"returnCode"])
				{
					if(contentOfString)
					{
						
						objclaimonlinesave.strreturnCode=contentOfString;
						[contentOfString release];
						contentOfString = nil;
						
						
					}		
					
				}
		
			else 
				if([elementName isEqualToString:@"errorText"])
				{
					if(contentOfString)
					{
						
						objclaimonlinesave.strerrorText=contentOfString;
						[contentOfString release];
						contentOfString = nil;
						
						
					}		
					
				}
		
		
			else 
				if([elementName isEqualToString:@"claimCategory"])
				{
					if(contentOfString)
					{
						
						objclaimonlinesave.strclaimCategory=contentOfString;
						[contentOfString release];
						contentOfString = nil;
						
						
					}		
					
				}
				else 
					if([elementName isEqualToString:@"claimType"])
					{
						if(contentOfString)
						{
							objclaimonlinesave.strclaimType=contentOfString;							
							[contentOfString release];
							contentOfString = nil;
							
							
						}		
						
					}
					else 
						if([elementName isEqualToString:@"amount"])
						{
							if(contentOfString)
							{
								objclaimonlinesave.strclaimType=contentOfString;							
								[contentOfString release];
								contentOfString = nil;
								
								
							}		
							
						}
						else 
							if([elementName isEqualToString:@"serviceBeginDt"])
							{
								if(contentOfString)
								{
									objclaimonlinesave.strserviceBeginDt=contentOfString;							
									[contentOfString release];
									contentOfString = nil;
									
									
								}		
								
							}
							else 
								if([elementName isEqualToString:@"serviceEndDt"])
								{
									if(contentOfString)
									{
										objclaimonlinesave.strserviceEndDt=contentOfString;							
										[contentOfString release];
										contentOfString = nil;
										
										
									}		
									
								}
								else 
									if([elementName isEqualToString:@"note"])
									{
										if(contentOfString)
										{
											objclaimonlinesave.strnote=contentOfString;							
											[contentOfString release];
											contentOfString = nil;
											
											
										}		
										
									}
									else 
										if([elementName isEqualToString:@"isPriorYear"])
										{
											if(contentOfString)
											{
												objclaimonlinesave.strisPriorYear=contentOfString;							
												[contentOfString release];
												contentOfString = nil;
												
												
											}		
											
										}
										else 
											if([elementName isEqualToString:@"payMode"])
											{
												if(contentOfString)
												{
													objclaimonlinesave.strpayMode=contentOfString;							
													[contentOfString release];
													contentOfString = nil;
													
													
												}		
												
											}
											else 
												if([elementName isEqualToString:@"multipleAcct"])
												{
													if(contentOfString)
													{
														objclaimonlinesave.strmultipleAcct=contentOfString;							
														[contentOfString release];
														contentOfString = nil;
														
														
													}		
													
												}
		
												else 
													if([elementName isEqualToString:@"account"])
													{
													
														
														if(objmultipleAcc)
														{
															
															[arrMultipleAccdata addObject:objmultipleAcc];
															[objmultipleAcc release],objmultipleAcc=nil;
														}
											
															
													}
													else 
														if([elementName isEqualToString:@"accountTypeCD"])
														{
															if(contentOfString)
															{
																
																objmultipleAcc.straccountTypeCD=contentOfString;							
																[contentOfString release];
																contentOfString = nil;
																
																
															}
															
														}
														else 
															if([elementName isEqualToString:@"accountTypeDesc"])
															{
																if(contentOfString)
																{
																	
																	objmultipleAcc.straccountTypeDesc=contentOfString;							
																	[contentOfString release];
																	contentOfString = nil;
																	
																	
																}
															}
															else 
																if([elementName isEqualToString:@"elctID"])
																{
																	if(contentOfString)
																	{
																		
																		objmultipleAcc.strelctID=contentOfString;							
																		[contentOfString release];
																		contentOfString = nil;
																		
																		
																	}		
																	
																}
																else 
																	if([elementName isEqualToString:@"accountNO"])
																	{
																		if(contentOfString)
																		{
																			
																			objmultipleAcc.straccountNO=contentOfString;							
																			[contentOfString release];
																			contentOfString = nil;
																			
																			
																		}	
																		
																	}
																	else 
																		if([elementName isEqualToString:@"purseType"])
																		{
																			if(contentOfString)
																			{
																				
																				objmultipleAcc.strpurseType=contentOfString;							
																				[contentOfString release];
																				contentOfString = nil;
																				
																				
																			}	
																			
																		}
																		else 
																			if([elementName isEqualToString:@"labelAssociatedValue"])
																			{
																				if(contentOfString)
																				{
																					
																					objmultipleAcc.strlabelAssociatedValue=contentOfString;							
																					[contentOfString release];
																					contentOfString = nil;
																					
																					
																				}
																			}
		
		
	}
- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
			if(contentOfString)
				[contentOfString appendString:string];
}
		
- (void)parserDidEndDocument:(NSXMLParser *)parse
		
{
	objclaimonlinesave=(ClaimonlineSaveOBJ *)[arrClaimonlinesave objectAtIndex:0];
	
	NSLog(@"returncode:%@",objclaimonlinesave.strreturnCode);		
	NSLog(@"arrClaimonlinesave%@",arrClaimonlinesave);
	NSLog(@" arrMultipleAccdata %d",[arrMultipleAccdata count]);
}	
+(NSMutableArray *)getarrClaimonlinesave
{
	
	return arrClaimonlinesave;
	
	
}

+(NSMutableArray *)getarrMultipleAccdata
{
	
	return arrMultipleAccdata;
}
@end
