    //
//  ticketNew.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 08/11/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import "ticketNew.h"
#import <QuartzCore/CALayer.h>
#import "request.h"
#import "ticket.h"
#import "ticketTypePerser.h"
#import "passPerser.h"
#import "UserresponcePerser.h"
#import "Decode64.h"
#import "AcclarisViewController.h"
#import "configurables.h"
@implementation ticketNew

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	

	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	
	
	NSMutableArray *arr_myconfig=[AcclarisViewController staticarr_config];//[configurableParser getconfig_arr];//
	con=(configurables *)[arr_myconfig objectAtIndex:0];
	self.view.backgroundColor = [UIColor colorWithRed:con.bgRed/255.0f green:con.bgGreen/255.0f blue:con.bgBlue/255.0f alpha:1.0];
	tools=[[MyTools alloc]init];
	loadingView=[tools createActivityIndicator1];

	
	NSMutableArray *my_arrUserinfo=[UserresponcePerser userdesc];
	UIImageView *logo_img = [[UIImageView alloc]initWithFrame:CGRectMake(0, 2, 170, 40)];
	NSData *data=[Base64 decode:con.logoImgdata];
	logo_img.image=	[UIImage imageWithData:[NSData dataWithData:data]];
	self.navigationItem.titleView=logo_img;
	
	tools=[[MyTools alloc]init];
	loadingView=[tools createActivityIndicator1];
	
	/////////////////////////////////////
	
	UIView	*view_messageType = [[UIView alloc]initWithFrame:CGRectMake(107, 10, 300-107+10, 30)];
	view_messageType.backgroundColor = [UIColor whiteColor];
	view_messageType.layer.cornerRadius=4;
	view_messageType.layer.borderWidth=1.5;
	CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();	
	float grayComponents[4] = { 0.3, 0.3, 0.3, 1.0 };
	view_messageType.layer.borderColor=CGColorCreate(colorSpace, grayComponents);
	[self.view addSubview:view_messageType];
	
	
	UILabel	*lbl_messageType_text = [[UILabel alloc]initWithFrame:CGRectMake(15, 15, 100, 20)];
	lbl_messageType_text.backgroundColor = [UIColor clearColor];
	lbl_messageType_text.text = @"Type";
	lbl_messageType_text.baselineAdjustment=UIBaselineAdjustmentNone;
	lbl_messageType_text.font=[UIFont fontWithName:con.fontname size:con.fontsize];
	lbl_messageType_text.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
	[self.view addSubview:lbl_messageType_text];
	
	txt_messageType_text = [[UITextField alloc]initWithFrame:CGRectMake(10, 7, 180, 20)];
	txt_messageType_text.backgroundColor = [UIColor clearColor];
	//txt_messageType_text.baselineAdjustment=UIBaselineAdjustmentAlignCenters;
	txt_messageType_text.text = @"";
	txt_messageType_text.font=[UIFont fontWithName:con.fontname size:con.fontsize];
	txt_messageType_text.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
	txt_messageType_text.delegate=self;
	[view_messageType addSubview:txt_messageType_text];
	
	/////////////////////////////////
	
	
	
	UIView	*view_messageDesc = [[UIView alloc]initWithFrame:CGRectMake(10, 45, 300, 30)];
	/*view_messageDesc.backgroundColor = [UIColor whiteColor];
	view_messageDesc.layer.cornerRadius=4;
	view_messageDesc.layer.borderWidth=1.5;
	
	view_messageDesc.layer.borderColor=CGColorCreate(colorSpace, grayComponents);*/
	[self.view addSubview:view_messageDesc];
	UILabel	*lbl_messageDesc_text = [[UILabel alloc]initWithFrame:CGRectMake(5, 5, 180, 20)];
	lbl_messageDesc_text.backgroundColor = [UIColor clearColor];
	lbl_messageDesc_text.text = @"Enter Description";
	lbl_messageDesc_text.font=[UIFont fontWithName:con.fontname size:con.fontsize];
	lbl_messageDesc_text.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
	[view_messageDesc addSubview:lbl_messageDesc_text];
	
	//////////////////////////////////
	
	
	UIView	*view_newmessage_textview = [[UIView alloc]initWithFrame:CGRectMake(10, 80, 300, 200)];
	view_newmessage_textview.backgroundColor = [UIColor whiteColor];
	view_newmessage_textview.layer.cornerRadius=4;
	view_newmessage_textview.layer.borderWidth=1.5;
	view_newmessage_textview.layer.borderColor=CGColorCreate(colorSpace, grayComponents);
	[self.view addSubview:view_newmessage_textview];
	
	
	txtv_msgNewNotes=[[UITextView alloc] initWithFrame:CGRectMake(5, 5, 290, 200)];
   	txtv_msgNewNotes.font = [UIFont fontWithName:con.fontname size:con.fontsize];
	txtv_msgNewNotes.returnKeyType = UIReturnKeyDefault;
	txtv_msgNewNotes.autocorrectionType=NO;
	txtv_msgNewNotes.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
	txtv_msgNewNotes.keyboardType = UIKeyboardTypeDefault;
	txtv_msgNewNotes.backgroundColor=[UIColor clearColor];
	txtv_msgNewNotes.keyboardAppearance=UIKeyboardAppearanceAlert;
	txtv_msgNewNotes.delegate=self;
	[view_newmessage_textview addSubview:txtv_msgNewNotes];
	
	///////////////////////////////////
	
	UIButton *btn_submitnewMSG=[UIButton buttonWithType:UIButtonTypeCustom];
	btn_submitnewMSG.frame = CGRectMake(43, 308, 234, 47);
	NSData *data_btnimg=[Base64 decode:con.btnImgdata];
	[btn_submitnewMSG setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
	btn_submitnewMSG.titleLabel.font = [UIFont fontWithName:con.btnfontname size:con.btnfontsize];
	[btn_submitnewMSG setTitle:@"Submit" forState:UIControlStateNormal];
	[btn_submitnewMSG setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn_submitnewMSG addTarget:self action:@selector(ticketRequest) forControlEvents:UIControlEventTouchUpInside];
	[self.view addSubview:btn_submitnewMSG];
	
	
	UIButton *addContactButton = [[UIButton buttonWithType:UIButtonTypeDetailDisclosure]retain];
    addContactButton.frame=CGRectMake(115+160, 5+7, 25, 25);
    addContactButton.backgroundColor = [UIColor clearColor];
    [addContactButton addTarget:self action:@selector(populateRadiusPicker) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:addContactButton];
	
	[self ticketTypeRequest];
	
	viewself=[[UIView alloc]initWithFrame:CGRectMake(0, 460, 320, 240)];
	
	
	
	[self signoutbt];
	[self donebt];
}

-(void)signoutbt
{
	signoutButton = [[UIBarButtonItem alloc]
					 initWithTitle:@"Sign Off"
					 style:UIBarButtonItemStyleBordered
					 target:self
					 action:@selector(signout)];
    self.navigationItem.rightBarButtonItem =signoutButton;
}
-(void)donebt
{
	doneButton = [[UIBarButtonItem alloc]
				  initWithTitle:@"Done"
				  style:UIBarButtonItemStyleBordered
				  target:self
				  action:@selector(done)];
}


-(void)ticketTypeRequest
{
	//[tools startLoading:self.view childView:loadingView text:@"Fetching ticket type list..."];
	[tools startLoading:self.view childView:loadingView text:@"Loading your Messages types. \nWait…"];
	request *r=[[request alloc] initWithTarget:self
								 SuccessAction:@selector(onSucceffulLogin)
								 FailureAction:@selector(onFailureLogin)];
	[r newticketTypeRequest];
	[r release];
	
	
}
-(void)ticketRequest
{
	
	if ([txt_messageType_text.text isEqualToString:@""])
	{
		
		NSDictionary *customMessageList_dict=[[NSUserDefaults standardUserDefaults] objectForKey:@"customMessageList"];
		
		
		NSString *strmessage=[[customMessageList_dict valueForKey:@"200040"]valueForKey:@"message"];
		NSString *strtype=[[customMessageList_dict valueForKey:@"200040"]valueForKey:@"type"];
		
		
		UIAlertView *alert= [[UIAlertView alloc] initWithTitle:strtype message:strmessage
													  delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		[alert show];    
		[alert release];
		return;
	}
	if ([txtv_msgNewNotes.text isEqualToString:@""])
	{		
		
		NSDictionary *customMessageList_dict=[[NSUserDefaults standardUserDefaults] objectForKey:@"customMessageList"];

		NSString *strmessage=[[customMessageList_dict valueForKey:@"200075"]valueForKey:@"message"];
		NSString *strtype=[[customMessageList_dict valueForKey:@"200075"]valueForKey:@"type"];
		UIAlertView *alert= [[UIAlertView alloc] initWithTitle:strtype message:strmessage
													  delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		[alert show];    
		[alert release];
		return;
	}
	[tools startLoading:self.view childView:loadingView text:@"Creating new ticket ..."];
	request *r=[[request alloc] initWithTarget:self
								 SuccessAction:@selector(onSucceffulsubmission)
								 FailureAction:@selector(onFailuresubmission)];
	[r newticketRequest:txt_messageType_text.text description:txtv_msgNewNotes.text];
	[r release];
	
	
	
}



-(void)onSucceffulLogin
{
	tktType=[ticketTypePerser tickettypeArr];
	[tools stopLoading:loadingView];
}
-(void)onFailureLogin
{
	[tools stopLoading:loadingView];	
	
}
-(void)onSucceffulsubmission
{
	[tools stopLoading:loadingView];
	/*UIAlertView *alert= [[UIAlertView alloc] initWithTitle:@"Info" message:@"New Message created successfully"
												  delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
	[alert show];    
	[alert release];*/
	
	[self reqTicket];
	
	
	

	
}
-(void)onFailuresubmission
{
	[tools stopLoading:loadingView];
}
-(void)reqTicket
{
	
	[tools startLoading:self.view childView:loadingView text:@"Updating your Message List. Wait…."];
	NSMutableArray *userinfo_arr=[passPerser passresponce];//static method fired
	request *r=[[request alloc] initWithTarget:self
								 SuccessAction:@selector(onSucceffulreq)
								 FailureAction:@selector(onFailurereq)];
	[r sendticketRequest:@"0" participentid:[userinfo_arr objectAtIndex:2] userid:[userinfo_arr objectAtIndex:4]];
	[r release];

	
}
-(void)onSucceffulreq
{
	[tools stopLoading:loadingView];
	[self.navigationController popViewControllerAnimated:YES];
}
-(void)onFailurereq
{
	[tools stopLoading:loadingView];
}


-(void)signout
{
	[((AcclarisAppDelegate *)[[UIApplication sharedApplication] delegate]) removeTabBar];
}
-(void)done
{
	[txtv_msgNewNotes resignFirstResponder];
	self.navigationItem.rightBarButtonItem =signoutButton;
}
#pragma mark textview delegate
- (BOOL)textViewShouldBeginEditing:(UITextView *)textView;
{
	self.navigationItem.rightBarButtonItem =doneButton;
	return YES;
}

#pragma mark -
#pragma mark textfield deligate
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
	[self populateRadiusPicker];
	return NO;
}

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField
{
	return YES;
}
-(BOOL)textFieldShouldReturn:(UITextField *)theTextField 
{
	return YES;
}
#pragma mark -
#pragma mark Picker
-(void)populateRadiusPicker
{
		
	NSArray *arrayOfViews=[viewself subviews];
	
	if([arrayOfViews count]>0)
		
	{
		
		for(int i=0;i<[arrayOfViews count];i++)
			
		{
			
			[[arrayOfViews objectAtIndex:i] removeFromSuperview];
			
		}
		
	} 
	
	
	viewself.backgroundColor=[UIColor colorWithRed:160.0/255 green:161.0/255.0 blue:166.0/255.0 alpha:1.0 ];
	
	[self.view addSubview:viewself]; 
	
	
	UIPickerView *radiusPickerView= [[UIPickerView alloc] initWithFrame:CGRectZero];
	
	radiusPickerView.autoresizingMask = UIViewAutoresizingFlexibleWidth;
	
	CGSize pickerSize = [radiusPickerView sizeThatFits:CGSizeZero];
	
	radiusPickerView.frame = CGRectMake(0.0,30.0, pickerSize.width,180);
	
	radiusPickerView.delegate = self;
	
	radiusPickerView.showsSelectionIndicator = YES;
	
	[viewself addSubview:radiusPickerView];
	
	[radiusPickerView release],nil; 
	
	
	UIButton *btnCancel=[UIButton buttonWithType:UIButtonTypeCustom];
	
	//[btnCancel setBackgroundImage:[UIImage imageNamed:@"done_active.png"] forState:UIControlStateNormal];
	
	[btnCancel setTitle:@"DONE" forState:UIControlStateNormal];
	
	btnCancel.frame=CGRectMake(242,4,70,25);
	
	[btnCancel setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	
	btnCancel.backgroundColor=[UIColor clearColor];
	
	btnCancel.showsTouchWhenHighlighted=NO;
	
	[btnCancel addTarget:self action:@selector(dismisPopulateActionSheet:) forControlEvents:UIControlEventTouchUpInside];
	
	[viewself addSubview:btnCancel];
	
	
	
	[UIView beginAnimations:nil context:nil];
	
	[UIView setAnimationDuration:0.3];
	
	viewself.frame=CGRectMake(0, 220, 320, 240);
	
	[UIView commitAnimations]; 
	
	
		
}
-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
	txt_messageType_text.text = ((ticketTypeOBJ *)[ tktType objectAtIndex:row]).label;
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
	return ((ticketTypeOBJ *)[tktType objectAtIndex:row]).label;
}
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
	return 1;
}
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
	return [tktType count];
}
- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component
{
	CGFloat componentWidth;
	componentWidth = 270.0;	// first column size is wider to hold names
	return componentWidth;
}
-(void)dismisPopulateActionSheet:(id)sender

{
	
		
	viewself.frame=CGRectMake(0, 220, 320, 240);
	
	[UIView beginAnimations:nil context:nil];
	
	[UIView setAnimationDuration:0.3];
	
	viewself.frame=CGRectMake(0, 460, 320, 240);
	
	[UIView commitAnimations];
	
	[self performSelector:@selector(removeSuperView) withObject:nil afterDelay:0.3]; 
	
	
} 

-(void)removeSuperView

{
	
	NSArray *arrayOfViews=[viewself subviews];
	
	if([arrayOfViews count]>0)
		
	{
		
		for(int i=0;i<[arrayOfViews count];i++)
			
		{
			
			[[arrayOfViews objectAtIndex:i] removeFromSuperview];
			
			//[[arrayOfViews objectAtIndex:i] release];
			
		}
		
	}
	
} 
#pragma mark -

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
