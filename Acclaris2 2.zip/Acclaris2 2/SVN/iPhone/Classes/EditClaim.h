//
//  EditClaim.h
//  Acclaris
//
//  Created by Subhojit on 07/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyTools.h"
#import "Decode64.h"
#import "ClaimSubmitNewOBJ.h"
#import "ClaimSubmitNewParser.h"
#import "ClaimSubOBJ.h"
#import "RequestPhase2.h"
#import "passPerser.h"
#import "AcclarisAppDelegate.h"
#import "UnsubmittedclaimOBJ.h"
#import "UnsubmittedClaimParser.h"
#import "SubmitNewClaimone.h"
#import "MultipleAccountView.h"
#import "ClaimonlineSaveOBJ.h"
#import "Claimonlineserviceparser.h"




@class configurables;
@interface EditClaim : UIViewController<UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate,UIPickerViewDelegate,UIPickerViewDataSource,UITextViewDelegate,didSelectInterested> {
	
	AcclarisAppDelegate *app;
	configurables *con;
	MyTools *tools;
	UITextField *txttype;
	UITextField *txtAmount;
	UITextField *txtProvider;
	UITextField *txtserviceFrom;
	UITextField *txtserviceTo;
	UITextField *txtPriorYear;
	UITextView *txtViewNote;
	
	UITableView *table;
	NSArray *placeholders;
	UIButton *btnRadio;
	UIButton *btnRadio1;
	
	//NSArray *pickerViewArray;
	UIPickerView *myPickerView;
	NSMutableArray *arrAllSection;
	UIDatePicker    *datePicker;
	
	NSString *strTxtNm;
	NSMutableArray *pickerViewArray;
	ClaimSubOBJ*  objClaimsub;;
	ClaimSubmitNewOBJ*  objClaimsubmit;
	NSMutableArray *arrDecide;
	NSString *strFont;
	NSMutableArray *arrsubmitcatagory;
	NSString *strPriorCheck;
	NSString *strPaystatus;
	NSMutableDictionary *DictSavedSubmitclaimInfo;
	NSString *icheckbox;
	UIView *loadingView;
	
	NSMutableDictionary *dictget;
	NSString *strselectclaimcatagory;
	
	int Selectedrow;
	NSMutableArray *arrunsubmittedClaimwork;
	
	//SubmitNewClaimone *objone;
	NSMutableArray *arrsubcatagory;
	NSString *strisprior;
	
	id actionTarget;
	SEL actionHandler;
	 NSMutableArray *arrclaimsave;
	NSMutableArray *userinfo_arr;
	NSString *strAccValue;
    NSString *strallowDuplicateClaim;

     id type;
	NSString *strFront;
	NSString *stropcodevalue;
	BOOL isfirstmultiple;
	NSDictionary *customMessageList_dict;


}
-(void)ClaimSave;
-(void)ClaimSave2;
-(void)createbarbuttondone;
-(void)donecancel;
-(void)signout;
-(void)constructTableCell;
-(void)PaytypeInput:(UITableViewCell *)cell;
-(void)HeadertypeInput:(UITableViewCell *)cell;

-(void)TypeInput:(UITableViewCell *)cell;
-(void)AmountInput:(UITableViewCell *)cell;
-(void)ProviderInput:(UITableViewCell *)cell;
-(void)ServiceFromInput:(UITableViewCell *)cell;
-(void)ServiceToInput:(UITableViewCell *)cell;
-(void)PriorInput:(UITableViewCell *)cell;
-(void)NoteInput:(UITableViewCell *)cell;
-(void)CreateView;
-(void)ClickbtnRadio:(id)sender;
-(void)ClickbtnRadio1:(id)sender;
-(id)initWitharr:(NSMutableArray *)arr str:(NSString *)s catagory:(NSMutableDictionary *)dict;
-(void)Vanishpicker;
-(void)constructTableCellnew;
-(void)Save;
-(void)createbar_button;
-(id)initWithrow:(int)row target:(id)target action:(SEL)action;
+(BOOL)getback;


@end
