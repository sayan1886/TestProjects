//
//  ImageShow.h
//  Acclaris
//
//  Created by Subhojit on 19/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RequestPhase2_2.h"
#import "passPerser.h"
#import "ReceiptShowOBJ.h"
#import "ReceiptShowParser.h"
#import "MyTools.h"
#import "AcclarisAppDelegate.h"
#import "Decode64.h"
#import "ReceiptShowOBJ.h"
#import "ReceiptShowParser.h"
@class configurables;
@interface ImageShow : UIViewController {

	NSString *strFileid;
	AcclarisAppDelegate *app;
	configurables *con;
	MyTools *tools;
	UIView *loadingView;
	
}
-(void)LoadImage;
@end
