//
//  showMessage.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 29/04/11.
//  Copyright 2011 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@class configurables;
@class MyTools;
@interface showMessage : UIViewController {
	configurables *con;
	MyTools *tools;
	NSString *message;
}
-(void)createView;
@end
