//
//  CountryOBJ.m
//  Acclaris
//
//  Created by Subhojit on 26/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "CountryOBJ.h"


@implementation CountryOBJ
@synthesize strcountry,strvalue1,strvalue2,strvalue3,strreturnCode,strerrorText;

@end
