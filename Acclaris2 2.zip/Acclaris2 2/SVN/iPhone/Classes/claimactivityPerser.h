//
//  claimactivityPerser.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 09/11/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
@class claimActivityOBJ;
@class denialReasonOBJ;
@class errorcodeOBJ;
@interface claimactivityPerser : NSObject <NSXMLParserDelegate>{

	claimActivityOBJ *myclaimActivity;
	NSMutableArray *arrItem;
	NSMutableString *contentOfString;
	denialReasonOBJ *mydenialOBJ;
	errorcodeOBJ *myerrorcodeOBJ;
	
}
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error;
+(NSMutableArray *)claimactivityArr;
+(NSMutableArray *)geterror_arr;
+(BOOL)gethasMoreRecords_claim;
@end
