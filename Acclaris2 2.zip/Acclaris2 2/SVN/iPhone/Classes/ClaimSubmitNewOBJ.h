//
//  ClaimSubmitNewOBJ.h
//  Acclaris
//
//  Created by Subhojit on 25/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface ClaimSubmitNewOBJ : NSObject {

	
	NSString *strcategoryListCount;
	NSString *strname;
	NSString *strlabel;
	NSString *strDisplayseq;
	NSString *strpriorYearActivePlan;
	NSMutableArray *arrclaimsubtype;
	NSString *strpendingClaimExists;
	NSString *strPayMode;
}
@property(nonatomic,retain)NSString *strcategoryListCount;
@property(nonatomic,retain)NSString *strname;
@property(nonatomic,retain)NSString *strlabel;
@property(nonatomic,retain)NSString *strDisplayseq;
@property(nonatomic,retain)NSString *strpriorYearActivePlan;
@property(nonatomic,retain)NSMutableArray *arrclaimsubtype;
@property(nonatomic,retain)NSString *strPayMode;
@property(nonatomic,retain)NSString *strpendingClaimExists;
@end
