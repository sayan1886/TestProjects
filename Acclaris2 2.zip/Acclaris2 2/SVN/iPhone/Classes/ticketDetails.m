    //
//  ticketDetails.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 26/10/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import "ticketDetails.h"
#import "ticket.h"
#import "ticketPerser.h"
#import "ticketDescDetails.h"
#import "ticketClose.h"
#import "ticketUpdate.h"
#import "configurables.h"
#import "UserresponcePerser.h"
#import "Decode64.h"
#import "configurableParser.h"
#import "AcclarisViewController.h"
#define FONT_SIZE 15.0f
#define CELL_CONTENT_WIDTH 120.0f
#define CELL_CONTENT_MARGIN 10.0f


@implementation ticketDetails

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];

	
	[self signoutbt];
	selectedRow=[ticket getSelectedRow];
	arr_celltytle=[ticketPerser ticketArr];
	
	ticketTableArrlabel=[[NSArray alloc]initWithObjects:((ticketOBJ *)[ arr_celltytle objectAtIndex:selectedRow]).LBLticketID,((ticketOBJ *)[ arr_celltytle objectAtIndex:selectedRow]).LBLticketType,((ticketOBJ *)[ arr_celltytle objectAtIndex:selectedRow]).LBLstatus,((ticketOBJ *)[ arr_celltytle objectAtIndex:selectedRow]).LBLcreatedOn,((ticketOBJ *)[ arr_celltytle objectAtIndex:selectedRow]).LBLcauseNote,nil];
	ticketTableArr=[[NSArray alloc]initWithObjects:((ticketOBJ *)[ arr_celltytle objectAtIndex:selectedRow]).ticketID,((ticketOBJ *)[ arr_celltytle objectAtIndex:selectedRow]).ticketType,((ticketOBJ *)[ arr_celltytle objectAtIndex:selectedRow]).status,((ticketOBJ *)[ arr_celltytle objectAtIndex:selectedRow]).createdOn,((ticketOBJ *)[ arr_celltytle objectAtIndex:selectedRow]).causeNote,nil];
	
	
	
	
	NSMutableArray *arr_myconfig=[AcclarisViewController staticarr_config];//[configurableParser getconfig_arr];//
	con=(configurables *)[arr_myconfig objectAtIndex:0];	
	self.view.backgroundColor = [UIColor colorWithRed:con.bgRed/255.0f green:con.bgGreen/255.0f blue:con.bgBlue/255.0f alpha:1.0];
	self.navigationItem.title=@"Back";
	
	
	
	//NSMutableArray *my_arrUserinfo=[UserresponcePerser userdesc];
	UIImageView *logo_img = [[UIImageView alloc]initWithFrame:CGRectMake(0, 2, 170, 40)];
	NSData *data=[Base64 decode:con.logoImgdata];
	logo_img.image=	[UIImage imageWithData:[NSData dataWithData:data]];
	self.navigationItem.titleView=logo_img;
	
	NSData *data_btnimg=[Base64 decode:con.btnImgdata];
	
	NSMutableDictionary *roleDict=[passPerser getRolebaseDict];

	UIButton *btn_close=[UIButton buttonWithType:UIButtonTypeCustom];
	if ([[roleDict valueForKey:@"CLOSEMESSAGE"]isEqualToString:@"Yes"]) {
		btn_close.frame = CGRectMake(10, 308, 120, 47);
		[btn_close setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
		btn_close.titleLabel.font = [UIFont fontWithName:con.fontname size:con.fontsize];
		[btn_close setTitle:[roleDict valueForKey:@"CLOSEMESSAGELabel"] forState:UIControlStateNormal];
		[btn_close setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
		[btn_close addTarget:self action:@selector(close) forControlEvents:UIControlEventTouchUpInside];
		[self.view addSubview:btn_close];
	
	}
	
	UIButton *btn_update=[UIButton buttonWithType:UIButtonTypeCustom];
	if ([[roleDict valueForKey:@"UPDATEEMESSAGE"]isEqualToString:@"Yes"]) {
		btn_update.frame = CGRectMake(190, 308, 120, 47);
		//NSData *data_btnimg=[Base64 decode:con.btnImgdata];
		[btn_update setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
		btn_update.titleLabel.font = [UIFont fontWithName:con.fontname size:con.fontsize];
		[btn_update setTitle:[roleDict valueForKey:@"UPDATEEMESSAGELabel"] forState:UIControlStateNormal];
		[btn_update setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
		[btn_update addTarget:self action:@selector(update) forControlEvents:UIControlEventTouchUpInside];
		[self.view addSubview:btn_update];
	}		
		
	[self createtableview];
	
	if ([((ticketOBJ *)[ arr_celltytle objectAtIndex:selectedRow]).status isEqualToString:@"Resolved"])
		{
			btn_close.alpha=0;
			btn_update.alpha=0;
		}
}
-(void)signoutbt
{
	UIBarButtonItem *signoutButton = [[UIBarButtonItem alloc]
									  initWithTitle:@"Sign Off"
									  style:UIBarButtonItemStyleBordered
									  target:self
									  action:@selector(signout)];
    self.navigationItem.rightBarButtonItem =signoutButton;
}
-(void)signout
{
	[((AcclarisAppDelegate *)[[UIApplication sharedApplication] delegate]) removeTabBar];
}
-(void)close
{
	ticketClose *myticketClose = [[[ticketClose alloc] init] autorelease];
	[self.navigationController pushViewController:myticketClose animated:YES];
}
-(void)update
{
	ticketUpdate *myticketUpdate = [[[ticketUpdate alloc] init] autorelease];
	[self.navigationController pushViewController:myticketUpdate animated:YES];
}

-(void)createtableview
{
	UITableView	*acctable=[[UITableView alloc] initWithFrame:CGRectMake(0,0,320,300) style:UITableViewStyleGrouped];
	acctable.delegate = self;
	acctable.dataSource = self;
	acctable.scrollEnabled = YES;
	acctable.autoresizesSubviews = YES;
	acctable.showsVerticalScrollIndicator=YES;
	acctable.showsHorizontalScrollIndicator=YES;
	acctable.backgroundColor=[UIColor clearColor];
	[self.view addSubview:acctable];	
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView  
{
	return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	return 5;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{  
	static NSString *CellIdentifier = @"Cell";
	static NSString *CellIdentifier1 = @"Cell1";
	UITableViewCell *cell;
	
	if(cell==nil)
	{
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier] autorelease];
	}
	else
	{
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier1];
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier1] autorelease];
		
	}
	cell.selectionStyle=UITableViewCellSelectionStyleNone;
	cell.backgroundColor=[UIColor whiteColor];
	
	
	
	strFont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];

	UILabel *cellLabelText=[[UILabel alloc]initWithFrame:CGRectMake(19,15,150,20)];
	cellLabelText.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
	
	cellLabelText.backgroundColor=[UIColor clearColor];
	cellLabelText.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];

	cellLabelText.text =[ticketTableArrlabel objectAtIndex:indexPath.row];
	[cell.contentView addSubview:cellLabelText];
	[cellLabelText release];
	
	
	UILabel *cellLabelstatus=[[UILabel alloc]initWithFrame:CGRectMake(170,15,120,20)];
	cellLabelstatus.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
	CGSize constraint = CGSizeMake(CELL_CONTENT_WIDTH - (CELL_CONTENT_MARGIN * 2), 20000.0f);
	cellLabelstatus.numberOfLines=0;
	CGSize size = [[ticketTableArr objectAtIndex:indexPath.row] sizeWithFont:[UIFont fontWithName:strFont size:con.bodyImpfntsize] constrainedToSize:constraint lineBreakMode:UILineBreakModeWordWrap];
	CGFloat height = MAX(size.height, 10.0f);
	
	NSLog(@"lable %f",height);
	cellLabelstatus.frame=CGRectMake(170,15,120,height);
	cellLabelstatus.backgroundColor=[UIColor clearColor];
	cellLabelstatus.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];

	cellLabelstatus.text = [ticketTableArr objectAtIndex:indexPath.row];
	if (indexPath.row==4) 
	{
		//cellLabelText.frame=CGRectMake(19,25,150,20);
		//cellLabelstatus.frame=CGRectMake(170,5,120,60);		
		//cellLabelstatus.numberOfLines=0;
		
		ticketOBJ *tickets1=((ticketOBJ *)[ arr_celltytle objectAtIndex:selectedRow]);
		if([tickets1.arrm_logs count]>0)
		{
			cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;	
		}
	}
	[cell.contentView addSubview:cellLabelstatus];
	[cellLabelstatus release];
	
	return cell;
	
	
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	if (indexPath.row==4)
	{
		ticketOBJ *tickets1=((ticketOBJ *)[ arr_celltytle objectAtIndex:selectedRow]);
		if([tickets1.arrm_logs count]>0)
		{
		
			ticketDescDetails *myticketDescDetails = [[[ticketDescDetails alloc] init] autorelease];
			[self.navigationController pushViewController:myticketDescDetails animated:YES];
		}
		
	}
	
	
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	
	//if (indexPath.row==4)
	//{
	    strFont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];

		CGSize constraint = CGSizeMake(CELL_CONTENT_WIDTH - (CELL_CONTENT_MARGIN * 2), 20000.0f);
		CGSize size = [[ticketTableArr objectAtIndex:indexPath.row] sizeWithFont:[UIFont fontWithName:strFont size:con.bodyImpfntsize] constrainedToSize:constraint lineBreakMode:UILineBreakModeWordWrap];
		CGFloat height = MAX(size.height, 10.0f);
	NSLog(@"row %f",height);

		return height + (CELL_CONTENT_MARGIN * 2);
	
		//}
	//else {
		//return 50;
	//}
//
	
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
