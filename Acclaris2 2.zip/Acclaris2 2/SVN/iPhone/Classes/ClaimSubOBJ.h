//
//  ClaimSubOBJ.h
//  Acclaris
//
//  Created by Subhojit on 25/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface ClaimSubOBJ : NSObject {

	
	NSString *strsubcategoryListCount;
	NSString *strsubname;
	NSString *strsublabel;
	NSString *strsubDisplayseq;
	
}
@property(nonatomic,retain)NSString *strsubcategoryListCount;
@property(nonatomic,retain)NSString *strsubname;
@property(nonatomic,retain)NSString *strsublabel;
@property(nonatomic,retain)NSString *strsubDisplayseq;
@end
