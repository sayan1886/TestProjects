//
//  configurables.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 11/11/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface configurables : NSObject {
	
	NSString *fontname;
	NSInteger fontsize;
	CGFloat navbarRed,navbarGreen,navbarBlue;
	CGFloat bgRed,bgGreen,bgBlue,bgRed2,bgGreen2,bgBlue2;
	CGFloat posnumRed,posnumGreen,posnumBlue;
	
	CGFloat txtRed,txtGreen,txtBlue;
	
	NSString *btnfontname;
	NSInteger btnfontsize;
	CGFloat ngtvRed,ngtvGreen,ngtvBlue;
	NSString *ngtvSufix,*ngtvPrefix,*ptvPrefix;
	
	NSString *btnImgdata;
	CGFloat linkimpRed,linkimpGreen,linkimpBlue;
	CGFloat linkgnRed,linkgnGreen,linkgnBlue;
	
	NSString *btnNavFontName;
	NSInteger btnNavFontSize;
	NSString *btnNavImgData;
	
	NSString *logoImgdata;
	
	//Diff Font size//
	NSInteger headerImpfntsize;
	NSInteger headerfntsize;
	NSInteger bodyImpfntsize;
	NSInteger bodyfntsize;
	
	
	
}
@property(nonatomic,retain)NSString *fontname,*btnfontname;
@property(nonatomic,assign)NSInteger fontsize,btnfontsize;
@property(nonatomic,assign)CGFloat navbarRed,navbarGreen,navbarBlue,bgRed,bgGreen,bgBlue,bgRed2,bgGreen2,bgBlue2;
@property(nonatomic,assign)CGFloat ngtvRed,ngtvGreen,ngtvBlue;
@property(nonatomic,assign)NSString *ngtvSufix,*ngtvPrefix,*ptvPrefix;
@property(nonatomic,assign)CGFloat posnumRed,posnumGreen,posnumBlue,txtRed,txtGreen,txtBlue;
@property(nonatomic,assign)NSString *btnImgdata;
@property(nonatomic,assign)CGFloat linkimpRed,linkimpGreen,linkimpBlue;
@property(nonatomic,assign)CGFloat linkgnRed,linkgnGreen,linkgnBlue;

@property (nonatomic, retain) NSString *btnNavFontName;
@property (nonatomic, assign) NSInteger btnNavFontSize;
@property (nonatomic, retain) NSString *btnNavImgData;
@property (nonatomic, retain) NSString *logoImgdata;

@property (nonatomic, assign) NSInteger headerImpfntsize;
@property (nonatomic, assign) NSInteger headerfntsize;
@property (nonatomic, assign) NSInteger bodyImpfntsize;
@property (nonatomic, assign) NSInteger bodyfntsize;


@end
