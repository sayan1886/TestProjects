//
//  claimActivityOBJ.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 09/11/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import "claimActivityOBJ.h"


@implementation claimActivityOBJ
@synthesize claimID;
@synthesize trxnID;
@synthesize serviceDate;
@synthesize accountType;
@synthesize claimType;
@synthesize claimCategory;
@synthesize amount;
@synthesize status;
@synthesize provider;
@synthesize paymentStatus;
@synthesize checkNo;
@synthesize paymentAmount;
@synthesize paymentMethod;
@synthesize paymentDate;
@synthesize isPreTax;
@synthesize claimSubType;
@synthesize submitDate;
@synthesize passthruClaimDate;

@synthesize LBLclaimID;
@synthesize LBLtrxnID;
@synthesize LBLserviceDate;
@synthesize LBLaccountType;
@synthesize LBLclaimType;
@synthesize LBLclaimCategory;
@synthesize LBLamount;
@synthesize LBLstatus;
@synthesize LBLprovider;
@synthesize LBLpaymentStatus;
@synthesize LBLcheckNo;
@synthesize LBLpaymentAmount;
@synthesize LBLpaymentMethod;
@synthesize LBLpaymentDate;
@synthesize LBLisPreTax;
@synthesize LBLclaimSubType;
@synthesize LBLsubmitDate;
@synthesize LBLpassthruClaimDate;

@synthesize arrdenialReason;


@end
