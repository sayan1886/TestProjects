//
//  electionOBJ.h
//  Acclaris
//
//  Created by Sayan banerjee on 19/11/10.
//  Copyright 2010 Objectsol. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface electionOBJ : NSObject {

	NSString *electionID;
	NSString *planYearType;
	NSString *planPeriod;
	NSString *endDate;
	NSString *graceEndDate;
	NSString *runOutEndDate;
	NSString *futureGraceEndDate;
	NSString *currentBalance;
	NSString *investmentBalance;
	NSString *beginDate;
	NSString *enrollmentStatus;
	NSString *dpstType;
}
@property(nonatomic,retain)NSString *electionID;
@property(nonatomic,retain)NSString *planYearType;
@property(nonatomic,retain)NSString *planPeriod;
@property(nonatomic,retain)NSString *endDate;
@property(nonatomic,retain)NSString *graceEndDate;
@property(nonatomic,retain)NSString *runOutEndDate;
@property(nonatomic,retain)NSString *futureGraceEndDate;
@property(nonatomic,retain)NSString *currentBalance;
@property(nonatomic,retain)NSString *investmentBalance;
@property(nonatomic,retain)NSString *beginDate;
@property(nonatomic,retain)NSString *dpstType;
@property(nonatomic,retain)NSString *enrollmentStatus;


@end
