//
//  Schedule.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 11/04/11.
//  Copyright 2011 ObjectSol Technologies. All rights reserved.
//

#import "ScheduleOBJ.h"


@implementation ScheduleOBJ
@synthesize highestSequenceId,hasMoreRecords;
@synthesize scheduleArr;
	

@end
