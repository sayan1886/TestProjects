//
//  PaynowOBJ.h
//  Acclaris
//
//  Created by Subhojit on 22/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface PaynowOBJ : NSObject {

	NSString *strerrorText;
	NSString *strreturnCode;
	NSString *strid;
	NSString *streeID;
	NSString *strClaimCategory;
	NSString *strClaimType;
	NSString *strClaimAmt;
	NSString *strserviceBegins;
	NSString *strserviceEnds;
	NSString *strprevYearPlanInd;
	NSString *strproviderID;
	NSString *strproviderName;
	NSString *strexternalCode;
	NSString *strexternalID;
	NSMutableArray *arr;
	
}
@property(nonatomic,retain)NSString *strid;
@property(nonatomic,retain)NSString *streeID;
@property(nonatomic,retain)NSString  *strClaimCategory;
@property(nonatomic,retain) NSString *strClaimType;
@property(nonatomic,retain)NSString *strClaimAmt;
@property(nonatomic,retain)NSString *strserviceBegins;
@property(nonatomic,retain)NSString *strserviceEnds;
@property(nonatomic,retain)NSString *strstrprevYearPlanInd;
@property(nonatomic,retain)NSString *strproviderID;
@property(nonatomic,retain)NSString *strproviderName;
@property(nonatomic,retain)NSString *strexternalCode;
@property(nonatomic,retain)NSString *strexternalID;
@property(nonatomic,retain)NSString *strerrorText;
@property(nonatomic,retain)NSString *strreturnCode;
@property(nonatomic,retain)NSMutableArray *arr;
@end
