//
//  ElectronicDeposit.h
//  Acclaris
//
//  Created by Subhojit on 22/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RequestPhase2_2.h"
#import "MyTools.h"
#import "Decode64.h"
#import "GopaperlessParser.h"
#import "GoPaperlessOBJ.h"
#import "passPerser.h"
#import "RequestPhase2_2.h"
#import "PaynowcontinueParser.h"
@class configurables;

@interface ElectronicDeposit : UIViewController<UITableViewDelegate,UITableViewDataSource,UIPickerViewDelegate,UITextFieldDelegate,UITextViewDelegate> {

	UITextField *txtBankAccountType;
	UITextField *txtBankRouting;
	UITextField *txtReenterBankRouting;
	UITextField *txtBankAccount;
	UITextField *txtReenterBankAccount;
	UITextField *txtdob;
	UITextField *txtEmail;
	
	
	UITableView *table;
	NSMutableArray  *arrAllSection;
	NSArray *pickerViewArray;
	UIPickerView *myPickerView;
	UIView *loadingView;
	configurables *con;
	MyTools *tools;
	NSMutableArray *arrelectronicdeposit;
	NSString *strTxtNm;
	UIDatePicker *datePicker;
   NSString	*strDob;
   NSString	*strEmail;
	NSDictionary *customMessageList_dict;
	
}
-(void)datePickerCreate;
-(void)createbar_button;
-(void)CreateView;
-(void)BankAccountTypeInput:(UITableViewCell *)cell;
-(void)BankRoutingInput:(UITableViewCell *)cell;
-(void)ReenterBankRoutingInput:(UITableViewCell *)cell;
-(void)BankAccountInput:(UITableViewCell *)cell;
-(void)ReenterBankAccountInput:(UITableViewCell *)cell;
-(void)constructTableCell;
-(void)ClickbtnSubmit;
-(void)CreateConnectionforsummery;
-(void)TextnoteInput:(UITableViewCell *)cell;
-(void)createbarbuttondone;
-(void)donecancel;
-(void)Vanishpicker;
-(void)signout;
-(void)EmailInput:(UITableViewCell *)cell;
-(void)DobInput:(UITableViewCell *)cell;
- (void)changeDateInLabel:(id)sender;
-(BOOL)validateEmail:(NSString *)email;
@end
