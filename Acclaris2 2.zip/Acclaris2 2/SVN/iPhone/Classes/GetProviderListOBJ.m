//
//  GetProviderListOBJ.m
//  Acclaris
//
//  Created by Subhojit on 16/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "GetProviderListOBJ.h"


@implementation GetProviderListOBJ

@synthesize strpayeeId,streeID,strname,strnickName,strprefix,strfirstName,strmiddleName,strlastName,stremail,strphone,strforFutureUse,strisActive,strpaymentReference,strproviderIdentifier,strline1,strline2,strline3,strcity,strstate,strzip,
strcountry,straddressType;

@end
