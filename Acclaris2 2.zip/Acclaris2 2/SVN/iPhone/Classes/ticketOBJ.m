//
//  ticketOBJ.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 26/10/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import "ticketOBJ.h"


@implementation ticketOBJ

@synthesize ticketID;
@synthesize LBLticketID;
@synthesize causeNote;
@synthesize LBLcauseNote;
@synthesize ticketType;
@synthesize LBLticketType;
@synthesize ticketCategory;
@synthesize createdBy;
@synthesize createdOn;
@synthesize LBLcreatedOn;
@synthesize resolvedBy;
@synthesize resolvedOn;
@synthesize resolutionNote;
@synthesize status;
@synthesize LBLstatus;
@synthesize priority;
@synthesize source;
@synthesize privacyLabel;
@synthesize ticketLogsCount;
@synthesize ticketLogs;
@synthesize arrm_logs;

-(void)dealloc{
	arrm_logs=nil;
	[super dealloc];
}
- (id)init{
	arrm_logs=nil;//[[[NSMutableArray alloc]init]autorelease];
	return self;
}


@end
