//
//  ClaimonlineSaveOBJ.m
//  Acclaris
//
//  Created by Subhojit on 31/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ClaimonlineSaveOBJ.h"


@implementation ClaimonlineSaveOBJ
@synthesize strreturnCode,strclaimCategory,strclaimType,stramount,strserviceBeginDt,strserviceEndDt,strnote,strisPriorYear,strpayMode,strerrorText,strmultipleAcct;
@end
