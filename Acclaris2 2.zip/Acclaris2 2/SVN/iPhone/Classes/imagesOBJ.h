//
//  imagesOBJ.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 07/12/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface imagesOBJ : NSObject {
	
	NSString	*receiptDate;
	NSString	*accountShortName;
	NSString	*receiptStatus;
	NSString	*receiptPurpose;
	NSString	*receiptID;
	
	
	NSString	*LBLreceiptDate;
	NSString	*LBLaccountShortName;
	NSString	*LBLreceiptStatus;
	NSString	*LBLreceiptPurpose;
	NSString	*LBLreceiptID;
	NSMutableArray *arrshowimageDetail;
}
@property(nonatomic,retain)NSString	*receiptDate;
@property(nonatomic,retain)NSString	*accountShortName;
@property(nonatomic,retain)NSString	*receiptStatus;
@property(nonatomic,retain)NSString	*receiptPurpose;
@property(nonatomic,retain)NSString	*receiptID;

@property(nonatomic,retain)NSString	*LBLreceiptDate;
@property(nonatomic,retain)NSString	*LBLaccountShortName;
@property(nonatomic,retain)NSString	*LBLreceiptStatus;
@property(nonatomic,retain)NSString	*LBLreceiptPurpose;
@property(nonatomic,retain)NSString	*LBLreceiptID;
@property(nonatomic,retain)NSMutableArray *arrshowimageDetail;

@end
