//
//  Schedule.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 11/04/11.
//  Copyright 2011 ObjectSol Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface ScheduleOBJ : NSObject {
	NSString *highestSequenceId,*hasMoreRecords;
	NSMutableArray *scheduleArr;
}
@property(nonatomic, retain)NSString *highestSequenceId,*hasMoreRecords;
@property(nonatomic, retain)NSMutableArray *scheduleArr;
@end
