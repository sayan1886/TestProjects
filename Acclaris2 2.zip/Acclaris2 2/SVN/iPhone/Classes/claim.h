//
//  claim.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 06/10/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AcclarisAppDelegate.h"
#import "SubmitNewClaimone.h"
#import "RequestPhase2.h"
#import "MyTools.h"
#import "passPerser.h"
#import "SubmitNewClaimThree.h"
#import "SubmitNewClaimTwo.h"
#import "ClaimSubmitNewParser.h"
#import "ClaimSubmitNewOBJ.h"
@class configurables;

@interface claim : UIViewController<UITableViewDelegate,UITableViewDataSource> {

	AcclarisAppDelegate *app;
	NSMutableArray *arr_celltytle;
	configurables *con;
     MyTools *tools;
	UIView *loadingView;
	NSMutableArray *arrDecide;
	
	NSString *name;
}

@property (nonatomic,retain) NSString *name;

-(id)initWithTabBar:(NSString *)label;
-(void)signoutbt;
-(void)createtableview;






@end
