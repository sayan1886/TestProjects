//
//  SubmitclaimParser.m
//  Acclaris
//
//  Created by Subhojit on 08/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "SubmitclaimParser.h"
NSMutableArray *arrgetsubmitclaimdetail;
NSString *strerrortext;
NSMutableArray *arrdenydetail;
NSMutableArray *arrReceiptrequired;
NSMutableArray *arrpendingclaim;

NSString   *strtrxnID;

@implementation SubmitclaimParser
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error
{
	
	arrgetsubmitclaimdetail = [[NSMutableArray alloc]init];
	NSXMLParser *parser;
	parser = [[NSXMLParser alloc] initWithData:data];
    [parser setDelegate:self];
	[parser setShouldProcessNamespaces:NO];
    [parser setShouldReportNamespacePrefixes:NO];
    [parser setShouldResolveExternalEntities:NO];
    [parser parse];
    NSError *parseError = [parser parserError];
    if (parseError && error) 
	{
        *error = parseError;
    }
	[parser release];
}

-(void)parserDidStartDocument:(NSXMLParser *)parser
{
	
	arrReceiptrequired=[[NSMutableArray alloc]init];
	arrpendingclaim=[[NSMutableArray alloc]init];
	arrdenydetail=[[NSMutableArray alloc]init];
	
}		

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
	if (qName)
	{
		elementName = qName;
	}
	else 
		if([elementName isEqualToString:@"returnCode"])
		{
			
						
			contentOfString=[NSMutableString string];
			[contentOfString retain];
			return;		
			
		}
		else 
			if([elementName isEqualToString:@"errorText"])
			{
				
				contentOfString=[NSMutableString string];
				[contentOfString retain];
				return;		
				
			}
	
			else 
				if([elementName isEqualToString:@"rcptRequiredClaims"])
				{
					
					strWhichtag=@"rcptRequiredClaims";
					
					
				}
				else 
					if([elementName isEqualToString:@"pendingPaymentClaims"])
					{
						strWhichtag=@"pendingPaymentClaims";
						
						
					}
			else 
				if([elementName isEqualToString:@"trxnID"])
				{
					
					contentOfString=[NSMutableString string];
					[contentOfString retain];
					return;		
					
				}

				else 
					if([elementName isEqualToString:@"claim"])
					{
						
						objSubmitclaim=[[SubmitclaimOBJ alloc]init];

												
					}

					else 
						if([elementName isEqualToString:@"clmID"])
						{
							
							contentOfString=[NSMutableString string];
							[contentOfString retain];
							return;		
							
						}

						else 
							if([elementName isEqualToString:@"clmAmount"])
							{
								
								contentOfString=[NSMutableString string];
								[contentOfString retain];
								return;		
								
							}
							else 
								if([elementName isEqualToString:@"clmCategory"])
								{
									
									contentOfString=[NSMutableString string];
									[contentOfString retain];
									return;		
									
								}

								else 
									if([elementName isEqualToString:@"clmType"])
									{
										
										contentOfString=[NSMutableString string];
										[contentOfString retain];
										return;		
										
									}

									else 
										if([elementName isEqualToString:@"actpCD"])
										{
											
											contentOfString=[NSMutableString string];
											[contentOfString retain];
											return;		
											
										}

										else 
											if([elementName isEqualToString:@"provider"])
											{
												
												contentOfString=[NSMutableString string];
												[contentOfString retain];
												return;		
												
											}

											else 
												if([elementName isEqualToString:@"serviceBegins"])
												{
													
													contentOfString=[NSMutableString string];
													[contentOfString retain];
													return;		
													
												}

												else 
													if([elementName isEqualToString:@"paymentRef"])
													{
														
														contentOfString=[NSMutableString string];
														[contentOfString retain];
														return;		
														
													}

													else 
														if([elementName isEqualToString:@"invoiceNo"])
														{
															
															contentOfString=[NSMutableString string];
															[contentOfString retain];
															return;		
															
														}
														else 
															if([elementName isEqualToString:@"customerNo"])
															{
																
																contentOfString=[NSMutableString string];
																[contentOfString retain];
																return;		
																
															}

															else 
																if([elementName isEqualToString:@"payeeID"])
																{
																	
																	contentOfString=[NSMutableString string];
																	[contentOfString retain];
																	return;		
																	
																}

																else 
																	if([elementName isEqualToString:@"servicePeriod"])
																	{
																		
																		contentOfString=[NSMutableString string];
																		[contentOfString retain];
																		return;		
																		
																	}
																	else 
																		if([elementName isEqualToString:@"deniedClaims"])
																		{
																			strWhichtag=@"deniedClaims";
																			arrdenydetail=[[NSMutableArray alloc]init];
																			
																		}

																		else 
																			if([elementName isEqualToString:@"ns2:text"])
																			{
																				
																				contentOfString=[NSMutableString string];
																				[contentOfString retain];
																				return;		
																				
																			}

																			else 
																				if([elementName isEqualToString:@"deniedOn"])
																				{
																					
																					contentOfString=[NSMutableString string];
																					[contentOfString retain];
																					return;		
																					
																				}
																				else 
																					if([elementName isEqualToString:@"deniedBy"])
																					{
																						
																						contentOfString=[NSMutableString string];
																						[contentOfString retain];
																						return;		
																						
																					}
	
	
	
}	
- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName     
{	
	if (qName)
	{
        elementName = qName;
		
    }
	else 
		if([elementName isEqualToString:@"returnCode"])
		{
			if(contentOfString)
			{
				//objSubmitclaim.strreturnCode=contentOfString;
				[contentOfString release];
				contentOfString = nil;
				
				
			}	
			
		}
		else 
			if([elementName isEqualToString:@"errorText"])
			{
				if(contentOfString)
				{
					
					strerrortext=contentOfString;
					[contentOfString release];
					contentOfString = nil;
					
					
				}		
				
			}

			
			else 
				if([elementName isEqualToString:@"pendingPaymentClaims"])
				{
					
					
						
						
					
										
				}
				else 
					if([elementName isEqualToString:@"rcptRequiredClaims"])
					{
						
						
						
					}
					else 
						if([elementName isEqualToString:@"claim"])
						{
							
							if([strWhichtag isEqualToString:@"rcptRequiredClaims"])
							
								
								  [arrReceiptrequired addObject:objSubmitclaim];
							
							else if([strWhichtag isEqualToString:@"pendingPaymentClaims"])
								    
								    [arrpendingclaim addObject:objSubmitclaim];
							
							else 
								
									[arrdenydetail addObject:objSubmitclaim];
									
									[objSubmitclaim release],objSubmitclaim=nil;
							
								
						}
						else 
							if([elementName isEqualToString:@"trxnID"])
							{
								
								strtrxnID=contentOfString;
								[contentOfString release];
								contentOfString = nil;
									
								
							}
	
	
				else 
					if([elementName isEqualToString:@"clmID"])
					{
						
						if(contentOfString)
						{
							
							objSubmitclaim.strclmID=contentOfString;
							[contentOfString release];
							contentOfString = nil;
							
							
						}		
						
					}
	
					else 
						if([elementName isEqualToString:@"clmAmount"])
						{
							
							if(contentOfString)
							{
								
								objSubmitclaim.strclmAmount=contentOfString;
								[contentOfString release];
								contentOfString = nil;
								
								
							}			
							
						}
						else 
							if([elementName isEqualToString:@"clmCategory"])
							{
								
								if(contentOfString)
								{
									
									objSubmitclaim.strclmCategory=contentOfString;
									[contentOfString release];
									contentOfString = nil;
									
									
								}			
								
							}
	
							else 
								if([elementName isEqualToString:@"clmType"])
								{
									
									if(contentOfString)
									{
										
										objSubmitclaim.strclmType=contentOfString;
										[contentOfString release];
										contentOfString = nil;
										
										
									}			
									
								}
	
								else 
									if([elementName isEqualToString:@"actpCD"])
									{
										
										objSubmitclaim.stractpCD=contentOfString;
										[contentOfString release];
										contentOfString = nil;	
										
									}
	
									else 
										if([elementName isEqualToString:@"provider"])
										{
											
											if(contentOfString)
											{
												
												objSubmitclaim.strprovider=contentOfString;
												[contentOfString release];
												contentOfString = nil;
												
												
											}			
											
										}
	
										else 
											if([elementName isEqualToString:@"serviceBegins"])
											{
												
												if(contentOfString)
												{
													
													objSubmitclaim.strserviceBegins=contentOfString;
													[contentOfString release];
													contentOfString = nil;
													
													
												}				
												
											}
	
											else 
												if([elementName isEqualToString:@"paymentRef"])
												{
													
													if(contentOfString)
													{
														
														objSubmitclaim.strpaymentRef=contentOfString;
														[contentOfString release];
														contentOfString = nil;
														
														
													}			
													
												}
	
												else 
													if([elementName isEqualToString:@"invoiceNo"])
													{
														
														if(contentOfString)
														{
															
															objSubmitclaim.strinvoiceNo=contentOfString;
															[contentOfString release];
															contentOfString = nil;
															
															
														}			
														
													}
													else 
														if([elementName isEqualToString:@"customerNo"])
														{
															
															if(contentOfString)
															{
																
																objSubmitclaim.strcustomerNo=contentOfString;
																[contentOfString release];
																contentOfString = nil;
																
																
															}			
															
														}
	
														else 
															if([elementName isEqualToString:@"payeeID"])
															{
																
																if(contentOfString)
																{
																	
																	objSubmitclaim.strpayeeID=contentOfString;
																	[contentOfString release];
																	contentOfString = nil;
																	
																	
																}			
																
															}
	
															else 
																if([elementName isEqualToString:@"servicePeriod"])
																{
																	
																	if(contentOfString)
																	{
																		
																		objSubmitclaim.strservicePeriod=contentOfString;
																		[contentOfString release];
																		contentOfString = nil;
																		
																		
																	}				
																	
																}
	
	
																else 
																	if([elementName isEqualToString:@"deniedClaims"])
																	{
																		
																		
																	}
	
																	else 
																		if([elementName isEqualToString:@"ns2:text"])
																		{
																			
																			if(contentOfString)
																			{
																				
																				objSubmitclaim.strtext=contentOfString;
																				[contentOfString release];
																				contentOfString = nil;
																				
																				
																			}			
																			
																		}
	
																		else 
																			if([elementName isEqualToString:@"deniedOn"])
																			{
																				
																				if(contentOfString)
																				{
																					
																					objSubmitclaim.strdeniedOn=contentOfString;
																					[contentOfString release];
																					contentOfString = nil;
																					
																					
																				}			
																				
																			}
																			else 
																				if([elementName isEqualToString:@"deniedBy"])
																				{
																					
																					if(contentOfString)
																					{
																						
																						objSubmitclaim.strdeniedBy=contentOfString;
																						[contentOfString release];
																						contentOfString = nil;
																						
																						
																					}			
																					
																				}
	
	
	
	
}	

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
	if(contentOfString)
		[contentOfString appendString:string];
}

- (void)parserDidEndDocument:(NSXMLParser *)parse
{
	
	//NSLog(@"arrgetsubmitclaimdetail  %@",arrgetsubmitclaimdetail);
	//objSubmitclaim=(SubmitclaimOBJ *)[arrdenydetail objectAtIndex:0];
	//NSLog(@"return code:%@",objSubmitclaim.strreturnCode);
	
	NSLog(@"%d",[arrdenydetail count]);
	NSLog(@"%d",[arrReceiptrequired count]);
	NSLog(@"%d",[arrpendingclaim count]);
	
}

+(NSMutableArray *)getarrdenydetail
{
	
	
	if (arrdenydetail) {
		
		return arrdenydetail;
	}
	else {
		return nil;
	}
	
	
}
+(NSMutableArray *)getarrReceiptrequired
{
	
	
	if (arrReceiptrequired) {
		
		return arrReceiptrequired;
	}
	else {
		return nil;
	}
	
	
}
+(NSMutableArray *)getarrpendingclaim
{
	
	
	if (arrpendingclaim) 
	{
		
		return arrpendingclaim;
	}
	else 
	{
		return nil;
	}
	
	
}
+(NSString *)getErrortxt

{
	
	
	return strerrortext;
}
+(NSString *)getstrtrxnID
{
	
	return strtrxnID;
}
@end
