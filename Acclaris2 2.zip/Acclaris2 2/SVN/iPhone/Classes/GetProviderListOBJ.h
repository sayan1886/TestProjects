//
//  GetProviderListOBJ.h
//  Acclaris
//
//  Created by Subhojit on 16/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface GetProviderListOBJ : NSObject {

	
	NSString *strpayeeId;
	NSString *streeID;
	NSString *strname;
	NSString *strnickName;
	NSString *strprefix;
	NSString *strfirstName;
	NSString *strmiddleName;
	NSString *strlastName;
	NSString *stremail;
	NSString *strphone;
	NSString *strforFutureUse;
	NSString *strisActive;
	NSString *strpaymentReference;
	NSString *strproviderIdentifier;
	NSString *strline1;
	NSString *strline2;
	NSString *strline3;
	NSString *strcity;
	NSString *strstate;
	NSString *strzip;
	NSString *strcountry;
	NSString *straddressType;
	

}

@property(nonatomic,retain) NSString *strpayeeId;
@property(nonatomic,retain) NSString *streeID;

@property(nonatomic,retain) NSString *strname;
@property(nonatomic,retain) NSString *strnickName;
@property(nonatomic,retain) NSString *strprefix;
@property(nonatomic,retain) NSString *strfirstName;
@property(nonatomic,retain) NSString *strmiddleName;
@property(nonatomic,retain) NSString *strlastName;
@property(nonatomic,retain) NSString *stremail;

@property(nonatomic,retain) NSString *strphone;
@property(nonatomic,retain) NSString *strforFutureUse;
@property(nonatomic,retain) NSString *strisActive;
@property(nonatomic,retain) NSString *strpaymentReference;
@property(nonatomic,retain) NSString *strproviderIdentifier;
@property(nonatomic,retain) NSString *strline1;
@property(nonatomic,retain) NSString *strline2;
@property(nonatomic,retain) NSString *strline3;

@property(nonatomic,retain) NSString *strcity;
@property(nonatomic,retain) NSString *strstate;

@property(nonatomic,retain) NSString *strzip;
@property(nonatomic,retain) NSString *strcountry;
@property(nonatomic,retain) NSString *straddressType;




@end
