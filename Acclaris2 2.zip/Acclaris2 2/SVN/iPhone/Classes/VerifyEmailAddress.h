//
//  VerifyEmailAddress.h
//  Acclaris
//
//  Created by Subhojit on 10/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyTools.h"
#import "Decode64.h"
#import "RequestPhase2_2.h"
#import "passPerser.h"
#import "PaynowcontinueParser.h"
#import "GoPaperlessOBJ.h"
#import "GopaperlessParser.h"
#import "AddEmailParser.h"
#import "AddEmailOBJ.h"
@class configurables;


@interface VerifyEmailAddress : UIViewController<UITextFieldDelegate> 
{

	
	UITextField *txtEmail;
	UITextField	*txtrenterEmail;
	MyTools *tools;
	configurables *con;
	UIView *loadingView;
	NSMutableArray *arrGopaperless;
	
}
-(void)CreateView;
-(BOOL)validateEmail:(NSString *)email ;
-(void)CreateConnectionforsummery;

@end
