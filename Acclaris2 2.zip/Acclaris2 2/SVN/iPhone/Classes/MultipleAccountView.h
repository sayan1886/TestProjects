//
//  MultipleAccountView.h
//  Acclaris
//
//  Created by Subhojit on 15/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ClaimonlineSaveOBJ.h"
#import"Claimonlineserviceparser.h"
#import "MultipleAccountOBJ.h"
#import <QuartzCore/QuartzCore.h>

@protocol didSelectInterested <NSObject>

-(void)whichSelected:(NSString *)str ;

@end

@interface MultipleAccountView : UIView<UITableViewDelegate,UITableViewDataSource> {

	UITableView  *table;
	NSMutableArray *arrMultipleAcc;
	id<didSelectInterested>Interesteddelegate;
	NSString *strAccValue;

}

@property (nonatomic, retain) id<didSelectInterested>Interesteddelegate;
-(void)CreateView;
@end
