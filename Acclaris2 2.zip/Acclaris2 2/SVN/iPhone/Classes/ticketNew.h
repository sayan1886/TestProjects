//
//  ticketNew.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 08/11/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AcclarisAppDelegate.h"
#import "MyTools.h"
@class configurables;


@interface ticketNew : UIViewController<UITextFieldDelegate,UIPickerViewDelegate,UITextViewDelegate> {
	
	
	MyTools *tools;
	UIView *loadingView;
	AcclarisAppDelegate *app;
	UIView *viewself;
	UITextField	*txt_messageType_text;
	NSMutableArray *tktType;
	UIBarButtonItem *signoutButton;
	UIBarButtonItem *doneButton;
	UITextView *txtv_msgNewNotes;
	configurables *con;
}
-(void)ticketTypeRequest;
-(void)ticketRequest;
-(void)populateRadiusPicker;
-(void)signoutbt;
-(void)donebt;
-(void)reqTicket;
@end
