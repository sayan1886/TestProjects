//
//  GopaperlessParser.h
//  Acclaris
//
//  Created by Subhojit on 11/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GoPaperlessOBJ.h"
#import "StatementforGoPaparlessOBJ.h"
#import "SelectOptionGoPaperlessOBJ.h"


@interface GopaperlessParser : NSObject<NSXMLParserDelegate> {

	NSMutableString *contentOfString;
	GoPaperlessOBJ *myGoPaperlessOBJ;
	StatementforGoPaparlessOBJ *myStatementforGoPaparlessOBJ;
	SelectOptionGoPaperlessOBJ *objselect;
	BOOL isSelected;
	
}
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error;
+(NSMutableArray *)getarrgoPaperlessinfo;
+(NSMutableArray *)getarrStatement;
@end
