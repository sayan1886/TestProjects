//
//  Deleteparser.h
//  Acclaris
//
//  Created by Subhojit on 11/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Deleteparser : NSObject<NSXMLParserDelegate> {

	NSMutableString *contentOfString;
	
}
+(NSString *)getErrortxt;
+(NSString *)getReturncode;
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error;
@end
