//
//  configurableParser.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 18/11/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>

@class configurables;
@interface configurableParser : NSObject<NSXMLParserDelegate> {

	NSMutableArray *controls;
	NSMutableArray *individualcontrols;
	NSMutableArray *controlproperties;
	NSMutableArray *controlpropertylist;
	NSMutableString *contentOfString;
	bool gotfont;
	
	
	NSMutableArray *property;
	NSMutableDictionary *customtext;
	configurables *con;
}
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error;
+(NSMutableArray *)getconfig_arr;
@end
