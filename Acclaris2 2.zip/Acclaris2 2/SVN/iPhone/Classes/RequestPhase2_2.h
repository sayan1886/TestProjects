//
//  RequestPhase2_2.h
//  Acclaris
//
//  Created by Subhojit on 09/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AcclarisAppDelegate.h"
#import "Constants.h"
#import "MyTools.h"
#import "PaynowcontinueParser.h"
#import "eCommunicationParser.h"
#import "AddEmailParser.h"
#import "ReceiptShowParser.h"
#import "errorResponseAlert.h"

@class GopaperlessParser;
@interface RequestPhase2_2 : NSObject {

	AcclarisAppDelegate *app;
	NSString *whichAPI;
	MyTools *tools;
	id target;
	SEL successHandler;
	SEL failureHandler;
	NSMutableData *d2;
	BOOL isstatus;
	
}
-(id)initWithTarget:(id)actionTarget
	  SuccessAction:(SEL)successAction 
	  FailureAction:(SEL)failureAction;
-(void)callPostMethod:(NSMutableString *)sRequest Action:(NSString *)action API:(NSString *)api;
-(NSString *)getUTCFormateDate:(NSDate *)localDate;
-(NSMutableString *)createHeader;
-(NSMutableString *)createHeader1;

-(void)AddEmail:(NSString *)participantID uID:(NSString *)userID  email:(NSString *)email;

-(void)AddPhoneNumber:(NSString *)participantID uID:(NSString *)userID  areaP:(NSString *)areaP restP:(NSString *)restP extnP:(NSString *)extnP

				areaS:(NSString *)areaS	restS:(NSString *)restS  extnS:(NSString *)extnS;

-(void)VerifyEmail:(NSString *)participantID uID:(NSString *)userID  email:(NSString *)email;

-(void)GetPrimarySummery:(NSString *)participantID uID:(NSString *)userID ; 



-(void)SubmitforeCommunication:(NSString *)participantID uID:(NSString *)userID email:(NSString *)email  reenterEmail:(NSString *)reenterEmail hsaStatement:(NSString *)hsaStatement
			  accountStatement:(NSString *)accountStatement otherCommunication:(NSString *)otherCommunication;

-(void)EditAchRequest:(NSString *)participantID uID:(NSString *)userID  accountType:(NSString *)accountType accountNo:(NSString *)accountNo reAccountNo:(NSString *)reAccountNo
			routingNo:(NSString *)routingNo   reRoutingNo:(NSString *)reRoutingNo   status:(NSString *)status dob:(NSString *)dob  
				email:(NSString *)email;


-(void)GetCustomText:(NSString *)participantID uID:(NSString *)userID ;

-(void)ShowImage:(NSString *)participantID uID:(NSString *)userID  fileID:(NSString *)fileID;

@end
