//
//  ClaimSubmitNewOBJ.m
//  Acclaris
//
//  Created by Subhojit on 25/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ClaimSubmitNewOBJ.h"


@implementation ClaimSubmitNewOBJ
@synthesize strcategoryListCount,strname,strlabel,arrclaimsubtype,strDisplayseq,strpriorYearActivePlan,strPayMode,strpendingClaimExists;
-(void)dealloc{
	arrclaimsubtype=nil;
	[super dealloc];
}
- (id)init{
	arrclaimsubtype=nil;//[[[NSMutableArray alloc]init]autorelease];
	return self;
}

@end
