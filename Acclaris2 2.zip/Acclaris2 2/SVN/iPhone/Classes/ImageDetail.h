//
//  ImageDetail.h
//  Acclaris
//
//  Created by Subhojit on 19/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyTools.h"
#import "AcclarisAppDelegate.h"
#import "imagesOBJ.h"
#import "ShowImageDetailsOBJ.h"
#import "ImageShow.h"
#import "passPerser.h"

#import "AcclarisViewController.h"
@class configurables;

@interface ImageDetail : UIViewController<UITableViewDelegate,UITableViewDataSource> {

	AcclarisAppDelegate *app;
	configurables *con;
	MyTools *tools;
	UIView *loadingView;
	UITableView *table;

	NSMutableArray *arrdetailImageInfo;
	int Selectedrow;
	imagesOBJ *my;
	ShowImageDetailsOBJ *myShow;
	
	
}
-(void)signoutbt;
-(void)CreateView;
-(id)initWithrowno:(int)row;
@end
