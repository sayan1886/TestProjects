//
//  ticketupdatePerser.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 04/11/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface ticketupdatePerser : NSObject<NSXMLParserDelegate> {

	NSMutableString *contentOfString;
	NSMutableString *arrItem;
}
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error;
+(NSMutableArray *)updateresponse;
@end
