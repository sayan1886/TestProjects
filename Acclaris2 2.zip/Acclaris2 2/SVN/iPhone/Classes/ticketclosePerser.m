//
//  ticketclosePerser.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 23/12/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import "ticketclosePerser.h"

NSMutableArray *arrcloseresponse;
@implementation ticketclosePerser
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error
{
	
	NSXMLParser *parser;
	parser = [[NSXMLParser alloc] initWithData:data];
    [parser setDelegate:self];
	[parser setShouldProcessNamespaces:NO];
    [parser setShouldReportNamespacePrefixes:NO];
    [parser setShouldResolveExternalEntities:NO];
    [parser parse];
    NSError *parseError = [parser parserError];
    if (parseError && error) 
	{
        *error = parseError;
    }
	[parser release];
}

-(void)parserDidStartDocument:(NSXMLParser *)parser
{
	
	arrcloseresponse=[[NSMutableArray alloc]init];
}		

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
	if(qName)
	{
        elementName = qName;
    }	
	
	if([elementName isEqualToString:@"returnCode"])
	{	
		contentOfString=[NSMutableString string];
		[contentOfString retain];
		return;				
	}
	else
	{
		;
	}
	
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName     
{	
	if(qName)
	{
        elementName = qName;
		
    }	
	
	if([elementName isEqualToString:@"returnCode"])
	{
		if(contentOfString)
		{
			[arrcloseresponse addObject:contentOfString];
			[contentOfString release];
			contentOfString = nil;
			
			
		}			
	}	
	
	
	else
	{
		;
	}
	
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
	if(contentOfString)
		[contentOfString appendString:string];
}

- (void)parserDidEndDocument:(NSXMLParser *)parse
{
	
}	
+(NSMutableArray *)closeresponse
{
	if (arrcloseresponse) {
		
		return arrcloseresponse;
	}
	else {
		return nil;
	}
	
}

@end
