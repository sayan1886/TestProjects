//
//  RollBasecOBJ.h
//  Acclaris
//
//  Created by Subhojit on 22/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface RollBasecOBJ : NSObject {

	NSString *strName;
	NSString *strDisplayseq;
	NSString *strlabel;
	NSString *displayable;
	NSMutableArray *arrSubRole;
	
}
@property(nonatomic,retain)NSString *strName;
@property(nonatomic,retain)NSString *displayable;
@property(nonatomic,retain)NSString *strDisplayseq;
@property(nonatomic,retain)NSString *strlabel;
@property(nonatomic,retain) NSMutableArray *arrSubRole;
@end
