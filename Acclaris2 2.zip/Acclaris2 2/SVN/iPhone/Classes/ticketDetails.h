//
//  ticketDetails.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 26/10/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AcclarisAppDelegate.h"
#import "MyTools.h"

@class ticket;
@class ticketDescDetails;
@class configurables;

@interface ticketDetails : UIViewController<UITableViewDelegate,UITableViewDataSource> {

	MyTools *tools;
	UIView *loadingView;

	
	AcclarisAppDelegate *app;
	NSMutableArray *arr_celltytle;
	NSInteger selectedRow;
	NSArray *ticketTableArrlabel;
	NSArray *ticketTableArr;
	configurables *con;
	
	NSString *strFont;
}

-(void)signoutbt;
-(void)createtableview;
@end
