//
//  claimActivityDetails.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 12/11/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AcclarisAppDelegate.h"
#import "MyTools.h"
@class configurables;


@interface claimActivityDetails : UIViewController<UITableViewDelegate,UITableViewDataSource> {

	MyTools *tools;
	AcclarisAppDelegate *app;
	UIView *loadingView;
	configurables *con;
	NSInteger selectedrow;
	NSMutableArray *arr_celltytle;
	NSArray *arr_cellstatus,*arr_celllabel;
	NSString *strFont;
}
-(void)signoutbt;
-(void)createtableview;
+(NSString *)getTranClaimID;
@end
