//
//  information.h
//  Acclaris
//
//  Created by Sayan banerjee on 21/11/10.
//  Copyright 2010 Objectsol. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AcclarisAppDelegate.h"
@class configurables;

@interface information : UIViewController {

	AcclarisAppDelegate *app;
	configurables *con;
	
}

@end

//if(str1.length==0|| [str1 stringByReplacingOccurrencesOfString:@" " withString:@""].length==0)