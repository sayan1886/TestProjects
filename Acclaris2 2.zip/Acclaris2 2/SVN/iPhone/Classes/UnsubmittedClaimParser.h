//
//  UnsubmittedClaimParser.h
//  Acclaris
//
//  Created by Subhojit on 01/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "UnsubmittedclaimOBJ.h"


@interface UnsubmittedClaimParser : NSObject<NSXMLParserDelegate> {

	NSMutableString *contentOfString;
	UnsubmittedclaimOBJ *objunsubmittedClaim;
}
+(NSMutableArray *)getarrgetunsubmittedClaim;
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error;
@end
