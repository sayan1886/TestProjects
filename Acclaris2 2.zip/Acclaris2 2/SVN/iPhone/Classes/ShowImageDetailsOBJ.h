//
//  ShowImageDetailsOBJ.h
//  Acclaris
//
//  Created by Subhojit on 19/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface ShowImageDetailsOBJ : NSObject {

	NSString *strfileID;
	NSString *strfileType;
	NSString *strfilePath;
	NSString *strfileSize;
	NSString *strfileReceivedOn;
	NSString *strOrigFileName;
}
@property(nonatomic,retain)NSString *strfileID;
@property(nonatomic,retain)NSString *strfileType;
@property(nonatomic,retain)NSString *strfilePath;
@property(nonatomic,retain)NSString *strfileSize;
@property(nonatomic,retain)NSString *strfileReceivedOn;
@property(nonatomic,retain)NSString *strOrigFileName;
@end
