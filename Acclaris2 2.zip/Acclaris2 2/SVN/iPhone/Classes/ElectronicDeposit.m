    //
//  ElectronicDeposit.m
//  Acclaris
//
//  Created by Subhojit on 22/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ElectronicDeposit.h"
#import "configurables.h"
#import "AcclarisViewController.h"
#import <QuartzCore/QuartzCore.h>
@implementation ElectronicDeposit

- (void)viewDidLoad {
    [super viewDidLoad];
	
	pickerViewArray = [[NSArray  arrayWithObjects:
						@"Checking",@"Savings",nil] retain];
	strDob=@"";
	strEmail=@"";
	
	customMessageList_dict=[[NSUserDefaults standardUserDefaults] objectForKey:@"customMessageList"];

	NSMutableArray *arr_myconfig=[AcclarisViewController staticarr_config];
	con=(configurables *)[arr_myconfig objectAtIndex:0];
	tools=[[MyTools alloc]init];
	loadingView=[tools createActivityIndicator1];
	
	self.view.backgroundColor = [UIColor colorWithRed:con.bgRed/255.0f green:con.bgGreen/255.0f blue:con.bgBlue/255.0f alpha:1.0];
	self.navigationController.navigationBar.tintColor=[UIColor colorWithRed:con.navbarRed/255.0f green:con.navbarGreen/255.0f blue:con.navbarBlue/255.0f alpha:1.0];
	
	UIImageView *logo_img = [[UIImageView alloc]initWithFrame:CGRectMake(0, 2, 170, 40)];
	NSData *data=[Base64 decode:con.logoImgdata];
	logo_img.image=	[UIImage imageWithData:[NSData dataWithData:data]];
	self.navigationItem.titleView=logo_img;
	
	
	
	[self createbar_button];
	
	[self CreateConnectionforsummery];
		
}
-(void)createbar_button
{
	
	UIBarButtonItem *signoutButton = [[UIBarButtonItem alloc]
									  initWithTitle:@"Sign Off"
									  style:UIBarButtonItemStyleBordered
									  target:self
									  action:@selector(signout)];
	self.navigationItem.rightBarButtonItem =signoutButton;
	
}
-(void)signout
{
	[((AcclarisAppDelegate *)[[UIApplication sharedApplication] delegate]) removeTabBar];
}

-(void)CreateConnectionforsummery
{
	
	
	NSMutableArray *userinfo_arr=[passPerser passresponce];
	RequestPhase2_2 *objrequestPhase2_2=[[RequestPhase2_2 alloc] initWithTarget:self
																  SuccessAction:@selector(onSuccefful)
																  FailureAction:@selector(onFailure)];
	
	[objrequestPhase2_2 GetPrimarySummery:[userinfo_arr objectAtIndex:2] uID:[userinfo_arr objectAtIndex:4]];
	[objrequestPhase2_2 release];
	
	[tools startLoading:self.view childView:loadingView text:@"Loading your Claim activity. Wait…."];
	
	
}
-(void)onSuccefful
{
	
	[tools stopLoading:loadingView];
	
	arrelectronicdeposit=[GopaperlessParser getarrgoPaperlessinfo];
	
	[self CreateView];
}

-(void)onFailure
{
	
	[tools stopLoading:loadingView];
	
}

-(void)CreateView
{
	
	 NSString	*strFont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];
      NSData *data_btnimg=[Base64 decode:con.btnImgdata];
		
		table=[[UITableView alloc]initWithFrame:CGRectMake(0, 65, 320, 250) style:UITableViewStylePlain];
		table.backgroundColor = [UIColor clearColor];
		table.bounces = YES;
		table.delegate=self;
		table.dataSource=self;
		table.separatorColor=[UIColor clearColor];
		[self.view addSubview:table];
		
		UIView *HeaderView=[[[UIView alloc]initWithFrame:CGRectMake(0, 0, 320, 60)]autorelease];
		HeaderView.backgroundColor=[UIColor colorWithRed:con.bgRed2/255.0 green:con.bgGreen2/255.0 blue:con.bgBlue2/255.0 alpha:1.0];
		[self.view addSubview:HeaderView];
		
		NSString *strViewTitle=@"Complete Electronic Deposit";
		//strViewTitle=[strViewTitle stringByAppendingString:@"\n"];
		//strViewTitle=[strViewTitle stringByAppendingFormat:@"%@",@"Deposit"];
		
		UILabel *lbltext=[[UILabel alloc]initWithFrame:CGRectMake(10, 5, 250, 60)];
		lbltext.text=strViewTitle;
		lbltext.backgroundColor=[UIColor clearColor];
		lbltext.textColor=[UIColor whiteColor];
		lbltext.numberOfLines=0;
		lbltext.font=[UIFont fontWithName:strFont size:con.headerImpfntsize];
		[HeaderView addSubview:lbltext];
		[lbltext release],lbltext=nil;
	
	
			
			
	UIButton *btnSubmit=[UIButton buttonWithType:UIButtonTypeCustom];
	btnSubmit.frame=CGRectMake(30, 325, 260, 40);
	[btnSubmit setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
	[btnSubmit setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	btnSubmit.titleLabel.font = [UIFont fontWithName:con.btnfontname size:con.btnfontsize];
	[btnSubmit setTitle:@"Submit" forState:UIControlStateNormal];
	[btnSubmit addTarget:self action:@selector(ClickbtnSubmit) forControlEvents:UIControlEventTouchUpInside];					 
	[self.view addSubview:btnSubmit];
	
		
	[self constructTableCell];
		
}
-(void)ClickbtnSubmit
{

	if([txtBankAccountType.text isEqualToString:@""])
	{
		NSString *strmessage=[[customMessageList_dict valueForKey:@"200053"]valueForKey:@"message"];
		NSString *strtype=[[customMessageList_dict valueForKey:@"200053"]valueForKey:@"type"];

		
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:strtype message:strmessage delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
		[alert show];
		[alert release];
		return ;
		
	}
	
	
	if([txtBankRouting.text isEqualToString:@""])
	{
		NSString *strmessage=[[customMessageList_dict valueForKey:@"200055"]valueForKey:@"message"];
		NSString *strtype=[[customMessageList_dict valueForKey:@"200055"]valueForKey:@"type"];
		
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:strtype message:strmessage delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
		[alert show];
		[alert release];
		return ;
		
	}
	

	if([txtBankRouting.text length]<9)
	{
		NSString *strmessage=[[customMessageList_dict valueForKey:@"200057"]valueForKey:@"message"];
		NSString *strtype=[[customMessageList_dict valueForKey:@"200057"]valueForKey:@"type"];
		
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:strtype message:strmessage delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
		[alert show];
		[alert release];
		return ;
		
	}
	if([txtReenterBankRouting.text isEqualToString:@""])
	{
		
		
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"ReEnter Routing No" delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
		[alert show];
		[alert release];
		return ;
		
	}
	if(![txtBankRouting.text isEqualToString:txtReenterBankRouting.text])
	{
		
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Enter Same Routing no." delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
		[alert show];
		[alert release];
		return ;
		
	}
	
	if([txtBankAccount.text isEqualToString:@""])
	{
		NSString *strmessage=[[customMessageList_dict valueForKey:@"200060"]valueForKey:@"message"];
		NSString *strtype=[[customMessageList_dict valueForKey:@"200060"]valueForKey:@"type"];

		
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:strtype message:strmessage delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
		[alert show];
		[alert release];
		return ;
		
	}
	if([txtReenterBankAccount.text isEqualToString:@""])
	{
				
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" message:@"Reenter Account No." delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
		[alert show];
		[alert release];
		return ;
		
	}
	if(![txtBankAccount.text isEqualToString:txtReenterBankAccount.text])
	{
		NSString *strmessage=[[customMessageList_dict valueForKey:@"200061"]valueForKey:@"message"];
		NSString *strtype=[[customMessageList_dict valueForKey:@"200061"]valueForKey:@"type"];
		
		
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:strtype message:strmessage delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
		[alert show];
		[alert release];
		return ;
		
		
	}
		
	NSMutableArray *userinfo_arr=[passPerser passresponce];
	RequestPhase2_2 *objrequestPhase2_2=[[RequestPhase2_2 alloc] initWithTarget:self
																  SuccessAction:@selector(onSucceffulSubmit)
																  FailureAction:@selector(onFailure)];
	
	[objrequestPhase2_2 EditAchRequest:[userinfo_arr objectAtIndex:2] uID:[userinfo_arr objectAtIndex:4] accountType:txtBankAccountType.text accountNo:txtBankAccount.text reAccountNo:txtReenterBankAccount.text routingNo:txtBankRouting.text reRoutingNo:txtReenterBankRouting.text 
                                status:@""
                                   dob:strDob
                                 email:strEmail];
	
	[objrequestPhase2_2 release];
	
	[tools startLoading:self.view childView:loadingView text:@"Loading your Claim activity. Wait…."];
	
	
}

-(void)onSucceffulSubmit
{
	
	[tools stopLoading:loadingView];
	
	NSString *strerror=[PaynowcontinueParser getErrortext];
	NSString *strreturncode=[PaynowcontinueParser getreturncode];
	
	if([strreturncode isEqualToString:@"0"])
	{
		
		[self.navigationController popViewControllerAnimated:YES];
		
	}
	else
	{
		UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:@"Info" 
															  message:strerror
															 delegate:self 
													cancelButtonTitle:@"OK" 
													otherButtonTitles:nil];
		[alertWarning show];
		[alertWarning release];
	}
	
	
	
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	
    return 1;
}



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	
	if([((GoPaperlessOBJ *)[arrelectronicdeposit objectAtIndex:0]).stremailReqForAch isEqualToString:@"Yes"] && [((GoPaperlessOBJ *)[arrelectronicdeposit objectAtIndex:0]).strdobReqForAch isEqualToString:@"Yes"])
	{
	   return 8;
	}
	else if([((GoPaperlessOBJ *)[arrelectronicdeposit objectAtIndex:0]).stremailReqForAch isEqualToString:@"No"] && [((GoPaperlessOBJ *)[arrelectronicdeposit objectAtIndex:0]).strdobReqForAch isEqualToString:@"No"])

	{
		return	6;
		
	}
	else
	{
		
		return 7;
	}


}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	
   	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
	if(nil == cell)
	{
		
		cell = [[arrAllSection objectAtIndex:0] objectAtIndex:indexPath.row];
		
	}
	
	
	cell.selectionStyle = UITableViewCellSelectionStyleNone;
	
    return cell;
	
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	
	

	     return 65.0;
	
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath

{
	
	
	
}
-(void)constructTableCell
{
	arrAllSection = [[NSMutableArray alloc] init];
	
#pragma mark --First Section
	NSMutableArray *arrFirstSection = [[NSMutableArray alloc]init];
	
	UITableViewCell *cell00 = [[UITableViewCell alloc] init];
	[self BankAccountTypeInput:cell00];
	[arrFirstSection addObject:cell00];
	[cell00 release];
	
	UITableViewCell *cell01 = [[UITableViewCell alloc] init];
	[self BankRoutingInput:cell01];
	[arrFirstSection addObject:cell01];
	[cell01 release];
	
	UITableViewCell *cell02 = [[UITableViewCell alloc] init];
	[self ReenterBankRoutingInput:cell02];
	[arrFirstSection addObject:cell02];
	[cell02 release];
	
	UITableViewCell *cell03 = [[UITableViewCell alloc] init];
	[self BankAccountInput:cell03];
	[arrFirstSection addObject:cell03];
	[cell03 release];
	
	
	UITableViewCell *cell10 = [[UITableViewCell alloc] init];
	[self ReenterBankAccountInput:cell10];
	[arrFirstSection addObject:cell10];
	[cell10 release];
	
		
	if([((GoPaperlessOBJ *)[arrelectronicdeposit objectAtIndex:0]).stremailReqForAch isEqualToString:@"Yes"])
	{
			UITableViewCell *cell12 = [[UITableViewCell alloc] init];
			[self EmailInput:cell12];
			[arrFirstSection addObject:cell12];
			[cell12 release];
	}
	
	if([((GoPaperlessOBJ *)[arrelectronicdeposit objectAtIndex:0]).strdobReqForAch isEqualToString:@"Yes"])
	{
		UITableViewCell *cell13 = [[UITableViewCell alloc] init];
		[self DobInput:cell13];
		[arrFirstSection addObject:cell13];
		[cell13 release];
		
	}	
	
	UITableViewCell *cell14 = [[UITableViewCell alloc] init];
	[self TextnoteInput:cell14];
	[arrFirstSection addObject:cell14];
	[cell14 release];
	
	
	[arrAllSection addObject:arrFirstSection];
	[arrFirstSection release];
	
}
-(void)BankAccountTypeInput:(UITableViewCell *)cell
{
	UILabel *lblBankAccountType=[[UILabel alloc]initWithFrame:CGRectMake(10, 0, 95, 45)];
	lblBankAccountType.text=@"Bank Acount Type";
	lblBankAccountType.backgroundColor=[UIColor clearColor];
	lblBankAccountType.textColor=[UIColor blackColor];
	lblBankAccountType.numberOfLines=0;
	lblBankAccountType.font=[UIFont fontWithName:@"Helvetica-Bold" size:14];
	[cell.contentView addSubview:lblBankAccountType];
	[lblBankAccountType release],lblBankAccountType=nil;
	
	txtBankAccountType=[[UITextField alloc]initWithFrame:CGRectMake(120, 5, 190, 30)];
	txtBankAccountType.delegate=self;
	txtBankAccountType.text=@"";
	txtBankAccountType.backgroundColor=[UIColor whiteColor];
	txtBankAccountType.contentVerticalAlignment=UIControlContentHorizontalAlignmentCenter;
	txtBankAccountType.borderStyle=UITextBorderStyleLine;
	txtBankAccountType.returnKeyType=UIReturnKeyDone;
	txtBankAccountType.textAlignment=UITextAlignmentLeft;
	txtBankAccountType.autocorrectionType =UITextAutocorrectionTypeNo;
	txtBankAccountType.userInteractionEnabled=YES;
	
	[cell.contentView addSubview:txtBankAccountType];			
	
}

#pragma mark -
#pragma mark emailInput Method

-(void)BankRoutingInput:(UITableViewCell *)cell
{
	
	UILabel *lblBankRouting=[[UILabel alloc]initWithFrame:CGRectMake(10, 0,130, 50)];
	lblBankRouting.text=@"Bank Routing#";
	lblBankRouting.backgroundColor=[UIColor clearColor];
	lblBankRouting.textColor=[UIColor blackColor];
	lblBankRouting.numberOfLines=0;
	lblBankRouting.font=[UIFont fontWithName:@"Helvetica-Bold" size:14];
	[cell.contentView addSubview:lblBankRouting];
	[lblBankRouting release],lblBankRouting=nil;
	
	
	txtBankRouting=[[UITextField alloc]initWithFrame:CGRectMake(120, 5, 190, 30)];
	txtBankRouting.delegate=self;
	
	//if([((GoPaperlessOBJ *)[arrelectronicdeposit objectAtIndex:0]).strachRoutingNo length]==0)
	   
		           txtBankRouting.text=@"";
	//else 
		
        //txtBankRouting.text=((GoPaperlessOBJ *)[arrelectronicdeposit objectAtIndex:0]).strachRoutingNo;
	
	txtBankRouting.secureTextEntry=YES;
	txtBankRouting.backgroundColor=[UIColor whiteColor];
	txtBankRouting.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	txtBankRouting.keyboardType=UIKeyboardTypeNumbersAndPunctuation;
	txtBankRouting.borderStyle=UITextBorderStyleLine;
	txtBankRouting.returnKeyType=UIReturnKeyDone;
	txtBankRouting.keyboardType=UIKeyboardTypeNumbersAndPunctuation;
	txtBankRouting.textAlignment=UITextAlignmentLeft;
	txtBankRouting.autocorrectionType =UITextAutocorrectionTypeNo;
	txtBankRouting.userInteractionEnabled=YES;

	[cell.contentView addSubview:txtBankRouting];
}

#pragma mark -
#pragma mark DOBInput Method

-(void)ReenterBankRoutingInput:(UITableViewCell *)cell
{
	UILabel *lblReenterBankRouting=[[UILabel alloc]initWithFrame:CGRectMake(10, 0, 145, 50)];
	lblReenterBankRouting.text=@"Reenter Bank Routing#";
	lblReenterBankRouting.backgroundColor=[UIColor clearColor];
	lblReenterBankRouting.textColor=[UIColor blackColor];
	lblReenterBankRouting.numberOfLines=0;
	lblReenterBankRouting.font=[UIFont fontWithName:@"Helvetica-Bold" size:14];
	[cell.contentView addSubview:lblReenterBankRouting];
	[lblReenterBankRouting release],lblReenterBankRouting=nil;
	
	
	txtReenterBankRouting=[[UITextField alloc]initWithFrame:CGRectMake(120, 5, 190, 30)];
	txtReenterBankRouting.delegate=self;
	//if([((GoPaperlessOBJ *)[arrelectronicdeposit objectAtIndex:0]).strachRoutingNo length]==0)
		
		    txtReenterBankRouting.text=@"";
	//else 
       // txtReenterBankRouting.text=((GoPaperlessOBJ *)[arrelectronicdeposit objectAtIndex:0]).strachRoutingNo;
	
	txtReenterBankRouting.secureTextEntry=YES;
	txtReenterBankRouting.backgroundColor=[UIColor whiteColor];
	txtReenterBankRouting.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	txtReenterBankRouting.borderStyle=UITextBorderStyleLine;
	txtReenterBankRouting.returnKeyType=UIReturnKeyDone;
	txtReenterBankRouting.keyboardType=UIKeyboardTypeNumbersAndPunctuation;
	txtReenterBankRouting.textAlignment=UITextAlignmentLeft;
	txtReenterBankRouting.autocorrectionType =UITextAutocorrectionTypeNo;
	txtReenterBankRouting.userInteractionEnabled=YES;
	[cell.contentView addSubview:txtReenterBankRouting];	
	
	
}

#pragma mark -
#pragma mark sexInput Method

-(void)BankAccountInput:(UITableViewCell *)cell
{
	UILabel *lblBankAccount=[[UILabel alloc]initWithFrame:CGRectMake(10, 5, 240, 50)];
	lblBankAccount.text=@"Bank Account#";
	lblBankAccount.backgroundColor=[UIColor clearColor];
	lblBankAccount.textColor=[UIColor blackColor];
	lblBankAccount.numberOfLines=0;
	lblBankAccount.font=[UIFont fontWithName:@"Helvetica-Bold" size:14];
	[cell.contentView addSubview:lblBankAccount];
	[lblBankAccount release],lblBankAccount=nil;
	
	txtBankAccount=[[UITextField alloc]initWithFrame:CGRectMake(120,3,190,30)];
	txtBankAccount.delegate=self;
	
	   // if([((GoPaperlessOBJ *)[arrelectronicdeposit objectAtIndex:0]).strachActNo length]==0)
			    txtBankAccount.text=@"";
	
			//else 
				
				//txtBankAccount.text=((GoPaperlessOBJ *)[arrelectronicdeposit objectAtIndex:0]).strachActNo;


	txtBankAccount.secureTextEntry=YES;
	txtBankAccount.backgroundColor=[UIColor whiteColor];
	txtBankAccount.borderStyle=UITextBorderStyleLine;
	txtBankAccount.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	txtBankAccount.returnKeyType=UIReturnKeyDone;
	txtBankAccount.keyboardType=UIKeyboardTypeNumbersAndPunctuation;
	txtBankAccount.textAlignment=UITextAlignmentLeft;
	txtBankAccount.autocorrectionType =UITextAutocorrectionTypeNo;
	txtBankAccount.userInteractionEnabled=YES;
	[cell.contentView addSubview:txtBankAccount];
}

#pragma mark -
#pragma mark lookingForInput Method

-(void)ReenterBankAccountInput:(UITableViewCell *)cell
{
	UILabel *lblReenterBankAccount=[[UILabel alloc]initWithFrame:CGRectMake(10, 5, 140, 50)];
	lblReenterBankAccount.text=@"Reenter Bank Account#";
	lblReenterBankAccount.backgroundColor=[UIColor clearColor];
	lblReenterBankAccount.textColor=[UIColor blackColor];
	lblReenterBankAccount.numberOfLines=0;
	lblReenterBankAccount.font=[UIFont fontWithName:@"Helvetica-Bold" size:14];
	[cell.contentView addSubview:lblReenterBankAccount];
	[lblReenterBankAccount release],lblReenterBankAccount=nil;
	
	
	txtReenterBankAccount=[[UITextField alloc]initWithFrame:CGRectMake(120,5, 190, 30)];
	txtReenterBankAccount.delegate=self;
	//if([((GoPaperlessOBJ *)[arrelectronicdeposit objectAtIndex:0]).strachActNo length]==0)
	             txtReenterBankAccount.text=@"";     
	//else 
          //txtReenterBankAccount.text=((GoPaperlessOBJ *)[arrelectronicdeposit objectAtIndex:0]).strachActNo;
	txtReenterBankAccount.secureTextEntry=YES;
	txtReenterBankAccount.backgroundColor=[UIColor whiteColor];
	txtReenterBankAccount.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	txtReenterBankAccount.borderStyle=UITextBorderStyleLine;
	txtReenterBankAccount.keyboardType=UIKeyboardTypeNumbersAndPunctuation;
	txtReenterBankAccount.returnKeyType=UIReturnKeyDone;
	txtReenterBankAccount.textAlignment=UITextAlignmentLeft;
	txtReenterBankAccount.autocorrectionType =UITextAutocorrectionTypeNo;
	txtReenterBankAccount.userInteractionEnabled=YES;
	[cell.contentView addSubview:txtReenterBankAccount];
	
	
}

-(void)TextnoteInput:(UITableViewCell *)cell
{
	
	
	UITextView *txtView=[[[UITextView alloc]init]autorelease];
	txtView.frame=CGRectMake(20, 0, 280, 70);
	txtView.delegate=self;
	[[txtView layer] setBorderColor:[[UIColor blackColor] CGColor]];
	[[txtView layer] setBorderWidth:1.0];
	[[txtView layer] setCornerRadius:2.0];
	[txtView setClipsToBounds: YES];
	
	txtView.text=@"Note: It may take up to 15 days to validate your Direct Deposit information. "
	"During that time, any payments to you will be made by check and not by ACH Direct Deposit. I authorize the Reimbursement Account "
	"Administrator to electronically deposit entries to my financial institution (as indicated above) for the reimbursement of my "
	"flexible spending account. I further authorize the Reimbursement Account Administrator to process charges (debit and credit entries) to my "
	"account to adjust for any errors related to such entries. I understand that the Reimbursement Account Administrator is NOT responsible if my "
	"financial institution does not make funds immediately available at the time of transmission and is not responsible or liable for any errors or "
	"disputes arising from my relationship with my financial institution. Direct Deposit will begin on the next available reimbursement cycle after "
	"receipt of this form and administrative validation of account and routing number information. I further understand that I may terminate or change "
	"this agreement with written notification to the Reimbursement Account Administrator or by editing my direct deposit account information in my online "
	"account with the Reimbursement Account Administrator. Any such change or notification will be effective only after the Reimbursement Account "
	"Administrator has had reasonable time to act on it. Pressing the Submit button below acknowledges your understanding and agreement with the above "
	"statements.";
	txtView.userInteractionEnabled=YES;
	[cell.contentView addSubview:txtView];
	
	
}
-(void)EmailInput:(UITableViewCell *)cell
{
	
	UILabel *lblEmail = [[UILabel alloc]initWithFrame:CGRectMake(10, 0, 140, 50)];
	lblEmail.backgroundColor = [UIColor clearColor];
	lblEmail.text=@"Email";
	lblEmail.font = [UIFont fontWithName:@"Helvetica-Bold" size:15];
	lblEmail.textAlignment = UITextAlignmentLeft;
	lblEmail.textColor=[UIColor blackColor];
	[cell.contentView addSubview:lblEmail];
	[lblEmail release], lblEmail = nil;
	
	
	txtEmail = [[UITextField alloc]initWithFrame:CGRectMake(120,6, 190, 30)];
	txtEmail.backgroundColor = [UIColor whiteColor];
	txtEmail.autocorrectionType = UITextAutocorrectionTypeNo;
	txtEmail.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	if([((GoPaperlessOBJ *)[arrelectronicdeposit objectAtIndex:0]).stremail length]==0)
	
	txtEmail.text=@"";
	else 
	{
		 txtEmail.text=((GoPaperlessOBJ *)[arrelectronicdeposit objectAtIndex:0]).stremail;
		 strEmail=((GoPaperlessOBJ *)[arrelectronicdeposit objectAtIndex:0]).stremail;
	}

	
	txtEmail.keyboardType=UIKeyboardTypeEmailAddress;
	txtEmail.delegate=self;
	txtEmail.borderStyle = UITextBorderStyleLine;
	//[focusArray addObject:txtEmail];
	
	[cell.contentView addSubview:txtEmail];
	
	
}


-(void)DobInput:(UITableViewCell *)cell
{
	
	
	UILabel *lbldob = [[UILabel alloc]initWithFrame:CGRectMake(10, 0, 140, 50)];
	lbldob.backgroundColor = [UIColor clearColor];
	lbldob.text=@"DOB";
	lbldob.font = [UIFont fontWithName:@"Helvetica-Bold" size:15];
	lbldob.textAlignment = UITextAlignmentLeft;
	lbldob.textColor=[UIColor blackColor];
	[cell.contentView addSubview:lbldob];
	[lbldob release], lbldob = nil;
	
	
	txtdob = [[UITextField alloc]initWithFrame:CGRectMake(120,6, 190, 30)];
	txtdob.backgroundColor = [UIColor whiteColor];
	txtdob.autocorrectionType = UITextAutocorrectionTypeNo;
	txtdob.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
	if([((GoPaperlessOBJ *)[arrelectronicdeposit objectAtIndex:0]).strdob length]==0)
	
	    txtdob.text=@"";
	else 
	{
		txtdob.text=((GoPaperlessOBJ *)[arrelectronicdeposit objectAtIndex:0]).strdob;
	     strDob=((GoPaperlessOBJ *)[arrelectronicdeposit objectAtIndex:0]).strdob;
	}
	
	txtdob.keyboardType=UIKeyboardTypeEmailAddress;
	txtdob.delegate=self;
	txtdob.borderStyle = UITextBorderStyleLine;
	//[focusArray addObject:txtdob];
	
	[cell.contentView addSubview:txtdob];
	
	
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component;
{
	
	NSString *str=@"";
			
		txtBankAccountType.text=[str stringByAppendingFormat:@"%@",[pickerViewArray objectAtIndex:[pickerView selectedRowInComponent:0]]];
	
	
	//[pickerView removeFromSuperview];
	
	
}
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
	
	
	return [pickerViewArray objectAtIndex:row];	
}

- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component
{
	// first column size is wider to hold names
	
	return 150.0;                     // second column is narrower to show numbers
	
}

- (CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component
{
	return 40.0;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
	return [pickerViewArray count];
	
	
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
	return 1;
	
}
-(void)CreatePickerView
{
	
	
	myPickerView = [[UIPickerView alloc] initWithFrame:CGRectMake(0, 155, 180, 150)];
	myPickerView.showsSelectionIndicator = YES;
	myPickerView.delegate = self;
	[self.view addSubview:myPickerView];
	
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
	
	
	if(textField==txtBankAccountType)
	{
		[self Vanishpicker];
		[self createbarbuttondone];
		[self CreatePickerView];
		return NO;
	}
	
	else if(textField==txtdob)
	{
		
		strTxtNm=@"txtdob";
		[self Vanishpicker];
		[self createbarbuttondone];
		[self datePickerCreate];
		return NO;
		
	}
		
	
	return YES;
}
- (BOOL)textFieldShouldEndEditing:(UITextField *)textField
{
	
	return YES;
	
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
   if(textField==txtEmail)
		
	{
		
		BOOL check=[self validateEmail:txtEmail.text];
		if(!check)
		{
			NSString *strmessage=[[customMessageList_dict valueForKey:@"200050"]valueForKey:@"message"];
			NSString *strtype=[[customMessageList_dict valueForKey:@"200050"]valueForKey:@"type"];
			UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:strtype
																  message:strmessage 
																 delegate:self 
														cancelButtonTitle:@"OK" 
														otherButtonTitles:nil];
			[alertWarning show];
			[alertWarning release];
			
		}
		
		else 
		{
			NSArray *arr=[textField.text componentsSeparatedByString:@".@"];
			if([arr	 count]==2)
			{
				
				NSString *strmessage=[[customMessageList_dict valueForKey:@"200050"]valueForKey:@"message"];
				NSString *strtype=[[customMessageList_dict valueForKey:@"200050"]valueForKey:@"type"];
				UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:strtype
																	  message:strmessage
																	 delegate:self 
															cancelButtonTitle:@"OK" 
															otherButtonTitles:nil];
				[alertWarning show];
				[alertWarning release];
				
				
			}
			else 
			{
				
			}
			
		}
	}
	
	

	[textField resignFirstResponder];
	return YES;
	
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string 
{
	
	
	
	if(textField==txtBankRouting || textField==txtReenterBankRouting)
		
	{
		NSString *newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
		if([newString length]>9)
		{
			
			return NO;
		}
		else if([string isEqualToString:@"E"])
		{
			
			return NO;
		}
		else if([string isEqualToString:@"."])
		{
			return NO;
		}
		
		else if ([string isEqualToString:@"e"]) 
		{
			return NO;
		}
		
		else if([string isEqualToString:@" "])
		{
			
			return NO;
		}
		
		else 
			
		{
			
			NSString *resultingString = [textField.text stringByReplacingCharactersInRange:range withString: string];
			
			if ([resultingString length] == 0) 
				
			{
				
				return true;
				
			}
			
			NSDecimal holder;
			
			NSScanner *scan = [NSScanner scannerWithString: resultingString];
			
			return [scan scanDecimal:&holder] && [scan isAtEnd];
			
			
	    }
	}
	
	else if(textField==txtBankAccount || textField==txtReenterBankAccount)
	{
		NSString *newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
		if([newString length]>9)
		{
			
			return NO;
		}
		else if([string isEqualToString:@"E"])
		{
			
			return NO;
		}
		else if([string isEqualToString:@"."])
		{
			return NO;
		}
		
		else if ([string isEqualToString:@"e"]) 
		{
			return NO;
		}
		
		else if([string isEqualToString:@" "])
		{
			
			return NO;
		}
		
		else 
			
		{
			
			NSString *resultingString = [textField.text stringByReplacingCharactersInRange:range withString: string];
			
			if ([resultingString length] == 0) 
				
			{
				
				return true;
				
			}
			
			NSDecimal holder;
			
			NSScanner *scan = [NSScanner scannerWithString: resultingString];
			
			return [scan scanDecimal:&holder] && [scan isAtEnd];
			
			
	    }
	}


	
	return YES;
	
	
}

- (BOOL)textViewShouldBeginEditing:(UITextView *)textView

{
	

	return NO;
	
	
}
-(void)createbarbuttondone
{
	UIBarButtonItem *doneButton = [[UIBarButtonItem alloc]
								   initWithTitle:@"Done"
								   style:UIBarButtonItemStyleBordered
								   target:self
								   action:@selector(donecancel)];
	
	
	
    self.navigationItem.rightBarButtonItem =doneButton;
	
}

-(void)donecancel
{
	[self  createbar_button];
	
	[self Vanishpicker];
	
	
}
-(void)datePickerCreate
{		
	//NSDateFormatter *df = [[NSDateFormatter alloc] init];
	//df.dateStyle = NSDateFormatterFullStyle;
	//df setDateFormat:@" MM-dd-yyyy"];
	//[df release];
	//strdDate=[df stringFromDate:datePicker.date]; 
	
	datePicker = [[UIDatePicker alloc] initWithFrame:CGRectMake(0, 240, 60, 60)];
	
	//datePicker.transform = CGAffineTransformMake(0.6, 0, 0, 0.7, -80, 0);
	
	
	datePicker.datePickerMode = UIDatePickerModeDate;
	datePicker.hidden = NO;
	datePicker.date = [NSDate date];
	datePicker.maximumDate=[NSDate date];
	[datePicker addTarget:self
				   action:@selector(changeDateInLabel:)
		 forControlEvents:UIControlEventValueChanged];
	
	[self.view addSubview:datePicker];
	//[datePick release];
}
- (void)changeDateInLabel:(id)sender
{	
	NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
	[dateFormat setDateFormat:@"MM/dd/yyyy"];
	 NSString	*strDate1=[dateFormat stringFromDate:datePicker.date]; 
		
		txtdob.text=strDate1;
	

}

-(void)Vanishpicker
{
	if(myPickerView)
	{
		[myPickerView removeFromSuperview];
	    [myPickerView release],myPickerView=nil;
	}
	 if(datePicker)
	{
		[datePicker removeFromSuperview];
		[datePicker release], datePicker = nil;
		
	}
	
}
-(BOOL)validateEmail:(NSString *)email
{ 
	BOOL stricterFilter = YES; // Discussion http://blog.logichigh.com/2010/09/02/validating-an-e-mail-address/
	NSString *stricterFilterString = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
	NSString *laxString = @".+@.+\\.[A-Za-z]{2}[A-Za-z]*";
	NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
	NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
	return [emailTest evaluateWithObject:email];
}
	/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
	txtBankAccountType=nil;
	txtReenterBankAccount=nil;
	txtBankRouting=nil; 
	txtReenterBankRouting=nil;
	
}


- (void)dealloc {
	[txtBankAccountType release];
	[txtReenterBankAccount release];
	[txtBankRouting release];
	[txtReenterBankRouting release];
	
    [super dealloc];
}


@end
