//
//  eCommunicationParser.m
//  Acclaris
//
//  Created by Subhojit on 16/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "eCommunicationParser.h"
NSMutableArray *arrtext;

@implementation eCommunicationParser
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error
{
	
	NSXMLParser *parser;
	parser = [[NSXMLParser alloc] initWithData:data];
    [parser setDelegate:self];
	[parser setShouldProcessNamespaces:NO];
    [parser setShouldReportNamespacePrefixes:NO];
    [parser setShouldResolveExternalEntities:NO];
    [parser parse];
    NSError *parseError = [parser parserError];
    if (parseError && error) 
	{
        *error = parseError;
    }
	[parser release];
}

-(void)parserDidStartDocument:(NSXMLParser *)parser
{
	
	arrtext=[[NSMutableArray alloc]init];
	
}		

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
	if (qName)
	{
		elementName = qName;
	}
	
	else 
		if([elementName isEqualToString:@"GetCustomTextMADetails"])
		{
			obj=[[eCommunicationOBJ  alloc]init];	
			
		}
	else 
		if([elementName isEqualToString:@"returnCode"])
		{
			contentOfString=[NSMutableString string];
			[contentOfString retain];
			return;		
			
		}
		else 
			if([elementName isEqualToString:@"errorText"])
			{
				contentOfString=[NSMutableString string];
				[contentOfString retain];
				return;		
				
			}
			else 
				if([elementName isEqualToString:@"agreementText"])
				{
					contentOfString=[NSMutableString string];
					[contentOfString retain];
					return;		
					
				}
}
- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName     
{	
	if (qName)
	{
        elementName = qName;
		
    }
	
	else 
		if([elementName isEqualToString:@"GetCustomTextMADetails"])
		{
			if(obj)
			{
				
				[arrtext addObject:obj];
				[obj release];
				obj = nil;
				
				
			}	
			
		}
	else 
		if([elementName isEqualToString:@"returnCode"])
		{
			if(contentOfString)
			{
			
				obj.strreturnCode=contentOfString;
				[contentOfString release];
				contentOfString = nil;
				
				
			}	
			
		}
		else 
			if([elementName isEqualToString:@"errorText"])
			{
				if(contentOfString)
				{
					obj.strerrorText=contentOfString;
					[contentOfString release];
					contentOfString = nil;
					
					
				}		
				
			}
	
			else 
				if([elementName isEqualToString:@"agreementText"])
				{
					if(contentOfString)
					{
											
						NSData *data=[Base64 decode:contentOfString];
						NSString *str=[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
						NSLog(@" data string%@",str);
						
						obj.stragreementText=str;
						[contentOfString release];
						contentOfString = nil;
						
						
					}
				}
}	
- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
	if(contentOfString)
		[contentOfString appendString:string];
}

- (void)parserDidEndDocument:(NSXMLParser *)parse
{
	
	
}	
+(NSMutableArray *)getarrText
{
	return arrtext;


}
@end
