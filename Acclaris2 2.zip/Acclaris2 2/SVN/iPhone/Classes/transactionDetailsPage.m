    //
//  transactionDetailsPage.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 20/10/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import "transactionDetailsPage.h"
#import "trancastionpage.h"
#import "configurables.h"
#import "transactionOBJ.h"
#import "transactionPerser.h"
#import "UserresponcePerser.h"
#import "configurableParser.h"
#import "Decode64.h"
#import "AcclarisViewController.h"
#import "InvestmentObj.h"
#import "InvestmentParser.h"
#define FONT_SIZE 15.0f
#define CELL_CONTENT_WIDTH 120.0f
#define CELL_CONTENT_MARGIN 10.0f


@implementation transactionDetailsPage


-(id)initWithInvestment:(BOOL)value
{
	self=[super init];
	isInvestment=value;
	return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
	self.view.backgroundColor=[UIColor whiteColor];
	
	NSMutableArray *arr_myconfig=[AcclarisViewController staticarr_config];//[configurableParser getconfig_arr];//
	con=(configurables *)[arr_myconfig objectAtIndex:0];
	self.view.backgroundColor = [UIColor colorWithRed:con.bgRed/255.0f green:con.bgGreen/255.0f blue:con.bgBlue/255.0f alpha:1.0];
	
	//NSMutableArray *my_arrUserinfo=[UserresponcePerser userdesc];
	UIImageView *logo_img = [[UIImageView alloc]initWithFrame:CGRectMake(0, 2, 170, 40)];
	NSData *data=[Base64 decode:con.logoImgdata];
	logo_img.image=	[UIImage imageWithData:[NSData dataWithData:data]];
	self.navigationItem.titleView=logo_img;
	
	selectedRow=[trancastionpage getSelectedRow];
	
	if(isInvestment)
	{
		arr_alltransaction=[InvestmentParser get_arr_investment];
	}
	else 
	{
		arr_alltransaction=[transactionPerser get_arr_transaction];
	}
	
	if(isInvestment)
	{
		arr_celltytle=[[NSArray alloc]initWithObjects:((InvestmentObj *)[arr_alltransaction objectAtIndex:selectedRow]).lblDate,((InvestmentObj *)[arr_alltransaction objectAtIndex:selectedRow]).lblTransactionStatus,((InvestmentObj *)[arr_alltransaction objectAtIndex:selectedRow]).lblInvestmentName,((InvestmentObj *)[arr_alltransaction objectAtIndex:selectedRow]).lblUnits,((InvestmentObj *)[arr_alltransaction objectAtIndex:selectedRow]).lblPrice,((InvestmentObj *)[arr_alltransaction objectAtIndex:selectedRow]).lblAmount,nil];
		arr_celldetails=[[NSArray alloc]initWithObjects:((InvestmentObj *)[arr_alltransaction objectAtIndex:selectedRow]).date,((InvestmentObj *)[arr_alltransaction objectAtIndex:selectedRow]).transactionStatus,((InvestmentObj *)[arr_alltransaction objectAtIndex:selectedRow]).investmentName,((InvestmentObj *)[arr_alltransaction objectAtIndex:selectedRow]).units,((InvestmentObj *)[arr_alltransaction objectAtIndex:selectedRow]).price,((InvestmentObj *)[arr_alltransaction objectAtIndex:selectedRow]).amount,nil];
	}
	else 
	{
	if ([((transactionOBJ *)[arr_alltransaction objectAtIndex:selectedRow]).transactionType isEqualToString:@"Distribution"] || [((transactionOBJ *)[arr_alltransaction objectAtIndex:selectedRow]).transactionType isEqualToString:@"preferred Repayment"]) {
		arr_celltytle=[[NSArray alloc]initWithObjects:((transactionOBJ *)[arr_alltransaction objectAtIndex:selectedRow]).lblserviceDate,((transactionOBJ *)[arr_alltransaction objectAtIndex:selectedRow]).lbltransactionType,((transactionOBJ *)[arr_alltransaction objectAtIndex:selectedRow]).lblcategory,((transactionOBJ *)[arr_alltransaction objectAtIndex:selectedRow]).lblFrom,((transactionOBJ *)[arr_alltransaction objectAtIndex:selectedRow]).lbltransactionAmount,nil];
		arr_celldetails=[[NSArray alloc]initWithObjects:((transactionOBJ *)[arr_alltransaction objectAtIndex:selectedRow]).serviceDate,((transactionOBJ *)[arr_alltransaction objectAtIndex:selectedRow]).transactionType,((transactionOBJ *)[arr_alltransaction objectAtIndex:selectedRow]).category,((transactionOBJ *)[arr_alltransaction objectAtIndex:selectedRow]).From,((transactionOBJ *)[arr_alltransaction objectAtIndex:selectedRow]).transactionAmount,nil];
		
	}
	else {
			
		arr_celltytle=[[NSArray alloc]initWithObjects:((transactionOBJ *)[arr_alltransaction objectAtIndex:selectedRow]).lbleffectiveDate,((transactionOBJ *)[arr_alltransaction objectAtIndex:selectedRow]).lbldpstType,((transactionOBJ *)[arr_alltransaction objectAtIndex:selectedRow]).lblstatus,((transactionOBJ *)[arr_alltransaction objectAtIndex:selectedRow]).lblnote,((transactionOBJ *)[arr_alltransaction objectAtIndex:selectedRow]).lbltransactionAmount,nil];
		arr_celldetails=[[NSArray alloc]initWithObjects:((transactionOBJ *)[arr_alltransaction objectAtIndex:selectedRow]).effectiveDate,((transactionOBJ *)[arr_alltransaction objectAtIndex:selectedRow]).dpstType,((transactionOBJ *)[arr_alltransaction objectAtIndex:selectedRow]).status,((transactionOBJ *)[arr_alltransaction objectAtIndex:selectedRow]).note,((transactionOBJ *)[arr_alltransaction objectAtIndex:selectedRow]).transactionAmount,nil];
	}
	}
	
	
		
	UIButton *btn_back=[UIButton buttonWithType:UIButtonTypeCustom];
	btn_back.frame = CGRectMake(43, 308, 234, 47);
	NSData *data_btnimg=[Base64 decode:con.btnImgdata];
	[btn_back setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
	btn_back.titleLabel.font = [UIFont fontWithName:con.btnfontname size:con.btnfontsize];
	[btn_back setTitle:@"Back To Transaction" forState:UIControlStateNormal];
	[btn_back setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn_back addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];
	[self.view addSubview:btn_back];
	
	
	[self signoutbt];
	[self createtableview];
	
}
-(void)backAction
{
	[self.navigationController popViewControllerAnimated:YES];
}
-(void)signoutbt
{
	UIBarButtonItem *signoutButton = [[UIBarButtonItem alloc]
									  initWithTitle:@"Sign Off"
									  style:UIBarButtonItemStyleBordered
									  target:self
									  action:@selector(signout)];
    self.navigationItem.rightBarButtonItem =signoutButton;
}
-(void)signout
{
	[((AcclarisAppDelegate *)[[UIApplication sharedApplication] delegate]) removeTabBar];
}


-(void)createtableview
{
	UITableView	*acctable=[[UITableView alloc] initWithFrame:CGRectMake(0,0,320,300) style:UITableViewStyleGrouped];
	acctable.delegate = self;
	acctable.dataSource = self;
	acctable.scrollEnabled = YES;
	acctable.autoresizesSubviews = YES;
	acctable.showsVerticalScrollIndicator=YES;
	acctable.showsHorizontalScrollIndicator=YES;
	acctable.backgroundColor=[UIColor clearColor];
	[self.view addSubview:acctable];	
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView  
{
	return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	
	return [arr_celltytle  count];
	
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{  
	static NSString *CellIdentifier = @"Cell";
	static NSString *CellIdentifier1 = @"Cell1";
	UITableViewCell *cell;
	
	if(cell==nil)
	{
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier] autorelease];
	}
	else
	{
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier1];
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier1] autorelease];
		
	}
	cell.selectionStyle=UITableViewCellSelectionStyleNone;
	cell.backgroundColor=[UIColor whiteColor];
	
	
	strFont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];
	UILabel *cellLabelText=[[UILabel alloc]initWithFrame:CGRectMake(10,17,150,20)];
	
	cellLabelText.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
	cellLabelText.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];

	cellLabelText.backgroundColor=[UIColor clearColor];
	cellLabelText.text = [arr_celltytle objectAtIndex:indexPath.row];
	[cell.contentView addSubview:cellLabelText];
	
		
	
	UILabel *cellLabelammount=[[UILabel alloc]initWithFrame:CGRectMake(190,17,120,20)];
	cellLabelammount.backgroundColor=[UIColor clearColor];
	
	
	if (indexPath.row==4)
	{
		NSString *str=[self chkvalue:[arr_celldetails objectAtIndex:indexPath.row]];
		cellLabelammount.text = str;
		if ([[arr_celldetails objectAtIndex:indexPath.row]floatValue]<0)
		{
			cellLabelammount.textColor=[UIColor colorWithRed:con.ngtvRed/255.0f green:con.ngtvGreen/255.0f blue:con.ngtvBlue/255.0f alpha:1.0];
		}
		else {
			cellLabelammount.textColor=[UIColor colorWithRed:con.posnumRed/255.0f green:con.posnumGreen/255.0f blue:con.posnumBlue/255.0f alpha:1.0];
		}

	}
	else 
	{
		cellLabelammount.text = [arr_celldetails objectAtIndex:indexPath.row];
		cellLabelammount.textColor=[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];

	}

	CGSize constraint = CGSizeMake(CELL_CONTENT_WIDTH - (CELL_CONTENT_MARGIN * 2), 20000.0f);
	CGSize size = [[arr_celldetails objectAtIndex:indexPath.row] sizeWithFont:[UIFont fontWithName:strFont size:con.bodyImpfntsize] constrainedToSize:constraint lineBreakMode:UILineBreakModeWordWrap];
	CGFloat height = MAX(size.height, 10.0f);
	cellLabelammount.numberOfLines=0;
	cellLabelammount.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
	cellLabelammount.frame=CGRectMake(190,17,120,height);
	[cell.contentView addSubview:cellLabelammount];
	
		
	return cell;
	
	
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	
	//return 55;
	
	strFont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];
	NSString *text =[arr_celldetails objectAtIndex:indexPath.row];
	CGSize constraint = CGSizeMake(CELL_CONTENT_WIDTH - (CELL_CONTENT_MARGIN * 2), 20000.0f);
	CGSize size = [text sizeWithFont:[UIFont fontWithName:strFont size:con.bodyImpfntsize] constrainedToSize:constraint lineBreakMode:UILineBreakModeWordWrap];
	CGFloat height = MAX(size.height, 10.0f);
	return height + (CELL_CONTENT_MARGIN * 2)+8;
	
	

}

-(NSString *)chkvalue:(NSString *)value
{
	NSString *newvalue=@"";
	if([value intValue]>=0)
	{
		newvalue=[newvalue stringByAppendingString:con.ptvPrefix];
		newvalue=[newvalue stringByAppendingString:value];
	}
	else {
		value=[value substringFromIndex:1];
		newvalue=[newvalue stringByAppendingString:con.ngtvPrefix];
		newvalue=[newvalue stringByAppendingString:value];
		newvalue=[newvalue stringByAppendingString:con.ngtvSufix];
		
	}
	return newvalue;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
   
}

- (void)viewDidUnload {
    [super viewDidUnload];
   
}


- (void)dealloc {
    [super dealloc];
}


@end
