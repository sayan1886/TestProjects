//
//  ActiveScheduleOBJ.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 08/04/11.
//  Copyright 2011 ObjectSol Technologies. All rights reserved.
//

#import "ActiveScheduleOBJ.h"


@implementation ActiveScheduleOBJ
@synthesize srtID,transferSchedule,transferAmount,initTransferDate,lastTransferDate,endDate,inactiveDate;
@synthesize actHolderName,actType,actNumber,bankRoutingNumber,priorPlan,electionId,lastStatus;


@synthesize lbl_srtID,lbl_transferSchedule,lbl_transferAmount,lbl_initTransferDate,lbl_lastTransferDate,lbl_endDate,lbl_inactiveDate;
@synthesize lbl_actHolderName,lbl_actType,lbl_actNumber,lbl_bankRoutingNumber,lbl_priorPlan,lbl_electionId,lbl_lastStatus;
@end
