//
//  MyScrollView.m
//  solitaire
//
//  Created by Ayon Das on 16/09/10.
//  Copyright 2009 rac it solutions pvt ltd. All rights reserved.
//

#import "MyScrollView.h"


@implementation MyScrollView


- (void) touchesBegan: (NSSet *) touches withEvent: (UIEvent *) event {
	
	[self.nextResponder touchesBegan:touches withEvent:event]; 
	[super touchesBegan: touches withEvent: event];
}


- (void) touchesMoved: (NSSet *) touches withEvent: (UIEvent *) event {
	
	[self.nextResponder touchesMoved:touches withEvent:event]; 
	
	[super touchesMoved: touches withEvent: event];
}


- (void) touchesEnded: (NSSet *) touches withEvent: (UIEvent *) event {
	
	[self.nextResponder touchesEnded: touches withEvent:event]; 
	
	[super touchesEnded: touches withEvent: event];
}




@end
