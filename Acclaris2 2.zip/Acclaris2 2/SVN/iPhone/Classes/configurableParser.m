//
//  configurableParser.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 18/11/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import "configurableParser.h"
#import "configurables.h"
NSMutableArray *config;
NSMutableDictionary *dict_custommessage;

@implementation configurableParser
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error
{
	NSXMLParser *parser;
	
	parser = [[NSXMLParser alloc] initWithData:data];
    [parser setDelegate:self];
	[parser setShouldProcessNamespaces:NO];
    [parser setShouldReportNamespacePrefixes:NO];
    [parser setShouldResolveExternalEntities:NO];
    [parser parse];
    NSError *parseError = [parser parserError];
    if (parseError && error) 
	{
        *error = parseError;
    }
	[parser release];
}

-(void)parserDidStartDocument:(NSXMLParser *)parser
{
		
	controls=[[NSMutableArray alloc]init];
}		

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
	if (qName)
	{
		elementName = qName;
	}
	else 
		if([elementName isEqualToString:@"control"])
		{
			individualcontrols=[[NSMutableArray alloc]init];
		}
	
	else 
		if([elementName isEqualToString:@"controlName"])
		{
			contentOfString=[NSMutableString string];
			[contentOfString retain];
			return;		
			
		}
		else 
			if([elementName isEqualToString:@"controlProps"])
			{
				controlproperties=[[NSMutableArray alloc]init];	
				
			}
			else 
				if([elementName isEqualToString:@"property"])
				{
					controlpropertylist=[[NSMutableArray alloc]init];	
					
				}
				else 
					if([elementName isEqualToString:@"propertyName"])
					{
								
						contentOfString=[NSMutableString string];
						[contentOfString retain];
						return;
					}
					else 
						if([elementName isEqualToString:@"propertyValue"])
						{
							
							contentOfString=[NSMutableString string];
							[contentOfString retain];
							return;
						}
						else 
							if([elementName isEqualToString:@"propertyValueImage"])
							{
								
								contentOfString=[NSMutableString string];
								[contentOfString retain];
								return;
							}
	//====================================================================================================
							else 
								if([elementName isEqualToString:@"customMessageList"])
								{
									
									dict_custommessage=[[NSMutableDictionary alloc]init];
									return;
								}
								else 
									if([elementName isEqualToString:@"customMessages"])
									{
										
										customtext=[[NSMutableDictionary alloc]init];
										return;
									}
									else 
										if([elementName isEqualToString:@"code"])
										{
											
											contentOfString=[NSMutableString string];
											[contentOfString retain];
											return;
										}
										else 
											if([elementName isEqualToString:@"message"])
											{
												
												contentOfString=[NSMutableString string];
												[contentOfString retain];
												return;
											}
											else 
												if([elementName isEqualToString:@"messageArea"])
												{
													
													contentOfString=[NSMutableString string];
													[contentOfString retain];
													return;
												}
												else 
													if([elementName isEqualToString:@"updatedOn"])
													{
														
														contentOfString=[NSMutableString string];
														[contentOfString retain];
								 						return;
													}
	
	
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName     
{	
	if (qName)
	{
        elementName = qName;
		
    }
	else 
		if([elementName isEqualToString:@"control"])
		{
			[controls addObject:individualcontrols]	;	
		}
		else 
			if([elementName isEqualToString:@"controlName"])
			{
				if(contentOfString)
				{
					[individualcontrols addObject:contentOfString];
					[contentOfString release];
					contentOfString = nil;
					
					
				}	
			}
			else 
				if([elementName isEqualToString:@"controlProps"])
				{
					
					[individualcontrols addObject:controlproperties];
					
					
				}
				else 
					if([elementName isEqualToString:@"property"])
					{
						[controlproperties addObject:controlpropertylist];
					}
					else 
						if([elementName isEqualToString:@"propertyName"])
						{
							if(contentOfString)
							{
								[controlpropertylist addObject:contentOfString];
								[contentOfString release];
								contentOfString = nil;
								
								
							}		
							
						}
	
	
						else 
							if([elementName isEqualToString:@"propertyValue"])
							{
								if(contentOfString)
								{
									[controlpropertylist addObject:contentOfString];
									[contentOfString release];
									contentOfString = nil;
									
									
								}		
								
							}
							else 
								if([elementName isEqualToString:@"propertyValueImage"])
								{
									if(contentOfString)
									{
										[controlpropertylist addObject:contentOfString];
										[contentOfString release];
										contentOfString = nil;
										
										
									}		
									
								}
	//====================================================================================================
								else 
									if([elementName isEqualToString:@"customMessageList"])
									{
										[[NSUserDefaults standardUserDefaults] setObject:(NSDictionary*)dict_custommessage forKey:@"customMessageList"];
										[[NSUserDefaults standardUserDefaults] synchronize];
									}
									else 
										if([elementName isEqualToString:@"customMessages"])
										{
											NSLog(@"%@",[customtext description]);
											[dict_custommessage setObject:customtext forKey:[customtext valueForKey:@"code"]];
											
										}
										else 
											if([elementName isEqualToString:@"code"])
											{
												if(contentOfString)
												{
													[customtext setValue:contentOfString forKey:@"code"];
													[contentOfString release];
													contentOfString = nil;
													
													
												}		
											}
											else 
												if([elementName isEqualToString:@"message"])
												{
													if(contentOfString)
													{
														[customtext setValue:contentOfString forKey:@"message"];
														[customtext setValue:@"Error" forKey:@"type"];
														[contentOfString release];
														contentOfString = nil;
														
														
													}		
												}
												else 
													if([elementName isEqualToString:@"messageArea"])
													{
														if(contentOfString)
														{
															[customtext setValue:contentOfString forKey:@"messageArea"];
															[contentOfString release];
															contentOfString = nil;
															
															
														}		
													}
													else 
														if([elementName isEqualToString:@"updatedOn"])
														{
															if(contentOfString)
															{
																[customtext setValue:contentOfString forKey:@"updatedOn"];
																[contentOfString release];
																contentOfString = nil;
																
																
															}		
														}
	
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
	if(contentOfString)
		[contentOfString appendString:string];
}

- (void)parserDidEndDocument:(NSXMLParser *)parse
{
	
	NSDictionary *customMessageList_dict=[[NSUserDefaults standardUserDefaults] objectForKey:@"customMessageList"];
	NSLog(@"**********%@",[customMessageList_dict description]);
	//=======================================================
	NSLog(@"**********%@",controls);
	con=[[configurables alloc]init];
	
	config=[[NSMutableArray alloc]init];
	
	for (int i=0; i<[controls count];i++)
	{	
		gotfont=NO;
		if ([[[controls objectAtIndex:i] objectAtIndex:0] isEqualToString:@"Button-Navigation"] )
		{			
			property=[[NSMutableArray alloc]init];
			for (int j=0; j<[[[controls objectAtIndex:i] objectAtIndex:1] count];j++)
			{
				if ([[[[[controls objectAtIndex:i] objectAtIndex:1]objectAtIndex:j]objectAtIndex:0] isEqualToString:@"image"] )
				{
					con.btnNavImgData=[[[[controls objectAtIndex:i] objectAtIndex:1]objectAtIndex:j]objectAtIndex:2];
				}
				else if ([[[[[controls objectAtIndex:i] objectAtIndex:1]objectAtIndex:j]objectAtIndex:0] isEqualToString:@"font"] && !gotfont)
				{
					gotfont=YES;
					con.btnNavFontName=[[[[controls objectAtIndex:i] objectAtIndex:1]objectAtIndex:j]objectAtIndex:1];
				}
				else if ([[[[[controls objectAtIndex:i] objectAtIndex:1]objectAtIndex:j]objectAtIndex:0] isEqualToString:@"size"] )
				{
					con.btnNavFontSize=[[[[[controls objectAtIndex:i] objectAtIndex:1]objectAtIndex:j]objectAtIndex:1] intValue];
				}
			}
			
		}	
		
		if ([[[controls objectAtIndex:i] objectAtIndex:0] isEqualToString:@"Button-General"] )
		{			
			property=[[NSMutableArray alloc]init];
			for (int j=0; j<[[[controls objectAtIndex:i] objectAtIndex:1] count];j++)
			{
				if ([[[[[controls objectAtIndex:i] objectAtIndex:1]objectAtIndex:j]objectAtIndex:0] isEqualToString:@"image"] )
				{
					con.btnImgdata=[[[[controls objectAtIndex:i] objectAtIndex:1]objectAtIndex:j]objectAtIndex:2];
				}
				else if ([[[[[controls objectAtIndex:i] objectAtIndex:1]objectAtIndex:j]objectAtIndex:0] isEqualToString:@"font"] && !gotfont)
				{
					gotfont=YES;
					con.btnfontname=[[[[controls objectAtIndex:i] objectAtIndex:1]objectAtIndex:j]objectAtIndex:1];
				}
				else if ([[[[[controls objectAtIndex:i] objectAtIndex:1]objectAtIndex:j]objectAtIndex:0] isEqualToString:@"size"] )
				{
					con.btnfontsize=[[[[[controls objectAtIndex:i] objectAtIndex:1]objectAtIndex:j]objectAtIndex:1] intValue];
				}
			}
			
		}	
		
		
		else if ([[[controls objectAtIndex:i] objectAtIndex:0] isEqualToString:@"Logo"] )
		{			
			property=[[NSMutableArray alloc]init];
			for (int j=0; j<[[[controls objectAtIndex:i] objectAtIndex:1] count];j++)
			{
				if ([[[[[controls objectAtIndex:i] objectAtIndex:1]objectAtIndex:j]objectAtIndex:0] isEqualToString:@"image"] )
				{
					;
				}
				
			}	
		}
		
		else if ([[[controls objectAtIndex:i] objectAtIndex:0] isEqualToString:@"Background"] )
		{			
			property=[[NSMutableArray alloc]init];
			for (int j=0; j<[[[controls objectAtIndex:i] objectAtIndex:1] count];j++)
			{
				if ([[[[[controls objectAtIndex:i] objectAtIndex:1]objectAtIndex:j]objectAtIndex:0] isEqualToString:@"color"] )
				{
					NSArray *arrRGB=[[[[[controls objectAtIndex:i] objectAtIndex:1]objectAtIndex:j]objectAtIndex:1] componentsSeparatedByString:@","];
					con.bgRed=[[arrRGB objectAtIndex:0] floatValue];
					con.bgGreen=[[arrRGB objectAtIndex:1]floatValue];
					con.bgBlue=[[arrRGB objectAtIndex:2]floatValue];
					
				}
				
			}	
		}
		else if ([[[controls objectAtIndex:i] objectAtIndex:0] isEqualToString:@"Link-Important"] )
		{			
			property=[[NSMutableArray alloc]init];
			for (int j=0; j<[[[controls objectAtIndex:i] objectAtIndex:1] count];j++)
			{
				if ([[[[[controls objectAtIndex:i] objectAtIndex:1]objectAtIndex:j]objectAtIndex:0] isEqualToString:@"color"] )
				{
					
				}
				
			}	
		}
		else if ([[[controls objectAtIndex:i] objectAtIndex:0] isEqualToString:@"Number-Negative"] )
		{			
			property=[[NSMutableArray alloc]init];
			for (int j=0; j<[[[controls objectAtIndex:i] objectAtIndex:1] count];j++)
			{
				if ([[[[[controls objectAtIndex:i] objectAtIndex:1]objectAtIndex:j]objectAtIndex:0] isEqualToString:@"color"] )
				{
					NSArray *arrRGB=[[[[[controls objectAtIndex:i] objectAtIndex:1]objectAtIndex:j]objectAtIndex:1] componentsSeparatedByString:@","];
					con.ngtvRed=[[arrRGB objectAtIndex:0] floatValue];
					con.ngtvGreen=[[arrRGB objectAtIndex:1]floatValue];
					con.ngtvBlue=[[arrRGB objectAtIndex:2]floatValue];
					
				}
			}
			for (int j=0; j<[[[controls objectAtIndex:i] objectAtIndex:1] count];j++)
			{
				if ([[[[[controls objectAtIndex:i] objectAtIndex:1]objectAtIndex:j]objectAtIndex:0] isEqualToString:@"prefix"] )
				{
					con.ngtvPrefix=[[[[controls objectAtIndex:i] objectAtIndex:1]objectAtIndex:j]objectAtIndex:1];
					
				}
				
			}	
			for (int j=0; j<[[[controls objectAtIndex:i] objectAtIndex:1] count];j++)
			{
				if ([[[[[controls objectAtIndex:i] objectAtIndex:1]objectAtIndex:j]objectAtIndex:0] isEqualToString:@"suffix"] )
				{
					con.ngtvSufix=[[[[controls objectAtIndex:i] objectAtIndex:1]objectAtIndex:j]objectAtIndex:1];
				}
				
			}	
		}
		else if ([[[controls objectAtIndex:i] objectAtIndex:0] isEqualToString:@"Number-General"] )
		{			
			property=[[NSMutableArray alloc]init];
			for (int j=0; j<[[[controls objectAtIndex:i] objectAtIndex:1] count];j++)
			{
				if ([[[[[controls objectAtIndex:i] objectAtIndex:1]objectAtIndex:j]objectAtIndex:0] isEqualToString:@"color"] )
				{
					NSArray *arrRGB=[[[[[controls objectAtIndex:i] objectAtIndex:1]objectAtIndex:j]objectAtIndex:1] componentsSeparatedByString:@","];
					con.posnumRed=[[arrRGB objectAtIndex:0] floatValue];
					con.posnumGreen=[[arrRGB objectAtIndex:1]floatValue];
					con.posnumBlue=[[arrRGB objectAtIndex:2]floatValue];
					
				}
				
			}
			for (int j=0; j<[[[controls objectAtIndex:i] objectAtIndex:1] count];j++)
			{
				if ([[[[[controls objectAtIndex:i] objectAtIndex:1]objectAtIndex:j]objectAtIndex:0] isEqualToString:@"prefix"] )
				{
					con.ptvPrefix=[[[[controls objectAtIndex:i] objectAtIndex:1]objectAtIndex:j]objectAtIndex:1];
					
				}
				
			}	
		}
		if ([[[controls objectAtIndex:i] objectAtIndex:0] isEqualToString:@"Text"] )
		{			
			property=[[NSMutableArray alloc]init];
			for (int j=0; j<[[[controls objectAtIndex:i] objectAtIndex:1] count];j++)
			{
				if ([[[[[controls objectAtIndex:i] objectAtIndex:1]objectAtIndex:j]objectAtIndex:0] isEqualToString:@"color"] )
				{
					NSArray *arrRGB=[[[[[controls objectAtIndex:i] objectAtIndex:1]objectAtIndex:j]objectAtIndex:1] componentsSeparatedByString:@","];
					con.txtRed=[[arrRGB objectAtIndex:0] floatValue];
					con.txtGreen=[[arrRGB objectAtIndex:1]floatValue];
					con.txtBlue=[[arrRGB objectAtIndex:2]floatValue];
					
					
					
				}
				else if ([[[[[controls objectAtIndex:i] objectAtIndex:1]objectAtIndex:j]objectAtIndex:0] isEqualToString:@"font"] && !gotfont)
				{
					gotfont=YES;
					con.fontname=[[[[controls objectAtIndex:i] objectAtIndex:1]objectAtIndex:j]objectAtIndex:1];
				}
				else if ([[[[[controls objectAtIndex:i] objectAtIndex:1]objectAtIndex:j]objectAtIndex:0] isEqualToString:@"size"] )
				{
					con.fontsize=[[[[[controls objectAtIndex:i] objectAtIndex:1]objectAtIndex:j]objectAtIndex:1] intValue];
				}
			}
		}	
		else if ([[[controls objectAtIndex:i] objectAtIndex:0] isEqualToString:@"Link-General"] )
		{			
			property=[[NSMutableArray alloc]init];
			for (int j=0; j<[[[controls objectAtIndex:i] objectAtIndex:1] count];j++)
			{
				if ([[[[[controls objectAtIndex:i] objectAtIndex:1]objectAtIndex:j]objectAtIndex:0] isEqualToString:@"color"] )
				{
					NSArray *arrRGB1=[[[[[controls objectAtIndex:i] objectAtIndex:1]objectAtIndex:j]objectAtIndex:1] componentsSeparatedByString:@","];
					con.linkgnRed=[[arrRGB1 objectAtIndex:0] floatValue];
					con.linkgnGreen=[[arrRGB1 objectAtIndex:1]floatValue];
					con.linkgnBlue=[[arrRGB1 objectAtIndex:2]floatValue];
					
				}
				
			}	
		}
		
		else if ([[[controls objectAtIndex:i] objectAtIndex:0] isEqualToString:@"Link-Important"] )
		{			
			property=[[NSMutableArray alloc]init];
			for (int j=0; j<[[[controls objectAtIndex:i] objectAtIndex:1] count];j++)
			{
				if ([[[[[controls objectAtIndex:i] objectAtIndex:1]objectAtIndex:j]objectAtIndex:0] isEqualToString:@"color"] )
				{
					NSArray *arrRGB1=[[[[[controls objectAtIndex:i] objectAtIndex:1]objectAtIndex:j]objectAtIndex:1] componentsSeparatedByString:@","];
					con.linkimpRed=[[arrRGB1 objectAtIndex:0] floatValue];
					con.linkimpGreen=[[arrRGB1 objectAtIndex:1]floatValue];
					con.linkimpBlue=[[arrRGB1 objectAtIndex:2]floatValue];
					
					
					
				}
				
			}	
		}
		
		else if ([[[controls objectAtIndex:i] objectAtIndex:0] isEqualToString:@"Header-Grid"] )
		{			
			property=[[NSMutableArray alloc]init];
			for (int j=0; j<[[[controls objectAtIndex:i] objectAtIndex:1] count];j++)
			{
				if ([[[[[controls objectAtIndex:i] objectAtIndex:1]objectAtIndex:j]objectAtIndex:0] isEqualToString:@"color"] )
				{
					NSArray *arrRGB1=[[[[[controls objectAtIndex:i] objectAtIndex:1]objectAtIndex:j]objectAtIndex:1] componentsSeparatedByString:@","];
					con.bgRed2=[[arrRGB1 objectAtIndex:0] floatValue];
					con.bgGreen2=[[arrRGB1 objectAtIndex:1]floatValue];
					con.bgBlue2=[[arrRGB1 objectAtIndex:2]floatValue];
					
					
					
				}
				
			}	
		}
		else if ([[[controls objectAtIndex:i] objectAtIndex:0] isEqualToString:@"Logo"] )
		{			
			property=[[NSMutableArray alloc]init];
			for (int j=0; j<[[[controls objectAtIndex:i] objectAtIndex:1] count];j++)
			{
				if ([[[[[controls objectAtIndex:i] objectAtIndex:1]objectAtIndex:j]objectAtIndex:0] isEqualToString:@"image"] )
				{
					con.logoImgdata=[[[[controls objectAtIndex:i] objectAtIndex:1]objectAtIndex:j]objectAtIndex:2];
						
				}
				
			}	
		}
		
		
	}
	[config addObject:con];
	
	
	configurables *con1=(configurables *)[config objectAtIndex:0];
	NSLog(@"linkimpBlue%f",con1.linkimpBlue);
	NSLog(@"linkimpGreen%f",con1.linkimpGreen);
	NSLog(@"linkimpRed%f",con1.linkimpRed);
	NSLog(@"%d",con1.bgGreen);
	NSLog(@"%@",con1.btnImgdata);
	NSLog(@"\n\n\n  logo data   %@",con1.logoImgdata);
	
	
	
	
}	
	
+(NSMutableArray *)getconfig_arr
{
	if (config) {
		
		return config;
	}
	else {
		return nil;
	}
	
}


@end
