//
//  Claimonlineserviceparser.h
//  Acclaris
//
//  Created by Subhojit on 31/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ClaimonlineSaveOBJ.h"
#import "MultipleAccountOBJ.h"



@interface Claimonlineserviceparser : NSObject<NSXMLParserDelegate> {

	ClaimonlineSaveOBJ *objclaimonlinesave;
	MultipleAccountOBJ *objmultipleAcc;
	NSMutableString *contentOfString;
	
}
+(NSMutableArray *)getarrClaimonlinesave;
+(NSMutableArray *)getarrMultipleAccdata;
-(void)parseXMLFileAtData:(NSMutableData *)data parseError:(NSError **)error;
@end
