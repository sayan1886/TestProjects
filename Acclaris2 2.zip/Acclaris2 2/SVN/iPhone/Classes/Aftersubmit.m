    //
//  Aftersubmit.m
//  Acclaris
//
//  Created by Subhojit on 12/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Aftersubmit.h"
#import "configurables.h"
#import "AcclarisViewController.h"


@implementation Aftersubmit


- (void)viewDidLoad {
    [super viewDidLoad];
	
	
	self.navigationItem.hidesBackButton=YES;
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	tools=[[MyTools alloc]init];
	loadingView=[tools createActivityIndicator1];
	
	NSMutableArray *arr_myconfig=[AcclarisViewController staticarr_config];
	con=(configurables *)[arr_myconfig objectAtIndex:0];
	
	self.navigationController.navigationBar.tintColor=[UIColor colorWithRed:con.navbarRed/255.0f green:con.navbarGreen/255.0f blue:con.navbarBlue/255.0f alpha:1.0];
	
	self.view.backgroundColor = [UIColor colorWithRed:con.bgRed/255.0f green:con.bgGreen/255.0f blue:con.bgBlue/255.0f alpha:1.0];
	UIImageView *logo_img = [[UIImageView alloc]initWithFrame:CGRectMake(0, 2, 170, 40)];
	NSData *data=[Base64 decode:con.logoImgdata];
	logo_img.image=	[UIImage imageWithData:[NSData dataWithData:data]];
	self.navigationItem.titleView=logo_img;
	
	
	
	
	UIBarButtonItem *signoutButton = [[UIBarButtonItem alloc]
									  initWithTitle:@"Sign Off"
									  style:UIBarButtonItemStyleBordered
									  target:self
									  action:@selector(signout)];
    self.navigationItem.rightBarButtonItem =signoutButton;
	
	
	arrdeny=[SubmitclaimParser getarrdenydetail];
	arrreptrequd=[SubmitclaimParser getarrReceiptrequired];
	arrpendingpayclaim=[SubmitclaimParser getarrpendingclaim];
	
	strclaimid=[SubmitclaimParser getstrtrxnID];
	[strclaimid retain];
	
	roleDict=[passPerser getRolebaseDict];

	[self CreateView];
	
}
-(void)CreateView
{
	
	NSData *data_btnimg=[Base64 decode:con.btnImgdata];
	
	table=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, 320, 300) style:UITableViewStylePlain];
	table.backgroundColor = [UIColor whiteColor];
	table.bounces = YES;
	table.delegate=self;
	table.dataSource=self;
	table.separatorColor=[UIColor blackColor];
	[self.view addSubview:table];
	
	
	UIButton *btnBackclaim=[UIButton buttonWithType:UIButtonTypeCustom];
	btnBackclaim.frame=CGRectMake(90, 315, 140, 40);
	[btnBackclaim setBackgroundImage:[UIImage imageWithData:[NSData dataWithData:data_btnimg]] forState:UIControlStateNormal];
	[btnBackclaim setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	btnBackclaim.titleLabel.font = [UIFont fontWithName:con.btnfontname size:con.btnfontsize];
	[btnBackclaim setTitle:@"Back to claims" forState:UIControlStateNormal];
	[btnBackclaim addTarget:self action:@selector(ClickbtnBackclaim) forControlEvents:UIControlEventTouchUpInside];					 
	[self.view addSubview:btnBackclaim];
	
	
	
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
	
	if(section==0)
	     return 35.0;
	
	else 
		return 50.0;
	

	
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
	
	
	NSString *Headerfont=@"";
	Headerfont=[Headerfont stringByAppendingString:con.fontname];
	Headerfont=[Headerfont stringByAppendingString:@"-Bold"];
	
	UIView *sectionView=[[UIView alloc]initWithFrame:CGRectMake(0,0, 320, 50)];
	sectionView.backgroundColor=[UIColor colorWithRed:con.bgRed2/255.0 green:con.bgGreen2/255.0 blue:con.bgBlue2/255.0 alpha:1.0];

	if(section==0)
		
	    {
		
				
			NSString *strViewTitle=@"Claim";

			UILabel *lbltext=[[UILabel alloc]initWithFrame:CGRectMake(10,0, 210, 35)];
			lbltext.text=strViewTitle;
			lbltext.backgroundColor=[UIColor clearColor];
			lbltext.textColor=[UIColor whiteColor];
			lbltext.font=[UIFont fontWithName:Headerfont size:con.headerImpfntsize];
			[sectionView addSubview:lbltext];
			[lbltext release],lbltext=nil;
			
			
	    }
	else if(section==1)
		
	   {
		
			   
		   NSString *strViewTitle=@"Submitted and need a";
		   strViewTitle=[strViewTitle stringByAppendingString:@"\n"];
		   strViewTitle=[strViewTitle stringByAppendingFormat:@"%@",@"receipt"];
		   		   
		   UILabel *lbltext=[[UILabel alloc]initWithFrame:CGRectMake(10,-3, 230, 50)];
		   lbltext.text=strViewTitle;
		   lbltext.backgroundColor=[UIColor clearColor];
		   lbltext.textColor=[UIColor whiteColor];
		   lbltext.numberOfLines=0;
		   lbltext.font=[UIFont fontWithName:Headerfont size:con.headerImpfntsize];
		   [sectionView addSubview:lbltext];
		   [lbltext release],lbltext=nil;
			   
		   
		
		
	   }
	
	else if(section==2)
		
	  {
		
		
		  NSString *strViewTitle=@"Approved and pending";
		  strViewTitle=[strViewTitle stringByAppendingString:@"\n"];
		  strViewTitle=[strViewTitle stringByAppendingFormat:@"%@",@"Payment"];
		  
		  UILabel *lbltext=[[UILabel alloc]initWithFrame:CGRectMake(10,-3, 230, 50)];
		  lbltext.text=strViewTitle;
		  lbltext.backgroundColor=[UIColor clearColor];
		  lbltext.textColor=[UIColor whiteColor];
		  lbltext.numberOfLines=0;
		  lbltext.font=[UIFont fontWithName:Headerfont size:con.headerImpfntsize];
		  [sectionView addSubview:lbltext];
		  [lbltext release],lbltext=nil;
			
		
		
	  }
	
	else if(section ==3)
		
	 {
		 

			 NSString *strViewTitle=@"Submitted and";
			 strViewTitle=[strViewTitle stringByAppendingString:@"\n"];
			 strViewTitle=[strViewTitle stringByAppendingFormat:@"%@",@"denied"];
			 
			 UILabel *lbltext=[[UILabel alloc]initWithFrame:CGRectMake(10,-3, 205, 50)];
			 lbltext.text=strViewTitle;
			 lbltext.backgroundColor=[UIColor clearColor];
			 lbltext.textColor=[UIColor whiteColor];
			 lbltext.numberOfLines=0;
			 lbltext.font=[UIFont fontWithName:Headerfont size:con.headerImpfntsize];
			 [sectionView addSubview:lbltext];
			 [lbltext release],lbltext=nil;
			
		
		
	  }

	return sectionView;
	
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView  
{
	
	return 4;
	
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	
	if(section==0)
		
		  return 1;
	
	else if(section==1)
		
		{
		  if([arrreptrequd count]==0)
		  {
			 
			  issinglerowreceipt=YES;
			  
				  return 1;
		  }
			else 
			  
		       return [arrreptrequd count];
		}
	
		else if(section==2)
		{
		
			if([arrpendingpayclaim count]==0)

			{
				issinglerowpending=YES;
				return 1;
			}
			else 
				
				return [arrpendingpayclaim count];
		}
	
	else if(section==3)
	{
		
				if([arrdeny count]==0)
				{
					 issinglerowdeny=YES;
					return 1;
				}
	         else 
		      return [arrdeny count];
	   
     }
	else 
	{
		return 0;
	}

	
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{  
	static NSString *CellIdentifier = @"Cell";
	static NSString *CellIdentifier1 = @"Cell1";
	UITableViewCell *cell;
	
	if(cell==nil)
	{
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier] autorelease];
	}
	else
	{
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier1];
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier1] autorelease];
		
	}
	
	
		
	cell.selectionStyle=UITableViewCellSelectionStyleNone;
	cell.backgroundColor=[UIColor whiteColor];
	
	strFont=[con.fontname stringByAppendingFormat:@"%@",@"-Bold"];

	
				if(indexPath.section==0)
					
				{
							
					UILabel *cellLabelclaim=[[UILabel alloc]initWithFrame:CGRectMake(10,0,300,60)];
					cellLabelclaim.font=[UIFont fontWithName:strFont size:con.bodyfntsize];
					cellLabelclaim.textColor =[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
					cellLabelclaim.backgroundColor=[UIColor clearColor];
					cellLabelclaim.text = @"Your claim entry was successful.The Transaction# for the claim(s) entered is";
					cellLabelclaim.text=[cellLabelclaim.text stringByAppendingFormat:@" %@",strclaimid];
					cellLabelclaim.numberOfLines=0;
					[cell.contentView addSubview:cellLabelclaim];
					[cellLabelclaim release],cellLabelclaim=nil; 
					
					
				}
				
				else if(indexPath.section==1)
					
				{
				
					if(issinglerowreceipt==YES)
						
						  {  
							  
								UILabel *cellLabelData=[[UILabel alloc]initWithFrame:CGRectMake(95,2,130,45)];
								cellLabelData.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
								cellLabelData.textColor =[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
								cellLabelData.backgroundColor=[UIColor clearColor];
								cellLabelData.textAlignment=UITextAlignmentCenter;
								cellLabelData.text = @"No Data";
								[cell.contentView addSubview:cellLabelData];
							
						
				         }
					else 
						
					{
						
						if(indexPath.section==1 && [[roleDict valueForKey:@"IMAGE_UPLOAD"]isEqualToString:@"Yes"])
							
						     {

					               cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
							 }
						else 
						{
							;	
						}

					
					UILabel *cellLabelDate=[[UILabel alloc]initWithFrame:CGRectMake(10,2,130,45)];
					cellLabelDate.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
					cellLabelDate.textColor =[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
					cellLabelDate.backgroundColor=[UIColor clearColor];
					cellLabelDate.text = @"Service";
					cellLabelDate.text=[cellLabelDate.text  stringByAppendingString:@"\n"];
				    cellLabelDate.text=[cellLabelDate.text  stringByAppendingFormat:@"%@",@"Date"];

					cellLabelDate.numberOfLines=0;
					[cell.contentView addSubview:cellLabelDate];
					[cellLabelDate release],cellLabelDate=nil; 
					
					
					
					UILabel *cellserviceDate=[[UILabel alloc]initWithFrame:CGRectMake(105,2,100,30)];
					cellserviceDate.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
					cellserviceDate.textColor =[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
					cellserviceDate.backgroundColor=[UIColor clearColor];
					cellserviceDate.text =((SubmitclaimOBJ *)[arrreptrequd objectAtIndex:indexPath.row]).strserviceBegins;
					[cell.contentView addSubview:cellserviceDate];
					[cellserviceDate release],cellserviceDate=nil; 
					
					
					
					UILabel *cellAmount=[[UILabel alloc]initWithFrame:CGRectMake(180,2,100,30)];
					cellAmount.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
					cellAmount.textColor =[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
					cellAmount.backgroundColor=[UIColor clearColor];
					cellAmount.text =@"Amount";
					[cell.contentView addSubview:cellAmount];
					[cellAmount release],cellAmount=nil; 
					
					
					UILabel *cellAmountvalue=[[UILabel alloc]initWithFrame:CGRectMake(260,2,100,30)];
					cellAmountvalue.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
					cellAmountvalue.textColor =[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
					cellAmountvalue.backgroundColor=[UIColor clearColor];
					 NSString *str=[self chkvalue:((SubmitclaimOBJ *)[arrreptrequd objectAtIndex:indexPath.row]).strclmAmount];
					cellAmountvalue.text =str;
					[cell.contentView addSubview:cellAmountvalue];
					[cellAmountvalue release],cellAmountvalue=nil; 
						
						
						UILabel *cellAcctype=[[UILabel alloc]initWithFrame:CGRectMake(10,40,130,45)];
						cellAcctype.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
						cellAcctype.textColor =[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
						cellAcctype.backgroundColor=[UIColor clearColor];
						cellAcctype.text = @"Account\nType";
						cellAcctype.numberOfLines=0;
						[cell.contentView addSubview:cellAcctype];
						[cellAcctype release],cellAcctype=nil; 
						
						
						UILabel *cellAcctypevalue=[[UILabel alloc]initWithFrame:CGRectMake(105,40,100,30)];
						cellAcctypevalue.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
						cellAcctypevalue.textColor =[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
						cellAcctypevalue.backgroundColor=[UIColor clearColor];
						cellAcctypevalue.text =((SubmitclaimOBJ *)[arrreptrequd objectAtIndex:indexPath.row]).stractpCD;
						[cell.contentView addSubview:cellAcctypevalue];
						[cellAcctypevalue release],cellAcctypevalue=nil; 
						
					}
					
				}
	
	          else if(indexPath.section==2)
			  {
			
				  if(issinglerowpending==YES)
				    {
					  
						UILabel *cellLabelData=[[UILabel alloc]initWithFrame:CGRectMake(95,2,130,45)];
						cellLabelData.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
						cellLabelData.textColor =[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
						cellLabelData.backgroundColor=[UIColor clearColor];
						cellLabelData.textAlignment=UITextAlignmentCenter;
						cellLabelData.text = @"No Data";
						[cell.contentView addSubview:cellLabelData];
						
						
				    }
				  else {
					  
				 

				  UILabel *cellLabelDate=[[UILabel alloc]initWithFrame:CGRectMake(10,2,130,45)];
				  cellLabelDate.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
				  cellLabelDate.textColor =[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
				  cellLabelDate.backgroundColor=[UIColor clearColor];
				  cellLabelDate.text = @"Service";
				  cellLabelDate.text=[cellLabelDate.text  stringByAppendingString:@"\n"];
				  cellLabelDate.text=[cellLabelDate.text  stringByAppendingFormat:@"%@",@"Date"];
				  
				  cellLabelDate.numberOfLines=0;
				  [cell.contentView addSubview:cellLabelDate];
				  [cellLabelDate release],cellLabelDate=nil; 
				  
				  
				  
				  UILabel *cellserviceDate=[[UILabel alloc]initWithFrame:CGRectMake(105,2,100,30)];
				  cellserviceDate.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
				  cellserviceDate.textColor =[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
				  cellserviceDate.backgroundColor=[UIColor clearColor];
				  cellserviceDate.text =((SubmitclaimOBJ *)[arrpendingpayclaim objectAtIndex:indexPath.row]).strserviceBegins;
				  [cell.contentView addSubview:cellserviceDate];
				  [cellserviceDate release],cellserviceDate=nil; 
				  
				  
				  
				  UILabel *cellAmount=[[UILabel alloc]initWithFrame:CGRectMake(180,2,100,30)];
				  cellAmount.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
				  cellAmount.textColor =[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
				  cellAmount.backgroundColor=[UIColor clearColor];
				  cellAmount.text =@"Amount";
				  [cell.contentView addSubview:cellAmount];
				  [cellAmount release],cellAmount=nil; 
				  
				  
				  UILabel *cellAmountvalue=[[UILabel alloc]initWithFrame:CGRectMake(260,2,100,30)];
				  cellAmountvalue.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
				  cellAmountvalue.textColor =[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
				  cellAmountvalue.backgroundColor=[UIColor clearColor];
				  NSString *str=[self chkvalue:((SubmitclaimOBJ *)[arrpendingpayclaim objectAtIndex:indexPath.row]).strclmAmount];
				  cellAmountvalue.text =str;
				  [cell.contentView addSubview:cellAmountvalue];
				  [cellAmountvalue release],cellAmountvalue=nil; 
					  
					  UILabel *cellAcctype=[[UILabel alloc]initWithFrame:CGRectMake(10,40,130,45)];
					  cellAcctype.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
					  cellAcctype.textColor =[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
					  cellAcctype.backgroundColor=[UIColor clearColor];
					  cellAcctype.text = @"Account\nType";
					  cellAcctype.numberOfLines=0;
					  [cell.contentView addSubview:cellAcctype];
					  [cellAcctype release],cellAcctype=nil; 
					  
					  
					  UILabel *cellAcctypevalue=[[UILabel alloc]initWithFrame:CGRectMake(105,40,100,30)];
					  cellAcctypevalue.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
					  cellAcctypevalue.textColor =[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
					  cellAcctypevalue.backgroundColor=[UIColor clearColor];
					  cellAcctypevalue.text =((SubmitclaimOBJ *)[arrpendingpayclaim objectAtIndex:indexPath.row]).stractpCD;
					  [cell.contentView addSubview:cellAcctypevalue];
					  [cellAcctypevalue release],cellAcctypevalue=nil; 
					  
					  
				  }
				  
				  
			  }
	
	         else 
				 
			  {
				  
				  if(issinglerowdeny==YES)
				  {
					  
					  UILabel *cellLabelData=[[UILabel alloc]initWithFrame:CGRectMake(95,2,130,45)];
					  cellLabelData.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
					  cellLabelData.textColor =[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
					  cellLabelData.backgroundColor=[UIColor clearColor];
					  cellLabelData.textAlignment=UITextAlignmentCenter;
					  cellLabelData.text = @"No Data";
					  [cell.contentView addSubview:cellLabelData];
					  
					  
				  }
				  else 
				  {
					  
					  
				  cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
				  
				  UILabel *cellLabelDate=[[UILabel alloc]initWithFrame:CGRectMake(10,2,130,45)];
				  cellLabelDate.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
				  cellLabelDate.textColor =[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
				  cellLabelDate.backgroundColor=[UIColor clearColor];
				  cellLabelDate.text = @"Service";
				  cellLabelDate.text=[cellLabelDate.text  stringByAppendingString:@"\n"];
				  cellLabelDate.text=[cellLabelDate.text  stringByAppendingFormat:@"%@",@"Date"];
				  
				  cellLabelDate.numberOfLines=0;
				  [cell.contentView addSubview:cellLabelDate];
				  [cellLabelDate release],cellLabelDate=nil; 
				  
				  
				  
				  UILabel *cellserviceDate=[[UILabel alloc]initWithFrame:CGRectMake(105,2,100,30)];
				  cellserviceDate.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
				  cellserviceDate.textColor =[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
				  cellserviceDate.backgroundColor=[UIColor clearColor];
				  cellserviceDate.text =((SubmitclaimOBJ *)[arrdeny objectAtIndex:indexPath.row]).strserviceBegins;
				  [cell.contentView addSubview:cellserviceDate];
				  [cellserviceDate release],cellserviceDate=nil; 
				  
				
				  
				  UILabel *cellAmount=[[UILabel alloc]initWithFrame:CGRectMake(180,2,100,30)];
				  cellAmount.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
				  cellAmount.textColor =[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
				  cellAmount.backgroundColor=[UIColor clearColor];
				  cellAmount.text =@"Amount";
				  [cell.contentView addSubview:cellAmount];
				  [cellAmount release],cellAmount=nil; 
				  
				  
				  UILabel *cellAmountvalue=[[UILabel alloc]initWithFrame:CGRectMake(260,2,100,30)];
				  cellAmountvalue.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
				  cellAmountvalue.textColor =[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
				  cellAmountvalue.backgroundColor=[UIColor clearColor];
				  
				  NSString *str=[self chkvalue:((SubmitclaimOBJ *)[arrdeny objectAtIndex:indexPath.row]).strclmAmount];
				  cellAmountvalue.text =str;
				  [cell.contentView addSubview:cellAmountvalue];
				  [cellAmountvalue release],cellAmountvalue=nil; 
					  
					  
					  UILabel *cellAcctype=[[UILabel alloc]initWithFrame:CGRectMake(10,40,130,45)];
					  cellAcctype.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
					  cellAcctype.textColor =[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
					  cellAcctype.backgroundColor=[UIColor clearColor];
					  cellAcctype.text = @"Account\nType";
					  cellAcctype.numberOfLines=0;
					  [cell.contentView addSubview:cellAcctype];
					  [cellAcctype release],cellAcctype=nil; 
					  
					  
					  UILabel *cellAcctypevalue=[[UILabel alloc]initWithFrame:CGRectMake(105,40,100,30)];
					  cellAcctypevalue.font=[UIFont fontWithName:strFont size:con.bodyImpfntsize];
					  cellAcctypevalue.textColor =[UIColor colorWithRed:con.txtRed/255.0f green:con.txtGreen/255.0f blue:con.txtBlue/255.0f alpha:1.0];
					  cellAcctypevalue.backgroundColor=[UIColor clearColor];
					  cellAcctypevalue.text =((SubmitclaimOBJ *)[arrdeny objectAtIndex:indexPath.row]).stractpCD;
					  [cell.contentView addSubview:cellAcctypevalue];
					  [cellAcctypevalue release],cellAcctypevalue=nil; 
					  
					  
				  }
				  
		
			  }

				
	return cell;
	
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	if(indexPath.section==0 && indexPath.row==0)
	{
	
		
		return 65.0;
	}
	else 
	{
		return 95.0;
	}

	
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
   
	
	
	if(indexPath.section==1 && [[roleDict valueForKey:@"IMAGE_UPLOAD"]isEqualToString:@"Yes"])
	{
		AddImage *obj=[[AddImage alloc]initWithindex:indexPath.row];
		[self.navigationController pushViewController:obj animated:YES];
	}
	
	else if(indexPath.section==3)
	{
		NSString *strReasontext=((SubmitclaimOBJ *)[arrdeny objectAtIndex:indexPath.row]).strtext;
		DenialreasonList *obj=[[DenialreasonList alloc]initWithtext:strReasontext];
		[self.navigationController pushViewController:obj animated:YES];
		
	}
	else 
	{
		;
	}


	
}
-(void)ClickbtnBackclaim
{
	
	
	[self.navigationController popToRootViewControllerAnimated:YES];
	
}
	
-(void)signout
{
	[((AcclarisAppDelegate *)[[UIApplication sharedApplication] delegate]) removeTabBar];
}
-(NSString *)chkvalue:(NSString *)value
{
	NSString *newvalue=@"";
	if([value intValue]>=0)
	{
		newvalue=[newvalue stringByAppendingString:con.ptvPrefix];
		newvalue=[newvalue stringByAppendingString:value];
	}
	else {
		value=[value substringFromIndex:1];
		newvalue=[newvalue stringByAppendingString:con.ngtvPrefix];
		newvalue=[newvalue stringByAppendingString:value];
		newvalue=[newvalue stringByAppendingString:con.ngtvSufix];
		
	}
	return newvalue;
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
