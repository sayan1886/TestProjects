//
//  AccountsOBJ.m
//  Acclaris
//
//  Created by Sayan banerjee on 19/11/10.
//  Copyright 2010 Objectsol. All rights reserved.
//

#import "AccountsOBJ.h"


@implementation AccountsOBJ;
@synthesize accountTypeCode;
@synthesize accountDisplaySeq;
@synthesize accountShortName;
@synthesize accountDisplayName;
@synthesize balanceRelevant;
@synthesize investmentRelevant;
@synthesize enrollmentStatus;
@synthesize electionListCount;
@synthesize planPeriodType;
@synthesize manageContribLink,lblmanageContribLink;
@synthesize elections;

-(void)dealloc{
	elections=nil;
	[super dealloc];
}
- (id)init{
	elections=nil;//[[[NSMutableArray alloc]init]autorelease];
	return self;
}

@end
