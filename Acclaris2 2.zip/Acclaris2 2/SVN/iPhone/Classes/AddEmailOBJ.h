//
//  AddEmailOBJ.h
//  Acclaris
//
//  Created by Subhojit on 18/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface AddEmailOBJ : NSObject {

	NSString *strreturnCode;
	NSString *strerrorText;
	NSString *strresult;
	
	
}
@property(nonatomic,retain)NSString *strreturnCode;
@property(nonatomic,retain)NSString *strerrorText;
@property(nonatomic,retain)NSString *strresult;

@end
