//
//  ClaimSubOBJ.m
//  Acclaris
//
//  Created by Subhojit on 25/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ClaimSubOBJ.h"


@implementation ClaimSubOBJ
@synthesize	strsubcategoryListCount,strsubname,strsublabel,strsubDisplayseq;
@end
