//
//  UnsubmittedclaimOBJ.m
//  Acclaris
//
//  Created by Subhojit on 01/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "UnsubmittedclaimOBJ.h"


@implementation UnsubmittedclaimOBJ
@synthesize strclaimid,streeID,strClaimType,strClaimCategory,strClaimAmt,strserviceBegins,strserviceEnds,strnote,strprevYearPlanInd,strpayeeID,strpaymentRef,strinvoiceNo,
strcustomerNo,strproviderID,strproviderName,strelctID,straccountNo,strdpndtID,strreference,strrefNo,strtrxnID,strdescription,strreceiptMethod,
strclaimBatchType,strforceReview,strhsaRealtimeBalance,stractpCD,strpayType;
@end
