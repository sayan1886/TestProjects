//
//  PaynowAccountOBJ.h
//  Acclaris
//
//  Created by Subhojit on 22/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface PaynowAccountOBJ : NSObject {

	
	NSString *straccountTypeCD;
	NSString *straccountTypeDesc;
	NSString *strelctID;
	NSString *straccountNO;
	NSString *strpurseType;
	NSString *strlabelAssociatedValue;
	
}

@property(nonatomic,retain)NSString *straccountTypeCD;
@property(nonatomic,retain)NSString *straccountTypeDesc;
@property(nonatomic,retain)NSString *strelctID;
@property(nonatomic,retain)NSString  *straccountNO;
@property(nonatomic,retain)NSString *strpurseType;
@property(nonatomic,retain)NSString *strlabelAssociatedValue;
@end
