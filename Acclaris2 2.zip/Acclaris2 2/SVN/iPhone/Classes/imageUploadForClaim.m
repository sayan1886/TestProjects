//
//  imageUploadForClaim.m
//  Acclaris
//
//  Created by SAYAN BANERJEE on 30/04/11.
//  Copyright 2011 ObjectSol Technologies. All rights reserved.
//

#import "imageUploadForClaim.h"
#import "RequestPhase2.h"
#import "AddImage.h"
#import "passPerser.h"
#import "Decode64.h"
#import "claimActivityDetails.h"
#import "SubmitclaimParser.h"
#import "SubmitclaimOBJ.h"


@implementation imageUploadForClaim
-(id)initWithTarget:(id)actionTarget
	  SuccessAction:(SEL)successAction 
	  FailureAction:(SEL)failureAction
      rowno:(int)rowSelected
{
	self=[super init];
	if(self==nil)
	{
		return nil;
	}
	
	target=actionTarget;
	successHandler=successAction;
	failureHandler=failureAction;
	row=rowSelected;
	NSLog(@"row  %d",row);
	
	
	return self;
}

-(void)uploadImage:(NSInteger )imageNo
{
	 NSMutableArray *arrreptrequd=[SubmitclaimParser getarrReceiptrequired];
	NSMutableArray *imageDataArr=[AddImage getImageDataArr];
	NSMutableArray *userinfo_arr=[passPerser passresponce];
	
	
	NSString *tranClaimID=[claimActivityDetails getTranClaimID];
	NSString *tranID;
	NSString *claimID;
	if(row==-1)
	{
	
	   tranID=[[tranClaimID componentsSeparatedByString:@"/"] objectAtIndex:0];
	
	   claimID=[[tranClaimID componentsSeparatedByString:@"/"] objectAtIndex:1]; 
		
	}
	
	else 
	{
		tranID=[SubmitclaimParser getstrtrxnID];
		claimID=((SubmitclaimOBJ *)[arrreptrequd  objectAtIndex:row]).strclmID;

	}


	RequestPhase2 *objrequestPhase2=[[RequestPhase2 alloc] initWithTarget:self
													SuccessAction:@selector(onSuccesful)
													FailureAction:@selector(onFailure)];
	


	[objrequestPhase2 UploadImage:[userinfo_arr objectAtIndex:2] userid:[userinfo_arr objectAtIndex:4] imgData:[Base64 encode:[imageDataArr objectAtIndex:imageNo]] imgName:@"test.tiff" trxnID:tranID clmID:claimID];

	[objrequestPhase2 release];

}
-(void)onSuccesful
{
	[target performSelector:successHandler];
}
-(void)onFailure
{
	[target performSelector:failureHandler];
}
@end
