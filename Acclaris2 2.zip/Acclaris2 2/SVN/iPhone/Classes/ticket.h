//
//  ticket.h
//  Acclaris
//
//  Created by SAYAN BANERJEE on 06/10/10.
//  Copyright 2010 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AcclarisAppDelegate.h"
#import "MyTools.h"
@class request;
@class configurables;


@interface ticket : UIViewController<UITableViewDelegate,UITableViewDataSource> {

	MyTools *tools;
	UIView *loadingView;

	AcclarisAppDelegate *app;
	NSMutableArray *arr_celltytle;
	NSInteger startID;
	
	UITableView	*acctable;
	UIButton *bt_previous;
	UIButton *bt_next;
	configurables *con;
}
-(id)initWithTabBar;
+(NSInteger)getSelectedRow;
+(NSString *)getSelectedpage;
-(void)signoutbt;
-(void)createtableview;
-(void)reqTicket;
@end
