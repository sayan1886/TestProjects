//
//  AcclarisViewController.m
//  Acclaris
//
//  Created by Objectsol5 on 23/09/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//
#import <QuartzCore/QuartzCore.h>
#import "AcclarisViewController.h"
#import "SignIn.h"
#import "Decode64.h"
#import "UserresponcePerser.h"
#import "configurableParser.h"
#import "configurables.h"
#define version @"1.0"
 NSString *User_Name;
NSMutableArray *congigurableData;
@implementation AcclarisViewController


/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/

+(NSString *)userName
{
	if (User_Name) {
		return User_Name;
	}
	else {
		return nil;
	}

}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
	
	
	changed=YES;
	
	UILabel	*lbl_Version = [[UILabel alloc]initWithFrame:CGRectMake(110,330,100, 40)];
	lbl_Version.backgroundColor = [UIColor clearColor];
	lbl_Version.font = [UIFont fontWithName:@"Arial-Bold" size:15];
	lbl_Version.numberOfLines = 0;
	lbl_Version.textAlignment = UITextAlignmentCenter;
	lbl_Version.text = @"Version 1.4";
	[self.view addSubview:lbl_Version];
	
	tools=[[MyTools alloc]init];
	loadingView=[tools createActivityIndicator1];

	
	self.view.backgroundColor = [UIColor whiteColor];
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	
	
	UITabBarItem *tbi = (UITabBarItem *)[app.tabBarController.tabBar.items objectAtIndex:1];
	tbi.badgeValue = @"2";
	
	
	
	UIImageView *imgv_Background = [[UIImageView alloc]initWithImage:[UIImage imageNamed: @"sign-in-bg.png"]];
	[self.view addSubview:imgv_Background];
	
	
	//---Adding a Custom Title to a UINavigationItem---
	UILabel	*lbl_title = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 170, 44)];
	lbl_title.textAlignment = UITextAlignmentCenter;
	lbl_title.font = [UIFont fontWithName:@"Arial" size:30];
	lbl_title.backgroundColor = [UIColor clearColor];
	lbl_title.textColor = [UIColor whiteColor];
	lbl_title.text = @"Sign-In";
	self.navigationItem.titleView = lbl_title;
	
	UILabel	*lbl_UserName = [[UILabel alloc]initWithFrame:CGRectMake(26, 101, 92, 21)];
	lbl_UserName.backgroundColor = [UIColor clearColor];
	lbl_UserName.text = @"Username";
	[self.view addSubview:lbl_UserName];

	txtf_UserName = [[UITextField alloc]initWithFrame:CGRectMake(119, 98, 170, 28)];
	txtf_UserName.textColor = [UIColor blackColor];
	txtf_UserName.borderStyle = UITextBorderStyleRoundedRect;
	txtf_UserName.delegate=self;
	txtf_UserName.keyboardAppearance=UIKeyboardAppearanceAlert;
	txtf_UserName.autocapitalizationType=NO;
	[self.view addSubview:txtf_UserName];
	
	UIButton *btn_SignIn=[UIButton buttonWithType:UIButtonTypeCustom];
	btn_SignIn.frame = CGRectMake(41, 174, 234, 47);
	[btn_SignIn setBackgroundImage:[UIImage imageNamed:@"green-button.png"] forState:UIControlStateNormal];
	btn_SignIn.titleLabel.font = [UIFont fontWithName:@"Arial" size:20];
	[btn_SignIn setTitle:@"Sign In" forState:UIControlStateNormal];
    //btn_SignIn.titleLabel.textColor = [UIColor whiteColor];
	[btn_SignIn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn_SignIn addTarget:self action:@selector(sendrequest) forControlEvents:UIControlEventTouchUpInside];
	[self.view addSubview:btn_SignIn];
	
	btn_Remember_Me=[UIButton buttonWithType:UIButtonTypeCustom];
	btn_Remember_Me.frame = CGRectMake((320/2)-(130/2), 260, 130, 25);
	//[btn_Remember_Me setImage:[UIImage imageNamed: @"remember-me2.png"] forState:UIControlStateNormal];
    [btn_Remember_Me addTarget:self action:@selector(btn_RememberMe_Clicked:) forControlEvents:UIControlEventTouchUpInside];
    [btn_Remember_Me setTag:1];
	[self.view addSubview:btn_Remember_Me];
	
	
	
	UILabel	*lbl_Note = [[UILabel alloc]initWithFrame:CGRectMake((320/2)-(320/2), 350, 320, 40)];
	lbl_Note.backgroundColor = [UIColor clearColor];
	lbl_Note.font = [UIFont fontWithName:@"Arial" size:12];
	lbl_Note.numberOfLines = 0;
	lbl_Note.textAlignment = UITextAlignmentCenter;
	//lbl_Note.text = @"If you forget your username Please Call\nCustomer Service at: 1.813.273.2020";
	[self.view addSubview:lbl_Note];
	
	userinfo=[[NSMutableArray alloc]init];
	NSArray *uploadItems=[[NSUserDefaults standardUserDefaults] objectForKey:@"User_info"];
	
	NSLog(@"  USER DETAILS    %@",uploadItems);
	
	
	if ([uploadItems count]>0)
	{
		//txtf_UserName.text=[self formatString:[uploadItems objectAtIndex:0]];//[uploadItems objectAtIndex:0];
		
		if([[uploadItems objectAtIndex:1]isEqualToString:@"yes"])
			[btn_Remember_Me setBackgroundImage:[UIImage imageNamed:@"remember-me.png"] forState:UIControlStateNormal];
		else
			[btn_Remember_Me setBackgroundImage:[UIImage imageNamed:@"remember-me2.png"] forState:UIControlStateNormal];
	}
	else
		[btn_Remember_Me setBackgroundImage:[UIImage imageNamed:@"remember-me2.png"] forState:UIControlStateNormal];
}

-(void)btn_RememberMe_Clicked:(id)sender
{
	if(btn_Remember_Me.currentBackgroundImage==[UIImage imageNamed:@"remember-me.png"])
		[btn_Remember_Me setBackgroundImage:[UIImage imageNamed:@"remember-me2.png"] forState:UIControlStateNormal];
	else
		[btn_Remember_Me setBackgroundImage:[UIImage imageNamed:@"remember-me.png"] forState:UIControlStateNormal];
	
}

-(void)sendrequest
{
	NSDictionary *customMessageList_dict=[[NSUserDefaults standardUserDefaults] objectForKey:@"customMessageList"];
	
	
	NSString *strmessage=[[customMessageList_dict valueForKey:@"200041"]valueForKey:@"message"];
	
	
	NSString *strtype=[[customMessageList_dict valueForKey:@"200041"]valueForKey:@"type"];
	
	[txtf_UserName resignFirstResponder];
	uploadItems1=[[NSUserDefaults standardUserDefaults] objectForKey:@"User_info"];
	if ([txtf_UserName.text length]==0)
	{
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:strtype message:strmessage delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
		[alert show];
		[alert release];
	}
	else {
		
	
	if(btn_Remember_Me.currentBackgroundImage==[UIImage imageNamed:@"remember-me.png"] )
	{
		if (changed) {
			[userinfo removeAllObjects];
			[userinfo addObject:txtf_UserName.text];
			[userinfo addObject:@"yes"];
			[[NSUserDefaults standardUserDefaults] setObject:(NSArray*)userinfo forKey:@"User_info"];
			[[NSUserDefaults standardUserDefaults] synchronize];
		}
		
	}
	else 
	{
		uploadItems1=[[NSUserDefaults standardUserDefaults] objectForKey:@"User_info"];

		[userinfo removeAllObjects];
		[userinfo addObject:@""];
		[userinfo addObject:@"no"];
		[[NSUserDefaults standardUserDefaults] setObject:(NSArray*)userinfo forKey:@"User_info"];
		[[NSUserDefaults standardUserDefaults] synchronize];
		
		
	}
	
	[tools startLoading:self./*navigationController.*/view childView:loadingView text:@"Signing in. Wait…."];
	if (changed) {
		User_Name = txtf_UserName.text;
	}
	else {
		//NSArray *uploadItems=[[NSUserDefaults standardUserDefaults] objectForKey:@"User_info"];
		User_Name=[uploadItems1 objectAtIndex:0];
	}
	
	request *r=[[request alloc] initWithTarget:self
								 SuccessAction:@selector(onSucceffulLogin:arr2:)
								 FailureAction:@selector(onFailureLogin)];
	[r senduserRequest:User_Name];
	[r release];
		
	}	
}
				
-(void)onSucceffulLogin:(NSMutableArray*)arr arr2:(NSMutableArray *)arr2
{
	
			
	
	[tools stopLoading:loadingView];
	
	
	NSMutableArray *userinfo_arr=[UserresponcePerser userdesc];//array to get last time of config change
	
		
	
	if ([[userinfo_arr objectAtIndex:0]intValue]!=0)
	{
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Sorry" message:[userinfo_arr objectAtIndex:1] delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
		[alert show];
		[alert release];
		
		return ;
	}
	if (![[[userinfo_arr objectAtIndex:9]objectAtIndex:2] isEqualToString:version] )
	{
		NSString *alertbodytxt=@"";
		alertbodytxt=[alertbodytxt stringByAppendingString:[[userinfo_arr objectAtIndex:9]objectAtIndex:3]];
		alertbodytxt=[alertbodytxt stringByAppendingString:@"\n"];
		alertbodytxt=[alertbodytxt stringByAppendingString:[[userinfo_arr objectAtIndex:9]objectAtIndex:0]];
		
		linkappDwnld=[[userinfo_arr objectAtIndex:9]objectAtIndex:0];//to the deligate to download
		
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Update Available" message:alertbodytxt delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Download",nil];
		[alert show];
		[alert release];
		return ;
	}
	
	if ([userinfo_arr count]<9) 
	{
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Sorry" message:@"Data Unavailable" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
		[alert show];
		[alert release];
		
		return ;
	}
	
	NSArray *lasttime=[[NSUserDefaults standardUserDefaults] objectForKey:@"configtime"];
	
	
	NSArray *config_data=[[NSUserDefaults standardUserDefaults] objectForKey:@"config_data"];
	if ([config_data count]>0 && [[userinfo_arr objectAtIndex:8] isEqualToString:[lasttime objectAtIndex:0]])
	{
	  [self getdata];
		
	}
	else {
	
	NSLog(@"\n\n\n\n\nHA HA HA HA HA HA HA HA\n\n\n\n\n");
	[tools startLoading:self.view childView:loadingView text:@"Loading configurables. Wait…."];
	request *r=[[request alloc] initWithTarget:self
								 SuccessAction:@selector(onSucceffulLogin1)
								 FailureAction:@selector(onFailureLogin1)];
	[r sendcdonfigRequest:txtf_UserName.text];
	[r release];
	
	}
	
	NSMutableArray *shaldwconfig=[[NSMutableArray alloc]init];//array to save last time of config change
	
	
	
	[shaldwconfig addObject:[userinfo_arr objectAtIndex:8]];
	[[NSUserDefaults standardUserDefaults] setObject:(NSArray*)shaldwconfig forKey:@"configtime"];
	[[NSUserDefaults standardUserDefaults] synchronize];
	
	
	
}
				
-(void)onFailureLogin
{
	[tools stopLoading:loadingView];	
	
}
-(void)onSucceffulLogin1
{
	[self savedata];
	[tools stopLoading:loadingView];
	
}
-(void)onFailureLogin1
{
	[tools stopLoading:loadingView];
	
}

-(void)pusttoPassscreen
{
	app=(AcclarisAppDelegate *)[[UIApplication sharedApplication]delegate];
	NSMutableArray *userinfo_arr=[UserresponcePerser userdesc];
	if ([[userinfo_arr objectAtIndex:0]intValue]==0)
	{
		
		SignIn *View_SignIn = [[SignIn alloc] init];
		[self.navigationController pushViewController:View_SignIn animated:YES];
		
	}
	else {
		
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Sorry" message:[userinfo_arr objectAtIndex:1] delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
		[alert show];
		[alert release];
		
	}
	
	
}
-(void)savedata
{
	NSMutableArray *configdata=[configurableParser getconfig_arr];
	configurables *con=(configurables *)[configdata objectAtIndex:0];
	
	//NSString *str=[[NSString alloc]initWithString:con.fontname];
	
	NSMutableArray *array_insrt=[[NSMutableArray alloc]init];
	
	[array_insrt addObject:[[NSString alloc]initWithString:con.fontname]];
	[array_insrt addObject:[NSString stringWithFormat:@"%d",con.fontsize]];
	
	[array_insrt addObject:[NSString stringWithFormat:@"%f",con.navbarRed]];
	[array_insrt addObject:[NSString stringWithFormat:@"%f",con.navbarGreen]];
	[array_insrt addObject:[NSString stringWithFormat:@"%f",con.navbarBlue]];
	
	
	[array_insrt addObject:[NSString stringWithFormat:@"%f",con.bgRed]];
	[array_insrt addObject:[NSString stringWithFormat:@"%f",con.bgGreen]];
	[array_insrt addObject:[NSString stringWithFormat:@"%f",con.bgBlue]];
	
	
	[array_insrt addObject:[NSString stringWithFormat:@"%f",con.bgRed2]];
	[array_insrt addObject:[NSString stringWithFormat:@"%f",con.bgGreen2]];
	[array_insrt addObject:[NSString stringWithFormat:@"%f",con.bgBlue2]];
		
	
	[array_insrt addObject:[NSString stringWithFormat:@"%f",con.posnumRed]];
	[array_insrt addObject:[NSString stringWithFormat:@"%f",con.posnumGreen]];
	[array_insrt addObject:[NSString stringWithFormat:@"%f",con.posnumBlue]];
	
	
	[array_insrt addObject:[NSString stringWithFormat:@"%f",con.txtRed]];
	[array_insrt addObject:[NSString stringWithFormat:@"%f",con.txtGreen]];
	[array_insrt addObject:[NSString stringWithFormat:@"%f",con.txtBlue]];
	
	
	[array_insrt addObject:[NSString stringWithFormat:@"%f",con.ngtvRed]];
	[array_insrt addObject:[NSString stringWithFormat:@"%f",con.ngtvGreen]];
	[array_insrt addObject:[NSString stringWithFormat:@"%f",con.ngtvBlue]];
	
	
	[array_insrt addObject:[NSString stringWithFormat:@"%@",con.ngtvSufix]];
	[array_insrt addObject:[NSString stringWithFormat:@"%@",con.ngtvPrefix]];
	[array_insrt addObject:[NSString stringWithFormat:@"%@",con.ptvPrefix]];
	
	[array_insrt addObject:[NSString stringWithFormat:@"%@",con.btnImgdata]];
	
	
	[array_insrt addObject:[NSString stringWithFormat:@"%@",con.btnfontname]];
	[array_insrt addObject:[NSString stringWithFormat:@"%d",con.btnfontsize]];
	
	[array_insrt addObject:[NSString stringWithFormat:@"%f",con.linkimpRed]];
	[array_insrt addObject:[NSString stringWithFormat:@"%f",con.linkimpGreen]];
	[array_insrt addObject:[NSString stringWithFormat:@"%f",con.linkimpBlue]];
	
	[array_insrt addObject:[NSString stringWithFormat:@"%f",con.linkgnRed]];
	[array_insrt addObject:[NSString stringWithFormat:@"%f",con.linkgnGreen]];
	[array_insrt addObject:[NSString stringWithFormat:@"%f",con.linkgnBlue]];
	
	[array_insrt addObject:[NSString stringWithFormat:@"%@",con.btnNavImgData]];
	[array_insrt addObject:[NSString stringWithFormat:@"%@",con.btnNavFontName]];
	[array_insrt addObject:[NSString stringWithFormat:@"%d",con.btnNavFontSize]];
	
	
	[array_insrt addObject:[NSString stringWithFormat:@"%@",con.logoImgdata]];
	
	[[NSUserDefaults standardUserDefaults] setObject:(NSArray*)array_insrt forKey:@"config_data"];
	[[NSUserDefaults standardUserDefaults] synchronize];
	
	[self getdata];
	
	
}

-(void)getdata
{
	NSArray *config_data=[[NSUserDefaults standardUserDefaults] objectForKey:@"config_data"];
	
	NSLog(@"sayans iphone config data  %@",config_data);
	
	configurables *con=[[configurables alloc]init];
	
	con.fontname=[config_data objectAtIndex:0];
	con.fontsize=[[config_data objectAtIndex:1] intValue];
	
	con.navbarRed=[[config_data objectAtIndex:2] floatValue];
	con.navbarGreen=[[config_data objectAtIndex:3] floatValue];
	con.navbarBlue=[[config_data objectAtIndex:4] floatValue];
	
	con.bgRed=[[config_data objectAtIndex:5] floatValue];
	con.bgGreen=[[config_data objectAtIndex:6] floatValue];
	con.bgBlue=[[config_data objectAtIndex:7] floatValue];
	
	con.bgRed2=[[config_data objectAtIndex:8] floatValue];
	con.bgGreen2=[[config_data objectAtIndex:9] floatValue];
	con.bgBlue2=[[config_data objectAtIndex:10] floatValue];
	
	con.posnumRed=[[config_data objectAtIndex:11] floatValue];
	con.posnumGreen=[[config_data objectAtIndex:12] floatValue];
	con.posnumBlue=[[config_data objectAtIndex:13] floatValue];
	
	con.txtRed=[[config_data objectAtIndex:14] floatValue];
	con.txtGreen=[[config_data objectAtIndex:15] floatValue];
	con.txtBlue=[[config_data objectAtIndex:16] floatValue];
	
	con.ngtvRed=[[config_data objectAtIndex:17] floatValue];
	con.ngtvGreen=[[config_data objectAtIndex:18] floatValue];
	con.ngtvBlue=[[config_data objectAtIndex:19] floatValue];
	
	con.ngtvSufix=[config_data objectAtIndex:20];
	con.ngtvPrefix=[config_data objectAtIndex:21];
	con.ptvPrefix=[config_data objectAtIndex:22];
	
	con.btnImgdata=[config_data objectAtIndex:23] ;
	
	con.btnfontname=[config_data objectAtIndex:24];
	con.btnfontsize=[[config_data objectAtIndex:25] intValue];
	
	con.linkimpRed=[[config_data objectAtIndex:26] floatValue];
	con.linkimpGreen=[[config_data objectAtIndex:27] floatValue];
	con.linkimpBlue=[[config_data objectAtIndex:28] floatValue];
	
	con.linkgnRed=[[config_data objectAtIndex:29] floatValue];
	con.linkgnGreen=[[config_data objectAtIndex:30] floatValue];
	con.linkgnBlue=[[config_data objectAtIndex:31] floatValue];
	
	con.btnNavImgData=[config_data objectAtIndex:32];
	
	con.btnNavFontName=[config_data	objectAtIndex:33];
	
	con.btnNavFontSize=[[config_data objectAtIndex:34] intValue];
	
	
	con.logoImgdata=[config_data objectAtIndex:35];
	
	con.headerImpfntsize=[[config_data objectAtIndex:1] intValue]+4;
	con.headerfntsize=[[config_data objectAtIndex:1] intValue]+1;
	
	con.bodyImpfntsize=[[config_data objectAtIndex:1] intValue];
	con.bodyfntsize=[[config_data objectAtIndex:1] intValue]-3;
	
	
	
	
	congigurableData=[[NSMutableArray alloc]init];
	
	[congigurableData addObject:con];
	
	
	configurables *con1=(configurables *)[congigurableData objectAtIndex:0];
		NSLog(@"linkgnRed%f",con1.linkgnRed);
		NSLog(@"linkgnGreen%f",con1.linkgnGreen);
		NSLog(@"linkgnBlue%f",con1.linkgnBlue);
		NSLog(@"%f",con1.bgGreen);
		NSLog(@"%@",con1.btnImgdata);
	
	[self pusttoPassscreen];
}

+(NSMutableArray *)staticarr_config
{
	if (congigurableData) {
		
		return congigurableData;
	}
	else {
		return nil;
	}
}

#pragma mark -
#pragma mark textfield deligate
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
	
	if(textField.frame.origin.y>=165)
	{
		UIView *ContainedView=[textField superview];
		CGRect rect=ContainedView.frame;
		[UIView beginAnimations:nil context:nil];
		[UIView setAnimationDuration:0.3];
		rect.origin.y-=(textField.frame.origin.y-165);
		ContainedView.frame=rect;
		[UIView commitAnimations];
	}
	return YES;
}

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField
{
	if((textField.frame.origin.y-165)>0)
	{
		UIView *ContainedView=[textField superview];
		CGRect rect=ContainedView.frame;
		[UIView beginAnimations:nil context:nil];
		[UIView setAnimationDuration:0.3];
		rect.origin.y+=(textField.frame.origin.y-165);
		ContainedView.frame=rect;
		[UIView commitAnimations];
	}
	return YES;
}
- (BOOL)textField:(UITextField *)textField 
         shouldChangeCharactersInRange:(NSRange)range
                     replacementString:(NSString *)string {
	
    if([string isEqualToString:@""]) {
        // Some replacement is taking place where the new string is empty
        // This implies a backspace (and not a character replacement)
        // Do your backspace-trapping here
		textField.text=@"";
		changed=YES;
        return NO;
    } else {
		changed=YES;
        return YES;
    }
	
}

-(BOOL)textFieldShouldReturn:(UITextField *)theTextField 
{
	[theTextField  resignFirstResponder];
	return YES;
}
#pragma mark -
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	if (buttonIndex==1)
	{
		[[UIApplication sharedApplication]openURL:[NSURL URLWithString:linkappDwnld]];
	}
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/
-(NSString *)formatString:(NSString *)Uname
{
	if ([Uname length]>0) {
		NSString *nottoMask=[Uname substringToIndex:[Uname length]-4];//
		NSString *formatedText=[nottoMask stringByAppendingString:@"****"];
		return formatedText;
	}
	else {
		return @"";
	}

}
- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}
-(void)viewWillAppear:(BOOL)animated
{
	//changed=NO;
	NSArray *uploadItems=[[NSUserDefaults standardUserDefaults] objectForKey:@"User_info"];
	
	
	if ([uploadItems count]>0)
	{
		txtf_UserName.text=[self formatString:[uploadItems objectAtIndex:0]];
	}
	if(btn_Remember_Me.currentBackgroundImage==[UIImage imageNamed:@"remember-me2.png"])
	{
		
		txtf_UserName.text=@"";
	}
	
}
-(void)viewDidDisappear:(BOOL)animated
{
	changed=NO;
}
+(NSString *)filePathForResourceName:(NSString *)name
{
	NSArray* fileName_ary = [name componentsSeparatedByString:@"."];
	NSString* filename = [fileName_ary objectAtIndex:0];
	NSString* fileExtension = ([fileName_ary count] > 1) ? [fileName_ary objectAtIndex:1] : @"png";
	
	NSString* filePath = [[NSBundle mainBundle] pathForResource:filename
														 ofType:fileExtension]; 
	return filePath;
}
@end
