============================
Google AdMob Ads SDK for iOS
============================

This is the Google AdMob Ad SDK for iOS.

Requirements:
- A Google AdSense or AdMob publisher ID.
- Xcode 3.2 or later; iOS SDK 4.2 or later.
- Runtime of iOS 3.0 or later.

The latest documentation and code samples are available at:
http://code.google.com/mobile/ads/docs/ios
