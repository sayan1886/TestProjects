//
//  AppDelegate.h
//  TestiAd
//
//  Created by Sayan on 10/07/12.
//  Copyright __MyCompanyName__ 2012. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AdRootViewController;

@interface AppDelegate : NSObject <UIApplicationDelegate> {
	UIWindow			*window;
	AdRootViewController	*viewController;
}

@property (nonatomic, retain) UIWindow *window;
@property (nonatomic,retain) AdRootViewController	*viewController;
 
@end
