//
//  NextScene.h
//  TestiAd
//
//  Created by Sayan on 10/07/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

//#import <Foundation/Foundation.h>
#import "cocos2d.h"
//#import "Box2D.h"
//#import "GLES-Render.h"


@interface NextScene : CCLayer {
    
}

@end
