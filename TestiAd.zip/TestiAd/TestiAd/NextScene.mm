//
//  NextScene.m
//  TestiAd
//
//  Created by Sayan on 10/07/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "NextScene.h"
#import "HelloWorldLayer.h"

@implementation NextScene
+(CCScene *) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	NextScene *layer = [NextScene node];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}

// on "init" you need to initialize your instance
-(id) init
{
	// always call "super" init
	// Apple recommends to re-assign "self" with the "super" return value
	if( (self=[super init])) {
		
		// enable touches
		self.isTouchEnabled = YES;
		
		// enable accelerometer
		self.isAccelerometerEnabled = YES;
		
		CGSize screenSize = [CCDirector sharedDirector].winSize;
		CCLOG(@"Screen width %0.2f screen height %0.2f",screenSize.width,screenSize.height);
        CCMenuItemFont *replaceSceneText = [CCMenuItemFont itemFromString:@"Previous Scene" block:(id)^{
            CCLOG(@"Replace Current Scene");
            [[CCDirector sharedDirector] replaceScene:[HelloWorldLayer node]];
        }];
        replaceSceneText.position = ccp(screenSize.width / 2,screenSize.height / 2);
        CCMenu *menu = [CCMenu menuWithItems:replaceSceneText, nil];
        [menu alignItemsVertically];
        [self addChild:menu];
	}
	return self;
}
@end
