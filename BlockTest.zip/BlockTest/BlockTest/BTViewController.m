//
//  BTViewController.m
//  BlockTest
//
//  Created by Sayan on 26/09/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "BTViewController.h"
#import "BTDetailViewController.h"

@interface BTViewController ()
@property (nonatomic,retain) NSMutableArray *tableContent;
@end

@implementation BTViewController

@synthesize tableContent = _tableContent;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    self.title = @"Blocks As Callback";
    self.tableContent = [NSMutableArray arrayWithObjects:@"Test1",@"Test2",@"Test3",@"Test4", nil] ;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [self.tableContent count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellid = @"cell";
    static NSString *niulCellid = @"nil";
    UITableViewCell *cell = nil;
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:niulCellid];
    }
    else {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellid];
    }
    cell.textLabel.text = [self.tableContent objectAtIndex:indexPath.row];
    return [cell autorelease];
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    BTDetailViewController *details = [[[BTDetailViewController alloc] initWithNibName:@"BTDetailViewController" bundle:nil] autorelease];
                                        //delegate:^(NSString *title){
        //[self.tableContent replaceObjectAtIndex:indexPath.row withObject:title];
        //[((UITableView *)[self.view viewWithTag:201]) reloadData];
    //}] autorelease];
    [details setDelegate:^(NSString *title){
        [self.tableContent replaceObjectAtIndex:indexPath.row withObject:title];
        [((UITableView *)[self.view viewWithTag:201]) reloadData];
    }];
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    [self.navigationController pushViewController:details animated:YES];
}

@end
