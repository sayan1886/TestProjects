//
//  BTDetailViewController.h
//  BlockTest
//
//  Created by Sayan on 27/09/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^BTDetailDelegate )(NSString *);

@interface BTDetailViewController : UIViewController{
    BTDetailDelegate delegate;
}

@property (nonatomic,copy) BTDetailDelegate delegate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil delegate:(BTDetailDelegate)delegate;

- (IBAction)setTitle:(id)sender;

@end
