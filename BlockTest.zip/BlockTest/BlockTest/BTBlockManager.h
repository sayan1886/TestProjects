//
//  BTBlockManager.h
//  BlockTest
//
//  Created by Sayan on 27/09/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BTBlockManager : NSObject

@end
