//
//  BTDetailViewController.m
//  BlockTest
//
//  Created by Sayan on 27/09/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "BTDetailViewController.h"

@interface BTDetailViewController ()

@end

@implementation BTDetailViewController

//@synthesize delegate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil delegate:(BTDetailDelegate)delegateBlock
{
    if ([self initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        //self.delegate = delegate;
        delegate = Block_copy(delegateBlock);
    }
    return self;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (BTDetailDelegate) delegate{
    return delegate;
}

- (void) setDelegate:(BTDetailDelegate)delegateBlock{
    delegate = Block_copy(delegateBlock);
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (IBAction)setTitle:(id)sender {
    UITextField *textField = ((UITextField *)[self.view viewWithTag:101]);
    if (textField.text.length > 0) {
        if (self.delegate) {
            delegate(textField.text);
        }
        [self.navigationController popViewControllerAnimated:YES];
    }
    
}

#pragma mark - UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}

@end
