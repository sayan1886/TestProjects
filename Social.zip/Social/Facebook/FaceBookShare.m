//
//  FaceBookShare.m
//  WarHits
//
//  Created by Sayan on 12/07/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "FaceBookShare.h"
#import "FbGraph.h"
#import "FbGraphFile.h"
#import "JSON.h"
#import "MessageBox.h"
#import "resource.h"

@interface FaceBookShare ()

@property (nonatomic,retain) FbGraph *fbGraph;
@property (nonatomic,retain) NSString *text;
@property (nonatomic,retain) UIImage *image;
@property (nonatomic,retain) NSString *urlString;
@property (nonatomic,assign) BOOL needToDeleteCookies;
@property (nonatomic,retain) Facebook *facebook;
@property (nonatomic,retain) NSArray *permissions;
@property (nonatomic,retain) NSString *fileURLString;
@property (nonatomic,retain) NSString *description;

- (void) initializeSharedInstance;

@end

@implementation FaceBookShare

static FaceBookShare *facebookSharer = nil;

@synthesize fbGraph;
@synthesize text;
@synthesize image;
@synthesize urlString;
@synthesize needToDeleteCookies;
@synthesize facebook;
@synthesize permissions;
@synthesize fileURLString;
@synthesize login;
@synthesize description;

+ (FaceBookShare *) facebookSharer{
    if (!facebookSharer) {
        facebookSharer = [[self alloc] init];
        [facebookSharer initializeSharedInstance];
    }
    return facebookSharer;
}

- (void) initializeSharedInstance{
    self.text = @"";
    self.urlString = @"";
    self.image = [UIImage imageNamed:@""];
    self.permissions = [[[NSArray alloc] initWithObjects:@"offline_access",@"publish_stream", @"user_photos",nil] autorelease];
    self.login = NO;
    //[[self facebook] authorize:permissions];
}

- (void) authenticateFaceBookForClientid:(NSString *)clientid andTarget:(id)target andShareText:(NSString *)text_ shareIamge:(UIImage *)image_ linkedURL:(NSString *)urlString_ needToDeleteCookies:(BOOL)delete{
    
    /*Facebook Application ID*/
	//NSString *client_id = @"320240481320431";//@"145003732251039";//@"214499911909451";
	self.text = text_;
    self.urlString = urlString_;
    self.image = image_;
    self.needToDeleteCookies = delete;
    actionTarget = target;
	//alloc and initalize our FbGraph instance
	self.fbGraph = [[[FbGraph alloc] initWithFbClientID:clientid] autorelease];
	if ([target isKindOfClass:[UIViewController class]]) {
        [fbGraph authenticateUserWithCallbackObject:self andSelector:@selector(fbGraphCallback:) andExtendedPermissions:@"user_photos,user_videos,publish_stream,offline_access,user_checkins,user_likes,friends_checkins" andSuperView:((UIViewController *)target).view];
        //((UIViewController *)target).navigationController.navigationBarHidden = YES;
    }
    else if ([target isKindOfClass:[UIView class]]) {
        [fbGraph authenticateUserWithCallbackObject:self andSelector:@selector(fbGraphCallback:) andExtendedPermissions:@"user_photos,user_videos,publish_stream,offline_access,user_checkins,user_likes,friends_checkins" andSuperView:target];
    }
    else {
        return;
    }
	
}

- (void) shareImageAndTextToFaceBook{
    
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    FbGraphResponse *fb_graph_response = [fbGraph doGraphGet:@"me" withGetVars:nil];
    //NSLog(@"getMeButtonPressed:  %@", fb_graph_response.htmlResponse);
    
    
    NSDictionary *dict = [fb_graph_response.htmlResponse JSONValue];
    
    NSLog(@"getMeButtonPressed:  %@", dict);
    
    NSString *usr_id = [dict objectForKey:@"id"];
    
    
    NSMutableDictionary *variables = [NSMutableDictionary dictionaryWithCapacity:2];
    
    
    
    //create a FbGraphFile object insance and set the picture we wish to publish on it
    FbGraphFile *graph_file = [[FbGraphFile alloc] initWithImage:self.image];
    
    //finally, set the FbGraphFileobject onto our variables dictionary....
    [variables setObject:graph_file forKey:@"file"];
    
    [variables setObject:self.text forKey:@"message"];
    [variables setObject:self.urlString forKey:@"link"];
    
    [graph_file release];
    
    //    if (fb_graph_response) {
    //        [fb_graph_response release],fb_graph_response = nil;
    //    }
    //the fbGraph object is smart enough to recognize the binary image data inside the FbGraphFile
    //object and treat that is such.....
    fb_graph_response = [fbGraph doGraphPost:[NSString stringWithFormat:@"%@/photos",usr_id] withPostVars:variables];
    NSLog(@"postPictureButtonPressed:  %@", fb_graph_response.htmlResponse);
    
    
    NSLog(@"Now log into Facebook and look at your profile & photo albums...");
    if (self.needToDeleteCookies) {
        [fbGraph deleteCookies];
    }
    
    [pool release];
    
}

#pragma mark - FaceBookConnect Helper

- (void)storeAuthData:(NSString *)accessToken expiresAt:(NSDate *)expiresAt {
    NSLog(@"ACCESS TOKEN ; %@",accessToken);
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:accessToken forKey:@"FBAccessTokenKey"];
    [defaults setObject:expiresAt forKey:@"FBExpirationDateKey"];
    [defaults synchronize];
}


- (void) uploadImageToPhtoAlbumWithTarget:(id)target Description:(NSString *)desc andShareText:(NSString *)text_ shareIamge:(UIImage *)image_ linkedURL:(NSString *)urlString_{
    self.image = image_;
    self.text= text_;
    self.urlString = urlString_;
    self.description = desc;
    
    currentAPICall = kAPIGraphUserPhotosPost;
    //NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys: image, @"picture",@"KillShot", @"name", nil];
    SBJSON *jsonWriter = [[SBJSON new] autorelease];
    NSArray* actionLinks = [NSArray arrayWithObjects:[NSDictionary dictionaryWithObjectsAndKeys: @"Get Started",@"name",urlString,@"link", nil], nil];
    NSString *actionLinksStr = [jsonWriter stringWithObject:actionLinks];
    //The "to" parameter targets the post to a friend
    //NSString *name = [NSString stringWithFormat:@"%@! Think you're smarter than me? Prove it with TrivPals!",freindName];
    
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   //[self.dictionary objectForKey:@"id"], @"to",
                                   //name, @"name",
                                   text, @"caption",
                                   //@"Warhits is the latest iPhone game that allows you to play gun action with your freinds using GameCenter or Local Wi-Fi.", @"description",
                                   description, @"description",
                                   urlString, @"link",
                                   image, @"picture",
                                   actionLinksStr, @"actions",
                                   nil];
    
    //Let's post it
    [facebook requestWithGraphPath:@"me/photos"
                         andParams:params
                     andHttpMethod:@"POST"
                       andDelegate:self];
}

- (void) openFaceBookSharingDialog {
//    NSMutableDictionary *params = 
//    [NSMutableDictionary dictionaryWithObjectsAndKeys:
//     @"Testing Feed Dialog", @"name",
//     @"Feed Dialogs are Awesome.", @"caption",
//     @"Check out how to use Facebook Dialogs.", @"description",
//     @"http://www.example.com/", @"link",
//     @"http://fbrell.com/f8.jpg", @"picture",
//     nil];  
    
    //NSString *freindName = [[[dictionary objectForKey:@"name"] componentsSeparatedByString:@" "] objectAtIndex:0];
    
    SBJSON *jsonWriter = [[SBJSON new] autorelease];
    NSArray* actionLinks = [NSArray arrayWithObjects:[NSDictionary dictionaryWithObjectsAndKeys:
                                                      @"Get Started",@"name",@"http://www.objectsol.in/",@"link", nil], nil];
    NSString *actionLinksStr = [jsonWriter stringWithObject:actionLinks];
    //The "to" parameter targets the post to a friend
    //NSString *name = [NSString stringWithFormat:@"%@! Think you're smarter than me? Prove it with TrivPals!",freindName];
    
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   //[self.dictionary objectForKey:@"id"], @"to",
                                   //name, @"name",
                                   @"Try It!", @"caption",
                                   @"Warhits is the latest iPhone game that allows you to play gun action with your freinds using GameCenter or Local Wi-Fi.", @"description",
                                   @"http://www.objectsol.in/", @"link",
                                   //image, @"picture",
                                   actionLinksStr, @"actions",
                                   nil];
    if (fileURLString.length > 0) {
        [params setObject:fileURLString forKey:@"picture"];
    }
    [facebook dialog:@"feed"
           andParams:params
         andDelegate:self];
}

- (void) setupFaceBookLogin{
    
    // Check App ID:
    // This is really a warning for the developer, this should not
    // 
#ifdef FB_CLIENT_ID
    // Initialize Facebook
    self.facebook = [[[Facebook alloc] initWithAppId:FB_CLIENT_ID andDelegate:self] autorelease];
    // Check and retrieve authorization information
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if ([defaults objectForKey:@"FBAccessTokenKey"] && [defaults objectForKey:@"FBExpirationDateKey"]) {
        self.facebook.accessToken = [defaults objectForKey:@"FBAccessTokenKey"];
        self.facebook.expirationDate = [defaults objectForKey:@"FBExpirationDateKey"];
    }
    // Now check that the URL scheme fb[app_id]://authorize is in the .plist and can
    // be opened, doing a simple check without local app id factored in here
    NSString *url = [NSString stringWithFormat:@"fb%@://authorize",FB_CLIENT_ID];
    BOOL bSchemeInPlist = NO; // find out if the sceme is in the plist file.
    NSArray* aBundleURLTypes = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleURLTypes"];
    if ([aBundleURLTypes isKindOfClass:[NSArray class]] &&
        ([aBundleURLTypes count] > 0)) {
        NSDictionary* aBundleURLTypes0 = [aBundleURLTypes objectAtIndex:0];
        if ([aBundleURLTypes0 isKindOfClass:[NSDictionary class]]) {
            NSArray* aBundleURLSchemes = [aBundleURLTypes0 objectForKey:@"CFBundleURLSchemes"];
            if ([aBundleURLSchemes isKindOfClass:[NSArray class]] &&
                ([aBundleURLSchemes count] > 0)) {
                NSString *scheme = [aBundleURLSchemes objectAtIndex:0];
                if ([scheme isKindOfClass:[NSString class]] &&
                    [url hasPrefix:scheme]) {
                    bSchemeInPlist = YES;
                }
            }
        }
    }
    // Check if the authorization callback will work
    NSLog(@"URL : %@",url);
    BOOL bCanOpenUrl = [[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString: url]];
    if (!bSchemeInPlist || !bCanOpenUrl) {
        UIAlertView *alertView = [[UIAlertView alloc]
                                  initWithTitle:@"Setup Error"
                                  message:@"Invalid or missing URL scheme. You cannot run the app until you set up a valid URL scheme in your .plist."
                                  delegate:self
                                  cancelButtonTitle:@"OK"
                                  otherButtonTitles:nil,
                                  nil];
        [alertView show];
        [alertView release];
    }
#else
        UIAlertView *alertView = [[UIAlertView alloc]
                                  initWithTitle:@"Setup Error"
                                  message:@"Missing app ID. You cannot run the app until you provide this in the code."
                                  delegate:self
                                  cancelButtonTitle:@"OK"
                                  otherButtonTitles:nil,
                                  nil];
        [alertView show];
        [alertView release];
#endif

}

- (void) faceBookAuthorizeWithTarget:(id)target Description:(NSString *)desc andShareText:(NSString *)text_ shareIamge:(UIImage *)image_ linkedURL:(NSString *)urlString_{
    actionTarget = target;
    //self.fileURLString = fileURLString;
    self.image = image_;
    self.text= text_;
    self.urlString = urlString_;
    self.description = desc;
    if (![self isLoggedin]) {
        [[self facebook] authorize:permissions];
    }
}

#pragma mark - Facebook API Calls
/**
 * Make a Graph API Call to get information about the current logged in user.
 */
- (void)apiFQLIMe {
    // Using the "pic" picture since this currently has a maximum width of 100 pixels
    // and since the minimum profile picture size is 180 pixels wide we should be able
    // to get a 100 pixel wide version of the profile picture
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   @"SELECT uid FROM user WHERE uid=me()", @"query",
                                   nil];
    [[self facebook] requestWithMethodName:@"fql.query"
                                                          andParams:params
                                                      andHttpMethod:@"POST"
                                                        andDelegate:self];
}

- (void)apiGraphUserPermissions {
    
    [[self facebook] requestWithGraphPath:@"me/permissions" andDelegate:self];
}

- (void) facebookLogout{
    [self.facebook logout];
}

//- (void) 
#pragma mark - FBDialogDelegate

/**
 * Called when a UIServer Dialog successfully return. Using this callback
 * instead of dialogDidComplete: to properly handle successful shares/sends
 * that return ID data back.
 */
- (void)dialogCompleteWithUrl:(NSURL *)url {
    if (![url query]) {
        NSLog(@"User canceled dialog or there was an error");
        return;
    }
    if (!([actionTarget isKindOfClass:[UIView class]] || ([actionTarget isKindOfClass:[UIViewController class]]))) {
        return;
    }
    MessageBox *message = nil;
    if ([actionTarget isKindOfClass:[UIView class]]) {
        message = [[[MessageBox alloc] initWithSuperview:((UIView *)actionTarget) hasNavigationBar:YES] autorelease];
    }
    if ([actionTarget isKindOfClass:[UIViewController class]]) {
        message = [[[MessageBox alloc] initWithSuperview:((UIView *)actionTarget) hasNavigationBar:YES] autorelease];
    }
    
    [message showMessage:@"Invitation Sent Successfull."];
}

- (void)dialogDidNotComplete:(FBDialog *)dialog {
    NSLog(@"Dialog dismissed.");
}

- (void)dialog:(FBDialog*)dialog didFailWithError:(NSError *)error {
    NSLog(@"Error message: %@", [[error userInfo] objectForKey:@"error_msg"]);
    //[self showMessage:@"Oops, something went haywire."];
    if (!([actionTarget isKindOfClass:[UIView class]] || ([actionTarget isKindOfClass:[UIViewController class]]))) {
        return;
    }
    MessageBox *message = nil;
    if ([actionTarget isKindOfClass:[UIView class]]) {
        message = [[[MessageBox alloc] initWithSuperview:((UIView *)actionTarget) hasNavigationBar:YES] autorelease];
    }
    if ([actionTarget isKindOfClass:[UIViewController class]]) {
        message = [[[MessageBox alloc] initWithSuperview:((UIView *)actionTarget) hasNavigationBar:YES] autorelease];
    }

    [message showMessage:@"There Was An Error To Sent Invitation."];
    
}




#pragma mark - FBSessionDelegate Methods
/**
 * Called when the user has logged in successfully.
 */
- (void)fbDidLogin {
    //[[self.view viewWithTag:101] removeFromSuperview];
   
    //login
    //[pendingApiCallsController userDidGrantPermission];
    self.login = YES;
    //[self openFaceBookSharingDialog];
    [self uploadImageToPhtoAlbumWithTarget:actionTarget Description:description andShareText:text shareIamge:image linkedURL:urlString];
}

-(void)fbDidExtendToken:(NSString *)accessToken expiresAt:(NSDate *)expiresAt {
    NSLog(@"token extended");
    [self storeAuthData:accessToken expiresAt:expiresAt];
}

/**
 * Called when the user canceled the authorization dialog.
 */
-(void)fbDidNotLogin:(BOOL)cancelled {
    //[pendingApiCallsController userDidNotGrantPermission];
    self.login = NO;
}

/**
 * Called when the request logout has succeeded.
 */
- (void)fbDidLogout {
    // pendingApiCallsController = nil;
    
    // Remove saved authorization information if it exists and it is
    // ok to clear it (logout, session invalid, app unauthorized)
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults removeObjectForKey:@"FBAccessTokenKey"];
    [defaults removeObjectForKey:@"FBExpirationDateKey"];
    [defaults synchronize];
    // [self showLoggedOut];
    self.login = NO;
}

/**
 * Called when the session has expired.
 */
- (void)fbSessionInvalidated {
    UIAlertView *alertView = [[UIAlertView alloc]
                              initWithTitle:@"Auth Exception"
                              message:@"Your session has expired."
                              delegate:nil
                              cancelButtonTitle:@"OK"
                              otherButtonTitles:nil,
                              nil];
    [alertView show];
    [alertView release];
    [self fbDidLogout];
}

#pragma mark - FBRequestDelegate Methods
/**
 * Called when the Facebook API request has returned a response. This callback
 * gives you access to the raw response. It's called before
 * (void)request:(FBRequest *)request didLoad:(id)result,
 * which is passed the parsed response object.
 */
- (void)request:(FBRequest *)request didReceiveResponse:(NSURLResponse *)response {
    NSLog(@"received response");
}

/**
 * Called when a request returns and its response has been parsed into
 * an object. The resulting object may be a dictionary, an array, a string,
 * or a number, depending on the format of the API response. If you need access
 * to the raw response, use:
 *
 * (void)request:(FBRequest *)request
 *      didReceiveResponse:(NSURLResponse *)response
 */
/*- (void)request:(FBRequest *)request didLoad:(id)result {
    //NSLog(@"RESULT : %@",result);
    if ([result isKindOfClass:[NSArray class]]) {
        if ([result count] > 0) {
            result = [result objectAtIndex:0];
        }
        
    }
    if ([result objectForKey:@"uid"]) {
        
    }
    if ([result objectForKey:@"id"]) {
        NSLog(@"IMAGE UPLOAD RESPONSE : %@",result);
    }*/
    /*
     // This callback can be a result of getting the user's basic
     // information or getting the user's permissions.
     if ([result objectForKey:@"name"]) {
     // If basic information callback, set the UI objects to
     // display this.
     */
    
//}

- (void)request:(FBRequest *)request didLoad:(id)result {
    
//    if ([result isKindOfClass:[NSArray class]] && ([result count] > 0)) {
//        result = [result objectAtIndex:0];
//    }
    if (currentAPICall == kAPIGraphUserPhotosPost) {
        if ([actionTarget isKindOfClass:[UIViewController class]]) {
            [[[[MessageBox alloc] initWithSuperview:((UIViewController *)actionTarget).view hasNavigationBar:NO] autorelease] showMessage:@"KillShot added to Your WarHit Album."];
        }
        else if ([actionTarget isKindOfClass:[UIView class]]) {
            [[[[MessageBox alloc] initWithSuperview:((UIView *)actionTarget) hasNavigationBar:NO] autorelease] showMessage:@"KillShot added to Your WarHit Album."];
        }
        else {
            NSLog(@"Can not add Message Box");
        }
        
    }
    
//    switch (currentAPICall) {
//        case kDialogFeedUser:
//            //[MessageBox]
//            break;
//        case kAPIGraphPhotoData: // step 3
//        {
//            // Facebook doesn't allow linking to images on fbcdn.net.  So for now use default thumb stored on Picasa
//            //NSString *thumbURL = kDefaultThumbURL;
//            NSString *imageLink = [NSString stringWithFormat:[result objectForKey:@"link"]];    
//            
//            currentAPICall = kDialogFeedUser;
//            SBJSON *jsonWriter = [[SBJSON new] autorelease];
//            NSArray* actionLinks = [NSArray arrayWithObjects:[NSDictionary dictionaryWithObjectsAndKeys:
//                                                              @"Get Started",@"name",@"http://www.objectsol.in/",@"link", nil], nil];
//            NSString *actionLinksStr = [jsonWriter stringWithObject:actionLinks];
//            //The "to" parameter targets the post to a friend
//            //NSString *name = [NSString stringWithFormat:@"%@! Think you're smarter than me? Prove it with TrivPals!",freindName];
//            
//            NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
//                                           //[self.dictionary objectForKey:@"id"], @"to",
//                                           //name, @"name",
//                                           @"Try It!", @"caption",
//                                           @"Warhits is the latest iPhone game that allows you to play gun action with your freinds using GameCenter or Local Wi-Fi.", @"description",
//                                           imageLink, @"link",
//                                           //image, @"picture",
//                                           actionLinksStr, @"actions",
//                                           nil];
//            if (fileURLString.length > 0) {
//                [params setObject:fileURLString forKey:@"picture"];
//            }
//            [facebook dialog:@"feed"
//                   andParams:params
//                 andDelegate:self];
//
//            break;
//        }
//        case kAPIGraphUserPhotosPost: // step 2
//        {
//            
//            NSString *imageID = [NSString stringWithFormat:[result objectForKey:@"id"]];            
//            NSLog(@"id of uploaded screen image %@",imageID);
//            
//            currentAPICall = kAPIGraphPhotoData;
//            //appDelegate = (Scorecard4AppDelegate *)[[UIApplication sharedApplication] delegate];
//            
//            [self.facebook requestWithGraphPath:imageID
//                                           andDelegate:self];
//            break;
//        }
//    }
}

/**
 * Called when an error prevents the Facebook API request from completing
 * successfully.
 */
- (void)request:(FBRequest *)request didFailWithError:(NSError *)error {
    NSLog(@"Err message: %@", [[error userInfo] objectForKey:@"error_msg"]);
    NSLog(@"Err code: %d", [error code]);
}


#pragma mark FbGraph Callback Function
/**
 * This function is called by FbGraph after it's finished the authentication process
 **/
- (void)fbGraphCallback:(id)sender {
	
	if ( (fbGraph.accessToken == nil) || ([fbGraph.accessToken length] == 0) ) {
		
		NSLog(@"You pressed the 'cancel' or 'Dont Allow' button, you are NOT logged into Facebook...I require you to be logged in & approve access before you can do anything useful....");
		
		//restart the authentication process.....
		[fbGraph authenticateUserWithCallbackObject:self andSelector:@selector(fbGraphCallback:) andExtendedPermissions:@"user_photos,user_videos,publish_stream,offline_access,user_checkins,friends_checkins"];
		
	} else {
		
		NSLog(@"------------>CONGRATULATIONS<------------, You're logged into Facebook...  Your oAuth token is:  %@", fbGraph.accessToken);
        [[UIApplication sharedApplication] setStatusBarHidden:NO];
        [self performSelectorInBackground:@selector(shareImageAndTextToFaceBook) withObject:nil];
		
	}
    //    if ([actionTarget isKindOfClass:[UIViewController class]]) {
    //        ((UIViewController *)actionTarget).navigationController.navigationBarHidden = NO;
    //    }
    //    
    [[UIApplication sharedApplication] setStatusBarHidden:YES];
    
}


@end
