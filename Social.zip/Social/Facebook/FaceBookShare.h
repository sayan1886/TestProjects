//
//  FaceBookShare.h
//  WarHits
//
//  Created by Sayan on 12/07/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FBConnect.h"

typedef enum apiCall {
    kAPILogout,
    kAPIGraphUserPermissionsDelete,
    kDialogPermissionsExtended,
    kDialogRequestsSendToMany,
    kAPIGetAppUsersFriendsNotUsing,
    kAPIGetAppUsersFriendsUsing,
    kAPIFriendsForDialogRequests,
    kDialogRequestsSendToSelect,
    kAPIFriendsForTargetDialogRequests,
    kDialogRequestsSendToTarget,
    kDialogFeedUser,
    kAPIFriendsForDialogFeed,
    kDialogFeedFriend,
    kAPIGraphUserPermissions,
    kAPIGraphMe,
    kAPIGraphUserFriends,
    kDialogPermissionsCheckin,
    kDialogPermissionsCheckinForRecent,
    kDialogPermissionsCheckinForPlaces,
    kAPIGraphSearchPlace,
    kAPIGraphUserCheckins,
    kAPIGraphUserPhotosPost,
    kAPIGraphUserVideosPost,
    kAPIGraphPhotoData,
} FACEBOOK_API_CALL;

@protocol FaceBookObserver <NSObject>

@optional
    - (void) canShareTextAndImageWithFaceBook;
@end

@interface FaceBookShare : NSObject<FBSessionDelegate,FBRequestDelegate,FBDialogDelegate>{
    FACEBOOK_API_CALL currentAPICall;
    id actionTarget;
    Facebook *facebook;
    NSArray *permissions;
    BOOL login;
}

@property (nonatomic,assign,getter = isLoggedin) BOOL login;

+ (FaceBookShare *) facebookSharer;
//fbconnect
- (void) setupFaceBookLogin;
//- (void) uploadImageToPhtoAlbum;//:(UIImage *)shareImage andTarget:(id)target;
- (void) uploadImageToPhtoAlbumWithTarget:(id)target Description:(NSString *)desc andShareText:(NSString *)text_ shareIamge:(UIImage *)image_ linkedURL:(NSString *)urlString_;
//- (void) faceBookAuthorizeWithTarget:(id)target fileURLForImageToShare:(UIImage *)shareImage;
- (void) faceBookAuthorizeWithTarget:(id)target Description:(NSString *)desc andShareText:(NSString *)text_ shareIamge:(UIImage *)image_ linkedURL:(NSString *)urlString_;

- (void) openFaceBookSharingDialog;
- (void) facebookLogout;
//fbgraph
- (void) authenticateFaceBookForClientid:(NSString *)clientid andTarget:(id)target andShareText:(NSString *)text shareIamge:(UIImage *)image linkedURL:(NSString *)urlString needToDeleteCookies:(BOOL)delete;

@end
