//
//  TwitterShare.m
//  WarHits
//
//  Created by Sayan on 12/07/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "TwitterShare.h"
#import <Twitter/Twitter.h>

@implementation TwitterShare

+ (void) shareToTwitterText:(NSString *)text image:(UIImage *)image url:(NSURL *)url fromTarget:(id)target{
    if ([TWTweetComposeViewController canSendTweet]) {
        // Initialize Tweet Compose View Controller
        TWTweetComposeViewController *vc = [[[TWTweetComposeViewController alloc] init] autorelease];
        
        // Settin The Initial Text
        [vc setInitialText:text];
        
        // Adding an Image
        //UIImage *image = [UIImage imageNamed:@"sample.jpg"];
        [vc addImage:image];
        
        // Adding a URL
        //NSURL *url = [NSURL URLWithString:@"http://www.objectsol.in"];
        [vc addURL:url];
        //for uiviewcontroller
        if ([target isKindOfClass:[UIViewController class]]) {
            // Setting a Completing Handler
            [vc setCompletionHandler:^(TWTweetComposeViewControllerResult result) {
                [((UIViewController *)target) dismissModalViewControllerAnimated:YES];
            }];
            // Display Tweet Compose View Controller Modally
            [((UIViewController *)target) presentViewController:vc animated:YES completion:nil];
        }
        //for uiview
        else if ([target isKindOfClass:[UIView class]]) {
            id object;
            while (![object isKindOfClass:[UIViewController class]]) {
                object = [object superview];
            }
            [vc setCompletionHandler:^(TWTweetComposeViewControllerResult result) {
                [((UIViewController *)object) dismissModalViewControllerAnimated:YES];
            }];
            // Display Tweet Compose View Controller Modally
            [((UIViewController *)object) presentViewController:vc animated:YES completion:nil];
        }
        //nsobject and other class
        else {
            // Setting a Completing Handler
            //        [vc setCompletionHandler:^(TWTweetComposeViewControllerResult result) {
            //            [self dismissModalViewControllerAnimated:YES];
            //        }];
            //        
            //        // Display Tweet Compose View Controller Modally
            //        [self presentViewController:vc animated:YES completion:nil];
            return ;
        }
    } 
    else {
        // Show Alert View When The Application Cannot Send Tweets
        NSString *message = @"The application cannot send a tweet at the moment. This is because it cannot reach Twitter or you don't have a Twitter account associated with this device,please connect your twitter account using settings app.";
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Oops!" message:message delegate:nil cancelButtonTitle:@"Dismiss" otherButtonTitles:nil];
        [alertView show];
        [alertView release];
    }
    

}

@end
