//
//  TwitterShare.h
//  WarHits
//
//  Created by Sayan on 12/07/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TwitterShare : NSObject
+ (void) shareToTwitterText:(NSString *)text image:(UIImage *)image url:(NSURL *)url fromTarget:(id)target;
@end
