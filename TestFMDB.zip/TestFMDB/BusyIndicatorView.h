//
//  BusyIndicatorView.h
//  SwamiParthSarathi
//
//  Created by Sayan on 31/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BusyIndicatorView : UIView{
    UILabel *_loadingView;
    UIView *_loading;
    //UIActivityIndicatorView *_spinner;
    NSString *_loadingText;
}

@property (nonatomic,retain) UILabel *loadingView;
@property (nonatomic,retain) UIView *loading;
//@property (nonatomic,retain) UIActivityIndicatorView *spinner;
@property (nonatomic,retain) NSString *loadingText;

- (id)initWithFrame:(CGRect)frame andLoadingText:(NSString *)text;
+ (BusyIndicatorView *) defaultLoadingViewWithFrame:(CGRect)frame andText:(NSString *)loadingText;
+ (BusyIndicatorView *) defaultLoadingViewWithText:(NSString *)loadingText;
- (void) setText:(NSString *)text;
- (void) startLoading;
- (void) stopLoading;
- (BOOL) isAnimating;
- (void) networkIndicatorVisible:(BOOL)visible;

@end
