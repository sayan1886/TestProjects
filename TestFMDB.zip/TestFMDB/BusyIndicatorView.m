//
//  BusyIndicatorView.m
//  SwamiParthSarathi
//
//  Created by Sayan on 31/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "BusyIndicatorView.h"

@interface BusyIndicatorView (Private)

-(void) initializeSharedInstance;

@end

@implementation BusyIndicatorView (Private)

-(void) initializeSharedInstance{
    
}

@end

@implementation BusyIndicatorView

static BusyIndicatorView *_sharedInstance;

@synthesize loadingView = _loadingView;
@synthesize loading;
//@synthesize spinner = _spinner;
@synthesize loadingText = _loadingText;

#pragma mark - Initialize

- (id)initWithFrame:(CGRect)frame andLoadingText:(NSString *)text
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.loadingText = text;
        self.loading = [[[UIView alloc] initWithFrame:CGRectMake(7, 7, 270, 80)] autorelease];
        
        UILabel  *lblLoadingView=[[UILabel alloc]initWithFrame:CGRectMake(40,5,220,70)];
        lblLoadingView.text=self.loadingText;
        //lblLoadingView.backgroundColor = [UIColor colorWithRed:1.0 green:0.0 blue:0.0 alpha:0.3];
        lblLoadingView.font=[UIFont fontWithName:@"Verdana-Bold" size:17];
        lblLoadingView.textColor=[UIColor whiteColor];
        lblLoadingView.textAlignment=UITextAlignmentCenter;
        lblLoadingView.numberOfLines = 0;
        lblLoadingView.backgroundColor=[UIColor clearColor];
        UIActivityIndicatorView *spinner = [[[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(5, 22, 35, 35)] autorelease];
        spinner.activityIndicatorViewStyle = UIActivityIndicatorViewStyleWhite;
        spinner.autoresizingMask = (UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin);
        spinner.backgroundColor=[UIColor clearColor];
        spinner.opaque=YES;
        [loading addSubview:spinner];
        self.loadingView = lblLoadingView;
        [loading addSubview:lblLoadingView];
        [lblLoadingView release];
    }
    return self;
}

//convenient approach to initialize

+ (BusyIndicatorView *) defaultLoadingViewWithFrame:(CGRect)frame andText:(NSString *)loadingText{
    if (!_sharedInstance) {
        _sharedInstance = [[self alloc] initWithFrame:frame andLoadingText:loadingText];
        [_sharedInstance initializeSharedInstance];
    }
    return _sharedInstance;
}

+ (BusyIndicatorView *) defaultLoadingViewWithText:(NSString *)loadingText{
    if (!_sharedInstance) {
        _sharedInstance = [[self alloc] initWithFrame:CGRectZero andLoadingText:loadingText];
        [_sharedInstance initializeSharedInstance];
    }
    [_sharedInstance setText:loadingText];
    return _sharedInstance;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
    
}
*/

#pragma mark - Loading Text
- (void) setText:(NSString *)text{
    self.loadingText = text;
    self.loadingView.text = self.loadingText;
}
#pragma mark - Loading
-(void)startLoading
{
	UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"" message:@"" delegate:self cancelButtonTitle:nil otherButtonTitles:nil];
//    NSLog(@"Loading Text : %@",self.loadingText);
//    NSLog(@"TEXT : %@",self.loadingView.text);
	[alert addSubview:loading];
	[(UIAlertView *)[self.loading superview] show];
	[[self.loading.subviews objectAtIndex:0] startAnimating];
	[alert release];	
	
}

-(void)stopLoading
{
	[[self.loading.subviews objectAtIndex:0] stopAnimating];
	[(UIAlertView *)[self.loading superview] dismissWithClickedButtonIndex:0 animated:YES];
}

- (BOOL) isAnimating{
    UIActivityIndicatorView *animator =[self.loading.subviews objectAtIndex:0];
    return [animator isAnimating];
}

- (void) networkIndicatorVisible:(BOOL)visible{
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:visible];
}

@end
