//
//  SearchView.h
//  TestContacts
//
//  Created by Sayan on 13/08/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol SearchDelegate <NSObject>
- (void) didSearchFindResults:(NSArray *)results searching:(BOOL)search;
@optional
- (void) didSearchCancel;
@end

@interface SearchView : UIView <UITextFieldDelegate>{
    NSArray *searchContent;
    NSMutableArray *searchResults;
    UITextField *searchField;
    BOOL searching;
    
    id<SearchDelegate> delegate;
}

@property (nonatomic,retain) NSArray *searchContent;
@property (nonatomic,assign) id<SearchDelegate> delegate;

- (id)initWithFrame:(CGRect)frame andSearchContent:(NSArray *)content;

@end
