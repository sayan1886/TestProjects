//
//  TCContactsViewController.h
//  TestContacts
//
//  Created by Sayan on 13/08/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SearchView.h"
#import <AddressBookUI/AddressBookUI.h>

@interface TCContactsViewController : UIViewController<SearchDelegate,ABUnknownPersonViewControllerDelegate,ABNewPersonViewControllerDelegate,ABPeoplePickerNavigationControllerDelegate>{
    UITableView *_contactList;
    BOOL searching;
    BOOL editing;
    NSArray *contacts;
    NSMutableArray *sectionContents;
    NSArray *searchResults;
}

@property (retain, nonatomic) IBOutlet UITableView *contactList;
@property (retain,nonatomic) NSArray *contacts;
@property (retain,nonatomic) NSMutableArray *sectionContents;
@property (retain,nonatomic) NSArray *searchResults;

@end
