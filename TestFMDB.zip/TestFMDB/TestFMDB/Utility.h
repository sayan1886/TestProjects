//
//  Utility.h
//  TestFMDB
//
//  Created by Ashim Samanta on 04/09/12.
//  Copyright (c) 2012 Objectsol. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Utility : NSObject

+(NSString *)DatabasePath;
+(NSString *)createFriendTableQuery;

@end
