//
//  Utility.m
//  TestFMDB
//
//  Created by Ashim Samanta on 04/09/12.
//  Copyright (c) 2012 Objectsol. All rights reserved.
//

#import "Utility.h"
#import "Constant.h"

@implementation Utility

+(NSString *)DatabasePath
{
    NSString *str = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
   return [str stringByAppendingFormat:@"/%@", DBPATH];
}

+(NSString *)createFriendTableQuery
{
    return @"CREATE TABLE IF NOT EXISTS friendList(ID INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT,fid TEXT NOT NULL, username TEXT,first_name TEXT, last_name TEXT, picture TEXT, UNIQUE (fid))";
    //return @"CREATE TABLE IF NOT EXISTS friendList(ID INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT,fid TEXT UNIQUEKEY fid NOT NULL, username TEXT,first_name TEXT, last_name TEXT, picture TEXT)";//,email TEXT UNIQUEKEY)";
}


@end
