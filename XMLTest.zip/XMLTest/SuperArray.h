//
//  SuperArray.h
//  SPLibrary
//
//  Created by Sumit Kr Prasad on 30/09/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SuperDictionary.h"
@class SuperDictionary;
@interface SuperArray : NSObject 
{
	NSMutableArray* mutableArray;
	NSArray* _innerArray;
}
@property(readonly) NSMutableArray* mutableArray;

+ (SuperArray*) superArrayWithArray:(NSArray*)anArray;

- (id)initWithArray:(NSArray*)anArray;
- (void)addObject:(id)anObject;


//  will not throw out of range exceptions & will not return nil but instead @""
- (NSString*)stringAtIndex:(NSUInteger)index;

// will not throw out of range exceptions 
- (SuperArray*)superArrayAtIndex:(NSUInteger)index;

// will not throw out of range exceptions 
- (SuperDictionary*)superDictionaryAtIndex:(NSUInteger)index;

// will not throw out of range exception
- (void) removeObjectAtIndex:(NSUInteger)index; 

- (NSUInteger)count;

@end
