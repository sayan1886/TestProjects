//
//  SPCustomNavTool.m
//  GoalGetter
//
//  Created by Sumit Kr Prasad on 18/12/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "SPCustomNavTool.h"
#import "SPUtils.h"

#import </usr/include/objc/objc-class.h>
#define SP_kSCNavigationBarBackgroundImageTag 6183746
UIColor *SP_kSCNavigationBarTintColor;

@implementation UINavigationBar (SPBackgroundImage)


- (void)scInsertSubview:(UIView *)view atIndex:(NSInteger)index
{
    [self scInsertSubview:view atIndex:index];
	
    UIView *backgroundImageView = [self viewWithTag:SP_kSCNavigationBarBackgroundImageTag];
    if (backgroundImageView != nil)
    {
        [self scSendSubviewToBack:backgroundImageView];
    }
}

- (void)scSendSubviewToBack:(UIView *)view
{
    [self scSendSubviewToBack:view];
	
    UIView *backgroundImageView = [self viewWithTag:SP_kSCNavigationBarBackgroundImageTag];
    if (backgroundImageView != nil)
    {
        [self scSendSubviewToBack:backgroundImageView];
    }
}

@end

@implementation SPCustomNavTool
+ (void)initialize
{
	[SPUtils swizzleSelector:@selector(insertSubview:atIndex:)
				   ofClass:[UINavigationBar class]
			  withSelector:@selector(scInsertSubview:atIndex:)];
    [SPUtils swizzleSelector:@selector(sendSubviewToBack:)
				   ofClass:[UINavigationBar class]
			  withSelector:@selector(scSendSubviewToBack:)];
}
+(UIColor *)setNavBarColor:(int)color
{
	SP_kSCNavigationBarTintColor=[SPUtils colorFromHex:color];
	return SP_kSCNavigationBarTintColor;
}

+ (void)customizeNavigationController:(UINavigationController*)navigationController 
				 withHeaderImageNamed:(NSString*)imageName
{
    UINavigationBar *navBar = [navigationController navigationBar];
    [navBar setTintColor:SP_kSCNavigationBarTintColor];
	
    UIImageView *imageView = (UIImageView *)[navBar viewWithTag:SP_kSCNavigationBarBackgroundImageTag];
    if (imageView == nil)
    {
        imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:imageName]];
        [imageView setTag:SP_kSCNavigationBarBackgroundImageTag];
        [navBar insertSubview:imageView atIndex:0];
        [imageView release];
    }
}

+ (void)customizeNavigationController:(UINavigationController*)navigationController 
				  withHeaderImageView:(UIImageView*)navImageView
{
    UINavigationBar *navBar = [navigationController navigationBar];
    [navBar setTintColor:SP_kSCNavigationBarTintColor];
	
    UIImageView *imageView = (UIImageView *)[navBar viewWithTag:SP_kSCNavigationBarBackgroundImageTag];
    if (imageView == nil)
    {
        imageView = navImageView;
        [imageView setTag:SP_kSCNavigationBarBackgroundImageTag];
        [navBar insertSubview:imageView atIndex:0];
        [imageView release];
    }
}


- (void)dealloc {
    [super dealloc];
}


@end
