//
//  SuperDictonary.m
//  SPLibrary
//
//  Created by Sumit Kr Prasad on 30/09/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "SuperDictionary.h"


@implementation SuperDictionary
- (id) initWithDictionary:(NSDictionary*)aDictionary
{
	if(self = [super init])
	{
		if([aDictionary isKindOfClass:[NSDictionary class]])
		{
			
			mutableDictionary = [[NSMutableDictionary dictionaryWithDictionary:aDictionary] retain];
		}
		else 
		{
			////NSLog(@"Could not set internal dictionary as %@ is not of type Dictionary", aDictionary);
		}
	}
	return self;
}


+ (SuperDictionary*) superDictionaryWithDictionary:(NSDictionary*)aDictionary
{
	return [[[SuperDictionary alloc] initWithDictionary:aDictionary] autorelease];
}

- (NSMutableDictionary*) mutableDictionary
{
	return mutableDictionary;
}

- (BOOL) isValid
{
	return !!mutableDictionary;
}


- (NSString*) stringForKey:(NSString*)aKey // nil strings are converted to empty strings like: @""
{
	if(!mutableDictionary)
	{
		////NSLog(@"SafeDictionary::stringForKey: Warning: internal dictionary is nil");
		return @"";
	}
	// key must be a string
	if(![aKey isKindOfClass:[NSString class]])
	{
		////NSLog(@"SafeDictionary::stringForKey Warning: nonString key used to access object from dictionary %@", mutableDictionary);
		return @"";
	}
	
	id value_obj = [mutableDictionary objectForKey:aKey];
	if(value_obj == nil)
	{
		////NSLog(@"SafeDictionary::stringForKey Warning: nil value found for key %@", aKey);
		return @"";
	}
	
	else if(!([value_obj isKindOfClass:[NSString class]] || [value_obj isKindOfClass:[NSNumber class]] ) )
	{
		////NSLog(@"SafeDictionary::stringForKey Warning: non-string value found for key %@", aKey);
		return @"";
	}
	
	return [value_obj description]; // take desciption just incase it's a numer
	
}

- (BOOL) stringIsDefinedForKey:(NSString*)aKey // returns false when string at index is nil
{
	if(!mutableDictionary)
	{
		////NSLog(@"SafeDictionary::stringIsDefinedForKey: Warning: internal dictionary is nil");
		return NO;
	}
	// key must be a string
	if(![aKey isKindOfClass:[NSString class]])
	{
		////NSLog(@"SafeDictionary::stringIsDefinedForKey Warning: nonString key used to access object with method stringIsDefinedForKey for internal dictionary %@",  mutableDictionary);
		return NO;
	}
	id value_obj = [mutableDictionary objectForKey:aKey];
	if(![value_obj isKindOfClass:[NSString class]])
	{
		////NSLog(@"SafeDictionary::stringIsDefinedForKey Warning: non-string value found for key %@", aKey);
		return NO;
	}
	
	
	return (value_obj != nil);
	
}

- (SuperArray*) superArrayForKey:(NSString*)aKey
{
	if(!mutableDictionary)
	{
		////NSLog(@"SuperDictionary::superArrayForKey: Warning: internal dictionary is nil");
		return nil;
	}
	// key must be a string
	if(![aKey isKindOfClass:[NSString class]])
	{
		////NSLog(@"SuperDictionary::superArrayForKey Warning: nonString key used to access object from dictionary %@", mutableDictionary);
		return nil;
	}
	
	id value_obj = [mutableDictionary objectForKey:aKey];
	if(value_obj == nil)
	{
		////NSLog(@"SuperDictionary::superArrayForKey Warning nil value found for key %@", aKey);
		return nil;
	}
	else if(!([value_obj isKindOfClass:[NSArray class]] || [value_obj isKindOfClass:[SuperArray class]] ))
	{
		////NSLog(@"SuperDictionary::superArrayForKey Warning non-array value found for key %@", aKey);
		return nil;
	}
	if([value_obj isKindOfClass:[SuperArray class]])
	{
		return (SuperArray*)value_obj;
	}
	else
	{
		return [[[SuperArray alloc] initWithArray:value_obj] autorelease];
	}
}

- (SuperDictionary*) safeDictionaryForKey:(NSString*)aKey
{
	if(!mutableDictionary)
	{
		////NSLog(@"SuperDictionary::superDictionaryForKey: Warning: internal dictionary is nil");
		return nil;
	}	
	// key must be a string
	if(![aKey isKindOfClass:[NSString class]])
	{
		////NSLog(@"SuperDictionary::superDictionaryForKey Warning: nonString key used to access object from dictionary %@", mutableDictionary);
		return nil;
	}
	
	id value_obj = [mutableDictionary objectForKey:aKey];
	if(value_obj == nil)
	{
		////NSLog(@"SuperDictionary::superDictionaryForKey Warning nil value found for key %@", aKey);
		return nil;
	}
	else if(!([value_obj isKindOfClass:[NSDictionary class]] || [value_obj isKindOfClass:[SuperDictionary class]] ))
	{
		////NSLog(@"SuperDictionary::superDictionaryForKey Warning non-dictionary value found for key %@", aKey);
		return nil;
	}
	if([value_obj isKindOfClass:[SuperDictionary class]])
	{
		return (SuperDictionary*)value_obj;
	}
	else
	{
		return [[[SuperDictionary alloc] initWithDictionary:value_obj] autorelease];
	}
}

- (id) objectForKey:(NSString*)aKey
{
	if(!mutableDictionary)
	{
		////NSLog(@"SuperDictionary::superDictionaryForKey: Warning: internal dictionary is nil");
		return nil;
	}	
	// key must be a string
	if(![aKey isKindOfClass:[NSString class]])
	{
		////NSLog(@"SuperDictionary::superDictionaryForKey Warning: nonString key used to access object from dictionary %@", mutableDictionary);
		return nil;
	}
	
	id value_obj = [mutableDictionary objectForKey:aKey];
	if(value_obj == nil)
	{
		////NSLog(@"SuperDictionary::superDictionaryForKey Warning nil value found for key %@", aKey);
		return nil;
	}
	else 
	{
		return value_obj;
	}
	
}

- (void) setObject:(id)anObject forKey:(NSString*)aKey // if object is nil, simply does nothing
{
	
	if(!mutableDictionary)
	{
		////NSLog(@"SafeDictionary::setObject:forKey: Warning: internal dictionary is nil");
		return;
	}
	
	if(![aKey isKindOfClass:[NSString class]])
	{
		////NSLog(@"SafeDictionary::setObject:forKey: Warning: ignored attempt to use nonString key to set object %@", anObject);
		return;
	}
	
	if(anObject == nil)
	{
		////NSLog(@"SafeDictionary::setObject:forKey: Warning ignored attempt to set nil object for key %@", aKey);
		return;
	}
	
	if(![mutableDictionary isKindOfClass:[NSDictionary class]])
	{
		////NSLog(@"SafeDictionary::setObject:forKey: Warning attempted to set object on non-dictionary!");
		return;
	}
	
	[mutableDictionary setObject:anObject forKey:aKey];
	
}
- (NSArray*) allKeys
{
	if(!mutableDictionary)
	{
		////NSLog(@"SafeDictionary::allKeys: Warning: internal dictionary is nil");
		return nil;
	}	
	
	if(![mutableDictionary isKindOfClass:[NSDictionary class]])
	{
		////NSLog(@"SafeDictionary::allKeys Warning non-dictionary value found for internal dictionary!");
		return nil;
	}
	return [mutableDictionary allKeys];
}

- (NSUInteger)count
{
	return [mutableDictionary count];
}


- (NSString*)description
{
	return [NSString stringWithFormat:@"<SuperDictionary> mutableDictionary contents: %@", [mutableDictionary description]];
}

- (void)dealloc 
{
	[mutableDictionary release];
    [super dealloc];
}

@end
