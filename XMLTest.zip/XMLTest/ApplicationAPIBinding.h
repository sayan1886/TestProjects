//
//  ApplicationAPIBinding.h
//  GoalGetter
//
//  Created by Sumit Kr Prasad on 19/12/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface ApplicationAPIBinding : NSObject {

}

@end
