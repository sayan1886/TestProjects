//
//  SPCustomNavTool.h
//  GoalGetter
//
//  Created by Sumit Kr Prasad on 18/12/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UINavigationBar (SPBackgroundImage)

- (void)scInsertSubview:(UIView *)view atIndex:(NSInteger)index;
- (void)scSendSubviewToBack:(UIView *)view;

@end
@interface SPCustomNavTool : NSObject {

}
+(UIColor *)setNavBarColor:(int)color;
+ (void)customizeNavigationController:(UINavigationController*)navigationController 
				 withHeaderImageNamed:(NSString*)imageName;
+ (void)customizeNavigationController:(UINavigationController*)navigationController 
				  withHeaderImageView:(UIImageView*)navImageView;
@end
