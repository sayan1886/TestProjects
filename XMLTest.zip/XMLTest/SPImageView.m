//
//  SPImageView.m
//  SPLibrary
//
//  Created by Sumit Kr Prasad on 01/10/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "SPImageView.h"


@implementation SPImageView
- (id) initWithImageNamed:(NSString*) imageName  memLog:(BOOL)memlog 
{
	if(!imageName)
	{
		////////NSLog(@"cannot create image with nil image name");
	}
	
	isAllocationsAndDeallocations = YES; //memlog;
	
	NSArray* fileName_ary = [imageName componentsSeparatedByString:@"."];
	NSString* filePath = [[NSBundle mainBundle] pathForResource:[fileName_ary objectAtIndex:0] 
														 ofType:[fileName_ary objectAtIndex:1]];  
	UIImage* image = [UIImage imageWithContentsOfFile:filePath];
	
	if(image.size.width < 1 && ![imageName isEqual:@"nil.jpg"])
	{
		////////NSLog(@"Image [%@] may not exist", imageName);
	}
	if(self = [super initWithImage:[UIImage imageWithContentsOfFile:filePath]])
	{
		strImageName = [imageName copy];
		if(YES || isAllocationsAndDeallocations)
		{
			self.userInteractionEnabled = YES;
			NSLog(@">>>>>>> Performing alloc of image %@", strImageName);
		}
		
	}
	return self;
}

- (void)dealloc 
{
	if(YES || isAllocationsAndDeallocations)
	{
		NSLog(@"<<<<<<< Performing dealloc of image %@", strImageName);
	}
	[strImageName release];
    [super dealloc];
}

@end
