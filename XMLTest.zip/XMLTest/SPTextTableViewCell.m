//
//  SPTextTableViewCell.m
//  SPLibrary
//
//  Created by Sumit Kr Prasad on 01/10/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "SPTextTableViewCell.h"
#import "SPUtils.h"

@implementation SPTextTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if ((self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])) 
	{
        // Initialization code
		//Text
		lblTitleText = [[[UILabel alloc] initWithFrame:CGRectMake(0 + 0, 7, 200, 50)] autorelease];
		lblTitleText.numberOfLines = 0;
		lblTitleText.font = [UIFont fontWithName:@"Helvetica" size:15];
		lblTitleText.backgroundColor = [UIColor clearColor];
		lblTitleText.textColor = [SPUtils colorFromHex:0x233F65];
		[self addSubview:lblTitleText];
    }
    return self;
}

-(void)setDictionary:(SuperDictionary *)dict
{
	dictionary=[dict retain];
}
-(SuperDictionary *)dictionary
{
	return dictionary;
}



- (void)dealloc {
    [super dealloc];
}


@end
