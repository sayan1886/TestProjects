//
//  XPathParser.m
//  XMLTest
//
//  Created by Sayan Chatterjee on 31/01/11.
//  Copyright 2011 ObjectSol. All rights reserved.
//

#import "XPathParser.h"
#import "XPathQuery.h"
#import "AsyncURLConnection.h"

@implementation XPathParser

@synthesize conn,element,parseQuery;

- (id) init{
	if (self) {
		[super init];
		//[self.conn init];
		self.element = [[NSArray alloc]init];
	}
	return self;
}

-(void) doParse:(NSString *)query{

	AsyncURLConnection *myCon = [[AsyncURLConnection alloc] init];
	self.conn	 = myCon;
	myCon.callback = self;
	[myCon release];
	[self.conn connectToURL];
	self.parseQuery = query;
		
}

- (void) handleSuccess{
	NSLog(@"SAYAN");
	//NSLog(@"XML : %@",self.element);
	NSData *xmlData = [[NSData alloc] init];
	xmlData = [self.conn resultBuffer];
	NSArray *xmlArr  = [[NSArray alloc] initWithArray: PerformXMLXPathQuery(xmlData, self.parseQuery)];
	self.element = xmlArr;
	[xmlArr release];
	NSLog(@"Xml String : %@",self.conn.bufferedURL);
	NSLog(@"XML DATA : %@",xmlData);
	NSLog(@"Parse® data : %@",self.element);
}

- (void) handleError{

}

/*- (NSArray *)  element{
	NSLog(@"SAYAN....");
	return [self.element autorelease];
}*/

- (void) dealloc{
	[self.conn release];
	[self.element release];
	[super dealloc];
}

@end
