//
//  XMLTestViewController.h
//  XMLTest
//
//  Created by Sayan Chatterjee on 18/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class XPathParser;

@class MyTools;

@interface XMLTestViewController : UIViewController {

	XPathParser *xpathParser;
	
	MyTools *aTools;
	UIView *loadingView;
	
}

- (void) startParsing;
- (void) stopParsing;

@property (nonatomic,retain) XPathParser *xpathParser;


@end

