//
//  SuperArray.m
//  SPLibrary
//
//  Created by Sumit Kr Prasad on 30/09/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "SuperArray.h"


@implementation SuperArray
@synthesize mutableArray;
- (id)initWithArray:(NSArray*)anArray
{
	if(self = [super init])
	{
		if([anArray isKindOfClass:[NSArray class]])
		{
			mutableArray = [[NSMutableArray arrayWithArray:anArray] retain];
		}
		else {
			////NSLog(@"Could not create safe array from array %@", anArray);
		}
		
	}
	return self;
}
+ (SuperArray*) superArrayWithArray:(NSArray*)anArray
{
	return [[[SuperArray alloc] initWithArray:anArray] autorelease];
}



- (void)addObject:(id)anObject
{
	if(!mutableArray)
	{
		////NSLog(@"SafeArray::addObject: Warning: internal array is nil");
		return;
	}
	if(!anObject)
	{
		////NSLog(@"SafeArray::addObject: Warning ignored attempt to set nil object");
		return;		
	}
	[mutableArray addObject:anObject];
}

- (void) removeObjectAtIndex:(NSUInteger)index
{
	if(!mutableArray)
	{
		////NSLog(@"SafeArray::removeObjectAtIndex: Warning: internal array is nil");
	}
	if( (index > -1) && (index < [self count]) )
	{
		[mutableArray removeObjectAtIndex:index];
	}
	else 
	{
		////NSLog(@"SafeArray::removeObjectAtIndex: Warning: index out of range");
	}	
}



- (NSString*)stringAtIndex:(NSUInteger)index
{
	if(!mutableArray)
	{
		////NSLog(@"SafeArray::stringAtIndex: Warning: internal array is nil");
		return @"";
	}
	
	if(index < [self count])
	{
		id value_obj = [mutableArray objectAtIndex:index];
		
		if( !([value_obj isKindOfClass:[NSString class]] || [value_obj isKindOfClass:[NSNumber class]]) )
		{
			////NSLog(@"SafeArray::stringAtIndex: Warning: non-string value found");
			return @"";
		}
		return [value_obj description];
	}
	else 
	{
		////NSLog(@"SafeArray::stringAtIndex: Warning: index out of range");
		return @"";
	}
}


- (SuperArray*)superArrayAtIndex:(NSUInteger)index
{
	if(!mutableArray)
	{
		////NSLog(@"SafeArray::safeArrayAtIndex: Warning: internal array is nil");
		return nil;
	}
	
	if(index < [self count])
	{
		id value_obj = [mutableArray objectAtIndex:index];
		
		if( !([value_obj isKindOfClass:[NSArray class]] || [value_obj isKindOfClass:[SuperArray class]]) )
		{
			////NSLog(@"SafeArray::safeArrayAtIndex: Warning: non-array value found");
			return nil;
		}
		
		if([value_obj isKindOfClass:[SuperArray class]])
		{
			return (SuperArray*)value_obj;
		}
		else
		{
			return [[[SuperArray alloc] initWithArray:value_obj] autorelease];
		}
	}
	else 
	{
		////NSLog(@"SafeArray::safeArrayAtIndex: Warning: index out of range");
		return nil;
	}	
}

- (SuperDictionary*)superDictionaryAtIndex:(NSUInteger)index
{
	if(!mutableArray)
	{
		////NSLog(@"SafeArray::safeDictionaryAtIndex: Warning: internal array is nil");
		return nil;
	}
	
	if(index < [self count])
	{
		id value_obj = [mutableArray objectAtIndex:index];
		
		if( !([value_obj isKindOfClass:[NSDictionary class]] || [value_obj isKindOfClass:[SuperDictionary class]]) )
		{
			////NSLog(@"SafeArray::safeDictionaryAtIndex: Warning: non-dictionary value found");
			return nil;
		}
		
		if([value_obj isKindOfClass:[SuperDictionary class]])
		{
			return (SuperDictionary*)value_obj;
		}
		else
		{
			return [[[SuperDictionary alloc] initWithDictionary:value_obj] autorelease];
		}
	}
	else 
	{
		NSLog(@"SuperArray::SuperDictionaryAtIndex: Warning: index (%i) out of range in array with %i elements.", 
			  index, [self count]);
		
		return nil;
	}	
}

- (id)objectAtIndex:(NSUInteger)index
{
	if(!mutableArray)
	{
		////NSLog(@"SafeArray::safeDictionaryAtIndex: Warning: internal array is nil");
		return nil;
	}
	
	if(index < [self count])
	{
		id value_obj = [mutableArray objectAtIndex:index];
		
		if( !value_obj )
		{
			////NSLog(@"SafeArray::safeDictionaryAtIndex: Warning: non-dictionary value found");
			return nil;
		}
		else 
			return value_obj;
	}
	else 
	{
		NSLog(@"SuperArray::SuperDictionaryAtIndex: Warning: index (%i) out of range in array with %i elements.", 
			  index, [self count]);
		
		return nil;
	}	
}

- (NSUInteger)count
{
	
	return [mutableArray count];
}

- (NSString*) description
{
	return [mutableArray description]; 
}

- (void)dealloc 
{
	[mutableArray release];
    [super dealloc];
}

@end
