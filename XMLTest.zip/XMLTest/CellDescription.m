//
//  CellDescription.m
//  SPLibrary
//
//  Created by Sumit Kr Prasad on 30/09/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "CellDescription.h"


@implementation CellDescription
@synthesize type,data,height,contentID,contentType;


- (id)initWithType:(NSString*) cellType  
			  data:(SuperDictionary*) cellData 
			height:(int) cellHeight
		 contentID:(NSString*)cellContentID
	   contentType:(NSString*)cellContentType
{
	if(self = [super init])
	{
		
		if (data && ![data isKindOfClass:[SuperDictionary class]]) 
		{
			NSLog(@"CD Dict %@", data);
			NSException *exception = [NSException exceptionWithName:@"HotTeaException"
									  
															 reason:@"The tea is too hot"  userInfo:nil];
			
			@throw exception; 
		}
		
		
		data = [cellData retain];
		type = [cellType retain];
		height = cellHeight;
		contentID = [cellContentID retain];
		contentType= [cellContentType retain];
	}
	
	return self;
}

@end
