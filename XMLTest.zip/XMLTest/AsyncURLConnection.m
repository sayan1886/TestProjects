//
//  AsyncURLConnection.m
//  XMLTest
//
//  Created by Sayan Chatterjee on 31/01/11.
//  Copyright 2011 ObjectSol. All rights reserved.
//

#import "AsyncURLConnection.h"
#import "XPathParser.h"
#import "MyTools.h"


@implementation AsyncURLConnection

@synthesize resultBuffer,toServerConnection,urlToBuffer,bufferedURL,flag;
@synthesize callback;




- (id) init {
	if (self) {
		// initialize variables 
		[super init];
		self.toServerConnection = nil;
		self.resultBuffer = nil;
		//self.urlToBuffer = (NSMutableString *)@"http://dev.mobiletakeout.com/export/locations/data.xml";
		self.urlToBuffer = (NSMutableString *)@"http://data.moliscgateway.com/afpdata/afpfeeds?feedPath=topics/olympics/index.xml";
		self.bufferedURL = (NSMutableString *)@"";
		self.flag = 0;
	}
	return self;
}

/*- (NSMutableData *) getResultBuffer{
	NSLog(@"SAYAN!!!!!");
	return [self.resultBuffer autorelease];
}*/

- (void) connectToURL{
	//if (self.toServerConnection == nil) {
		self.resultBuffer = [NSMutableData new];
		self.toServerConnection =[NSURLConnection connectionWithRequest:
									[NSURLRequest requestWithURL:
											[NSURL URLWithString:self.urlToBuffer]] 
											                      delegate:self];
	//}
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
	[resultBuffer appendData:data];
}

- (void) initializeVariablesAgain {
	[resultBuffer release], resultBuffer = nil;
	toServerConnection = nil;	
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
	NSString *localStr = [[NSString alloc] initWithData:resultBuffer encoding:NSASCIIStringEncoding];
	self.bufferedURL = (NSMutableString *)localStr;
	//[self.bufferedURL setString:[NSMutableString alloc] ];
	//NSLog(@"XMLSTring: %@",bufferedURL);
	//XPathParser *xpathParser = [[XPathParser alloc] init];
	//xpathParser.element = bufferedURL;
	self.flag = 0;
	if (self.callback) {
		if ([self.callback respondsToSelector:@selector(handleSuccess)]) {
			[self.callback handleSuccess];
		}
	}
	//[self initializeVariablesAgain];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
	//[self.bufferedURL setString:[error localizedDescription]];
	NSString *localStr = [[NSString alloc] initWithData:resultBuffer encoding:NSASCIIStringEncoding];
	self.bufferedURL = (NSMutableString *)localStr;
	//NSLog(@"XMLSTring: %@",bufferedURL);
	self.flag = 1;
	//[self initializeVariablesAgain];
	if (self.callback) {
		if ([self.callback respondsToSelector:@selector(handleError)]) {
			[self.callback handleError];
		}
	}
}

- (void) dealloc{

	[resultBuffer release], resultBuffer = nil;
	toServerConnection = nil;
	[super dealloc];
}

@end
