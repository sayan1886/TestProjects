/*
 *  SPTableCellProtocol.h
 *  SPLibrary
 *
 *  Created by Sumit Kr Prasad on 01/10/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#import <UIKit/UIKit.h>


@protocol SPTableCellProtocol <NSObject>

@required 
+ (NSString*) cellType;
+ (NSString*) cellHeight;

- (void) setDictionary:(NSDictionary*)dict;
- (NSDictionary*) dictionary;


- (void) cellDidAppear;
- (void) cellDidDissappear;
@end