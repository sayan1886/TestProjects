//
//  APIBindings.m
//  GoalGetter
//
//  Created by Sumit Kr Prasad on 19/12/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "APIBindings.h"

#define PROPERTY_TAG_TOKEN @"__prop__"
#define DECIMAL_POINT_TOKEN @"__dp__"
@implementation APIBindings
+ (NSString*) propertyTagStringFromDictionary:(NSMutableDictionary*)dict
{
	NSMutableString* propertyTags_str = [[NSMutableString alloc] initWithCapacity:0];
	NSArray* propertyNames = [dict allKeys];
	
	int numProperties = [propertyNames count];
	
	for(int i = 0; i < numProperties; i++)
	{
		NSString* propertyName  = [propertyNames objectAtIndex:i];
		NSString* propertyValue = [dict objectForKey:propertyName];
		if([SPUtils string:propertyValue containsSubstring:@"."])
		{
			propertyValue = [SPUtils string:propertyValue replaceSubstring:@"." withString:DECIMAL_POINT_TOKEN];
		}
		
		[propertyTags_str appendFormat: (i ? @",%@%@%@" : @"%@%@%@"), propertyName, PROPERTY_TAG_TOKEN, propertyValue];
	}
	
	return propertyTags_str;
}

/* So far handled in xml parser 
 // str is comma delimited tag string: key1_value1,key2_value2,...,keyn_valuen
 + (NSDictionary*) propertyTagDictionaryFromString:(NSString*)str
 {
 
 }
 */					   




NSString* md5( NSString *str )
{
	
	const char *cStr = [str UTF8String];
	unsigned char result[CC_MD5_DIGEST_LENGTH];
	CC_MD5( cStr, strlen(cStr), result );
	
	return [[NSString 
			 
			 stringWithFormat: @"%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X",
			 
			 result[0], result[1],
			 
			 result[2], result[3],
			 
			 result[4], result[5],
			 
			 result[6], result[7],
			 
			 result[8], result[9],
			 
			 result[10], result[11],
			 
			 result[12], result[13],
			 
			 result[14], result[15]
			 
			 ] lowercaseString];
}


+ (NSString*)generateSignature:(NSMutableDictionary*)vars
{
	
	
	NSMutableArray* sigGenArray = [NSMutableArray arrayWithCapacity:3];
	[sigGenArray addObject:API_PASSWORD];
	
	NSEnumerator *enumerator = [vars keyEnumerator];
	NSString* key;
	while ((key = (NSString*)[enumerator nextObject])) 
	{
		[sigGenArray addObject:[key stringByAppendingString:[vars objectForKey:key]]];
	}
	
	NSMutableArray* sigGenArraySorted = (NSMutableArray*)[sigGenArray sortedArrayUsingSelector:@selector(compare:)];
	//////////NSLog(@"Pre md5: %@", sigGenArraySorted);
	NSString* signatureGenStr = [sigGenArraySorted componentsJoinedByString:@""];
	return md5(signatureGenStr);
}

+ (SPRequester*) makeRequest:(NSString*)api_method  
				 paramters:(NSMutableDictionary*)vars 
		   responseHandler:(SEL)rh 
			failureHandler:(SEL)fh 
					target:(id)target
				success_cb:(SEL)success
				failure_cb:(SEL)failure

{
	return [self makeRequest:(NSString*)api_method  
				   paramters:(NSMutableDictionary*)vars 
			 responseHandler:(SEL)rh 
			  failureHandler:(SEL)fh 
					  target:(id)target
				  success_cb:(SEL)success
				  failure_cb:(SEL)failure
					   extra:nil];
}


+ (SPRequester*) makeRequest:(NSString*)api_method  
				 paramters:(NSMutableDictionary*)vars 
		   responseHandler:(SEL)rh 
			failureHandler:(SEL)fh 
					target:(id)target
				success_cb:(SEL)success
				failure_cb:(SEL)failure
					 extra:extraOrNil
{
	
	[vars setObject:api_method forKey:@"method"];
	[vars setObject:API_KEY forKey:@"api_key"];
	NSString* api_sig = [self generateSignature:vars];
	[vars setObject:api_sig forKey:@"api_sig"];
	//////////NSLog(@"signature gen string: %@", api_sig);
	
	APIResponseHandler* responseHandler = [[[APIResponseHandler alloc] 
											initWithResponseHandler:rh 
											failureHanlder:fh 
											target:target
											success_cb:success 
											failure_cb:failure
											extra:extraOrNil] autorelease];
	
	// autorelease responseHandler
	////////NSLog(@"Making request with url: %@", API_URL);
	SPRequester* r = [[(SPRequester*)[SPRequester alloc] initWithURL:API_URL actionTarget:responseHandler] autorelease];
	r.onFailure = @selector(onFailure:requester:);  //request is to invoke onFailure on responseHandler
	r.onResponse = @selector(onResponse:requester:);  //request is to invoke onSuccess on responseHandler
	responseHandler.requester = r;
	[r submit:vars  requestMethod:@"POST"];
	
	return r;
	
}


+ (SPRequester*) makeGetRequestWithURL:(NSString*)url
						   forAction:(NSString*)action
						   paramters:(NSMutableDictionary*)vars 
					 responseHandler:(SEL)rh 
					  failureHandler:(SEL)fh 
							  target:(id)target
						  success_cb:(SEL)success
						  failure_cb:(SEL)failure
							   extra:extraOrNil
{
	APIResponseHandler* responseHandler = [[[APIResponseHandler alloc] 
											initWithResponseHandler:rh 
											failureHanlder:fh 
											target:target
											success_cb:success 
											failure_cb:failure
											extra:extraOrNil] autorelease];
	
	NSString* actionURL = [url stringByAppendingFormat:@"/%@",action];
	//  ?app_key=%@&id=%@,[vars objectForKey:@"app_id"],[vars objectForKey:@"id"]];
	
	
	// autorelease responseHandler
	////NSLog(@"URL created: %@",actionURL);
	SPRequester* r = [[(SPRequester*)[SPRequester alloc] initWithURL:actionURL actionTarget:responseHandler] autorelease];
	r.onFailure = @selector(onFailure:requester:);  //request is to invoke onFailure on responseHandler
	r.onResponse = @selector(onResponse:requester:);  //request is to invoke onSuccess on responseHandler
	[r submit:vars  requestMethod:@"GET"];
	////NSLog(@"URL created: %@/%@",r.requestURL,vars);
	return r;
}

@end
