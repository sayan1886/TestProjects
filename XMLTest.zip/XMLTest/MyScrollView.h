//
//  MyScrollView.h
//  solitaire
//
//  Created by Ayon Das on 16/09/10.
//  Copyright 2009 rac it solutions pvt ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyScrollView : UIScrollView
{

}

@end
