//
//  SuperDictonary.h
//  SPLibrary
//
//  Created by Sumit Kr Prasad on 30/09/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SuperArray.h"
@class SuperArray;

@interface SuperDictionary : NSObject
{
	NSMutableDictionary* mutableDictionary;
}

@property(readonly) NSMutableDictionary* mutableDictionary;

+ (SuperDictionary*) superDictionaryWithDictionary:(NSDictionary*)aDictionary;

- (BOOL) isValid;

- (NSMutableDictionary*) mutableDictionary;
- (NSUInteger)count;

- (NSString*) stringForKey:(NSString*)aKey; // nil strings are converted to empty strings like: @""
- (BOOL) stringIsDefinedForKey:(NSString*)aKey; // returns false when string at index is nil

- (SuperArray*) superArrayForKey:(NSString*)aKey;
- (SuperDictionary*) safeDictionaryForKey:(NSString*)aKey;

- (void) setObject:(id)anObject forKey:(id)aKey; // if object is nil, simply does nothing
- (NSArray*) allKeys;



@end
