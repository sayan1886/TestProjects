//
//  CommentsList.m
//  RealWeatherGirls
//
//  Created by Sumit Kr Prasad on 03/08/10.
//  Copyright 2010 Treemo Labs. All rights reserved.
//

#import "CommentsList.h"


@implementation CommentsList
@synthesize totalItems,totalPages,pageSize,pageNumber,comments;



- (id) init
{
	if(self = [super init])
	{
		comments = [[NSMutableArray arrayWithCapacity:0] retain];
	}
	return self;
}


- (id) objectAtIndex:(NSUInteger)index
{
	return [comments objectAtIndex:index];
}

- (void) removeObjectAtIndext:(NSUInteger)index
{
	[comments removeObjectAtIndex:index];
}

- (void)addObject:(NSObject*) anObject
{
	[comments addObject:anObject];
}

- (NSUInteger) count
{
	return [comments count];
}


- (void) dealloc 
{
	[comments release];
	[super dealloc];
}

@end
