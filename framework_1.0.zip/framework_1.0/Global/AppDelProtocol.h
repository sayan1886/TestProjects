/*
 *  AppDelProtocol.h
 *  eMagazine
 *
 *  Created by SOHAMPAUL on 04/11/11.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */


@protocol AppDelProtocol

- (void)showMagazine:(BOOL)pdf;
- (void)dismissMagazine;
- (void)setUserID:(NSString*)_id;
- (NSString*)getUserID;
- (BOOL)is_iPad;
- (BOOL)isInternetReachable;
- (UIWindow*)getAppWindow;
@end