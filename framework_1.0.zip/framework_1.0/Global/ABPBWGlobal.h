//
//  ABPBWGlobal.h
//  ABPBW
//
//  Created by Sayan on 07/05/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//


#pragma mark Colors

#define SKYBLUE [UIColor colorWithRed:70.0/255.0 green:198.0/255.0 blue:248.0/255.0 alpha:1.0]

#define DARKRED [UIColor colorWithRed:260.0 / 255.0 green:59.0 / 255.0 blue:63.0 / 255.0 alpha:1.0]

#define LIGHTGRAY [UIColor colorWithRed:240.0/255.0 green:240.0/255.0 blue:240.0/255.0 alpha:1.0]
#define DARKGREEN [UIColor colorWithRed:0.000 green:0.216 blue:0.212 alpha:1.000]
#define RGBCOLOR(r,g,b) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1]
#define RGBACOLOR(r,g,b,a) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:(a)]
#define BACKGROUND_COLOR [UIColor colorWithRed:46.0 / 255.0   green:46.0 / 255.0 blue:46.0 / 255.0 alpha:1.0]

static NSString *reuseIdentifier = @"magazine";

#pragma mark System Versioning Preprocessor Macros


#define SYSTEM_VERSION_EQUAL_TO(v)                  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedSame)

#define SYSTEM_VERSION_GREATER_THAN(v)              ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedDescending)
#define SYSTEM_VERSION_LESS_THAN(v)                 ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedAscending)

#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v)  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN_OR_EQUAL_TO(v)  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedDescending)

#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_IPHONE_5_1 (version)([version compare:@"5.1" options:NSNumericSearch] != NSOrderedAscending)

static inline bool systemVersionGreaterThanOrEqualTo(NSString *iOSVersion){
    //NSLog(@"System Version ; %@",[[UIDevice currentDevice] systemVersion]);
    return ([[[UIDevice currentDevice] systemVersion] compare:iOSVersion options:NSNumericSearch] != NSOrderedAscending);
}

#pragma mark USER Details

#define USER_DETAILS @"user_details"
#define KEYCHAIN_SERVICE @"magazine"

#define USER_NAME @"userid"
#define PASSWORD @"password"
#define FNAME @"fname"
#define LNAME @"lname"
#define EMAIL @"email"
#define MOBILE @"phone"

#define SUBTYPE @"sub_type"
#define MAGID @"mag_id"
#define DURATION @"duration"

#define NEXT @"next"
#define PREVIOUS @"previous"

#define ITEM_TYPE @"itemType"
//#define DEVICE_ID @"device_id"
#define DEVICE_TOKEN @"device_id"
#define PUSH_ID @"push_id"
#define DEVICE_TYPE @"device_type"
#define DEVICE_TYPE_IPHONE @"iphone"
#define START_INDEX @"begin_index"
#define NO_OF_ITEMS @"grid_value"
#define HAS_MORE @"hasMore"

#pragma mark Store Keys

#define PDF_URL @"content_url"
#define PDF_IMAGE @"cover_image"
#define PDF_DESC @"description"
#define PDF_PURCHASED @"isPurchased"
#define ISSUE_DATE @"issue_date"
#define MAG_ID @"magazine_id"
#define MAG_TYPE @"magazine_type" //special or normal
#define MAG_PREVIEW @"preview_issue" //has preview or not
#define PREVIEW_URL @"preview_url"
#define PRICE @"price"

#pragma mark - Server 

//#define SERVER_URL @"http://115.113.197.105:8080/businessworld/"
#define SERVER_URL @"http://23.23.182.255/businessworld/"
#define APPLOAD @"apploader"
#define APPLOAD_AGAINST_USER @""
#define VALIDATE @"validateuser"
#define REGISTRATION @"register"
#define LOGIN @"login"
static inline NSString * forgotPasswordUpdate(NSString *username,NSString *email){
    return ([NSString stringWithFormat:@"emailupdate?userid=%@&email=%@&action=password",username,email]);
}

static inline NSString * forgotPassword(NSString *username){
    return ([NSString stringWithFormat:@"forgotpassword?userid=%@",username]);
}
//#define FORGOT_PASSWORD (userid) ([NSString stringWithFormat:@"forgotpassword?email=%@",userid])
#define TRANSACTION @"validaterecept"
#define GETCONTENT(path) ([NSString stringWithFormat:@"content?path=%@",path])

#pragma mark - Image And Files 

#define MagazineId @"magazine_id"
#define CoverPage  @"cover_image"
#define MAGAZINE @"magazine.pdf"
#define MAGAZINE_NAME @"magazine_name"
#define PREVIEW_COPY @"PreviewCopy.pdf"
#define MAG_COVER @"cover.png"
#define ADD_BANNER @"banner.png"

#pragma mark - Subscriptions

#define DEV true

#if DEV 
    static NSString *inappSecret = @"1e818c3535a441a995459d7abd213609";
#else
    static NSString *inappSecret = @"6f93e7b3811344b8965e5784a1fb2997";
#endif

#define INAPP_SECRET_RELEASE @"6f93e7b3811344b8965e5784a1fb2997"
#define INAPP_SECRET_DEV @"1e818c3535a441a995459d7abd213609"

#define SUBSCRIPTIONS3 @"com.abpdigital.ABPBW.sub3" //"sub3"
#define SUBSCRIPTIONS6 @"com.abpdigital.ABPBW.sub6" //@"sub6"
#define SUBSCRIPTIONS12 @"com.abpdigital.ABPBW.sub12" //@"sub12"

#pragma mark - Notification Name

#define MAGAZINE_DOWNLAOD_COMPLETED @"magazinedownloadcomplete"
#define REFRESH_USER_INTERFACE @"refreshui"

#pragma mark - Shared Secret
#define SECRET @"token"


