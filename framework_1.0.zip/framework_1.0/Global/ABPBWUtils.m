//
//  ABPBWUtils.m
//  ABPBW
//
//  Created by Sayan on 07/05/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ABPBWUtils.h"
#import "NSData+AES256.h"
#import "SFHFKeychainUtils.h"
#import "ABPBWGlobal.h"
#import <sys/xattr.h>

@implementation ABPBWUtils


+ (NSString *)urlEncodeValue:(NSString *)str
{
NSString *result = (NSString *) CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault, 
                                                                        (CFStringRef)str, NULL, CFSTR("?=&+_."), kCFStringEncodingUTF8);
return [result autorelease];
}

+ (NSString *) urlDecodeValue:(NSString *)str{
    NSString *result = [str stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    //(NSString *)CFURLCreateStringByReplacingPercentEscapesUsingEncoding(kCFAllocatorDefault, (CFStringRef)str, NULL,kCFStringEncodingUTF8);
    //result = [result stringByReplacingOccurrencesOfString:@"+" withString:@" "];
    //NSLog(@"URL DECODE STRING : %@",result);
    return result;
}

+ (NSString *) urlDecodeValue:(NSString *)str treatmentForPlus:(BOOL)tretment{
    NSString *result = [self urlDecodeValue:str];
    if (tretment) {
        result = [result stringByReplacingOccurrencesOfString:@"+" withString:@" "];
    }
    return result;
}

//returns Application document directory path
+ (NSString *) applicationDocumentsDirectory{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *basePath = ([paths count] > 0) ? [paths objectAtIndex:0] : nil;
    return basePath;
}

//returns Application document directory path
+ (NSString *) applicationLibraryDirectory{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSUserDomainMask, YES);
    NSString *basePath = ([paths count] > 0) ? [paths objectAtIndex:0] : nil;
    return basePath;
}

//Libray Caches Diretcory
+ (NSString *) libraryCachesDirectory{
    NSString *applicationLibraryPath = [[self class] applicationLibraryDirectory];
    return (applicationLibraryPath != nil) ? [applicationLibraryPath stringByAppendingPathComponent:@"/Caches"] : nil;
}

//do not back up in iCloud
/*
#ifdef  __IPHONE_OS_VERSION_MAX_ALLOWED
#if __IPHONE_5_1 <= __IPHONE_OS_VERSION_MAX_ALLOWED 
+ (BOOL)addSkipBackupAttributeToItemAtURL:(NSURL *)URL
{
    assert([[NSFileManager defaultManager] fileExistsAtPath: [URL path]]);
    
    NSError *error = nil;
    BOOL success = [URL setResourceValue: [NSNumber numberWithBool: YES] forKey:NSURLIsExcludedFromBackupKey error: &error];
    if(!success){
        NSLog(@"Error excluding %@ from backup %@", [URL lastPathComponent], error);
    }
    return success;
}
#else
+ (BOOL)addSkipBackupAttributeToItemAtURL:(NSURL *)URL
{
    assert([[NSFileManager defaultManager] fileExistsAtPath: [URL path]]);
    
    const char* filePath = [[URL path] fileSystemRepresentation];
    
    const char* attrName = "com.apple.MobileBackup";
    u_int8_t attrValue = 1;
    
    int result = setxattr(filePath, attrName, &attrValue, sizeof(attrValue), 0, 0);
    return result == 0;
}
#endif
#endif
*/

+ (BOOL)addSkipBackupAttributeToItemAtURL:(NSURL *)URL
{
    assert([[NSFileManager defaultManager] fileExistsAtPath: [URL path]]);
    BOOL success = NO;
    if (systemVersionGreaterThanOrEqualTo(@"5.1")) {
        NSError *error = nil;
         success = [URL setResourceValue: [NSNumber numberWithBool: YES] forKey:@"NSURLIsExcludedFromBackupKey" error: &error];
        if(!success){
            NSLog(@"Error excluding %@ from backup %@", [URL lastPathComponent], error);
        }
    }
    else {
        const char* filePath = [[URL path] fileSystemRepresentation];
        
        const char* attrName = "com.apple.MobileBackup";
        u_int8_t attrValue = 1;
        
        int result = setxattr(filePath, attrName, &attrValue, sizeof(attrValue), 0, 0);
        success = (result == 0);
    }
    return success;
}
 

/*
+ (BOOL)addSkipBackupAttributeToItemAtURL:(NSURL *)URL{
    BOOL sucess = NO;
    if (SYSTEM_VERSION_LESS_THAN_OR_EQUAL_TO(@"5.0.1"))
    {
        const char* filePath = [[URL path] fileSystemRepresentation];            
        const char* attrName = "com.apple.MobileBackup";
        u_int8_t attrValue = 1;
        
        int result = setxattr(filePath, attrName, &attrValue, sizeof(attrValue), 0, 0); 
        sucess = (result == 0);
    }          
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"5.1"))
    {
        NSError *error = nil;
        //[URL setResourceValue:[NSNumber numberWithBool:YES] forKey:NSURLIsExcludedFromBackupKey error:&error];
        [URL setResourceValue:[NSNumber numberWithBool:YES] forKey:@"NSURLIsExcludedFromBackupKey" error:&error];
        sucess = (error == nil);
    }
    return sucess;
}
 */

//crate diretctory at path if created return sucess else false

+ (BOOL) createDirectoryAtPath:(NSString *)path withInterMediateDirectory:(BOOL)isIntermediateDirectory{
    //NSLog(@"NEW DIR PATH : %@",path);
    if ([self fileExistsAtPath:path]) {
        return YES;
    }
    return [[NSFileManager defaultManager] createDirectoryAtPath:path
                                     withIntermediateDirectories:isIntermediateDirectory
                                                      attributes:nil
                                                           error:NULL];
}
//returns temp directory path
+ (NSString *) tempFilePathForDir:(NSString *)dirName{
    //[NSTemporaryDirectory() stringByAppendingPathComponent:[[NSProcessInfo processInfo] globallyUniqueString]];
    return [NSTemporaryDirectory() stringByAppendingPathComponent:dirName];
}

+ (BOOL) fileExistsAtPath:(NSString *)path {
    BOOL directory;
    return [[NSFileManager defaultManager] fileExistsAtPath:path isDirectory:&directory];
}

//write file 

+ (BOOL) writeContent:(NSData *)fileContent ToFile:(NSString *)fileName andPath:(NSString *)filePath {
    NSString *appendeFilePath = [NSString stringWithFormat:@"%@/%@",filePath,fileName];
    //NSLog(@"PATH : %@",appendeFilePath);
    NSError *error = nil;
    if ([[self class] fileExistsAtPath:filePath ]) {
        if ([[self class] fileExistsAtPath:appendeFilePath]) {
            if ([[self class] deleteFileAtPath:appendeFilePath ]) {
                NSLog(@"File Deleted Successfully");
            }
            else{
                NSLog(@"File Not Deleted");
            }
            
        }
        return [[NSFileManager defaultManager] createFileAtPath:appendeFilePath contents:fileContent attributes:nil]; //[fileContent AES256EncryptWithKey:AES256_KEY]
    }
    [[NSFileManager defaultManager] createDirectoryAtPath:filePath withIntermediateDirectories:NO attributes:nil error:&error];
    return [[NSFileManager defaultManager] createFileAtPath:appendeFilePath contents:fileContent  attributes:nil]; //[fileContent AES256EncryptWithKey:AES256_KEY]
}

//read file at given path

+ (NSData *) readFileAtPath:(NSString *)path {
    if ([[self class] fileExistsAtPath:path]) {
        return [[NSFileManager defaultManager] contentsAtPath:path];
    }
    return nil;
}

//encrypted write file with AES encryption

+ (BOOL) writeContent:(NSData *)fileContent ToFile:(NSString *)fileName andPath:(NSString *)filePath isEncrypted:(BOOL)encrypted andAESKeys:(NSString *)keys{
    NSString *appendeFilePath = [NSString stringWithFormat:@"%@/%@",filePath,fileName];
    //NSLog(@"PATH : %@",appendeFilePath);
    NSError *error = nil;
    if ([[self class] fileExistsAtPath:filePath ]) {
        if ([[self class] fileExistsAtPath:appendeFilePath]) {
            if ([[self class] deleteFileAtPath:appendeFilePath ]) {
                NSLog(@"File Deleted Successfully");
            }
            else{
                NSLog(@"File Not Deleted");
            }
            
        }
        return [[NSFileManager defaultManager] createFileAtPath:appendeFilePath contents:[fileContent AES256EncryptWithKey:keys] attributes:nil]; 
    }
    [[NSFileManager defaultManager] createDirectoryAtPath:filePath withIntermediateDirectories:NO attributes:nil error:&error];
    return [[NSFileManager defaultManager] createFileAtPath:appendeFilePath contents:[fileContent AES256EncryptWithKey:keys]  attributes:nil]; 
}

//read AES encrypted file

+ (NSData *) readAESEncryptedFileAtPAth:(NSString *)path andAESKey:(NSString *)key{
    if ([[self class] fileExistsAtPath:path]) {
        return [[[NSFileManager defaultManager] contentsAtPath:path] AES256DecryptWithKey:key];
    }
    return nil;
}

//delete file

+ (BOOL) deleteFileAtPath:(NSString *)filepath{
    NSError *err = nil;
    if ([[self class] fileExistsAtPath:filepath]) {
        [[NSFileManager defaultManager] removeItemAtPath:filepath error:&err];
    }
    else {
        return NO;
    }
    if (err) {
        return NO;
    }
    return YES;
}

//clear subviews

+ (void)clearSubviewsfromView:(UIView *)view{
    for(UIView *subview in [view subviews]){
        [subview removeFromSuperview];
    }
}

//getting a view if is it on the superview

+ (BOOL) isViewWithTag:(int)tag beingDispalyedOnSuperView:(UIView *)superview{
    for (UIView *view in [superview subviews]) {
        if (view.tag == tag) {
            return YES;
        }
    }
    return NO;
}

//rounded  croner view

+ (void) getRoundedCornerFroView:(UIView *)view withCornerRadius:(float)radius{
    // create round corners
    [view.layer setCornerRadius:radius];
    [view.layer setMasksToBounds:YES];
}

+ (float) getHeightForString:(NSString *)str forFontName:(NSString *)fontName adnSize:(float)size{
    CGSize maximumSize = CGSizeMake(300, 1000);
    UIFont *selectedFont = [UIFont fontWithName:fontName size:size];
    CGSize stringSize = [str sizeWithFont:selectedFont 
                        constrainedToSize:maximumSize 
                            lineBreakMode:UILineBreakModeWordWrap];
    return stringSize.height;
}

//Serialize to Persistence

+ (BOOL) serializeInputs:(NSArray *)inputs forKeys:(NSArray *)keys{
    int i = 0;
    if ([inputs count] != [keys count]) {
        return NO;
    }
    for (id objects in inputs) {
        [[NSUserDefaults standardUserDefaults] setObject:objects forKey:[keys objectAtIndex:i++]];
    }
    [[NSUserDefaults standardUserDefaults] synchronize];
    return YES;
}

+ (NSArray *) deserializeForKeys:(NSArray *)keys{
    NSMutableArray *toReturn = [[NSMutableArray new] autorelease];
    if ([keys count] == 0) {
        return nil;
    }
    int notFound = 0;
    for (NSString *key in keys) {
        if ([[NSUserDefaults standardUserDefaults] objectForKey:key]){
            [toReturn addObject:[[NSUserDefaults standardUserDefaults] objectForKey:key]];
        }
        else{
            notFound++;
        }
    }
    [[NSUserDefaults standardUserDefaults] synchronize];
    if (notFound == [keys count]) {
        return nil;
    }
    return toReturn;
}

+ (BOOL) removeSerializableForKeys:(NSArray *)keys{
    if ([keys count] == 0) {
        return NO;
    }
    for (NSString *key in keys) {
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:key];
    }
    [[NSUserDefaults standardUserDefaults] synchronize];
    return YES;
}

#pragma mark - USERDETAILS

+ (BOOL) storeUserDetailsInKeyChain:(NSDictionary *)userDetails{
    NSError *err=nil;
    [[self class] serializeInputs:[NSArray arrayWithObject:userDetails] forKeys:[NSArray arrayWithObject:USER_DETAILS]];
    return [SFHFKeychainUtils storeUsername:[userDetails objectForKey:USER_NAME] andPassword:[userDetails objectForKey:PASSWORD] forServiceName:KEYCHAIN_SERVICE updateExisting:YES error:&err];
}

+ (BOOL) deleteUserDetailsForUserName:(NSString *)userName{
    NSError *err=nil;
    [[self class] removeSerializableForKeys:[NSArray arrayWithObject:USER_DETAILS]];
    return [SFHFKeychainUtils deleteItemForUsername:userName andServiceName:KEYCHAIN_SERVICE error:&err];
}

+ (NSDictionary *) getUserDetails{
    
    if([[self class] deserializeForKeys:[NSArray arrayWithObject:USER_DETAILS]]) 
        return [[[self class] deserializeForKeys:[NSArray arrayWithObject:USER_DETAILS]] objectAtIndex:0];
    else
        return nil;
}

+ (NSString *) getPasswordForUserName:(NSString *)userName{
    NSError *err=nil;
    return [SFHFKeychainUtils getPasswordForUsername:userName andServiceName:KEYCHAIN_SERVICE error:&err];
}

+ (BOOL) validateDictionaryItem:(NSDictionary *)dict forKey:(NSString *)key{
    if ([dict objectForKey:key]) {
        if ([[dict objectForKey:key] isKindOfClass:[NSString class]]) {
            if (((NSString *)[dict objectForKey:key]).length > 0) {
                return YES;
            }
        }
        if ([[dict objectForKey:key] isKindOfClass:[NSArray class]]) {
            if (((NSArray *)[dict objectForKey:key]).count > 0) {
                return YES;
            }
        }
        if ([[dict objectForKey:key] isKindOfClass:[NSDictionary class]]) {
            if (((NSDictionary *)[dict objectForKey:key]).count > 0) {
                return YES;
            }
        }
        if ([[dict objectForKey:key] isKindOfClass:[NSDecimalNumber class]]) {
            return NO;
        }
    }
    return NO;
}


@end

