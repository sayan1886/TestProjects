//
//  ABPBWUtils.h
//  ABPBW
//
//  Created by Sayan on 07/05/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Utils.h"

@interface ABPBWUtils : Utils

+ (NSString *)urlEncodeValue:(NSString *)str;
+ (NSString *) urlDecodeValue:(NSString *)str;
+ (NSString *) urlDecodeValue:(NSString *)str treatmentForPlus:(BOOL)tretment;
+ (NSString *) applicationDocumentsDirectory;
+ (NSString *) applicationLibraryDirectory;
+ (BOOL)addSkipBackupAttributeToItemAtURL:(NSURL *)URL;
+ (NSString *) libraryCachesDirectory;
+ (BOOL) createDirectoryAtPath:(NSString *)path withInterMediateDirectory:(BOOL)isIntermediateDirectory;
+ (NSString *) tempFilePathForDir:(NSString *)dirName;
+ (BOOL) fileExistsAtPath:(NSString *)path ;
+ (BOOL) deleteFileAtPath:(NSString *)filepath;
+ (BOOL) writeContent:(NSData *)fileContent ToFile:(NSString *)fileName andPath:(NSString *)filePath ;
+ (NSData *) readFileAtPath:(NSString *)path ;
+ (BOOL) writeContent:(NSData *)fileContent ToFile:(NSString *)fileName andPath:(NSString *)filePath isEncrypted:(BOOL)encrypted andAESKeys:(NSString *)keys;
+ (NSData *) readAESEncryptedFileAtPAth:(NSString *)path andAESKey:(NSString *)key;

+ (void)clearSubviewsfromView:(UIView *)view;
+ (BOOL) isViewWithTag:(int)tag beingDispalyedOnSuperView:(UIView *)superview;
+ (void) getRoundedCornerFroView:(UIView *)view withCornerRadius:(float)radius;
+ (float) getHeightForString:(NSString *)str forFontName:(NSString *)fontName adnSize:(float)size;

+ (BOOL) serializeInputs:(NSArray *)inputs forKeys:(NSArray *)keys;
+ (NSArray *) deserializeForKeys:(NSArray *)keys;
+ (BOOL) removeSerializableForKeys:(NSArray *)keys;
+ (BOOL) validateDictionaryItem:(NSDictionary *)dict forKey:(NSString *)key;

@end
