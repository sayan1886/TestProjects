///// General ///////////////////////////////
#define LANG_CANCEL @"Cancel"
#define LANG_OK @"OK"
#define LANG_DONE @"Done"
#define LANG_LOADING @"Loading..."
#define LANG_LOAD_FAILED @"Load Failed :("
#define LANG_BACK @"Back"
#define LANG_TRY_AGAIN @"Try Again"
#define LANG_LOAD_ERROR_TITLE @"Connection Error"
#define LANG_LOAD_ERROR_MESSAGE @"Could not load data from server."
#define LANG_SUBMIT @"Submit"
///// end General //////////////////////////////

////// Register / Sign In //////////////////
#define LANG_REGISTER @"Register"
#define LANG_SIGN_IN @"Sign In"

#define LANG_JOIN_AS_TITLE @"Sign up to play..."

#define LANG_SIGN_IN_SUCCESS_TITLE @"Sign In Successful!"
#define LANG_SIGN_IN_SUCCESS_MESSAGE nil //@"Sign in saved.  You will not be prompted to sign in again unless you sign out."
#define LANG_SIGN_IN_FAILURE_TITLE @"Sign In Error" 
#define LANG_SIGN_IN_FAILURE_PASSWORD_MESSAGE @"Invalid Password"
#define LANG_SIGN_IN_FAILURE_USERNAME_MESSAGE @"Invalid Username"

#define LANG_REGISTER_FAILURE_TITLE @"Register Error"
#define LANG_REGISTER_FAILURE_EMAIL_MESSAGE @"Invalid Email Address"
#define LANG_REGISTER_FAILURE_PASSWORD_MESSAGE @"Invalid Password"
#define LANG_REGISTER_FAILURE_EMAIL_USERNAME @"Invalid Username"
////// end Register / Sign In //////////////////


// Guess //////////////////////////////////
#define LANG_COULD_NOT_SUBMIT_GUESS @"Guess could not be sent..."
// end Guess //////////////////////////////

/////////// Scene ////////////////////////////
#define LANG_SCENE_LOAD_ERROR_TITLE @"Could Not Load Scene"
#define LANG_SCENE_LOAD_ERROR_MESSAGE @"Scene data could not be loaded from server."
/////////// end Scene ////////////////////////

/////////// Bios ////////////////////////////
#define LANG_BIO_LOAD_ERROR_TITLE @"Could Not Load Character Data"
#define LANG_BIO_LOAD_ERROR_MESSAGE @"Character data could not be loaded from server."
/////////// end Bios ////////////////////////

///////// Killer Guess ////////////////////
#define LANG_KILLER_GUESS_CONFIRM_TITLE @"Submit Killer Guess Now!!?"
#define LANG_KILLER_GUESS_CONFIRM_MESSAGE @"You only get one chance to guess the killer, ever!  Are you sure you want to submit it now?"
///////// end Killer Guess ////////////////


/*
///// Upload //////////////////////////////////
#define LANG_UPLOAD_SOURCE_SELECTION_TITLE @"How would you like to upload your snap?"
#define LANG_UPLOAD_LIBRARY @"Select a Snap"
#define LANG_UPLOAD_CAMERA @"Shoot a Snap"

#define LANG_JOIN_TO_UPLOAD_SNAPS @"Join to upload, view, and receive comments on your snaps..."
#define LANG_UPLOAD_SUCCESS_TITLE @"Snap Uploaded!"
#define LANG_BROWSE_AFTER_UPLOAD @"Browse Snaps"

#define LANG_UPLOAD_TRANSMITTING @"Sending Snap..."
#define LANG_UPLOAD_SENT @"Snap Uploaded!"
#define LANG_CATEGORY_SELECTION_HEADER @"Select a collection for this snap..."
///// end Upload //////////////////////////////////

///// Content List ////////////////////////////////
#define LANG_LIST_LOAD_ERROR_TITLE @"Could Not Load Data"
#define LANG_EMPTY_SNAPS_LIST_ERROR_TITLE @"Try Uploading a Snap"
#define LANG_EMPTY_SNAPS_LIST_ERROR_MESSAGE @"Just click the camera button in the upper right corner to get started!"
//#define LANG_PROMPT_JOIN_TITLE @"Join to Comment"
#define LANG_PROMPT_JOIN_MESSAGE @"Join to read and write comments on this item."
///// end Content List ////////////////////////////////

///// Content Item ////////////////////////////////
#define LANG_DEFAULT_ITEM_TITLE  @"Snap"
#define LANG_DEFAULT_USERNAME @"a LimeLife user"
#define LANG_JOIN_TO_VIEW_COMMENTS @"Please join to view comments."
#define LANG_COMMENT_SECTION_HEADER_TITLE @"post your comments"
#define LANG_COMMENT_LOAD_ERROR_TITLE @"Snap Comment Load Error"
#define LANG_JOIN_TO_COMMENT @"Join to read and write comments"
#define LANG_YOU_POSTED_NAME @"You"
#define LANG_JUST_POSTED_DATE @"just now"
///// end Content Item ///////////////////////////////

///// Login on Launch /////////////////////////////////
#define LANG_NO_INTERNET_TITLE @"Could not Connect"
#define LANG_NO_INTERNET_MESSAGE @"Unable to establish a connection with LimeLife servers."
#define LANG_QUIT @"Quit"

#define LANG_LOGGIN_FAILED_TITLE @"Loggin Failed"
#define LANG_LOGGIN_FAILED_MESSAGE @"Sorry, at the moment, we cannot login"
#define LANG_SKIP @"Skip"
///// end Login on Launch /////////////////////////////
*/
