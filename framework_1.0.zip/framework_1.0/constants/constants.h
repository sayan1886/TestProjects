// App constants

/*#import "FlurryAPI.h"

#define SAVED_ARTICLES @"savedArticles"

#define APPLICATION_NAME @"CBSNews"
#define DISPLAY_NAME @"CBS News"

#define APPLICATION_VERSION @"2.0"
#define SAVE_STORY_ALERT_SHOW_PREFERENCE @"saveStoryAlertShowPreference"
//#define TWITTER_DOMAIN @"cbsnews.ian.dw2.treemo.com"
//#define JIFFY_LINK_DOMAIN @"http://cbsnews.ian.dw2.treemo.com"
//#define LINK_DOMAIN @"labs.ian.dw2.treemo.com/jiffy" //@"iphone.cbsnews.treemo.com" // @"cbsnews.ian.dw2.treemo.com/cbsnews" //  
#define LINK_DOMAIN @"iphone.cbsnews.treemo.com"
#define TWITTER_DOMAIN @"cbsnews.treemo.com"
#define JIFFY_LINK_DOMAIN @"http://" @"cbsnews.treemo.com" 



#define VAR_TOKEN @"#QUERY_STRING#"
#define VERSION_TOKEN @"&version=2.0"


#define LINK_DOMAIN_URL_STRING @"http://" LINK_DOMAIN
#define API_URL  JIFFY_LINK_DOMAIN @"/services/api/" //http://cbsnews.ian.dw2.treemo.com/services/api



#define FLURRY_KEY @"VYMPZF1HNTM2LPTXMIUP"

#define API_KEY @"68320d13010992b41fc6ef29c0a675d0"
#define API_PASSWORD @"Fullscreen"
#define MEDIALETS_DEFAULT_COUNT @"2"


#define DEFAULT_ACTION_SHEET_STYLE UIActionSheetStyleBlackTranslucent

#define kStdButtonWidth	106.0
#define kStdButtonHeight 40.0
#define APP_USER_TOKEN  nil

#define TopNavTintColor 0x703675
#define NEWS_STORY_BODY_STYLE  @"color:#233565;size:13px;line-height:20px;padding 8px;font-family:helvetica;"




#define CAROUSEL_TEXT_SELECTED 0xFFFFFF
#define CAROUSEL_BACKGROUND @"carousel_spinner-bg.png"
#define CAROUSEL_TEXT_UNSELECTED 0x606270

#define CAROUSEL_RIGHT @"carousel_right-arrow.png"
#define CAROUSEL_LEFT @"carousel_left-arrow.png"
#define CAROUSEL_HEIGHT 39

#define STATION_QUERY_STRING @""

#define CATEGORIES_NEWS @"Top News, U.S. ,World,Politics,SciTech,Health,Entertainment,Money Watch,Sports,Opinion,Blogs"
#define CATEGORIES_NEWS_IDS @"100,201,202,250,205,204,207,500395,500290,215,501463"


#define CATEGORIES_SHOWS @"CBS Evening News,The Early Show,48 Hours,60 Minutes,Saturday Early Show,Sunday Morning,Face the Nation,Up to the Minute" 
#define CATEGORIES_SHOWS_IDS @"18563,500202,18559,18560,SES,3445,3460,3455"
#define CATEGORIES_FULLSHOWS_IDS @"503445,NULL,503443,503444,NULL,NULL,NULL,NULL"
#define CATEGORIES_SHOWS_BANNERS @"cbsnews.png,earlyShow.png,48hours.png,60min.png,earlyShow.png,sundayMorning.png,faceTheNation.png,upToTheMinute.png"

#define CATEGORIES_TWITTER @"All Tweets,Mark Knoller,Byron Pitts,Katie Couric,CBS News,CBS News Live Feed,CBS News Hot Sheet,CBS Investigates,The Early Show,60 Minutes"

#define CATEGORIES_TWITTER_IDS @"cbs_tweet_feed,markknoller,byronpitts,katiecouric,CBSNews,cbsnewslivefeed,CBSNewsHotSheet,CBSInvestigates,theearlyshow,60Minutes"

#define CATEGORIES_SEARCH @"     All News     ,     Video     ,     Images     "
#define CATEGORIES_SEARCH_IDS @"News,Video,Image"

#define AD_USER_ID @"4cab67944677e858"
#define AD_DEFAULT_SECTION_ID @"1285"

// Legal URLS
#define LEGAL_TOU_URL @"http://www.cbsinteractive.com/info/tou"
#define LEGAL_PRIVACY_URL @"http://www.cbsinteractive.com/info/privacy"
#define LEGAL_EULA_URL @"http://www.cbsinteractive.com/info/eula"
*/

#import "framework_constants.h"

#define FB_API_KEY @"aeb2d8ebd7a7a41f1a6ad7019d260e29"
#define FB_SECRET_APPID @"23ad30d8882cf1924f8963b9d4e9f588"

#define APPLICATION_NAME @"RickSteves_AudioEurope"
#define DISPLAY_NAME @"Rick Steves AudioEurope"

#define APPLICATION_VERSION @"1.0"


#define SAVE_STORY_ALERT_SHOW_PREFERENCE @"saveStoryAlertShowPreference"


/*
 #define LINK_DOMAIN  @"rwg.dw2.treemo.com" //@"cbsnews.ian.dw2.treemo.com"
 #define TWITTER_DOMAIN @"cbsnews.treemo.com"
 #define JIFFY_LINK_DOMAIN @"http://" @"cbsnews.treemo.com" // @"http://" @"cbsnews.ian.dw2.treemo.com" 
 */


#define LINK_DOMAIN_URL_STRING @"http://" LINK_DOMAIN
//#define API_URL   @"http://ricksteves.dw2.treemo.com/" //JIFFY_LINK_DOMAIN @"/services/api/" //http://cbsnews.ian.dw2.treemo.com/services/api
//#define API_URL   @"http://rwg.treemo.com/services/api/"
#define API_URL   @"http://ricksteves.treemo.com/services/api/"
#define API_KEY @"68320d13010992b41fc6ef29c0a675d0"
#define API_PASSWORD @"Fullscreen"
#define NEWS_STORY_BODY_STYLE  @"color:#233565;size:13px;line-height:20px;padding 8px;font-family:helvetica;"



#define STATION_QUERY_STRING @""

#define CATEGORIES_NEWS @"Editor's Choice, U.S. ,World,Politics,SciTech,Health,Entertainment,MoneyWatch,Sports,Opinion,Blogs"
#define CATEGORIES_NEWS_IDS @"100,201,202,250,205,204,207,500395,500290,215,501463"


#define CATEGORIES_SHOWS @"CBS Evening News,The Early Show,48 Hours,60 Minutes,Sunday Morning,Face the Nation,Up to the Minute" 
#define CATEGORIES_SHOWS_IDS @"18563,500202,18559,18560,3445,3460,3455"
#define CATEGORIES_FULLSHOWS_IDS @"503445,NULL,503443,503444,NULL,NULL,NULL,NULL"
#define CATEGORIES_SHOWS_BANNERS @"cbsnews.png,earlyShow.png,48hours.png,60min.png,earlyShow.png,sundayMorning.png,faceTheNation.png,upToTheMinute.png"

#define CATEGORIES_TWITTER @"All Tweets,Andrew Cohen,Mark Knoller,Byron Pitts,Katie Couric,CBS News,CBS News Live Feed,CBS News Hot Sheet,CBS Investigates,The Early Show,60 Minutes"

#define CATEGORIES_TWITTER_IDS @"cbs_tweet_feed,cbsandrewcohen,markknoller,byronpitts,katiecouric,CBSNews,cbsnewslivefeed,CBSNewsHotSheet,CBSInvestigates,theearlyshow,60Minutes"

#define CATEGORIES_SEARCH @"     All News     ,     Video     ,     Images     "
#define CATEGORIES_SEARCH_IDS @"News,Video,Image"

//#define AD_USER_ID @"4cab67944677e858"
//#define AD_DEFAULT_SECTION_ID @"4390"
#define AD_USER_ID @"4b026313cae839a3"
#define AD_DEFAULT_SECTION_ID @"7211"
#define AD_DEFAULT_SECTION_ID_PAD @"7234"
// Legal URLS
#define LEGAL_TOU_URL @"http://www.cbsinteractive.com/info/tou"
#define LEGAL_PRIVACY_URL @"http://www.cbsinteractive.com/info/privacy"
#define LEGAL_EULA_URL @"http://www.cbsinteractive.com/info/eula"



