/*
 *  TreemoClassOverrides.h
 *  Qwiket
 *
 *  Create by Andrew Paul Simmons on 6/27/09.
 *  Copyright 2009 Treemo Labs. All rights reserved.
 *
 */

/* Default Configuration 
 #import "RegisterViewController.h" 
 #define TREEMO_REGISTER_VIEW_CONTROLLER RegisterViewController
 
 #import "SignInViewController.h"
 #define TREEMO_SIGN_IN_VIEW_CONTROLLER SignInViewController
*/

// custom classes must extend default classes 
#import "RegisterViewController.h"
#define	TREEMO_REGISTER_VIEW_CONTROLLER RegisterViewController  

#import "SignInViewController.h"
#define TREEMO_SIGN_IN_VIEW_CONTROLLER SignInViewController

