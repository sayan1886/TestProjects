//
//  Qwiket_APIBinding.m
//  Qwiket
//
//  Create by Andrew Paul Simmons on 7/27/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import "ApplicationAPIBinding.h"
#import "JSON.h"

#define BITLY_VER @"2.0.1"
#define BITLY_USRNAME @"treemo" 
#define BITLY_KEY @"R_b0ffca95f36cfaaf7ae5eea1049f8ee8"

@implementation ApplicationAPIBinding

/*
+ (Requester*) bitlyShortenURLRequest:(NSString*)longURL
					   responseTarget:(id)target
						   success_cb:(SEL)success
						   failure_cb:(SEL)failure
{
	NSString* api_action = @"shorten";
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:2];
	[vars setObject:longURL forKey:@"longUrl"]; 
	[vars setObject:BITLY_KEY forKey:@"apiKey"];
	[vars setObject:BITLY_USRNAME forKey:@"login"];
	[vars setObject:BITLY_VER forKey:@"version"];
	
	SEL rh = @selector(bitlyResponse:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	
	return [self makeGetAppRequestWithURL:@"http://api.bit.ly"
							 forAction:api_action 
							 paramters:vars
					   responseHandler:rh 
						failureHandler:fh
								target:target
							success_cb:success
							failure_cb:failure
								 extra:nil];
}*/




+ (void) bitlyResponse:(APIResponseHandler*)apirh
{
	//NSLog(@"bitlyResponse %@", apirh.response);
	NSDictionary* dict =  [apirh.response JSONValue];
	////NSLog(@"Dictionary1:%@",dict);
	NSDictionary* dict2 = [dict objectForKey:@"results"];
	////NSLog(@"Dictionary2: %@",dict2);
	////NSLog(@"Dictionary.errorCode: %@",[dict objectForKey:@"errorCode"]);
	NSDictionary* dict3 = [dict2 objectForKey:[[dict2 allKeys] objectAtIndex:0]];
	if([[dict3 objectForKey:@"errorCode"] integerValue] == 0)
	{				
		////NSLog(@"shortURL:%@",[dict3 objectForKey:@"shortUrl"]);
		[apirh.target performSelector:apirh.success withObject:[dict3 objectForKey:@"shortUrl"]];
	}
	else
	{
		[apirh.target performSelector:apirh.failure withObject:[dict objectForKey:@"errorMessage"]];
	}		
}


/*
 GET /cbsnews/newssearch?callback=?&query=eric&station=kcbs&page=1&callback=C&_1267144616456= HTTP/1.1

 Accept: 
Accept-Language: en-us
Accept-Encoding: gzip, deflate
Cookie: cbsnews-prod=6p37tlkfqjf32jaa0n47nn8dc1; lang=en_us
Connection: keep-alive
*/
+ (Requester*) getXMLForStockFeed:(NSString*)stockList
				   responseTarget:(id)target
					   success_cb:(SEL)success
					   failure_cb:(SEL)failure
{
	NSString* api_action = @"XMLREST";
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:1];
	[vars setObject:@"cbsinteractive" forKey:@"Account"];
	// 	[vars setObject:@"CBSNews" forKey:@"station"];
	[vars setObject:stockList forKey:@"Ticker"];
	
	SEL rh = @selector(XML_gotStockFeed:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	
	return [self makeGetAppRequestWithURL:@"http://feeds.financialcontent.com"
							 forAction:api_action 
							 paramters:vars
					   responseHandler:rh 
						failureHandler:fh
								target:target
							success_cb:success
							failure_cb:failure
								 extra:nil];	
}


/*
 
 <Quote>
 
	<Record>
		<RecordID>DJI</RecordID>
		<Ticker>$DJI</Ticker>
		<CompanyName>Dow Jones Industrial Average</CompanyName>
		<ShortCompanyName>Dow</ShortCompanyName>
		<Exchange>Dow Jones Indices</Exchange>
		<ExchangeShortName>Dow Jones</ExchangeShortName>
		<ExchangeCode>DJI</ExchangeCode>
		<LastTrade>1267479017</LastTrade>
		<UpdateTime>1267479917000</UpdateTime>
		<Volume>173754869</Volume>
		<AverageVolume>190676496</AverageVolume>
		<Last>10403.79</Last>
		<Open>10326.0996</Open>
		<High>10413.9902</High>
		<Low>10326.0996</Low>
		<High52>10729.8896</High52>
		<Low52>6469.9502</Low52>
		<Close>10325.2598</Close>
		<ChangePrice>78.5303</ChangePrice>
		<ChangePercent>0.7606</ChangePercent>
		<Bid>0.00</Bid>
		<Ask>0.00</Ask>
		<BidSize>0</BidSize>
		<AskSize>0</AskSize>
		<Dividend>0.00</Dividend>
		<EPS>0.00</EPS>
		<SharesOutstanding>0</SharesOutstanding>
	</Record>
 
	<Record>
		...
	</Record>
	...
 </Quote>
*/


+ (void) XML_gotStockFeed:(APIResponseHandler*)apirh
{
	
	
	
	WebXML* xml = [[WebXML alloc] initWithString:apirh.response];
	////NSLog(@"Got stock XML: %@",apirh.response);
	xmlNodeSetPtr nodeset;
	if(xml == nil)
	{
		////NSLog(@"Could not create XML Document!");
		[apirh.target performSelector:apirh.failure withObject:@"Could Not Parse XML Response"];
	}
 	else if( (nodeset = [xml nodeSetWithPath:@"/Quote/Record"]) && nodeset->nodeNr > 0)
	{
		//make array of objects.
		NSMutableArray* arr = [[[NSMutableArray alloc]initWithCapacity:0] autorelease];
		for (int i = 0; i < nodeset->nodeNr; i++) 
		{
			NSMutableDictionary* dict = [[[NSMutableDictionary alloc] init] autorelease];
			xmlNodePtr n = nodeset->nodeTab[i];
			
			[dict setValue:[xml valueWithPath:@"/Quote/Record/RecordID" fromNode:n atIndex:i] forKey:@"RecordID"];
			[dict setValue:[xml valueWithPath:@"/Quote/Record/Ticker" fromNode:n atIndex:i] forKey:@"Ticker"];
			[dict setValue:[xml valueWithPath:@"/Quote/Record/CompanyName" fromNode:n atIndex:i] forKey:@"CompantName"];
			[dict setValue:[xml valueWithPath:@"/Quote/Record/ShortCompanyName" fromNode:n atIndex:i] forKey:@"ShortCompanyName"];
			[dict setValue:[xml valueWithPath:@"/Quote/Record/Exchange" fromNode:n atIndex:i] forKey:@"Exchange"];
			[dict setValue:[xml valueWithPath:@"/Quote/Record/ExchangeShortName" fromNode:n atIndex:i] forKey:@"ExchangeShortName"];
			[dict setValue:[xml valueWithPath:@"/Quote/Record/ExchangeCode" fromNode:n atIndex:i] forKey:@"ExchangeCode"];
			[dict setValue:[xml valueWithPath:@"/Quote/Record/LastTrade" fromNode:n atIndex:i] forKey:@"LastTrade"];
			[dict setValue:[xml valueWithPath:@"/Quote/Record/UpdateTime" fromNode:n atIndex:i] forKey:@"UpdateTime"];
			[dict setValue:[xml valueWithPath:@"/Quote/Record/Volume" fromNode:n atIndex:i] forKey:@"Volume"];
			[dict setValue:[xml valueWithPath:@"/Quote/Record/AverageVolume" fromNode:n atIndex:i] forKey:@"AverageVolume"];
			[dict setValue:[xml valueWithPath:@"/Quote/Record/Last" fromNode:n atIndex:i] forKey:@"Last"];
			[dict setValue:[xml valueWithPath:@"/Quote/Record/Open" fromNode:n atIndex:i] forKey:@"Open"];
			[dict setValue:[xml valueWithPath:@"/Quote/Record/High" fromNode:n atIndex:i] forKey:@"High"];
			[dict setValue:[xml valueWithPath:@"/Quote/Record/Low" fromNode:n atIndex:i] forKey:@"Low"];
			[dict setValue:[xml valueWithPath:@"/Quote/Record/High52" fromNode:n atIndex:i] forKey:@"High52"];
			[dict setValue:[xml valueWithPath:@"/Quote/Record/Low52" fromNode:n atIndex:i] forKey:@"Low52"];
			[dict setValue:[xml valueWithPath:@"/Quote/Record/Close" fromNode:n atIndex:i] forKey:@"Close"];
			[dict setValue:[xml valueWithPath:@"/Quote/Record/ChangePrice" fromNode:n atIndex:i] forKey:@"ChangePrice"];
			[dict setValue:[xml valueWithPath:@"/Quote/Record/ChangePercent" fromNode:n atIndex:i] forKey:@"ChangePercent"];
			[dict setValue:[xml valueWithPath:@"/Quote/Record/Bid" fromNode:n atIndex:i] forKey:@"Bid"];
			[dict setValue:[xml valueWithPath:@"/Quote/Record/Ask" fromNode:n atIndex:i] forKey:@"Ask"];
			[dict setValue:[xml valueWithPath:@"/Quote/Record/BidSize" fromNode:n atIndex:i] forKey:@"BidSize"];
			[dict setValue:[xml valueWithPath:@"/Quote/Record/AskSize" fromNode:n atIndex:i] forKey:@"AskSize"];
			[dict setValue:[xml valueWithPath:@"/Quote/Record/Dividend" fromNode:n atIndex:i] forKey:@"Dividend"];
			[dict setValue:[xml valueWithPath:@"/Quote/Record/EPS" fromNode:n atIndex:i] forKey:@"EPS"];
			[dict setValue:[xml valueWithPath:@"/Quote/Record/SharesOutstanding" fromNode:n atIndex:i] forKey:@"SharesOutstanding"];

			[arr addObject:dict];	
		}	

		[apirh.target performSelector:apirh.success withObject:arr];
	}
	
	else	
	{
		////NSLog(@"Error: no error");
		[apirh.target performSelector:apirh.failure withObject:@"Could not find stock."];
	}	
	
	[xml release];
	
}
//http://cbsnews.ian.dw2.treemo.com/cbsnews/image?id=6030713

+ (Requester*) getJSONForSlideShowList:(NSString*)slideShowID
						responseTarget:(id)target
							success_cb:(SEL)success
							failure_cb:(SEL)failure
{
	NSString* api_action = @"cbsnews/nativeimage";
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:1];
	[vars setObject:slideShowID	forKey:@"id"];
	
	SEL rh = @selector(Jiffy_loadListSuccess:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	
	return [self makeGetAppRequestWithURL:JIFFY_LINK_DOMAIN
							 forAction:api_action 
							 paramters:vars
					   responseHandler:rh 
						failureHandler:fh
								target:target
							success_cb:success
							failure_cb:failure
								 extra:nil];
}

+ (Requester*) getJSONforNewsSearch:(NSString*)searchCriteria
						 pageNumber:(NSString*)page
					 responseTarget:(id)target
						 success_cb:(SEL)success
						 failure_cb:(SEL)failure
{
	NSString* api_action = @"cbsnews/newssearch";
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:1];
	[vars setObject:searchCriteria forKey:@"query"];
// 	[vars setObject:@"CBSNews" forKey:@"station"];
	[vars setObject:page forKey:@"page"];

	SEL rh = @selector(Jiffy_loadListSuccess:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	
	return [self makeGetAppRequestWithURL:JIFFY_LINK_DOMAIN
							 forAction:api_action 
							 paramters:vars
					   responseHandler:rh 
						failureHandler:fh
								target:target
							success_cb:success
							failure_cb:failure
								 extra:nil];
}

+ (Requester*) getJSONforImageList:(NSString*)category
						pageNumber:(NSString*)page
					responseTarget:(id)target
						success_cb:(SEL)success
						failure_cb:(SEL)failure
{
	
	NSString* apiAction = @"cbsnews/imagelist";	
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:1];

	[vars setObject:category forKey:@"category"];
	[vars setObject:page forKey:@"page"];
	
	
	SEL rh = @selector(Jiffy_loadImageListSuccess:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	
	NSString* listtype_category_page = [NSString stringWithFormat:@"%@_%@_%@", @"imageList", category, page];
	return [self makeGetAppRequestWithURL:JIFFY_LINK_DOMAIN
							 forAction:apiAction 
							 paramters:vars
					   responseHandler:rh 
						failureHandler:fh
								target:target
							success_cb:success
							failure_cb:failure
								 extra:listtype_category_page];	
}


+ (Requester*) getJSONforImageSearch:(NSString*)searchCriteria
						  pageNumber:(NSString*)page
					  responseTarget:(id)target
						  success_cb:(SEL)success
						  failure_cb:(SEL)failure
{
	NSString* api_action = @"cbsnews/imagesearch";
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:1];
	[vars setObject:searchCriteria forKey:@"query"];
	// 	[vars setObject:@"CBSNews" forKey:@"station"];
	[vars setObject:page forKey:@"page"];
	
	SEL rh = @selector(Jiffy_loadListSuccess:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	
	return [self makeGetAppRequestWithURL:JIFFY_LINK_DOMAIN
							 forAction:api_action 
							 paramters:vars
					   responseHandler:rh 
						failureHandler:fh
								target:target
							success_cb:success
							failure_cb:failure
								 extra:nil];
}


+ (Requester*) getJSONforVideoSearch:(NSString*)searchCriteria
						 pageNumber:(NSString*)page
					 responseTarget:(id)target
						 success_cb:(SEL)success
						 failure_cb:(SEL)failure
{
	NSString* api_action = @"cbsnews/cnetvideosearch";
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:1];
	[vars setObject:searchCriteria forKey:@"query"];
	// 	[vars setObject:@"CBSNews" forKey:@"station"];
	[vars setObject:page forKey:@"page"];
	
	SEL rh = @selector(Jiffy_loadListSuccess:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	
	return [self makeGetAppRequestWithURL:JIFFY_LINK_DOMAIN
							 forAction:api_action 
							 paramters:vars
					   responseHandler:rh 
						failureHandler:fh
								target:target
							success_cb:success
							failure_cb:failure
								 extra:[NSString stringWithFormat:@" _%@_%@",@"natureList",page]];
}

+ (Requester*) getXMLAccuWeather_loadWeatherFromLat:(NSString*)latitude
											 andLong:(NSString*)longitude
									 responseTarget:(id)target
										 success_cb:(SEL)success
										 failure_cb:(SEL)failure
{
	NSString* api_action = @"widget/cbstr/weather-data.asp";
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:2];
	[vars setObject:latitude forKey:@"lat"];
	[vars setObject:longitude forKey:@"lon"];
	[vars setObject:@"0" forKey:@"metric"];
	
	SEL rh = @selector(gotXMLAccuWeather_loadCityNameFromZipcodeResponse:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	
	return [self makeGetAppRequestWithURL:@"http://cbstr.accu-weather.com"
							 forAction:api_action 
							 paramters:vars
					   responseHandler:rh 
						failureHandler:fh
								target:target
							success_cb:success
							failure_cb:failure
								 extra:nil];
}

+ (Requester*) getXMLAccuWeather_loadCityNameFromZipcode:(NSString*)zipcode
										  responseTarget:(id)target
											  success_cb:(SEL)success
											  failure_cb:(SEL)failure
{
	NSString* api_action = @"widget/cbstr/weather-data.asp";
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:2];
	[vars setObject:zipcode forKey:@"location"];
	[vars setObject:@"0" forKey:@"metric"];
	
	
	SEL rh = @selector(gotXMLAccuWeather_loadCityNameFromZipcodeResponse:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	
	return [self makeGetAppRequestWithURL:@"http://cbstr.accu-weather.com"
							 forAction:api_action 
							 paramters:vars
					   responseHandler:rh 
						failureHandler:fh
								target:target
							success_cb:success
							failure_cb:failure
								 extra:zipcode];
	
	////NSLog(@"Trying to get popular events");
}

+ (void) gotXMLAccuWeather_loadCityNameFromZipcodeResponse:(APIResponseHandler*)apirh
{	
	//////NSLog(@"AccuWeather response %@", apirh.response);
	
	NSString* namespaceCleanXML = [Utils string:apirh.response 
							   replaceSubstring:@"xmlns"
									 withString:@"XML_Namespaces_Removed"];
	
	WebXML* xml = [[WebXML alloc] initWithString:namespaceCleanXML];
	
	if(xml == nil)
	{
		////NSLog(@"Could not create XML Document!");
		[apirh.target performSelector:apirh.failure withObject:@"Could Not Parse Eventful Response"];
	}
	else if([xml elementExistsForPath:@"/adc_database/failure"])
	{
		NSString* error_msg = [xml firstValueWithPath:@"/adc_database/failure"];
		// it is ok for the error_msg to be nil
		[apirh.target performSelector:apirh.failure withObject:error_msg];
	}
	else if([xml elementExistsForPath:@"/adc_database/local/city"])
	{
		//NSString* cityName = [xml firstValueWithPath:@"/adc_database/local/city"];
		//NSString* zipcode = (NSString*)apirh.extra;
		[apirh.target performSelector:apirh.success withObject:xml];
	}
	else	
	{
		////NSLog(@"Error: no error");
		[apirh.target performSelector:apirh.failure withObject:nil];
	}	
	
	[xml release];
}

+ (Requester*) Jiffy_loadTwitterListForSearch:(NSString*)search
								 responseTarget:(id)target
									 success_cb:(SEL)success
									 failure_cb:(SEL)failure
{
	NSString* apiAction = @"twitter/search";
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:1];
	[vars setObject:search forKey:@"query"];
	
	SEL rh = @selector(Jiffy_loadListSuccess:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	
	NSString* listtype_category_page = [NSString stringWithFormat:@"%@_%@_0", @"twitterList", search];
	return [self makeGetAppRequestWithURL:JIFFY_LINK_DOMAIN
							 forAction:apiAction 
							 paramters:vars
					   responseHandler:rh 
						failureHandler:fh
								target:target
							success_cb:success
							failure_cb:failure
								 extra:listtype_category_page];
}

+ (Requester*) Jiffy_loadTwitterListForCategory:(NSString*)category
										 responseTarget:(id)target
											 success_cb:(SEL)success
											 failure_cb:(SEL)failure
 {
	 NSString* apiAction = @"twitter/timeline";
	 NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:1];
	 [vars setObject:category forKey:@"user"];
	 
	 SEL rh = @selector(Jiffy_loadListSuccess:);
	 SEL fh = @selector(onConnectionFailure:withRequester:);
	 
	 NSString* listtype_category_page = [NSString stringWithFormat:@"%@_%@_0", @"twitterList", category];
	 return [self makeGetAppRequestWithURL:JIFFY_LINK_DOMAIN
							  forAction:apiAction 
							  paramters:vars
						responseHandler:rh 
						 failureHandler:fh
								 target:target
							 success_cb:success
							 failure_cb:failure
								  extra:listtype_category_page];
 }


+ (Requester*) Jiffy_loadVideoDetailsForID:(NSString*)videoID
								 videoType:(NSString*)videoType
							responseTarget:(id)target
								success_cb:(SEL)success
								failure_cb:(SEL)failure
{
	NSString* apiAction = @"cbsnews/cnetvideodetails";
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:2];
	[vars setObject:videoID forKey:@"id"];
	[vars setObject:videoType forKey:@"videoType"];
	
	SEL rh = @selector(Jiffy_loadVideoDetailsSuccess:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	
	NSString* videoType_id = [NSString stringWithFormat:@"%@_%@", videoType, videoID];
	return [self makeGetAppRequestWithURL:JIFFY_LINK_DOMAIN
							 forAction:apiAction 
							 paramters:vars
					   responseHandler:rh 
						failureHandler:fh
								target:target
							success_cb:success
							failure_cb:failure
								 extra:videoType_id];
}

+ (void) Jiffy_loadVideoDetailsSuccess:(APIResponseHandler*)apirh
{
	//////NSLog(@"Jiffy Story Load Response %@", apirh.response);
	
	[apirh.target performSelector:apirh.success withObject:apirh.response withObject:apirh.extra];
}

+ (Requester*) Jiffy_loadStoryForID:(NSString*)storyID
						  storyType:(NSString*)storyType
					 responseTarget:(id)target
						 success_cb:(SEL)success
						 failure_cb:(SEL)failure
{
	//possible storytypes are @"blog" and @"story"
	NSString* apiAction = @"cbsnews/nativenewsstory";
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:2];
	
	if([storyType isEqualToString:@"blog"])
	{
		[vars setObject:@"1" forKey:@"isBlogItem"];
	}
	
	[vars setObject:storyID forKey:@"id"];
		
	
	NSString* storytype_id = [NSString stringWithFormat:@"%@_%@", storyType, storyID];
	SEL rh = @selector(Jiffy_loadStorySuccess:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	
	return [self makeGetAppRequestWithURL:JIFFY_LINK_DOMAIN
							 forAction:apiAction 
							 paramters:vars
					   responseHandler:rh 
						failureHandler:fh
								target:target
							success_cb:success
							failure_cb:failure
								 extra:storytype_id];
}


+ (void) Jiffy_loadStorySuccess:(APIResponseHandler*)apirh
{
	//NSLog(@"Jiffy Story Load Response %@", apirh.response);
	
	[apirh.target performSelector:apirh.success withObject:apirh.response withObject:apirh.extra];
}


+ (Requester*) Jiffy_loadListForMultipleCategory:(NSString*)category
								   multipleVideo:(NSString*)video
							  pageNumber:(int)pageNumber
						  responseTarget:(id)target
							  success_cb:(SEL)success
							  failure_cb:(SEL)failure
{	
	NSString* apiAction = @"cbsnews/cnetcombinedlist";	
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:1];
	NSString* pageNumber_str = [NSString stringWithFormat:@"%i", pageNumber]; 
	[vars setObject:category forKey:@"newsCategory"];
	[vars setObject:video forKey:@"videoCategory"];
	[vars setObject:pageNumber_str forKey:@"page"];
	//[vars setObject:@"1" forKey:@"withIntro"];
	
	
	SEL rh = @selector(Jiffy_loadListSuccess:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	
	
	NSString* listtype_category_page = [NSString stringWithFormat:@"%@_%@_%@", @"newslist", category, pageNumber_str];
	return [self makeGetAppRequestWithURL:JIFFY_LINK_DOMAIN
							 forAction:apiAction 
							 paramters:vars
					   responseHandler:rh 
						failureHandler:fh
								target:target
							success_cb:success
							failure_cb:failure
								 extra:listtype_category_page];	
}

+ (Requester*) Jiffy_loadListForCategory:(NSString*)category
							  pageNumber:(int)pageNumber
						  responseTarget:(id)target
							  success_cb:(SEL)success
							  failure_cb:(SEL)failure
{	
	NSString* apiAction = @"cbsnews/nativenewslist";	
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:1];
	NSString* pageNumber_str = [NSString stringWithFormat:@"%i", pageNumber]; 
	[vars setObject:category forKey:@"category"];
	[vars setObject:pageNumber_str forKey:@"page"];
	[vars setObject:@"1" forKey:@"withIntro"];
	
	
	SEL rh = @selector(Jiffy_loadListSuccess:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	
	NSString* listtype_category_page = [NSString stringWithFormat:@"%@_%@_%@", @"newslist", category, pageNumber_str];
	return [self makeGetAppRequestWithURL:JIFFY_LINK_DOMAIN
							 forAction:apiAction 
							 paramters:vars
					   responseHandler:rh 
						failureHandler:fh
								target:target
							success_cb:success
							failure_cb:failure
								 extra:listtype_category_page];	
}
+ (Requester*) Jiffy_loadVideoListForCategory:(NSString*)category
								   pageNumber:(int)pageNumber
										 wifi:(BOOL)wifi
									  popular:(BOOL)popular
							   responseTarget:(id)target
								   success_cb:(SEL)success
								   failure_cb:(SEL)failure
{	
	NSString* apiAction = @"cbsnews/cnetnativevideolist";	
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:1];
	NSString* pageNumber_str = [NSString stringWithFormat:@"%i", pageNumber]; 
	NSString* videoType = @"iphone_hires";
	
	[vars setObject:category forKey:@"category"];
	[vars setObject:pageNumber_str forKey:@"page"];
	if (popular) {
		[vars setObject:@"popular" forKey:@"type"];
	}
	[vars setObject:videoType forKey:@"videoType"];
	SEL rh = @selector(Jiffy_loadListSuccess:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	NSString* listtype_category_page = [NSString stringWithFormat:@"%@%@%@_%@", @"videolist",popular?@"_popular_":@"_", category, pageNumber_str];
	return [self makeGetAppRequestWithURL:JIFFY_LINK_DOMAIN
							 forAction:apiAction 
							 paramters:vars
					   responseHandler:rh 
						failureHandler:fh
								target:target
							success_cb:success
							failure_cb:failure
								 extra:listtype_category_page];
	
	//http://treemo.com/cbsnews/videolist?category=100&videoType=iphone_hires
}


+ (Requester*) Jiffy_loadVideoListForCategory:(NSString*)category
								   pageNumber:(int)pageNumber
										wifi:(BOOL)wifi
							   responseTarget:(id)target
								   success_cb:(SEL)success
								   failure_cb:(SEL)failure
{	
	NSString* apiAction = @"cbsnews/cnetnativevideolist";	
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:1];
	NSString* pageNumber_str = [NSString stringWithFormat:@"%i", pageNumber]; 
	NSString* videoType = @"iphone_hires";
	
	[vars setObject:category forKey:@"category"];
	[vars setObject:pageNumber_str forKey:@"page"];
	[vars setObject:videoType forKey:@"videoType"];
	SEL rh = @selector(Jiffy_loadListSuccess:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	
	NSString* listtype_category_page = [NSString stringWithFormat:@"%@_%@_%@", @"videolist", category, pageNumber_str];
	return [self makeGetAppRequestWithURL:JIFFY_LINK_DOMAIN
							 forAction:apiAction 
							 paramters:vars
					   responseHandler:rh 
						failureHandler:fh
								target:target
							success_cb:success
							failure_cb:failure
								 extra:listtype_category_page];
	
	//http://treemo.com/cbsnews/videolist?category=100&videoType=iphone_hires
}


+ (Requester*) Jiffy_loadCombinedListForCategory:(NSString*)category
										 wifi:(BOOL)wifi
							   responseTarget:(id)target
								   success_cb:(SEL)success
								   failure_cb:(SEL)failure
{	
	NSString* apiAction = @"cbsnews/cnetcombinedlist";	
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:2];
	NSString* videoType = @"iphone_hires";
	[vars setObject:category forKey:@"category"];
	[vars setObject:videoType forKey:@"videoType"]; //hires or lowres
	[vars setObject:@"1" forKey:@"withIntro"];
	SEL rh = @selector(Jiffy_loadListSuccess:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	
	return [self makeGetAppRequestWithURL:JIFFY_LINK_DOMAIN
							 forAction:apiAction 
							 paramters:vars
					   responseHandler:rh 
						failureHandler:fh
								target:target
							success_cb:success
							failure_cb:failure
								 extra:category];
}

+ (Requester*) Jiffy_loadCombinedListForCategory:(NSString*)category
											wifi:(BOOL)wifi
										 popular:(BOOL)popular
								  responseTarget:(id)target
									  success_cb:(SEL)success
									  failure_cb:(SEL)failure
{	
	NSString* apiAction = @"cbsnews/cnetcombinedlist";	
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:2];
	NSString* videoType = @"iphone_hires";
	if(popular)
	{
		[vars setObject:@"popular" forKey:@"type"];
	}	
	[vars setObject:category forKey:@"category"];

	[vars setObject:videoType forKey:@"videoType"]; //hires or lowres
	[vars setObject:@"1" forKey:@"withIntro"];
	SEL rh = @selector(Jiffy_loadListSuccess:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	NSString*extra_str ;
	if (popular)
	{
		extra_str = [NSString stringWithFormat:@"popular_%@",category];
	}
	else
	{
		extra_str = category;
	}

	return [self makeGetAppRequestWithURL:JIFFY_LINK_DOMAIN
							 forAction:apiAction 
							 paramters:vars
					   responseHandler:rh 
						failureHandler:fh
								target:target
							success_cb:success
							failure_cb:failure
								 extra:extra_str];
}


+ (void) Jiffy_loadImageListSuccess:(APIResponseHandler*)apirh
{
	////NSLog(@"Jiffy List Load Response %@", apirh.response);
	NSString* categoryAndPage = (NSString*)apirh.extra; 
	NSDictionary* dict = [apirh.response JSONValue];
	//NSLog(@"apirh: %@",apirh.response);
	if(![dict objectForKey:@"list"])
	{
		[apirh.target performSelector:apirh.failure withObject:[dict objectForKey:@"error"]  withObject:[apirh.requester retain]];
		return;
	}
	
	[apirh.target performSelector:apirh.success withObject:apirh.response withObject:categoryAndPage];
}

+ (void) Jiffy_loadListSuccess:(APIResponseHandler*)apirh
{
	//NSLog(@"Jiffy List Load Response %@", apirh.response);
	NSString* categoryAndPage = (NSString*)apirh.extra; 
	NSDictionary* dict = [apirh.response JSONValue];
	if([dict objectForKey:@"error"])
	{
		[apirh.target performSelector:apirh.failure withObject:[apirh.requester retain]];
		return;
	}

	[apirh.target performSelector:apirh.success withObject:apirh.response withObject:categoryAndPage];
}


+ (Requester*) AccuWeather_loadCityNameFromZipcode:(NSString*)zipcode
									responseTarget:(id)target
										success_cb:(SEL)success
										failure_cb:(SEL)failure
{
	NSString* api_action = @"widget/cbstr/weather-data.asp";
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:2];
	[vars setObject:zipcode forKey:@"location"];
	[vars setObject:@"0" forKey:@"metric"];
	
	
	SEL rh = @selector(AccuWeather_loadCityNameFromZipcodeResponse:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	
	return [self makeGetAppRequestWithURL:@"http://cbstr.accu-weather.com"
							 forAction:api_action 
							 paramters:vars
					   responseHandler:rh 
						failureHandler:fh
								target:target
							success_cb:success
							failure_cb:failure
								 extra:zipcode];
	
	////NSLog(@"Trying to get popular events");
}


+ (void) AccuWeather_loadCityNameFromZipcodeResponse:(APIResponseHandler*)apirh
{	
	////NSLog(@"AccuWeather response %@", apirh.response);

	NSString* namespaceCleanXML = [Utils string:apirh.response 
							   replaceSubstring:@"xmlns"
									 withString:@"XML_Namespaces_Removed"];
	
	WebXML* xml = [[WebXML alloc] initWithString:namespaceCleanXML];
	
	if(xml == nil)
	{
		////NSLog(@"Could not create XML Document!");
		[apirh.target performSelector:apirh.failure withObject:@"Could Not Parse Eventful Response"];
	}
	else if([xml elementExistsForPath:@"/adc_database/failure"])
	{
		NSString* error_msg = [xml firstValueWithPath:@"/adc_database/failure"];
		// it is ok for the error_msg to be nil
		
		[apirh.target performSelector:apirh.failure withObject:error_msg];
	}
	else if([xml elementExistsForPath:@"/adc_database/local/city"])
	{
		NSString* cityName = [xml firstValueWithPath:@"/adc_database/local/city"];
		NSString* zipcode = (NSString*)apirh.extra;
		[apirh.target performSelector:apirh.success withObject:cityName withObject:zipcode];
	}
	else
	{
		////NSLog(@"Error: no error");
		[apirh.target performSelector:apirh.failure withObject:nil];
	}	
	
	[xml release];
}

+ (Requester*) makeGetAppRequestWithURL:(NSString*)url
						   forAction:(NSString*)action
						   paramters:(NSMutableDictionary*)vars 
					 responseHandler:(SEL)rh 
					  failureHandler:(SEL)fh 
							  target:(id)target
						  success_cb:(SEL)success
						  failure_cb:(SEL)failure
							   extra:extraOrNil

{
	[vars setObject:@"rsae" forKey:@"app_name"];
	[vars setObject:[NSString stringWithFormat:@"%@",[[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleVersion"]] forKey:@"version"];
	[vars setObject:@"iphone" forKey:@"device"];
	return [self makeGetRequestWithURL:url
						 forAction:action
						 paramters:vars 
				   responseHandler:rh 
					failureHandler:fh 
							target:target
						success_cb:success
						failure_cb:failure
							 extra:extraOrNil];
	 
}



@end
