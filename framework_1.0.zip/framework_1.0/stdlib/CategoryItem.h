//
//  CategoryItem.h
//  EyeReport
//
//  Create by Andrew Paul Simmons on 10/1/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface CategoryItem : NSObject <NSCoding>
{
	NSString* title;
	NSString* description;
	NSString* thumbnail;
	NSString* type;
	NSString* feed;
	NSString* url;
	NSString* uploadTags;
	NSNumber* index;
	
	//may be nil on non-featured category item
	NSString* featureButtonNormal;
	NSString* featureButtonPressed;
}

@property(copy) NSString* title;
@property(copy) NSString* description;
@property(copy) NSString* thumbnail;
@property(copy) NSString* type;
@property(copy) NSString* feed;
@property(copy) NSString* url;
@property(copy) NSString* uploadTags;
@property(copy) NSNumber* index;

@property(copy) NSString* featureButtonNormal;
@property(copy) NSString* featureButtonPressed;
@end