//
//  Requester.m
//  MyImagePicker
//
//  Create by Andrew Paul Simmons on 7/25/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import "Requester.h"
#import "NetworkReachability.h"

@implementation Requester
@synthesize progressTarget;


- (id) init
{
	//Should raise exception if requestURL is nil
	[super init];
	return self;
}

- (void)connection:(NSURLConnection *)connection 
   didSendBodyData:(NSInteger)bytesWritten
 totalBytesWritten:(NSInteger)totalBytesWritten
totalBytesExpectedToWrite:(NSInteger)totalBytesExpectedToWrite
{
	float x = (float)bytesWritten / (float)totalBytesExpectedToWrite;
	////////NSLog(@"Progress at: %f",x);
	//allows a calling class to get this data.
	[progressTarget connection:connection 
			   didSendBodyData:bytesWritten
			 totalBytesWritten:totalBytesWritten
	 totalBytesExpectedToWrite:totalBytesExpectedToWrite];
	
	
}

-(id)initWithURL:(NSString*)url actionTarget:(id)target
{	
	if(![super init]) return nil;
	
	requestFailed = NO;
	actionTarget = target;
	// If the actiontarget is an object simply designed to act in the place
	// of a closure it may be auto released. So, we must retain it.
	[actionTarget retain]; 
	requestURL = [url retain];
	multipartBoundry = @"--------Ef1cH2ae0Ef1Ef1cH2Ef1ae0gL6cH2";
	receivedData  = [[[NSMutableData alloc] initWithCapacity:100] autorelease];
	//////////NSLog(@"Requester initializedWithURL: %@", url);
	return self;
}

@synthesize onFailure;
@synthesize onResponse;
@synthesize requestURL;


- (void) attachData:(NSData*)data withFieldName:(NSString*)fieldName andFileName:(NSString*)filename
{
	uploadData = data; //i.e. image to upload
	[uploadData retain];
	//////////NSLog(@"UploadData Retained");
	uploadFieldName = fieldName;
	uploadFileName = filename;
}


- (void)submit:(NSDictionary*)vars requestMethod:(NSString*)methodOrNil
{
	

	requestVars = [vars retain];
	NSURLRequest* r;
	if([methodOrNil isEqualToString:@"POST"])
	{
		requestMethod = @"POST"; // saved for possible retry
		
		r = [self buildPostRequestWithVars:vars];
	}
	else 
	{
		requestMethod = @"GET";
		r = [self buildGetRequestWithVars:vars];
	}


	//////NSLog(@"Trying to request: %@",[r URL]) ;
	myConnection = [[NSURLConnection alloc] initWithRequest:r delegate:self startImmediately:YES];
	
	[Utils addNetworkUsage];
	[self retain];
	
	//- (id)initWithRequest:(NSURLRequest *)request delegate:(id)delegate startImmediately:(BOOL)startImmediately
	
	/*
    urlData = [NSURLConnection sendSynchronousRequest:r
                                    returningResponse:&response
                                                error:&error];
	*/
	//- (id)initWithRequest:(NSURLRequest *)request delegate:(id)delegate startImmediately:(BOOL)startImmediately
	//NSString* result = [[NSString alloc] initWithData:urlData encoding:NSUTF8StringEncoding];
	//////////NSLog(@"result: %@",  result);
	
}

-(void)cancel
{
	//////NSLog(@"Request Canceled");
	canceled = YES;
	
	[myConnection cancel];
	[uploadData release];
	uploadData = nil;
	[Utils removeNetworkUsage];
	actionTarget = nil;
	[self performSelector:@selector(release) withObject:nil afterDelay:5];
	
}

+ (NSString *) urlEncodeVars:(NSDictionary *)vars
{
	NSMutableArray* vars_prsAry = (NSMutableArray*)[NSMutableArray arrayWithCapacity:3];
	NSEnumerator *enumerator = [vars keyEnumerator];
	NSString* key;
	while ((key = (NSString*)[enumerator nextObject])) 
	{
		[vars_prsAry addObject:[NSString stringWithFormat:@"%@=%@", 
								[self urlEncodeValue:key], 
								[self urlEncodeValue:[vars objectForKey:key]]
								]
		];
	}
	
	NSString* vars_str = [vars_prsAry componentsJoinedByString:@"&"];
	////////NSLog(@"the var_str for url request: %@",vars_str);
	// for get [@"?" stringByAppendingString:vars_str];
	return  vars_str;
}

- (NSData *) multipartEncodeVars:(NSDictionary*)vars
{
	NSString* boundary = [NSString stringWithString:multipartBoundry];
	NSArray* keys = [vars allKeys];
	NSMutableData* result = [[NSMutableData alloc] initWithCapacity:100];
	int i;
	//If data provided upload data
	if(false && uploadData != nil)
	{
		//Content-Disposition: form-data; name="Filename"
		[result appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
		[result appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"%@\"\r\n\r\n", @"Filename"] dataUsingEncoding:NSUTF8StringEncoding]];
		[result appendData:[[NSString stringWithFormat:@"%@",uploadFileName] dataUsingEncoding:NSUTF8StringEncoding]];
		[result appendData:[[NSString stringWithString:@"\r\n"] dataUsingEncoding:NSUTF8StringEncoding]];
	}
	
	//If data provided upload data
	if(uploadData != nil)
	{
		[result appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
		[result appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"%@\"; filename=\"%@\"\r\n", uploadFieldName, uploadFileName] dataUsingEncoding:NSUTF8StringEncoding]];
		[result appendData:[[NSString stringWithString:@"Content-Type: image/jpeg\r\n\r\n"] dataUsingEncoding:NSUTF8StringEncoding]];
		[result appendData:uploadData];
		[result appendData:[[NSString stringWithString:@"\r\n"] dataUsingEncoding:NSUTF8StringEncoding]];
		
		
		//Content-Disposition: form-data; name="Upload"
		[result appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
		[result appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"%@\"\r\n\r\n", @"Upload"] dataUsingEncoding:NSUTF8StringEncoding]];
		[result appendData:[[NSString stringWithFormat:@"%@", @"Submit Query"] dataUsingEncoding:NSUTF8StringEncoding]];
		[result appendData:[[NSString stringWithString:@"\r\n"] dataUsingEncoding:NSUTF8StringEncoding]];
	}
	
	for (i = 0; i < [keys count]; i++) 
	{
		id value = [vars valueForKey:[keys objectAtIndex: i]];
		/*Boundry*/[result appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
		/*Heading*/[result appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"%@\"\r\n\r\n", [keys objectAtIndex:i]] dataUsingEncoding:NSUTF8StringEncoding]];
		/*Content*/[result appendData:[[NSString stringWithFormat:@"%@",value] dataUsingEncoding:NSUTF8StringEncoding]];
		/*End*/    [result appendData:[[NSString stringWithString:@"\r\n"] dataUsingEncoding:NSUTF8StringEncoding]];
	}
	

	

	
	[result appendData:[[NSString stringWithFormat:@"--%@--\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
	return [result autorelease];
}

+ (NSString *)urlEncodeValue:(NSString *)str
{
	NSString *result = (NSString *) CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault, 
									(CFStringRef)str, NULL, CFSTR("?=&+_."), kCFStringEncodingUTF8);
	return [result autorelease];
}

+ (NSString *) urlDecodeValue:(NSString *)str{
    NSString *result = [str stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    //(NSString *)CFURLCreateStringByReplacingPercentEscapesUsingEncoding(kCFAllocatorDefault, (CFStringRef)str, NULL,kCFStringEncodingUTF8);
    //result = [result stringByReplacingOccurrencesOfString:@"+" withString:@" "];
    //NSLog(@"URL DECODE STRING : %@",result);
    return result;
}

+ (NSString *) urlDecodeValue:(NSString *)str treatmentForPlus:(BOOL)tretment{
    NSString *result = [self urlDecodeValue:str];
    if (tretment) {
        result = [result stringByReplacingOccurrencesOfString:@"+" withString:@" "];
    }
    return result;
}

 - (NSURLRequest*) buildPostRequestWithVars:(NSDictionary *)vars
{
	NSData* postData = [[self multipartEncodeVars:vars] retain]; //@"api%5Fkey=d0a06257a3eb8f3d6e953284eb1e43b6&username=testuser1&method=treemo%2Eauth%2EtrustedGetToken&api%5Fsig=941d0c48e4eb0d227e87ee0a7aef606f"; //[self encodeVars:vars];
	//////////NSLog(@"Multipart Request String: %@", [[[NSString alloc]  initWithData:postData encoding:NSASCIIStringEncoding] autorelease]);
	//////////NSLog(@"encoded vars: %@", [post  );
	NSString *postLength = [NSString stringWithFormat:@"%d", [postData length]];
	NSMutableURLRequest *request = [[[NSMutableURLRequest alloc] init] autorelease];
	[request setTimeoutInterval:10000 ];
	[request addValue:[NSString stringWithFormat:@"multipart/form-data; boundary=%@", multipartBoundry] 
						forHTTPHeaderField:@"Content-Type"];
	[request setHTTPBody:[postData retain]];
	[request setURL:[NSURL URLWithString:requestURL]];
	[request setHTTPMethod:@"POST"];
	[request setValue:postLength forHTTPHeaderField:@"Content-Length"];
	[request setValue:[UIDevice currentDevice].model forHTTPHeaderField:@"X-DEVICE-MODEL"];
	[request setValue:[UIDevice currentDevice].uniqueIdentifier forHTTPHeaderField:@"X-DEVICE-UNIQ"];
	[request setValue:[UIDevice currentDevice].systemVersion forHTTPHeaderField:@"X-DEVICE-SYSTEM-VERSION"];
	[request setValue:[UIDevice currentDevice].name forHTTPHeaderField:@"X-DEVICE-NAME"];
	[request setValue:[UIDevice currentDevice].systemName forHTTPHeaderField:@"X-DEVICE-SYSTEM-NAME"];
	
	int networkType = [NetworkReachability reachability];
	if (networkType == 1) {
		[request setValue:@"wifi" forHTTPHeaderField:@"X-DEVICE-NETWORK-TYPE"];
	} else if (networkType == 0) {
		[request setValue:@"none" forHTTPHeaderField:@"X-DEVICE-NETWORK-TYPE"];
	} else {
		[request setValue:@"cellular" forHTTPHeaderField:@"X-DEVICE-NETWORK-TYPE"];
	}
	
	
	//[request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
	//[request setHTTPBody:postData]; 
	return request; 
 }

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    // append the new data to the receivedData
    // receivedData is declared as a method instance elsewhere
	//////////NSLog(@"Did append data");
    [receivedData appendData:data];
	
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response

{
	
    // this method is called when the server has determined that it
    // has enough information to create the NSURLResponse
    // it can be called multiple times, for example in the case of 
    // redirect, so each time we reset the data.
    // receivedData is declared as a method instance elsewhere
	NSHTTPURLResponse* httpResponse = (NSHTTPURLResponse*)response;
	//////////NSLog(@"Got response %@", [httpResponse allHeaderFields]);
	//////////NSLog(@"Deleted received data");
    [receivedData setLength:0];	
	//////////NSLog(@"Connection started with receive data length %i", [receivedData length]);
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
	
	
	
	//////////NSLog(@"Received data %@", receivedData);
	NSString* response = [[[NSString alloc] initWithData:receivedData encoding:NSUTF8StringEncoding] autorelease];
	//////////NSLog(@"Connection finished with receive data length %i", [receivedData length]);
	//////////NSLog(@"Connection finished with response %@",response );
	//////////NSLog(@"got response %@", receivedData);
	//////////NSLog(@"RequestCompleted Succesfully\n ___________________________________________\n%@\n __________________________________________________\n",response);

	//[receivedData release];
	[response retain];
	[self retain];
	if(!canceled)
	{
		NSInvocation* inv = [Utils makeInv:onResponse target:actionTarget];
		[inv setArgument:&response atIndex:2];
		[inv setArgument:&self atIndex:3];
		[inv invoke];
	
		
	}
	else
	{
		////////NSLog(@"Connection Finish Canceled");
	}
	
	[connection release];
	[uploadData release];
	[Utils removeNetworkUsage];
	[self release];
}

- (void) connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
	
	static int failCount = 0;
    ////NSLog(@"Connection failed! Error - %@ %@", [error localizedDescription],[[error userInfo] objectForKey:NSErrorFailingURLStringKey]);
	//////NSLog(@"Connection Finish Failure");
	
	failCount++;
	requestFailed = YES;
	
	[actionTarget performSelector:onFailure withObject:error withObject:self];
	
	//[connection release];
	//[receivedData release]; 
	[uploadData release];
	[Utils removeNetworkUsage];
	[self autorelease];
}

- (void) retry
{
	if(!requestFailed)
	{
		////NSLog(@"Ignoring retry because requester not yet in a failed state");
		return;
	}
	else {
		////NSLog(@"Requester attempting retry");
	}

	requestFailed = NO;
	[self submit:requestVars requestMethod:requestMethod];
	
}



- (void) dealloc 
{
	// should we removeNetworkUsage here
	
	//[actionTarget release];
	//////////NSLog(@"Requester Released");
	[requestVars release];
	[requestURL release];
	[super dealloc];
}


- (NSURLRequest*) buildGetRequestWithVars:(NSDictionary *)vars
{
	NSString* getRequestURL;
	if([vars count])
	{
		NSString* vars_str = [Requester urlEncodeVars:vars]; //@"api%5Fkey=d0a06257a3eb8f3d6e953284eb1e43b6&username=testuser1&method=treemo%2Eauth%2EtrustedGetToken&api%5Fsig=941d0c48e4eb0d227e87ee0a7aef606f"; //[self encodeVars:vars];
		getRequestURL = [requestURL stringByAppendingFormat:@"?%@", vars_str];
	}
	else
	{
		getRequestURL = requestURL;
	}

	//	////////NSLog(@"Request URL String: %@", getRequestURL);

	/*  
	NSData *postData = [vars_str dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
	NSString *postLength = [NSString stringWithFormat:@"%d", [postData length]];
	*/
	NSMutableURLRequest *request = [[[NSMutableURLRequest alloc] init] autorelease];	

	
	[request setURL:[NSURL URLWithString:getRequestURL]];
	[request setHTTPMethod:@"GET"];
	//[request setValue:postLength forHTTPHeaderField:@"Content-Length"];
	[request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
	[request setValue:[UIDevice currentDevice].model forHTTPHeaderField:@"X-DEVICE-MODEL"];
	[request setValue:[UIDevice currentDevice].uniqueIdentifier forHTTPHeaderField:@"X-DEVICE-UNIQ"];
	[request setValue:[UIDevice currentDevice].systemVersion forHTTPHeaderField:@"X-DEVICE-SYSTEM-VERSION"];
	[request setValue:[UIDevice currentDevice].name forHTTPHeaderField:@"X-DEVICE-NAME"];
	[request setValue:[UIDevice currentDevice].systemName forHTTPHeaderField:@"X-DEVICE-SYSTEM-NAME"];
	
	int networkType = [NetworkReachability reachability];
	if (networkType == 1) {
		[request setValue:@"wifi" forHTTPHeaderField:@"X-DEVICE-NETWORK-TYPE"];
	} else if (networkType == 0) {
		[request setValue:@"none" forHTTPHeaderField:@"X-DEVICE-NETWORK-TYPE"];
	} else {
		[request setValue:@"cellular" forHTTPHeaderField:@"X-DEVICE-NETWORK-TYPE"];
	}
	
	//[request setHTTPBody:postData];
	 
	
	return request; 
	
}

/*
 [post addValue: @"multipart/form-data; boundary=_insert_some_boundary_here_" forHTTPHeaderField: @"Content-Type"];
 [post setHTTPMethod: @"POST"];
 [post setHTTPBody:regData];
 */

/*
NSString *post = @"key1=val1&key2=val2";
NSData *postData = [post dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];

NSString *postLength = [NSString stringWithFormat:@"%d", [postData length]];

NSMutableURLRequest *request = [[[NSMutableURLRequest alloc] init] autorelease];
[request setURL:[NSURL URLWithString:@"http://www.nowhere.com/sendFormHere.php"]];
[request setHTTPMethod:@"POST"];
[request setValue:postLength forHTTPHeaderField:@"Content-Length"];
[request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
[request setHTTPBody:postData];
 
*/
@end
