//
//  FadeNavigationController.m
//  HarpersIsland
//
//  Create by Andrew Paul Simmons on 2/10/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import "FadeNavigationController.h"

#define kAnimationDuration 0.25

@implementation FadeNavigationController


- (id) initWithRootViewController:(UIViewController*)rootViewController
{
	
	if(self = [super initWithRootViewController:rootViewController])
	{
		blackOverlay = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
		blackOverlay.backgroundColor = [UIColor blackColor];
	}
	
	return self;
}

- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated
{
	
	[super pushViewController:viewController animated:YES];	
	/*
	 [NSTimer scheduledTimerWithTimeInterval: 0.02f 
	 target: self 
	 selector: @selector(onEnterFrame) 
	 userInfo: nil 
	 repeats: NO]; 
	 */
}

- (void) pushViewController:(UIViewController *)viewController fade:(BOOL)fade
{
	[self pushViewController:viewController fade:fade popToViewController:nil];
}

- (void) pushViewController:(UIViewController *)viewController fade:(BOOL)fade 
		popToViewController:(UIViewController*)controllerToPopToOrNil
{
	
	if(fading) return;
	popToViewController = controllerToPopToOrNil;
	fading = YES;
	if(fade)
	{
		nextViewController = viewController;
		[self fadeInPush];
	}
	else
	{
		[self pushViewController:viewController animated:NO];
	}
	
}

- (void) popViewControllerFade:(BOOL)fade
{
	if(fading) return;
	fading = YES;
	
	if(fade)
	{
		[self fadeInPop];
	}
	else
	{
		[self popViewControllerAnimated:NO];
	}
}

- (void)fadeInPush
{
	blackOverlay.alpha = 0;
	[self.view addSubview:blackOverlay];
	
	[UIView beginAnimations:nil context: @"some-identifier-used-by-a-delegate-if-set" ]; 
	[UIView setAnimationBeginsFromCurrentState:YES];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseIn];
	[UIView setAnimationDuration:kAnimationDuration]; // Set the duration to 4/10ths of a second.
	[UIView setAnimationDelegate:self];                       
	[UIView setAnimationDidStopSelector:@selector(fadeOutPush:finished:context:)];
	
	blackOverlay.alpha = 1.0;
	
	[UIView commitAnimations]; // Animate!
	
	
}

- (void) fadeOutPush:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context
{
	if(popToViewController)
	{
		[super popToViewController:popToViewController animated:NO];
	}
	if(nextViewController)
	{
		[super pushViewController:nextViewController animated:NO];
	}
	[self.view addSubview:blackOverlay];
	[UIView beginAnimations:nil context: @"some-identifier-used-by-a-delegate-if-set" ]; 
	[UIView setAnimationBeginsFromCurrentState:YES];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseIn];
	[UIView setAnimationDuration: kAnimationDuration ]; // Set the duration to 4/10ths of a second.
	[UIView setAnimationDelegate:self];                       
	[UIView setAnimationDidStopSelector:@selector(transitionComplete:finished:context:)];
	
	blackOverlay.alpha = 0.0;
	
	[UIView commitAnimations]; // Animate!
}

- (void)fadeInPop
{
	
	blackOverlay.alpha = 0;
	[self.view addSubview:blackOverlay];
	
	[UIView beginAnimations:nil context: @"some-identifier-used-by-a-delegate-if-set" ]; 
	[UIView setAnimationBeginsFromCurrentState:YES];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseIn];
	[UIView setAnimationDuration: kAnimationDuration]; // Set the duration to 4/10ths of a second.
	[UIView setAnimationDelegate:self];                       
	[UIView setAnimationDidStopSelector:@selector(fadeOutPop:finished:context:)];
	
	blackOverlay.alpha = 1.0;
	
	[UIView commitAnimations]; // Animate!
	
	
}

- (void) fadeOutPop:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context
{
	
	[self popViewControllerAnimated:NO];
	[self.view addSubview:blackOverlay];
	[UIView beginAnimations:nil context: @"some-identifier-used-by-a-delegate-if-set" ]; 
	[UIView setAnimationBeginsFromCurrentState:YES];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseIn];
	[UIView setAnimationDuration: kAnimationDuration ]; // Set the duration to 4/10ths of a second.
	[UIView setAnimationDelegate:self];                       
	[UIView setAnimationDidStopSelector:@selector(transitionComplete:finished:context:)];
	
	blackOverlay.alpha = 0.0;
	
	[UIView commitAnimations]; // Animate!
	
	
}

- (void) transitionComplete:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context
{
	nextViewController = nil;
	[blackOverlay removeFromSuperview];
	fading = NO;
}

- (void)dealloc 
{
	[blackOverlay release];
	[super dealloc];
}
@end
