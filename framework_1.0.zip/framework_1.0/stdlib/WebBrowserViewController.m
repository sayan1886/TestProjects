//
//  WebBrowserViewController.m
//  EyeReport
//
//  Create by Andrew Paul Simmons on 10/16/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import "WebBrowserViewController.h"


@implementation WebBrowserViewController
@synthesize startLocation, actionTarget, onSelectReport, myNavigationController;
- (id)init
{
	if(self = [super initWithNibName:@"WebBrowserViewController" bundle:nil])
	{
		[self doInit];
	}	
	return self; 
}

- (id) initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
	if(self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])
	{
		[self doInit];
	}
	return self;
}

- (id) initWithCoder:(NSCoder*)aDecoder
{
	if(self = [super initWithNibName:@"WebBrowserViewController" bundle:nil])
	{
		[self doInit];
	}
	return self;
}

- (void)doInit
{
	loadPaused = NO;
	viewClosed = NO;
	restoreName = @"WebBrowserVC_CBSNews";
}

/*
// Override initWithNibName:bundle: to load the view using a nib file then 
 perform additional customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil 
 {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/* Implement loadView to create a view hierarchy programmatically. */
- (void)loadView 
{
	[super loadView];
	
	back.enabled = myWebView.canGoBack;
	forward.enabled = myWebView.canGoForward;

	[self loadURLString:startLocation];
}

- (UIViewController*) restoreViewState 
{
	[super restoreViewState];
	return self;
}

/*
// Implement viewDidLoad to do additional setup after loading the view.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/

- (IBAction) onHome:(id)sender
{
	[self loadURLString:startLocation];
}

- (IBAction) onRefresh:(id)sender
{
	[myWebView reload];
}

- (IBAction) onBack:(id)sender
{
	[myWebView goBack];
}

- (IBAction) onForward:(id)sender
{
	[myWebView goForward];
}

- (IBAction) onHide:(id)sender
{
	////////NSLog(@"Dismiss Modal %@", self.navigationController);
	viewClosed = YES;
	[self.parentViewController dismissModalViewControllerAnimated:YES];
}

- (IBAction) onReport:(id)sender
{
	////////NSLog(@"Should report");
	[actionTarget performSelector:onSelectReport];
}

- (void) loadURLString:(NSString*)urlString
{
	////////NSLog(@"Loading URL: %@ in %@", urlString, myWebView);
	NSURLRequest* itemViewRequest = [NSURLRequest requestWithURL:[NSURL URLWithString:urlString]];
	[myWebView	loadRequest:itemViewRequest];
}

- (void)webViewDidStartLoad:(UIWebView *)webView
{
	////////NSLog(@"did start load");
	back.enabled = myWebView.canGoBack;
	forward.enabled = myWebView.canGoForward;
	[connectingAnimation_ai startAnimating];
}

- (void)webViewDidFinishLoad:(UIWebView *)webView
{
	////////NSLog(@"did finish load");
	back.enabled = myWebView.canGoBack;
	forward.enabled = myWebView.canGoForward;
	[connectingAnimation_ai stopAnimating];
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
	[connectingAnimation_ai stopAnimating];
	int noInternetConnectionErrorCode = -0x3F1;
	
	if([error code] ==  noInternetConnectionErrorCode)
	{
		if(!noInternetAlert)
		{
			noInternetAlert = [[[UIAlertView alloc] initWithTitle:@"No Internet connection."
															 message:nil
															delegate:nil
												   cancelButtonTitle:@"OK"
												   otherButtonTitles:nil, nil]autorelease];
			[noInternetAlert show ];
		}
	}
	else
	{
		/*
		if(!viewClosed)
		{
			if(!noInternetAlert)
			{
				noInternetAlert= [[[UIAlertView alloc] initWithTitle:@"Failed to load."
															 message:[NSString stringWithFormat:@"%@",error]
															delegate:nil
												   cancelButtonTitle:@"OK"
												   otherButtonTitles:nil]autorelease];
				[noInternetAlert show];
			}
		}
		 */
	}
	////////NSLog(@"Failed Load with error %@", error);	
}

-(void) viewDidAppear:(BOOL)animated
{
	[super viewDidAppear:animated];

	if(loadPaused)
	{
		loadPaused = NO;
		[myWebView reload];
	}
}

-(void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
	if(myWebView.loading)
	{
		loadPaused = YES;
		[myWebView stopLoading];
	}
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation 
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (void)didReceiveMemoryWarning 
{
    [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
    // Release anything that's not essential, such as cached data
		////////NSLog(@"WebBrowserViewController did recieve memeory warning.");
}


- (void)dealloc 
{
	[NSTimer timerWithTimeInterval:1.0 target:self selector:@selector(_dealloc) userInfo:nil repeats:NO];
  
}

- (void)_dealloc
{
	[super dealloc];
}


@end
