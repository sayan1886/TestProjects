//
//  SwipeView.m
//  Swipe_View
//
//  Created by Amrit on 04/03/09.
//  Copyright 2009 __GlobalLogic__. All rights reserved.
//
#import "SwipeView.h"


//Private Methods
@interface SwipeView(PrivateMethods) 
-(void)displayFirstPage:(UIView *)firstView;
-(void)calculateCurrentPageIndex;
- (void)update;
@end

//Class Implementation SwipeView
@implementation SwipeView


//Property Synthesis
@synthesize currentView,currentPageIndex,numViews;
@synthesize dataSource,aDelegate;

/******************************************************************************
 Method Name: initWithFirstView:viewPadding:
 Return Type:  id
 Parameters: (UIView*)firstView,(float)viewPadding
 
 Description: The initialization method used to initialize the SwipeView Object.
 It uses the  view padding value sent as a parameter.
 ******************************************************************************/
#pragma mark Implementation:initialization methods
- (id) initWithFirstView:(UIView*)firstView viewPadding:(float)viewPadding
{
#ifdef _DEBUG
	////////NSLog(@"In initWithFirstView:viewPadding");
#endif
		x_CordinateForPreviousView = 0.0;
	
	//Proceed Only if first view is not nil(NULL)
	if ( firstView != nil)
	{	
		if (self = [super init] )
		{
			
#ifdef _DEBUG
			////////NSLog(@"In initWithFirstView:viewPadding");
#endif
			if(viewPadding >= 0.0 )
			{
				viewPaddingValue = viewPadding;
			}
			else
			{
				viewPaddingValue = kDefaultPadding;
			}
			
			[self displayFirstPage:firstView];	
		}
	}	
	else
	{
		//IF first view is nil then return nil;	
		self = nil;
	}
	return self;
}

/******************************************************************************
 Method Name: initWithFirstView
 Return Type:  id
 Parameters: (UIView*)firstView
 
 Description: The initialization method used to initialize the SwipeView Object.
 It uses the default view padding value.
 ******************************************************************************/
- (id) initWithFirstView:(UIView*)firstView
{
	//Proceed Only if first view is not nil(NULL)
	if( firstView != nil)
	{	
		if (self = [super init] )
		{
			
#ifdef _DEBUG
			////////NSLog(@">>In initWithFirstView");
#endif
			//Set ViewPadding Value
			viewPaddingValue = kDefaultPadding;
			[self displayFirstPage:firstView];
		}
		
	}
	else
	{
		//IF first view is nil then return nil;
		self = nil;
		
	}
	
	
	return self;
}

/******************************************************************************
 Method Name: displayFirstPage
 Return Type: void 
 Parameters:  (UIView *)firstView
 
 Description: This method is called by the initWithFirstView:(UIView*)firstView and 
 initWithFirstView:(UIView*)firstView viewPadding:(float)viewPadding.It implements the
 common functionality in both.
 ******************************************************************************/
-(void)displayFirstPage:(UIView *)firstView
{
	CGRect aRect = CGRectMake(0.0, 0.0, 320, 480);
	self.frame = aRect;
	self.pagingEnabled = YES;
	self.showsHorizontalScrollIndicator = NO;
	self.showsVerticalScrollIndicator = NO;
	self.scrollsToTop = NO;
	self.delegate = self;
	self.contentSize = CGSizeMake(kDefaultScrollWidth, kDefaultScrollHeight);
	
	
	b_shouldSlideForward =  YES;	// This Bool variable is set  to YES by default 
	// if (shouldSlideForwardToView:viewIndex:) returns NO
	// the view will not slide forward
	
	b_shouldSlideBackWard = YES;	// This Bool variable is set to YES by  default
	// if (shouldSlideBackwardToView:viewIndex:) returns NO
	// the view will not slide forward
	[self addSubview:firstView];
	numViews			= 1;
	currentPageIndex	= 0;
	currentView			= [self.subviews objectAtIndex:0];
}


-(void)calculateCurrentPageIndex
{
	CGFloat pageWidth = self.frame.size.width;
	
	int page = floor(((self.contentOffset.x) - (pageWidth +viewPaddingValue)/ 2) / (pageWidth +viewPaddingValue)) + 1;	
	currentPageIndex = page;

		//numViews =  [dataSource numberOfViewsInSwipView:self];
	if(currentPageIndex >= [dataSource numberOfViewsInSwipView:self])
	{
		currentPageIndex--;
	}
	
	if(currentPageIndex < self.subviews.count)
	{
		
		currentView = [[self subviews]objectAtIndex:currentPageIndex];
		
	}
	
}

/******************************************************************************
 Method Name: addView
 Return Type: void 
 Parameters: (UIView *)view
 
 Description: This method adds the new views to the right.
 ******************************************************************************/
#pragma mark add a view
-(void) addView:(UIView*)view
{
#ifdef _DEBUG
	////////NSLog(@"IN >> addView\n");
#endif	
	
	if(view != nil)
	{	
		UIView *tempView = view;
		//Assuming that the First view is at 0,0
		//////////NSLog(@"Adding view %@", tempView); return;
		//////////NSLog(@" view bounds: (%f, %f)", tempView.bounds.size.width, tempView.bounds.size.height);
		
		CGFloat x_CordinateForNewView = x_CordinateForPreviousView + tempView.bounds.size.width + viewPaddingValue;
		//////////NSLog(@"x_coord for new view %f", x_CordinateForNewView);
		CGRect tempFrame = CGRectMake( x_CordinateForNewView, 0,tempView.bounds.size.width, kDefaultScrollHeight);
		tempView.frame = tempFrame;
		
		// Increase the number of pages now present in the view
		numViews ++;
		
		[self setContentSize:CGSizeMake(((kDefaultScrollWidth)*(numViews))+(viewPaddingValue *(numViews - 1)) , kDefaultScrollHeight)];
		
		
		[self addSubview:tempView];
		x_CordinateForPreviousView	= x_CordinateForNewView;		
	}
	else
	{
#ifdef _DEBUG
		[NSException raise:@"Error:" format:@"View is nil"];
#endif		
	}
}

/******************************************************************************
 Method Name: removeView
 Return Type: void 
 Parameters : (UIView*)view
 
 Description: This method removes a view.We look for the view in the 
 viewArray_DataSource and determine it's index.Once the index is determined
 we call - (void) removeViewAtIndex:(int)index
 ******************************************************************************/		 
#pragma mark remove a view
- (void) removeView:(UIView*)view
{	
	if(view !=nil)
	{	
		if( [self.subviews containsObject:view] )
		{
			int index = [self.subviews indexOfObject:view];
			
			if(!(index == [self.subviews count]))
			{
				[self removeViewAtIndex:index];
			}
			else
			{
				
#ifdef _DEBUG
				[NSException raise:@"Error" format:@"Operation not permitted.Only View Present"];
#endif		
				
			}
		}
		else
		{
			
#ifdef _DEBUG
			[NSException raise:@"Error" format:@"View not present"];
#endif
			
		}
	}
	else
	{
		
#ifdef _DEBUG	
		[NSException raise:@"Error" format:@"View is NIL"];
#endif	
		
	}
	
}
/******************************************************************************
 Method Name:  removeViewAtIndex
 Return Type:  void
 Parameters : (int)index
 
 Description: This method removes a view at an index.
 ******************************************************************************/
- (void) removeViewAtIndex:(int)index
{
	if(index >= 0 && index < numViews - 1)
	{		
		UIView *viewToBeRemoved = [self.subviews objectAtIndex:index];			
		CGRect rect = [viewToBeRemoved frame];
		
		CGRect tempRect;
		for(int i = index; i < self.subviews.count; i++)
		{
			viewToBeRemoved.hidden = YES;
			[UIView beginAnimations:nil context:nil];
			[UIView setAnimationDuration:0.5];
			
			UIView *tempView = [self.subviews objectAtIndex:i];			
			tempRect = tempView.frame;
			tempView.frame = rect;
			rect = tempRect;
			
			[UIView commitAnimations];
		}
		
		numViews = numViews - 1;
		[self update];
		[viewToBeRemoved removeFromSuperview];
		//[viewArray_DataSource removeObjectAtIndex:index];
	}
	else
	{
#ifdef _DEBUG
		[NSException raise:@"Error" format:@"Removal Index provided is out of range"];
#endif		
	}	
}

#pragma mark Slide actions
/******************************************************************************
 Method Name: slideForwardAnimated
 Return Type: slideBackwardAnimated
 Parameters:  (BOOL)animated
 
 Description: This method slides forward to the next view.The BOOL parameter
 suggests if the view transition should be animated or no.
 ******************************************************************************/		 
//Slide Forward by one page
- (void) slideForwardAnimated:(BOOL)animated
{
	
#ifdef _DEBUG
	////////NSLog(@"Current Page Index=========%d",currentPageIndex);
#endif	
	
	if(currentPageIndex < (numViews-1))
	{
		if(aDelegate!=nil && [aDelegate respondsToSelector:@selector(shouldSlideForwardToView:viewIndex:)])
		{
			b_shouldSlideForward = [aDelegate shouldSlideForwardToView:[self.subviews objectAtIndex:currentPageIndex + 1] viewIndex:(currentPageIndex + 1)];
		}
		
		if(b_shouldSlideForward )
		{
			UIView *aTempView = [self.subviews objectAtIndex:currentPageIndex + 1];
			[self scrollRectToVisible:aTempView.frame animated:animated];
			[self update];
			
			if(aDelegate != nil && [aDelegate respondsToSelector:@selector(didSlideForwardToView:previousView:)])
			{
				[aDelegate didSlideForwardToView:[self.subviews objectAtIndex:currentPageIndex+1] previousView:[self.subviews objectAtIndex:currentPageIndex]];
				//[self calculateCurrentPageIndex];
				
			}	

		}
	}
	currentPageIndex++;
}


/******************************************************************************
 Method Name: slideBackwardAnimated
 Return Type: slideBackwardAnimated
 Parameters:  (BOOL)animated
 
 Description: This method slides backward to the previous view.The BOOL parameter
 suggests if the view transition should be animated or no.
 ******************************************************************************/

//Slide backward by one view
- (void) slideBackwardAnimated:(BOOL)animated
{	
	
	if(currentPageIndex > 0)
	{		
		if(aDelegate!=nil && [aDelegate respondsToSelector:@selector(shouldSlideBackwardToView:viewIndex:)])
		{
			//Setting arbitary value
			b_shouldSlideBackWard = [aDelegate shouldSlideBackwardToView:[self.subviews objectAtIndex:currentPageIndex -1] viewIndex:(currentPageIndex -1)];
		}
		
		if(b_shouldSlideBackWard /*&& ((currentPageIndex -1) > 0)*/)
		{
			UIView *aTempView = [self.subviews objectAtIndex:currentPageIndex -1];
			[self scrollRectToVisible:aTempView.frame animated:animated];
			[self update];
			
			if(aDelegate != nil && [aDelegate respondsToSelector:@selector(didSlideBackwardToView:previousView:)])
			{
				[aDelegate didSlideBackwardToView:[self.subviews objectAtIndex:currentPageIndex-1] previousView:[self.subviews objectAtIndex:currentPageIndex]];
				[self calculateCurrentPageIndex];
			}
		}
	}
}



/******************************************************************************
 Method Name: slideToView
 Return Type:  void
 Parameters: (UIView*)view
 
 Description: This Method takes a view as a parameter and slides to the view
 ******************************************************************************/

//Slide to given View
- (void)slideToView:(UIView*)view
{
	if(view !=nil)
	{		
		if([self.subviews containsObject:view])
		{
			int index			= [self.subviews indexOfObject:view];
			UIView *aTempView	= [self.subviews objectAtIndex:index];
			[self scrollRectToVisible:aTempView.frame animated:YES];
		}
		else
		{
#ifdef _DEBUG
			[NSException raise:@"Error" format:@"The View is not present"];
#endif			
		}
	}
}




/******************************************************************************
 Method Name: update
 Return Type: void 
 Parameters: N.A 
 
 Description: This method load the required views on the SwipeView on a scroll.
 
 ******************************************************************************/


BOOL didEndDecelerate = NO;
int requiredPages;

- (void)update
{
	[self calculateCurrentPageIndex];
	
	if(aDelegate!=nil & [aDelegate respondsToSelector:@selector(willUnloadView:)])
	{		
		NSArray *subViews = [self subviews];
		for(int i = [subViews count] - 1; i >= 0 ; i--)
		{
			[aDelegate willUnloadView:[subViews objectAtIndex:i]];
			[[subViews objectAtIndex:i] removeFromSuperview];
		}
		
		for(int count = currentPageIndex - kDefaultNumLeftViewsToStore; count <= currentPageIndex - 1; count++)
		{
			if(count >= 0)
				[self addSubview:[dataSource swipeView:self viewForIndex:count]];
		}
		
		[self addSubview:[dataSource swipeView:self viewForIndex:currentPageIndex]];
		
		for(int count = currentPageIndex + 1; count <= currentPageIndex + kDefaultNumRightViewsToStore; count++)
		{
			if(count < [dataSource numberOfViewsInSwipView:self])
				[self addSubview:[dataSource swipeView:self viewForIndex:count]];
		}		
	}
	
}


/******************************************************************************
 Method Name: scrollViewWillBeginDecelerating
 Return Type: void
 Parameters:(UIScrollView *)scrollView
 
 Description:Tells the delegate that the scroll view is starting to decelerate the scrolling movement. 
 ******************************************************************************/

#pragma mark scroll view delegates
-(void)scrollViewWillBeginDecelerating:(UIScrollView *)scrollView
{
	[self calculateCurrentPageIndex];
#ifdef _DEBUG
	////////NSLog(@"IN >> scrollViewWillBeginDecelerating *** currentPageIndex = %d\n", currentPageIndex);
#endif	
	
	[self setContentOffset:CGPointMake(((kDefaultScrollWidth + viewPaddingValue) * currentPageIndex + 1), 0.0) animated:YES];
	
}

/******************************************************************************
 Method Name: scrollViewDidEndDecelerating
 Return Type: void
 Parameters:(UIScrollView *)scrollView
 
 Description:Tells the delegate that the scroll view has ended decelerating the scrolling movement 
 ******************************************************************************/

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
	
	[self update];
	
}


/******************************************************************************
 Method Name: touchesBegan
 Return Type: void
 Parameters:(NSSet *)touches
 (UIEvent *)event 
 
 Description: It is in this method that we detect the initial pixels touched
 on the iPhones Screen.
 ******************************************************************************/

#pragma mark touch event
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	[super touchesBegan:touches withEvent:event];
	UITouch *touch = [touches anyObject];
	startTouchPosition = [touch locationInView:self];
	
}

/******************************************************************************
 Method Name: touchesMoved
 Return Type:  void
 Parameters: (NSSet *)touches
 (UIEvent *)event
 
 Description: This method is called whenever the fingers move over the 
 iPhone Screen.It is here that we track the SWIPE Movement.Once the
 horizonal swipe is detected on either sides.We check should the Views
 move forward or backward.Of the forward/backward movement is permitted there
 is a transition of views and the didScrollForward and didScrollBackward is
 implemented.
 ******************************************************************************/
- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
	
	[super touchesMoved:touches withEvent:event ];
	
	[self calculateCurrentPageIndex];
	
	if([self isKindOfClass:[SwipeView class]])
	{
		UITouch *touch = [touches anyObject];
		CGPoint currentTouchPosition = [touch locationInView:self];
		
		// If the swipe tracks correctly.
		if (	fabsf(startTouchPosition.x - currentTouchPosition.x)	>=	HORIZ_SWIPE_DRAG_MIN 
			&&
			fabsf(startTouchPosition.y - currentTouchPosition.y)	<=	VERT_SWIPE_DRAG_MAX
			)
		{	
			// It appears to be a swipe.
			if (startTouchPosition.x < currentTouchPosition.x)
			{
#ifdef _DEBUG
				////////NSLog(@" ##############\nSwipe Backwards\n############\n");
#endif
				
				self.scrollEnabled=YES;
				if(aDelegate!=nil && [aDelegate respondsToSelector:@selector(shouldSlideBackwardToView:viewIndex:)])
				{
#ifdef _DEBUG
					////////NSLog(@"A delegate responds to the selector shouldSlideBackwardToView:viewIndex:");
#endif
					
					//Setting arbitary values to check call to method
					if(currentPageIndex > 0 && currentPageIndex < self.subviews.count)
						//if(currentPageIndex > 0)
						b_shouldSlideBackWard = [aDelegate shouldSlideBackwardToView:[self.subviews objectAtIndex:(currentPageIndex-1)] viewIndex:(currentPageIndex)];
					
					if(!b_shouldSlideBackWard)
					{
						//since should slide backward is disabled
						// scroll is disabled
						self.scrollEnabled=NO;
						return;
					}				
					
					if (b_shouldSlideBackWard)// && (currentPageIndex == previousPageIndex ))
					{
#ifdef _DEBUG
						////////NSLog(@" Scrolled to Previous view.....check didSlideBackwardToView\n");
#endif			
						
						if(aDelegate != nil && [aDelegate respondsToSelector:@selector(didSlideBackwardToView:previousView:)])
						{
							//Setting arbitary values to check call to method
							[aDelegate didSlideBackwardToView:nil previousView:nil];
							//previousPageIndex = currentPageIndex;
						}
						
						self.scrollEnabled = YES;
					}
				}			
			}
			else		
			{				
#ifdef _DEBUG
				////////NSLog(@"Swipe Forwards\n");
#endif		
				self.scrollEnabled=YES;
				if(aDelegate!=nil && [aDelegate respondsToSelector:@selector(shouldSlideForwardToView:viewIndex:)])
				{
#ifdef _DEBUG
					////////NSLog(@"A delegate responds to the selector shouldSlideForwardToView:viewIndex:");
#endif
					
					//Setting arbitary values to check call to method
					if(currentPageIndex + 1 < self.subviews.count)
						b_shouldSlideForward = [aDelegate shouldSlideForwardToView:[self.subviews objectAtIndex:(currentPageIndex+1)] viewIndex:currentPageIndex];
					
					if(!b_shouldSlideForward)
					{
						//since should slide forward is disabled
						// scroll is disabled
						self.scrollEnabled=NO;
						return;
					}
					
					if(b_shouldSlideForward)// && (previousPageIndex == (currentPageIndex-1)))
					{
#ifdef _DEBUG
						////////NSLog(@" Scrolled to Next view.....check didSlideForwardToView\n");
#endif
						
						if(aDelegate != nil && [aDelegate respondsToSelector:@selector(didSlideForwardToView:previousView:)])
						{
							//Setting arbitary values to check call to method
							[aDelegate didSlideForwardToView:nil previousView:nil];
							//previousPageIndex = currentPageIndex;
						}
						else
						{
							//////////NSLog(@"Does not respond to selector");
						}
						self.scrollEnabled=YES;
					}
				}
			}
		}// end if the swipe tracks correctly.		
	}//end if self is a kind of Class
}//end touchesMoved :)


/******************************************************************************
 Method Name: dealloc
 Return Type:  void
 Parameters: N.A
 
 Description: The dealloc method is called whenever the retain count of
 SwipeView Object is zero.Make sure all objects allocated are deallocated here.
 ******************************************************************************/

#pragma mark dealloc method
- (void)dealloc 
{
	[super dealloc];
}

@end
