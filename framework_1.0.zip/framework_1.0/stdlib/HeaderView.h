//
//  HeaderView.h
//  eMagazine
//
//  Created by SOHAMPAUL on 03/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface HeaderView : UIView {
	id delegate;
	UIButton *butPage;
	UIButton *butStore;
    UIButton *butWebcast;
    UIButton *collection;

}
@property (nonatomic, retain) id delegate;
@property (nonatomic, retain) UIButton *butPage;
@property (nonatomic, retain) UIButton *butStore;
@property (nonatomic, retain) UIButton *butWebcast;
@property (nonatomic, retain) UIButton *butCollection;

- (id)initWithFrame:(CGRect)frame andDelegate:(id)del;
-(void)selectButton:(UIButton*)but;
@end
