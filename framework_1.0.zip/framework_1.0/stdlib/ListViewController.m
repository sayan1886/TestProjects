//
//  BrowseViewController.m
//  EyeReport
//
//  Create by Andrew Paul Simmons on 10/11/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//


#import "ListViewController.h"


@implementation ListViewController
@synthesize initURLString; 

- (id)init
{
	if(self = [super init])
	{
		restoreName = @"browseVC";
		webViewFrameAfterDelay = CGRectMake(0, 0, 320, 367);
		
		//UITableView
		/*
		webBrowser_vc = [[WebBrowserViewController alloc] init];
		webBrowser_vc.doNotStoreStateOnAppear = YES;
		webBrowser_vc.actionTarget = self;
		webBrowser_vc.onSelectReport = @selector(onChildViewSelectReport);
		 */
	}
	
	return self;
}


// Implement loadView to create a view hierarchy programmatically.
- (void)loadView 
{
	myWebView = nil;
	connectingAnimation_ai = nil; 
	
	[super loadView]; 
	
	myWebView = [[[UIWebView alloc] initWithFrame:CGRectMake(0, 46, 320, 321)] autorelease];
	myWebView.delegate = self;
	
	[self.view addSubview:myWebView];
	if(initURLString) [self loadURLString:[initURLString autorelease]];	


	connectingAnimation_ai = [[[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray] autorelease];
	connectingAnimation_ai.hidesWhenStopped = YES;
	[connectingAnimation_ai startAnimating];
	CGSize caSize = connectingAnimation_ai.frame.size;
	connectingAnimation_ai.frame = CGRectMake((320.0f - caSize.width)/2, 
											  (321.0f - caSize.height)/2, 
											  caSize.width, 
											  caSize.height);
	
	connectingAnimationInitY = connectingAnimation_ai.frame.origin.y;
	
	
	[self.view addSubview:connectingAnimation_ai];
	
	//UINavigationBar
	//[self.navigationController.navigationBar  pushNavigationItem:[[UINavigationItem alloc] initWithTitle:@"Test"] animated:YES];
	
}


//debuggin info
- (BOOL) webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request 
												 navigationType:(UIWebViewNavigationType)navigationType
{
	//////////NSLog(@"Should start load %@", [[request URL] absoluteString]);
	BOOL startLoad = [super webView:webView shouldStartLoadWithRequest:request navigationType:navigationType];
	if(startLoad)
	{
		////////NSLog(@"Load started");
	}
	else
	{
		////////NSLog(@"ListView !!started canceled");
	}
	return startLoad; 
}

- (WebAction) onShowItem:(NSString*)url
{
	[self showItemWithURL:url animated:YES];
}

- (WebAction) onRenderStart:(NSString*)voidParam
{
	[connectingAnimation_ai stopAnimating];
}
- (WebAction) onShowEvent:(NSString*)voidParam
{
	////////NSLog(@"Showing Event");
	eventVisible = YES;
}


- (BOOL) shouldPopViewController:(UIViewController*)vc
{
		if(eventVisible)
		{
			[myWebView goBack];
			eventVisible = NO;
			return NO;
		}
		else
		{
			return YES;
		}
}

- (void) showItemWithURL:(NSString*)url animated:(BOOL)animated
{
	/*
	[self itemViewMakeFresh];
	[self.navigationController pushViewController:item_vc animated:animated];
	[item_vc loadURLString:[LINK_DOMAIN_URL_STRING stringByAppendingString:url]];
	 */
	
}

/*
- (ItemViewController*) itemViewMakeFresh
{
	
	[item_vc release];
	item_vc = [[ItemViewController alloc] init];
	item_vc.actionTarget = self;
	item_vc.onSelectJoin = @selector(onItemViewSelectJoin:);
	item_vc.onSelectReport = @selector(onChildViewSelectReport);
	return item_vc;
}

*/



- (void)webViewDidStartLoad:(UIWebView *)webView
{
	[connectingAnimation_ai startAnimating];
}

- (void) loadURLString:(NSString*)urlString
{
	[urlToLoadAfterDelay release];
	urlToLoadAfterDelay = [urlString retain];
	if(myWebView)
	{
		myWebView.delegate = nil;
		[myWebView stopLoading];
		[myWebView setHidden:NO];
		[connectingAnimation_ai startAnimating];
		NSDate* delayDate = [[[NSDate alloc] initWithTimeIntervalSinceNow:1] autorelease];
		[self performSelector:@selector(loadURLStringActual:) withObject:myWebView afterDelay:[delayDate timeIntervalSinceNow]];
		myWebView = nil;
	}
}

- (void) loadURLStringActual:(UIWebView*)webviewToRemoveFromSuperView
{
	////////NSLog(@"___ webview should load url: %@", urlToLoadAfterDelay);
	[webviewToRemoveFromSuperView removeFromSuperview];
	myWebView = [[[UIWebView alloc] initWithFrame:webViewFrameAfterDelay] autorelease];
	myWebView.delegate = self;
	//////////NSLog(@"Attempting tlo load url actual %@", urlToLoadAfterDelay);
	NSURLRequest* itemViewRequest = [NSURLRequest requestWithURL:[NSURL URLWithString:urlToLoadAfterDelay]];
	[urlToLoadAfterDelay release];
	urlToLoadAfterDelay = nil;
	////////NSLog(@"webview %@", myWebView);
	[myWebView loadRequest:itemViewRequest];
	[self.view insertSubview:myWebView belowSubview:connectingAnimation_ai];

}


- (void)webViewDidFinishLoad:(UIWebView *)webView
{
	////////NSLog(@"Reached webViewDidFInishLoad in listViewController.");
	//[super webViewDidFinishLoad:webView];
	
	[connectingAnimation_ai stopAnimating];
	
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
	[connectingAnimation_ai stopAnimating];
	//[super webView:webView didFailLoadWithError:error];
	////////NSLog(@"Failed Load with error %@", error);	
}




- (BOOL) shouldLaunchExternalInSafari:(NSString*)urlString
{
	////////NSLog(@"Should launch url [%@] in external view?", urlString);
	return NO;
	if([urlString rangeOfString:@"phobos.apple.com"].location != NSNotFound)
	{
		[[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlString]];
	}
	else
	{
		////////NSLog(@"URL STRING %@", urlString);	
		/*
		webBrowser_vc.startLocation = urlString;
		[webBrowser_vc loadURLString:urlString];
		 */
		
		[Utils navigateToURL:urlString];
		//[self.navigationController presentModalViewController:webBrowser_vc animated:YES];
	}
	return YES;
}
/*
- (void) onTabToHome
{
	
}

- (void) onTabToMyChannel:(id)sender
{

}

- (void) onTabToFollowing:(id)sender
{
	
}

- (void) onTabToVideo:(id)sender
{
	
}

- (void) onTabToWebsite:(id)sender
{
	
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/



- (void) viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
}

- (void) viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void) viewDidAppear:(BOOL)animated
{
	[super viewDidAppear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation 
{
    // Return YES for supported orientations
    return NO;
}


- (void)didReceiveMemoryWarning 
{	
    [super didReceiveMemoryWarning]; 
		////////NSLog(@"ListViewController did recieve memeory warning.");
}

- (void)dealloc 
{
	    [super dealloc];
}


@end
