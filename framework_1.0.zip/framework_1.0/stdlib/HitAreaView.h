//
//  HitArea.h
//  EyeReport
//
//  Create by Andrew Paul Simmons on 9/2/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HitAreaView : UIControl 
{
	id actionTarget;
	BOOL overload;
	SEL onPress;
	SEL onRelease;
}

@property (assign) id actionTarget;
@property (assign) SEL onPress, onRelease;
@property (assign) BOOL overload;


@end
