//
//  PrivateMesssageCompositionViewController.h
//  Qwiket
//
//  Created by steve on 7/29/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "ApplicationAPIBinding.h"
#import "MessageCompositionViewController.h"
@interface PrivateMessageCompositionViewController : MessageCompositionViewController
{
	UIActivityIndicatorView* loading;
}
//::Public

//::Private
- (IBAction) onCancel:(id)sender;
- (IBAction) onSendMessage:(id)sender;
- (void) createCells;
@end
