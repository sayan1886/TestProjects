//
//  ReportAbuseMessageCompositionViewController.h
//  Qwiket
//
//  Created by steve on 8/12/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MessageCompositionViewController.h"
#import "APIBinding.h"

@interface ReportAbuseMessageCompositionViewController : MessageCompositionViewController
{

	NSString* generatedSubject;
 	UITextView* body;
	UIActivityIndicatorView* loading;
	Requester* requester;
}

@property(copy) NSString* generatedSubject;
//::PUBLIC


- (id) initWithSubject:(NSString*) subject; //it's expected that a description of where and for which user this abuseReport is being generated from.

//::PRIVATE
//overloaded functions
- (IBAction) onCancel:(id)sender;
- (IBAction) onSendMessage:(id)sender;
- (void) createCells;

@end
