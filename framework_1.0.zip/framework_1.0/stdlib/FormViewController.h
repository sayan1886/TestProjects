//
//  FormViewController.h
//  EyeReport
//
//  Create by Andrew Paul Simmons on 8/5/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HitAreaView.h"

@interface FormViewController : UIViewController <UITextViewDelegate, UITextFieldDelegate> 
{
	IBOutlet UIScrollView* viewAsSrollView;  // a reference to view but of proper type UIScrollView	
	CGSize editContentFrameSize;
	CGSize normalContentFrameSize;
	HitAreaView* hitArea;
	BOOL suppressAutoOffsetAdjust;
}

//::Public
@property(assign, readwrite) CGSize editContentFrameSize;
@property(assign, readwrite) CGSize normalContentFrameSize;

//::Protected
- (void) scrollToTop;
-(void) onClickOut;
@end
