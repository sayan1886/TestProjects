//
//  ScrollerThumbView.m
//  eMagazine
//
//  Created by SMB on 21/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ScrollerThumbView.h"

#define THUMBS_GAP 20
#define THUMBS_WIDTH 60
#define THUMBS_HEIGHT 120

@implementation ScrollerThumbView
@synthesize delegate;

- (id)initWithFrame:(CGRect)frame{
    
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code.
		self.backgroundColor = [UIColor colorWithWhite:0.32f alpha:0.2f];
		self.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin;
		thumbURLs = [[NSMutableArray alloc] init];
		//ScrollView
		scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.height)];
		scrollView.delegate = self;
		scrollView.backgroundColor = [UIColor clearColor];
		scrollView.showsVerticalScrollIndicator = NO;
		scrollView.showsHorizontalScrollIndicator = NO;
		scrollView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleTopMargin;
		[self addSubview:scrollView];
		
    }
    return self;
}

-(void)drawThumbs {
	
	int noThumbs = [self getNumOfThumbs];
	
	scrollView.contentSize = CGSizeMake((noThumbs*(THUMBS_GAP+THUMBS_WIDTH))+100, self.frame.size.height);

	CGFloat leftGap = THUMBS_GAP;
	for(int i=0; i<noThumbs; i++) {
		CGRect frm = CGRectMake(leftGap, ((self.frame.size.height-THUMBS_HEIGHT)/2), THUMBS_WIDTH, THUMBS_HEIGHT);
		UIImage *thmImg = [UIImage imageWithContentsOfFile:[thumbURLs objectAtIndex:i]];
		
		UIButton *butThumb = [UIButton buttonWithType:UIButtonTypeCustom];
		butThumb.frame = frm;
		butThumb.tag = i;
		[butThumb addTarget:self action:@selector(didTapOnThumb:) forControlEvents:UIControlEventTouchUpInside];
		[butThumb setImage:thmImg forState:UIControlStateHighlighted];
		[butThumb setImage:thmImg forState:UIControlStateNormal];
		butThumb.autoresizingMask = UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin;
		[scrollView addSubview:butThumb];
		
		leftGap = leftGap + THUMBS_WIDTH + THUMBS_GAP;
	}
}

-(int)getNumOfThumbs {
	int no=0;
	NSString *path = [self getResourcePath];
	NSLog(@"path:%@",path);
	NSArray *dirContent = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:path error:NULL];

	if (dirContent!=nil) {
		for (NSString *fileName in dirContent) {
			if ([[fileName pathExtension] isEqualToString:@"png"]) {
				[thumbURLs addObject:[path stringByAppendingPathComponent:fileName]];
				no++;
			}
		}
	}
	return no;	
	
}

-(NSString*)getResourcePath {

	return [[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject] stringByAppendingString:@"/html/thumbs"];
    //return [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"/html/thumbs"];
}

-(void)didTapOnThumb:(UIButton*)but {
	NSLog(@"butTap");
	[self.delegate thumbViewDidReceiveTapAt:but.tag];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code.
}
*/

- (void)dealloc {
	[thumbURLs release];
	[scrollView release];
    [super dealloc];
}


@end
