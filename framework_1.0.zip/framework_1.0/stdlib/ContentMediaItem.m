//
//  MediaItem.m
//  EyeReport
//
//  Create by Andrew Paul Simmons Simmons on 10/30/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import "ContentMediaItem.h"


@implementation ContentMediaItem
@synthesize title, contentID, description, username, numComments, tags, propertyTags, date, contentPage, thumbnail, image, original,mp4, collectionName, imageSize, index;
@synthesize  originalImageSize,fileSize,contentDuration;
-(NSString*) description
{
	return [NSString stringWithFormat:@"{contentID:%@, title:%@, description:%@, username:%@, numComments:%@, tags:%@, propertyTags:%@, date:%@, contentPage:%@, thumbnail:%@, image:%@, original:%@, mp4:%@, imageSize:(%f, %f), original image size:(%f, %f), index:%@, fileSize: %@, content Duration: %@} \n\n", 
											contentID,title,description,username,numComments,tags,propertyTags,date,contentPage,thumbnail,image,original,mp4,imageSize.width,imageSize.height,originalImageSize.width,originalImageSize.height, index,fileSize,contentDuration];

}
- (NSString*) _description
{
	return description;
}
- (void) _setDescription:(NSString*)value 
{
	
	description = [value copy];
}

- (void)dealloc 
{	
	[title release];
	[contentID release];
	[description release];
	[username release];
	[numComments release];
	[tags release];
	[contentPage release];
	[thumbnail release];
	[image release];
	[index release];
	[original release];
	[mp4 release];
	[propertyTags release];
	[collectionName release];
	
	[fileSize release];
	[contentDuration release];
    [super dealloc];
}

@end
