//
//  ListViewController.h
//  EyeReport
//
//  Create by Andrew Paul Simmons on 10/11/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "constants.h"
//#import "ItemViewController.h"
#import "WebActionHandler.h"
#import "Utils.h"

@interface ListViewController : WebActionHandler <UIWebViewDelegate>
{
	UIWebView* myWebView;
	UIActivityIndicatorView* connectingAnimation_ai;
	NSString* urlToLoadAfterDelay;
	float connectingAnimationInitY;
	CGRect webViewFrameAfterDelay;
	NSString* initURLString;
	BOOL eventVisible;
}


//::Public
- (void) showAndReloadBrowse;
//- (ItemViewController*) itemViewMakeFresh;

@property(copy) NSString* initURLString;

//::Private
- (void) loadURLString:(NSString*)urlString;
- (void) showItemWithURL:(NSString*)url animated:(BOOL)animated;
- (WebAction) onShowItem:(NSString*)url;

@end
