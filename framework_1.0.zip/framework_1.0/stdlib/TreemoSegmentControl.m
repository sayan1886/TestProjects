//
//  TreemoSegmentControl.m
//  Qwiket
//
//  Created by steve on 8/20/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import "TreemoSegmentControl.h"


@implementation TreemoSegmentControl


- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        delegate = nil;
    }
    return self;
}

- (id) init
{
	leftSideSelected = [Utils imageViewWithImageName:@"left-button-press.png"];
	rightSide = [Utils imageViewWithImageName:@"rightbutton-off.png"];
	rightSideSelected = [Utils imageViewWithImageName:@"right-button-press.png"];
	leftSide = [Utils imageViewWithImageName:@"leftbutton-off.png"]; 
	background = [Utils imageViewWithImageName:@"button-bg.png"];
	[Utils view:leftSide setX:5 setY:3];
	[Utils view:leftSideSelected setX:5 setY:3];
	[Utils view:rightSide setX:(leftSide.frame.origin.x + 155) setY:3];
	[Utils view:rightSideSelected setX:(leftSide.frame.origin.x + 155) setY:3];
	////////NSLog(@"Initilaizing TreemoSegmentControl");
	////////NSLog(@"Background information: %@",background);
	if(self = [self initWithFrame:CGRectMake(0, 0, background.frame.size.width, background.frame.size.height)])
	{
		[self addSubview:background];
		[self addSubview:leftSideSelected];
		[self addSubview:rightSide];
		[self addSubview:leftSide];
		[self addSubview:rightSideSelected];
		rightSideSelected.hidden = YES;
		leftSide.hidden = YES;
		
		selectedIndex = 0; 
		split_point = self.frame.size.width/2;
	}
	return self;
}
- (id) initWithFrame:(CGRect)frame
			 leftImage:(UIImageView*)leftImage
			rightImage:(UIImageView*)rightImage
	 leftImageSelected:(UIImageView*)leftImageSelected
	rightImageSelected:(UIImageView*)rightImageSelected
{
	if(self = [self initWithFrame:frame])
	{
		leftSideSelected = [leftImageSelected retain];
		leftSide = [leftImage retain];
		rightSide = [rightImage retain];
		rightSideSelected = [rightImageSelected retain];
		[self addSubview:leftSideSelected];
		[self addSubview:rightSideSelected];
		[self addSubview:rightSide];
		[self addSubview:leftSide];
		rightSideSelected.hidden = YES;
		leftSide.hidden = YES;
		selectedIndex = 0; 
		split_point = self.frame.size.width/2;
	}
	return self;
}


- (void)drawRect:(CGRect)rect {
    // Drawing code
}


- (void)dealloc {
	[leftSideSelected release];
	[leftSide release];
	[rightSide release];
	[rightSideSelected release];
	[seperator release];
    [super dealloc];
}


- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	UITouch* touch = [touches anyObject];
	CGPoint location = [touch locationInView:self];
	[super touchesBegan:touches	withEvent:event];
	self.selectedIndex = ((location.x > split_point)?1:0); 
}
- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
	[super touchesMoved:touches withEvent:event];
}
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
	[super touchesEnded:touches withEvent:event];
}
- (void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event
{
	[super touchesCancelled:touches withEvent:event];
}

- (NSInteger) selectedIndex
{
	return selectedIndex;
}
- (void) setSelectedIndex:(NSInteger)index
{
	if(index != 0 && index != 1)
	{
		// ERROR
		return;
	}
	if(selectedIndex == index)
	{
		return;
	}
	else
	{
		
		//[apirh.target performSelector:apirh.failure withObject:error_msg];
		selectedIndex = index;
		
		[self performSelector:(selectedIndex?@selector(onRight:):@selector(onLeft:)) withObject:self];
	}
	
	
}
- (void) onRight:(id)sender
{
	rightSideSelected.hidden = NO;
	rightSide.hidden = YES;
	leftSide.hidden = NO;
	leftSideSelected.hidden = YES;
	[delegate performSelector:@selector(onRight:) withObject:sender];
}
- (void) onLeft:(id)sender
{
	leftSideSelected.hidden = NO;
	leftSide.hidden = YES;
	rightSide.hidden = NO;
	rightSideSelected.hidden = YES;
	[delegate performSelector:@selector(onLeft:) withObject:sender];
}
@end

