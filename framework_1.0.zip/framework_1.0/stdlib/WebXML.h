//
//  WebXMLParser.h
//  ShowTreemo
//
//  Create by Andrew Paul Simmons on 7/30/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <libxml/xmlmemory.h>
#import <libxml/parser.h>
#import <libxml/xpath.h>

@interface WebXML : NSObject 
{
	xmlDocPtr doc;
}

//:::Public
-(id) initWithString:(NSString*)xml_str;

- (NSString*) firstValueWithPath:(NSString*)xpath;
- (NSString*) firstValueWithPath:(NSString*)xpath fromNode:(xmlNodePtr)contextNode;


- (xmlNodeSetPtr) nodeSetWithPath:(NSString*)xpath;
- (xmlNodeSetPtr) nodeSetWithPath:(NSString*)xpath fromNode:(xmlNodePtr)contextNode;


- (NSString*) valueWithPath:(NSString*)xpath fromNode:(xmlNodePtr)contextNode atIndex:(int)index;


-(bool) elementExistsForPath:(NSString*)xpath;


//::Private

@end
