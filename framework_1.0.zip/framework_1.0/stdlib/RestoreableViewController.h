//
//  RestoreableViewController.h
//  EyeReport
//
//  Create by Andrew Paul Simmons on 10/24/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>

#define RESTORE_PATH_KEY @"applicationRestorePath"

@interface RestoreableViewController : UIViewController 
{
	NSString* restoreName;
	BOOL doNotStoreStateOnAppear;
	//BOOL viewStateNeedsRestore;
}

//::Public
@property(assign) NSString* restoreName;
@property(assign) BOOL doNotStoreStateOnAppear;
- (UIViewController*) restoreViewState;
- (UIViewController*) restoreViewStateAndAdd:(BOOL)addViewController;

//::Protected
@property(retain, readwrite) NSMutableArray* restorePath;
@property(readonly) BOOL isLastControllerInPath;
@property(readonly) NSString* nextViewControllerRestoreName;
- (BOOL) viewControllerIsLastInPath:(RestoreableViewController*)rvc;
- (void) pushViewControllersAnimateLast:(BOOL)animate;
- (void)storePath:(NSArray*)path;

// made public to be invoked when multiple view
// controllers are pushed one after the next. 
- (void) updateRestorePath;

//::Private

- (void)storeCurrentPath;

@end
