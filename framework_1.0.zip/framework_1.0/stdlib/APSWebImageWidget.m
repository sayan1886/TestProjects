//
//  APSWebImageWidget.m
//  Andrew_CBSNews
//
//  Create by Andrew Paul Simmons on 2/25/10.
//  Copyright 2010 Treemo Labs All rights reserved.
//

#import "APSWebImageWidget.h"


#define FADE_SUSPEND_TIME_INTERVAL 0.1f

double fadeSuspendTime;


@implementation APSWebImageWidget
@synthesize actionTarget, onLoadSuccess, onLoadFailure, webImage;


- (id) initWithFrame:(CGRect)frame
{
	if(self = [super initWithFrame:frame])
	{
		CGRect innerImageFrame = CGRectMake(0, 0, frame.size.width, frame.size.height);
		webImage = [[APSWebImageView alloc] initWithFrame:innerImageFrame];
		[self addSubview:webImage];
		
		[self initAPSWebImageWidget];
	}
	return self;
}


- (id) initWithConstraintFrame:(CGRect)constraintFrame
{
	return [self initWithConstraintFrame:constraintFrame 
							   anchorTop:NO 
							  anchorLeft:NO];	
}


- (id) initWithConstraintFrame:(CGRect)constraintFrame 
					 anchorTop:(BOOL)lockTop 
					anchorLeft:(BOOL)lockLeft
{
	if(self = [super initWithFrame:constraintFrame])
	{
		imageIsConstrained = YES;
		webImage = [[APSWebImageView alloc] initWithFrame:CGRectZero] ;
		[self addSubview:webImage];
		[self initAPSWebImageWidget];
	}
	return self;
}

- (BOOL) imageIsDiskCachedForStringURL:(NSString*)aURL
{
	return [webImage imageIsDiskCachedForStringURL:aURL];
}
- (void) initAPSWebImageWidget
{
	self.backgroundColor = [UIColor clearColor];
	
	//init event handlers
	
	webImage.suppressFadeInOnLoadFromWeb = YES;
	webImage.actionTarget = self;
	webImage.onLoadSuccess = @selector(_onLoadSuccess);
	webImage.onLoadFailure = @selector(_onLoadFailure);
	webImage.onLoadStart = @selector(onLoadStart);
	webImage.onLoadProgress = @selector(onLoadProgress);
	webImage.onLoadFromWebSuccess = @selector(_onLoadFromWebSuccess);
	
	progressBarHeght = 3;
	progressBarColor = [[Utils colorFromHex:0xa6c8eb] retain];
	
	
	float height = self.frame.size.height;
	progressBarInitY = height - progressBarHeght;
	progressBar = [[[UIView alloc] initWithFrame:CGRectMake(0, progressBarInitY, 0, progressBarHeght)] autorelease];
	progressBar.backgroundColor = progressBarColor;
	[self addSubview:progressBar];
	
}

- (void)setProgressBarHeight:(float)value
{
	[Utils view:progressBar setHeight:value];
}
- (void) setProgressBarBottomOffset:(float)value
{
	progressBarBottomOffset = value;
	CGRect f = progressBar.frame;
	progressBar.frame = CGRectMake(f.origin.x,progressBarInitY - value, f.size.width, f.size.height);

}

-(float) progressBarBottomOffset
{
	return progressBarBottomOffset;
}

- (void) loadAndCacheImageWithStringURL:(NSString*)url loadNext:(BOOL)loadNext
{
	[webImage loadAndCacheImageWithStringURL:url loadNext:loadNext];
}

- (void) loadAndCacheImageWithStringURL:(NSString*)url
{
	////NSLog(@"Loading Image with URL @%", url);
	[webImage loadAndCacheImageWithStringURL:url];
}

- (void)setDiskCacheOnly:(BOOL)value
{
	webImage.diskCacheOnly = value;
} 

-(BOOL)diskCacheOnly
{
	return webImage.diskCacheOnly;
}

- (void) cancel
{
	[webImage cancel];
	[Utils view:progressBar setWidth:0];
}

- (void) unload
{
	[webImage unload];
	[Utils view:progressBar setWidth:0];
}

- (void) setBackgroundImageByName:(NSString*)imageName
{
	[self insertSubview:[Utils imageViewWithImageName:imageName] atIndex:0];
}

//Event Handlers
- (void) _onLoadFailure
{
	if([actionTarget respondsToSelector:onLoadFailure])
	{
		[actionTarget performSelector:onLoadFailure];
	}
}

- (void) _onLoadSuccess
{
	
	
	////NSLog(@"Actual Image Size (%f, %f) ", webImage.image.size.width, webImage.image.size.height); 
	
	[Utils view:webImage setWidth:webImage.image.size.width];
	[Utils view:webImage setHeight:webImage.image.size.height];
	
	//webImage.image
	
	if(imageIsConstrained)
	{
		[self centerImage];
	}
	
	[actionTarget performSelector:onLoadSuccess];
}

- (void) fitImage
{
	float scale;
	float imageWidth = webImage.image.size.width;
	float imageHeight = webImage.image.size.height;
	float maxWidth = self.frame.size.width;
	float maxHeight = self.frame.size.height;
	
	if(imageWidth > imageHeight)
	{
		scale = maxWidth / imageWidth; 
	}
	else
	{
		scale = maxWidth / imageHeight; 
	}
	
	if(scale*imageWidth > maxWidth + 1)
	{
		scale = maxWidth/imageHeight;
	}
	else if(scale*imageHeight > maxHeight)
	{
		scale = maxHeight / imageHeight;
	}
	
	
	webImage.frame = CGRectMake(0, 0, scale*imageWidth, scale*imageHeight);
	[self centerImage];
}		   

- (void) centerImage
{
	
	float imageWidth = webImage.frame.size.width;
	float imageHeight = webImage.frame.size.height;
	float maxWidth = self.frame.size.width;
	float maxHeight = self.frame.size.height;
	
	
	
	// If the image is bigger than the display area
	// we must adjust it down to fit.
	// Plus ones adjust for rounding errors.
	if(imageWidth > maxWidth + 1 || imageHeight > maxHeight + 1)
	{
		////NSLog(@"Did not center");
		////NSLog(@"Image Size (%f, %f) ", webImage.image.size.width, webImage.image.size.height);
		////NSLog(@"Max Size (%f, %f) ", maxWidth, maxHeight);
		[self fitImage]; // we must fit the image first
		return;
	}
	
	float offsetX = (maxWidth - imageWidth) / 2;
	float offsetY = (maxHeight - imageHeight) / 2;
	[Utils view:webImage setX:offsetX];
	[Utils view:webImage setY:offsetY];
}


- (void) onLoadStart
{
	////////NSLog(@"On load start invoked");
	//float width = self.frame.size.width;
	
	[Utils view:progressBar setWidth:0];
	
	
}
- (void) onLoadProgress
{
	////////NSLog(@"Load Progress | Percent Complete %f", webImage.bytesLoaded / webImage.bytesTotal);
	
	float percentComplete = webImage.bytesLoaded / webImage.bytesTotal;
	float width = self.frame.size.width;
	[Utils recordToAnimate];
	[Utils view:progressBar setWidth:percentComplete*width];
	[Utils animate];
}


- (void) _onLoadFromWebSuccess
{
	////////NSLog(@"Onload from web success");
	
	BOOL fadeIn = ([[NSDate date] timeIntervalSince1970] - fadeSuspendTime > FADE_SUSPEND_TIME_INTERVAL);
	
	if(fadeIn)webImage.alpha = 0;
	
	[Utils recordToAnimate];
	float width = self.frame.size.width;
	[Utils view:progressBar setWidth:width];
	[Utils animate];
	[Utils recordToAnimateWithDuration:0.9];
	progressBar.alpha = 0;
	[Utils animate];
	
	if(fadeIn)
	{
		[Utils recordToAnimate];
		webImage.alpha = 1.0;
		[Utils animate];
	}
	
	
}

+ (void)suspendFadeIn
{
	fadeSuspendTime = [[NSDate date] timeIntervalSince1970];
}



- (void)dealloc 
{
	webImage.actionTarget = nil;
	[webImage release];
	[progressBarColor release];
	
    [super dealloc];
}


@end
