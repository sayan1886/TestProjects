//
//  RestoreableViewController.m
//  EyeReport
//
//  Create by Andrew Paul Simmons on 10/24/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import "RestoreableViewController.h"

NSMutableArray* restorePath;
BOOL restoreInProgress = YES;
NSString* nextViewControllerRestoreName;
NSMutableArray* viewControllers;

@implementation RestoreableViewController

@synthesize restoreName, doNotStoreStateOnAppear;

/*
// Override initWithNibName:bundle: to load the view using a nib file then perform additional customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically.
- (void)loadView {
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/


// invoked on viewDidAppear when final VC in path, else invoked on viewWillAppear
- (UIViewController*) restoreViewState 
{
	return [self restoreViewStateAndAdd:YES];
}

- (UIViewController*) restoreViewStateAndAdd:(BOOL)addViewController 
{
	if(addViewController)
	{
		if(viewControllers == nil)
		{
			viewControllers = [[NSMutableArray arrayWithCapacity:8] retain]; 
		}
		
		[viewControllers addObject:self];
	}

	// get last selected    
	// if item page open push item page in loadView with: showItemPageOnLoadView
	int nextIndex = [restorePath indexOfObject:self.restoreName] + 1;
	if(nextIndex == [restorePath count])
	{
		nextViewControllerRestoreName = nil;
	}
	else
	{
		nextViewControllerRestoreName = (NSString*)[restorePath objectAtIndex:nextIndex]; 
	}
	
	return self;
}

- (void) pushViewControllersAnimateLast:(BOOL)animate
{

	int numViewControllers = [viewControllers count];
	if(numViewControllers < 1) return;
	int i = 0; 
	for(;i < numViewControllers - 1; i++)
	{
		[self.navigationController pushViewController:(UIViewController*)[viewControllers objectAtIndex:i] animated:NO];
	}
	
	[self.navigationController pushViewController:[viewControllers objectAtIndex:i] animated:animate];
	
}

/*
- (void) restorePathNeedsUpdate
{
	[NSException raise:NSInvalidArchiveOperationException 
				format:@"Invoked abstract method 'restorePathNeedsUpdate', developer must override!"];
}
*/

- (void) storeCurrentPath
{
	//////////NSLog(@"Storing Path %@", restorePath);
	[self storePath:restorePath];

}

- (void)storePath:(NSArray*)path
{
	[[NSUserDefaults standardUserDefaults] setObject:path forKey:RESTORE_PATH_KEY]; 
	[[NSUserDefaults standardUserDefaults] synchronize];
}


- (NSMutableArray*) restorePath
{
	return restorePath;
}

- (void) setRestorePath:(NSMutableArray*)value
{
	if(value != restorePath)
	{
		[restorePath release];
		restorePath = value;
		[restorePath retain];
	}
}

- (NSString*) nextViewControllerRestoreName
{
	return nextViewControllerRestoreName;	 
}

- (BOOL)isLastControllerInPath
{
	return [self viewControllerIsLastInPath:self];
}

- (BOOL) viewControllerIsLastInPath:(RestoreableViewController*)rvc
{
	return [rvc.restoreName isEqualToString:(NSString*)[restorePath lastObject]];	
}

/*
- (void) viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	
	if(viewStateNeedsRestore && !self.isLastControllerInPath)
	{
		////////NSLog(@"Pushing on view will appear");
		viewStateNeedsRestore = NO;
		[self restoreViewState];
	}
	
	[self updateRestorePath];
}

*/

- (void) viewDidAppear:(BOOL)animated
{
	[super viewDidAppear:animated];
	if(doNotStoreStateOnAppear) return;
	
	if(restoreInProgress && self.isLastControllerInPath)
	{
		restoreInProgress = NO;
		[self storeCurrentPath];
	}
	else if(!restoreInProgress)
	{
		[self updateRestorePath];
	}
	
	
	/*
	if(viewStateNeedsRestore && self.isLastControllerInPath)
	{
		////////NSLog(@"Pushing on view did appear");
		viewStateNeedsRestore = NO;
		[self restoreViewState];
	}
	 */
}
 

- (void) updateRestorePath
{
	int myPathIndex = [self.restorePath indexOfObject:restoreName];
	if(myPathIndex == NSNotFound)
	{
		[restorePath addObject:restoreName];
	}
	else if(!self.isLastControllerInPath)
	{
		/*
		////////NSLog(@"Last controller in path is %@, current controller is %@", 
				[self.restorePath lastObject], self.restoreName);*/
		while([restorePath count] > myPathIndex + 1)
		{
			[restorePath removeObjectAtIndex:(myPathIndex + 1)];
		}
	}
	else
	{
		////////NSLog(@"Last controller in path is current controller: %@", self.restoreName);
	}
	//////////NSLog(@"Updated restore path for view %@", self.restoreName);
	[self storeCurrentPath];
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
    // Release anything that's not essential, such as cached data
		////////NSLog(@"RestorableViewController did recieve memeory warning.");
}


- (void)dealloc {
    [super dealloc];
}


@end
