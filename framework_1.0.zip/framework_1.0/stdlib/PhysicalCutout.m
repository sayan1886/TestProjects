//
//  PhysicalCutout.m
//  EyeReport
//
//  Create by Andrew Paul Simmons on 11/12/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import "PhysicalCutout.h"


@implementation PhysicalCutout

@synthesize view, ax,ay, vx,vy, horizontalMuK,verticalMuK;

- (id) initWithView:(UIView*)uiView
{
	self = [super init];
	view = [uiView retain];
	
	horizontalMuK = 0.9;
	verticalMuK = 0.9;
	
	return self;
}

-(float)x
{
	return view.frame.origin.x;
}
-(void) setX:(float)x
{
	view.frame = CGRectMake(x, view.frame.origin.y,  view.frame.size.width, view.frame.size.height);
}


- (float) y
{
	return view.frame.origin.y;
}

- (void) setY:(float)y
{
	view.frame = CGRectMake(view.frame.origin.x, y,  view.frame.size.width, view.frame.size.height);
}

- (void) updateWithExternalForceX:(float)externalForceX externalForceY:(float)externalForceY
{
	ax += externalForceX;
	ay += externalForceY;	
	[self update];
}



-(void)attachHorizontalSpringWithConstant:(float)k x:(float)x
{
	horizontalSpringK = k;
	springX = x;
}

-(void) attachVerticalSpringWithConstant:(float)k y:(float)y
{
	verticalSpringK = k;
	springY = y;	
}

- (void) update
{
	ax += (-horizontalSpringK*(self.x - springX));
	vx += ax;
	vx *= horizontalMuK;
	if(fabs(vx) < 0.05) vx = 0;
	self.x += vx;
	ax = 0;
	
	ay += (-verticalSpringK*(self.y - springY));
	vy += ay;
	vy*= verticalMuK;
	if(fabs(vy) < 0.05) vy = 0;
	self.y += vy;
	ay = 0;
	 
}

- (void)dealloc 
{
	[view release];
    [super dealloc];
}

@end
