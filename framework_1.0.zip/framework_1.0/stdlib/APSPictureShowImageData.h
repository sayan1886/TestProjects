//
//  APSPictureShowImageData.h
//  Andrew_CBSNews
//
//  Create by Andrew Paul Simmons on 3/13/10.
//  Copyright 2010 Treemo Labs All rights reserved.
//

#import <Foundation/Foundation.h>


@interface APSPictureShowImageData : NSObject 
{
	NSString* title;
	NSString* caption;
	NSString* byline;
	NSString* url;
}

@property (retain) NSString* title;
@property (retain) NSString* caption;
@property (retain) NSString* byline;
@property (retain) NSString* url;


@end
