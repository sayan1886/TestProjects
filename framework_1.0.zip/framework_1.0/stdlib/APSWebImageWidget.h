//
//  APSWebImageWidget.h
//  Andrew_CBSNews
//
//  Create by Andrew Paul Simmons on 2/25/10.
//  Copyright 2010 Treemo Labs All rights reserved.
//

#import <UIKit/UIKit.h>

#import "APSWebImageView.h"

@interface APSWebImageWidget : UIView 
{
	id actionTarget;
	SEL onLoadSuccess;
	SEL onLoadFailure;
	
	APSWebImageView* webImage;
	
	UIView* progressBar;
	float progressBarHeght;
	float progressBarBottomOffset;
	UIColor* progressBarColor;
	
	BOOL imageIsConstrained;
	
	float progressBarInitY;
	

	
	
}

@property(readonly) APSWebImageView* webImage;
@property(assign) float progressBarBottomOffset;

//::Public
- (id) initWithConstraintFrame:(CGRect)constraintFrame;

- (id) initWithConstraintFrame:(CGRect)constraintFrame 
					 anchorTop:(BOOL)lockTop 
					anchorLeft:(BOOL)lockLeft;


//@property(readonly) APSWebImageView*  webImage;

- (void) setBackgroundImageByName:(NSString*)imageName;

- (void) loadAndCacheImageWithStringURL:(NSString*)url;
- (void) cancel;  // cancel the load request
- (void) unload;  // remove/release the image and/or if loading cancel the load request
- (void)setProgressBarHeight:(float)value;


@property (assign) id actionTarget;
@property (assign) SEL onLoadSuccess;
@property (assign) SEL onLoadFailure;

@property (assign) BOOL diskCacheOnly;


+ (void)suspendFadeIn;

- (BOOL) imageIsDiskCachedForStringURL:(NSString*)aURL;

//::Private
- (void) initAPSWebImageWidget;
- (void) centerImage;

@end
