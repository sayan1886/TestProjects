//
//  SignInViewController.h
//  Qwiket
//
//  Create by Andrew Paul Simmons on 6/27/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "RegisterViewController.h"


@interface SignInViewController : RegisterViewController 
{
	SEL onSignIn;
}


@property(assign) SEL onSignIn; //onSignInWithUsername:andPassword:

@end
