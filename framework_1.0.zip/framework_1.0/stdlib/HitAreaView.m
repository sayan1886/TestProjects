//
//  HitArea.m
//  EyeReport
//
//  Create by Andrew Paul Simmons on 9/2/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import "HitAreaView.h"


@implementation HitAreaView
@synthesize overload;

- (id)initWithFrame:(CGRect)frame {
	if (self = [super initWithFrame:frame]) {
		// Initialization code
		overload = NO;
		self.backgroundColor = [UIColor clearColor];
	}
	return self;
}

@synthesize actionTarget, onPress, onRelease;


- (BOOL)beginTrackingWithTouch:(UITouch *)touch withEvent:(UIEvent *)event 
{
	if(overload)[actionTarget beginTrackingWithTouch:touch withEvent:event];
	if([actionTarget respondsToSelector:onPress])
	{
		[actionTarget performSelector:onPress];
	}
	return YES;
}

- (void)endTrackingWithTouch:(UITouch *)touch withEvent:(UIEvent *)event 
{
	if(overload)[actionTarget endTrackingWithTouch:touch withEvent:event];
	if([actionTarget respondsToSelector:onRelease])
	{
		[actionTarget performSelector:onRelease];
	}
}

- (void)drawRect:(CGRect)rect {
	// Drawing code
}


- (void)dealloc {
	[super dealloc];
}


@end
