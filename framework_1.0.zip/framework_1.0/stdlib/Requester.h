//
//  Requester.h
//  
//
//  Create by Andrew Paul Simmons on 7/25/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//


#import <Foundation/Foundation.h>
#import "Utils.h"

@interface Requester : NSObject 
{
	NSString* requestURL;
	NSString* multipartBoundry;
	
	NSData* uploadData;
	NSMutableData* receivedData;
	NSString* uploadFieldName;
	NSString* uploadFileName;
	NSURLConnection* myConnection;
	
	//vars and method saved for retry
	NSString* requestMethod;
	NSDictionary* requestVars;
	
	BOOL canceled;
	BOOL requestFailed;
	//Actions
	id progressTarget;
	id actionTarget;
	SEL onResponse;
	SEL onFailure;
}


@property(assign, readwrite) SEL onResponse;
@property(assign, readwrite) SEL onFailure;
@property(readonly) NSString* requestURL;
@property(assign) id progressTarget;
//:::Public
- (id) initWithURL:(NSString*)url actionTarget:(id)target;
- (void) retry;
// It is safe to release Requester after submit has been invoked.
// (Requester retains self after submit is invoked. 
//  On response/failure complete Requester releases self.)
- (void) submit:(NSDictionary*)vars requestMethod:(NSString*)method;
- (void) attachData:(NSData*)data withFieldName:(NSString*)fieldName andFileName:(NSString*)filename;
-(void)cancel;
+ (NSString*) urlEncodeVars:(NSDictionary *)vars; // used for making requests in browser control

//:::Private
- (NSData *) multipartEncodeVars:(NSDictionary*)vars;
+ (NSString*) urlEncodeValue:(NSString*)str;
+ (NSString *) urlDecodeValue:(NSString *)str;
+ (NSString *) urlDecodeValue:(NSString *)str treatmentForPlus:(BOOL)tretment;
- (NSURLRequest*) buildPostRequestWithVars:(NSDictionary *)vars;
- (NSURLRequest*) buildGetRequestWithVars:(NSDictionary *)vars;
- (void)connectionDidFinishLoading:(NSURLConnection *)connection;

@end
