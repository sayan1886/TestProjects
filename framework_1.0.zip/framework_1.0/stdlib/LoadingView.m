//
//  LoadingView.m
//  MichaelJackson
//
//  Create by Andrew Paul Simmons on 7/9/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import "LoadingView.h"


@implementation LoadingView


- (id)initWithFrame:(CGRect)frame 
{
    if (self = [super initWithFrame:frame]) 
	{
        // Initialization code
		
		background = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)] autorelease];
		background.backgroundColor = [UIColor blackColor];
		background.alpha = 0.4;
		self.backgroundColor = [UIColor clearColor];
		[self addSubview:background];
		//UIImageView* loadingGraphic = [Utils imageViewWithImageName:@"cbsloading.png"];
		//[Utils centerView:loadingGraphic inView:self];
		//[self addSubview:loadingGraphic];
		UIActivityIndicatorView* ai = [Utils activityInidicatorCenteredInSize:self.frame.size];
		[Utils view:ai setX:ai.frame.origin.x + 25 setY:ai.frame.origin.y - 20];
		[self addSubview:ai];
		
		loadingText =  [Utils labelWithFrame:CGRectMake(0, 0, 100, 30) 
												 text:@"Loading..." 
											textColor:[Utils colorFromHex:0xFFFFFF] 
											 fontName:FONTNAME_helvetica
											 fontSize:13 
												 bold:YES];
		
		[self addSubview:loadingText];
		[Utils centerView:loadingText inView:self];
		[Utils view:loadingText setX:loadingText.frame.origin.x - 5 setY:loadingText.frame.origin.y - 20];
    }
	
    return self;
}

- (void) setText:(NSString*)value
{
	loadingText.text = value;
}

-(NSString*)text
{
	return loadingText.text;
}

- (void)drawRect:(CGRect)rect 
{
    // Drawing code
}

- (void) startAnimating{
    for (UIView *view in [self subviews]) {
        if ([view isKindOfClass:[UIActivityIndicatorView class]]) {
            [(UIActivityIndicatorView *)view startAnimating];
        }
    }
}

- (void) stopAnimating{
    for (UIView *view in [self subviews]) {
        if ([view isKindOfClass:[UIActivityIndicatorView class]]) {
            [(UIActivityIndicatorView *)view startAnimating];
        }
    }
}

- (BOOL) isAnimating{
    BOOL isAnimating = NO;
    for (UIView *view in [self subviews]) {
        if ([view isKindOfClass:[UIActivityIndicatorView class]]) {
            isAnimating = [(UIActivityIndicatorView *)view isAnimating];
        }
    }
    return isAnimating;
}

- (void)dealloc 
{
	[super dealloc];
}


@end
