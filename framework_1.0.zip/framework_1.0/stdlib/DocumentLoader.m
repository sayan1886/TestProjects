//
//  DocumentLoader.m
//  EyeReport
//
//  Create by Andrew Paul Simmons on 9/30/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import "DocumentLoader.h"

@implementation DocumentLoader



- (id) init
{
	if(![super init]) return nil;
	
	NSException* exception = [NSException exceptionWithName:@"init failed"
													 reason:@"Must use init with URL"  
												   userInfo:nil];
	@throw exception;
	return self;
}

@synthesize onSuccess, onFailure;
@synthesize actionTarget;


+ (void) loadDocumentAtURL:(NSString*)url actionTarget:(id)target 
				   success:(SEL)success_cb failure:(SEL)failure_cb
{
	DocumentLoader* dl = [(DocumentLoader*)[DocumentLoader alloc] initWithURL:url];
	dl.onSuccess = success_cb;
	dl.onFailure = failure_cb;
	dl.actionTarget = target;
}

- (id)initWithURL:(NSString*)stringURL 
{
	NSURLRequest* r = [[[NSURLRequest alloc] initWithURL:[NSURL URLWithString:stringURL]] autorelease];
	NSURLConnection* connection = nil;
	receivedData = [[NSMutableData alloc] initWithCapacity:100];
	connection = [[NSURLConnection alloc] initWithRequest:r delegate:self startImmediately:YES];
	[self retain];
	[Utils addNetworkUsage];
	return self;
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    // append the new data to the receivedData
    // receivedData is declared as a method instance elsewhere
	//////////NSLog(@"Did Receive Data");
    [receivedData appendData:data];
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    // this method is called when the server has determined that it
    // has enough information to create the NSURLResponse
    // it can be called multiple times, for example in the case of 
    // redirect, so each time we reset the data.
    // receivedData is declared as a method instance elsewhere
    [receivedData setLength:0];	
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
	NSString* response = [[[NSString alloc] initWithData:receivedData encoding:NSUTF8StringEncoding] autorelease];
	//////////NSLog(@"RequestCompleted Succesfully\n ___________________________________________\n%@\n __________________________________________________\n",response);
	[actionTarget performSelector:onSuccess withObject:response];

	[receivedData release];
	[connection release];
	[Utils removeNetworkUsage];
	[self release];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    ////////NSLog(@"Connection failed! Error - %@ %@", [error localizedDescription],[[error userInfo] objectForKey:NSErrorFailingURLStringKey]);
	
	if(onFailure)[actionTarget performSelector:onFailure withObject:[[error userInfo] objectForKey:NSErrorFailingURLStringKey]];
	[connection release];
	[receivedData release]; 
	[Utils removeNetworkUsage];
	[self release];
}

@end
