//
//  RegisterViewController.h
//  Qwiket
//
//  Create by Andrew Paul Simmons on 6/27/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Utils.h"
#import "fontnames.h"
#import "SettingsCell_TextEntry.h"
#import "SettingsCell_Switch.h"
#import "constants.h"
#import "SettingsCell_ToggleSegmentedControl.h"

@interface RegisterViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>
{
	id actionTarget;
	SEL onRegister;
	
	UITableView* myTableView;
	
	/* 
		In subclasses set these properties in the constructor to
		configure the table.
	 */
	UIButton* registerbtn;
	NSMutableDictionary* cells;
	CGRect tableFrame;
	UITableViewStyle tableStyle;
	
	BOOL ignoreNextKeyboardHideNotification;
	BOOL ignoreNextKeyboardShowNotification;
	BOOL selectedCellIsTextEntryCell;
	BOOL keyboardDown;
	

	NSTimer* insetUpdateTimer;
	
	BOOL keyboardIsVisible;
	BOOL oldKeyboardVisibility;
	BOOL registerInProgress;
}

@property(assign) id actionTarget;
@property(assign) SEL onRegister; // onSubmitWithUsername:(NSString*)username andPassword:(NSString*)password


//::Public
- (void) reactivate; //Override
- (void) enableRegister;
- (void) diableRegister;
//:: Protected
- (void) onPeformRegister;
- (void) createCells; //Override
- (void) deselectOthers:(UITableViewCell*)selectedCell; //Call on select
//::Private
-(void)genderSelectorChanged:(UITableViewCell*)genderSelectorCell;
- (void)doInit;

@end
