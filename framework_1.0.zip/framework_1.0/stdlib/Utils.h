//
//  Utils.h
//  ShowTreemo
//
//  Create by Andrew Paul Simmons on 7/30/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreFoundation/CoreFoundation.h>

#import <QuartzCore/QuartzCore.h>
#import "TraceImageView.h"
#import "HTMLEntitiesConverter.h"
#import <math.h>

@interface UINavigationBar (BackgroundImage)

- (void)scInsertSubview:(UIView *)view atIndex:(NSInteger)index;
- (void)scSendSubviewToBack:(UIView *)view;

@end


@interface Utils : NSObject 
{

}
////////UINAVIGATIONBAR OVERLOADS

+ (void)customizeNavigationController:(UINavigationController *)navController;
+ (void)customizeNavigationController:(UINavigationController *)navController withImageNamed:(NSString*)imageName;


//Swizzling
+ (void)swizzleSelector:(SEL)orig ofClass:(Class)c withSelector:(SEL)new;

//////////////
+ (double) distanceGiveLat1:(NSString*)lat1
					   lon1:(NSString*)lon1
					   lat2:(NSString*)lat2
					   lon2:(NSString*)lon2;
//SharedApplication
+ (void) navigateToPhoneNumber:(NSString*)number;
+ (void) navigateToURL:(NSString*)urlString;
+ (void)navigateToMailWithAddress:(NSString*)address
						  subject:(NSString*)subject
							 body:(NSString*)body;

//System properties
+ (BOOL) isPad;

//Buttons
+ (UIButton*) buttonWithNormalImageNamed:(NSString*)normalImageName
						pressedImageName:(NSString*)pressedImageName
							actionTarget:(id)actionTarget
								selector:(SEL)selector
									   x:(float)x
									   y:(float)y;

+ (UIButton *)buttonWithTitle:	(NSString *)title
					   target:(id)target
					 selector:(SEL)selector
						frame:(CGRect)frame
						image:(UIImage *)image
				 imagePressed:(UIImage *)imagePressed
				darkTextColor:(BOOL)darkTextColor;

+ (UIButton *) buttonWithFrame:(CGRect)frame 
						 label:(NSString*)label
				  actionTarget:(id)target
						 onTap:(SEL)onTap_cb;

// Labels
+ (void)setLabel:(UILabel *)label withText:(NSString *)text maxHeight:(int)maxHeight;

+(UILabel*) labelWithFrame:(CGRect)frame 
					  text:(NSString*)textOrNill
				 textColor:(UIColor*)textColorOrNil 
				  fontName:(NSString*)fontNameOrNil
				  fontSize:(CGFloat)fontSize 
					  bold:(BOOL)bold;


+(UILabel*) labelWithFrame:(CGRect)frame 
					  text:(NSString*)textOrNill
				 textColor:(UIColor*)textColorOrNil 
				  fontName:(NSString*)fontNameOrNil
				  fontSize:(CGFloat)fontSize;


+ (UIWebView*) htmlTextViewWithFrame:(CGRect)frame
					   andHtmlString:(NSString*)text;

+ (UIScrollView*) scrollViewFromWebView:(UIWebView*)webview;

// Invocation
+ (NSInvocation*) makeInv:(SEL)selector target:(id)target;

// preferences
+ (void) setPreference:(NSString*)key withValue:(NSString*)value;
+ (NSString*) preferenceWithKey:(NSString*)key;
+ (NSString*) username;
+ (NSString*) authToken;

//user defaults
+ (void) resetFromUserDefaults;  // this will delete all content stored in user defaults (possibly not preferences too, but maybe)



// Cookies
+ (void) setCookieAtDomain:(NSString*)domain name:(NSString*)name value:(NSString*)value;
+ (void) deleteAllCookiesAtURL:(NSString*) urlString;
+ (void) deleteCookieAtDomain:(NSString*)domain withName:(NSString*)name;
+ (NSString*) retrieveCookieValueAtDomain:(NSString*)domain withName:(NSString*)name;

//AlertViews
+ (void) showAlertViewWithOKButtonAndLabel:(NSString*)label;
+ (void)showLoadingAlertViewWithLabel:(NSString*)label;
+ (void)hideLoadingAlertView;


// status bar network activity indicator
+ (void) addNetworkUsage;
+ (void) removeNetworkUsage;

//Strings
+ (NSString*) unescapeString:(NSString*)str;
+ (NSString*) string:(NSString*)str
	replaceSubstring:(NSString*)substr 
		  withString:(NSString*)repstr;
+ (NSString*) phoneNumberDigitStringFromString:(NSString*)str;
+ (NSString*) digitStringFromString:(NSString*)str;
+ (BOOL) string:(NSString*)str containsSubstring:(NSString*)substr;
+ (NSString*) string:(NSString*)str 
	replaceSubstring:(NSString*)substr 
		  withString:(NSString*)repstr 
	adjacentAsSingle:(BOOL)adjacentAsSingle;

+ (NSString*) urlStringFromWebSafeURL:(NSString*)string;
+ (NSArray*) splitString:(NSString*)str 
				onString:(NSString*)splitStr 
handleAdjacentDelimiterAsSingleDelimiter:(BOOL)adjacentAsSingle; 

+ (NSString*) trimString:(NSString*)str;
+ (NSArray*) splitString:(NSString*)str onString:(NSString*)splitStr;
+ (NSString*) joinArray:array byString:(NSString*)byStr;
+ (NSString*) nameStringFromString:(NSString*)str;
+ (NSString*) truncateAndAddEllipsisWithString:(NSString*)str maxLengthIncludingEllipsis:(int)maxLength;
+ (NSString*) commaFormatedStringFromString:(NSString*)str;


//Colors
+ (UIColor*) colorFromHex:(int)hexColor;
+ (UIColor*) colorFromImageName:(NSString*)imageName;

//ViewControllers
+ (BOOL)viewControllerWillBeReleasedDuringMemoryWarning:(UIViewController*)vc;

//UIActivityIndicatorView
+ (UIActivityIndicatorView*) activityIndicatorWhite;
+ (UIActivityIndicatorView*) activityIndicatorWhiteWithX:(float)x y:(float)y;

+ (UIActivityIndicatorView*) activityIndicatorGray;
+ (UIActivityIndicatorView*) activityIndicatorGrayWithX:(float)x y:(float)y;

+ (UIActivityIndicatorView*) activityInidicatorCenteredInSize:(CGSize)size; 
+ (UIActivityIndicatorView*) activityInidicatorCenteredInSize:(CGSize)size white:(BOOL)white;

//UIImageViews
+ (UIImageView*) imageViewWithImageName:(NSString*)imageName;
+ (UIImageView*) imageViewWithImageName:(NSString*)imageName memlog:(BOOL)memlog;
+ (UIImageView*) imageViewWithImageName:(NSString*)imageName x:(float)x y:(float)y memlog:(BOOL)memlog; 

+ (UIImageView*) imageViewWithImageName:(NSString*)imageName x:(float)x y:(float)y;
+ (UIImageView*) imageViewFromView:(UIView*)view;
+ (UIImageView *) hiresImageViewWithImageName:(NSString *)imageName;
+(UIImageView *) hiresImageViewWithImageName:(NSString *)imageName x:(int)x y:(int)y;
//Views
+ (void) view:(UIView*)view setX:(float)x;
+ (void) view:(UIView*)view setY:(float)y;
+ (void) view:(UIView*)view setX:(float)x setY:(float)y;
+ (void) view:(UIView*)view setWidth:(float)width;
+ (void) view:(UIView*)view setHeight:(float)height;
+ (UIView*) centerView:(UIView*)smallView inView:(UIView*)largerView;
+ (void) drawBorderAroundView:(UIView*)view;
+ (void) view:(UIView*)view resizeWidthToFitText:(NSString*)text withFont:(UIFont*)font;


+ (void) recordToAnimate;
+ (void) recordToAnimateWithDuration:(float)duration;
+ (void) recordToAnimateWithDuration:(float)duration 
							  target:(id)actionTarget
						  onComplete:(SEL)onComplete;
+ (void) recordToAnimateWithDuration:(float)duration 
							  easing:(UIViewAnimationCurve)easing
							  target:(id)actionTarget
						  onComplete:(SEL)onComplete;
+ (void) animate;

//Rects
+ (CGRect) rectWithRect:(CGRect)rect x:(float)x;
+ (CGRect) rectWithRect:(CGRect)rect y:(float)y;
+ (CGRect) rectWithRect:(CGRect)rect width:(float)width;
+ (CGRect) rectWithRect:(CGRect)rect height:(float)height;

+ (void) logRect:(CGRect)rect message:(NSString*)message;

//Index Paths
+ (NSIndexPath*)indexPathWithIndex:(int)indexOne withIndex:(int)indexTwo;

//PropertyTags
// str is comma delimited tag string: key1_value1,key2_value2,...,keyn_valuen
+ (NSDictionary*) propertyTagDictionaryFromString:(NSString*)str;
+ (NSString*) propertyTagStringFromDictionary:(NSDictionary*)dict;



//Dates
+ (double) timestampDouble;
+ (NSNumber*) timestampNSNumber;
+ (NSString*) timestampNSString;
+ (NSString*) readableTimeIntervalFromNSTimeInterval:(NSTimeInterval)timeInterval;


//internet
+ (BOOL) validateEmail: (NSString *) email;
+ (BOOL) validateUserName:(NSString *)userName;
+ (BOOL) validateName:(NSString *)name multipartCount:(int)multipart;
+ (BOOL) validateMobileNo:(NSString *)mobile;
+ (BOOL)isInternetReachable;
@end
