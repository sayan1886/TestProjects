//
//  TreemoSegmentControl.h
//  Qwiket
//
//  Created by steve on 8/20/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Utils.h"

@interface TreemoSegmentControl : UIView {
	UIImageView* leftSideSelected;
	UIImageView* leftSide;
	UIImageView* rightSide;
	UIImageView* rightSideSelected;
	UIImageView* background;
	UIImageView* seperator; //optional

	//CGRect frame;
	NSInteger selectedIndex;
	NSInteger split_point;
	
	id delegate;
}

- (id) init;
- (id) initWithFrame:(CGRect)frame
		   leftImage:(UIImageView*)leftImage
		  rightImage:(UIImageView*)rightImage
   leftImageSelected:(UIImageView*)leftImageSelected
  rightImageSelected:(UIImageView*)rightImageSelected;


- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event;
- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event;
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event;
- (void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event;


@property NSInteger selectedIndex;
@end
