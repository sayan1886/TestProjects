//
//  ThumbnailView.m
//  eMagazine
//
//  Created by SOHAMPAUL on 04/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ThumbnailView.h"
#import <QuartzCore/QuartzCore.h>

@implementation ThumbnailView


- (id)initWithOrigin:(CGPoint)origin andImage:(UIImage*)img {
	CGRect frm = CGRectMake(origin.x, origin.y, 100, 100);
    if ((self = [super initWithFrame:frm])) {
        
		UIImageView *thumbView= [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 100, 100)];
		thumbView.image = img;
		thumbView.backgroundColor = [UIColor clearColor];
		thumbView.userInteractionEnabled = NO;
		[self addSubview:thumbView];
		
		CALayer *viewLayer = [self layer];
		[viewLayer setCornerRadius:6.0];
		[viewLayer setBorderWidth:1.0];
		[viewLayer setBorderColor:[[UIColor grayColor] CGColor]];
		
		[self setClipsToBounds:YES];
		[thumbView release];
		thumbView = nil;
    }
    return self;
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (void)dealloc {
    [super dealloc];
}


@end
