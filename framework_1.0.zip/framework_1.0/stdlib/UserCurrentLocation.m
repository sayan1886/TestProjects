    //
//  UserCurrentLocation.m
//  SKIIP
//
//  Created by Sayan Chatterjee on 25/03/11.
//  Copyright 2011 ObjectSol. All rights reserved.
//

#import "UserCurrentLocation.h"
#import "BusyIndicatorView.h"


@implementation UserCurrentLocation

@synthesize delegate;

#pragma mark LOCATION MANAGER
-(void)getCurrentLocation{
	if(locationManager)
		[locationManager release];
	
	locationManager=[[CLLocationManager alloc] init];
	locationManager.delegate=self;
	locationManager.distanceFilter = 25.0f;//kCLDistanceFilterNone;
	locationManager.desiredAccuracy= kCLLocationAccuracyBest;//kCLLocationAccuracyBest;
	[locationManager startUpdatingLocation];//need to open
	
	//self.latitude=@"22.639875";//Airport 1 no
	//self.longitude=@"88.428149";//Airport 1 no
	//[self.delegate locationFound];
    
    BusyIndicatorView *loding = [BusyIndicatorView defaultLoadingViewWithText:@""] ;
    [loding setText:@"Getting Locations"];
    [loding startLoading];
    

}

-(void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation{
	
	NSLog(@"Location: %@", [newLocation description]);
	lat = [NSString stringWithFormat:@"%0.9f",newLocation.coordinate.latitude];
	long_ = [NSString stringWithFormat:@"%0.9f",newLocation.coordinate.longitude];
	
	if(!lat){
		lat = @"0.0";
	}
	if(!long_){
		long_ = @"0.0";
	}
	
	if(([lat isEqualToString:@"0.0"]&&[long_ isEqualToString:@"0.0"])||([lat isEqualToString:@"0"]&&[long_ isEqualToString:@"0"])){
		[self.delegate locationError:@"Location Not Found"];
	}
	else
	{
		[self.delegate locationFoundWithLatitude:lat andLongitude:long_];
	}
    
    [[BusyIndicatorView defaultLoadingViewWithText:@""] stopLoading];
    [locationManager stopUpdatingLocation];
}

-(void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error{
	NSLog(@"location Error = %@",error);
	[locationManager stopUpdatingLocation];
	[self.delegate locationError:error.localizedDescription];
    [[BusyIndicatorView defaultLoadingViewWithText:@""] stopLoading];
    [locationManager stopUpdatingLocation];
}


- (void)dealloc {
	lat = nil, [lat release];
	long_ = nil, [long_ release];
	locationManager = nil, [locationManager release];
	delegate = nil;
	locationManager.delegate = nil;
    [super dealloc];
}


@end
