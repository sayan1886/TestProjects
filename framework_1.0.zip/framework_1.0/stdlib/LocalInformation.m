//
//  LocalInformation.m
//



#import "LocalInformation.h"
@implementation LocalInformation
@synthesize actionTarget,placemark,lat,lon,myLocation;

NSMutableArray* cityNameQueue;
NSMutableArray* latLonQueue;
LocalInformation* firstLM;
BOOL hasLongLat;
BOOL firstloadComplete;
NSNumber* longitude;
NSNumber* latitude;
CLLocationManager* lm;
NSString* _cityName;
MKReverseGeocoder* reverseGeoCoder;




+ (LocalInformation*) getLatLonWithDelegate:(id)actionTarget 
{
	
	if(!latLonQueue) latLonQueue = [[NSMutableArray alloc] initWithCapacity:0];
	
	if(hasLongLat && lm)
	{
		[actionTarget localInformationGotLatitude:latitude longitude:longitude];
	}
	else
	{
		LocalInformation* li = [[LocalInformation alloc] createLatLon:actionTarget];
		[latLonQueue addObject:li];
		return li;
	}
	 
	return nil;
	 
	
}

+ (LocalInformation*) getCityNameWithDelegate:(id)actionTarget 
{
	if(!cityNameQueue) cityNameQueue = [[NSMutableArray alloc] initWithCapacity:0];
	
	if([Utils preferenceWithKey:@"cityName"] && firstloadComplete && firstloadComplete)
	{
		[actionTarget localInformationGotCityName:[Utils preferenceWithKey:@"cityName"] andReference:nil];
	}
	else
	{
		
		LocalInformation* li = [[LocalInformation alloc] createCity:actionTarget];
		[cityNameQueue addObject:li];
		return li;
	}
	return nil;
	
}

// Constructors 

- (id) createLatLon:(id)target
{
	if(self = [super init])
	{
		self.actionTarget = target;
		[self createLocationRequest];
	}
	return self;
}

- (id) createCity:(id)target
{
	if(self = [super init])
	{
		self.actionTarget = target;
		getReverseGeoCoder = YES;
		[self createLocationRequest];
	}
	return self;
}


+ (void) onLoadCoords:(CLLocation *)newLocation localInformation:(LocalInformation*)li
{
	[Utils setPreference:@"LatLon" withValue:[NSString stringWithFormat:@"%@,%@",latitude,longitude]];
	[li.actionTarget localInformationGotLatitude:latitude longitude:longitude];
	[latLonQueue removeObject:li];
	//remove from queue?
}

+ (void) onLoadCoordsFailure:(NSString*)message localInformation:(LocalInformation*)li
{
	[li.actionTarget localInformationCoordsRequestFailed:message];
	[latLonQueue removeObject:li];
}

+ (void) onLoadCity:(NSString *)cityName localInformation:(LocalInformation*)li 
{
	[li.actionTarget localInformationGotCityName:cityName andReference:li];	
	[cityNameQueue removeObject:li];
}

+ (void) onLoadCityFailure:(NSString*)message localInformation:(LocalInformation*)li
{
	if([Utils preferenceWithKey:@"cityName"])
	{
		[li.actionTarget localInformationGotCityName:[Utils preferenceWithKey:@"cityName"] andReference:li];
	}
	else
	{
		[li.actionTarget localInformationCityRequestFailed:message];
	}
	[cityNameQueue removeObject:li];
}


- (void)createLocationRequest
{

	if(!lm)
	{	firstloadComplete = NO;
		lm = [[CLLocationManager alloc] init ];
		lm.delegate = self;
		lm.desiredAccuracy = kCLLocationAccuracyBest;
		lm.distanceFilter = kCLDistanceFilterNone;
		//if(!(TARGET_IPHONE_SIMULATOR))
		//{
		[lm startUpdatingLocation];
		//}
		firstLM = [self retain];
	}
	
	if(lm.locationServicesEnabled)
	{
		[lm startUpdatingLocation];
	}
	else
	{
		for(int i = 0 ; i < [latLonQueue count]; i ++)
		{
			id temp = [latLonQueue objectAtIndex:i];
			[temp retain];
			[LocalInformation onLoadCoordsFailure:@"Operation Denied by User" localInformation:nil];
		}
		
		
		for(int i = 0 ; i < [cityNameQueue count]; i ++)
		{
			LocalInformation* temp = [cityNameQueue objectAtIndex:i];
			[temp retain];
			[LocalInformation onLoadCityFailure:@"Operation Denied by User" localInformation:nil];
		}	
	}

}

- (void)locationManager:(CLLocationManager *)manager
	didUpdateToLocation:(CLLocation *)newLocation
		   fromLocation:(CLLocation *)oldLocation
{
	hasLongLat = YES;
	//firstloadComplete = YES;
	lat = newLocation.coordinate.latitude;
	lon = newLocation.coordinate.longitude;
	NSNumber* lat_num = [NSNumber numberWithFloat:lat];
	NSNumber* lon_num = [NSNumber numberWithFloat:lon];
	longitude = [lon_num retain];
	latitude = [lat_num retain];
	hasLongLat = YES;
	[Utils setPreference:@"LatLon" withValue:[NSString stringWithFormat:@"%@,%@",latitude,longitude]];
	//if(internalVersion)
	//{
	for(int i = 0 ; i < [latLonQueue count]; i ++)
	{
		id* temp = [latLonQueue objectAtIndex:i];
		[LocalInformation onLoadCoords:newLocation localInformation:temp];
	}
	
	//[lm stopUpdatingLocation];
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{	
	if(error.code == kCLErrorDenied)
	{
		////NSLog(@"CANCEL ERROR: %@",[error localizedDescription]);
		//[lm stopUpdatingLocation];
		//lm.delegate = nil;
	}
	for(int i = 0 ; i < [latLonQueue count]; i ++)
	{
		id temp = [latLonQueue objectAtIndex:i];
		[temp retain];
		[LocalInformation onLoadCoordsFailure:[error localizedDescription] localInformation:temp];
	}


	for(int i = 0 ; i < [cityNameQueue count]; i ++)
	{
		LocalInformation* temp = [cityNameQueue objectAtIndex:i];
		[temp retain];
		[LocalInformation onLoadCityFailure:[error localizedDescription] localInformation:temp];
	}	
	
}

- (void)reverseGeocoder:(MKReverseGeocoder *)geocoder didFailWithError:(NSError *)error
{
	//////NSLog(@"error:%@",error);
	for(int i = 0 ; i < [cityNameQueue count]; i ++)
	{
		LocalInformation* temp = [cityNameQueue objectAtIndex:i];
		[temp retain];
		[LocalInformation onLoadCityFailure:[error localizedDescription] localInformation:temp];
	}
}

- (void)reverseGeocoder:(MKReverseGeocoder *)geocoder didFindPlacemark:(MKPlacemark *)_placemark
{
	_cityName = [_placemark.locality copy];
	if(_cityName)
	{	
		[Utils setPreference:@"cityName" withValue:_cityName];
	}
	placemark = [_placemark retain];
	
	if(placemark)
	{
		[Utils setPreference:@"zipcode" withValue:[placemark.postalCode copy]];
	
		firstloadComplete = YES;
		for(int i = 0 ; i < [cityNameQueue count]; i ++)
		{
			LocalInformation* temp = [cityNameQueue objectAtIndex:i];
			[temp retain];
			[LocalInformation onLoadCity:_cityName localInformation:temp];
		}
	}
	[lm stopUpdatingLocation];
	lm.delegate = nil;
	[lm release];
	
	reverseGeoCoder.delegate = nil;
	[reverseGeoCoder release];
}








- (void)dealloc 
{
	//[lm release];
	//[reverseGeoCoder release];
	//[cityName release];
	//[placemark release];
    [super dealloc];
}

@end
