//
//  CategoryItem.m
//  EyeReport
//
//  Create by Andrew Paul Simmons on 10/1/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import "CategoryItem.h"

@implementation CategoryItem

@synthesize title, thumbnail, url, type, feed, uploadTags, index, 
				featureButtonNormal, featureButtonPressed;


- (id)initWithCoder:(NSCoder *)coder
{		
	self = [super init];	
	
	self.title = [coder decodeObjectForKey:@"title"];
	self.description = [coder decodeObjectForKey:@"description"];
	self.thumbnail = [coder decodeObjectForKey:@"thumbnail"];
	self.url = [coder decodeObjectForKey:@"url"];
	self.type = [coder decodeObjectForKey:@"type"];
	self.feed = [coder decodeObjectForKey:@"feed"];
	self.uploadTags = [coder decodeObjectForKey:@"uploadTags"];
	self.index = [coder decodeObjectForKey:@"index"];
	
	self.featureButtonNormal = [coder decodeObjectForKey:@"featureButtonNormal"];
	self.featureButtonPressed = [coder decodeObjectForKey:@"featureButtonPressed"];
	
	return self;
}

- (void)encodeWithCoder:(NSCoder *)coder
{
    [coder encodeObject:title forKey:@"title"];	
	[coder encodeObject:description forKey:@"description"];	
	[coder encodeObject:thumbnail forKey:@"thumbnail"];	
    [coder encodeObject:url forKey:@"url"];	
	[coder encodeObject:type forKey:@"type"];	
	[coder encodeObject:feed forKey:@"feed"];
	[coder encodeObject:uploadTags forKey:@"uploadTags"];
	[coder encodeObject:index forKey:@"index"];
	
	[coder encodeObject:featureButtonNormal forKey:@"featureButtonNormal"];
	[coder encodeObject:featureButtonPressed forKey:@"featureButtonPressed"];
}

- (void) setDescription:(NSString*)value
{
	//if(description)[description release];
	description = [value copy];
}

- (NSString*) description
{
	return description ? description : @"";
}
- (void) dealloc 
{
	[title release];
	[description release];
	[thumbnail release];
	[type release];
	[feed release];
	[url release];
	[featureButtonNormal release];
	[featureButtonPressed release];
	[uploadTags release];
	[index release];
	[super dealloc];
}
@end
