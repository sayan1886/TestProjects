//
//  MessageCompositionViewController.m
//  Qwiket
//
//  Created by steve on 8/12/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import "MessageCompositionViewController.h"


@implementation MessageCompositionViewController

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (id) initWithNibName:(NSString*)nibNameOrNil bundle:(NSBundle*)bundle
{
	if(self = [super initWithNibName:nibNameOrNil bundle:bundle])
	{
		////////NSLog(@"MessageCompositionViewController initWithNibName reached.");
		[self doInit];
	}
	return self;
}
- (id) init 
{
	////////NSLog(@"MessageCompositionViewController init called.");
	if(self = [self initWithNibName:@"MessageCompositionViewController" bundle:nil])
	{
		[self doInit];
	}
	return self;	
}

- (void) doInit
{
	myTableFrame = CGRectMake(0, 50, 320, 450);
	myTableStyle = UITableViewStylePlain;
	myTableView = [[[UITableView alloc] initWithFrame:myTableFrame style:myTableStyle] autorelease];
	myTableView.delegate = self;
	myTableView.dataSource = self;
	myTableView.scrollEnabled = NO;

	
}

- (void)didReceiveMemoryWarning {
		////////NSLog(@"messageCompositionViewController did recieve memeory warning.");
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}

- (void) createCells 
{
	{
		NSString* cellIdentifier = @"user";
		SettingsCell_TextEntry* cell;
		cell = [[[SettingsCell_TextEntry alloc] initWithFrame:CGRectZero reuseIdentifier:cellIdentifier]autorelease];
		cell.label.text = @"User";
		cell.propertyText.keyboardType = UIKeyboardTypeDefault;
		[cells setObject:cell forKey:cellIdentifier];
		////////NSLog(@"Created cell %@", [cells objectForKey:@"user"]);
		
	}
	
	{
		NSString* cellIdentifier = @"subject";
		SettingsCell_TextEntry* cell;
		cell = [[[SettingsCell_TextEntry alloc] initWithFrame:CGRectZero reuseIdentifier:cellIdentifier]autorelease];
		cell.label.text = @"Subject";
		cell.propertyText.keyboardType = UIKeyboardTypeDefault;
		[cells setObject:cell forKey:cellIdentifier];
		////////NSLog(@"Created cell %@", [cells objectForKey:@"subject"]);
	}
	/*
	 {
	 NSString* cellIdentifier = @"Body";
	 SettingsCell_TextEntry* cell;
	 cell = [[[SettingsCell_TextEntry alloc] initWithFrame:CGRectZero reuseIdentifier:cellIdentifier] autorelease];
	 cell.label.text = @"Body";
	 cell.propertyText.keyboardType = UIKeyboardTypeDefault;
	 [cells setObject:cell forKey:cellIdentifier];
	 ////////NSLog(@"Created cell %@", [cells objectForKey:@"Body"]);
	 }
	 */
}

- (IBAction) onSendMessage: (id) sender
{
	//this is a virtual function
}

- (IBAction) onCancel:(id)sender
{
	//this is a virtual function
}


- (void)dealloc {
    [super dealloc];
}

-(NSInteger)tableView:(UITableView*)tableView numberOfRowsInSection:(NSInteger)section
{
	return 0;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath 
{
		
	return nil;
}


@end
