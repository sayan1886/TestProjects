//
//  APSNavigationController.m
//  Qwiket
//
//  Create by Andrew Paul Simmons on 6/4/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import "APSNavigationController.h"


@implementation APSNavigationController



- (BOOL)navigationBar:(UINavigationBar *)navigationBar shouldPopItem:(UINavigationItem *)item
{
	int numViewControllers = [self.viewControllers count];
	
	for(int i = 0; i < numViewControllers; i++)
	{
		UIViewController* vc = [self.viewControllers objectAtIndex:i];
		if([vc respondsToSelector:@selector(shouldPopViewController:)])
		{
			if(![ ((id)vc) shouldPopViewController:self.topViewController])
			{
				return NO;
			}
		}
	}
	return [super navigationBar:navigationBar shouldPopItem:item];
}
 

/*
- (UIViewController *)popViewControllerAnimated:(BOOL)animated
{
	return [super popViewControllerAnimated:animated];
	////////NSLog(@"APS: Poping View Controller");
}
 */

- (void)dealloc {
    [super dealloc];
}


@end
