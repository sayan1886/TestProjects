//
//  APSWebImageView.h
//
//

#import <UIKit/UIKit.h>

#import "Utils.h"
#import "UIImage+Resize.h"


@interface APSWebImageView : UIImageView 
{	
	NSMutableData* receivedData;
	NSURLConnection* connection;
	NSString* urlString;
	bool stopped;
	BOOL enqueued;
	BOOL useCache;
	BOOL loaded;
	id actionTarget;
	
	
	//--- event handlers
	//invoked whenever the image had loaded
	SEL onLoadSuccess; 
	// invoked, in addition to onLoadSuccess, but only invoked when a load from the web
	// has completed.
	SEL onLoadFromWebSuccess; 
	SEL onLoadFailure;
	SEL onLoadStart;
	SEL onLoadProgress;
	
	UIActivityIndicatorView* ai;
	CGSize viewSize;
	float bytesTotal;
	float bytesLoaded;
	BOOL useConstraints;
	BOOL anchorTop;
	BOOL anchorLeft;
	BOOL diskCacheOnly;
	
	float widthConstraint;
	float heightConstraint;
	NSString* urlOfLoadedImage;
	CGRect originalFrame;
	BOOL myFadeIn;
	
	BOOL suppressFadeInOnLoadFromWeb;
}


//::Public

+ (void) clearRamCache;

/*
- (id) initWithConstraintFrame:(CGRect)constraintFrame;

- (id) initWithConstraintFrame:(CGRect)constraintFrame 
					 anchorTop:(BOOL)lockTop 
					anchorLeft:(BOOL)lockLeft;
 */

- (void) loadImageWithStringURL:(NSString*)url; //will first unload if loading/loaded does not cache
- (void) loadAndCacheImageWithStringURL: (NSString*)url;
- (void) loadAndCacheImageWithStringURL: (NSString*)url  loadNext:(BOOL)loadNext;
- (BOOL) imageIsDiskCachedForStringURL:(NSString*)aURL;
- (void) cancel;  // cancel the load request
- (void) unload;  // remove/release the image and/or if loading cancel the load request

// optional callbacks, example callback prototype: -(void) onLoadSuccess;
@property (assign) id actionTarget;
@property (assign) SEL onLoadSuccess;
@property (assign) SEL onLoadFromWebSuccess;
@property (assign) SEL onLoadFailure;
@property (assign) SEL onLoadProgress;
@property (assign) SEL onLoadStart;
@property (assign) BOOL suppressFadeInOnLoadFromWeb;
@property (assign) BOOL diskCacheOnly;
@property (readonly) float bytesLoaded;
@property (readonly) float bytesTotal;

@property (readonly) BOOL loaded;
@property (assign) CGSize viewSize;
// would onLoadCancel also be useful here?
+( void)suspendFadeIn;


//Prevent a cached image from being cleared from the cache
// saved images will be skiped when tabulating the cache size
+ (void) saveCachedImageWithURL:(NSString*)imageURL;
//Allow a cached image to be cleared from cache 
+ (void) unsaveCachedImageWithURL:(NSString*)imageURL;


//::Private
- (CGRect) frameForImageSize:(CGSize)imageSize;
- (void) enqueueLoadRequest;
- (void) loadNextRequest;
- (void) startLoad; 
- (void) loadDone;
+ (void) registerToReceiveLowMemoryWarnings;
+ (void) registerToReceiveApplicationTerminationNotification;
+ (void) registerToReceiveRelevantSystemNotifications;

// disk cache
- (void) setDiskCachedImageData:(NSData*)img_data forURL:(NSString*)url;
- (UIImage*) cachedImageForURL:(NSString*)url;

- (UIImage*) reasonablizeImageFromImage:(UIImage*)img;

@end
