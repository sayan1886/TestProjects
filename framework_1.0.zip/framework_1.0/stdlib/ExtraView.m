//
//  ExtraView.m
//  HarpersIsland
//
//  Create by Andrew Paul Simmons on 4/2/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import "ExtraView.h"


@implementation ExtraView

@synthesize extra;

- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        // Initialization code
    }
    return self;
}


- (void)drawRect:(CGRect)rect {
    // Drawing code
}


- (void)dealloc {

    [super dealloc];
}


@end
