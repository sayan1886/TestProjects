//
//  Utils.m
//  ShowTreemo
//
//  Create by Andrew Paul Simmons on 7/30/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import "Utils.h"

#import "APIBinding.h"
#import "Requester.h"
#import "LocalInformation.h"
#import <MapKit/MapKit.h>
#import <math.h>
#import </usr/include/objc/objc-class.h>
#import <Foundation/Foundation.h>
#import "Reachability.h"

#define kSCNavigationBarBackgroundImageTag 6183746
#define kSCNavigationBarTintColor [UIColor colorWithRed:0.0 green:0.0 blue:0.00 alpha:1.0]
#define RADIUS 3963.1676
#define PI 3.14159265



@implementation UINavigationBar (BackgroundImage)

- (void)scInsertSubview:(UIView *)view atIndex:(NSInteger)index
{
    [self scInsertSubview:view atIndex:index];
	
    UIView *backgroundImageView = [self viewWithTag:kSCNavigationBarBackgroundImageTag];
    if (backgroundImageView != nil)
    {
        [self scSendSubviewToBack:backgroundImageView];
    }
}

- (void)scSendSubviewToBack:(UIView *)view
{
    [self scSendSubviewToBack:view];
	
    UIView *backgroundImageView = [self viewWithTag:kSCNavigationBarBackgroundImageTag];
    if (backgroundImageView != nil)
    {
        [self scSendSubviewToBack:backgroundImageView];
    }
}

@end

@implementation Utils

///UINavigationBar Overload

+ (void)customizeNavigationController:(UINavigationController *)navController withImageNamed:(NSString*)imageName
{
	UINavigationBar *navBar = [navController navigationBar];
    [navBar setTintColor:kSCNavigationBarTintColor];
	
    UIImageView *imageView = (UIImageView *)[navBar viewWithTag:kSCNavigationBarBackgroundImageTag];
    if (imageView == nil)
    {
        imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:imageName]];
        [imageView setTag:kSCNavigationBarBackgroundImageTag];
        [navBar insertSubview:imageView atIndex:0];
        [imageView release];
    }
}

+ (void)customizeNavigationController:(UINavigationController *)navController
{
	[Utils customizeNavigationController:navController withImageNamed:@"header.png"];
}
//////////////////////	


//swizzelling
+ (void)swizzleSelector:(SEL)orig ofClass:(Class)c withSelector:(SEL)new
{
    Method origMethod = class_getInstanceMethod(c, orig);
    Method newMethod = class_getInstanceMethod(c, new);
	
    if (class_addMethod(c, orig, method_getImplementation(newMethod), method_getTypeEncoding(newMethod)))
    {
        class_replaceMethod(c, new, method_getImplementation(origMethod), method_getTypeEncoding(origMethod));
    }
    else
    {
        method_exchangeImplementations(origMethod, newMethod);
    }
}

//degrees 
+ (long double) degreesToRadians:(long double)degrees
{
	return degrees * PI/180;
}
+ (long double) distanceGiveLat1:(NSString*)lat1
					   lon1:(NSString*)lon1
					   lat2:(NSString*)lat2
					   lon2:(NSString*)lon2
{
	long double dlat1,dlat2,dlon1, dlon2;
	sscanf([lat1 cString],"%Lf",&dlat1 );
	sscanf([lat2 cString],"%Lf",&dlat2 );
	sscanf([lon1 cString],"%Lf",&dlon1 );
	sscanf([lon2 cString],"%Lf",&dlon2 );
	
	dlat1 = [Utils degreesToRadians:dlat1];
	dlat2 = [Utils degreesToRadians:dlat2];
	dlon1 = [Utils degreesToRadians:dlon1];
	dlon2 = [Utils degreesToRadians:dlon2];
	long double delta_lat = dlat2 - dlat1;
	long double delta_lon = dlon2 - dlon1;
	
	long double a = pow(sinl(delta_lat / 2.0) , 2) + cosl(dlat1)*cosl(dlat2) * pow(sin(delta_lon/2.0),2);
	long double c = 2 * atan2l(sqrtl(a),sqrtl(1-a));
	return c * RADIUS;
}
+ (void) setPreference:(NSString*)key withValue:(NSString*)value
{
	// Set up the preference.
	
	CFStringRef key_strref = (CFStringRef)key;
	
	//////////NSLog(@"Set preference value: %@", value);
	CFPreferencesSetAppValue(key_strref, (CFStringRef)value, kCFPreferencesCurrentApplication);
	
	// Write out the preference data.
	CFPreferencesAppSynchronize(kCFPreferencesCurrentApplication);
}

+ (NSString*) preferenceWithKey:(NSString*)key
{
	NSString* prefValue;
	prefValue = (NSString*)CFPreferencesCopyAppValue((CFStringRef)key, kCFPreferencesCurrentApplication);
	return prefValue;
}

+ (NSString*) urlStringFromWebSafeURL:(NSString*)string
{
	return [string stringByReplacingPercentEscapesUsingEncoding:NSASCIIStringEncoding];
}


+ (void) resetFromUserDefaults  // this will delete all content stored in user defaults
{
	[[NSUserDefaults standardUserDefaults] setPersistentDomain:[NSDictionary dictionary] 
													   forName:[[NSBundle mainBundle] bundleIdentifier]];
}

+ (UIWebView*) htmlTextViewWithFrame:(CGRect)frame
					   andHtmlString:(NSString*)text
{
	UIWebView* charityText_wv = [[[UIWebView alloc] initWithFrame:frame] autorelease];
    charityText_wv.backgroundColor = [UIColor clearColor];
    charityText_wv.opaque = NO;
    NSArray *sv = [NSArray arrayWithArray:[charityText_wv subviews]];
    
    UIScrollView *webScroller = (UIScrollView *)[sv objectAtIndex:0];
    
    NSArray *wsv = [NSArray arrayWithArray:[webScroller subviews]];
    
    [[wsv objectAtIndex:6] setHidden:YES];
    [[wsv objectAtIndex:7] setHidden:YES];
    [[wsv objectAtIndex:8] setHidden:YES];
    [[wsv objectAtIndex:9] setHidden:YES];
    
    [charityText_wv loadHTMLString:text baseURL:nil];
	return [charityText_wv retain];
}

+ (UIScrollView*) scrollViewFromWebView:(UIWebView*)webview
{
	NSArray *sv = [NSArray arrayWithArray:[webview subviews]];    
    UIScrollView* webScroller = (UIScrollView *)[sv objectAtIndex:0];
	
	return webScroller;
}



+ (NSString*) username
{
	return [Utils preferenceWithKey:@"username"];
}

+ (void) navigateToPhoneNumber:(NSString*)number
{
	NSString* phoneNumberURLString = [NSString stringWithFormat:@"tel:%@", number];
	////////NSLog(@"attempting to call: %@",phoneNumberURLString);
	
	[[UIApplication sharedApplication] openURL:[NSURL URLWithString:phoneNumberURLString]]; 
}
+ (void)navigateToMailWithAddress:(NSString*)address
						   subject:(NSString*)subject
							  body:(NSString*)body

{

	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:2];
	
	[vars setObject:subject forKey:@"subject"];
	[vars setObject:body forKey:@"body"];
	NSString* urlEncodedVars = [Requester urlEncodeVars:vars];
	
	
	NSString* mailtoString = [NSString stringWithFormat:@"mailto:%@?%@", address, urlEncodedVars];
	////////NSLog(@"MailtoString %@", mailtoString);
	[[UIApplication sharedApplication] openURL:[NSURL URLWithString:mailtoString]];
}

+ (BOOL) isPad 
{
    return (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad);
}

+ (NSString*) authToken
{
	return [Utils preferenceWithKey:@"authToken"];
}

+ (NSInvocation*) makeInv:(SEL)selector target:(id)target 
{
	NSMethodSignature * sig = nil;
	sig = [[target class] instanceMethodSignatureForSelector:selector];
	if(sig == nil)
	{
		////////NSLog(@"no method with signature %@", selector);
	}
	NSInvocation* inv = nil;
	inv = [NSInvocation invocationWithMethodSignature:sig]; // no need to release
	[inv setTarget:target];
	[inv setSelector:selector];
	return inv;
}



+ (void) sendUserLocationToServer
{
	if([self authToken])
	{
		[LocalInformation getCityNameWithDelegate:self];
		 
		 //loadCityNameWithTarget:self 
			//				   onLoadCitySuccess:@selector(onLoadCityToSendAsUserLocation:localInformation:)
			//				   onLoadCityFailure:@selector(onLoadCityToSendAsUserLocationFailure:)];
	}
	else
	{
		////////NSLog(@"Ignoring request to store location because user is not logged in");
	}
}

- (void) localInformationGotCityName:(NSString*)cityName andReference:(LocalInformation*)localInformation;
{
	MKPlacemark* placemark = localInformation.placemark;
	NSString* locationDescription = [NSString stringWithFormat:@"%@, %@", cityName, placemark.administrativeArea];
	[APIBinding userEditProfileWithLocation:locationDescription
							   actionTarget:nil
								 success_cb:nil
								 failure_cb:nil];
	
}

+ (void) onLoadCityToSendAsUserLocationFailure:(NSString*)message
{
	////////NSLog(@"Could not send user location [%@]", message);
}

+(UILabel*) labelWithFrame:(CGRect)frame 
					  text:(NSString*)textOrNill
				 textColor:(UIColor*)textColorOrNil 
				  fontName:(NSString*)fontNameOrNil
				  fontSize:(CGFloat)fontSize 
					  bold:(BOOL)bold
{
	UIColor* primaryColor = textColorOrNil ? textColorOrNil : [UIColor blackColor];
	NSString* fontName = (fontNameOrNil) ? fontNameOrNil : @"Helvetica";
	UIFont *font;
	if (bold) 
	{
		font = [UIFont fontWithName:fontName size:fontSize];
	}
	else 
	{
		font = [UIFont fontWithName:fontName size:fontSize];
	}
	
	UILabel *newLabel = [[[UILabel alloc] initWithFrame:frame] autorelease];
	newLabel.backgroundColor = [UIColor clearColor];
	newLabel.opaque = YES;
	newLabel.textColor = primaryColor;
	newLabel.highlightedTextColor = primaryColor;
	newLabel.font = font;
	if(textOrNill) newLabel.text = textOrNill;
	
	return newLabel;
}

+(UILabel*) labelWithFrame:(CGRect)frame 
					  text:(NSString*)textOrNill
				 textColor:(UIColor*)textColorOrNil 
				  fontName:(NSString*)fontNameOrNil
				  fontSize:(CGFloat)fontSize 

{
	UILabel *newLabel = [self labelWithFrame:frame  text:textOrNill textColor:textColorOrNil fontName:fontNameOrNil fontSize:fontSize bold:NO];
    newLabel.numberOfLines = 0;
    newLabel.adjustsFontSizeToFitWidth = YES;
    newLabel.lineBreakMode = UILineBreakModeWordWrap;
    newLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
	return newLabel;
}

// performs truncation and alligns vertically
+ (void)setLabel:(UILabel *)label withText:(NSString *)text maxHeight:(int)maxHeight
{
	
	NSString* labelText = text; //[self truncateAndAddEllipsisWithString:text maxLengthIncludingEllipsis:maxLength];
	
	CGSize stringSize = [labelText sizeWithFont:label.font 
							  constrainedToSize:CGSizeMake(label.frame.size.width, maxHeight) 
								  lineBreakMode:label.lineBreakMode];
	
	label.numberOfLines = 0; // required for multiline 
	
	// vertical align = top
	label.frame = CGRectMake(label.frame.origin.x, 
							   label.frame.origin.y, 
							   label.frame.size.width, 
							   stringSize.height
							   );
	
	label.text = labelText;
}

+(void)navigateToURL:(NSString*)urlString
{
	[[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlString]];
}


//UIActivityIndicator
+ (UIActivityIndicatorView*) activityIndicatorWhite
{
	return [self activityIndicatorWhiteWithX:0 y:0];
}

+ (UIActivityIndicatorView*) activityIndicatorWhiteWithX:(float)x y:(float)y
{
	UIActivityIndicatorView* ai = [[[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite] autorelease];
	[self view:ai setX:x setY:y];
	[ai startAnimating];
	return ai;
}

+ (UIActivityIndicatorView*) activityIndicatorGray
{
	return [self activityIndicatorGrayWithX:0 y:0];
}
+ (UIActivityIndicatorView*) activityIndicatorGrayWithX:(float)x y:(float)y
{
	UIActivityIndicatorView* ai = [[[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray] autorelease];
	[self view:ai setX:x setY:y];
	[ai startAnimating];
	return ai;
}



+ (UIActivityIndicatorView*) activityInidicatorCenteredInSize:(CGSize)size 
{
	return [self activityInidicatorCenteredInSize:size white:YES];
}
+ (UIActivityIndicatorView*) activityInidicatorCenteredInSize:(CGSize)size white:(BOOL)white
{
	UIActivityIndicatorViewStyle style = white ? UIActivityIndicatorViewStyleWhite : UIActivityIndicatorViewStyleGray;
	UIActivityIndicatorView* ai = [[[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:style] autorelease];
	[ai startAnimating];
	[self view:ai setX:(size.width - ai.frame.size.width)/2];
	[self view:ai setY:(size.height - ai.frame.size.height)/2];
	return ai;
}

//UIImageViews 

+(UIImageView *) hiresImageViewWithImageName:(NSString *)imageName
{
	
	UIImageView *imageView=[self hiresImageViewWithImageName:imageName x:0 y:0];
	
	return imageView;
}

+(UIImageView *) hiresImageViewWithImageName:(NSString *)imageName x:(int)x y:(int)y
{
	UIImageView *imageView=[self imageViewWithImageName:imageName x:x y:y];
	UIDevice *dev = [UIDevice currentDevice];
	
	NSString *deviceSystemVersion = dev.systemVersion;
	NSString *deviceType= dev.model;
	//NSLog(@"device type: %@ device system version: %@",deviceType, deviceSystemVersion);
	//if([deviceSystemVersion floatValue]<4.0 || [deviceType isEqualToString:@"iPhone Simulator"] )
	{
		CGRect rect=imageView.frame;
		imageView.frame=CGRectMake(rect.origin.x, rect.origin.y, rect.size.width/2, rect.size.height/2);
	}
	return imageView;
}
+ (UIImageView*) imageViewWithImageName:(NSString*)imageName
{
	return [self imageViewWithImageName:imageName x:0 y:0 memlog:NO];
}

+ (UIImageView*) imageViewWithImageName:(NSString*)imageName memlog:(BOOL)memlog
{
	return [self imageViewWithImageName:imageName x:0 y:0 memlog:memlog];
}

+ (UIImageView*) imageViewWithImageName:(NSString*)imageName x:(float)x y:(float)y
{
	
	return [self imageViewWithImageName:imageName x:x y:y memlog:NO];
}

+ (UIImageView*) imageViewWithImageName:(NSString*)imageName x:(float)x y:(float)y memlog:(BOOL)memlog 
{
	
	//UIImage* image = [UIImage imageNamed:imageName];
	/*
	if(image.size.width == 0 && image.size.height == 0)
	{
		////////NSLog(@"Warning: Image with name %@ may not exist", imageName);
	}
	*/
	TraceImageView* imageView = [[[TraceImageView alloc] initWithImageNamed:imageName memlog:memlog] autorelease];
	
	[self view:imageView setX:x setY:y];
	
	return imageView;
}

+ (UIImageView*) imageViewFromView:(UIView*)view
{
	UIGraphicsBeginImageContext(view.bounds.size);
	[view.layer renderInContext:UIGraphicsGetCurrentContext()];
	UIImage* imageView = UIGraphicsGetImageFromCurrentImageContext();  // is autoreleased
	UIGraphicsEndImageContext();
	
	return [[[UIImageView alloc] initWithImage:imageView] autorelease];
}

//Views
+ (void) view:(UIView*)view resizeWidthToFitText:(NSString*)text withFont:(UIFont*)font;
{
    CGSize constraintSize = CGSizeMake(MAXFLOAT, view.frame.size.height);
    CGSize labelSize = [text sizeWithFont:font constrainedToSize:constraintSize lineBreakMode:UILineBreakModeClip];
    [Utils view:view setWidth:(labelSize.width)];
}

+ (void) drawBorderAroundView:(UIView*)view
{
    view.layer.borderColor = [[UIColor redColor] CGColor];
    view.layer.borderWidth = 3;
}

+ (UIView*) centerView:(UIView*)smallView inView:(UIView*)largerView
{
	float newX = (largerView.frame.size.width - smallView.frame.size.width)/2;
	float newY = (largerView.frame.size.height - smallView.frame.size.height)/2;
	if(smallView.superview != largerView)
	{
		newX += largerView.frame.origin.x;
		newY += largerView.frame.origin.y;
	}
	[self view:smallView setX:newX setY:newY];	
	return smallView;
}

+ (void) view:(UIView*)view setX:(float)x
{
	view.frame = [self rectWithRect:view.frame x:x];
}

+ (void) view:(UIView*)view setY:(float)y
{
	view.frame = [self rectWithRect:view.frame y:y];
}

+ (void) view:(UIView*)view setX:(float)x setY:(float)y
{
	view.frame = CGRectMake(x, y, view.frame.size.width, view.frame.size.height);
}

+ (void) view:(UIView*)view setWidth:(float)width
{
	view.frame = [self rectWithRect:view.frame width:width];
}
+ (void) view:(UIView*)view setHeight:(float)height
{
	view.frame = [self rectWithRect:view.frame height:height];
}

+ (CGRect) rectWithRect:(CGRect)rect x:(float)x
{
	return CGRectMake(x, rect.origin.y, rect.size.width, rect.size.height);

}

+ (CGRect) rectWithRect:(CGRect)rect y:(float)y
{
	return CGRectMake(rect.origin.x, y, rect.size.width, rect.size.height);
}

+ (CGRect) rectWithRect:(CGRect)rect width:(float)width
{
	return CGRectMake(rect.origin.x, rect.origin.y, width, rect.size.height);
}

+ (CGRect) rectWithRect:(CGRect)rect height:(float)height
{
	return CGRectMake(rect.origin.x, rect.origin.y, rect.size.width, height);
}

+ (void) logRect:(CGRect)rect message:(NSString*)message
{
	////////NSLog(@"%@ (%f,%f,%f,%f)",message, rect.origin.x, rect.origin.y, rect.size.width, rect.size.height);
}

+ (void) recordToAnimate 
{
	[self recordToAnimateWithDuration:0.3f target:nil onComplete:nil];
}
+ (void) recordToAnimateWithDuration:(float)duration 
{
	[self recordToAnimateWithDuration:duration target:nil onComplete:nil];
}
+ (void) recordToAnimateWithDuration:(float)duration 
							  target:(id)actionTarget
						  onComplete:(SEL)onComplete
{
	[self recordToAnimateWithDuration:duration
							   easing:UIViewAnimationCurveEaseInOut
							   target:actionTarget
						   onComplete:onComplete];
}
SEL animateCompleteHandler;
id animateTarget;
+ (void) recordToAnimateWithDuration:(float)duration 
							  easing:(UIViewAnimationCurve)easing
							  target:(id)actionTarget
						  onComplete:(SEL)onComplete

{
	
	[UIView beginAnimations: nil context: @"some-identifier-used-by-a-delegate-if-set" ]; // Tell UIView we're ready to start animations.
	[UIView setAnimationCurve: easing ];
	[UIView setAnimationDuration: duration ];
	[UIView setAnimationDelegate:self];                       
	[UIView setAnimationDidStopSelector:@selector(animateComplete:finished:context:)];
	
	animateTarget = actionTarget;
	animateCompleteHandler = onComplete;
}

+ (void) animate
{
	[ UIView commitAnimations ]; // Animate!
}

+ (void) animateComplete:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context
{
	if(animateTarget)
	{
		[animateTarget performSelector:animateCompleteHandler];
	}
}

/*
 - (CGSize)sizeWithFont:(UIFont *)font forWidth:(CGFloat)width lineBreakMode:(UILineBreakMode)lineBreakMode
 
 
- (void)setUILabel:(UILabel *)myLabel withMaxFrame:(CGRect)maxFrame withText:(NSString *)theText usingVerticalAlign:(int)vertAlign {
	CGSize stringSize = [theText sizeWithFont:myLabel.font constrainedToSize:maxFrame.size lineBreakMode:myLabel.lineBreakMode];
	
	switch (vertAlign) {
		case 0: // vertical align = top
			myLabel.frame = CGRectMake(myLabel.frame.origin.x, 
									   myLabel.frame.origin.y, 
									   myLabel.frame.size.width, 
									   stringSize.height
									   );
			break;
			
		case 1: // vertical align = middle
			// don't do anything, lines will be placed in vertical middle by default
			break;
			
		case 2: // vertical align = bottom
			myLabel.frame = CGRectMake(myLabel.frame.origin.x, 
									   (myLabel.frame.origin.y + myLabel.frame.size.height) - stringSize.height, 
									   myLabel.frame.size.width, 
									   stringSize.height
									   );
			break;
	}
	
	myLabel.text = theText;
}
*/

+ (NSString*) phoneNumberDigitStringFromString:(NSString*)str
{
	char szTmp[128];
	int i;
	if ([str length] >= sizeof(szTmp)) return nil;
	
	const char *s = [str cString];
	if (!s) return nil;
	
	for (i=0; *s && (i<127); s++) 
	{
		if (isdigit(*s)) 
		{
			szTmp[i] = *s;
			i++;
		}
	}
	
	szTmp[i]='\0';
	
	NSString *sr = [NSString stringWithCString:szTmp];
	
	return sr;
}


+ (NSString*) digitStringFromString:(NSString*)str
{
	char szTmp[1024];
	int i;
	if ([str length] >= sizeof(szTmp)) return nil;
	
	const char *s = [str cString];
	if (!s) return nil;
	
	for (i=0; *s && (i<1023); s++) 
	{
		if (isdigit(*s)) 
		{
			szTmp[i] = *s;
			i++;
		}
	}
	
	szTmp[i]='\0';
	
	NSString *sr = [NSString stringWithCString:szTmp];
	
	return sr;	
}



+ (UIButton*) buttonWithNormalImageNamed:(NSString*)normalImageName
						pressedImageName:(NSString*)pressedImageName
							actionTarget:(id)actionTarget
								selector:(SEL)selector
									   x:(float)x
									   y:(float)y
{
	UIImage* normalImage = [Utils imageViewWithImageName:normalImageName].image;
	UIImage* pressedImage = [Utils imageViewWithImageName:pressedImageName].image;
	CGSize buttonSize = normalImage.size;
	CGRect buttonFrame = CGRectMake(x, y, buttonSize.width, buttonSize.height);

	return [self buttonWithTitle:@"" target:actionTarget selector:selector frame:buttonFrame 
						   image:normalImage imagePressed:pressedImage darkTextColor:YES];
	
	
}


+(UIButton *) buttonWithTitle:(NSString *)title
					   target:(id)target
					 selector:(SEL)selector
						frame:(CGRect)frame
						image:(UIImage *)image
				 imagePressed:(UIImage *)imagePressed
				darkTextColor:(BOOL)darkTextColor
{	
	UIButton* button = [[[UIButton alloc] initWithFrame:frame] autorelease];
	// or you can do this:
	//		UIButton *button = [[UIButton buttonWithType:UIButtonTypeCustom] retain];
	//		button.frame = frame;
	
	button.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
	button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
	
	[button setTitle:title forState:UIControlStateNormal];	
	if (darkTextColor)
	{
		[button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
	}
	else
	{
		[button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	}
	
	UIImage *newImage = [image stretchableImageWithLeftCapWidth:12.0 topCapHeight:0.0];
	[button setBackgroundImage:newImage forState:UIControlStateNormal];
	
	UIImage *newPressedImage = [imagePressed stretchableImageWithLeftCapWidth:12.0 topCapHeight:0.0];
	[button setBackgroundImage:newPressedImage forState:UIControlStateHighlighted];
	
	[button addTarget:target action:selector forControlEvents:UIControlEventTouchUpInside];
	
    // in case the parent view draws with a custom color or gradient, use a transparent color
	button.backgroundColor = [UIColor clearColor];
	button.titleLabel.font=[UIFont systemFontOfSize:16.0];
	return button;
}

+ (UIButton *) buttonWithFrame:(CGRect)frame 
						 label:(NSString*)label
				  actionTarget:(id)target
						onTap:(SEL)onTap_cb
{
	return [self buttonWithTitle:label 
						  target:target 
						selector:onTap_cb 
						   frame:frame 
						   image:[self imageViewWithImageName:@"whiteButton.png"].image
					imagePressed:[self imageViewWithImageName:@"blueButton.png"].image
				   darkTextColor:NO];
}

+ (void) deleteAllCookiesAtURL:(NSString*) urlString
{
	NSHTTPCookieStorage* cookieStorage = [NSHTTPCookieStorage sharedHTTPCookieStorage];
	NSArray* theCookies = [cookieStorage cookiesForURL:[NSURL URLWithString:urlString]];
	
	for(int i = 0; i < [theCookies count]; i++)
	{
		[cookieStorage deleteCookie:(NSHTTPCookie*)[theCookies objectAtIndex:i]];
	}
}


//Strings
+ (NSString*) unescapeString:(NSString*)str
{
	NSString* str_withoutPercentEscapes = [str stringByReplacingPercentEscapesUsingEncoding:NSASCIIStringEncoding];
	HTMLEntitiesConverter* htmlEntitiesConverter = [[[HTMLEntitiesConverter alloc] init] autorelease];
	NSString* unescapedString = [htmlEntitiesConverter convertEntiesInString:str_withoutPercentEscapes];
	return unescapedString;
}

+ (BOOL) string:(NSString*)str containsSubstring:(NSString*)substr
{
	return ([str rangeOfString:substr].location != NSNotFound);
}

+ (NSString*) string:(NSString*)str replaceSubstring:(NSString*)substr withString:(NSString*)repstr
{
	return [self joinArray:[self splitString:str onString:substr] byString:repstr];
}
+ (NSString*) string:(NSString*)str 
   replaceSubstring:(NSString*)substr 
		  withString:(NSString*)repstr 
	adjacentAsSingle:(BOOL)adjacentAsSingle //21,520,090,000
{
	return [self joinArray:[self splitString:str onString:substr handleAdjacentDelimiterAsSingleDelimiter:adjacentAsSingle] byString:repstr]; 
}
+ (NSString*) commaFormatedStringFromString:(NSString*)str
{
	NSArray* str_prsary = [Utils splitString:str onString:@"."];
	NSString* numberPart = [str_prsary objectAtIndex:0];
	NSString* decimalPart = @"";
	if([str_prsary count] > 1)
	{
		decimalPart = [NSString stringWithFormat:@".%@", [str_prsary objectAtIndex:1]];
	}
	//////NSLog(@"Full String [%@], Number Part [%@], Decimal Part [%@]", str,numberPart,decimalPart);
	
	NSMutableString* mstr = [[[NSMutableString alloc] initWithCapacity:0] autorelease];
	[mstr setString:numberPart];
	

	int length = [mstr length];
	
	int counter = 0;
	int nextInsertCount = 3;
	for(int i = length -1; i > 0; i--)
	{
		counter++;
		
		if (counter == nextInsertCount) 
		{
			counter = 0;
			[mstr insertString:@"," atIndex:i];
			
		}
	}

	
	return [NSString stringWithFormat:@"%@%@", mstr,decimalPart];
}
+ (NSString*) nameStringFromString:(NSString*)str
{
	NSMutableArray* names = [NSMutableArray arrayWithArray:[self splitString:str onString:@" "]];
	int numNames = [names count];	
	for(int i = 0; i < numNames; i++)
	{
		NSString* name = [names objectAtIndex:i];
		NSString* newName = [NSString stringWithFormat:@"%@%@", 
							 [[name substringToIndex:1] uppercaseString], 
							 [name substringFromIndex:1]];
		[names replaceObjectAtIndex:i withObject:newName];
	}
	return [self joinArray:names byString:@" "];
}
+ (NSString*) trimString:(NSString*)str
{
	return [str stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
}

+ (NSArray*) splitString:(NSString*)str onString:(NSString*)splitStr 
{
	return [self splitString:str 
					onString:splitStr  handleAdjacentDelimiterAsSingleDelimiter:YES];
}

+ (NSArray*) splitString:(NSString*)str 
				onString:(NSString*)splitStr 
handleAdjacentDelimiterAsSingleDelimiter:(BOOL)adjacentAsSingle 
{
	NSArray* tempArray = [str componentsSeparatedByString:splitStr];

	if(adjacentAsSingle)
	{
		int numTempElements = [tempArray count];
		NSMutableArray* array = [NSMutableArray arrayWithCapacity:numTempElements];
		for (int i = 0; i < numTempElements; i++) 
		{

			NSString* tempObject = (NSString*)[tempArray objectAtIndex:i];
			if([tempObject length]) [array addObject:tempObject];
			
		}
		return array;
	}
	else 
	{
		return tempArray;
	}
}

+ (NSString*) joinArray:array byString:(NSString*)byStr 
{
	return [array componentsJoinedByString:byStr];
}

+ (NSString*) truncateAndAddEllipsisWithString:(NSString*)str maxLengthIncludingEllipsis:(int)maxLength
{
	if([str length] <= maxLength)
	{
		return str;
	}
	return [[str  substringToIndex:(maxLength - 3)] stringByAppendingString:@"..."];
}


// if 'no such cookie' does nothing
+ (void) deleteCookieAtDomain:(NSString*)domain withName:(NSString*)name
{
	NSHTTPCookieStorage* cookieStorage = [NSHTTPCookieStorage sharedHTTPCookieStorage];
	NSArray* theCookies = [cookieStorage cookiesForURL:[NSURL URLWithString:domain]];
	
	for(int i = 0; i < [theCookies count]; i++)
	{
		NSHTTPCookie* cookie = (NSHTTPCookie*)[theCookies objectAtIndex:i];
		
		if([[cookie name] isEqualToString:name])
		{
			[cookieStorage deleteCookie:cookie];
			////////NSLog(@"Deleted cookie with name: %@", name);
		}
	}
}
+ (NSString*) retrieveCookieValueAtDomain:(NSString*)domain withName:(NSString*)name
{
	NSHTTPCookieStorage* cookieStorage = [NSHTTPCookieStorage sharedHTTPCookieStorage];
	NSArray* theCookies = [cookieStorage cookiesForURL:[NSURL URLWithString:domain]];
	
	for(int i = 0; i < [theCookies count]; i++)
	{
		NSHTTPCookie* cookie = (NSHTTPCookie*)[theCookies objectAtIndex:i];
		//////NSLog(@"retrieved cookie %@", cookie);
		if([[cookie name] isEqualToString:name])
		{
			return cookie.value;
		}		
	}
	return @"";
}

//This cookie will not expire
// domain: www.example.com (no http://)
+ (void) setCookieAtDomain:(NSString*)domain name:(NSString*)name value:(NSString*)value
{
	//A good looking cookie
	/*
	  <NSHTTPCookie version:0 
					   name:@"auth_token_joshksdjfn_cbs" value:@"95eb92cf1c2049dc0f23ac5a80e0395d" 
				expiresDate:@"2009-08-29 20:42:04 -0700" 
					created:@"241760524.724525" 
				sessionOnly:FALSE domain:@".cbs.josh.dw2.treemo.com" 
						path:@"/" 
					  secure:FALSE 
					 comment:@"(null)" 
				  commentURL:@"(null)" 
					portList:(null)>
	 */
	
	/*
	 <NSHTTPCookie version:0 
					  name:@"auth_token_joshksdjfn_cbs" value:@"524f929361a1090aca17364a4d99dc98" 
			   expiresDate:@"2009-08-29 23:17:46 -0700" 
				   created:@"241769866.310222" 
					sessionOnly:FALSE domain:@".cbs.josh.dw2.treemo.com" path:@"/" secure:FALSE comment:@"(null)" commentURL:@"(null)" portList:(null)>
	 */
	
/*<NSHTTPCookie version:0 
				name:@"auth_token_joshksdjfn_cbs" value:@"aa9878d1d25448cb1eeced8ff84a1413" 
				expiresDate:@"2009-08-30 05:51:09 -0700" 
				created:@"241772543.817089" 
				sessionOnly:FALSE 
				domain:@"cbs.josh.dw2.treemo.com" 
				path:@"/" secure:FALSE 
			comment:@"(null)" commentURL:@"(null)" portList:(null)>
 
 */
	
	NSMutableDictionary * cookieProperties = [NSMutableDictionary dictionaryWithCapacity:7];
	
	
	NSHTTPCookieStorage* cookieStorage = [NSHTTPCookieStorage sharedHTTPCookieStorage];
	NSArray* theCookies = [cookieStorage cookiesForURL:[NSURL URLWithString:domain]];
	////////NSLog(@"The cookies before delete %@", theCookies);
	
	//if a cookie with the current name already exits delete it
	[self deleteCookieAtDomain:domain withName:name];
	
	NSHTTPCookieStorage* cookieStorageAfter = [NSHTTPCookieStorage sharedHTTPCookieStorage];
	NSArray* theCookiesAfter = [cookieStorageAfter cookiesForURL:[NSURL URLWithString:domain]];
	////////NSLog(@"The cookies before delete %@", theCookiesAfter);
	
	// Name Value Domain
	[cookieProperties setObject:name forKey:NSHTTPCookieName];
	[cookieProperties setObject:value forKey:NSHTTPCookieValue];
	[cookieProperties setObject:domain forKey:NSHTTPCookieDomain];
	int yearInSeconds = 31556926;
	[cookieProperties setObject:[NSDate dateWithTimeIntervalSinceNow:yearInSeconds] forKey:NSHTTPCookieExpires];
	
	//An overload could be created to accept a path param
	// (we do not yet need this)
	NSString* defaultPath = @"/"; 
	[cookieProperties setObject:defaultPath forKey:@"Path"];		// This does work.
	
	
	// Check the NSDictionary for sanity.
	//////////NSLog([@"cookieProperties>" stringByAppendingString:[cookieProperties description]]);
	
	// Build a cookie.
	
	NSHTTPCookie* cookie = [NSHTTPCookie cookieWithProperties:cookieProperties];
	if (cookie) 
	{
		NSHTTPCookieStorage* cookieStorage = [NSHTTPCookieStorage sharedHTTPCookieStorage];
		[cookieStorage setCookie:cookie];
		//////NSLog(@"created cookie: %@", cookie);
	}
	else
	{
		//////NSLog(@"Cookie %@ was invalid and could not be created", name);
	}
	 
}

+ (void) showAlertViewWithOKButtonAndLabel:(NSString*)label
{

	////NSLog(@"Trying to display alret view");

	UIAlertView* alertView = [[[UIAlertView alloc] initWithTitle:label
												   message:nil 
												  delegate:nil 
										 cancelButtonTitle:@"OK"
										 otherButtonTitles:nil] autorelease]; 
	[alertView show];
}

UIAlertView* loadingAlertView;
+ (void)showLoadingAlertViewWithLabel:(NSString*)label
{
	if(loadingAlertView) return;
	loadingAlertView = [[[UIAlertView alloc] initWithTitle:label
														message:nil 
													   delegate:self 
											  cancelButtonTitle:nil
											  otherButtonTitles:nil] autorelease]; 
	
	[loadingAlertView addSubview:[Utils activityInidicatorCenteredInSize:CGSizeMake(280,120)]];
	[loadingAlertView show];
}

+ (void)hideLoadingAlertView
{
	[loadingAlertView dismissWithClickedButtonIndex:0 animated:YES];
	loadingAlertView = nil;
}

int networkUsageCount;
+ (void) addNetworkUsage
{
	//////////NSLog(@"adding network usage");
	networkUsageCount++;
	[UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
}

+ (void) removeNetworkUsage
{
	//////////NSLog(@"decrimenting network usage");
	networkUsageCount--;
	if(networkUsageCount < 1)
	{
		//////////NSLog(@"removing network usage");
		[UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
	}
	
	if(networkUsageCount < 0)
	{
		////////NSLog(@"Error: removeNetworkUsage invoked with network usage count already at 0");
	}
}


+ (NSIndexPath*)indexPathWithIndex:(int)indexOne withIndex:(int)indexTwo
{
	NSUInteger indexArr[] = {indexOne, indexTwo};
	return [NSIndexPath indexPathWithIndexes:indexArr length:2];
}

+ (UIColor*)colorFromHex:(int) hexColor
{
	//0xFFFFFF
	uint greenMask = 0x00FF00;
	uint blueMask = 0x0000FF;
	
	int red = hexColor >> 16;
	int green = (hexColor & greenMask) >> 8; 
	int blue = (hexColor & blueMask);
	
	float redPercent = ((float)red)/0xFF;
	float greenPercent = ((float)green)/0xFF;
	float bluePercent = ((float)blue)/0xFF;
	
	//////////NSLog(@"Red: %x, Green: %x, Blue: %x", red, green, blue);
	//////////NSLog(@"RedPercent: %f, GreenPercent: %f, BluePercent: %f", redPercent, greenPercent, bluePercent);
	return [UIColor colorWithRed:redPercent green:greenPercent blue:bluePercent alpha:1.0];
	
	
}

+ (UIColor*) colorFromImageName:(NSString*)imageName
{
	UIImageView* tempImageView = [Utils imageViewWithImageName:imageName];
	return [UIColor colorWithPatternImage:tempImageView.image];	
}


+ (BOOL)viewControllerWillBeReleasedDuringMemoryWarning:(UIViewController*)vc
{
	return !(vc.modalViewController || (vc.navigationController.topViewController == vc));
}

//Dates

+ (double) timestampDouble
{ 
	NSDate * date = [NSDate date];
	double timestamp = [date timeIntervalSinceDate:[NSDate dateWithNaturalLanguageString:@"01/01/1970"]];
	return timestamp;
}

+ (NSNumber*) timestampNSNumber
{
	return [NSNumber numberWithDouble:[self timestampDouble]];
}

+ (NSString*) timestampNSString
{
	return [NSString stringWithFormat:@"%@", [Utils timestampNSNumber]];
}

#define YEAR_SEC 31556926.00
#define MONTH_SEC 2629743.00
#define WEEK_SEC 604800.00
#define DAY_SEC 86400.00
#define HOUR_SEC 3600.00
#define MINUTE_SEC 60.00

+ (NSString*) readableTimeIntervalFromNSTimeInterval:(NSTimeInterval)_timeInterval
{
	int timeInterval = (int)_timeInterval ;
	int years=0;
	int months=0;
	int weeks=0;
	int days=0;
	int hours=0;
	int minutes=0;

	NSMutableString* intervalString = [[NSMutableString alloc]initWithString:@""];
	if ((years = timeInterval / YEAR_SEC) >= 1)
	{
		timeInterval = timeInterval - YEAR_SEC * years;
		[intervalString appendString:[NSString stringWithFormat:(years==1?@"%d Year":@"%d Years"),years]];
	}
	/*if((months = timeInterval / MONTH_SEC) >=1 )
	{
		timeInterval = timeInterval - MONTH_SEC * months;
		[intervalString appendString:[NSString stringWithFormat:(years==1?@"%d Month, ":@"%d Months, "),months]];
	}
	if((weeks = timeInterval / WEEK_SEC) >= 1)
	{
		timeInterval = timeInterval - WEEK_SEC * weeks;
		[intervalString appendString:[NSString stringWithFormat:(years==1?@"%d Week, ":@"%d Weeks, "),weeks]];
	}*/
	if((days = timeInterval / DAY_SEC) >=1)
	{
		timeInterval = timeInterval - DAY_SEC *days;
		if(years)
		{
			[intervalString appendString:@", "];	
		}
		[intervalString appendString:[NSString stringWithFormat:(years==1?@"%d Day":@"%d Days"),days]];
	}
	if((hours = timeInterval / HOUR_SEC) >= 1)
	{
		timeInterval = timeInterval - HOUR_SEC*hours;
		if (days || years)
		{
			[intervalString appendString:@", "];	
		}
		[intervalString appendString:[NSString stringWithFormat:(years==1?@"%d Hour":@"%d Hours"),hours]];
	}
	if((minutes = timeInterval / MINUTE_SEC) >=1)
	{
		timeInterval = timeInterval - MINUTE_SEC*minutes;
		if(days || minutes || years)
		{
			[intervalString appendString:@", "];	
		}
		[intervalString appendString:[NSString stringWithFormat:(years==1?@"%d Minute":@"%d Minutes"),minutes]];
	}
	
	//[intervalString appendString:[NSString stringWithFormat:(years==1?@"%d Second":@"%d Seconds"),timeInterval]];
	
	////NSLog(@"Got Time Interval String: %@",intervalString);
	return intervalString;
}


//Internet 

 + (BOOL)isInternetReachable {
	
	Reachability *reach = [Reachability reachabilityForInternetConnection];
	if ([reach currentReachabilityStatus] == NotReachable) {
        return NO;
    } 
	return YES;
}

+(BOOL) validateEmail: (NSString *) email 
{
   // NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSString *emailRegex =
    @"(?:[a-z0-9!#$%\\&'*+/=?\\^_`{|}~-]+(?:\\.[a-z0-9!#$%\\&'*+/=?\\^_`{|}"
    @"~-]+)*|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\"
    @"x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[a-z0-9](?:[a-"
    @"z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\\[(?:(?:25[0-5"
    @"]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-"
    @"9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21"
    @"-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    BOOL isValid = [emailTest evaluateWithObject:email];
    return isValid;
}

+ (BOOL) validateUserName:(NSString *)userName{
    NSString *userNameRegex = @"^[a-z]{1}:[a-z0-9_-]{3,15}$";
    //NSPredicate *userNameTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", userNameRegex];
    //return  [userNameTest evaluateWithObject:userName];
    NSError *err = nil;
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:userNameRegex options:NSRegularExpressionCaseInsensitive error:&err];
    if (err) {
        NSLog(@"ERROR %@",err.localizedDescription);
        
    }
    int noOfMatches = [regex numberOfMatchesInString:userName options:0 range:NSMakeRange(0, [userName length])] ;
    return noOfMatches > 0;
}
//enter 1 for single part
+ (BOOL) validateName:(NSString *)name multipartCount:(int)multipart{
    NSString *nameRegex = @"[A-Za-z0-9]{3,15}";
    for (int i = 1; i < multipart; i++) {
        nameRegex = [nameRegex stringByAppendingFormat:@"+\" \"[A-Za-z0-9]{3,15}"];
    }
    NSPredicate *nameTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", nameRegex];
    return  [nameTest evaluateWithObject:name];
}

+ (BOOL) validateMobileNo:(NSString *)mobile{
    NSString *mobileRegex = @"^(?:|0|[1-9]\\d*)(?:\\.\\d*)?$";
    //@"9[0-9]{9}";
    NSPredicate *mobileTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", mobileRegex];
    return  [mobileTest evaluateWithObject:mobile];
}

@end