//
//  ContentList.m
//  MichaelJackson
//
//  Create by Andrew Paul Simmons on 7/17/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import "ContentList.h"


@implementation ContentList

@synthesize totalNumberOfItems, totalNumberOfPages, pageSize, pageNumber, contentList;


- (id) init
{
	if(self = [super init])
	{
		contentList = [[NSMutableArray arrayWithCapacity:0] retain];
	}
	return self;
}


- (id) objectAtIndex:(NSUInteger)index
{
	return [contentList objectAtIndex:index];
}

- (void) removeObjectAtIndext:(NSUInteger)index
{
	[contentList removeObjectAtIndex:index];
}

- (void)addObject:(NSObject*) anObject
{
	[contentList addObject:anObject];
}

- (NSUInteger) count
{
	return [contentList count];
}


- (void) dealloc 
{
	[contentList release];
	[super dealloc];
}

@end
