//
//  ContentList.h
//  MichaelJackson
//
//  Create by Andrew Paul Simmons on 7/17/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ContentList : NSMutableArray 
{
	int totalNumberOfItems;
	int totalNumberOfPages;
	int pageSize;
	int pageNumber;
	NSMutableArray* contentList;
}

@property(assign) int totalNumberOfItems;
@property(assign) int totalNumberOfPages;
@property(assign) int pageSize;
@property(assign) int pageNumber;

@property(readonly) NSMutableArray* contentList;

@end
