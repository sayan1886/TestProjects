//
//  FooterView.h
//  eMagazine
//
//  Created by SOHAMPAUL on 03/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface FooterView : UIView {
	id delegate;
	UISlider *slider;
	
}
@property (nonatomic, retain) UISlider *slider;
@property (nonatomic,assign) id delegate;

- (id)initWithFrame:(CGRect)frame andDelegate:(id)del;
@end
