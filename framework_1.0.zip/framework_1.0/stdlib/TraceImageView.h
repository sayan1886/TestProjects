//
//  TraceImage.h
//  HarpersIsland
//
//  Create by Andrew Paul Simmons on 4/6/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface TraceImageView : UIImageView 
{
	
	NSString* myImageName;
	
	BOOL logAllocationsAndDeallocations;

}


//::Public
- (id) initWithImageNamed:(NSString*) imageName  memlog:(BOOL)memlog;

//::Private

@end
