//
//  ChooseImageFromGallery.h
//  TestCartoon
//
//  Created by Sayan on 27/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChooseImageFromGallery : UIViewController<UIImagePickerControllerDelegate,UINavigationControllerDelegate>{
    UIImage *_pickedImage;
    id target;
    SEL action;
}

@property (nonatomic,retain) UIImage *pickedImage;

- (id)initWithTarget:(id)target_ action:(SEL)action_;
- (void) presentImagePicker;

@end
