//
//  ColoredTableViewCell.m
//  Andrew_CBSNews
//
//  Create by Andrew Paul Simmons on 2/26/10.
//  Copyright 2010 Treemo Labs All rights reserved.
//

#import "ColoredTableViewCell.h"


@implementation ColoredTableViewCell
@synthesize retainedBackgroundColor;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier 
{
    if ((self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])) 
	{
        // Initialization code
		self.backgroundColor = [UIColor whiteColor];
    }
    return self;
}



- (void)setSelected:(BOOL)selected animated:(BOOL)animated 
{
    [super setSelected:selected animated:animated];
	self.backgroundColor = [UIColor whiteColor];
    // Configure the view for the selected state
}

- (void) layoutSubviews
{
	[super layoutSubviews];
	self.backgroundColor = [UIColor whiteColor];
	//self.backgroundColor = retainedBackgroundColor;
}


- (void)dealloc 
{
	[retainedBackgroundColor release];
    [super dealloc];
}


@end
