//
//  TextOnlyListItem.m
//  Andrew_CBSNews
//
//  Create by Andrew Paul Simmons on 1/7/10.
//  Copyright 2010 Treemo Labs. All rights reserved.
//

#import "TextOnlyListCellDark.h"
#import "Utils.h"
#import "fontnames.h"


@implementation TextOnlyListCellDark



- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier 
{
    if( self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]  ) 
	{
		titleText_lb = [[[UILabel alloc] initWithFrame:CGRectMake(10, 0, 280, 50)] autorelease];
		titleText_lb.numberOfLines = 0;
		titleText_lb.font = [UIFont fontWithName:FONTNAME_helvetica size:15];
		titleText_lb.backgroundColor = [UIColor clearColor];
		titleText_lb.textColor = [Utils colorFromHex:0xA6C8EB];
		
		UIImageView* disclouserInidcator = [Utils imageViewWithImageName:@"listArrow.png"];
		[Utils view:disclouserInidcator setX:298.5 setY:23];
		[self addSubview:disclouserInidcator];
		
		//Thumbnail
		
		
		[self addSubview:titleText_lb];
        // Initialization code
		//NSLog(@"Table Cell Created");
		//UITextViewAttributes
		//self.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
		self.selectionStyle = UITableViewCellSelectionStyleNone;
		[self addSubview:[Utils imageViewWithImageName:@"separatorLineDark.png"]];
		
    }
	
    return self;
}

+ (NSString*) cellType
{
	return @"TextOnlyListCellDark";
}

+ (int) cellHeight
{
	return 50;
}

- (void)layoutSubviews
{
	[super	 layoutSubviews];
		self.backgroundColor = [Utils colorFromHex:0x2D3035];
}

- (void) setTitleText:(NSString*)value
{
	titleText_lb.text = value;
}

- (NSString*) titleText
{
	return titleText_lb.text;
}

- (void) setDictionary:(NSDictionary*)dict
{
	dictionary = [dict retain];
	self.titleText = [dict objectForKey:@"title"];
	if ([dict objectForKey:@"color"]) {
		titleText_lb.textColor = [Utils colorFromHex:0xA6C8EB];
		self.backgroundColor = [Utils colorFromHex:0x2D3035];
	}
}
- (NSDictionary*) dictionary
{
	return dictionary;

}
-(void)cellDidAppear
{
	//NSLog(@"Cell with text \"%@\" did appear!", self.titleText);
}

-(void)cellDidDissappear
{
	//NSLog(@"Cell with text \"%@\" did disappear!", self.titleText);
}



- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
	//[super setSelected:selected animated:animated];
	if(selected)
	{
		self.backgroundColor = [Utils colorFromHex:0xA6C8EB];
		titleText_lb.textColor = [Utils colorFromHex:0x2D3035];
	}
	else
	{
		titleText_lb.textColor = [Utils colorFromHex:0xA6C8EB];
		if(false && animated)
		{
			[Utils recordToAnimateWithDuration:0.7];
		}
		self.backgroundColor = [Utils colorFromHex:0x2D3035];
		if(false && animated)
		{
			[Utils animate];
		}
	}
}
- (void)setHighlighted:(BOOL)highlighted animated:(BOOL)animated
{
	[super setHighlighted:highlighted animated:animated];
	if(highlighted)
	{
		self.backgroundColor = [Utils colorFromHex:0xA6C8EB];
		titleText_lb.textColor = [Utils colorFromHex:0x2D3035];
	}
	else 
	{
		self.backgroundColor = [Utils colorFromHex:0x2D3035];
		titleText_lb.textColor = [Utils colorFromHex:0xA6C8EB];
	}
	
}



- (void)dealloc 
{
	[dictionary release];
    [super dealloc];
}


@end
