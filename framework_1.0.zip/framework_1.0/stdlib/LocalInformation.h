

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>
#import <MapKit/MKReverseGeocoder.h>
#import <MapKit/MKPlacemark.h>
#import <CoreLocation/CoreLocation.h>
#import "Utils.h"

@interface LocalInformation : NSObject <CLLocationManagerDelegate, MKReverseGeocoderDelegate>
{

	float lat;
	float lon;
	BOOL needCity;
	BOOL getReverseGeoCoder;
	BOOL needLatLon;
	id actionTarget;
	CLLocation* myLocation;
	MKPlacemark* placemark;
}

@property(readonly) float lat;
@property(assign) id actionTarget;
@property(readonly) CLLocation* myLocation;
@property(readonly) float lon;
@property(readonly) MKPlacemark* placemark;

//::Public

/* Load Local Coords */
+ (LocalInformation*) getLatLonWithDelegate:(id)actionTarget; 
+ (LocalInformation*) getCityNameWithDelegate:(id)actionTarget;


/*Private Constructors*/
- (id) createCity:(id)target;
- (id) createLatLon:(id)target;



+ (void) onLoadCoords:(CLLocation *)newLocation localInformation:(LocalInformation*)li;
+ (void) onLoadCoordsFailure:(NSString*)message localInformation:(LocalInformation*)li;

+ (void) onLoadCity:(NSString *)cityName placemark:(NSString*)placemark localInformation:(LocalInformation*)li;
+ (void) onLoadCityFailure:(NSString*)message localInformation:(LocalInformation*)li;

//delegate methods

- (void) localInformationGotLatitude:(NSNumber*)latitude longitude:(NSNumber*)longitude;
- (void) localInformationCoordsRequestFailed:(NSString*)message;

- (void) localInformationGotCityName:(NSString*)cityName andReference:(LocalInformation*)localInformation;
- (void) localInformationCityRequestFailed:(NSString*)message;
@end
