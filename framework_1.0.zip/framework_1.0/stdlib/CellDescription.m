//
//  CellData.m
//  Andrew_CBSNews
//
//  Create by Andrew Paul Simmons on 1/29/10.
//  Copyright 2010 Treemo Labs All rights reserved.
//

#import "CellDescription.h"
#import "SafeDictionary.h"

@implementation CellDescription

@synthesize type,data,height,contentID,contentType;


- (id)initWithType:(NSString*) cellType  
			  data:(SafeDictionary*) cellData 
			height:(int) cellHeight
		 contentID:(NSString*)cellContentID
	   contentType:(NSString*)cellContentType
{
	if(self = [super init])
	{
		
		if (data && ![data isKindOfClass:[SafeDictionary class]]) 
		{
			NSLog(@"CD Dict %@", data);
			NSException *exception = [NSException exceptionWithName:@"HotTeaException"
									  
															 reason:@"The tea is too hot"  userInfo:nil];
			
			@throw exception; 
		}

		
		data = [cellData retain];
		type = [cellType retain];
		height = cellHeight;
		contentID = [cellContentID retain];
		contentType= [cellContentType retain];
	}
	
	return self;
}

@end
