//
//  FooterView.m
//  eMagazine
//
//  Created by SOHAMPAUL on 03/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "FooterView.h"


@implementation FooterView
@synthesize slider;
@synthesize delegate;

- (id)initWithFrame:(CGRect)frame andDelegate:(id)del {
    if ((self = [super initWithFrame:frame])) {
        // Initialization code
		delegate = del;
		
		CGFloat selfHeight = frame.size.height;
		
		UIButton *butLeft = [UIButton buttonWithType:UIButtonTypeCustom];
		butLeft.frame = CGRectMake(5, (selfHeight-20)/2, 21, 20);
		[butLeft setBackgroundColor:[UIColor clearColor]];
		[butLeft setBackgroundImage:[UIImage imageNamed:@"arrow_left.png"] forState:UIControlStateNormal];
		[butLeft setBackgroundImage:[UIImage imageNamed:@"arrow_left.png"] forState:UIControlStateHighlighted];
		[butLeft addTarget:delegate action:@selector(footerLeftButAction:) forControlEvents:UIControlEventTouchUpInside];
		[self addSubview:butLeft];
		
		slider = [[UISlider alloc] initWithFrame:CGRectMake(26, (selfHeight-23)/2, frame.size.width-52, 0)];
		slider.autoresizingMask = UIViewAutoresizingFlexibleWidth;
		[slider setMinimumTrackImage:[UIImage imageNamed:@"scroll_bar_max.png"] forState:UIControlStateNormal];
		[slider setMaximumTrackImage:[UIImage imageNamed:@"scroll_bar_max.png"] forState:UIControlStateNormal];
		[slider setThumbImage: [UIImage imageNamed:@"scroll.png"] forState:UIControlStateNormal];
		[slider setThumbImage: [UIImage imageNamed:@"scroll.png"] forState:UIControlStateHighlighted];
		[slider addTarget:delegate action:@selector(sliderValueChange:) forControlEvents:UIControlEventValueChanged];
		[self addSubview:slider];
	
		
		UIButton *butRight = [UIButton buttonWithType:UIButtonTypeCustom];
		butRight.frame = CGRectMake(frame.size.width-26, (selfHeight-20)/2, 21, 20);
		butRight.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
		[butRight setBackgroundColor:[UIColor clearColor]];
		[butRight setBackgroundImage:[UIImage imageNamed:@"arrow_right.png"] forState:UIControlStateNormal];
		[butRight setBackgroundImage:[UIImage imageNamed:@"arrow_right.png"] forState:UIControlStateHighlighted];
		[butRight addTarget:delegate action:@selector(footerRightButAction:) forControlEvents:UIControlEventTouchUpInside];
		[self addSubview:butRight];
		
	}
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (void)dealloc {
	[slider release];
    [super dealloc];
}


@end
