//
//  ItemListProxy.h
//  EyeReport
//
//  Create by Andrew Paul Simmons Simmons on 11/5/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "APIBinding.h"
#import "Requester.h"

typedef enum 
{
	ItemListProxyFeedTypeTags, 
	ItemListProxyFeedTypeChannel
} ItemListProxyFeedType;


@protocol ItemListProxyDelegate <NSObject>
	@required
	- (void) didGetItemList:(NSArray*) itemList;
	
	@optional
	- (void) cannotGetItemList:(NSString*) failureMessage;
@end

@interface ItemListProxy : NSObject 
{
	ItemListProxyFeedType feedType;
	NSString* lastTagRequested;
	id <ItemListProxyDelegate> delegate;
	Requester* requester;
	BOOL loadInProgress;
}

//:: Public
@property(assign) id <ItemListProxyDelegate> delegate;

- (void) requestItemListForTag:(NSString*)tag;
- (void) requestItemListForTag:(NSString*)tag maxLength:(int)length;

- (void) requestItemListForChannel:(NSString*)channel;
- (void) requestItemListForChannel:(NSString*)channel maxLength:(int)length;


//::Private
- (void) onLoadItemsForChannel:(NSString*)channel contentItems:(NSArray*)contentItems;




@end
