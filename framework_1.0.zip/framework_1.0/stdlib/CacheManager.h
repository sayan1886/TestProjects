//
//  CBSNewsCache.h
//  Andrew_CBSNews
//
//  Create by Andrew Paul Simmons on 12/10/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>  

@interface CacheManager : NSObject 
{

}

// if one of these methods doesn't do it for ya, make a new one that does.
+ (id) newManagedObjectForEntityName:(NSString*)name; //create object 
+ (void) save; // save object
+ (id) readEntityWithName:(NSString*)entityName withCacheID:(NSString*)cacheID; //read object with id

// deletes entities with name entityName which are over 10 days old
+ (NSArray*) deleteOldEntitiesWith:(NSString*)entityName;

// these methods probably should not be used
+ (NSManagedObjectContext*) managedObjectContext;
+ (NSManagedObjectModel*) managedObjectModel;
+ (NSPersistentStoreCoordinator*) persistentStoreCoordinator;
+ (NSString*) applicationDocumentsDirectory;




@end
