//
//  NativeListViewController.m
//  Andrew_CBSNews
//
//  Create by Andrew Paul Simmons on 1/6/10.
//  Copyright 2010 Treemo Labs. All rights reserved.
//


#import "NativeListViewController.h"
#import "Utils.h"




@implementation NativeListViewController
@synthesize tableView;


/*
- (id)initWithStyle:(UITableViewStyle)style {
    // Override initWithStyle: if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
    if (self = [super initWithStyle:style]) {
    }
    return self;newsListItems
}newsnewsListItems
*/


- (void)viewDidLoad 
{
    [super viewDidLoad];
	
	[self setupTableView];

}



- (void) setupTableView
{
	self.tableView = [[[UITableView alloc] initWithFrame:CGRectMake(0, 39, 320, 329) 
												   style:UITableViewStylePlain] autorelease];
	
	[self.view addSubview:self.tableView];
	tableView.delegate = self;
	tableView.dataSource = self;
	UIImageView* bottomshadow = [Utils imageViewWithImageName:@"gradient-bottom.png"];
	UIImageView* topshadow = [Utils imageViewWithImageName:@"gradient-top.png"];
	tableView.tableFooterView = bottomshadow;
	tableView.tableHeaderView = topshadow;
	tableView.contentInset = UIEdgeInsetsMake(-22, 0, -22, 0);
	
	
	//[self retain];
}



- (CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	CellDescription* cd = [cellDescriptions objectAtIndex:indexPath.row];
	return cd.height;
	
}


////- (void) setupContent   // recommended for classes extending NativeListViewController
////{
////	---------------- Example Definition --------------------
////	ApplicationDataCenter* dataCenter = [[ApplicationDataCenter alloc] init];
////	dataCenter.delegate = self;
////	
////	if(cellDescriptions == nil)
////	{
////		NSDictionary* data = [dataCenter requestNewsListForCategory:@"topnews" pageNumber:0];
////		newsListItems = [[data objectForKey:@"list"] retain];
////		
////		[self buildCellDescriptions];
////	}
////	
////	if(newsListItems == nil)
////	{
////		//NSLog(@"Adding loading view");
////		[self addLoadingView];
////	}
//// }


////- (void) buildCellDescriptions   // recommended for classes extending NativeListViewController
////{
////	---------------- Example Definition --------------------
////	if(cellDescriptions == nil) return;
////	[cellDescriptions release];
////	cellDescriptions = [[NSMutableArray alloc] initWithCapacity:0];
////	for(int i = 0; i < [newsListItems count]; i++)
////	{
////		NSDictionary* story = [newsListItems objectAtIndex:i];
////		BOOL isThumbnailCell = ([[story objectForKey:@"thumbnail"] length] > 0);
////		
////		NSString* type;
////		int height;
////		if (isThumbnailCell)
////		{
////			type = [ListCell cellType];
////			height = [ListCell cellHeight];
////		}
////		else 
////		{
////			type = [TextOnlyListCell cellType];
////			height = [TextOnlyListCell cellHeight];			
////		}
////		
////		CellDescription* cd = [[[CellDescription alloc] 
////								initWithType:type data:story height:height] autorelease];
////		
////		[cellDescriptions addObject:cd];
////}


/*
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}
*/

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
	[tableView deselectRowAtIndexPath:[tableView indexPathForSelectedRow] animated:YES];
}

/*
- (void)viewWillDisappear:(BOOL)animated {
	[super viewWillDisappear:animated];
}
*/
/*
- (void)viewDidDisappear:(BOOL)animated {
	[super viewDidDisappear:animated];
}
*/

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    if (!self.view.superview && [Utils isPad]) {
        self.view = nil;
        [self viewDidUnload];
    }
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	[super viewDidUnload];
	self.tableView = nil;
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


#pragma mark Table view methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *) tableView 
{
    return 1;
}

// How do I add more types :o) ??? Oh that's easy, just follow these 3 steps:
// (1) to add more types simply override,  
// (2) if([super treemoCellForType] == nil), 
// (3) then return correct cell else return super's cell
- (TTCProtocol*) treemoCellForType:(NSString*)type
{
	if([type isEqualToString:[ListCell cellType]])
	{
		return (TTCProtocol*) [[[ListCell alloc] initWithStyle:UITableViewCellStyleDefault 
												 reuseIdentifier:[ListCell cellType]] autorelease];
	}
	else if([type isEqualToString:[TextOnlyListCell cellType]])
	{
		return  (TTCProtocol*) [[[TextOnlyListCell alloc] initWithStyle:UITableViewCellStyleDefault 
														 reuseIdentifier:[TextOnlyListCell cellType]] autorelease];
	}
	else 
	{
		return nil;
	}

}

// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
    return   [cellDescriptions count];
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)_tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath 
{
	
	TTCProtocol* cell;
	CellDescription* cd = [cellDescriptions objectAtIndex:indexPath.row];

	NSString* cellType = cd.type;
	cell = (TTCProtocol*)[tableView dequeueReusableCellWithIdentifier:cellType];
	if(cell == nil ) cell = [self treemoCellForType:cellType];
	[cell setDictionary:[cd data]];
	 
	return cell;	

	//return [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"Fox"];

}


/*
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    // Navigation logic may go here. Create and push another view controller.
	// AnotherViewController *anotherViewController = [[AnotherViewController alloc] initWithNibName:@"AnotherView" bundle:nil];
	// [self.navigationController pushViewController:anotherViewController];
	// [anotherViewController release];
}
*/

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/


/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:YES];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/


/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/


/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/


- (void)dealloc 
{
	[tableView release];
    [super dealloc];
}


@end

