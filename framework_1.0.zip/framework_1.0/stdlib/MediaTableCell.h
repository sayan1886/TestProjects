//
//  MediaTableCell.h
//  MediaExplorer
//
//  Create by Andrew Paul Simmons on 8/23/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "APSWebImageView.h"
#import "Utils.h"

@interface MediaTableCell : UITableViewCell 
{
	//UIImage* thumbnail_img;
	UIButton* detailDisclosure_btn;
	APSWebImageView* thumbnail_wiv;
	
	UIImageView* bg_iv;
	UILabel* title_lb;
	UILabel* authorLabel;
	UILabel* dateLabel;

	NSString* title;
	NSString* author;
	NSString* date;
	
	NSString* imageURL;

	
}

//::Public



@property(copy) NSString* title;
@property(copy) NSString* imageURL;
@property(copy) NSString* author;
@property(copy) NSString* date;
@property(readonly) UIImage* thumbnail;
//::Private
- (UILabel *)newLabelWithPrimaryColor:(UIColor *)primaryColor 
						selectedColor:(UIColor *)selectedColor 
							 fontSize:(CGFloat)fontSize 
								 bold:(BOOL)bold;
- (UIButton*) newDetailDisclosureButton;
-(UIImage*) newUIImageWithURL:(NSString*)urlString;


/*
 // assign 
 property = newValue; 
 // retain 
 if (property != newValue) 
 { 
 [property release]; 
 property = [newValue retain]; 
 } 
 // copy 
 if (property != newValue) 
 { 
 [property release]; 
 property = [newValue copy]; 
 } 
*/ 

@end
