//
//  BrowseViewController.m
//  EyeReport
//
//  Create by Andrew Paul Simmons on 10/11/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//


#import "WebViewController.h"

#ifndef STATION_QUERY_STRING
	#define STATION_QUERY_STRING @""
#endif 
#ifndef VERSION_TOKEN
	#define VERSION_TOKEN @""
#endif
#ifndef VERSION_TOKEN
#define VERSION_TOKEN @""
#endif

//UIWebViewDelegate
@implementation WebViewController
@synthesize initURLString, disableStationQueryStr; 

- (id)init
{
	if(self = [super init])
	{
		[self doInit];
	}
	return self;
}

- (id) initWithNibName:(NSString*)nibNameOrNil bundle:(NSBundle*)nibBundleOrNil
{
	if(self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])
	{
		[self doInit];
	}
	return self;
}


- (id) initWithCoder:(NSCoder*)aDecoder
{
	if(self = [super initWithCoder:aDecoder])
	{
		[self doInit];
	}	
	return self;
}


- (void) doInit
{
	restoreName = @"browseVC";
	webViewFrame = CGRectMake(0, 0, 320, 367);
	webViewDisplayIndex = -1;

}


// Implement loadView to create a view hierarchy programmatically.
- (void)loadView 
{
	myWebView = nil;
	connectingAnimation_ai = nil; 
	
	[super loadView]; 
	
	webViewFrameAfterDelay = webViewFrame;
	myWebView = [[[UIWebView alloc] initWithFrame:CGRectMake(400, 146, 320, 321)] autorelease];
	myWebView.delegate = self;
	
	[self.view addSubview:myWebView];
	if(initURLString) [self loadURLString:initURLString];
	
	
	connectingAnimation_ai = [[[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray] autorelease];
	connectingAnimation_ai.hidesWhenStopped = YES;
	if(!supressDefaultLoadingAnimation)[connectingAnimation_ai startAnimating];
	CGSize caSize = connectingAnimation_ai.frame.size;
	connectingAnimation_ai.frame = CGRectMake((320.0f - caSize.width)/2, 
											  (321.0f - caSize.height)/2, 
											  caSize.width, 
											  caSize.height);
	
	connectingAnimationInitY = connectingAnimation_ai.frame.origin.y;
	[self.view addSubview:connectingAnimation_ai];
	
	//UINavigationBar
	//[self.navigationController.navigationBar  pushNavigationItem:[[UINavigationItem alloc] initWithTitle:@"Test"] animated:YES];
}


//debuggin info
- (BOOL) webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request 
  navigationType:(UIWebViewNavigationType)navigationType
{
	//////NSLog(@"Load started");
	if(webViewDisplayIndex < 0)
	{
		[self.view addSubview:connectingAnimation_ai];
	}
	else
	{
		[self.view insertSubview:connectingAnimation_ai atIndex:webViewDisplayIndex + 1];
	}
	//////NSLog(@"Should start load %@", [[request URL] absoluteString]);
	
	BOOL startLoad = [super webView:webView 
		 shouldStartLoadWithRequest:request 
					 navigationType:navigationType];
	
	if(startLoad)
	{
		
	}
	else
	{
		////////NSLog(@"WebView !!started canceled");
	}
	
	return startLoad; 
	
}

- (WebAction) onShowItem:(NSString*)url
{
	[self showItemWithURL:url animated:YES];
}



- (WebAction) onRenderStart:(NSString*)voidParam
{
	[connectingAnimation_ai stopAnimating];
	////////NSLog(@"On Render Start invoked");
	myWebView.hidden = NO;
}

- (void)viewDidUnload
{
	[super viewDidUnload];
	myWebView = nil;	
}

- (void) retryLoadAfterFailure
{
	[super retryLoadAfterFailure];
	[myWebView reload];
}

- (void) showItemWithURL:(NSString*)url animated:(BOOL)animated
{
	/*
	 [self itemViewMakeFresh];
	 [self.navigationController pushViewController:item_vc animated:animated];
	 [item_vc loadURLString:[LINK_DOMAIN_URL_STRING stringByAppendingString:url]];
	 */
	
}

/*
 - (ItemViewController*) itemViewMakeFresh
 {
 
 [item_vc release];
 item_vc = [[ItemViewController alloc] init];
 item_vc.actionTarget = self;
 item_vc.onSelectJoin = @selector(onItemViewSelectJoin:);
 item_vc.onSelectReport = @selector(onChildViewSelectReport);
 return item_vc;
 }
 
 */



- (void)webViewDidStartLoad:(UIWebView *)webView
{
	if(!supressDefaultLoadingAnimation)[connectingAnimation_ai startAnimating];
}

- (void) loadURLString:(NSString*)urlString
{

	[urlToLoadAfterDelay release];
	////////NSLog(@"loading URL String: %@",urlString);
	
	urlToLoadAfterDelay = [urlString retain];
	if(myWebView)
	{
		myWebView.delegate = nil;
		[myWebView stopLoading];
		myWebView.hidden = YES;
		if(!supressDefaultLoadingAnimation)[connectingAnimation_ai startAnimating];
		NSDate* delayDate = [[[NSDate alloc] initWithTimeIntervalSinceNow:1] autorelease];
		[self performSelector:@selector(loadURLStringActual:) withObject:myWebView afterDelay:[delayDate timeIntervalSinceNow]];
		myWebView = nil;
	}
	
}

- (void) loadHTMLString:(NSString*)hTML
{
	if(myWebView)
	{
		myWebView.delegate = nil;
		[myWebView stopLoading];
		myWebView.hidden = YES;
		if(!supressDefaultLoadingAnimation)[connectingAnimation_ai startAnimating];
		//NSDate* delayDate = [[[NSDate alloc] initWithTimeIntervalSinceNow:1] autorelease];
		[self performSelector:@selector(loadHTMLStringActually:withHTMLString:) withObject:myWebView withObject:hTML];
	}
}

- (void) loadHTMLStringActually:(UIWebView*)webviewToRemoveFromSuperView withHTMLString:(NSString*)hTML
{
	myWebView.hidden = NO;
	[webviewToRemoveFromSuperView removeFromSuperview];
	
	myWebView = [[[UIWebView alloc] initWithFrame:webViewFrameAfterDelay] autorelease];
	if(webViewIsTransparent)myWebView.backgroundColor = [UIColor clearColor];
	myWebView.opaque = NO;
	myWebView.delegate = self;
	myWebView.hidden = YES;
	[myWebView loadHTMLString:[hTML retain] baseURL:[NSURL URLWithString:LINK_DOMAIN_URL_STRING]];
	if(webViewDisplayIndex < 0)
	{
		[self.view insertSubview:myWebView belowSubview:connectingAnimation_ai];
	}
	else
	{
		[self.view insertSubview:myWebView atIndex:webViewDisplayIndex];
	}
	myWebView.hidden = NO;
}


- (void) loadPathString:(NSString*)filePath withParams:(NSString*)htmlParameterString
{
	[pathString release];
	[paramString release];
	
	////////NSLog(@"loading URL String: %@",filePath);
	if (htmlParameterString) {
		paramString = [htmlParameterString retain];
	}
	pathString = [filePath retain];
	
	if(myWebView)
	{
		myWebView.delegate = nil;
		[myWebView stopLoading];
		myWebView.hidden = YES;
		if(!supressDefaultLoadingAnimation)[connectingAnimation_ai startAnimating];
		NSDate* delayDate = [[[NSDate alloc] initWithTimeIntervalSinceNow:1] autorelease];
		[self performSelector:@selector(laodPathStringActually:) withObject:myWebView afterDelay:[delayDate timeIntervalSinceNow]];
		myWebView = nil;
	}
}


- (void) laodPathStringActually:(UIWebView*)webviewToRemoveFromSuperView
{
	
	
	//////NSLog(@"htmlParameterString: %@",paramString);
	NSData* myData = [NSData dataWithContentsOfFile:pathString];
	NSURL* baseURL = [NSURL fileURLWithPath:pathString];
	NSString* mapHTML;
	
	myWebView.hidden = NO;
	if(myData)
	{
		mapHTML = [[[NSString alloc] initWithData:myData encoding:NSASCIIStringEncoding] autorelease];
	//////////NSLog(@"Mapped data: %@",mapHTML);
		////////NSLog(@"MasterBlaster Owns Barter Town.");
	}
	else
	{
		////////NSLog(@"failed to load file.");
		return;
	}

	//[paramString retain];
	NSString*tmpHTML;
	if(disableStationQueryStr)
	{
		tmpHTML = [mapHTML stringByReplacingOccurrencesOfString:VAR_TOKEN withString:[NSString stringWithFormat:@"?%@%@",paramString,VERSION_TOKEN]];
	}
	else
	{
		tmpHTML = [mapHTML stringByReplacingOccurrencesOfString:VAR_TOKEN withString:[NSString stringWithFormat:@"?%@%@%@",paramString,STATION_QUERY_STRING,VERSION_TOKEN]];
	}
	
    ////////NSLog(@"Mapped data: %@",tmpHTML);
	//[mapHTML release];
	
	[webviewToRemoveFromSuperView removeFromSuperview];
	myWebView = [[[UIWebView alloc] initWithFrame:webViewFrameAfterDelay] autorelease];
	if(webViewIsTransparent)myWebView.backgroundColor = [UIColor clearColor];
	myWebView.opaque = NO;
	myWebView.delegate = self;
	myWebView.hidden = YES;
	
	//NSURLRequest* itemViewRequest = [NSURLRequest requestWithURL:[NSURL URLWithString:urlToLoadAfterDelay]];
	//[urlToLoadAfterDelay release];
	//urlToLoadAfterDelay = nil;
	////////NSLog(@"webview %@", myWebView);
	//////////NSLog(@"itemViewRequest:%@",itemViewRequest);
	//[myWebView loadRequest:itemViewRequest];
	////////NSLog(@"%@",tmpHTML);
	[myWebView loadHTMLString:[tmpHTML retain] baseURL:[NSURL URLWithString:LINK_DOMAIN_URL_STRING]];
	//[myWebView loadHTMLString:[tmpHTML retain] baseURL:[NSURL fileURLWithPath:[[NSBundle mainBundle] bundlePath]]];
	if(webViewDisplayIndex < 0)
	{
		[self.view insertSubview:myWebView belowSubview:connectingAnimation_ai];
	}
	else
	{
		[self.view insertSubview:myWebView atIndex:webViewDisplayIndex];
	}
	myWebView.hidden = NO;
	////////NSLog(@"made it to the end.");
	
	
	
	
}

- (void) loadURLStringActual:(UIWebView*)webviewToRemoveFromSuperView
{

	[webviewToRemoveFromSuperView removeFromSuperview];
	myWebView = [[[UIWebView alloc] initWithFrame:webViewFrameAfterDelay] autorelease];
	if(webViewIsTransparent)myWebView.backgroundColor = [UIColor clearColor];
	myWebView.opaque = NO;
	myWebView.delegate = self;
	myWebView.hidden = YES;

	NSURLRequest* itemViewRequest = [NSURLRequest requestWithURL:[NSURL URLWithString:urlToLoadAfterDelay]];
	[urlToLoadAfterDelay release];
	urlToLoadAfterDelay = nil;
	////////NSLog(@"webview %@", myWebView);
	////////NSLog(@"itemViewRequest:%@",itemViewRequest);
	[myWebView loadRequest:itemViewRequest];
	if(webViewDisplayIndex < 0)
	{
		[self.view insertSubview:myWebView belowSubview:connectingAnimation_ai];
	}
	else
	{
		[self.view insertSubview:myWebView atIndex:webViewDisplayIndex];
	}
	
}

- (void)webViewDidFinishLoad:(UIWebView *)webView
{
	//////NSLog(@"Reached webViewDidFInishLoad in webviewController");

	//////NSLog(@"myWebView [%@] finished loading", myWebView);
	[connectingAnimation_ai stopAnimating];	
	webView.hidden = NO;
	////////NSLog(@"leaving webViewDidFinishLoad.");
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
	//[//super webView:webView didFailLoadWithError:error];

	[connectingAnimation_ai stopAnimating];
	
	////////NSLog(@"Failed Load with error %@", error);	
}



	

- (BOOL) shouldLaunchExternalInSafari:(NSString*)urlString
{
	////////NSLog(@"Should launch url [%@] in external view?", urlString);
	return NO;
	if([urlString rangeOfString:@"phobos.apple.com"].location != NSNotFound)
	{
		[[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlString]];
	}
	else
	{
		//////NSLog(@"URL STRING %@", urlString);	
		/*
		 webBrowser_vc.startLocation = urlString;
		 [webBrowser_vc loadURLString:urlString];
		 */
		
		[Utils navigateToURL:urlString];
		//[self.navigationController presentModalViewController:webBrowser_vc animated:YES];
	}
	return YES;
}
/*
 - (void) onTabToHome
 {
 
 }
 
 - (void) onTabToMyChannel:(id)sender
 {
 
 }
 
 - (void) onTabToFollowing:(id)sender
 {
 
 }
 
 - (void) onTabToVideo:(id)sender
 {
 
 }
 
 - (void) onTabToWebsite:(id)sender
 {
 
 }
 */

/*
 // Implement viewDidLoad to do additional setup after loading the view.
 - (void)viewDidLoad {
 [super viewDidLoad];
 }
 */



- (void) viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
}

- (void) viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
	[statusLoadingIndicatorTime invalidate];
	statusLoadingIndicatorTime = nil;
}

- (void) viewDidAppear:(BOOL)animated
{
	[super viewDidAppear:animated];
	#ifdef FLURRYAPI_H
		[FlurryAPI logEvent:@"page view"];
	#endif
	statusLoadingIndicatorTime = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(testIsLoading)
																userInfo:NO repeats:YES];
}

- (void)testIsLoading
{
	//////////NSLog(@"mywebview: %@",myWebView);
	//////////NSLog(@"shared application: %@", [UIApplication sharedApplication]);
	if(self != nil)
	{
		//////////NSLog(@"self = %@",self);
		[UIApplication sharedApplication].networkActivityIndicatorVisible = [myWebView isLoading];
	}
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation 
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (void)didReceiveMemoryWarning 
{	
	[initURLString retain];
    [super didReceiveMemoryWarning]; 
		////////NSLog(@"webViewController did recieve memeory warning.");
}

- (void)dealloc 
{
	[initURLString release];
	[myWebView stopLoading];
	[super dealloc];
}

@end
