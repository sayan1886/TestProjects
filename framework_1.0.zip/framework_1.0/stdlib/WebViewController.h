//
//  ListViewController.h
//  EyeReport
//
//  Create by Andrew Paul Simmons on 10/11/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "constants.h"
//#import "ItemViewController.h"
#import "WebActionHandler.h"
#import "Utils.h"

#ifndef VERSION_TOKEN
#define VERSION_TOKEN @""
#endif

@interface WebViewController : WebActionHandler <UIWebViewDelegate>
{
	
	UIWebView* myWebView;
	UIActivityIndicatorView* connectingAnimation_ai;
	NSString* urlToLoadAfterDelay;
	float connectingAnimationInitY;
	CGRect webViewFrame;
	CGRect webViewFrameAfterDelay;
	NSString* initURLString;
	UIView* loadingViewBackground;
	BOOL supressDefaultLoadingAnimation;
	BOOL webViewIsTransparent;
	BOOL disableStationQueryStr;
	int webViewDisplayIndex;  // -1 => floating 
	UIAlertView* loadFailureAlertView;
	NSTimer* statusLoadingIndicatorTime;
	NSString* pathString;
	NSString* paramString;

}


//::Public
- (void) showAndReloadBrowse;
- (WebAction) onRenderStart:(NSString*)voidParam;
//- (ItemViewController*) itemViewMakeFresh;

@property(copy) NSString* initURLString;
@property(assign) BOOL disableStationQueryStr;
//::Private

- (void) doInit;
- (void) loadURLString:(NSString*)urlString;
- (void) loadPathString:(NSString*)filePath withParams:(NSString*)htmlParameterString;
- (void) showItemWithURL:(NSString*)url animated:(BOOL)animated;


@end
