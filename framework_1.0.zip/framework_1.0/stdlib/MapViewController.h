//
//  MapViewController.h
//  Qwiket
//
//  Create by Andrew Paul Simmons on 6/18/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//


#import <UIKit/UIKit.h>

#import <MapKit/MapKit.h>
#import <MapKit/MKAnnotation.h>

#import <CoreLocation/CoreLocation.h>

#import "LocalInformation.h"
#import "BasicMapAnnotation.h"
#import "Utils.h"

@interface MapViewController : UIViewController <MKMapViewDelegate>
{
	MKMapView* mapView;
	LocalInformation* localInformation;
	
	float currentLatitude;
	float currentLongitude;

	NSString* cityName;
	UIAlertView* errorMessage;
	BOOL hideDetailsButton;
	BOOL notLocal;
	BOOL finishedLoading;
}

//::Public

//::Protected
- (void) centerMapOnLat:(float)lat lon:(float)lon;

/* Abstract */
- (void)onLoadCity:(NSString*)city; // Override this method
- (void) onTapCallout:(id<MKAnnotation>)annotation; //Override this method


//::Private

@end
