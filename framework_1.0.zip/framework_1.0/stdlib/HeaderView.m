//
//  HeaderView.m
//  eMagazine
//
//  Created by SOHAMPAUL on 03/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "HeaderView.h"
#import "Utils.h"

@implementation HeaderView
@synthesize delegate;
@synthesize butPage;
@synthesize butStore;
@synthesize butWebcast;
@synthesize butCollection;

- (id)initWithFrame:(CGRect)frame andDelegate:(id)del {
    if ((self = [super initWithFrame:frame])) {
        // Initialization code
		
		CGFloat selfHeight = frame.size.height;
		CGFloat selfWidth = frame.size.width;
		delegate = del;
		self.backgroundColor = [UIColor clearColor];
		
		UIButton *butHome = [UIButton buttonWithType:UIButtonTypeCustom];
		butHome.frame = CGRectMake(20, 0, selfHeight, selfHeight);
		[butHome setBackgroundColor:[UIColor clearColor]];
		[butHome setBackgroundImage:[UIImage imageNamed:@"home_deselect.png"] forState:UIControlStateNormal];
		[butHome setBackgroundImage:[UIImage imageNamed:@"home_select.png"] forState:UIControlStateHighlighted];
		[butHome addTarget:delegate action:@selector(homeButtonAction:) forControlEvents:UIControlEventTouchUpInside];
		[self addSubview:butHome];
		
		/*UIButton *butAbout = [UIButton buttonWithType:UIButtonTypeCustom];
		butAbout.frame = CGRectMake(20+selfHeight, 0, selfHeight, selfHeight);
		[butAbout setBackgroundColor:[UIColor clearColor]];
		[butAbout setBackgroundImage:[UIImage imageNamed:@"about_deselect.png"] forState:UIControlStateNormal];
		[butAbout setBackgroundImage:[UIImage imageNamed:@"about_select.png"] forState:UIControlStateHighlighted];
		[butAbout addTarget:delegate action:@selector(aboutButtonAction:) forControlEvents:UIControlEventTouchUpInside];
		[self addSubview:butAbout];*/
		
		/*UIButton *butFeedback = [UIButton buttonWithType:UIButtonTypeCustom];
		butFeedback.frame = CGRectMake(20+68+68, 0, 64, selfHeight);
		[butFeedback setBackgroundColor:[UIColor clearColor]];
		[butFeedback setBackgroundImage:[UIImage imageNamed:@"feedback_deselect.png"] forState:UIControlStateNormal];
		[butFeedback setBackgroundImage:[UIImage imageNamed:@"feedback_select.png"] forState:UIControlStateHighlighted];
		[butFeedback addTarget:delegate action:@selector(feedbackButtonAction:) forControlEvents:UIControlEventTouchUpInside];
		[self addSubview:butFeedback];
		
		UIButton *butArchive = [UIButton buttonWithType:UIButtonTypeCustom];
		butArchive.frame = CGRectMake(20+68+68+68, 0, 64, selfHeight);
		[butArchive setBackgroundColor:[UIColor clearColor]];
		[butArchive setBackgroundImage:[UIImage imageNamed:@"archive_deselect.png"] forState:UIControlStateNormal];
		[butArchive setBackgroundImage:[UIImage imageNamed:@"archive_select.png"] forState:UIControlStateHighlighted];
		[butArchive addTarget:delegate action:@selector(archiveButtonAction:) forControlEvents:UIControlEventTouchUpInside];
		[self addSubview:butArchive];*/
		
		UIButton *butContact = [UIButton buttonWithType:UIButtonTypeCustom];
		//butContact.frame = CGRectMake(20+68+68+68+68, 0, 64, selfHeight);
		butContact.frame = CGRectMake(20+(selfHeight*1), 0, selfHeight, selfHeight);
		[butContact setBackgroundColor:[UIColor clearColor]];
		[butContact setBackgroundImage:[UIImage imageNamed:@"contact_deselect.png"] forState:UIControlStateNormal];
		[butContact setBackgroundImage:[UIImage imageNamed:@"contact_select.png"] forState:UIControlStateHighlighted];
		[butContact addTarget:delegate action:@selector(contactButtonAction:) forControlEvents:UIControlEventTouchUpInside];
		[self addSubview:butContact];
		
		/*UIButton *butSetting = [UIButton buttonWithType:UIButtonTypeCustom];
		butSetting.frame = CGRectMake(20+68+68+68+68+68, 0, 64, selfHeight);
		[butSetting setBackgroundColor:[UIColor clearColor]];
		[butSetting setBackgroundImage:[UIImage imageNamed:@"settings_deselect.png"] forState:UIControlStateNormal];
		[butSetting setBackgroundImage:[UIImage imageNamed:@"settings_select.png"] forState:UIControlStateHighlighted];
		[butSetting addTarget:delegate action:@selector(settingButtonAction:) forControlEvents:UIControlEventTouchUpInside];
		[self addSubview:butSetting];*/
		
		/*butPage = [UIButton buttonWithType:UIButtonTypeCustom];
		butPage.frame = CGRectMake(selfWidth-(selfHeight*2.9)-10, selfHeight/4, (selfHeight*2.9), selfHeight/2);
		butPage.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
		[butPage setBackgroundColor:[UIColor clearColor]];
		[butPage setBackgroundImage:[UIImage imageNamed:@"page_no_deselect.png"] forState:UIControlStateNormal];
		[butPage setBackgroundImage:[UIImage imageNamed:@"page_no_select.png"] forState:UIControlStateHighlighted];
		[self addSubview:butPage];*/
        
        butCollection = [UIButton buttonWithType:UIButtonTypeCustom];
        butCollection.tag = 101;
        
		butCollection.frame = CGRectMake(selfWidth - 171 - 121 - 200, (selfHeight/4), 191, 36); // 121 - 200
		[butCollection setBackgroundColor:[UIColor clearColor]];
		[butCollection setBackgroundImage:[UIImage imageNamed:@"collection.png"] forState:UIControlStateNormal];
        [butCollection setBackgroundImage:[UIImage imageNamed:@"collection_1.png"] forState:UIControlStateHighlighted];
		[butCollection setBackgroundImage:[UIImage imageNamed:@"collection_1.png"] forState:UIControlStateSelected];
		[butCollection addTarget:delegate action:@selector(collectionButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        butCollection.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleHeight;
       [self addSubview:butCollection];

		
		butStore = [UIButton buttonWithType:UIButtonTypeCustom];
        butStore.tag = 102;
		butStore.frame = CGRectMake(selfWidth - 171 -121, (selfHeight/4), 109, 36); //- 121
		[butStore setBackgroundColor:[UIColor clearColor]];
		[butStore setBackgroundImage:[UIImage imageNamed:@"store.png"] forState:UIControlStateNormal];
        [butStore setBackgroundImage:[UIImage imageNamed:@"store_1.png"] forState:UIControlStateHighlighted];
		[butStore setBackgroundImage:[UIImage imageNamed:@"store_1.png"] forState:UIControlStateSelected];
		[butStore addTarget:delegate action:@selector(storeButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        butStore.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleBottomMargin |  UIViewAutoresizingFlexibleHeight;
        [self addSubview:butStore];

        
        butWebcast = [UIButton buttonWithType:UIButtonTypeCustom];
        butWebcast.tag = 103;
		butWebcast.frame = CGRectMake(selfWidth-171, (selfHeight/4), 141, 36);
		[butWebcast setBackgroundColor:[UIColor clearColor]];
		[butWebcast setBackgroundImage:[UIImage imageNamed:@"logout_inactive.png"] forState:UIControlStateNormal];
		[butWebcast setBackgroundImage:[UIImage imageNamed:@"logout_active.png"] forState:UIControlStateSelected];
        [butWebcast setBackgroundImage:[UIImage imageNamed:@"logout_active.png"] forState:UIControlStateHighlighted];
		[butWebcast addTarget:delegate action:@selector(webcastButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        butWebcast.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleBottomMargin |  UIViewAutoresizingFlexibleHeight;
		[self addSubview:butWebcast];
        
        if (![Utils isPad]) {
            butCollection.frame = CGRectMake(selfWidth - 68 - 49 - 83 , selfHeight / 4, 80, 20);
            butStore.frame = CGRectMake(selfWidth - 68 - 49, selfHeight / 4, 46, 20);
            butWebcast.frame = CGRectMake(selfWidth - 68, selfHeight / 4, 65 , 20);
        }
        
    }
    return self;
}

-(void)selectButton:(UIButton*)but {
    if (but!=nil) {
        [but setSelected:YES];
        if (but.tag==101) {
            [butStore setSelected:NO];
            [butWebcast setSelected:NO];
        }
        else if(but.tag==102) {
            [butCollection setSelected:NO];
            [butWebcast setSelected:NO];
        }
        else if(but.tag==103) {
            [butStore setSelected:NO];
            [butCollection setSelected:NO];
        }
    }
    else {
        [butStore setSelected:NO];
        [butCollection setSelected:NO];
        [butWebcast setSelected:NO];
    }
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
	
}
*/

- (void)dealloc {
    self.butCollection = nil;
    self.butStore = nil;
    self.butWebcast = nil;
    [super dealloc];
}


@end
