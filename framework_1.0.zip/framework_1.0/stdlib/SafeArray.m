//
//  SafeArray.m
//  Andrew_CBSNews
//
//  Create by Andrew Paul Simmons on 3/11/10.
//  Copyright 2010 Treemo Labs All rights reserved.
//

#import "SafeArray.h"



@implementation SafeArray
@synthesize mutableArray;
- (id)initWithArray:(NSArray*)anArray
{
	if(self = [super init])
	{
		if([anArray isKindOfClass:[NSArray class]])
		{
			mutableArray = [[NSMutableArray arrayWithArray:anArray] retain];
		}
		else {
			////NSLog(@"Could not create safe array from array %@", anArray);
		}

	}
	return self;
}

+ (SafeArray*) safeArrayWithArray:(NSArray*)anArray
{
	return [[[SafeArray alloc] initWithArray:anArray] autorelease];
}



- (void)addObject:(id)anObject
{
	if(!mutableArray)
	{
		////NSLog(@"SafeArray::addObject: Warning: internal array is nil");
		return;
	}
	if(!anObject)
	{
		////NSLog(@"SafeArray::addObject: Warning ignored attempt to set nil object");
		return;		
	}
	[mutableArray addObject:anObject];
}

- (void) removeObjectAtIndex:(NSUInteger)index
{
	if(!mutableArray)
	{
		////NSLog(@"SafeArray::removeObjectAtIndex: Warning: internal array is nil");
	}
	if( (index > -1) && (index < [self count]) )
	{
		[mutableArray removeObjectAtIndex:index];
	}
	else 
	{
		////NSLog(@"SafeArray::removeObjectAtIndex: Warning: index out of range");
	}	
}



- (NSString*)stringAtIndex:(NSUInteger)index
{
	if(!mutableArray)
	{
		////NSLog(@"SafeArray::stringAtIndex: Warning: internal array is nil");
		return @"";
	}
	
	if(index < [self count])
	{
		id value_obj = [mutableArray objectAtIndex:index];
		
		if( !([value_obj isKindOfClass:[NSString class]] || [value_obj isKindOfClass:[NSNumber class]]) )
		{
			////NSLog(@"SafeArray::stringAtIndex: Warning: non-string value found");
			return @"";
		}
		return [value_obj description];
	}
	else 
	{
		////NSLog(@"SafeArray::stringAtIndex: Warning: index out of range");
		return @"";
	}
}


- (SafeArray*)safeArrayAtIndex:(NSUInteger)index
{
	if(!mutableArray)
	{
		////NSLog(@"SafeArray::safeArrayAtIndex: Warning: internal array is nil");
		return nil;
	}
	
	if(index < [self count])
	{
		id value_obj = [mutableArray objectAtIndex:index];
		
		if( !([value_obj isKindOfClass:[NSArray class]] || [value_obj isKindOfClass:[SafeArray class]]) )
		{
			////NSLog(@"SafeArray::safeArrayAtIndex: Warning: non-array value found");
			return nil;
		}
		
		if([value_obj isKindOfClass:[SafeArray class]])
		{
			return (SafeArray*)value_obj;
		}
		else
		{
			return [[[SafeArray alloc] initWithArray:value_obj] autorelease];
		}
	}
	else 
	{
		////NSLog(@"SafeArray::safeArrayAtIndex: Warning: index out of range");
		return nil;
	}	
}

- (SafeDictionary*)safeDictionaryAtIndex:(NSUInteger)index
{
	if(!mutableArray)
	{
		////NSLog(@"SafeArray::safeDictionaryAtIndex: Warning: internal array is nil");
		return nil;
	}
	
	if(index < [self count])
	{
		id value_obj = [mutableArray objectAtIndex:index];
		
		if( !([value_obj isKindOfClass:[NSDictionary class]] || [value_obj isKindOfClass:[SafeDictionary class]]) )
		{
			////NSLog(@"SafeArray::safeDictionaryAtIndex: Warning: non-dictionary value found");
			return nil;
		}
		
		if([value_obj isKindOfClass:[SafeDictionary class]])
		{
			return (SafeDictionary*)value_obj;
		}
		else
		{
			return [[[SafeDictionary alloc] initWithDictionary:value_obj] autorelease];
		}
	}
	else 
	{
		NSLog(@"SafeArray::safeDictionaryAtIndex: Warning: index (%i) out of range in array with %i elements.", 
			  index, [self count]);
		
		return nil;
	}	
}


- (NSUInteger)count
{
	
	return [mutableArray count];
}

- (NSString*) description
{
	return [mutableArray description]; 
}

- (void)dealloc 
{
	[mutableArray release];
    [super dealloc];
}

// values are pulled by type
@end
