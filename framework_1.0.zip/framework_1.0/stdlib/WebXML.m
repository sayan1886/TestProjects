//
//  WebXMLParser.m
//  ShowTreemo
//
//  Create by Andrew Paul Simmons on 7/30/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import "WebXML.h"


xmlXPathObjectPtr getnodeset (xmlDocPtr doc, xmlChar* xpath, xmlNodePtr contextNode)
{
	
	xmlXPathContextPtr context;
	xmlXPathObjectPtr result;
	
	context = xmlXPathNewContext(doc);
	if (context == NULL) 
	{
		printf("Error in xmlXPathNewContext\n");
		return NULL;
	}
	
	if(contextNode) context->node = contextNode;
	
	result = xmlXPathEvalExpression(xpath, context);
	xmlXPathFreeContext(context);
	if (result == NULL) 
	{
		printf("Error in xmlXPathEvalExpression\n");
		return NULL;
	}
	if(xmlXPathNodeSetIsEmpty(result->nodesetval))
	{
		xmlXPathFreeObject(result);
		//printf("No result\n");
		return NULL;
	}
	return result;
}



@implementation WebXML

-(id)initWithString:(NSString*)xml_str 
{	
	if(![super init]) return nil;

	if(xml_str == nil)
	{
		////////NSLog(@"could not create xml document from empty string");
		return nil;
	}
	
	//for files use xmlParseFile
	doc = xmlRecoverMemory([xml_str UTF8String], 
						   [xml_str lengthOfBytesUsingEncoding:NSUTF8StringEncoding]);
	
	if(doc == nil)
	{
		////////NSLog(@"could not create xml document");
		return nil;
	}
	
	return self;
}

- (NSString* ) firstValueWithPath:(NSString*)xpath
{
	return [self firstValueWithPath:xpath fromNode:nil];

}

- (NSString*) firstValueWithPath:(NSString*)xpath fromNode:(xmlNodePtr)contextNode
{	
	
	return [self valueWithPath:xpath fromNode:contextNode atIndex:0];
	/*
	xmlChar* xpath_xmlChar = (xmlChar*)[xpath UTF8String];

	
	xmlXPathObjectPtr result = getnodeset(doc, xpath_xmlChar, contextNode);
	if(result == NULL) return nil;
	
	if(result->nodesetval == NULL 
	   || result->nodesetval->nodeTab == NULL
	   || result->nodesetval->nodeTab[0] == NULL 
	   || result->nodesetval->nodeTab[0]->children == NULL 
	   || result->nodesetval->nodeTab[0]->children->content == NULL)
	{
		//////////NSLog(@"Could not find value after obtaining xpath result");
		return nil;
	}
	
	//xmlChar* is unsigned cast to signed
	xmlChar* value = result->nodesetval->nodeTab[0]->children->content;	
	//  does not copy bytes
	return [NSString stringWithCString:(char*)value encoding:NSUTF8StringEncoding];
	 */
}



- (NSString*) valueWithPath:(NSString*)xpath fromNode:(xmlNodePtr)contextNode atIndex:(int)index 
{	
	xmlChar* xpath_xmlChar = (xmlChar*)[xpath UTF8String];
	
	
	xmlXPathObjectPtr result = getnodeset(doc, xpath_xmlChar, contextNode);

	if(result == NULL) return nil;
	
	if(result->nodesetval == NULL 
	   || result->nodesetval->nodeTab == NULL
	   || result->nodesetval->nodeTab[index] == NULL 
	   || result->nodesetval->nodeTab[index]->children == NULL 
	   || result->nodesetval->nodeTab[index]->children->content == NULL)
	{
		//////////NSLog(@"Could not find value after obtaining xpath result");
		return nil;
	}
	
	//xmlChar* is unsigned cast to signed
	xmlChar* value = result->nodesetval->nodeTab[index]->children->content;	
	//  does not copy bytes
	return [NSString stringWithCString:(char*)value encoding:NSUTF8StringEncoding];
}

- (xmlNodeSetPtr) nodeSetWithPath:(NSString*)xpath
{
	return [self nodeSetWithPath:xpath fromNode:nil];
}

- (xmlNodeSetPtr) nodeSetWithPath:(NSString*)xpath fromNode:(xmlNodePtr)contextNode
{
	
	xmlChar* xpath_xmlChar = (xmlChar*)[xpath UTF8String];
	xmlXPathObjectPtr result;
	
	result = getnodeset(doc, xpath_xmlChar, contextNode);
	
	if(!result)
	{
		////////NSLog(@"Could not get result from xpath expression %@", xpath);
		return NULL; 
	}
	
	xmlNodeSetPtr nodeset = result->nodesetval;
	
	return nodeset;	
}


- (bool) elementExistsForPath:(NSString*)xpath
{
	id result  = [self firstValueWithPath:xpath];
	bool elementExists = (result != nil);
	return elementExists;
}

- (void) dealloc 
{
	xmlFreeDoc(doc);
	[super dealloc];
}

@end
