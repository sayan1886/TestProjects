//
//  MessageCompositionViewController.h
//  Qwiket
//
//  Created by steve on 8/12/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "fontnames.h"
#import "SettingsCell_TextEntry.h"
#import "Utils.h"

@interface MessageCompositionViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>
{
	UITableView* myTableView;
	CGRect myTableFrame;
	UITableViewStyle myTableStyle;
	NSMutableDictionary* cells;
	IBOutlet UIBarButtonItem* send;
	//UIActivityIndicatorView* loading;
	
}
//::Public

//::Private
- (IBAction) onCancel:(id)sender;
- (IBAction) onSendMessage:(id)sender;
- (void) doInit;
- (void) createCells;


@end
