//
//  PrivateMesssageCompositionViewController.m
//  Qwiket
//
//  Created by steve on 7/29/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import "PrivateMessageCompositionViewController.h"

@implementation PrivateMessageCompositionViewController : MessageCompositionViewController

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}registerviewcontroller
*/ 

- (id) init 
{
	if(self = [super init])
	{
		[super doInit];
		loading = [Utils activityInidicatorCenteredInSize:CGSizeMake(320, 400)];
		loading.activityIndicatorViewStyle = UIActivityIndicatorViewStyleGray;
		[loading stopAnimating];
		
	}
	return self;	
}


/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/

- (void) viewDidAppear:(BOOL)animated
{
	SettingsCell_TextEntry* user_te = [cells objectForKey:@"user"];
	SettingsCell_TextEntry* subject_te = [cells objectForKey:@"subject"];
	NSString* usertmp = ((SettingsCell_TextEntry*)[cells objectForKey:@"user"]).propertyText.text;
	NSString* subjecttmp = ((SettingsCell_TextEntry*)[cells objectForKey:@"subject"]).propertyText.text;
	
	
	if(((SettingsCell_TextEntry*)[cells objectForKey:@"user"]).propertyText.text == nil)
	{
		[user_te setSelected:YES animated:NO];
		//[((SettingsCell_TextEntry*)[myTableView accessibilityElementAtIndex:0]) updateSelection];
	}
	else if (((SettingsCell_TextEntry*)[cells objectForKey:@"subject"]).propertyText.text == nil)
	{
		[subject_te setSelected:YES animated:NO];
		//[((SettingsCell_TextEntry*)[myTableView accessibilityElementAtIndex:1]) updateSelection];
	}
	else
	{
		[((UITextView*)myTableView.tableFooterView) becomeFirstResponder];
		NSInteger length = ((UITextView*)myTableView.tableFooterView).text.length;
		((UITextView*)myTableView.tableFooterView).selectedRange = NSMakeRange(0,0);
	}
}
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	////////NSLog(@"PMCVC: View Did Load");
	
	

	////////NSLog(@"PMCVC: Creating cells dictionary.");
	cells = [[NSMutableDictionary alloc] initWithCapacity:0];
	////////NSLog(@"PMCVC: Calling CreateCells.");
	[self createCells];
	////////NSLog(@"PMCVC: Adding subview, MyTableView.");
	UITextView* body = [[UITextView alloc] initWithFrame:CGRectMake(0, 0, 320, 320)];
	body.font = [UIFont fontWithName:FONTNAME_helvetica size:15];
	myTableView.tableFooterView = body;
	//UITextView* messageBodyText = [[[UITextView alloc] init] autorelease];
	//[myTableView.tableFooterView addSubview:messageBodyText];
	[self.view addSubview:myTableView];
	[self.view addSubview:loading];	
	////////NSLog(@"PMCVC: finished viewdidload");
}

- (void)viewDidUnload {

	[super viewDidUnload];
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}

- (void) onPeformRegister:(id)sender
{
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/


- (IBAction) onCancel: (id) sender
{
	[loading stopAnimating];
	////////NSLog(@"Cancel message send pressed.");
	[self.parentViewController dismissModalViewControllerAnimated:YES];
}

-(void) alertView:(UIAlertView*)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	[loading stopAnimating];
	//[super alertView:alertView clickedButtonAtIndex:buttonIndex];
	if([alertView.title compare:@"Error Loading Page"] != 0)
	{
		send.enabled = YES;
		////////NSLog(@"alertview reached for message: %@",alertView.title);
	
		if( alertView.title == @"Message Sent")
		{
			////////NSLog(@"poping view controller.");
			if(self != nil)
				[self.parentViewController dismissModalViewControllerAnimated:YES];
		}
	
		[alertView release];
		alertView = nil;
		[self release];
	}
	return;
}

- (IBAction) onSendMessage: (id) sender
{
	[loading startAnimating];

	////////NSLog(@"OnSend pressed. BUTTON ID: %@",send);
	[self retain];
	//Error handling for message
	send.enabled = NO;
	////////NSLog(@"send button should be disabled.");
	SettingsCell_TextEntry* user = [cells objectForKey:@"user"];
	if(user.propertyText.text == nil)
	{
		
		UIAlertView* incompleteParameters = [[UIAlertView alloc] initWithTitle: @"Message Send Failure"
																		message: @"You must specify a user." 
																	   delegate:self
															  cancelButtonTitle:nil 
															  otherButtonTitles:@"OK",nil];
		[incompleteParameters show];
		//sender.enabled = YES;
		return;
	}

	////////NSLog(@"user : %@", user.propertyText.text);
	SettingsCell_TextEntry	* subject = [cells objectForKey:@"subject"];
	if(subject.propertyText.text == nil)
	{
		
		UIAlertView* incompleteParameters = [[UIAlertView alloc] initWithTitle: @"Message Send Failure"
																		message: @"You must have a subject." 
																	   delegate:self
															  cancelButtonTitle:nil 
															  otherButtonTitles:@"OK",nil];
		[incompleteParameters show];
		return;
	}
	////////NSLog(@"subject : %@", subject.propertyText.text );
	UITextView* body_temp = myTableView.tableFooterView;
	NSString* body = body_temp.text;
	/*if(body == "")
	{
		UIAlertView* incompleteParameters = [[[UIAlertView alloc] initWithTitle: @"Message Send Failure"
																		message: @"Your message must have a body." 
																	   delegate:self
															  cancelButtonTitle:nil 
															  otherButtonTitles:@"OK",nil] autorelease];
		[incompleteParameters show];
		return;
	}*/
	////////NSLog(@"body : %@",body);
	/*
	[ApplicationAPIBinding  qwiketsSendPrivateMessageWithUser:user.propertyText.text
													  subject:subject.propertyText.text
														 body:body
													   targer:self
												   success_cb:@selector(success:)
												   failure_cb:@selector(failure:)];
	 */
	return;
}
-(void) success:(id)sender
{
	[loading stopAnimating];
	UIAlertView* messageSent = [[UIAlertView alloc] initWithTitle: @"Message Sent"
														   message: @"Your message has been sent." 
														  delegate:self
												 cancelButtonTitle:nil 
												 otherButtonTitles:@"OK",nil];
	
	
	messageSent.delegate = self;
	[messageSent show];
	////////NSLog(@"onSend successful!");
}

-(void) failure:(id)sender
{
	[loading stopAnimating];
	UIAlertView* messageSendFailed = [[UIAlertView alloc] initWithTitle: @"Message Send Failed"
														  message: sender 
														 delegate:self
												cancelButtonTitle:nil 
												otherButtonTitles:@"OK",nil];
	
	messageSendFailed.delegate = self;
	[messageSendFailed show];
	////////NSLog(@"onSend failure :( .");
	
}
- (void) createCells 
{
	{
		NSString* cellIdentifier = @"user";
		SettingsCell_TextEntry* cell;
		cell = [[[SettingsCell_TextEntry alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier]autorelease];
		cell.label.text = @"User";
		cell.propertyText.keyboardType = UIKeyboardTypeDefault;
		[cells setObject:cell forKey:cellIdentifier];
		////////NSLog(@"Created cell %@", [cells objectForKey:@"user"]);
	}

	{
		NSString* cellIdentifier = @"subject";
		SettingsCell_TextEntry* cell;
		cell = [[[SettingsCell_TextEntry alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
		cell.label.text = @"Subject";
		cell.propertyText.keyboardType = UIKeyboardTypeDefault;
		[cells setObject:cell forKey:cellIdentifier];
		////////NSLog(@"Created cell %@", [cells objectForKey:@"subject"]);
	}
	/*
	{
		NSString* cellIdentifier = @"Body";
		SettingsCell_TextEntry* cell;
		cell = [[[SettingsCell_TextEntry alloc] initWithFrame:CGRectZero reuseIdentifier:cellIdentifier] autorelease];
		cell.label.text = @"Body";
		cell.propertyText.keyboardType = UIKeyboardTypeDefault;
		[cells setObject:cell forKey:cellIdentifier];
		////////NSLog(@"Created cell %@", [cells objectForKey:@"Body"]);
	}
	*/
}


-(NSInteger)tableView:(UITableView*)tableView numberOfRowsInSection:(NSInteger)section
{
	return 2;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath 
{
	
		if(indexPath.row == 0)
		{
			////////NSLog(@"Returning user cell: %@",[cells objectForKey:@"user"]);
			return [cells objectForKey:@"user"];
		}
		else if (indexPath.row == 1)
		{
			return [cells objectForKey:@"subject"];
		}
	
	return nil;
}


- (void)didReceiveMemoryWarning {
		////////NSLog(@"privatemessageCompositionViewController did recieve memeory warning.");
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}




- (void)dealloc {
    [cells release];
	cells = nil;
	[super dealloc];
	
}


@end
