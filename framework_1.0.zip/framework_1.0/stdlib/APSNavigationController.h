//
//  APSNavigationController.h
//  Qwiket
//
//  Create by Andrew Paul Simmons on 6/4/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>

// Data surce protocol
@protocol APSNavigationControllerListener

@optional
- (BOOL) shouldPopViewController:(UIViewController*)vc;


@end

@interface APSNavigationController : UINavigationController 
{
	

}

@end
