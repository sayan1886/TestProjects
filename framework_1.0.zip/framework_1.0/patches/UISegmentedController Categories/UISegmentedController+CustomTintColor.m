//
//  UISegmentedController+CustomTintColor.m
//  BigGameRegs
//
//  Created by Sayan on 18/02/11.
//  Copyright 2011 Sportsmanregs LLC. All rights reserved.
//

#import "UISegmentedController+CustomTintColor.h"


@implementation UISegmentedController_CustomTintColor

@end

@implementation UISegmentedControl(CustomTintExtension)

-(void)setTag:(NSInteger)tag forSegmentAtIndex:(NSUInteger)segment {
	[[[self subviews] objectAtIndex:segment] setTag:tag];
}

-(void)setTintColor:(UIColor*)color forTag:(NSInteger)aTag {
	// must operate by tags.  Subview index is unreliable
	UIView *segment = [self viewWithTag:aTag];
	SEL tint = @selector(setTintColor:);
	
	// UISegment is an undocumented class, so tread carefully
	// if the segment exists and if it responds to the setTintColor message
	if (segment && ([segment respondsToSelector:tint])) {
		[segment performSelector:tint withObject:color];
	}
}

-(void)setTextColor:(UIColor*)color forTag:(NSInteger)aTag {
	UIView *segment = [self viewWithTag:aTag];
	for (UIView *view in segment.subviews) {
		SEL text = @selector(setTextColor:);
		
		// if the sub view exists and if it responds to the setTextColor message
		if (view && ([view respondsToSelector:text])) {
			[view performSelector:text withObject:color];
		}
	}
}

-(void)setShadowColor:(UIColor*)color forTag:(NSInteger)aTag {
	
	UIView *segment = [self viewWithTag:aTag];
	for (UIView *view in segment.subviews) {
		SEL shadowColor = @selector(setShadowColor:);
		// if the sub view exists and if it responds to the setShadowColor message
		if (view && ([view respondsToSelector:shadowColor])) {
			[view performSelector:shadowColor withObject:color];
		}
	}
}
-(void)setFont:(UIFont *)textFont forTag:(NSInteger)aTag {
	
	UIView *segment = [self viewWithTag:aTag];
	for (UIView *view in segment.subviews) {
		SEL font = @selector(setFont:);
		// if the sub view exists and if it responds to the setFont message
		if (view && ([view respondsToSelector:font])) {
			[view performSelector:font withObject:textFont];
		}
	}
}

@end