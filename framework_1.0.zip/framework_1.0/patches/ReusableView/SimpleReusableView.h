//
//  SimpleReusableView.h
//  ViewsCache
//
//  Created by Dmitry Stadnik on 1/21/10.
//  Copyright www.dimzzy.com 2010. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewsCache.h"

@interface SimpleReusableView : UIView <ReusableView> {
	NSString *reuseIdentifier;
}

@end
