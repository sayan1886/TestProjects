//
//  MessageBox.m
//  TrivPals
//
//  Created by Sayan on 21/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "MessageBox.h"

@implementation MessageBox

- (id)initWithSuperview:(UIView *)superview hasNavigationBar:(BOOL)navbar
{
    int cutOffNavBarHeight = 0;
    if(navbar) cutOffNavBarHeight = 44;
    CGFloat yLabelViewOffset = superview.bounds.size.height-cutOffNavBarHeight-30;
    self = [super initWithFrame:CGRectMake(0, yLabelViewOffset, superview.bounds.size.width, 30)];
    if (self) {
        // Initialization code
        // Message Label for showing confirmation and status messages
        
        self.backgroundColor = [UIColor lightGrayColor];
        isNavBar = navbar;
        UIView *messageInsetView = [[UIView alloc] initWithFrame:CGRectMake(1, 1, superview.bounds.size.width-1, 28)];
        messageInsetView.backgroundColor = [UIColor colorWithRed:255.0/255.0
                                                           green:248.0/255.0
                                                            blue:228.0/255.0
                                                           alpha:1];
        messageLabel = [[UILabel alloc]
                        initWithFrame:CGRectMake(4, 1, superview.bounds.size.width-10, 26)];
        messageLabel.text = @"";
        messageLabel.font = [UIFont fontWithName:@"Helvetica" size:14.0];
        messageLabel.backgroundColor = [UIColor colorWithRed:255.0/255.0
                                                       green:248.0/255.0
                                                        blue:228.0/255.0
                                                       alpha:0.6];
        [messageInsetView addSubview:messageLabel];
        [self addSubview:messageInsetView];
        [messageInsetView release];
        self.hidden = YES;
        [superview addSubview:self];
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (void)showMessage:(NSString *)message {
    int cutoffHeight = 0;
    if (isNavBar) {
        cutoffHeight = 44;
    }
    CGRect labelFrame = self.frame;
    labelFrame.origin.y = [UIScreen mainScreen].bounds.size.height - cutoffHeight - 20;
    self.frame = labelFrame;
    messageLabel.text = message;
    self.hidden = NO;
    
    // Use animation to show the message from the bottom then
    // hide it.
    [UIView animateWithDuration:0.5
                          delay:0.5
                        options: UIViewAnimationCurveEaseOut
                     animations:^{
                         CGRect labelFrame = self.frame;
                         labelFrame.origin.y -= labelFrame.size.height;
                         self.frame = labelFrame;
                     }
                     completion:^(BOOL finished){
                         if (finished) {
                             [UIView animateWithDuration:0.5
                                                   delay:3.0
                                                 options: UIViewAnimationCurveEaseOut
                                              animations:^{
                                                  CGRect labelFrame = self.frame;
                                                  labelFrame.origin.y += self.frame.size.height;
                                                  self.frame = labelFrame;
                                              }
                                              completion:^(BOOL finished){
                                                  if (finished) {
                                                      self.hidden = YES;
                                                      messageLabel.text = @"";
                                                  }
                                              }];
                         }
                     }];
}

/*
 * This method hides the message, only needed if view closed
 * and animation still going on.
 */
- (void)hideMessage {
    self.hidden = YES;
    messageLabel.text = @"";
}


@end
