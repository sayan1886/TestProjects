//
//  PDFReaderContentPage.h
//  TestPDF
//
//  Created by SMB on 10/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

enum PDFDocumentLinkType{
    PDFDocumentLinkTypeNavigationLocal = 0,
    PDFDocumentLinkTypeNavigationRemote = 1,
    PDFDocumentLinkTypeMultimediaAudioLocal = 2,
    PDFDocumentLinkTypeMultimediaAudioRemote = 3,
    PDFDocumentLinkTypeMultimediaVideoLocal = 4,
    PDFDocumentLinkTypeMultimediaVideoRemote = 5,
    PDFDocumentLinkTypeNone = 6
};

typedef NSUInteger PDFDocumentLinkType;

@class PDFReaderContentPage;

@protocol PDFLink <NSObject>

@optional
- (void) documentHasLinks:(NSUInteger)numberOfLinks;
- (void) documentHasLink:(PDFDocumentLinkType)link andURL:(NSURL *)url atRect:(CGRect)rect;
- (void) documentRecivedDoubleTapAtRect:(CGRect)rect forLinkType:(PDFDocumentLinkType)link withURL:(NSURL *)url;

@end

@interface PDFReaderContentPage : UIView {
@private // Instance variables
	
	NSMutableArray *_links;
	
	CGPDFDocumentRef _PDFDocRef;
	
	CGPDFPageRef _PDFPageRef;
	
	NSInteger _pageAngle;
	
	CGSize _pageSize;
	
	id<PDFLink> delegate;
	
	NSMutableArray *movieControllers;
	
}
@property (nonatomic,assign) id<PDFLink> delegate;
- (id)initWithURL:(NSURL *)fileURL page:(NSInteger)page password:(NSString *)phrase;

- (id)singleTap:(UITapGestureRecognizer *)recognizer;
//SMB: Added
-(void)parseLinksAndDrawContents:(NSURL*)urlLink withRect:(CGRect)rect;

- (void)buildAnnotationLinksList;
- (id)findLinkTarget:(CGPDFDictionaryRef)annotationDictionary;
//- (NSArray *) checkAndEditLinkForMultimedia:(NSString *)uri;

@end

#pragma mark -

//
//	PDFReaderDocumentLink class interface
//

@interface PDFReaderDocumentLink : NSObject
{
@private // Instance variables
	
	CGPDFDictionaryRef _dictionary;
	
	CGRect _rect;
}

@property (nonatomic, assign, readonly) CGRect rect;

@property (nonatomic, assign, readonly) CGPDFDictionaryRef dictionary;

+ (id)withRect:(CGRect)linkRect dictionary:(CGPDFDictionaryRef)linkDictionary;

- (id)initWithRect:(CGRect)linkRect dictionary:(CGPDFDictionaryRef)linkDictionary;

@end

