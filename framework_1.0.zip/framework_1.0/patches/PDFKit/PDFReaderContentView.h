//
//  PDFReaderContentView.h
//  TestPDF
//
//  Created by SMB on 10/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import "PDFReaderContentPage.h"

@class PDFReaderContentView;

@protocol PDFReaderContentViewDelegate <NSObject>

@required // Delegate protocols

- (void)contentView:(PDFReaderContentView *)contentView touchesBegan:(NSSet *)touches;

- (void)setPageZoomScale:(CGFloat)zoom;
- (CGFloat)getPageZoomScale;

@end


@interface PDFReaderContentView : UIScrollView <UIScrollViewDelegate>
{
@private // Instance variables
	
	PDFReaderContentPage *theContentView;
	
	//ReaderContentThumb *theThumbView;
	
	UIView *theContainerView;
	
	
}

@property (nonatomic, assign, readwrite) id <PDFReaderContentViewDelegate> message;

- (id)initWithFrame:(CGRect)frame fileURL:(NSURL *)fileURL page:(NSUInteger)page password:(NSString *)phrase;

- (void)showPageThumb:(NSURL *)fileURL page:(NSInteger)page password:(NSString *)phrase guid:(NSString *)guid;

- (id)singleTap:(UITapGestureRecognizer *)recognizer;

- (void)zoomIncrement;
- (void)zoomDecrement;
- (void)zoomReset;

@end

#pragma mark -
/*
//
//	ReaderContentThumb class interface
//

@interface PDFReaderContentThumb : ReaderThumbView
{
@private // Instance variables
}

@end
*/