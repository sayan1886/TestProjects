    //
//  SMBMediaPlayer.m
//  SMBPDFKit
//
//  Created by SMB on 24/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "SMBMediaPlayer.h"
#import "UIImage+Resizing.h"
#import "PlayerConfig.h"


@implementation SMBMediaPlayer
@synthesize delegate;
@synthesize tag;

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/

-(id)initWithFrame:(CGRect)frame urlString:(NSString*)urlString isLocal:(BOOL)local {
	
	if (self = [super init]) {
		_local = local;
		if (_local) {
			mediaURL = [[NSURL alloc] initFileURLWithPath:urlString];
		}
		else {
			mediaURL = [[NSURL alloc] initWithString:urlString];
		}
		mediaFrame = frame;
		tag = 0; //initiate with tag 0
	}
	
	return self;
	
}

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];

	
	self.view.frame = mediaFrame;
	self.view.backgroundColor = [UIColor blackColor];
	
	[self showPlayButton];
	
	//Notification for MediaPlayer
	[[NSNotificationCenter defaultCenter] addObserver:self 
											 selector:@selector(moviePlayBackDidFinish:) 
												 name:MPMoviePlayerPlaybackDidFinishNotification 
											   object:nil];
	
	[[NSNotificationCenter defaultCenter] addObserver:self 
											 selector:@selector(moviePlayBackStateChange:) 
												 name:MPMoviePlayerPlaybackStateDidChangeNotification
											   object:nil];
	
	[[NSNotificationCenter defaultCenter] addObserver:self 
											 selector:@selector(movieLoadStateDidChange:) 
												 name:MPMoviePlayerLoadStateDidChangeNotification
											   object:nil];
	
	
	//NOtification for player stop
	
	[[NSNotificationCenter defaultCenter] addObserver:self 
											 selector:@selector(stopCurrentPlayer:) 
												 name:SMB_PLAYER_STOP_NOTIFICATION
											   object:nil];
	
	
}

-(void)showPlayButton {
	
	CGFloat smallerLength = (self.view.frame.size.width>self.view.frame.size.height)?self.view.frame.size.height:self.view.frame.size.width;
	CGFloat butWidth = smallerLength/2;
	
	playBut = [UIButton buttonWithType:UIButtonTypeCustom];
	playBut.tag=self.tag;
	playBut.frame = CGRectMake((self.view.frame.size.width-butWidth)/2, (self.view.frame.size.height-butWidth)/2, butWidth, butWidth);
	[playBut setImage:[UIImage imageOfSize:CGSizeMake(butWidth, butWidth) fromImage:[UIImage imageNamed:@"play2.png"]] forState:UIControlStateNormal];
	[playBut addTarget:self action:@selector(playButtonAction:) forControlEvents:UIControlEventTouchUpInside];
	[self.view addSubview:playBut];
	
	
}

-(void)removePlayButton {
	
	if (playBut) {
		[playBut removeFromSuperview];
		playBut=nil;
	}
	
}


-(void)showLoadingLabel {
	
	label = [[UILabel alloc] initWithFrame:self.view.bounds];
	[label setBackgroundColor:[UIColor clearColor]];
	[label setTag:self.tag];
	[label setText:@"Loading..."];
	[label setFont:[UIFont systemFontOfSize:16]];
	[label setTextAlignment:UITextAlignmentCenter];
	[label setTextColor:[UIColor whiteColor]];
	[self.view addSubview:label];
	
}

-(void)removeLoadingLabel {
	
	if (label!=nil) {
		
		[label removeFromSuperview];
		[label release];
		label=nil;
	}
	
	
}

-(void)initializeMediaPlayer {
	moviePlayer = [[MPMoviePlayerController alloc] init];
    NSLog(@"MEDIA URL : %@",[mediaURL absoluteString]);
	[moviePlayer setContentURL:mediaURL];
	[moviePlayer.view setFrame:self.view.bounds];
	[moviePlayer.view setBackgroundColor:[UIColor clearColor]];
	moviePlayer.controlStyle = MPMovieControlStyleEmbedded;
	moviePlayer.shouldAutoplay = YES;
	moviePlayer.view.tag = self.tag;
	[self.view addSubview:moviePlayer.view];
	
}

-(void)playButtonAction:(UIButton*)but {
	
	[self removePlayButton];
	
	[self showLoadingLabel];
	
	[self initializeMediaPlayer];
	
}



#pragma mark -
#pragma mark Notification Handling

-(void)moviePlayBackDidFinish:(NSNotification*)notification {
	
	if ([delegate respondsToSelector:@selector(playbackDidFinishInMediaPlayer:)]) {
		[delegate playbackDidFinishInMediaPlayer:self];
	}
	
}

-(void)moviePlayBackStateChange:(NSNotification*)notification {
	if (_local) {
		[self removeLoadingLabel];
	}
	
	
}

-(void)movieLoadStateDidChange:(NSNotification*)notification {
	
	MPMoviePlayerController *mpPlayer = ((MPMoviePlayerController*)[notification object]);
	
	switch (mpPlayer.loadState) {
		case MPMovieLoadStateUnknown:
			NSLog(@"player Load state:unknown");
			break;
		case MPMovieLoadStatePlayable:
			NSLog(@"player Load state:playable");
			[self removeLoadingLabel];
			break;
		case MPMovieLoadStatePlaythroughOK:
			NSLog(@"player Load state:throughOK");
			break;
		case MPMovieLoadStateStalled:
			NSLog(@"player Load state:Stalled");
			break;
		default:
			break;
	}
	
}


-(void)stopCurrentPlayer:(NSNotification*)notification {
	NSLog(@"Stoping Player");
	if (moviePlayer) {
		[moviePlayer stop];
		[moviePlayer release];
		moviePlayer = nil;
	}
	
		[self removeLoadingLabel];
	
	if (playBut==nil) {
		[self showPlayButton];
	}
}

#pragma mark -
#pragma mark Rotation Support

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return YES;
}

#pragma mark -
#pragma mark Memory management

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
	[mediaURL release];
	
	if (moviePlayer) {
		[moviePlayer stop];
		[moviePlayer release];
		moviePlayer = nil;
	}
	
	
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[mediaURL release];
	
	if (moviePlayer) {
		[moviePlayer stop];
		[moviePlayer release];
		moviePlayer = nil;
	}
	
	
	NSNotificationCenter *notificationCenter = [NSNotificationCenter defaultCenter];
	[notificationCenter removeObserver:self name:MPMoviePlayerPlaybackDidFinishNotification object:nil];
	[notificationCenter removeObserver:self name:MPMoviePlayerPlaybackStateDidChangeNotification object:nil];
	[notificationCenter removeObserver:self name:MPMoviePlayerLoadStateDidChangeNotification object:nil];
	[notificationCenter removeObserver:self name:SMB_PLAYER_STOP_NOTIFICATION object:nil];
	
    [super dealloc];
}


@end
