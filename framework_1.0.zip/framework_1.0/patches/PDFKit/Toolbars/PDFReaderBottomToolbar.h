//
//  PDFReaderbottomToolbar.h
//  SMBPDFKit
//
//  Created by SMB on 10/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PDFDocument.h"
#import "UIXBottomToolbarView.h"

@class PDFReaderBottomToolbar;


@protocol PDFReaderBottomToolbarDelegate <NSObject>

@required // Delegate protocols
- (void)bottombar:(PDFReaderBottomToolbar *)bottombar gotoPage:(NSInteger)page;
@end

@interface PDFReaderBottomToolbar : UIXBottomToolbarView {
@private // Instance variables
	
	int numOfPages;
	
	UISlider *slider;
}

@property (nonatomic, assign, readwrite) id <PDFReaderBottomToolbarDelegate> delegate;

- (id)initWithFrame:(CGRect)frame document:(PDFDocument *)object;

- (void)hideToolbar;
- (void)showToolbar;
- (void)leftButtonTapped:(UIButton*)but;
- (void)rightButtonTapped:(UIButton*)but;
- (void)sliderValueChange:(UISlider*)sld;
- (void)setSliderValue:(int)val;

@end
