//
//  PDFReaderbottomToolbar.m
//  SMBPDFKit
//
//  Created by SMB on 10/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "PDFReaderBottomToolbar.h"
#import <QuartzCore/QuartzCore.h>
#import "PDFReaderConfig.h"

@implementation PDFReaderBottomToolbar

#pragma mark Constants

#define LEFT_GAP 8.0f
#define RIGHT_GAP 8.0f
#define LEFT_RIGHT_BUTTON_WIDTH 25.0f

#define BUTTON_X 8.0f
#define BUTTON_Y 8.0f
#define BUTTON_SPACE 8.0f
#define BUTTON_HEIGHT 30.0f

#pragma mark Properties

@synthesize delegate;

#pragma mark PDFReaderBottomToolbar instance methods

- (id)initWithFrame:(CGRect)frame
{
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif
	
	return [self initWithFrame:frame document:nil];
}

- (id)initWithFrame:(CGRect)frame document:(PDFDocument *)object
{
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif
	
	assert(object != nil); // Check
	
	if ((self = [super initWithFrame:frame]))
	{
		
		numOfPages = [[object pageCount] intValue];
		
		CGFloat viewWidth = self.bounds.size.width;
		
		UIImage *imageH = [UIImage imageNamed:@"Reader-Button-H.png"];
		UIImage *imageN = [UIImage imageNamed:@"Reader-Button-N.png"];
		
		UIImage *buttonH = [imageH stretchableImageWithLeftCapWidth:5 topCapHeight:0];
		UIImage *buttonN = [imageN stretchableImageWithLeftCapWidth:5 topCapHeight:0];
		
		
		
		UIButton *butLeft = [UIButton buttonWithType:UIButtonTypeCustom];
		butLeft.frame = CGRectMake(LEFT_GAP, BUTTON_Y, LEFT_RIGHT_BUTTON_WIDTH, BUTTON_HEIGHT);
		[butLeft setTitle:@"◀" forState:UIControlStateNormal];
		[butLeft setTitleColor:[UIColor colorWithWhite:0.0f alpha:1.0f] forState:UIControlStateNormal];
		[butLeft setTitleColor:[UIColor colorWithWhite:1.0f alpha:1.0f] forState:UIControlStateHighlighted];
		[butLeft addTarget:self action:@selector(leftButtonTapped:) forControlEvents:UIControlEventTouchUpInside];
		[butLeft setBackgroundImage:buttonH forState:UIControlStateHighlighted];
		[butLeft setBackgroundImage:buttonN forState:UIControlStateNormal];
		butLeft.titleLabel.font = [UIFont systemFontOfSize:14.0f];
		butLeft.autoresizingMask = UIViewAutoresizingNone;
		[self addSubview:butLeft];
		
		//Slider
		slider = [[UISlider alloc] init];
		slider.frame = CGRectMake(LEFT_GAP+LEFT_RIGHT_BUTTON_WIDTH+BUTTON_SPACE, BUTTON_Y, viewWidth-LEFT_GAP-RIGHT_GAP-(2*LEFT_RIGHT_BUTTON_WIDTH)-(2*BUTTON_SPACE), BUTTON_HEIGHT);
		slider.autoresizingMask = UIViewAutoresizingFlexibleWidth;
		slider.minimumValue = 1;
		slider.maximumValue = numOfPages;
		slider.continuous = NO;
		slider.backgroundColor = [UIColor clearColor];
		[slider addTarget:self action:@selector(sliderValueChange:) forControlEvents:UIControlEventValueChanged];
		[self addSubview:slider];	
		
		
		UIButton *butRight = [UIButton buttonWithType:UIButtonTypeCustom];
		butRight.frame = CGRectMake(viewWidth-RIGHT_GAP-LEFT_RIGHT_BUTTON_WIDTH, BUTTON_Y, LEFT_RIGHT_BUTTON_WIDTH, BUTTON_HEIGHT);
		[butRight setTitle:@"▶" forState:UIControlStateNormal];
		[butRight setTitleColor:[UIColor colorWithWhite:0.0f alpha:1.0f] forState:UIControlStateNormal];
		[butRight setTitleColor:[UIColor colorWithWhite:1.0f alpha:1.0f] forState:UIControlStateHighlighted];
		[butRight addTarget:self action:@selector(rightButtonTapped:) forControlEvents:UIControlEventTouchUpInside];
		[butRight setBackgroundImage:buttonH forState:UIControlStateHighlighted];
		[butRight setBackgroundImage:buttonN forState:UIControlStateNormal];
		butRight.titleLabel.font = [UIFont systemFontOfSize:14.0f];
		butRight.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
		[self addSubview:butRight];	
	}
	
	return self;
}

- (void)dealloc
{
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif
	[slider release];
	slider = nil;
	
	[super dealloc];
}


- (void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag {
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif
	self.hidden = YES;
}

- (void)hideToolbar
{
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif
	
	if (self.hidden == NO)
	{
		//TODO
		//for iOS version less than 4.0
		[UIView beginAnimations:nil context:nil];
		[UIView setAnimationDuration:0.25];
		[UIView setAnimationDelay:0.0];
		[UIView setAnimationDelegate:self];
		[UIView setAnimationCurve:UIViewAnimationCurveEaseOut];
		self.alpha = 0.0f;
		[UIView commitAnimations];
		
		//iOS 4+
		/*[UIView animateWithDuration:0.25 delay:0.0 options:UIViewAnimationOptionCurveLinear | UIViewAnimationOptionAllowUserInteraction
		 animations:^(void)
		 {
		 self.alpha = 0.0f;
		 }
		 completion:^(BOOL finished)
		 {
		 self.hidden = YES;
		 }
		 ];*/
		
	}
}

- (void)showToolbar
{
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif
	
	if (self.hidden == YES)
	{
		
		//TODO
		//for iOS version less than 4.0
		[UIView beginAnimations:nil context:nil];
		[UIView setAnimationDuration:0.25];
		[UIView setAnimationDelay:0.0];
		[UIView setAnimationCurve:UIViewAnimationCurveEaseIn];
		self.hidden = NO;
		self.alpha = 1.0f;
		[UIView commitAnimations];
		
		
		//iOS 4+
		/*[UIView animateWithDuration:0.25 delay:0.0
		 options:UIViewAnimationOptionCurveLinear | UIViewAnimationOptionAllowUserInteraction
		 animations:^(void)
		 {
		 self.hidden = NO;
		 self.alpha = 1.0f;
		 }
		 completion:NULL
		 ];*/
	}
}

#pragma mark UIButton action methods

-(void)leftButtonTapped:(UIButton*)but {
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif
	[slider setValue:1 animated:YES];
	[delegate bottombar:self gotoPage:1];
}

-(void)rightButtonTapped:(UIButton*)but {
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif
	[slider setValue:numOfPages animated:YES];
	[delegate bottombar:self gotoPage:numOfPages];
}

-(void)sliderValueChange:(UISlider*)sld {
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif
	
	[delegate bottombar:self gotoPage:floor(sld.value)];
	
}

- (void)setSliderValue:(int)val {
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif
	if (slider.state==UIControlStateNormal) {
		[slider setValue:val animated:NO];
	}
	
}

@end
