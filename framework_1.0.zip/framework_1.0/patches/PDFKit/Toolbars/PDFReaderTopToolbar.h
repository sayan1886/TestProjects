//
//  PDFReaderTopToolbar.h
//  SMBPDFKit
//
//  Created by SMB on 10/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PDFDocument.h"
#import "UIXToolbarView.h"

@class PDFReaderTopToolbar;


@protocol PDFReaderTopToolbarDelegate <NSObject>

@required // Delegate protocols

- (void)tappedInToolbar:(PDFReaderTopToolbar *)toolbar doneButton:(UIButton *)button;
- (void)tappedInToolbar:(PDFReaderTopToolbar *)toolbar thumbsButton:(UIButton *)button;
- (void)tappedInToolbar:(PDFReaderTopToolbar *)toolbar printButton:(UIButton *)button;
- (void)tappedInToolbar:(PDFReaderTopToolbar *)toolbar emailButton:(UIButton *)button;
- (void)tappedInToolbar:(PDFReaderTopToolbar *)toolbar markButton:(UIButton *)button;
@optional
- (void) movePopOverToButtonLocation:(UIButton *)button;
@end

@interface PDFReaderTopToolbar : UIXToolbarView {
@private // Instance variables
	
	UIButton *markButton;
	UIImage *markImageN;
	UIImage *markImageY;
}

@property (nonatomic, retain, readwrite) NSObject <PDFReaderTopToolbarDelegate> *delegate;

- (id)initWithFrame:(CGRect)frame document:(PDFDocument *)object;

- (void)setBookmarkState:(BOOL)state;

- (void)hideToolbar;
- (void)showToolbar;

@end
