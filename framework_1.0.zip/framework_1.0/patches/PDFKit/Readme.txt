Requires iOS 4.0 and above

-(void)openReader:(NSString*)path {
	
	NSString *password = nil; // Document password (for unlocking most encrypted PDF files)
	
	
	PDFDocument *document = [[[PDFDocument alloc] initWithFilePath:path password:password] autorelease];
	
	
	if (document != nil) // Must have a valid ReaderDocument object in order to proceed
	{
		PDFReaderViewController *readerViewController = [[PDFReaderViewController alloc] initWithPDFDocument:document];
		
		readerViewController.delegate = self;
        
		[self.navigationController pushViewController:readerViewController animated:YES];
		
		[readerViewController release];
	}
	
	
}
