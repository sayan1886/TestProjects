//
//  GMBookMarkViewController.h
//  GenaMagazine
//
//  Created by Sayan on 09/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GMBookMarkViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>{
    NSMutableArray *addedBookmark;
    id actionTarget;
    BOOL flag;
}

@property (nonatomic,retain) NSMutableArray *addedBookmark;
@property (nonatomic,assign) id actionTarget;

- (id)initWithBookMarkDetails:(NSMutableArray *)bookmarkDetails andTaget:(id) target;
@end
