//
//  GMBookMarkViewController.m
//  GenaMagazine
//
//  Created by Sayan on 09/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "GMBookMarkViewController.h"
#import "PDFReaderViewController.h"

@interface GMBookMarkViewController ()

@end

@implementation GMBookMarkViewController

@synthesize addedBookmark;
@synthesize actionTarget;

- (id)initWithBookMarkDetails:(NSMutableArray *)bookmarkDetails andTaget:(id) target
{
    self = [super init ];
    if (self) {
        // Custom initialization
        self.addedBookmark = bookmarkDetails;
        self.actionTarget = target;
    }
    return self;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    flag = YES;
    UIButton *bookamrkButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    bookamrkButton.frame = CGRectMake((self.view.frame.size.width - 170) / 2, 10, 150, 50);
    [bookamrkButton addTarget:actionTarget action:@selector(addBookmark:) forControlEvents:UIControlEventTouchUpInside];
    [bookamrkButton setTitle:@"Add Bookmark" forState:UIControlStateNormal];
    bookamrkButton.autoresizesSubviews = YES;
    bookamrkButton.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    [self.view addSubview:bookamrkButton];
    
    UITableView *bookmarks = [[UITableView alloc] initWithFrame:CGRectMake((self.view.frame.size.width - 320) / 2, 70, 320, 320) style:UITableViewStyleGrouped];
    bookmarks.backgroundColor = [UIColor clearColor];
    bookmarks.dataSource = self;
    bookmarks.delegate = self;
    bookmarks.separatorColor = [UIColor clearColor];
    bookmarks.autoresizesSubviews = YES;
    [bookmarks setBackgroundView:nil];
    bookmarks.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    if ([addedBookmark count] > 0) {
        [self.view addSubview:bookmarks];
    }
    [bookmarks release];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
//    if (flag) {
//        int i = 1;
//        for (UIView *subview in [tableView subviews]) {
//            NSLog(@"%d",i++);
//        }
//        flag = NO;
//    }
    
    return [addedBookmark count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellIdentifier = @"cell";
    static NSString *nilCellIdentifier = @"nil";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
	if (cell == nil) {
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nilCellIdentifier] autorelease];
		cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
		cell.selectionStyle = UITableViewCellSelectionStyleBlue;
	}
    else{
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
		cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
		cell.selectionStyle = UITableViewCellSelectionStyleBlue;
    }
    cell.textLabel.text = [[addedBookmark objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
    //cell.textLabel.textColor = [UIColor whiteColor];
    //cell.backgroundColor = [UIColor whiteColor];
    return cell;
}


#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    int page = [[[addedBookmark objectAtIndex:indexPath.section]objectAtIndex:indexPath.row + 1]intValue];
    //NSLog(@"Page : %d",page);
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    [(PDFReaderViewController *)actionTarget navigateToBookmark:page];
}

#pragma mark - Memory

- (void) dealloc{
    self.addedBookmark = nil;
    [super dealloc];
}


@end
