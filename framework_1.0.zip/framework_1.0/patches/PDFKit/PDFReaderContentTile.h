//
//  PDFReaderContentTile.h
//  TestPDF
//
//  Created by SMB on 10/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>


@interface PDFReaderContentTile : CATiledLayer {
@private // Instance variables
}

@end
