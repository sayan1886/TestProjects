//
//	UIXToolbarView.h
//	

#import <UIKit/UIKit.h>

@interface UIXToolbarView : UIView
{
@private // Instance variables
}

@end

#pragma mark -

//
//	UIXToolbarShadow class interface
//

@interface UIXToolbarShadow : UIView
{
@private // Instance variables
}

@end
