//
//  TestIAPHelper.m
//  TestInAppPurchase
//
//  Created by ASHIM SAMANTA on 09/02/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import "TestIAPHelper.h"


@implementation TestIAPHelper

static TestIAPHelper * _sharedHelper;

+ (TestIAPHelper *) sharedHelper 
{
    if (_sharedHelper != nil) 
	{
        return _sharedHelper;
    }
    _sharedHelper = [[TestIAPHelper alloc] init];
    return _sharedHelper;
}

- (id)init 
{
    NSSet *productIdentifiers = [NSSet setWithObjects:/*@"PRO1", @"Mode1",*/@"autoren",/*@"nonren"*/nil];
								 	
    if ((self = [super initWithProductIdentifiers:productIdentifiers])) {
    }
    return self;
}

@end
