//
//  IAPHelper.h
//  TestInAppPurchase
//
//  Created by ASHIM SAMANTA on 09/02/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <StoreKit/StoreKit.h>

#define kProductsLoadedNotification         @"ProductsLoaded"
#define kProductPurchasedNotification       @"ProductPurchased"
#define kProductPurchaseFailedNotification  @"ProductPurchaseFailed"
#define kSharedSecret						  @"bea12eb07dd843b79eb76a5c905a33fd"	

//Observer for InApp

@protocol InAppObserver <NSObject>
@optional
- (void) userHasPurchasedProductWithTransaction:(SKPaymentTransaction *)transaction;
- (void) useHasSubscribedWithTransaction:(SKPaymentTransaction *)transaction;
- (void) TransactionFailed:(SKPaymentTransaction *)transaction;
@end

@interface IAPHelper : NSObject <SKProductsRequestDelegate, SKPaymentTransactionObserver> 
{
	NSSet * _productIdentifiers;    
    NSArray * _products;
    NSMutableSet * _purchasedProducts;
    SKProductsRequest * _request;
    
    id<InAppObserver> observer;
}

@property (retain) NSSet *productIdentifiers;
@property (retain) NSArray * products;
@property (retain) NSMutableSet *purchasedProducts;
@property (retain) SKProductsRequest *request;

@property (nonatomic,assign) id<InAppObserver> observer;

- (void)requestProducts;
- (id)initWithProductIdentifiers:(NSSet *)productIdentifiers;
- (void)buyProductIdentifier:(NSString *)productIdentifier;

@end



