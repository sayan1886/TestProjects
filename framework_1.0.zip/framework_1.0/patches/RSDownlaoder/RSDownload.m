//
//  RSDownload.m
//  RickSteves_AudioEurope
//
//  Created by Paul Neiland on 10/5/10.
//  Copyright 2010 Treemo Labs. All rights reserved.
//

#import "RSDownload.h"
#import "RSDownloadManager.h"
#import "RSDownloadManager+QueueControl.h"
#import "RSUtils.h"

@interface RSDownload()
-(void)waitForNetworkReconnection;
-(void)retryAfterTimeout;
@end

@implementation RSDownload

#pragma mark -
#pragma mark Property methods and synthesis

@synthesize size;
@synthesize url;
@synthesize title;
@synthesize saveDir;
@synthesize bytesDownloaded;
@synthesize filename;
@synthesize ID;
@synthesize progressValue;
@synthesize played;
@synthesize playDuration;
#pragma mark -
#pragma mark Property setters and getters

-(NSString*)filepath {
    NSString *filedir = [NSString stringWithFormat:@"%@/%@", [RSUtils podcastDir], self.saveDir];
    NSString *filepath = [NSString stringWithFormat:@"%@/%@", filedir, self.filename];
    
    return filepath;
}

-(UIProgressView *)progressBar {
    return progressBar;
}

-(void)setProgressBar:(UIProgressView *)newBar {
    double progress;
    BOOL oldProgress = NO;
    
    if(progressBar) {
        oldProgress = YES;
        progress = progressBar.progress;
    }
    
    [progressBar autorelease];
    progressBar = newBar;
    [progressBar retain];
    
    if(oldProgress) {
        progressBar.progress = progress;
    }
}

-(UILabel *)progressValue {
    return progressValue;
}

-(void)setProgressValue:(UILabel *)newValue {
    NSString *text;
    BOOL oldText = NO;
    
    if(progressValue) {
        oldText = YES;
        text = progressValue.text;
    }
    
    [progressValue autorelease];
    progressValue = newValue;
    [progressValue retain];
    
    if(oldText) {
        progressValue.text = text;
    }
}
    

#pragma mark -
#pragma mark Instance Methods

-(id) init {
    if((self = [super init])) {
    }
    return self;
}

//Queue the download onto the download manager
-(void)enqueue {
    [RSDownloadManager queueDownload:self];
}

-(NSString *)description
{
	if(self)
	{
		return [NSString stringWithFormat:@"{size=%d,url=%@,title=%@,dir=%@,filename=%@, id=%@, duration=%@} \n\n", 
		 size,url,title,saveDir,filename,ID,playDuration];
		
	}
	else {
		return nil;
	}

}


//Cancel the download and delete any of its stored data
-(void)destroy {
    /*
    if(!conn) {
        return;
    }
     */
    
    [conn cancel];
    [conn release];
    conn = nil;
    
    [[NSFileManager defaultManager] removeItemAtPath:self.filepath error:NULL];
    
    [RSDownloadManager destroyDownload:self];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:RSDownloadCancelledNotification object:self];
}

//Pause the download, keeping any stored data
-(void)pause {
   /* if(!conn) {
        return;
    }
    */
	
    [conn cancel];
    [conn release];
    conn = nil;
       
    [RSDownloadManager pauseDownload:self];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:RSDownloadPausedNotification object:self];
}

-(void)resume{
    [RSDownloadManager resumeDownload:self];
}

-(void)restart {
    [RSDownloadManager restartDownload:self];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:RSDownloadRestartNotification object:self];
}

#pragma mark -
#pragma mark Network condition change recovery methods

-(void)waitForNetworkReconnection {
    [RSDownloadManager waitForNetworkReconnection];
    
    [conn release];
    conn = nil;
}

-(void)retryAfterTimeout {
    [RSDownloadManager retryAfterTimeout];
    
    [conn release];
    conn = nil;
}

#pragma mark -
#pragma mark Class Methods

+(RSDownload*)downloadForID:(NSString*)_ID {
    //Check to see if there's already a download for that url and if so, return it
    NSArray *dloads = [self allQueuedDownloads];
    for(RSDownload *dl in dloads) {
        if([dl.ID isEqualToString:_ID]) {
            return [[dl retain] autorelease];
        }
    }
    
    dloads = [RSDownloadManager allPausedDownloads];
    for(RSDownload *dl in dloads) {
        if([dl.ID isEqualToString:_ID]) {
            return [[dl retain] autorelease];
        }
    }
    
    dloads = [RSDownloadManager allCompleteDownloads];
    for(RSDownload *dl in dloads) {
        if([dl.ID isEqualToString:_ID]) {
            return [[dl retain] autorelease];
        }
    }
    
    RSDownload *dload = [[RSDownload alloc] init];
    dload.ID = _ID;
    
    return [dload autorelease];
}

+(NSArray*)allQueuedDownloads {
    return [RSDownloadManager allQueuedDownloads];
}

#pragma mark -
#pragma mark NSURLConnection delegate methods

-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    [[NSNotificationCenter defaultCenter] postNotificationName:RSDownloadConnectionRestoredNotification object:self userInfo:nil];
    NSLog(@"%@: didReceiveResponse called", [self ID]);
    
    //Set the connection pointer
    [conn release];
    conn = [connection retain];
    
    //Verify that the file being sent is of the correct type... video is here just in case that is added in the future
    if(!([[response MIMEType] hasPrefix:@"audio"] || 
         [[response MIMEType] hasPrefix:@"video"] ||
         [[response MIMEType] hasPrefix:@"application"])) {
        NSLog(@"Wrong file type returned by server!! Failing download.");
        [conn cancel];
        [self connection:connection didFailWithError:nil];
    }
    
    //Set the file size if this is a fresh download
    if(self.bytesDownloaded == 0) {
        size = [response expectedContentLength];
    }
    
    //Set the name that the file will be
    self.filename = [response suggestedFilename];
    
    if(self.bytesDownloaded > 0) {
        self.progressBar.progress = (float)self.bytesDownloaded / (float)self.size;
		self.progressValue.text=[NSString stringWithFormat:@"%0.2f%%",(self.progressBar.progress*100.0f)];
    } else {
        //Remove any old copies of the file if this is a new file and create a file
        [[NSFileManager defaultManager] createDirectoryAtPath:[NSString stringWithFormat:@"%@/%@", [RSUtils podcastDir], self.saveDir]
                                  withIntermediateDirectories:YES
                                                   attributes:nil
                                                        error:NULL];
        BOOL fileMade = [[NSFileManager defaultManager] createFileAtPath:self.filepath contents:[NSData data] attributes:nil];
        self.progressBar.progress = 0;
		self.progressValue.text=@"0.0%%";
    }
    
    //Open up the file
    [fileHandle release];
    fileHandle = [[NSFileHandle fileHandleForUpdatingAtPath:self.filepath] retain];
    [fileHandle seekToEndOfFile];
}

-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    //NSLog(@"%@: didReceiveData called", [self ID]);
    //Append the data received and set the progress bar's lenght appropriately
    //NSLog(@"Download %@ received data", self.ID);
    [fileHandle writeData:data];
    bytesDownloaded += [data length];
    self.progressBar.progress = self.bytesDownloaded / (float)self.size;
	self.progressValue.text=[NSString stringWithFormat:@"%0.2f%%",(self.progressBar.progress*100.0f)];
}

-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    NSLog(@"%@: didFailWithError called", [self ID]);
    
    NSFileHandle *logFile = [NSFileHandle fileHandleForUpdatingAtPath:[NSString stringWithFormat:@"%@/%@", [RSUtils podcastDir], @"errorlog.txt"]];
    [logFile seekToEndOfFile];
    
    [logFile writeData:[[error description] dataUsingEncoding:NSUTF8StringEncoding]];
    [logFile writeData:[@"\n" dataUsingEncoding:NSUTF8StringEncoding]];
    
    [logFile writeData:[[NSString stringWithFormat:@"****** Error code was %i\n", [error code]] dataUsingEncoding:NSUTF8StringEncoding]];
    
    [conn release];
    conn = nil;
    
    switch ([error code]) {
        //If we got a connection offline message, delay the download to be resumed later
        case -1009:
            [[NSNotificationCenter defaultCenter] postNotificationName:RSDownloadConnectionInterruptedNotifiaction object:self];
            [self waitForNetworkReconnection];
            break;
        //Try again in a little bit if:
        //If we get a timeout or hostname not found (-1001 and -1003)
        //The connection is lost (-1005)
        //A phone call is active on a network that doesn't support both phone calls and data (-1019)
        case -1001:
        case -1003:
        case -1005:
        case -1019:
            [[NSFileManager defaultManager] createFileAtPath:[NSString stringWithFormat:@"%@/%@", [RSUtils podcastDir], @"interrupt.txt"] contents:[NSData data] attributes:nil];
            [[NSNotificationCenter defaultCenter] postNotificationName:RSDownloadConnectionInterruptedNotifiaction object:self];
            [self retryAfterTimeout];
            break;
        default:
            [RSDownloadManager downloadFailed:self];
            [fileHandle release];
            fileHandle = nil;
            bytesDownloaded = 0;
            [[NSFileManager defaultManager] createFileAtPath:[NSString stringWithFormat:@"%@/%@", [RSUtils podcastDir], @"failed.txt"] contents:[NSData data] attributes:nil];
            [[NSNotificationCenter defaultCenter] postNotificationName:RSDownloadFailedNotification object:self];
            break;
    }
}

-(void)connectionDidFinishLoading:(NSURLConnection *)connection 
{
    NSLog(@"%@: didFinishLoading called", [self ID]);
	//NSString *strMessage=[[[NSString alloc] initWithData:receivedData encoding:NSUTF8StringEncoding] autorelease];
	NSLog(@"size: %d",self.size);
    
	
	if(self.bytesDownloaded != self.size)
	{
		/*[self saveToFile];
         
         [RSDownloadManager pauseDownload:self];
         [[NSNotificationCenter defaultCenter] postNotificationName:RSDownloadPausedNotification object:self];*/
        bytesDownloaded = 0;
		[RSDownloadManager downloadFailed:self];
		[[NSNotificationCenter defaultCenter] postNotificationName:RSDownloadFailedNotification object:self];
	}
	else 
	{
        [RSDownloadManager downloadFinished:self];
        
        //    if([delegate respondsToSelector:@selector(rsDownloadComplete:)]) {
        //        [delegate performSelector:@selector(rsDownloadComplete:) withObject:self];
        //    }
        
        //TODO: do a failed notification in the event of file write failure
        [[NSNotificationCenter defaultCenter] postNotificationName:RSDownloadCompleteNotification object:self];
	}
    [fileHandle release];
    fileHandle = nil;
}

#pragma mark -
#pragma mark NSCoding protocol methods

-(void)encodeWithCoder:(NSCoder *)encoder
{
    [encoder encodeInt:size forKey:@"size"];
    [encoder encodeObject:url forKey:@"url"];
    [encoder encodeObject:saveDir forKey:@"saveDir"];
    [encoder encodeObject:filename forKey:@"filename"];
    [encoder encodeObject:title forKey:@"title"];
    [encoder encodeObject:ID forKey:@"ID"];
    [encoder encodeInt64:bytesDownloaded forKey:@"bytesDownloaded"];
    [encoder encodeObject:progressBar forKey:@"progressBar"];
	[encoder encodeObject:progressValue forKey:@"progressValue"];
    [encoder encodeBool:played forKey:@"played"];
	[encoder encodeObject:playDuration forKey:@"playDuration"];
}

-(id)initWithCoder:(NSCoder *)decoder
{
    if((self = [super init])) {
        size = [decoder decodeIntForKey:@"size"];
        self.url = [decoder decodeObjectForKey:@"url"];
        self.saveDir = [decoder decodeObjectForKey:@"saveDir"];
        self.filename = [decoder decodeObjectForKey:@"filename"];
        self.title = [decoder decodeObjectForKey:@"title"];
        self.ID = [decoder decodeObjectForKey:@"ID"];
        bytesDownloaded = [decoder decodeInt64ForKey:@"bytesDownloaded"];
        self.progressBar = [decoder decodeObjectForKey:@"progressBar"];
		self.progressValue=[decoder decodeObjectForKey:@"progressValue"];
        self.played = [decoder decodeBoolForKey:@"played"];
		self.playDuration=[decoder decodeObjectForKey:@"playDuration"];
    }
    
    return self;
}

#pragma mark -

-(void)dealloc {
    //Release the properties with 'retain' or 'copy' descriptors
    self.url = nil;
    self.saveDir = nil;
    self.progressBar = nil;
    self.progressValue=nil;
	self.playDuration=nil;
    
    [fileHandle release];
    
    self.filename = nil;
    
    [conn release];
    
    [super dealloc];
}

@end
