//
//  RSDownloader.m
//  RickSteves_AudioEurope
//
//  Created by Paul Neiland on 10/5/10.
//  Copyright 2010 Treemo Labs. All rights reserved.
//

#import "RSDownloadManager.h"
#import "RSDownload.h"
#import "RSUtils.h"
#import "RSDloadDirectoryData.h"
#import "Reachability.h"

@interface RSDownloadManager()

//Starts the next download if the current one is done
+(void)startNextDownload;

@end

@implementation RSDownloadManager

static NSMutableArray *queue;
static NSURLConnection *conn;

#pragma mark -
#pragma mark Download actions

+(void)startNextDownload {
    //If the connection is already live or we have no queued downloads, do nothing
    if(conn || ![queue count]) {
        return;
    }
    
    RSDownload* dload = [queue objectAtIndex:0];
    NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:dload.url]];
    
    if(dload.bytesDownloaded > 0) {
        NSString *range = [NSString stringWithFormat:@"bytes=%d-", dload.bytesDownloaded];
        [theRequest addValue:@"bytes" forHTTPHeaderField:@"Accept-Ranges"];
        [theRequest addValue:range forHTTPHeaderField:@"Range"];
    } else {
        dload.progressBar.progress=0.0f;
    }
    [conn release];
    conn = [[NSURLConnection alloc] initWithRequest:theRequest delegate:dload startImmediately:NO];
    [conn scheduleInRunLoop:[NSRunLoop currentRunLoop] forMode:NSRunLoopCommonModes];
    [conn start];
   
    
    if(!conn) {
        //Do some error management... eventually ;)
    }
}

+(void)queueDownload:(RSDownload*)dload {
    if(!queue) {
        queue = [[NSMutableArray arrayWithCapacity:1] retain];
    }
    
    [queue addObject:dload];
    
    [self startNextDownload];
}

+(void)destroyDownload:(RSDownload*)dload 
{
    NSMutableArray *paused = (NSMutableArray*)[self allPausedDownloads];
    NSMutableArray *finished = (NSMutableArray*)[self allCompleteDownloads];
    NSMutableArray *failed = (NSMutableArray*)[self allFailedDownloads];
    
    //Check whether this download is the current one
    BOOL currentDload = (dload == [RSDownloadManager itemCurrentlyDownloading]);
    
	if([queue containsObject:dload]) {
        [queue removeObject:dload];
        //[self startNextDownload];
    } else if([paused containsObject:dload]) {
        [paused removeObject:dload];
        [self writePausedDownlaods];
    } else if([finished containsObject:dload]) {
        [finished removeObject:dload];
        [self writeFinishedDownloads];
    } else if([failed containsObject:dload]) {
        [failed removeObject:dload];
		[self writeFailedDownlaods];
    }
    
    if(currentDload) {
        [conn cancel];
        [conn release];
        conn = nil;
        [self startNextDownload];
    }
}

+(void)pauseDownload:(RSDownload*)dload 
{
    //If there's no queue, there's no download to pause
    if(!queue) {
        return;
    }
    
    //Check whether this download is the current one
    BOOL currentDload = (dload == [RSDownloadManager itemCurrentlyDownloading]);
    
    NSMutableArray *pausedDloads = (NSMutableArray*)[self allPausedDownloads];
    
    [pausedDloads addObject:dload];
        
    [queue removeObject:dload];
    
    [self writePausedDownlaods];
    
    //If this was the current download, start the next one
    if(currentDload) {
        [conn release];
        conn = nil;
        
        [self startNextDownload];
    }
}

+(void)resumeDownload:(RSDownload *)dload
{
	[self queueDownload:dload];
    
    [(NSMutableArray*)[self allPausedDownloads] removeObject:dload];
    
    [self writePausedDownlaods];
    
    //[self startNextDownload];
}

+(void)restartDownload:(RSDownload*)dload
{
    if([[self allFailedDownloads] containsObject:dload]) {
        [(NSMutableArray*)[self allFailedDownloads] removeObject:dload];
    }
    
    [self queueDownload:dload];
}

#pragma mark -
#pragma mark Network connection methods

static Reachability *netReach = nil;

+(void)waitForNetworkReconnection {
    if(!netReach) {
        [conn release];
        conn = nil;
        
        netReach = [[Reachability reachabilityForInternetConnection] retain];
        [netReach startNotifier];
        [[NSNotificationCenter defaultCenter] addObserver:self selector: @selector(reachabilityChanged:) name: kReachabilityChangedNotification object: nil];
    }
}

+(void)retryAfterTimeout {
    //Retry connecting
    [conn release];
    conn = nil;
    [self startNextDownload];
}

+(void)reachabilityChanged:(NSNotification*)notification
{
    Reachability *reach = [notification object];
    if(reach == netReach) {
        NetworkStatus netStatus = [reach currentReachabilityStatus];
        switch (netStatus) {
            case (ReachableViaWiFi || ReachableViaWWAN):
                [self onNetworkConnectionReturn];
                break;
        }
    }
}

+(void)onNetworkConnectionReturn {
    [netReach stopNotifier];
    [netReach release];
    netReach = nil;
    [self startNextDownload];
}

#pragma mark -
#pragma mark Download queue related methods

+(RSDownload *)itemCurrentlyDownloading
{
	if([queue count]>0)
	{
		return [queue objectAtIndex:0];
	}
	else
	{
		return nil;
	}
    
}

+(void)downloadFinished:(RSDownload*)dload {
    [(NSMutableArray*)[self allCompleteDownloads] addObject:dload];
    [self writeFinishedDownloads];
    
    [queue removeObject:dload];
    [conn release];
    conn = nil;
    [self startNextDownload];
}

+(void)downloadFailed:(RSDownload*)dload {
    [(NSMutableArray*)[self allFailedDownloads] addObject:dload];
    [self writeFailedDownlaods];
    [queue removeObject:dload];
    [conn release];
    conn = nil;
    [self startNextDownload];
}


+(NSArray*)allQueuedDownloads {
    return queue;
}

#pragma mark -
#pragma mark Serialized data methods

+(NSArray *)allDownloads
{
	NSMutableArray *arrDownloads=[[NSMutableArray arrayWithCapacity:1] retain];
	
	NSArray *allPausedDownloads=[self allPausedDownloads];
	NSArray *allComepletedDownloads=[self allCompleteDownloads];
	NSArray *allFailedDownloads=[self allFailedDownloads];
	NSArray *allRunningDownloads=queue;
	
	
	for(int i=0;i<[allPausedDownloads count];i++)
	{
		[arrDownloads addObject:[allPausedDownloads objectAtIndex:i]];
	}
	for(int j=0;j<[allComepletedDownloads count];j++)
	{
		[arrDownloads addObject:[allComepletedDownloads objectAtIndex:j]];
	}
	for(int i=0;i<[allFailedDownloads count];i++)
	{
		[arrDownloads addObject:[allFailedDownloads objectAtIndex:i]];
	}
	for(int j=0;j<[allRunningDownloads count];j++)
	{
		[arrDownloads addObject:[allRunningDownloads objectAtIndex:j]];
	}
	
	return arrDownloads;
}
+(NSArray*)allPausedDownloads {
    static NSMutableArray *pausedDownloads;
    
    //If pausedDownloads isn't initialized, grab the archived download file
    if(!pausedDownloads) {
        pausedDownloads = [[NSKeyedUnarchiver unarchiveObjectWithFile:[RSUtils pausedDownloadsFile]] retain];
        
        //If there's no archive to grab, just create a blank array
        if(!pausedDownloads) {
            pausedDownloads = [[NSMutableArray arrayWithCapacity:1] retain];
        }
    }
    
    return pausedDownloads;
}

+(NSArray*)allCompleteDownloads {
    static NSMutableArray *finishedDownloads;
    
    //If finishedDownloads isn't initialized, grab the archived download file
    if(!finishedDownloads) {
        finishedDownloads = [[NSKeyedUnarchiver unarchiveObjectWithFile:[RSUtils finishedDownloadsFile]] retain];
        
        //If there's no archive to grab, just create a blank array
        if(!finishedDownloads) {
            finishedDownloads = [[NSMutableArray arrayWithCapacity:1] retain];
        }
    }
    
    return finishedDownloads;
}

+(NSArray*)allFailedDownloads {
    static NSMutableArray *failedDownloads;
    
    //If finishedDownloads isn't initialized, grab the archived download file
	if(!failedDownloads) {
        failedDownloads = [[NSKeyedUnarchiver unarchiveObjectWithFile:[RSUtils failedDownloadsFile]] retain];
	}
    if(!failedDownloads) {
        failedDownloads = [[NSMutableArray arrayWithCapacity:1] retain];
    }
    
    return failedDownloads;
}


+(void)writeFinishedDownloads {
    [NSKeyedArchiver archiveRootObject:(NSMutableArray*)[self allCompleteDownloads] toFile:[RSUtils finishedDownloadsFile]];
}

+(void)writePausedDownlaods {
    [NSKeyedArchiver archiveRootObject:(NSMutableArray*)[self allPausedDownloads] toFile:[RSUtils pausedDownloadsFile]];
}

+(void)writeFailedDownlaods {
	[NSKeyedArchiver archiveRootObject:(NSMutableArray*)[self allFailedDownloads] toFile:[RSUtils failedDownloadsFile]];
}

#pragma mark -
#pragma mark  Determining correct type of track directories

+(NSArray *)sortDirectoriesForDownloads:(NSArray *)allDownloads
{
	if([allDownloads count]>0)
	{
		NSMutableArray *arrdownloadDirectories=[[[NSMutableArray alloc] init] autorelease];
		for(int i=0;i<[allDownloads count];i++)
		{
			RSDownload *dloads=[allDownloads objectAtIndex:i];
			if([arrdownloadDirectories count]==0)
			{
				RSDloadDirectoryData *dloadItem=[[[RSDloadDirectoryData alloc] init] autorelease];
				dloadItem.directory=dloads.saveDir;
				[dloadItem.tracks addObject:dloads];
				[arrdownloadDirectories addObject:dloadItem];
			}
			else {
				BOOL itemAdded=NO;
				for(int j=0;j<[arrdownloadDirectories count];j++)
				{
					
					RSDloadDirectoryData *savedDloadItem=[arrdownloadDirectories objectAtIndex:j];
					if([savedDloadItem.directory isEqualToString:dloads.saveDir])
					{
						BOOL flag=NO;
						itemAdded=YES;
						for(int k=0;k<[savedDloadItem.tracks count];k++)
						{
							RSDownload *savedDload=[savedDloadItem.tracks objectAtIndex:k];
							if([savedDload.ID isEqualToString:dloads.ID])
							{
								flag=YES;
								
								break;
							}
						}
						if(!flag)
						{
							[savedDloadItem.tracks addObject:dloads];
							[arrdownloadDirectories replaceObjectAtIndex:j withObject:savedDloadItem];
							break;
						}
					}
				}
				
				if(!itemAdded)
				{
					RSDloadDirectoryData *dloadItem=[[[RSDloadDirectoryData alloc] init] autorelease];
					dloadItem.directory=dloads.saveDir;
					[dloadItem.tracks addObject:dloads];
					[arrdownloadDirectories addObject:dloadItem];
				}
			}
			
		}
		
		return (NSArray *)arrdownloadDirectories;
	}
	else {
		return nil;
	}
	
}
+(NSArray *)allDownloadedDirectories
{
	NSArray *allDownloads=[self allCompleteDownloads];
	NSArray *allCompletedDownloads=[self sortDirectoriesForDownloads:allDownloads];
	return allCompletedDownloads;
}

+(RSDloadDirectoryData *)downloadsForDirectory:(NSString *)directoryName
{
	NSArray *allDirectories=[self allDownloadedDirectories];
	if([allDirectories count]>0)
	{
		RSDloadDirectoryData *dloadItem=nil;
		for(int i=0;i<[allDirectories count];i++)
		{
			RSDloadDirectoryData *dloadTempItem=[allDirectories objectAtIndex:i];
			NSString *strDirectory=dloadTempItem.directory;
			//NSLog(@"dloadItem.directory: %@ , directoryName: %@",[strDirectory lowercaseString],[directoryName lowercaseString]);
			if([[strDirectory lowercaseString] isEqualToString:[directoryName lowercaseString]])
			{
				dloadItem=dloadTempItem;
				break;
			}
		}
		return dloadItem;
	}
	else {
		return nil;
	}

}

+(NSArray *)allDownloadingDirectory
{
	NSArray *arrDownloading=(NSArray *)queue;
	NSArray *allUnderDownload=[self sortDirectoriesForDownloads:arrDownloading];
	return allUnderDownload;
}

+(RSDloadDirectoryData *)downloadingForDirectory:(NSString *)directoryName
{
	NSArray *allUnderDownload=[self allDownloadingDirectory];
	
	if([allUnderDownload count]>0)
	{
		RSDloadDirectoryData *dloadItem=nil;
		for(int i=0;i<[allUnderDownload count];i++)
		{
			RSDloadDirectoryData *dloadTempItem=[allUnderDownload objectAtIndex:i];
			NSString *strDirectory=dloadTempItem.directory;
			//NSLog(@"dloadItem.directory: %@ , directoryName: %@",[strDirectory lowercaseString],[directoryName lowercaseString]);
			if([[strDirectory lowercaseString] isEqualToString:[directoryName lowercaseString]])
			{
				dloadItem=dloadTempItem;
				break;
			}
		}
		return dloadItem;
	}
	else {
		return nil;
	}
}

+(NSArray *)allPausedDirectories
{
	NSArray *arrDownloading=[self allPausedDownloads];
	NSArray *allUnderDownload=[self sortDirectoriesForDownloads:arrDownloading];
	return allUnderDownload;
}
+(RSDloadDirectoryData *)pausedForDirectory:(NSString *)directoryName
{
	NSArray *allPausedDloads=[self allPausedDirectories];
	if([allPausedDloads count]>0)
	{
		RSDloadDirectoryData *dloadItem=nil;
		for(int i=0;i<[allPausedDloads count];i++)
		{
			RSDloadDirectoryData *dloadTempItem=[allPausedDloads objectAtIndex:i];
			NSString *strDirectory=dloadTempItem.directory;
			//NSLog(@"dloadItem.directory: %@ , directoryName: %@",[strDirectory lowercaseString],[directoryName lowercaseString]);
			if([[strDirectory lowercaseString] isEqualToString:[directoryName lowercaseString]])
			{
				dloadItem=dloadTempItem;
				break;
			}
		}
		return dloadItem;
	}
	else {
		return nil;
	}
}

+(NSArray *)allFailedDirectories
{
	NSArray *arrFailed=[self allFailedDownloads];
	NSArray *allFailedDownloads=[self sortDirectoriesForDownloads:arrFailed];
	return allFailedDownloads;
}
+(RSDloadDirectoryData *)failedForDirectory:(NSString *)directoryName
{
	NSArray *allFailedDloads=[self allFailedDirectories];
	if([allFailedDloads count]>0)
	{
		RSDloadDirectoryData *dloadItem=nil;
		for(int i=0;i<[allFailedDloads count];i++)
		{
			RSDloadDirectoryData *dloadTempItem=[allFailedDloads objectAtIndex:i];
			NSString *strDirectory=dloadTempItem.directory;
			//NSLog(@"dloadItem.directory: %@ , directoryName: %@",[strDirectory lowercaseString],[directoryName lowercaseString]);
			if([[strDirectory lowercaseString] isEqualToString:[directoryName lowercaseString]])
			{
				dloadItem=dloadTempItem;
				break;
			}
		}
		return dloadItem;
	}
	else {
		return nil;
	}
}

+(NSArray *)everyDownload
{
	
	NSArray *arrDownloaded=[self allCompleteDownloads];
	NSArray *arrDownloading=(NSArray *)queue;
	NSArray *arrPausedDownload=[self allPausedDownloads];
	NSArray *arrFailed=[self allFailedDownloads];
	NSMutableArray *arrEveryDownload=nil;;
	if([arrDownloaded count]>0)
	{
		arrEveryDownload=[[[NSMutableArray alloc] initWithArray:arrDownloaded] autorelease];
	}
	if([arrDownloading count]>0)
	{
		if([arrEveryDownload count]>0)
		{
			for(int i=0;i<[arrDownloading count];i++)
			{
				[arrEveryDownload addObject:[arrDownloading objectAtIndex:i]];
			}
		}
		else {
			arrEveryDownload=[[[NSMutableArray alloc] initWithArray:arrDownloading] autorelease];
		}

	}
	if([arrPausedDownload count]>0)
	{
		if([arrEveryDownload count]>0)
		{
			for(int i=0;i<[arrPausedDownload count];i++)
			{
				[arrEveryDownload addObject:[arrPausedDownload objectAtIndex:i]];
			}
		}
		else {
			arrEveryDownload=[[[NSMutableArray alloc] initWithArray:arrPausedDownload] autorelease];
		}
		
	}
	if([arrFailed count]>0)
	{
		if([arrEveryDownload count]>0)
		{
			for(int i=0;i<[arrFailed count];i++)
			{
				[arrEveryDownload addObject:[arrFailed objectAtIndex:i]];
			}
		}
		else {
			arrEveryDownload=[[[NSMutableArray alloc] initWithArray:arrFailed] autorelease];
		}
		
	}
	
	NSArray *everyDirectories=[self sortDirectoriesForDownloads:arrEveryDownload];
	return everyDirectories;
}
+(RSDloadDirectoryData *)anyDownloadForDirectory:(NSString *)directory
{
	RSDloadDirectoryData *allDownloads=[[[RSDloadDirectoryData alloc] init] autorelease];
	RSDloadDirectoryData *downloadItem=[self downloadsForDirectory:directory];
	RSDloadDirectoryData *downloadingItem=[self downloadingForDirectory:directory];
	RSDloadDirectoryData *pausedItems=[self pausedForDirectory:directory];
	RSDloadDirectoryData *failedItems=[self failedForDirectory:directory];
	
	if(downloadItem)
	{
		allDownloads.directory=downloadItem.directory;
	}
	else if(downloadingItem)
	{
		allDownloads.directory=downloadingItem.directory;
	}
	else if(pausedItems)
	{
		allDownloads.directory=pausedItems.directory;
	}
	else if(failedItems)
	{
		allDownloads.directory=failedItems.directory;
	}

	if([downloadItem.tracks count]>0)
	{
		allDownloads.tracks=downloadItem.tracks;
	}
	if([allDownloads.tracks count]==0 && [downloadingItem.tracks count]>0)
	{
		allDownloads.tracks=downloadingItem.tracks;
	}
	else if([allDownloads.tracks count]!=0 && [downloadingItem.tracks count]>0)
	{
		for(int i=0;i<[downloadingItem.tracks count];i++)
		{
			[allDownloads.tracks addObject:[downloadingItem.tracks objectAtIndex:i]];
		}
	}
	
	if([allDownloads.tracks count]==0 && [pausedItems.tracks count]>0)
	{
		allDownloads.tracks=pausedItems.tracks;
	}
	else if([allDownloads.tracks count]!=0 && [pausedItems.tracks count]>0)
	{
		for(int i=0;i<[pausedItems.tracks count];i++)
		{
			[allDownloads.tracks addObject:[pausedItems.tracks objectAtIndex:i]];
		}
	}
	
	if([allDownloads.tracks count]==0 && [failedItems.tracks count]>0)
	{
		allDownloads.tracks=failedItems.tracks;
	}
	else if([allDownloads.tracks count]!=0 && [failedItems.tracks count]>0)
	{
		for(int i=0;i<[failedItems.tracks count];i++)
		{
			[allDownloads.tracks addObject:[failedItems.tracks objectAtIndex:i]];
		}
	}

	return allDownloads;
}

+(void)pauseAllDownloads {
    NSArray *downloadingItems=[RSDownloadManager allDownloadingDirectory];
	for(int i=0;i<[downloadingItems count];i++)
	{
		RSDloadDirectoryData *dloadDirectory=[downloadingItems objectAtIndex:i];
		for(int j=0;j<[dloadDirectory.tracks count];j++)
		{
			RSDownload *dload=[dloadDirectory.tracks objectAtIndex:j];
			[dload pause];
		}
	}
}

@end
