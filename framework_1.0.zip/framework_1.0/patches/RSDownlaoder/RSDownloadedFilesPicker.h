//
//  RSDownloadedFilesPicker.h
//  RickSteves_AudioEurope
//
//  Created by Sumit Kr Prasad on 07/10/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface RSDownloadedFilesPicker : NSObject 
{

}
+(NSMutableArray *)downloadedFiles;
@end
