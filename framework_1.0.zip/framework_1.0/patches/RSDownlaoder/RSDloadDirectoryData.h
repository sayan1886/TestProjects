//
//  RSDloadDirectoryData.h
//  RickSteves_AudioEurope
//
//  Created by Sumit Kr Prasad on 19/10/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface RSDloadDirectoryData : NSObject 
{
	NSString *directory;
	NSMutableArray *tracks;
}

@property (assign, nonatomic) NSString *directory;
@property (assign, nonatomic) NSMutableArray *tracks;
@end
