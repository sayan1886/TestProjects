//
//  TextEntryCell.h
//  Qwiket
//
//  Create by Andrew Paul Simmons on 6/28/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "SettingsCell_Property.h"

@interface SettingsCell_TextEntry : SettingsCell_Property
{
	UITextField *propertyText;
	UITextField *textField;
	BOOL editable;
	

	SEL onReturnKeyPress;
	
}

//::Public
@property (retain, readonly) UITextField *propertyText;
@property (assign) BOOL editable;

- (void) setReturnKeyNextWithActionTarget:(id)target onReturn:(SEL)onReturn_cb;
- (void) setReturnKeyDoneWithActionTarget:(id)target onReturn:(SEL)onReturn_cb;
- (void) setReturnKeyType:(UIReturnKeyType)returnKeyType actionTarget:(id)target onReturn:(SEL)onReturn_cb;


@end