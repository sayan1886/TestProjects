//
//  TextEntryCell.m
//  Qwiket
//
//  Create by Andrew Paul Simmons on 6/28/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import "SettingsCell_TextEntry.h"




@interface SettingsCell_TextEntry () <UITextFieldDelegate>

@property (retain) UITextField *propertyText;

@end

@implementation SettingsCell_TextEntry


@synthesize propertyText;
@synthesize editable;

- (id)initWithFrame:(CGRect)frame reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithFrame:frame reuseIdentifier:reuseIdentifier]) 
	{
		CGRect frame = CGRectMake(100,10,200,35);
		textField = [[UITextField alloc] initWithFrame:frame];
		
		textField.delegate = self;
		
		textField.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
		textField.autocapitalizationType = UITextAutocapitalizationTypeNone;
		textField.autocorrectionType = UITextAutocorrectionTypeNo;
		textField.textAlignment = UITextAlignmentRight;
		textField.textColor = [UIColor blueColor];
		textField.backgroundColor = [UIColor clearColor];
		textField.enabled = NO;
	
		
		//##[textField addTarget:self action:@selector(textEditingDidEnd:forEvent:) forControlEvents:UIControlEventEditingDidEnd];
		
		self.propertyText = textField;
		
		[self.contentView addSubview:textField];
		[textField release];
		
		self.editable = YES;
		
		[self setNeedsLayout];
    }
	
    return self;
}

- (void) setReturnKeyNextWithActionTarget:(id)target onReturn:(SEL)onReturn_cb
{
	[self setReturnKeyType:UIReturnKeyNext actionTarget:target onReturn:onReturn_cb];
}

- (void) setReturnKeyDoneWithActionTarget:(id)target onReturn:(SEL)onReturn_cb
{
	[self setReturnKeyType:UIReturnKeyDone actionTarget:target onReturn:onReturn_cb];
}

- (void) setReturnKeyType:(UIReturnKeyType)returnKeyType actionTarget:(id)target onReturn:(SEL)onReturn_cb
{
	actionTarget = target;
	onReturnKeyPress = onReturn_cb;
	textField.returnKeyType = returnKeyType;
}



- (BOOL) allowsTextEntry
{
	return YES;
}


- (void) setSelected:(BOOL)selected animated:(BOOL)animated
{
	[super setSelected:selected animated:animated];
	[self updateSelection];
	/*
	[NSTimer scheduledTimerWithTimeInterval:0.0f 
											 target:self 
										   selector:@selector(updateSelection) 
										   userInfo:nil 
											repeats:NO];
	 */

}

-(void) updateSelection
{
	if(self.selected)
	{
		//textField
		//////////NSLog(@"Selected!");
		textField.enabled = YES;
		[textField becomeFirstResponder];
		
	}
	else
	{
		////////NSLog(@"Deselected!");
		
		[textField resignFirstResponder];
		textField.enabled = NO;
	}
}

/*##
- (void)textEditingDidEnd:(id)sender forEvent:(UIEvent *)event
{
	[UIApp sendAction:@selector(textEditingDidEnd:) to:nil from:self forEvent:event];
}
*/

- (void)layoutSubviews 
{
    [super layoutSubviews];
	[self.contentView addSubview:textField];
	
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
	return self.editable;
}

- (BOOL)textFieldShouldReturn:(UITextField *)aTextField
{
	[aTextField resignFirstResponder];
	[actionTarget performSelector:onReturnKeyPress];
	if(aTextField.returnKeyType == UIReturnKeyDone)
	{
		return YES;
	}
	else
	{
		return NO;
	}

}

- (void)dealloc
{
	[textField resignFirstResponder];
	self.propertyText = nil;
	
    [super dealloc];
}

@end
