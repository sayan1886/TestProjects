//
//  SettingsCell.h
//  Qwiket
//
//  Create by Andrew Paul Simmons on 6/28/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface SettingsCell : UITableViewCell 
{
	UILabel *label;
	
	id actionTarget;
	SEL onChange;
	NSString* value;
	
}

//::Public
@property (retain, readonly) UILabel *label;
@property(assign) id actionTarget;
@property(assign) SEL onChange; // - (void) onChange:(SettingsCell*)settingsCell
@property(readonly) NSString* value; 

- (BOOL) allowsTextEntry;

@end
