//
//  SettingsCell.m
//  Qwiket
//
//  Create by Andrew Paul Simmons on 6/28/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import "SettingsCell.h"
 
 
@interface SettingsCell ()

@property (retain) UILabel *label;

@end

@implementation SettingsCell

@synthesize label, actionTarget, onChange;

- (id)initWithFrame:(CGRect)frame reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithFrame:frame reuseIdentifier:reuseIdentifier]) {
		CGRect labelFrame = CGRectMake(10.0, 10.0, CGRectGetMaxX(self.contentView.bounds) - 100.0, 22.0);
		UILabel *labelView = [[UILabel alloc] initWithFrame:labelFrame];
		
		labelView.autoresizingMask = UIViewAutoresizingNone;
		labelView.font = [UIFont boldSystemFontOfSize:18.0];
		labelView.textAlignment = UITextAlignmentLeft;
		labelView.textColor = [UIColor blackColor];
		labelView.highlightedTextColor = [UIColor whiteColor];
		labelView.backgroundColor = [UIColor clearColor];
		self.selectionStyle = UITableViewCellSelectionStyleNone;
		[self.contentView addSubview:labelView];
		[labelView release];
		
		self.label = labelView;
    }
	
    return self;
}



- (BOOL) allowsTextEntry
{
	return NO;
}
// Must override
- (NSString*) value
{
	return "override";
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
	
    // Configure the view for the selected state
}


- (void)dealloc
{
	self.label = nil;
	
    [super dealloc];
}


@end
