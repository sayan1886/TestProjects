//
//  SettingsCell_Property.m
//  Qwiket
//
//  Create by Andrew Paul Simmons on 6/28/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import "SettingsCell_Property.h"


@implementation SettingsCell_Property
@synthesize propertyName;

- (id)initWithFrame:(CGRect)frame reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithFrame:frame reuseIdentifier:reuseIdentifier]) {
    }
	
    return self;
}

- (void)dealloc
{
	self.propertyName = nil;
	
    [super dealloc];
}
@end
