//
//  SettingsCell_Property.h
//  Qwiket
//
//  Create by Andrew Paul Simmons on 6/28/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "SettingsCell.h"

@interface SettingsCell_Property : SettingsCell 
{
	NSString *propertyName;
}

@property (nonatomic, retain) NSString *propertyName;

@end
