//
//  TestTweetAppDelegate.h
//  TestTweet
//
//  Created by Subhojit on 09/02/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class TestTweetViewController;

@interface TestTweetAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    TestTweetViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet TestTweetViewController *viewController;

@end

