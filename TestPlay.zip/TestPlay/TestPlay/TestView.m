//
//  TestView.m
//  TestPlay
//
//  Created by Sayan on 18/11/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "TestView.h"

@implementation TestView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        moviePlayer = [[MPMoviePlayerController alloc] initWithContentURL:[NSURL fileURLWithPath:[[[NSBundle mainBundle] resourcePath]stringByAppendingPathComponent:@"/armani.mp4"]]];
        moviePlayer.view.frame = CGRectMake(10, 10, 200, 200);
        [self addSubview:moviePlayer.view];
        [moviePlayer play];
        moviePlayer.controlStyle = MPMovieControlStyleEmbedded;
        self.backgroundColor = [UIColor whiteColor];
    }
    return self;
}


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
//    moviePlayer = [[MPMoviePlayerController alloc] initWithContentURL:[NSURL fileURLWithPath:[[[NSBundle mainBundle] resourcePath]stringByAppendingPathComponent:@"/armani.mp4"]]];
//    moviePlayer.view.frame = CGRectMake(50, 100, 220, 220);
//    [self addSubview:moviePlayer.view];
//    [moviePlayer play];
//    moviePlayer.controlStyle = MPMovieControlStyleEmbedded;
}

- (void) tapOnScreen:(UIGestureRecognizer *)tap{
    NSLog(@"View Screen tapped");
    //[UIImage an]
}

@end
