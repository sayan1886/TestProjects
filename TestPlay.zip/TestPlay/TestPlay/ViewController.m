//
//  ViewController.m
//  TestPlay
//
//  Created by Sayan on 18/11/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
//    moviePlayer = [[MPMoviePlayerController alloc] initWithContentURL:[NSURL fileURLWithPath:[[[NSBundle mainBundle] resourcePath]stringByAppendingPathComponent:@"/armani.mp4"]]];
//    moviePlayer.view.frame = CGRectMake(50, 100, 220, 220);
//    [self.view addSubview:moviePlayer.view];
//    [moviePlayer play];
//    moviePlayer.controlStyle = MPMovieControlStyleEmbedded;
    aView = [[TestView alloc] initWithFrame:CGRectMake(50, 150, 220 , 220)];
    [self.view addSubview:aView];
    UITapGestureRecognizer *tapOnScreen = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapOnScreen:)];
    tapOnScreen.numberOfTapsRequired = 1;
    [self.view addGestureRecognizer:tapOnScreen];
    UIImageView *image = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"eaglefly.gif"]]    ;
    image.frame = CGRectMake(0, 0, 100, 100);
    [self.view addSubview:image];
}

- (void) tapOnScreen:(UIGestureRecognizer *)tap{
    NSLog(@"ViewController Screen tapped");
    
    [aView tapOnScreen:tap];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
    } else {
        return YES;
    }
}

@end
