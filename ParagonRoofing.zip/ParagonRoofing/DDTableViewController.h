//
//  DDTableViewController.h
//  RiskManagementIpad
//
//  Created by Avik Roy on 5/1/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomDropDown.h"

@interface DDTableViewController : UITableViewController
{
    NSArray *arrData;
    id<SelectedValue>delegate;
}

@property (nonatomic,retain) NSArray *arrData;
@property (nonatomic,assign) id<SelectedValue>delegate;

@end
