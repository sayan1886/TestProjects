//
//  request.m
//  Trail
//
//  Created by mmandal on 02/10/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//
#import "URLRequest.h"


@implementation URLRequest
@synthesize data = _data;
@synthesize target = _target;
@synthesize successHandler = _successHandler;
@synthesize failureHandler = _failureHandler;

-(id)initWithTarget:(id)actionTarget
	  SuccessAction:(SEL)successAction 
	  FailureAction:(SEL)failureAction
{
	self=[super init];
	if(self==nil)
	{
		return nil;
	}
	
	self.target=actionTarget;
	self.successHandler=successAction;
	self.failureHandler=failureAction;
	
	return self;
}


-(void)postWithString:(NSMutableString *)sRequest urlString:(NSString *)aUrl soapAction:(NSString *)sAction 
{
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
	
	NSData *postBody;
    
	postBody=[sRequest dataUsingEncoding:NSUTF8StringEncoding];
    
	NSURL *apiURL=[NSURL URLWithString:aUrl];
	NSMutableURLRequest *request=[NSMutableURLRequest requestWithURL:apiURL];
	[request addValue:@"text/xml" forHTTPHeaderField:@"Content-Type"];
	[request addValue:sAction forHTTPHeaderField:@"SOAPAction"];
	[request setHTTPMethod:@"POST"];
	[request setHTTPBody:postBody];
	NSURLConnection *conn=[[NSURLConnection alloc] initWithRequest:request delegate:self];
	if (conn)
	{
		;
	}
}

-(void)postWithString:(NSMutableString *)sRequest urlString:(NSString *)aUrl
{
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
	
	NSData *postBody;
    
	postBody=[sRequest dataUsingEncoding:NSUTF8StringEncoding];
    
	NSURL *apiURL=[NSURL URLWithString:aUrl];
	NSMutableURLRequest *request=[NSMutableURLRequest requestWithURL:apiURL];
	[request setHTTPMethod:@"POST"];
	[request setHTTPBody:postBody];
	NSURLConnection *conn=[[NSURLConnection alloc] initWithRequest:request delegate:self];
	if (conn)
	{
		;
	}
}

#pragma mark -
#pragma mark Connection Deligate
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    status = [(NSHTTPURLResponse*) response statusCode];
	NSLog(@"HERE RESPONSE: %d",status);
	
	if(self.data)
		self.data = nil;
	self.data=[[NSMutableData alloc]init];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
	[self.data appendData:data];	
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{  
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
    if(status == 200)
    {
        NSString *responseData = [[NSString alloc] initWithData:self.data encoding:NSUTF8StringEncoding];
        [self.target performSelector:self.successHandler withObject:responseData];
    }
    else
    {
        [self.target performSelector:self.failureHandler];
    }
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
	[self.target performSelector:self.failureHandler];
}

-(void)dealloc{
    
    _data = nil;
    _target = nil;
    _successHandler = nil;
    _failureHandler = nil;
    
    [super dealloc];
}

@end
