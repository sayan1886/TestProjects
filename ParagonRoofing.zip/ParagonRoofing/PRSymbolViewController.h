//
//  PRSymbolViewController.h
//  ParagonRoofing
//
//  Created by Manas Kumar Mandal on 11/04/12.
//  Copyright (c) 2012 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PRSymbolDelegate.h"

@class SymbolView;

@interface PRSymbolViewController : UIViewController <UIGestureRecognizerDelegate, UIAlertViewDelegate, UITableViewDataSource, UITableViewDelegate, UIPopoverControllerDelegate, PRSymbolDelegate>
{
    CGFloat _firstX;
	CGFloat _firstY;
    BOOL isSymbol;
    BOOL shouldDismissPopOver;
    
    SymbolView *undoView;
}
@property (strong, nonatomic) UIImage *shotImage;
@property (nonatomic, retain) UIToolbar *toolBar;
@property (nonatomic) BOOL isTollbarHiden;
@property (nonatomic, retain) UIImageView *symbolImageView;
@property (nonatomic, retain) UIImageView *markerView;

@property (nonatomic, retain) SymbolView *symbolView;
@property (nonatomic, retain) UIPanGestureRecognizer *panRecognizer;

@property (nonatomic, retain) UIBarButtonItem *itemDone;
@property (nonatomic, retain) UIPopoverController *popOver;
@property (nonatomic, retain) NSMutableArray *arrOfSymbols;
@property (nonatomic, retain) NSMutableArray *arrOfName;


-(void)makeToolBar;
-(void)symbol:(id)sender;
-(UIImage *)takeScreenShot;
-(void)resetFields;

-(void)uploadMainImg;
-(void)showAllSymbol;
-(void)placeSymbolWithImageName:(NSString *)imageName;
-(void)deleteLastSymbol;
-(void)processSymbolAdded;

@end
