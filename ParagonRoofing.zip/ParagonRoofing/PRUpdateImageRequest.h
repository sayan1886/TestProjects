//
//  PRUpdateImageRequest.h
//  ParagonRoofing
//
//  Created by Manas Kumar Mandal on 26/04/12.
//  Copyright (c) 2012 ObjectSol Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PRUpdateImageRequest : NSObject
{
    
}

@property (nonatomic, retain) NSString *_iSurveyId;
@property (nonatomic, retain) NSString *_sFileName;
@property (nonatomic, retain) NSString *_sImageType;
@property (nonatomic, retain) NSString *_sImages64BaseStream;

-(NSMutableString *)updateImageRequestString;

@end
