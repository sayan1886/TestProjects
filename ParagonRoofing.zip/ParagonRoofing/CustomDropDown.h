//
//  CustomDropDown.h
//  RiskManagementIpad
//
//  Created by Avik Roy on 5/1/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol SelectedValue
@required
- (void)didSelectValue:(NSString *)value;

@end

@protocol DropDownDelegate; 

@interface CustomDropDown : NSObject<UIPopoverControllerDelegate,SelectedValue>
{
    UIPopoverController *popoverController;
    NSArray *arrData;
    int tag;
    id<DropDownDelegate>delegate;
}

@property (nonatomic,retain) UIPopoverController *popoverController;
@property (nonatomic,retain) NSArray *arrData;
@property (nonatomic,assign) id<DropDownDelegate>delegate;
@property (nonatomic,assign) int tag;

- (id)initWithArray:(NSArray *)arr andTag:(int)_tag;
- (void)showDropDownFromRect:(CGRect)frame atView:(UIView *)view;

@end

@protocol DropDownDelegate

- (void)selectedValue:(NSString *)value forTag:(int)tag;

@end

