//
//  PRUserDetails.h
//  ParagonRoofing
//
//  Created by Manas Kumar Mandal on 26/04/12.
//  Copyright (c) 2012 ObjectSol Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PRUserDetails : NSObject
{
    
}

@property (nonatomic, retain) NSString *P_Observer_Name;
@property (nonatomic, retain) NSString *P_Address;
@property (nonatomic, retain) NSString *P_Unit_No;
@property (nonatomic, retain) NSString *P_City;
@property (nonatomic, retain) NSString *P_State;
@property (nonatomic, retain) NSString *P_Zip;
@property (nonatomic, retain) NSString *P_Country;

@property (nonatomic, retain) NSString *P_DateTime;
@property (nonatomic, retain) NSString *P_Big_Image_Id;
@property (nonatomic, retain) NSString *PD_Identity;
@property (nonatomic, retain) NSString *PD_Budget_Timeline;

@property (nonatomic, retain) NSString *PD_Unit_Level;
@property (nonatomic, retain) NSString *PD_Qty;
@property (nonatomic, retain) NSString *PD_Miscellaneous_Cost;
@property (nonatomic, retain) NSString *PD_Image;
@property (nonatomic, retain) NSString *PD_Description;
@property (nonatomic, retain) NSString *PD_Requirement;

@property (nonatomic, retain) UIImage *clearViewImage;

@end
