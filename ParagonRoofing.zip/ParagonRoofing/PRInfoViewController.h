//
//  PRInfoViewController.h
//  ParagonRoofing
//
//  Created by Manas Kumar Mandal on 17/04/12.
//  Copyright (c) 2012 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ImagePicker.h"
#import "PRSymbolDelegate.h"

@interface PRInfoViewController : UIViewController <UITextViewDelegate, UITextFieldDelegate, CaptureImage, UITableViewDataSource, UITableViewDelegate, UIPopoverControllerDelegate>
{
    NSInteger timeLineIndex;
}
@property (retain, nonatomic) IBOutlet UIImageView *photoView;
@property (retain, nonatomic) IBOutlet UILabel *lblAssignedNo;

@property (retain, nonatomic) IBOutlet UITextField *txtUnit;
@property (retain, nonatomic) IBOutlet UITextField *txtQty;
@property (retain, nonatomic) IBOutlet UITextField *txtMiscel;
@property (retain, nonatomic) IBOutlet UITextField *txtRequirement;
@property (retain, nonatomic) IBOutlet UITextView *txtViewdesc;
@property (nonatomic, assign) id<PRSymbolDelegate> delegate;

@property (nonatomic, retain) NSMutableArray *arrOfRequirement;
@property (nonatomic, retain) UIPopoverController *popOver;


- (IBAction)addPhoto:(id)sender;
-(BOOL)hasAllFieldValidData;
-(void)uploadImageWithSurveyID:(NSString *)sID;

@end
