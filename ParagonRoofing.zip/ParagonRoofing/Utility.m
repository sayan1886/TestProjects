//
//  Utility.m
//  ParagonRoofing
//
//  Created by Manas Kumar Mandal on 19/04/12.
//  Copyright (c) 2012 ObjectSol Technologies. All rights reserved.
//

#import "Utility.h"
#import "Reachability.h"
#import "MBProgressHUD.h"
#import "PRUserDetails.h"
#import "Constant.h"
#import "PRAppDelegate.h"

@implementation Utility
UIImage *bgImage;
+(void)showAlertWithTitle:(NSString *)aTitle Message:(NSString *)aMsg OkTitle:(NSString *)ok
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:aTitle message:aMsg delegate:nil cancelButtonTitle:ok otherButtonTitles:nil, nil];
    [alert show];
    alert = nil;
}
#pragma mark
#pragma mark Rechability

+(BOOL)isNetworkAvailable
{
	if([[Reachability sharedReachability] remoteHostStatus] == NotReachable)
		return NO;
	else 
		return YES;
}

+(void)showLoadingView
{
    UIWindow *keyWindow = [UIApplication sharedApplication].keyWindow;
    [MBProgressHUD showHUDAddedTo:keyWindow animated:YES];
}

+(void)hideLoadingView
{
    UIWindow *keyWindow = [UIApplication sharedApplication].keyWindow;
    [MBProgressHUD hideHUDForView:keyWindow animated:YES];
}
+(void)saveUserDetails:(PRUserDetails *)userDetail
{
    NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
    NSData *data = [NSKeyedArchiver archivedDataWithRootObject:userDetail];
    [def setObject:data forKey:KEY_USER_DETAILS];
    [def synchronize];
    def = nil;
}

+(PRUserDetails *)loadUserDetails
{
    NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
    PRUserDetails *userDetail = [NSKeyedUnarchiver unarchiveObjectWithData:[def objectForKey:KEY_USER_DETAILS]];
    
    def = nil;
    return userDetail;
}

+(void)setImage:(UIImage *)image
{
    PRAppDelegate *appDelegate = (PRAppDelegate *)[[UIApplication sharedApplication] delegate];
    appDelegate.image = image;
}
+(UIImage *)image
{
    PRAppDelegate *appDelegate = (PRAppDelegate *)[[UIApplication sharedApplication] delegate];
    return appDelegate.image;
}

@end
