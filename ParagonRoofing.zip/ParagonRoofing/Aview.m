//
//  Aview.m
//  ParagonRoofing
//
//  Created by Manas Kumar Mandal on 04/05/12.
//  Copyright (c) 2012 ObjectSol Technologies. All rights reserved.
//

#import "Aview.h"

@implementation Aview

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)drawHeading:(NSString *)str  atPoint:(CGPoint)point
{
	UIFont *font=[UIFont boldSystemFontOfSize:15];
    [str drawAtPoint:point withFont:font];
}	

- (void)drawImage:(UIImage *)img  atPoint:(CGPoint)point
{
    UIImage *myImage = (UIImage *)img;
    [myImage drawAtPoint:point];
}

-(void)creteImageWithBGImage:(UIImage *)bgImg SymbolImage:(UIImage *)sImage identity:(NSInteger)iD atRect:(CGRect)rect
{
    if(bgImg != nil)
    [bgImg drawAtPoint:CGPointMake(0, 0)];
    if(sImage != nil)
    [sImage drawAtPoint:CGPointMake(rect.origin.x, rect.origin.y - 26)];
    if(iD > 0)
    [self drawHeading:[NSString stringWithFormat:@"%d",iD] atPoint:CGPointMake(rect.origin.x, rect.origin.y)];
}

-(void)createImageWithSymbolImage:(UIImage *)sImage identity:(NSInteger)iD atRect:(CGRect)rect
{
    [sImage drawAtPoint:CGPointMake(0, 0)];
    [self drawHeading:[NSString stringWithFormat:@"%d",iD] atPoint:CGPointMake(rect.origin.x, rect.origin.y+25)];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
