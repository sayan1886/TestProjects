//
//  PRDoWorkRequest.m
//  ParagonRoofing
//
//  Created by Manas Kumar Mandal on 26/04/12.
//  Copyright (c) 2012 ObjectSol Technologies. All rights reserved.
//

#import "PRDoWorkRequest.h"
#import "PRUserDetails.h"
#import "Utility.h"

@implementation PRDoWorkRequest

-(NSMutableString *)getRequestString
{
    PRUserDetails *userDetail = [Utility loadUserDetails];
    NSMutableString *mStr = [[NSMutableString alloc] init];
    [mStr appendString:@"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\" xmlns:ns=\"http://schemas.datacontract.org/2004/07/\"><soapenv:Header/><soapenv:Body><tem:DoWork><tem:objParagon>"];
    [mStr appendFormat:@"<ns:P_Observer_Name>%@</ns:P_Observer_Name>", userDetail.P_Observer_Name];
    [mStr appendFormat:@"<ns:P_Address>%@</ns:P_Address>", userDetail.P_Address];
    [mStr appendFormat:@"<ns:P_Unit_No>%@</ns:P_Unit_No>",userDetail.P_Unit_No];
    [mStr appendFormat:@"<ns:P_City>%@</ns:P_City>", userDetail.P_City];
    [mStr appendFormat:@"<ns:P_State>%@</ns:P_State>", userDetail.P_State];
    [mStr appendFormat:@"<ns:P_Country>%@</ns:P_Country>", userDetail.P_Country];
    [mStr appendFormat:@"<ns:P_Zip>%@</ns:P_Zip>", userDetail.P_Zip];
    
    [mStr appendFormat:@"<ns:P_Main_Image></ns:P_Main_Image>"];
    [mStr appendFormat:@"<ns:P_Main_Imgae_Desc></ns:P_Main_Imgae_Desc>"];
    
    [mStr appendFormat:@"<ns:P_DateTime>%@</ns:P_DateTime>", userDetail.P_DateTime];

    [mStr appendFormat:@"<ns:P_Big_Image_Id>%@</ns:P_Big_Image_Id>", userDetail.P_Big_Image_Id];

    [mStr appendFormat:@"<ns:PD_Identity>%@</ns:PD_Identity>", userDetail.PD_Identity];

    [mStr appendFormat:@"<ns:PD_Budget_Timeline>%d</ns:PD_Budget_Timeline>", [userDetail.PD_Budget_Timeline intValue]];
    [mStr appendFormat:@"<ns:PD_Unit_Level>%@</ns:PD_Unit_Level>", userDetail.PD_Unit_Level];
    [mStr appendFormat:@"<ns:PD_Qty>%d</ns:PD_Qty>", [userDetail.PD_Qty intValue]];
    [mStr appendFormat:@"<ns:PD_Miscellaneous_Cost>%@</ns:PD_Miscellaneous_Cost>", userDetail.PD_Miscellaneous_Cost];
    [mStr appendFormat:@"<ns:PD_Image>%@.png</ns:PD_Image>", userDetail.PD_Image ];
    [mStr appendFormat:@"<ns:PD_Description>%@</ns:PD_Description>", userDetail.PD_Description];
    [mStr appendFormat:@"<ns:PD_Requirement>%@</ns:PD_Requirement>", userDetail.PD_Requirement];
    [mStr appendString:@"</tem:objParagon></tem:DoWork></soapenv:Body></soapenv:Envelope>"];
     
    return mStr;
}

-(NSMutableString *)getRequestStringWith:(NSString *)P_Main_Image Desc:(NSString *)desc
{
    PRUserDetails *userDetail = [Utility loadUserDetails];
    NSMutableString *mStr = [[NSMutableString alloc] init];
    [mStr appendString:@"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\" xmlns:ns=\"http://schemas.datacontract.org/2004/07/\"><soapenv:Header/><soapenv:Body><tem:DoWork><tem:objParagon>"];
    [mStr appendFormat:@"<ns:P_Observer_Name>%@</ns:P_Observer_Name>", userDetail.P_Observer_Name];
    [mStr appendFormat:@"<ns:P_Address>%@</ns:P_Address>", userDetail.P_Address];
    [mStr appendFormat:@"<ns:P_Unit_No>%@</ns:P_Unit_No>",userDetail.P_Unit_No];
    [mStr appendFormat:@"<ns:P_City>%@</ns:P_City>", userDetail.P_City];
    [mStr appendFormat:@"<ns:P_State>%@</ns:P_State>", userDetail.P_State];
    [mStr appendFormat:@"<ns:P_Country>%@</ns:P_Country>", userDetail.P_Country];
    [mStr appendFormat:@"<ns:P_Zip>%@</ns:P_Zip>", userDetail.P_Zip];
    
    [mStr appendFormat:@"<ns:P_Main_Image>%@</ns:P_Main_Image>", P_Main_Image];
    [mStr appendFormat:@"<ns:P_Main_Imgae_Desc>%@</ns:P_Main_Imgae_Desc>", desc];
    
    [mStr appendFormat:@"<ns:P_DateTime>%@</ns:P_DateTime>", userDetail.P_DateTime];
    
    [mStr appendFormat:@"<ns:P_Big_Image_Id>%@</ns:P_Big_Image_Id>", userDetail.P_Big_Image_Id];
    
    [mStr appendFormat:@"<ns:PD_Identity>%@</ns:PD_Identity>", userDetail.PD_Identity];
    
    [mStr appendFormat:@"<ns:PD_Budget_Timeline>%d</ns:PD_Budget_Timeline>", [userDetail.PD_Budget_Timeline intValue]];
    [mStr appendFormat:@"<ns:PD_Unit_Level>%@</ns:PD_Unit_Level>", userDetail.PD_Unit_Level];
    [mStr appendFormat:@"<ns:PD_Qty>%d</ns:PD_Qty>", [userDetail.PD_Qty intValue]];
    [mStr appendFormat:@"<ns:PD_Miscellaneous_Cost>%@</ns:PD_Miscellaneous_Cost>", userDetail.PD_Miscellaneous_Cost];
    [mStr appendFormat:@"<ns:PD_Image>%@.png</ns:PD_Image>", userDetail.PD_Image ];
    [mStr appendFormat:@"<ns:PD_Description>%@</ns:PD_Description>", userDetail.PD_Description];
    [mStr appendFormat:@"<ns:PD_Requirement>%@</ns:PD_Requirement>", userDetail.PD_Requirement];
    [mStr appendString:@"</tem:objParagon></tem:DoWork></soapenv:Body></soapenv:Envelope>"];
    
    return mStr;
}


@end
