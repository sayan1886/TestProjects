//
//  PRAppDelegate.h
//  ParagonRoofing
//
//  Created by Manas Kumar Mandal on 11/04/12.
//  Copyright (c) 2012 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@class PRViewController;

@interface PRAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) PRViewController *viewController;
@property (strong, nonatomic) UINavigationController *aNavController;
@property (nonatomic, retain) UIImage *image;
@property (nonatomic) NSInteger MAX_UPLOADED;
@property (nonatomic) BOOL canResetAllFields;

@end
