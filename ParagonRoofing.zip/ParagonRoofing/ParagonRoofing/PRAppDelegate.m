//
//  PRAppDelegate.m
//  ParagonRoofing
//
//  Created by Manas Kumar Mandal on 11/04/12.
//  Copyright (c) 2012 ObjectSol Technologies. All rights reserved.
//

#import "PRAppDelegate.h"
#import "PRViewController.h"
#import "Constant.h"
#import "UncaughtExceptionHandler.h"
#import "URLRequest.h"

@implementation PRAppDelegate

@synthesize window = _window;
@synthesize viewController = _viewController;
@synthesize aNavController = _aNavController;
@synthesize image = _image;
@synthesize MAX_UPLOADED;
@synthesize canResetAllFields;

- (void)dealloc
{
    [_window release];
    [_viewController release];
    [_aNavController release];
    self.image = nil;
    [super dealloc];
}

- (void)installUncaughtExceptionHandler
{
	InstallUncaughtExceptionHandler();
}

- (void)badAccess
{
    void (*nullFunction)() = NULL;
    
    nullFunction();
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]] autorelease];
    // Override point for customization after application launch.
    
    [self updateCrashReport];
    NSUserDefaults *userDef = [NSUserDefaults standardUserDefaults];
    [userDef setInteger:0 forKey:KEY_SYMBOL_ADDED];
    
    self.viewController = [[[PRViewController alloc] initWithNibName:@"PRViewController" bundle:nil] autorelease];
    self.aNavController = [[UINavigationController alloc] initWithRootViewController:self.viewController];
    [self.aNavController.navigationBar setBarStyle:UIBarStyleBlackOpaque];
    [self.window addSubview:self.aNavController.view];
    [self performSelector:@selector(installUncaughtExceptionHandler) withObject:nil afterDelay:0];
    [self.window makeKeyAndVisible];
    return YES;
}

-(void)updateCrashReport
{
    NSString *strCrash = [[NSUserDefaults standardUserDefaults] objectForKey:EXCEPTION_KEY];
    if(strCrash != nil && [strCrash length])
    {
        [self sendReportToServer:[strCrash mutableCopy]];
    }
}

-(void)sendReportToServer:(NSMutableString *)mStr
{
    URLRequest *urlReq = [[URLRequest alloc] initWithTarget:self SuccessAction:@selector(sucess:) FailureAction:@selector(falied)];
    [urlReq postWithString:mStr urlString:EXCEPTION_SERVER_URL];
}

-(void)sucess:(id)sender
{
    NSString *strResponse = (NSString *)sender;
    [[NSUserDefaults standardUserDefaults] setObject:nil forKey:EXCEPTION_KEY];
    [[NSUserDefaults standardUserDefaults] setObject:nil forKey:EXCEPTION_ADDR];
    [[NSUserDefaults standardUserDefaults] synchronize];
    NSLog(@"sucess!! Response : = %@", strResponse);
}

-(void)falied
{
    NSLog(@"falied!!!");
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    /*
     Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
     Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
     */
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    /*
     Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
     If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
     */
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    /*
     Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
     */
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    /*
     Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
     */
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    /*
     Called when the application is about to terminate.
     Save data if appropriate.
     See also applicationDidEnterBackground:.
     */
}

@end
