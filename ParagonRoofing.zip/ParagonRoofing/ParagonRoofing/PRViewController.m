//
//  PRViewController.m
//  ParagonRoofing
//
//  Created by Manas Kumar Mandal on 11/04/12.
//  Copyright (c) 2012 ObjectSol Technologies. All rights reserved.
//

#import "PRViewController.h"
#import "PRMapViewController.h"
#import "JSON.h"
#import "MBProgressHUD.h"
#import "Utility.h"
#import "PRUserDetails.h"
#import "Constant.h"
#import <QuartzCore/QuartzCore.h>
#import "ImagePicker.h"
#import "UIImage+TKCategory.h"
#import "PRUserDetails.h"
#import "URLRequest.h"
#import "PRDoWorkRequest.h"
#import "PRUpdateImageRequest.h"
#import "Decode64.h"
#import "XMLReader.h"
#import "PRAppDelegate.h"
#import "CustomDropDown.h"

@implementation PRViewController
@synthesize txtName;
@synthesize txtAddress;
@synthesize txtCity;
@synthesize txtState;
@synthesize txtZip;
@synthesize txtCountry;
@synthesize txtInspectionType;
@synthesize clearView;
@synthesize txtViewClear;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

-(id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if(self)
    {
        UIBarButtonItem *aItem = [[UIBarButtonItem alloc] initWithTitle:@"Next" style:UIBarButtonItemStyleDone target:self action:@selector(next:)];
        [self.navigationItem setRightBarButtonItem:aItem animated:YES];
        [aItem release]; aItem = nil;
        
        UIImageView *titleView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:LOGO]];
        self.navigationItem.titleView = titleView;
        [titleView release]; titleView = nil;
    }
    return self;
}

-(void)resetAllField
{
    self.txtName.text = @"";
    self.txtAddress.text = @"";
    self.txtCity.text = @"";
    self.txtState.text = @"";
    self.txtZip.text = @"";
    self.txtCountry.text = @"";
    self.clearView.image = nil;
    self.txtViewClear.text = @"";
    [Utility saveUserDetails:nil];
}

#pragma mark DropDownDelegate

- (void)selectedValue:(NSString *)value forTag:(int)tag
{
    self.txtInspectionType.text = value;
}


#pragma mark - next

-(BOOL)hasAllFieldValidData
{
    NSString *strName = self.txtName.text;
    NSString *strAdd = self.txtAddress.text;
    NSString *strCity = self.txtCity.text;
    NSString *strState = self.txtState.text;
    NSString *strZip = self.txtZip.text;
    NSString *strDesc = self.txtViewClear.text;
    
    if(self.clearView.image == nil) return NO;
    
    if(!strName || !strAdd || !strCity || !strState || !strZip || !strDesc)
        return NO;
    
    strName = [strName stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    strAdd = [strAdd stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    strCity = [strCity stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    strState = [strState stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    strZip = [strZip stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    strDesc = [strDesc stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    return (([strName length] > 0) && ([strAdd length] > 0) &&
            ([strCity length] > 0) && ([strState length] > 0) && ([strZip length] > 0) &&
            ([strDesc length] > 0));
}

-(void)next:(id)sender
{
    if(![self hasAllFieldValidData])
    {
        [Utility showAlertWithTitle:@"Error!" Message:@"Must fillup Name, Address, City, State, Zip, Clear View of Property and Roof system type, life expectancy fields." OkTitle:@"Ok"];
        return ;
    }
    [Utility showLoadingView];
    if(![Utility isNetworkAvailable])
    {
        [Utility hideLoadingView];
        [Utility showAlertWithTitle:@"Error!" Message:@"Connection Failed. Please try again later." OkTitle:@"Ok"];
        
        return ;
    }
    
    PRUserDetails *userDetail = [[PRUserDetails alloc] init];
    userDetail.P_Observer_Name = self.txtName.text;
    userDetail.P_Address = self.txtAddress.text;
    userDetail.P_City = self.txtCity.text;
    userDetail.P_State = self.txtState.text;
    userDetail.P_Zip = self.txtZip.text;
    userDetail.P_Country = self.txtCountry.text;
    userDetail.P_Unit_No = @"";
    userDetail.clearViewImage = self.clearView.image;
    [Utility saveUserDetails:userDetail];
    [self upload];
}

-(void)upload
{
    if(![self hasAllFieldValidData])
    {
        [Utility showAlertWithTitle:@"Error!" Message:@"Fill up all the fields" OkTitle:@"Ok"];
        return ;
    }
    PRUserDetails *userDetails = [Utility loadUserDetails];
    userDetails.PD_Identity = @"";
    userDetails.PD_Budget_Timeline = @"";
    userDetails.PD_Unit_Level = @"";
    userDetails.PD_Qty = @"";
    userDetails.PD_Miscellaneous_Cost = @"";
    userDetails.PD_Description = @"";
    userDetails.PD_Requirement = @"";
    NSDateFormatter *formater = [[NSDateFormatter alloc] init];
    [formater setDateFormat:@"yyyy-MM-dd"];
    NSString *str = [formater stringFromDate:[NSDate date]];
    userDetails.P_DateTime = str;
    userDetails.P_Big_Image_Id = str;
    userDetails.PD_Image = @"img.png";
    
    formater = nil; str = nil;
    [Utility saveUserDetails:userDetails];
        
    if(![Utility isNetworkAvailable])
    {
        [Utility hideLoadingView];
        [Utility showAlertWithTitle:@"Error!" Message:@"Connection failed. Please try again later." OkTitle:@"Ok"];
        
        return ;
    }
    
    URLRequest *req = [[URLRequest alloc] initWithTarget:self SuccessAction:@selector(uploadSuccess:) FailureAction:@selector(uploadFailed)];
    PRDoWorkRequest *doWork = [[PRDoWorkRequest alloc] init];
    [req postWithString:[doWork getRequestStringWith:@"BigImg" Desc:txtViewClear.text] urlString:BASE_URL soapAction:SOAP_ACTION_DOWORK];
}

-(void)uploadSuccess:(id)sender
{
    NSString *responseData = (NSString *)sender;
    NSError *err;
    NSDictionary *dict = [XMLReader dictionaryForXMLString:responseData error:&err];
    NSString *text = [[[[[dict objectForKey:@"s:Envelope"]objectForKey:@"s:Body"] valueForKey:@"DoWorkResponse"] valueForKey:@"DoWorkResult"] valueForKey:@"text"];
    [[NSUserDefaults standardUserDefaults] setValue:text forKey:@"lastID"];
    if([text intValue] > 0)
    {
        [self uploadImageWithSurveyID:text];
    }
    else
    {
        
        [Utility showAlertWithTitle:@"Error!" Message:@"Upload unsuccessful. Please try again later." OkTitle:@"Ok"];
    }
}

-(void)uploadImageWithSurveyID:(NSString *)sID
{
    if(![Utility isNetworkAvailable])
    {
        [Utility hideLoadingView];
        [Utility showAlertWithTitle:@"Error!" Message:@"Connection failed. Please try again later." OkTitle:@"Ok"];
        
        return ;
    }
    
    URLRequest *req = [[URLRequest alloc] initWithTarget:self SuccessAction:@selector(imageUploadSuccess:) FailureAction:@selector(uploadFailed)];
    PRUpdateImageRequest *imgReq = [[PRUpdateImageRequest alloc] init];
    imgReq._iSurveyId = sID;
    imgReq._sFileName = [NSString stringWithFormat:@"img%@.png",sID];
    imgReq._sImageType = @"BigImg";
    imgReq._sImages64BaseStream = [Base64 encode:UIImagePNGRepresentation(self.clearView.image)];
    [req postWithString:[imgReq updateImageRequestString] urlString:BASE_URL soapAction:SOAP_ACTION_UPDATE_IMAGE];
}

-(void)imageUploadSuccess:(id)sender;
{
    NSString *responseData = (NSString *)sender;
    
    NSError *err;
    NSDictionary *dict = [XMLReader dictionaryForXMLString:responseData error:&err];
    
    NSString *text = [[[[[dict objectForKey:@"s:Envelope"]objectForKey:@"s:Body"] valueForKey:@"UpdateImageResponse"] valueForKey:@"UpdateImageResult"] valueForKey:@"text"];
    if([text boolValue])
        [self latLonForAddress];
    else
        [Utility showAlertWithTitle:@"Error!" Message:@"Upload unsuccessful. Please try again later." OkTitle:@"Ok"];
}
-(void)uploadFailed
{
    [Utility hideLoadingView];
    [Utility showAlertWithTitle:@"Error!" Message:@"Upload unsuccessful. Please try again later." OkTitle:@"Ok"];
}

-(void)latLonForAddress
{
    NSMutableString *mStr = [[NSMutableString alloc] init];
    if(self.txtAddress.text)
    {
        [mStr appendString:self.txtAddress.text];
        [mStr appendString:@","];
    }
    if(self.txtCity.text)
    {
        [mStr appendString:self.txtCity.text];
        [mStr appendString:@","];
    }
    if(self.txtState.text)
    {
        [mStr appendString:self.txtState.text];
        [mStr appendString:@","];
    }
    if(self.txtCountry.text)
    {
        [mStr appendString:self.txtCountry.text];
        [mStr appendString:@","];
    }
    if(self.txtZip.text)
    {
        [mStr appendString:self.txtZip.text];
    }
    [Utility hideLoadingView];
    dispatch_queue_t myQueue = dispatch_queue_create("com.inspect2go.paragonRoofing", 0);
    dispatch_async(myQueue, ^{
        CLLocationCoordinate2D location = [self geoCodeUsingAddress:[mStr description]];
        [self gotoNextPage:location];
    });
}


-(void)gotoNextPage:(CLLocationCoordinate2D)location
{
    dispatch_sync(dispatch_get_main_queue(), ^{
    
    PRMapViewController *viewController = [[PRMapViewController alloc] initWithNibName:@"PRMapViewController" bundle:nil];
    viewController.coordinate = location;
    [self.navigationController pushViewController:viewController animated:YES];
    [viewController release]; viewController = nil;
    });
}

- (IBAction)takePhoto:(id)sender {
    
    ImagePicker *picker = [[ImagePicker alloc] init] ;
	picker.delegate = self;
	picker.vc = self;
	[picker clickAddPictureAtViewController:self.view];
}

-(void) didReceivePicture:(UIImage *)img
{
    if(img != nil)
    {
        img = [img fixOrientation];
        self.clearView.image = img;
    }
}

- (CLLocationCoordinate2D) geoCodeUsingAddress:(NSString *)address
{
    NSString *esc_addr =  [address stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSString *req = [NSString stringWithFormat:@"http://maps.google.com/maps/api/geocode/json?sensor=false&address=%@", esc_addr];
    NSString *result = [NSString stringWithContentsOfURL:[NSURL URLWithString:req] encoding:NSUTF8StringEncoding error:NULL];
    SBJsonParser *parser = [[SBJsonParser alloc] init];
    NSDictionary *dict = [parser objectWithString:result];
    
    NSDictionary    *resultsDict = [dict valueForKey:@"results"];   // get the results dictionary
    NSDictionary   *geometryDict = [resultsDict valueForKey: @"geometry"];   // geometry dictionary within the  results dictionary
    NSDictionary   *locationDict = [geometryDict valueForKey: @"location"];   // location dictionary     
    NSArray *latArray = [locationDict valueForKey: @"lat"]; NSString *latString = [latArray lastObject];     
    NSArray *lngArray = [locationDict valueForKey: @"lng"]; NSString *lngString = [lngArray lastObject];         
    CLLocationCoordinate2D center;
    center.latitude = [latString doubleValue];
    center.longitude = [lngString doubleValue];
    return center;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:BG]];
	self.txtViewClear.backgroundColor = [UIColor whiteColor];
    self.txtViewClear.layer.borderWidth = 1.5;
    self.txtViewClear.layer.borderColor = [UIColor grayColor].CGColor;
}

#pragma mark textFieldDelegate Method

-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if(textField == self.txtInspectionType)
    {
        NSArray *arr = [NSArray arrayWithObjects:@"Annual", @"Bi-Annual", @"2nd Quarter", @"3rd Quarter", @"4th Quarter." , nil];
        CustomDropDown *dropDown = [[CustomDropDown alloc] initWithArray:arr andTag:1];
        dropDown.delegate = self;
        [dropDown showDropDownFromRect:textField.frame atView:self.view];
        return NO;
    }
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if(textField == self.txtZip)
    {
        if(range.location < 5)
        {
            NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:VALID_INTEGER] invertedSet];
            NSString *filtered = [[string componentsSeparatedByCharactersInSet:cs] componentsJoinedByString:@""];
        
            return [string isEqualToString:filtered];
        }
        return NO;
    }
    return YES;
}

#pragma mark textViewDelegate

#pragma mark textViewDelegate
-(BOOL)textViewShouldBeginEditing:(UITextView *)textView
{
    CGRect frame = self.view.frame;
    
    frame.origin.y = -250;
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.30];
    self.view.frame = frame;
    [UIView commitAnimations];
    return YES;
}

- (BOOL)textViewShouldEndEditing:(UITextView *)textView
{
    CGRect frame = self.view.frame;
    frame.origin.y = 0;
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.30];
    self.view.frame = frame;
    [UIView commitAnimations];
    return YES;
}

- (void)viewDidUnload
{
    [self setTxtName:nil];
    [self setTxtAddress:nil];
    [self setTxtCity:nil];
    [self setTxtState:nil];
    [self setTxtZip:nil];
    [self setTxtCountry:nil];
    [self setClearView:nil];
    [self setTxtViewClear:nil];
    [self setTxtInspectionType:nil];
    [super viewDidUnload];
}

- (void)viewWillAppear:(BOOL)animated
{
    NSUserDefaults *userDef = [NSUserDefaults standardUserDefaults];
    [userDef setInteger:0 forKey:KEY_SYMBOL_ADDED];
    [userDef synchronize];
    PRAppDelegate *appDelegate = [UIApplication sharedApplication].delegate;
    if(appDelegate.canResetAllFields)
    {
        appDelegate.canResetAllFields = NO;
        [self resetAllField];
    }
    
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}
/*
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return YES;
}*/

- (void)dealloc {
    
    [txtName release];
    [txtAddress release];
    [txtCity release];
    [txtState release];
    [txtZip release];
    [txtCountry release];    
    [clearView release];
    [txtViewClear release];
    [txtInspectionType release];
    [super dealloc];
}
@end
