//
//  PRViewController.h
//  ParagonRoofing
//
//  Created by Manas Kumar Mandal on 11/04/12.
//  Copyright (c) 2012 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import "ImagePicker.h"
#import "CustomDropDown.h"

@class MBProgressHUD;


@interface PRViewController : UIViewController<UITextFieldDelegate, CaptureImage, DropDownDelegate>
{
    
}
@property (retain, nonatomic) IBOutlet UITextField *txtName;
@property (retain, nonatomic) IBOutlet UITextField *txtAddress;
@property (retain, nonatomic) IBOutlet UITextField *txtCity;
@property (retain, nonatomic) IBOutlet UITextField *txtState;
@property (retain, nonatomic) IBOutlet UITextField *txtZip;
@property (retain, nonatomic) IBOutlet UITextField *txtCountry;
@property (retain, nonatomic) IBOutlet UITextField *txtInspectionType;
@property (retain, nonatomic) IBOutlet UIImageView *clearView;
@property (retain, nonatomic) IBOutlet UITextView *txtViewClear;

- (IBAction)takePhoto:(id)sender;
- (CLLocationCoordinate2D) geoCodeUsingAddress:(NSString *)address;
-(void)gotoNextPage:(CLLocationCoordinate2D)location;

-(BOOL)hasAllFieldValidData;
-(void)resetAllField;
-(void)upload;
-(void)uploadImageWithSurveyID:(NSString *)sID;
-(void)latLonForAddress;

@end
