//
//  NewImspectionViewController.h
//  ParagonRoofing
//
//  Created by Ashim Samanta on 09/08/12.
//  Copyright (c) 2012 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewImspectionViewController : UIViewController
{
    
}
- (IBAction)startNewInspection:(id)sender;
@end
