//
//  SymbolView.h
//  ParagonRoofing
//
//  Created by Ashim Samanta on 07/08/12.
//  Copyright (c) 2012 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SymbolView : UIView
{
}
@property (nonatomic) CGFloat _firstX;
@property (nonatomic) CGFloat _firstY;
@end
