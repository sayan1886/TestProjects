//
//  PRInfoViewController.m
//  ParagonRoofing
//
//  Created by Manas Kumar Mandal on 17/04/12.
//  Copyright (c) 2012 ObjectSol Technologies. All rights reserved.
//

#import "PRInfoViewController.h"
#import "Constant.h"
#import "ImagePicker.h"
#import "UIImage+TKCategory.h"
#import "PRUserDetails.h"
#import "Utility.h"
#import "URLRequest.h"
#import "PRDoWorkRequest.h"
#import "XMLReader.h"
#import "PRUpdateImageRequest.h"
#import "Decode64.h"
#import <QuartzCore/QuartzCore.h>

@interface PRInfoViewController (Private) 

-(void)configRequirement;
    
@end

@implementation PRInfoViewController

@synthesize photoView;
@synthesize lblAssignedNo;
@synthesize txtUnit;
@synthesize txtQty;
@synthesize txtMiscel;
@synthesize txtRequirement;
@synthesize txtViewdesc;
@synthesize delegate;
@synthesize arrOfRequirement;
@synthesize popOver;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        UIBarButtonItem *aItem = [[UIBarButtonItem alloc] initWithTitle:@"upload" style:UIBarButtonItemStyleDone target:self action:@selector(upload:)];
        [self.navigationItem setRightBarButtonItem:aItem animated:YES];
        [aItem release]; aItem = nil;
        
        UIImageView *titleView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:LOGO]];
        self.navigationItem.titleView = titleView;
        [titleView release]; titleView = nil;
    }
    return self;
}
-(BOOL)hasAllFieldValidData
{
    if(!photoView.image) return NO;
    NSString *strUnit = self.txtUnit.text;
    NSString *strQty = self.txtQty.text;
    NSString *mis = self.txtMiscel.text;
    NSString *desc = self.txtViewdesc.text;
    NSString *req = self.txtRequirement.text;
    
    if( !strUnit || !strQty || !mis || !desc || !req) return NO;
    
    strUnit = [strUnit stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    strQty = [strQty stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    mis = [mis stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    desc = [desc stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    req = [req stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    return ( ([strUnit length] > 0) && ([strQty length] > 0)
            && ([mis length] > 0) && ([desc length] > 0) && ([req length] > 0));
}

-(void)upload:(id)sender
{
    if(![self hasAllFieldValidData])
    {
        [Utility showAlertWithTitle:@"Error!" Message:@"Fill up all the fields" OkTitle:@"Ok"];
        return ;
    }
    
    [self.delegate didSelectTimeline:timeLineIndex];
    
    PRUserDetails *userDetails = [Utility loadUserDetails];
    userDetails.PD_Identity = self.lblAssignedNo.text;
    userDetails.PD_Budget_Timeline = @"";
    userDetails.PD_Unit_Level = self.txtUnit.text;
    userDetails.PD_Qty = self.txtQty.text;
    userDetails.PD_Miscellaneous_Cost = self.txtMiscel.text;
    userDetails.PD_Description = self.txtViewdesc.text;
    userDetails.PD_Requirement = self.txtRequirement.text;
    NSDateFormatter *formater = [[NSDateFormatter alloc] init];
    [formater setDateFormat:@"yyyy-MM-dd"];
    NSString *str = [formater stringFromDate:[NSDate date]];
    userDetails.P_DateTime = str;
    userDetails.P_Big_Image_Id = str;
    userDetails.PD_Image = @"img.png";
   
    formater = nil; str = nil;
    [Utility saveUserDetails:userDetails];
    
    [Utility showLoadingView];
    
    if(![Utility isNetworkAvailable])
    {
        [Utility hideLoadingView];
        [Utility showAlertWithTitle:@"Error!" Message:@"Connection failed. Please try again later." OkTitle:@"Ok"];
        
        return ;
    }
    
    URLRequest *req = [[URLRequest alloc] initWithTarget:self SuccessAction:@selector(uploadSuccess:) FailureAction:@selector(uploadFailed)];
    PRDoWorkRequest *doWork = [[PRDoWorkRequest alloc] init];
    [req postWithString:[doWork getRequestString] urlString:BASE_URL soapAction:SOAP_ACTION_DOWORK];
}

-(void)uploadSuccess:(id)sender
{
    NSString *responseData = (NSString *)sender;
    
    NSError *err;
    NSDictionary *dict = [XMLReader dictionaryForXMLString:responseData error:&err];
    NSString *text = [[[[[dict objectForKey:@"s:Envelope"]objectForKey:@"s:Body"] valueForKey:@"DoWorkResponse"] valueForKey:@"DoWorkResult"] valueForKey:@"text"];
    [[NSUserDefaults standardUserDefaults] setValue:text forKey:@"lastID"];
    if([text intValue] > 0)
    {
        [self uploadImageWithSurveyID:text];
    }
    else
    {
        [Utility hideLoadingView];
        [Utility showAlertWithTitle:@"Error!" Message:@"Upload unsuccessful. Please try again later." OkTitle:@"Ok"];
    }
}

-(void)uploadImageWithSurveyID:(NSString *)sID
{
    if(![Utility isNetworkAvailable])
    {
        [Utility hideLoadingView];
        [Utility showAlertWithTitle:@"Error!" Message:@"Connection failed. Please try again later." OkTitle:@"Ok"];
        
        return ;
    }
    
    URLRequest *req = [[URLRequest alloc] initWithTarget:self SuccessAction:@selector(imageUploadSuccess:) FailureAction:@selector(uploadFailed)];
    PRUpdateImageRequest *imgReq = [[PRUpdateImageRequest alloc] init];
    imgReq._iSurveyId = sID;
    imgReq._sFileName = [NSString stringWithFormat:@"img%@.png",sID];
    imgReq._sImageType = @"sub";
    imgReq._sImages64BaseStream = [Base64 encode:UIImagePNGRepresentation(self.photoView.image)];
    [req postWithString:[imgReq updateImageRequestString] urlString:BASE_URL soapAction:SOAP_ACTION_UPDATE_IMAGE];
}

-(void)imageUploadSuccess:(id)sender;
{
    NSString *responseData = (NSString *)sender;
    
    NSError *err;
    NSDictionary *dict = [XMLReader dictionaryForXMLString:responseData error:&err];
    [Utility hideLoadingView];
    
    NSString *text = [[[[[dict objectForKey:@"s:Envelope"]objectForKey:@"s:Body"] valueForKey:@"UpdateImageResponse"] valueForKey:@"UpdateImageResult"] valueForKey:@"text"];
    if([text boolValue])
    {
        [Utility showAlertWithTitle:@"Successful!" Message:@"Upload successfully." OkTitle:@"Ok"];
        [self.navigationController popViewControllerAnimated:YES];
    }
    else
    {
        [Utility showAlertWithTitle:@"Error!" Message:@"Upload unsuccessful. Please try again later." OkTitle:@"Ok"];
    }
}
-(void)uploadFailed
{
    [Utility hideLoadingView];
    
    [Utility showAlertWithTitle:@"Error!" Message:@"Upload unsuccessful. Please try again later." OkTitle:@"Ok"];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}


#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:BG]];
    
    NSMutableArray *arr = [[NSMutableArray alloc] initWithObjects:@"Immediate", @"1 Year", @"2 Year", @"3 Year",nil];
    self.arrOfRequirement = arr;
    [arr release]; arr = nil;
    
    NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
    NSInteger val = [def integerForKey:KEY_SYMBOL_ADDED];
    self.lblAssignedNo.text = [NSString stringWithFormat:@"%d",val];
    self.txtViewdesc.backgroundColor = [UIColor clearColor];
//    [self.navigationItem setHidesBackButton:YES animated:YES];
    self.txtViewdesc.backgroundColor = [UIColor whiteColor];
    self.txtViewdesc.layer.borderWidth = 1.5;
    self.txtViewdesc.layer.borderColor = [UIColor grayColor].CGColor;
}

#pragma mark Requirement Configuire

-(void)configRequirement
{
    UITableViewController *tabContrler = [[UITableViewController alloc] initWithStyle:UITableViewStylePlain];
    tabContrler.view.frame = CGRectMake(0, 0, 200, 200);
    tabContrler.tableView.delegate = self;
    tabContrler.tableView.dataSource = self;
    
    UIPopoverController *pop = [[UIPopoverController alloc] initWithContentViewController:tabContrler];
    pop.popoverContentSize = CGSizeMake(200, 200);
    [pop presentPopoverFromRect:CGRectMake(550, 110, 200, 200) inView:self.view permittedArrowDirections:UIPopoverArrowDirectionUp animated:YES];
    pop.delegate = self;
    self.popOver = pop;
    [tabContrler release]; tabContrler = nil;
    [pop release]; pop = nil;
}

#pragma mark tableView Delegate & data source & popover delegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 55.0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.arrOfRequirement count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cellId";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell == nil)
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
    cell.textLabel.text = [self.arrOfRequirement objectAtIndex:indexPath.row];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self.popOver dismissPopoverAnimated:YES];
    timeLineIndex = indexPath.row;
    self.txtRequirement.text = [self.arrOfRequirement objectAtIndex:indexPath.row];
}

- (BOOL)popoverControllerShouldDismissPopover:(UIPopoverController *)popoverController
{
    return YES;
}

#pragma mark createToolBar For TextView

-(void)createToolBar
{
    UIToolbar *tool = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, 1, 44)];
    
    NSMutableArray *arr = [[NSMutableArray alloc] init];
    
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithTitle:@"Cancel" style:UIBarButtonItemStylePlain target:self action:@selector(cancelTextView)];
    [arr addObject:item];
    item = nil;
    
    item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    [arr addObject:item];
    item = nil;
    
    item = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStylePlain target:self action:@selector(doneTextView)];
    [arr addObject:item];
    item = nil;
    
    [tool setItems:arr animated:YES];
    arr = nil;
    
    self.txtViewdesc.inputAccessoryView = tool;
    tool = nil;
}

-(void)cancelTextView
{
    self.txtViewdesc.text = @"";
    [self.txtViewdesc resignFirstResponder];
}

-(void)doneTextView
{
    [self.txtViewdesc resignFirstResponder];
}

- (void)viewDidUnload
{
    [self setLblAssignedNo:nil];
    [self setTxtUnit:nil];
    [self setTxtQty:nil];
    [self setTxtMiscel:nil];
    [self setTxtViewdesc:nil];
    [self setPhotoView:nil];
    [self setTxtRequirement:nil];
    self.arrOfRequirement = nil;
    self.popOver = nil;
    [super viewDidUnload];
}

-(void)dealloc
{
    self.lblAssignedNo = nil;
    self.txtUnit = nil;
    self.txtQty = nil;
    self.txtMiscel = nil;
    self.txtViewdesc = nil;
    self.photoView = nil;
    self.arrOfRequirement = nil;
    self.popOver = nil;
    [txtRequirement release];
    [super dealloc];
}

- (IBAction)addPhoto:(id)sender {
    ImagePicker *picker = [[ImagePicker alloc] init] ;
	picker.delegate = self;
	picker.vc = self;
	[picker clickAddPictureAtViewController:self.view];
}

-(void) didReceivePicture:(UIImage *)img
{
	img = [img fixOrientation];
    self.photoView.image = img;
}
#pragma mark textFieldDelegate

-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if(textField == self.txtRequirement)
    {
        [self configRequirement];
        return NO;
    }
    return YES;
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
//    if(textField == self.txtQty)
//    {
//        NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:VALID_INTEGER] invertedSet];
//        NSString *filtered = [[string componentsSeparatedByCharactersInSet:cs] componentsJoinedByString:@""];
//        return [string isEqualToString:filtered];
//    }
//    if(textField == self.txtMiscel)
//    {
//        NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:VALID_FLOAT] invertedSet];
//        NSString *filtered = [[string componentsSeparatedByCharactersInSet:cs] componentsJoinedByString:@""];
//        return [string isEqualToString:filtered];
//    }
    return YES;
}

#pragma mark textViewDelegate
-(BOOL)textViewShouldBeginEditing:(UITextView *)textView
{    
    CGRect frame = self.view.frame;
    frame.origin.y = -300;
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.30];
    self.view.frame = frame;
    [UIView commitAnimations];
    [self createToolBar];
    return YES;
}

- (BOOL)textViewShouldEndEditing:(UITextView *)textView
{
    CGRect frame = self.view.frame;
    frame.origin.y = 0;
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.30];
    self.view.frame = frame;
    [UIView commitAnimations];
    return YES;
}

@end
