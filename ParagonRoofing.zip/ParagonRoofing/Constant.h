
#define KEY_SYMBOL_ADDED @"symbolAdded"

#define KEY_USER_DETAILS @"UserDetails"

#define BASE_URL @"http://pg.inspect2gohosting.com/pg/Paragon_Service.svc"

#define SOAP_ACTION_DOWORK @"http://tempuri.org/IParagon_Service/DoWork"
#define SOAP_ACTION_UPDATE_IMAGE @"http://tempuri.org/IParagon_Service/UpdateImage"

#define VALID_INTEGER @"0123456789"
#define VALID_FLOAT @".0123456789"

#define LOGO @"logo.png"
#define BG @"background.png"

#define EXCEPTION_KEY @"keyException"
#define EXCEPTION_ADDR @"keyExcpAddr"

#define EXCEPTION_SERVER_URL @"http://174.136.1.35/dev/paragon/report.php"

//click the link below to see report
//http://174.136.1.35/dev/paragon/data.txt