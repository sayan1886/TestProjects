//
//  request.h
//  Trail
//
//  Created by mmandal on 02/10/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface URLRequest : NSObject <NSURLConnectionDelegate>
{
	NSInteger status;
}

@property (nonatomic, retain) NSMutableData *data;
@property (nonatomic, assign) id target;
@property (nonatomic, assign) SEL successHandler;
@property (nonatomic, assign) SEL failureHandler;

-(id)initWithTarget:(id)actionTarget
	  SuccessAction:(SEL)successAction 
	  FailureAction:(SEL)failureAction;

-(void)postWithString:(NSMutableString *)sRequest 
            urlString:(NSString *)aUrl 
           soapAction:(NSString *)sAction;

-(void)postWithString:(NSMutableString *)sRequest urlString:(NSString *)aUrl;


@end
