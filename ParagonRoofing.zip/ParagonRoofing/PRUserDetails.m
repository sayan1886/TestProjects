//
//  PRUserDetails.m
//  ParagonRoofing
//
//  Created by Manas Kumar Mandal on 26/04/12.
//  Copyright (c) 2012 ObjectSol Technologies. All rights reserved.
//

#import "PRUserDetails.h"

@implementation PRUserDetails

@synthesize P_Observer_Name = _P_Observer_Name;
@synthesize P_Address = _P_Address;
@synthesize P_Unit_No = _P_Unit_No;
@synthesize P_City = _P_City;
@synthesize P_State = _P_State;
@synthesize P_Zip = _P_Zip;
@synthesize P_Country = _P_Country;

@synthesize P_DateTime = _P_DateTime;
@synthesize P_Big_Image_Id = _P_Big_Image_Id;
@synthesize PD_Identity = _PD_Identity;
@synthesize PD_Budget_Timeline = _PD_Budget_Timeline;

@synthesize PD_Unit_Level = _PD_Unit_Level;
@synthesize PD_Qty = _PD_Qty;
@synthesize PD_Miscellaneous_Cost = _PD_Miscellaneous_Cost;
@synthesize PD_Image = _PD_Image;
@synthesize PD_Description = _PD_Description;
@synthesize PD_Requirement = _PD_Requirement;

@synthesize clearViewImage = _clearViewImage;

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super init];
    if(self)
    {
        self.P_Observer_Name = [aDecoder decodeObjectForKey:@"P_Observer_Name"];
        self.P_Address = [aDecoder decodeObjectForKey:@"P_Address"];
        self.P_Unit_No = [aDecoder decodeObjectForKey:@"P_Unit_No"];
        self.P_City = [aDecoder decodeObjectForKey:@"P_City"];
        self.P_State = [aDecoder decodeObjectForKey:@"P_State"];
        self.P_Zip = [aDecoder decodeObjectForKey:@"P_Zip"];
        self.P_Country = [aDecoder decodeObjectForKey:@"P_Country"];
        
        self.P_DateTime = [aDecoder decodeObjectForKey:@"P_DateTime"];
        self.P_Big_Image_Id = [aDecoder decodeObjectForKey:@"P_Big_Image_Id"];
        self.PD_Identity = [aDecoder decodeObjectForKey:@"PD_Identity"];
        self.PD_Budget_Timeline = [aDecoder decodeObjectForKey:@"PD_Budget_Timeline"];
        
        self.PD_Unit_Level = [aDecoder decodeObjectForKey:@"PD_Unit_Level"];
        self.PD_Qty = [aDecoder decodeObjectForKey:@"PD_Qty"];
        self.PD_Miscellaneous_Cost = [aDecoder decodeObjectForKey:@"PD_Miscellaneous_Cost"];
        self.PD_Image = [aDecoder decodeObjectForKey:@"PD_Image"];
        self.PD_Description = [aDecoder decodeObjectForKey:@"PD_Description"];
        self.PD_Requirement = [aDecoder decodeObjectForKey:@"PD_Requirement"];
        self.clearViewImage = [aDecoder decodeObjectForKey:@"clearViewImage"];
    }
    
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeObject:self.P_Observer_Name forKey:@"P_Observer_Name"];
    [aCoder encodeObject:self.P_Address forKey:@"P_Address"];
    [aCoder encodeObject:self.P_Unit_No forKey:@"P_Unit_No"];
    [aCoder encodeObject:self.P_City forKey:@"P_City"];
    [aCoder encodeObject:self.P_State forKey:@"P_State"];    
    [aCoder encodeObject:self.P_Zip forKey:@"P_Zip"];
    [aCoder encodeObject:self.P_Country forKey:@"P_Country"];
    
    [aCoder encodeObject:self.P_DateTime forKey:@"P_DateTime"];
    [aCoder encodeObject:self.P_Big_Image_Id forKey:@"P_Big_Image_Id"];
    [aCoder encodeObject:self.PD_Identity forKey:@"PD_Identity"];
    [aCoder encodeObject:self.PD_Budget_Timeline forKey:@"PD_Budget_Timeline"];
    
    [aCoder encodeObject:self.PD_Unit_Level forKey:@"PD_Unit_Level"];
    [aCoder encodeObject:self.PD_Qty forKey:@"PD_Qty"];
    [aCoder encodeObject:self.PD_Miscellaneous_Cost forKey:@"PD_Miscellaneous_Cost"];
    [aCoder encodeObject:self.PD_Image forKey:@"PD_Image"];
    [aCoder encodeObject:self.PD_Description forKey:@"PD_Description"];
    [aCoder encodeObject:self.PD_Requirement forKey:@"PD_Requirement"];
    [aCoder encodeObject:self.clearViewImage forKey:@"clearViewImage"];
}

-(void)dealloc
{
    self.P_Observer_Name = nil;
    self.P_Address = nil;
    self.P_Unit_No = nil;
    self.P_City = nil;
    self.P_State = nil;
    self.P_Zip = nil;
    self.P_Country = nil;
    
    self.P_DateTime = nil;
    self.P_Big_Image_Id = nil;
    self.PD_Identity = nil;
    self.PD_Budget_Timeline = nil;
    
    self.PD_Unit_Level = nil;
    self.PD_Qty = nil;
    self.PD_Miscellaneous_Cost = nil;
    self.PD_Image = nil;
    self.PD_Description = nil;
    self.PD_Requirement = nil;
    [_clearViewImage release];
    [super dealloc];
}

@end
