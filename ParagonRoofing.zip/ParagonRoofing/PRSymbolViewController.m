//
//  PRSymbolViewController.m
//  ParagonRoofing
//
//  Created by Manas Kumar Mandal on 11/04/12.
//  Copyright (c) 2012 ObjectSol Technologies. All rights reserved.
//

#import "PRSymbolViewController.h"
#import "PRAppDelegate.h"
#import "PRInfoViewController.h"
#import "Constant.h"
#import "Utility.h"
#import "URLRequest.h"
#import "PRUpdateImageRequest.h"
#import "Decode64.h"
#import "XMLReader.h"
#import "Aview.h"
#import <QuartzCore/QuartzCore.h>
#import "SymbolView.h"
#import "NewImspectionViewController.h"

static int LIMIT_FOR_DELETE = 2;

@implementation PRSymbolViewController

@synthesize shotImage = _shotImage;
@synthesize toolBar = _toolBar;
@synthesize isTollbarHiden = _isTollbarHiden;
@synthesize symbolImageView = _symbolImageView;
@synthesize markerView = _markerView;
@synthesize symbolView = _symbolView;
@synthesize panRecognizer = _panRecognizer;

@synthesize itemDone = _itemDone;
@synthesize popOver = _popOver;
@synthesize arrOfSymbols = _arrOfSymbols;
@synthesize arrOfName;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        UIBarButtonItem *aItem = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleDone target:self action:@selector(done:)];
        self.itemDone = aItem;
        [aItem release]; aItem = nil;
        [self.navigationItem setRightBarButtonItem:self.itemDone animated:YES];
        self.itemDone.enabled = NO;
        
        UIImageView *titleView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:LOGO]];
        self.navigationItem.titleView = titleView;
        [titleView release]; titleView = nil;
        
        [self.navigationItem setHidesBackButton:YES animated:YES];
        
        UIButton *btnBack = [UIButton buttonWithType:UIButtonTypeCustom];
        btnBack.frame = CGRectMake(0, 0, 53, 29);
        [btnBack setBackgroundImage:[UIImage imageNamed:@"back_active.png"] forState:UIControlStateNormal];
        [btnBack setBackgroundImage:[UIImage imageNamed:@"back_inactive.png"] forState:UIControlStateHighlighted];
        [btnBack addTarget:self action:@selector(back:) forControlEvents:UIControlEventTouchUpInside];
        aItem = [[UIBarButtonItem alloc] initWithCustomView:btnBack];
        [self.navigationItem setLeftBarButtonItem:aItem];
        [aItem release]; aItem = nil;
    }
    return self;
}

#pragma mark back:
-(void)back:(id)sender
{
    if([[NSUserDefaults standardUserDefaults] integerForKey:KEY_SYMBOL_ADDED] > 0)
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Confirmed!" message:@"If you go back you may loose all of your previous data. Do you want to proceed?" delegate:self cancelButtonTitle:@"Yes" otherButtonTitles:nil, nil];
        [alert addButtonWithTitle:@"No"];
        alert.tag = 2;
        [alert show];
        [alert release]; alert = nil;
    }
    else
        [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark done:
-(void)done:(id)sender
{
    if(self.symbolView != nil && [self.symbolView superview])
    {
        PRInfoViewController *viewController = [[PRInfoViewController alloc] initWithNibName:@"PRInfoViewController" bundle:nil];
        viewController.delegate = self;
        [self.navigationController pushViewController:viewController animated:YES];
    }
    else{
        self.itemDone.enabled = NO;
    }
}

#pragma mark alertView delegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    [alertView dismissWithClickedButtonIndex:buttonIndex animated:YES];
    if(alertView.tag == 1 && buttonIndex == 0)
    {
        [self deleteLastSymbol];
    }
    else if(alertView.tag == 2 && buttonIndex == 0)
    {
        [self.navigationController popViewControllerAnimated:YES];
    }
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
}

#pragma mark makeToolBar

-(void)makeToolBar
{
    self.toolBar = [[UIToolbar alloc] initWithFrame:CGRectMake(0.0, 918.0, 768, 44)];
    [self.view addSubview:self.toolBar];
    
    NSMutableArray *arrOfItems = [[NSMutableArray alloc] init];
    
    UIBarButtonItem *aItem = [[UIBarButtonItem alloc] initWithTitle:@"Symbol" style:UIBarButtonItemStyleDone target:self action:@selector(symbol:)];
    [arrOfItems addObject:aItem];
    
    [aItem release]; aItem = nil;
    
    
    aItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    [arrOfItems addObject:aItem];
    [aItem release]; aItem = nil;
    
    aItem = [[UIBarButtonItem alloc] initWithTitle:@"AllDone" style:UIBarButtonItemStyleDone target:self action:@selector(allDone:)];
    [arrOfItems addObject:aItem];
    [aItem release]; aItem = nil;
    
    [self.toolBar setItems:arrOfItems animated:YES];
    [arrOfItems release]; arrOfItems = nil;
}

#pragma mark symbol and marker

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 35.0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.arrOfSymbols count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cellId";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell == nil)
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
    NSString *imageName = [self.arrOfSymbols objectAtIndex:indexPath.row];
    cell.imageView.image = [UIImage imageNamed:imageName];
    cell.textLabel.text = [self.arrOfName objectAtIndex:indexPath.row];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self.popOver dismissPopoverAnimated:YES];
    [self processSymbolAdded];
    [self placeSymbolWithImageName:[self.arrOfSymbols objectAtIndex:indexPath.row]];
    self.itemDone.enabled = YES;
}

- (BOOL)popoverControllerShouldDismissPopover:(UIPopoverController *)popoverController
{
    return YES;
}

-(void)placeSymbolWithImageName:(NSString *)imageName
{
    //if previous symbol exist make sure that it can't move.
    //So remove the gesture.
    [self.toolBar setAlpha:0.0];
    /*if(self.symbolView)
    {
        [self.symbolView removeGestureRecognizer:self.panRecognizer];
        self.panRecognizer = nil;
        self.symbolView = nil;
    }*/
    
    self.markerView = nil;
    UIImage *sImage = [UIImage imageNamed:imageName];
    
    self.symbolView = [[SymbolView alloc] initWithFrame:CGRectMake(364, -26, 45, 40)];
    self.symbolView.tag = [[NSUserDefaults standardUserDefaults] integerForKey:KEY_SYMBOL_ADDED];
    
    self.symbolView.backgroundColor = [UIColor clearColor];
    self.symbolImageView = [[UIImageView alloc] initWithImage:sImage];
    self.panRecognizer = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(move:)];
    [self.panRecognizer setMinimumNumberOfTouches:1];
    [self.panRecognizer setMaximumNumberOfTouches:1];
    [self.panRecognizer setDelegate:self];
    [self.symbolView addGestureRecognizer:self.panRecognizer];
    [self.symbolView addSubview:self.symbolImageView];
    
    [self.view addSubview:self.symbolView];
    CGRect frame = self.symbolView.frame;
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.40];
    frame.origin.y = 482;
    self.symbolView.frame = frame;
    [UIView commitAnimations];
    
    UITapGestureRecognizer *gesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapped:)];
    [self.view addGestureRecognizer:gesture];
    gesture.numberOfTapsRequired = 2;
    [gesture release]; gesture = nil;
}

-(void)tapped:(id)sender
{
    PRAppDelegate *app = (PRAppDelegate *)[[UIApplication sharedApplication] delegate];
    NSInteger numTodelete = [[NSUserDefaults standardUserDefaults] integerForKey:KEY_SYMBOL_ADDED];
    if(numTodelete <= 0) return ;
    if(app.MAX_UPLOADED - LIMIT_FOR_DELETE < numTodelete && [self.symbolView superview])
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Warning!" message:@"Are you sure want to delete the last symbol?" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil , nil];
        [alert addButtonWithTitle:@"Cancel"];
        alert.tag = 1;
        [alert show];
        [alert release];
    }
}

-(void)deleteLastSymbol
{
    if([self.symbolView superview])
    {
        [self.symbolView removeFromSuperview];
        self.toolBar.alpha = 1.0;
        NSUserDefaults *userDef = [NSUserDefaults standardUserDefaults];
        NSInteger total = [userDef integerForKey:KEY_SYMBOL_ADDED];
        NSLog(@"Total = %d", total);
        if(total > 0)
            total--;
        [userDef setInteger:total forKey:KEY_SYMBOL_ADDED];
        [userDef synchronize];
        if(total <= 0) self.itemDone.enabled = NO;
        self.symbolView = (SymbolView *)[self.view viewWithTag:[[NSUserDefaults standardUserDefaults] integerForKey:KEY_SYMBOL_ADDED]];
    }
}

-(void)symbol:(id)sender
{
    if(self.arrOfSymbols == nil)
        self.arrOfSymbols = [[NSMutableArray alloc] initWithObjects:@"1.jpg", @"1A.jpg", @"1B.jpg", @"1C.jpg", @"B.jpg", @"b1.jpg",@"BALD.jpg", @"BS.jpg", @"C.jpg", @"CFa.jpg", @"CFb.jpg", @"CFc.jpg", @"CFd.jpg", @"CL.jpg", @"CRICKET_ICON.jpg", @"CS.jpg", @"CURB.jpg", @"D.jpg", @"danger1.jpg", @"DBR.jpg", @"EC.jpg", @"EJ.jpg", @"EJE.jpg", @"EW.jpg", @"F.jpg", @"GG.jpg", @"GTR.jpg", @"H.jpg", @"hatch.jpg", @"hv.jpg", @"HVAC.jpg", @"M.jpg", @"MC.jpg", @"P.jpg", @"pj.jpg", @"PW.jpg", @"S.jpg", @"sat.jpg", @"SKY.jpg", @"TJ.jpg", @"TRIANGLE.jpg", @"V.jpg" , @"WA.jpg", @"WB.jpg", @"WC.jpg", @"WD.jpg", @"WI.jpg", @"WKP.jpg", @"WR.jpg", @"WS.jpg",/*@"X.jpg",*/ @"Xa.jpg", nil];
    if(self.arrOfName == nil)
        self.arrOfName = [[NSMutableArray alloc] initWithObjects:@"Base flashing", @"Base flashing",@"Base flashing",@"Base flashing",@"Blister", @"Blocking", @"Bald spot", @"Base flashing seams", @"Crack", @"Counterflashing", @"Counterflashing", @"Counterflashing", @"Counterflashing", @"Condensate leak", @"Cricket needed", @"Capstone", @"HVAC curb", @"Drain", @"Abandoned mechanical instrument", @"Debris", @"EFIS coping cap", @"Expansion joint", @"Expansion joint base flashing", @"EFIS wall", @"Fryer", @"Gravel guard", @"Gutter", @"Hole", @"Roof hatch", @"Heater vent", @"HVAC unit", @"", @"Metal coping cap", @"Pitch pan", @"Plumbing jack", @"Ponding water", @"Scupper", @"Satellite dish", @"Sky light", @"Tilt wall joint", @"Cricket", @"Vent", @"Wall flashing", @"Wall flashing", @"Wall flashing", @"Wall flashing",@"Wet insulation", @"Walk pad", @"Pitch pan runner", @"Wall flashing seams", @"Grease damage",  nil];
    [self showAllSymbol];
}

-(void)processSymbolAdded
{
    NSUserDefaults *userDef = [NSUserDefaults standardUserDefaults];
    NSInteger total = [userDef integerForKey:KEY_SYMBOL_ADDED];
    NSLog(@"Total = %d", total);
    if(total >= 19)
    {
        [Utility showAlertWithTitle:@"Error!" Message:@"Not allowed to add more than 20 symbols." OkTitle:@"Ok"];
        return ;
    }
    else
    {
        total++;
        [userDef setInteger:total forKey:KEY_SYMBOL_ADDED];
        [userDef synchronize];
    }
    userDef = nil;
}

-(void)showAllSymbol
{
    shouldDismissPopOver = NO;
    UITableViewController *tabContrler = [[UITableViewController alloc] initWithStyle:UITableViewStylePlain];
    tabContrler.view.frame = CGRectMake(0, 0, 300, 500);
    tabContrler.tableView.delegate = self;
    tabContrler.tableView.dataSource = self;
    self.popOver = [[UIPopoverController alloc] initWithContentViewController:tabContrler];
    self.popOver.popoverContentSize = CGSizeMake(300, 500);
    [self.popOver presentPopoverFromRect:CGRectMake(1, 980, 300, 500) inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
    self.popOver.delegate = self;
}

-(UIImage *)takeScreenShot
{
    CGRect frame = self.view.frame;
    Aview *aView = [[[Aview alloc] initWithFrame:frame] retain];
    
    UIGraphicsBeginImageContext(frame.size);
    //CGContextSetFillColorWithColor(UIGraphicsGetCurrentContext(), color.CGColor);
    //[aView creteImageWithBGImage:[Utility image] SymbolImage:self.symbolImageView.image identity:[[NSUserDefaults standardUserDefaults]integerForKey:KEY_SYMBOL_ADDED] atRect:self.symbolView.frame];
    [aView drawImage:[Utility image] atPoint:CGPointMake(0, 0)];
    for(UIView *sView in [self.view subviews])
    {
        if([sView isKindOfClass:[SymbolView class]])
        {
            UIImageView *imgView = [[[sView subviews] lastObject] retain];
            [aView drawImage:imgView.image atPoint:sView.frame.origin];
            [imgView release]; imgView = nil;
        }
    }
    [aView.layer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage *screen = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    [aView release]; aView = nil;
    return screen;
}

-(UIImage *)drawTextInViewWithColor:(UIColor *)color
{
    CGRect frame = self.symbolView.frame;
    Aview *aView = [[Aview alloc] initWithFrame:frame];
    
    UIGraphicsBeginImageContext(frame.size);
    CGContextSetFillColorWithColor(UIGraphicsGetCurrentContext(), color.CGColor);
    [aView createImageWithSymbolImage:self.symbolImageView.image identity:[[NSUserDefaults standardUserDefaults]integerForKey:KEY_SYMBOL_ADDED] atRect:CGRectMake(0, 0, self.symbolView.frame.size.width, self.symbolView.frame.size.height)];
    [aView.layer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage *screen = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    [aView release]; aView = nil;
    return screen;
}

#pragma mark didSelectTimeline

-(void)didSelectTimeline:(int)index
{
    UIColor *color = nil;
    switch (index) 
    {
        case 0:
            color = [UIColor redColor];
            break;
            
        case 1:
            color = [UIColor yellowColor];
            break;
            
        case 2:
            color = [UIColor blueColor];
            break;
    }
    
    self.symbolImageView.frame = self.symbolView.frame;
    [self.symbolImageView removeFromSuperview];
    [self.symbolImageView release]; 
    self.symbolImageView = [[UIImageView alloc] initWithImage:[self drawTextInViewWithColor:color]];
    PRAppDelegate *app = (PRAppDelegate *)[[UIApplication sharedApplication] delegate];
    app.MAX_UPLOADED = [[NSUserDefaults standardUserDefaults] integerForKey:KEY_SYMBOL_ADDED];
    [self.symbolView addSubview:self.symbolImageView];
}

-(void)allDone:(id)sender
{
    self.toolBar.alpha = 0.0;
    [Utility setImage:[self takeScreenShot]];
    
    [self uploadMainImg];
}

-(void)uploadMainImg
{
   [Utility showLoadingView];
    if(![Utility isNetworkAvailable])
    {
        [Utility hideLoadingView];
        self.toolBar.alpha = 1.0;
        [Utility showAlertWithTitle:@"Error!" Message:@"Connection failed. Please try again later." OkTitle:@"Ok"];
        
        return ;
    }
    
    NSString *sID = [[NSUserDefaults standardUserDefaults] valueForKey:@"lastID"];
    URLRequest *req = [[URLRequest alloc] initWithTarget:self SuccessAction:@selector(imageUploadSuccess:) FailureAction:@selector(uploadFailed)];
    PRUpdateImageRequest *imgReq = [[PRUpdateImageRequest alloc] init];
    imgReq._iSurveyId = sID;
    imgReq._sFileName = [NSString stringWithFormat:@"main%@.png",sID];
    imgReq._sImageType = @"main";
    
    self.shotImage = [Utility image];
    
    imgReq._sImages64BaseStream = [Base64 encode:UIImagePNGRepresentation(self.shotImage)];
    [req postWithString:[imgReq updateImageRequestString] urlString:BASE_URL soapAction:SOAP_ACTION_UPDATE_IMAGE];
}

-(void)imageUploadSuccess:(id)sender;
{
    NSString *responseData = (NSString *)sender;
    NSError *err;
    NSDictionary *dict = [XMLReader dictionaryForXMLString:responseData error:&err];
    [Utility hideLoadingView];
    
    NSString *text = [[[[[dict objectForKey:@"s:Envelope"]objectForKey:@"s:Body"] valueForKey:@"UpdateImageResponse"] valueForKey:@"UpdateImageResult"] valueForKey:@"text"];
    if([text boolValue])
    {
        [Utility showAlertWithTitle:@"Successful!" Message:@"Upload successfully." OkTitle:@"Ok"];
        NewImspectionViewController *vc = [[NewImspectionViewController alloc] initWithNibName:@"NewImspectionViewController" bundle:nil];
        [self.navigationController pushViewController:vc animated:YES];
        [vc release]; vc = nil;
    }
    else
    {
        self.toolBar.alpha = 1.0;
        [Utility showAlertWithTitle:@"Error!" Message:@"Upload unsuccessful. Please try again later." OkTitle:@"Ok"];
    }
}
-(void)uploadFailed
{
    [Utility hideLoadingView];
    self.toolBar.alpha = 1.0;
    [Utility showAlertWithTitle:@"Error!" Message:@"Upload unsuccessful. Please try again later." OkTitle:@"Ok"];
    return ;
}

#pragma mark move

-(void)move:(id)sender 
{    
    UIPanGestureRecognizer *gesture = (UIPanGestureRecognizer *)sender;
    SymbolView *aView = (SymbolView *)gesture.view;
    CGPoint translatedPoint = [gesture translationInView:aView];
    CGPoint loc = [(UIPanGestureRecognizer*)sender locationInView:self.view];
    
    if(loc.y <= 20.0 || loc.y >= 980.0) return;

    if([(UIPanGestureRecognizer*)sender state] == UIGestureRecognizerStateBegan) 
    {
        if(aView)
        {
            aView._firstX = [aView center].x;
            aView._firstY = [aView center].y;
        }
    }
    
    translatedPoint = CGPointMake(aView._firstX+translatedPoint.x, aView._firstY+translatedPoint.y);
    [aView setCenter:translatedPoint];
}


#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    UIImageView *imgView = [[UIImageView alloc] initWithFrame:self.view.frame];
    imgView.tag = 1000;
    imgView.image = [Utility image];
    [self.view addSubview:imgView];
    
    [self makeToolBar];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    UIImageView *imgView = (UIImageView *)[self.view viewWithTag:1000];
    imgView.image = [Utility image];
}

-(void)resetFields
{
    if(self.symbolView)
    {
        if([self.symbolView superview])
            [self.symbolView removeFromSuperview];
        [self.symbolView removeGestureRecognizer:self.panRecognizer];
        self.panRecognizer = nil;
        self.symbolView = nil;
    }
}

-(void)viewWillDisappear:(BOOL)animated
{
    //if previous symbol exist make sure that it can't move.
    //So remove the gesture.
    
    [super viewWillDisappear:animated];
}
-(void)viewDidDisappear:(BOOL)animated
{
    self.toolBar.alpha = 1.0;
    [super viewDidDisappear:animated];
}

/*
#pragma mark hideToolBar
-(void)hideToolBar
{
    self.isTollbarHiden = !self.isTollbarHiden;
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.60];
    if(self.isTollbarHiden)
        [self.toolBar setAlpha:0.0];
    else
        [self.toolBar setAlpha:1.0];
    [UIView commitAnimations];
}
*/
- (void)viewDidUnload
{
    [self setShotImage:nil];
    [self setToolBar:nil];
    self.itemDone = nil;
    self.popOver = nil;
    self.arrOfSymbols = nil;
    self.arrOfName = nil;
    [super viewDidUnload];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
	return YES;
}
-(void)dealloc
{
    
    self.shotImage = nil;
    self.toolBar = nil;
    self.itemDone = nil;
    self.popOver = nil;
    self.arrOfSymbols = nil;
    [arrOfName release];
    
    [super dealloc];
}

@end
