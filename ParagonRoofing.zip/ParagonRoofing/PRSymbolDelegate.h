//
//  PRSymbolDelegate.h
//  ParagonRoofing
//
//  Created by Manas Kumar Mandal on 08/06/12.
//  Copyright (c) 2012 ObjectSol Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol PRSymbolDelegate <NSObject>

-(void)didSelectTimeline:(int)index;

@end
