//
//  PRDoWorkRequest.h
//  ParagonRoofing
//
//  Created by Manas Kumar Mandal on 26/04/12.
//  Copyright (c) 2012 ObjectSol Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PRUserDetails.h"

@interface PRDoWorkRequest : NSObject
{
    
}

-(NSMutableString *)getRequestString;
-(NSMutableString *)getRequestStringWith:(NSString *)P_Main_Image Desc:(NSString *)desc;


@end
