//
//  Aview.h
//  ParagonRoofing
//
//  Created by Manas Kumar Mandal on 04/05/12.
//  Copyright (c) 2012 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Aview : UIView
{
    
}

- (void)drawHeading:(NSString *)str  atPoint:(CGPoint)point;
- (void)drawImage:(UIImage *)img  atPoint:(CGPoint)point;
-(void)creteImageWithBGImage:(UIImage *)bgImg SymbolImage:(UIImage *)sImage identity:(NSInteger)iD atRect:(CGRect)rect;
-(void)createImageWithSymbolImage:(UIImage *)sImage identity:(NSInteger)iD atRect:(CGRect)rect;

@end
