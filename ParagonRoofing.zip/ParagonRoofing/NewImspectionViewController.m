//
//  NewImspectionViewController.m
//  ParagonRoofing
//
//  Created by Ashim Samanta on 09/08/12.
//  Copyright (c) 2012 ObjectSol Technologies. All rights reserved.
//

#import "NewImspectionViewController.h"
#import "PRAppDelegate.h"
#import "Constant.h"

@interface NewImspectionViewController ()

@end

@implementation NewImspectionViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        [self.navigationItem setHidesBackButton:YES animated:YES];
        UIImageView *titleView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:LOGO]];
        self.navigationItem.titleView = titleView;
        [titleView release]; titleView = nil;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"background.png"]];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	return YES;
}

- (IBAction)startNewInspection:(id)sender {
    PRAppDelegate *appDelegate = [UIApplication sharedApplication].delegate;
    appDelegate.canResetAllFields = YES;
    [self.navigationController popToRootViewControllerAnimated:YES];
}
@end
