//
//  Utility.h
//  ParagonRoofing
//
//  Created by Manas Kumar Mandal on 19/04/12.
//  Copyright (c) 2012 ObjectSol Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>

@class PRUserDetails;

@interface Utility : NSObject
{
    
}

+(void)showAlertWithTitle:(NSString *)aTitle Message:(NSString *)aMsg OkTitle:(NSString *)ok;
+(BOOL)isNetworkAvailable;
+(void)showLoadingView;
+(void)hideLoadingView;

+(void)saveUserDetails:(PRUserDetails *)userDetail;
+(PRUserDetails *)loadUserDetails;
+(void)setImage:(UIImage *)image;
+(UIImage *)image;

@end
