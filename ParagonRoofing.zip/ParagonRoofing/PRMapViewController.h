//
//  PRMapViewController.h
//  ParagonRoofing
//
//  Created by Manas Kumar Mandal on 11/04/12.
//  Copyright (c) 2012 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>

@interface PRMapViewController : UIViewController<MKMapViewDelegate, CLLocationManagerDelegate>
{
    
}
@property (retain, nonatomic) IBOutlet MKMapView *mapView;
@property (retain, nonatomic) UIActivityIndicatorView *activityView;
@property (nonatomic, assign) CLLocationCoordinate2D coordinate;
//@property (nonatomic, retain) CLLocationManager *clManager;
-(UIImage *)takeScreenShot;
@end
