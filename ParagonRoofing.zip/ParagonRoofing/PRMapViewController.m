//
//  PRMapViewController.m
//  ParagonRoofing
//
//  Created by Manas Kumar Mandal on 11/04/12.
//  Copyright (c) 2012 ObjectSol Technologies. All rights reserved.
//

#import "PRMapViewController.h"
#import <QuartzCore/QuartzCore.h>
#import "PRSymbolViewController.h"
#import "Utility.h"
#import "Constant.h"

@implementation PRMapViewController

@synthesize mapView;
@synthesize activityView = _activityView;
@synthesize coordinate = _coordinate;
//@synthesize clManager = _clManager;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        UIBarButtonItem *aItem = [[UIBarButtonItem alloc] initWithTitle:@"Next" style:UIBarButtonItemStyleDone target:self action:@selector(next:)];
        [self.navigationItem setRightBarButtonItem:aItem animated:YES];
        [aItem release]; aItem = nil;
        
        UIImageView *titleView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:LOGO]];
        self.navigationItem.titleView = titleView;
        [titleView release]; titleView = nil;
    }
    return self;
}

#pragma mark - next:

-(void)next:(id)sender
{
    PRSymbolViewController *vc = [[PRSymbolViewController alloc] init];
    [Utility setImage:[self takeScreenShot]];
    [self.navigationController pushViewController:vc animated:YES];
    [vc release]; vc = nil;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    MKCoordinateSpan span;
    span.latitudeDelta = 0.00001;
    span.longitudeDelta = 0.00001;
    MKCoordinateRegion region;
    region.span = span;
    region.center = self.coordinate;
    [self.mapView setRegion:region animated:YES];
    self.mapView.showsUserLocation = YES;
    [self.mapView setMapType:MKMapTypeHybrid];
    [self.mapView setZoomEnabled:YES];
    
    /*UIImageView *compass = [[UIImageView alloc] initWithFrame:CGRectMake(650, 20, 45.0, 218.0)];
    compass.tag = 1;
    [compass setImage:[UIImage imageNamed:@"compass.png"]];
    [self.mapView addSubview:compass];
    [compass release]; compass = nil;
    
    
    self.clManager = [[CLLocationManager alloc] init];
    self.clManager.delegate = self;
    */
    UIActivityIndicatorView *activity = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite];
    activity.center = self.view.center;
    activity.hidden = NO;
    [activity startAnimating];
    self.activityView = activity;
    [activity release]; activity = nil;
}

- (void)mapViewWillStartLoadingMap:(MKMapView *)mapView
{
    [self.view addSubview:self.activityView];
}
- (void)mapViewDidFinishLoadingMap:(MKMapView *)mapView
{
    [self.activityView removeFromSuperview];
}
- (void)mapViewDidFailLoadingMap:(MKMapView *)mapView withError:(NSError *)error
{
    [self.activityView removeFromSuperview];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error!" message:@"Failed to load Map." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    [alert show];
    [alert release]; alert = nil;
}
/*
-(void)locationManager:(CLLocationManager *) manager didUpdateHeading:(CLHeading *) newHeading 
{
    if(newHeading)
    {
        UIImageView *imgView = (UIImageView *)[self.view viewWithTag:1];
        double rotation = newHeading.magneticHeading;
        CGAffineTransform transform = CGAffineTransformMakeRotation(-rotation *M_PI/180);
        if(imgView)
            [imgView setTransform:transform];
    }
}*/

-(UIImage *)takeScreenShot
{
    BOOL hasSuperView = NO;
    if([self.activityView superview])
    {
        hasSuperView = YES;
        [self.activityView removeFromSuperview];
    }
    CGRect frame = self.view.frame;
    UIGraphicsBeginImageContext(frame.size);
    [self.view.layer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage *screen = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    if(hasSuperView)
    {
        [self.view addSubview:self.activityView];
    }
    
    return screen;
}
/*
- (void)locationManager:(CLLocationManager *)manager
       didFailWithError:(NSError *)error
{
    if(error)
    {
        NSLog(@"Location Error = %@", [error description]);
    }
}*/


- (void)viewDidUnload
{
    [self setMapView:nil];
    self.activityView = nil;
    //self.clManager = nil;
    [super viewDidUnload];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    //[self.clManager startUpdatingHeading];
    [[NSUserDefaults standardUserDefaults] setInteger:0 forKey:KEY_SYMBOL_ADDED];
    [[NSUserDefaults standardUserDefaults] synchronize];
}
-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    //[self.clManager stopUpdatingHeading];
}
/*
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
	return YES;
}*/

- (void)dealloc {
    
    [mapView release];
    self.activityView = nil;
    //self.clManager = nil;
    
    [super dealloc];
}
@end
