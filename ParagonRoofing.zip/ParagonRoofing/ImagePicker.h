//
//  ImagePicker.h
//  RestroomCalibration
//
//  Created by Avik Roy on 03/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol CaptureImage;


@interface ImagePicker : NSObject
<UIActionSheetDelegate,UINavigationControllerDelegate,UIImagePickerControllerDelegate>
{
	id<CaptureImage> delegate;
	UIView *view;
	UIViewController *vc;
	
	UIPopoverController *popover;
}

@property (nonatomic,assign) id<CaptureImage> delegate;
@property (nonatomic,retain) UIView *view;
@property (nonatomic, retain) UIViewController *vc;

- (void)clickAddPictureAtViewController:(UIView *)view;
- (void)captureImageFormPhone;
- (void)PickImageForIndex;


@end


@protocol CaptureImage

- (void) didReceivePicture:(UIImage *)img;

@end

