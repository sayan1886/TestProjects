//
//  CustomDropDown.m
//  RiskManagementIpad
//
//  Created by Avik Roy on 5/1/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "CustomDropDown.h"
#import "DDTableViewController.h"

@implementation CustomDropDown

@synthesize popoverController,arrData,delegate,tag;

- (id)initWithArray:(NSArray *)arr andTag:(int)_tag
{
    if(self=[super init])
    {
        self.arrData=[[NSArray alloc] initWithArray:arr];
        self.tag=_tag;
    }
    return self;
}

- (void)showDropDownFromRect:(CGRect)frame atView:(UIView *)view
{
    if(![self.popoverController isPopoverVisible])
    {
		DDTableViewController *tviewController = [[[DDTableViewController alloc] initWithStyle:UITableViewStylePlain] autorelease] ;
        tviewController.arrData=self.arrData;
		self.popoverController = [[[UIPopoverController alloc] initWithContentViewController:tviewController] retain];
        tviewController.delegate=self;
		self.popoverController.delegate=self;
		[self.popoverController setPopoverContentSize:CGSizeMake(150.0f, 0.0f)];
        [self.popoverController presentPopoverFromRect:frame inView:view permittedArrowDirections:UIPopoverArrowDirectionUp animated:YES];
        
        [UIView animateWithDuration:0.3 
                         animations:^{
                             [self.popoverController setPopoverContentSize:CGSizeMake(150.0f, 185.0f)];
                         }
                         completion:^(BOOL completed){
            
                         }
        ];
	}
    else
    {
		[self.popoverController dismissPopoverAnimated:YES];
	}

}

#pragma mark - uipopovercontroller delegate

- (BOOL) popoverControllerShouldDismissPopover:(UIPopoverController *)popoverController
{
    [UIView animateWithDuration:0.2 
                     animations:^{
                         [self.popoverController setPopoverContentSize:CGSizeMake(150.0f, 0.0f)];
                     }
                     completion:^(BOOL completed){
                         
                     }
     ];
    return YES;
}

#pragma mark - selected value protocol delegate

- (void)didSelectValue:(NSString *)value
{
    [delegate selectedValue:value forTag:self.tag];
    [UIView animateWithDuration:0.2
                     animations:^{
                         [self.popoverController setPopoverContentSize:CGSizeMake(150.0f, 0.0f)];
                     }
                     completion:^(BOOL completed){
                         [self.popoverController dismissPopoverAnimated:YES];
                     }
     ];
}


- (void)dealloc
{
    [arrData release],self.arrData=nil;
    [popoverController release],self.popoverController=nil;
    [super dealloc];
}

@end
