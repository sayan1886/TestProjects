//
//  ImagePicker.m
//  RestroomCalibration
//
//  Created by Avik Roy on 03/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ImagePicker.h"
#import "Constant.h"

@implementation ImagePicker

@synthesize delegate;
@synthesize view, vc;

#pragma mark -
#pragma mark take picture

- (void)clickAddPictureAtViewController:(UIView *)view1
{
	
	view=view1;
	UIActionSheet *AC = [[UIActionSheet alloc]initWithTitle:@"ADD PHOTO\n" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"BROWSE PHOTO",@"TAKE FROM CAMERA",nil];
    AC.actionSheetStyle =UIActionSheetStyleBlackTranslucent;
    AC.delegate = self;
    [AC showInView:view];
}

#pragma mark -
#pragma mark <UIActionSheetDelegate>

-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
	if(buttonIndex == 0)
	{
		[self PickImageForIndex];
	}
	if(buttonIndex == 1)
	{
        [self captureImageFormPhone];
	}
}

#pragma mark -
#pragma mark <captureImageFormPhone>

- (void)captureImageFormPhone
{
	if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) 
	{		
		
		UIImagePickerController *camerapicker = [[UIImagePickerController alloc] init];
		
		camerapicker.delegate = self;
		camerapicker.sourceType = UIImagePickerControllerSourceTypeCamera;
		[camerapicker parentViewController];
        
        popover = [[UIPopoverController alloc]initWithContentViewController:camerapicker] ;
		
        [popover presentPopoverFromRect:CGRectMake(100,100, 100, 100) inView:view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
        [camerapicker release],camerapicker=nil;
		
	}
	else 
	{
		UIAlertView *alert1;
		alert1 = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"There is no Camera in the Device" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		alert1.tag=2;
		[alert1 show];
		[alert1 release],alert1=nil;
	}
}

#pragma mark -
#pragma mark <UIImagePickerControllerDelegate>

- (void)PickImageForIndex
{
	UIImagePickerControllerSourceType imgCtrlType;
	
    if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary])
	{
		imgCtrlType = UIImagePickerControllerSourceTypePhotoLibrary;
	}
	else if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeSavedPhotosAlbum])
	{
		imgCtrlType = UIImagePickerControllerSourceTypeSavedPhotosAlbum;
	}
	UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init]; 
	
	imagePicker.sourceType = imgCtrlType;
	
	imagePicker.delegate = self;
    popover = [[UIPopoverController alloc]initWithContentViewController:imagePicker] ;
		
    [popover presentPopoverFromRect:CGRectMake(100,100, 100, 100) inView:view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
    imagePicker=nil;
}

#pragma mark PhotoGalary Delegate Method

-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo
{ 
    [popover dismissPopoverAnimated:YES];
	popover = nil;
	[delegate didReceivePicture:image];
}

-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
	[popover dismissPopoverAnimated:YES];
    popover = nil;
} 


@end
