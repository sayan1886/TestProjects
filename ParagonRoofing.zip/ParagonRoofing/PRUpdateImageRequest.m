//
//  PRUpdateImageRequest.m
//  ParagonRoofing
//
//  Created by Manas Kumar Mandal on 26/04/12.
//  Copyright (c) 2012 ObjectSol Technologies. All rights reserved.
//

#import "PRUpdateImageRequest.h"

@implementation PRUpdateImageRequest

@synthesize _iSurveyId = __iSurveyId;
@synthesize _sFileName = __sFileName;
@synthesize _sImageType = __sImageType;
@synthesize _sImages64BaseStream = __sImages64BaseStream;

-(NSMutableString *)updateImageRequestString
{
    NSMutableString *mStr = [[NSMutableString alloc] init];
    
    [mStr appendString:@"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\" xmlns:ns=\"http://schemas.datacontract.org/2004/07/\"><soapenv:Header/><soapenv:Body><tem:UpdateImage><tem:objUploadPic>"];
    [mStr appendFormat:@"<ns:_iSurveyId>%@</ns:_iSurveyId>", self._iSurveyId];
    [mStr appendFormat:@"<ns:_sFileName>%@</ns:_sFileName>", self._sFileName];
    [mStr appendFormat:@"<ns:_sImageType>%@</ns:_sImageType>", self._sImageType];
    [mStr appendFormat:@"<ns:_sImages64BaseStream>%@</ns:_sImages64BaseStream>", self._sImages64BaseStream];
    [mStr appendString:@"</tem:objUploadPic></tem:UpdateImage></soapenv:Body></soapenv:Envelope>"];
    
    return mStr;
}

-(void)dealloc
{
    __iSurveyId = nil;
    __sFileName = nil;
    __sImageType = nil;
    __sImages64BaseStream = nil;
    [super dealloc];
}

@end
