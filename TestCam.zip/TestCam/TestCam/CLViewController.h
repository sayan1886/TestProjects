//
//  CLViewController.h
//  TestCam
//
//  Created by Sayan on 02/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CLViewController : UIViewController

@end
