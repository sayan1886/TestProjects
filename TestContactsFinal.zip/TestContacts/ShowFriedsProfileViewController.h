//
//  ShowFriedsProfileViewController.h
//  SKIIP
//
//  Created by Objectsol3 on 31/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AsyncImageView.h"
#import <QuartzCore/QuartzCore.h>


@interface ShowFriedsProfileViewController : UIViewController <UITextFieldDelegate,UITableViewDelegate, UITableViewDataSource>
{
	NSMutableDictionary *dictReceiveFriendList;
	NSMutableArray *arrTabContent;
	NSMutableArray *arrDetails;
	NSMutableDictionary *detialsDict;
	NSString *strImageUrl;
	NSMutableArray *arrList;
	NSMutableArray *secContent;
	NSMutableDictionary *sectionContent;
	NSMutableArray *arrForCheck;
	NSMutableDictionary *dictFriendRequest;
	BOOL bcheck;
	NSString *uid;
	//NSMutableArray *uidContent;
	//search bar
	UITextField *search;
	UITableView *searchTableView;
	BOOL searching;
	NSMutableArray *arrAfterSearch;
	UISegmentedControl *rqstCtrl;
	UIActivityIndicatorView *spinner;
	NSMutableDictionary *dictFrndSearch;
	NSString *strFriendCount;
	
}
-(void)bottomBar;

- (void)createTableView;
//-(id)initWithDict:(NSMutableDictionary*)dictFriendDictionary;
-(id)initWithDict:(NSMutableDictionary*)dictFriendDictionary  withFrequest:(NSString*)fRequest;

//-(void)createTable;

//- (void) showSkiipFriends;
- (void) createTableView;


@end
