    //
//  ShowFriedsProfileViewController.m
//  SKIIP
//
//  Created by Objectsol3 on 31/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ShowFriedsProfileViewController.h"
#import "SKIIPHelperObject.h"
#import "FriendsRequestConnectionParse.h"
#import "ShowFriendRequestViewController.h"
#import "FriendListConnectionParse.h"
#import "PromoterProfileViewController.h"
#import "SkiiperProfileViewController.h"
#import "FriendListSearchParse.h"
#import "FriendListSearchViewController.h"

@implementation ShowFriedsProfileViewController

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/
/*-(id)initWithDict:(NSMutableDictionary*)dictFriendDictionary
{
	self=[super init];
	if (self) {
		dictReceiveFriendList=dictFriendDictionary;
		NSLog(@"print dictionary description************%@",[dictReceiveFriendList description]);
	}
	return self;
	
}*/

-(id)initWithDict:(NSMutableDictionary*)dictFriendDictionary  withFrequest:(NSString*)fRequest
{
	self=[super init];
	if (self) {
		dictReceiveFriendList=dictFriendDictionary;
		NSLog(@"print dictionary description************%@",[dictReceiveFriendList description]);
		strFriendCount=[[NSString alloc]initWithString:fRequest];
		NSLog(@"no. of Friend request ==== %@",strFriendCount);
	}
	return self;
	
}


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	if (dictReceiveFriendList) {
		
	
		strImageUrl=[[NSString alloc]initWithString:(NSString*)[dictReceiveFriendList valueForKey:@"domain"]];
		//strImageUrl=[NSString stringWithFormat:@"%@",[dictReceiveFriendList objectForKey:@"domain"]];
		NSLog(@"image url================%@",strImageUrl);
		arrList=[[NSMutableArray alloc]initWithArray:[dictReceiveFriendList objectForKey:@"list"]];

		[arrList retain];
		sectionContent=[[NSMutableDictionary alloc]init];
		NSLog(@"array list**********%@",arrList);
		arrTabContent=[[NSMutableArray alloc]init];
		arrDetails = [[NSMutableArray alloc]init];
		//uidContent = [[NSMutableArray alloc]init];
		for (int i=0; i<[arrList count]; i++) {
			NSDictionary *dictFriendDetails=[arrList objectAtIndex:i];
			NSString *strName=[NSString stringWithFormat:@"%@",[dictFriendDetails objectForKey:@"sk_fname"]];
			strName=[strName stringByAppendingString:@" "];
			strName=[strName stringByAppendingFormat:@"%@",[dictFriendDetails objectForKey:@"sk_lname"]];
			[arrTabContent addObject:strName];
			[arrDetails addObject:dictFriendDetails];
			//[uidContent addObject:[dictFriendDetails objectForKey:@"sk_id"]];
		}
		
	}
		
	NSLog(@"Arrdetails : %@",arrDetails);
	
	
	arrAfterSearch = [[NSMutableArray alloc]init];
	UIView *searchView = [[UIView alloc]initWithFrame:CGRectMake(0,0,320,44)];
	searchView.backgroundColor = [UIColor clearColor];
	
	UIImageView *backgroundView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"skiiplist_black_bar.png"]];
	backgroundView.frame = CGRectMake(0, 0, 320, 44);
	[searchView addSubview:backgroundView];
	[backgroundView release];
	
	UIImageView *backView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"skiiplist_search_field.png"]];
	backView.frame = CGRectMake(6, 6, 308, 33);
	[searchView addSubview:backView];
	[backView release];
	
	
	UIImageView *searchLogo = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"skiiplist_search_icon.png"]];
	searchLogo.frame = CGRectMake(12, 12, 19, 19);
	[searchView addSubview:searchLogo];
	[searchLogo release];
	
	search=[[UITextField alloc]initWithFrame:CGRectMake(32,6,280,33)];
	search.autocorrectionType = UITextAutocorrectionTypeNo;
	//search.placeholder = @"e.g. hip hop, bar, DJ Vice ";
	search.borderStyle = UITextBorderStyleRoundedRect;
	search.borderStyle = UITextBorderStyleNone;
	search.clearButtonMode = UITextFieldViewModeWhileEditing;
	search.contentHorizontalAlignment=UIControlContentHorizontalAlignmentCenter;
	search.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
	search.font = [UIFont boldSystemFontOfSize:14];
	[searchView addSubview:search];
	[search addTarget:self action:@selector(didSearchText) forControlEvents:UIControlEventEditingChanged];
	search.delegate = self;
	
	[self.view addSubview:searchView];
	[searchView release];
	searching = NO;
	secContent = [[NSMutableArray alloc]initWithObjects:@"A",@"B",@"C",@"D",@"E",@"F",@"G",@"H",@"I",@"J",@"K",@"L",@"M",@"N",@"O",@"P",@"Q",@"R",@"S",@"T",@"U",@"V",@"W",@"X",@"Y",@"Z",nil];
	detialsDict = [[NSMutableDictionary alloc]init];
	//NSLog(@"Table : %@",imgArr);
	int count = 0;
	for(char c = 'A'; c <= 'Z'; c++){
		NSMutableArray *tempDict =[[NSMutableArray alloc]init];
		NSMutableArray *tempArr = [[NSMutableArray alloc]init];
		for (int i=0; i < [arrTabContent count]; i++) {
			NSString *str=[[arrTabContent objectAtIndex:i]substringToIndex:1];
			if ([str isEqualToString:[NSString stringWithFormat:@"%c",c]]) {
				[tempDict addObject:[arrTabContent objectAtIndex:i]];
				[tempArr addObject:[arrDetails objectAtIndex:i]];
				//[tempDict addObject:[uidContent objectAtIndex:i]];
			}
			
		}
		NSString *key = (NSString *)[secContent objectAtIndex:count++];
		[sectionContent setValue:tempDict forKey:key];
		[detialsDict setValue:tempArr forKey:key];
		//[sectionContent setValue:tempDict forKey:[NSString stringWithFormat:@"%@",[secContent objectAtIndex:count++]]];
		[tempDict release];		
		[tempArr release];
	}
		
	NSLog(@"Details Dict : %@",detialsDict);
	UIButton *goHome = [UIButton buttonWithType:UIButtonTypeCustom];
	[goHome setImage:[UIImage imageNamed:@"back_inactive.png"] forState:UIControlStateNormal];
	goHome.frame=CGRectMake(-10,0,71,35);
	goHome.tag=1;
	goHome.backgroundColor=[UIColor clearColor];
	//[logout setTitle:@"Accept" forState:UIControlStateNormal];
	[goHome addTarget:self action:@selector(goHome:) forControlEvents:UIControlEventTouchUpInside];
	UIBarButtonItem *goHomeBarButton = [[UIBarButtonItem alloc] initWithCustomView:goHome];
	self.navigationItem.leftBarButtonItem = goHomeBarButton;
	[goHomeBarButton release];
	
	//[self createTableView];
	
	//[self bottomBar];
}
- (void) viewWillAppear:(BOOL)animated{
	[super viewWillAppear:YES];
	[self createTableView];
	[self bottomBar];
	[rqstCtrl setSelectedSegmentIndex:0];
}

- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView {
	
	
	NSMutableArray *toBeReturned = [[NSMutableArray alloc]init];
	
	for(char c = 'A'; c <= 'Z'; c++) [toBeReturned addObject:[NSString stringWithFormat:@"%c",c]];
	
	return [toBeReturned autorelease];
	
}


- (void) createTableView
{
	if (searchTableView) {
		[searchTableView reloadData];
	}
	searchTableView =[[UITableView alloc] initWithFrame:CGRectMake(0, 44, 320, 322) style:UITableViewStylePlain];
	searchTableView.delegate = self;
	searchTableView.dataSource = self;
	searchTableView.autoresizesSubviews = YES;
	searchTableView.scrollEnabled = YES;
	searchTableView.showsVerticalScrollIndicator = NO;
	searchTableView.backgroundColor = [UIColor clearColor];
	[self.view addSubview:searchTableView];
}
-(void)search
{
	NSString *searchText = search.text;
	NSInteger len=searchText.length;
	NSMutableArray *searchArray = [[NSMutableArray alloc] init];
	//[self readData];
	for(int i=0;i<[arrTabContent count];i++)
	{
		[searchArray addObject:[arrTabContent objectAtIndex:i]];
	}
	for(int i=0;i<[searchArray count];i++)
	{
		NSString *name= [searchArray objectAtIndex:i];
		if(name.length<len)
		{
			continue;
		}
		NSString *str=[name substringToIndex:len];
		if([searchText caseInsensitiveCompare:str]==0)
		{
			[arrAfterSearch addObject:[searchArray objectAtIndex:i]];
		}
	}
	[searchArray release];
	searchArray = nil;
}

-(void)didSearchText{
	[arrAfterSearch removeAllObjects];
	if([search.text length] > 0)
	{
		searching = YES;
		[self search];
	}
	else 
	{
		searching = NO;
	}
	[searchTableView reloadData];
	
}



-(void)bottomBar
{
	UIToolbar *toolMsg=[[UIToolbar alloc]initWithFrame:CGRectMake(0, 324, 320, 44)];
	toolMsg.tintColor=[UIColor colorWithRed:94.0/255.0 green:158.0/255.0 blue:84.0/255.0 alpha:0.5];
	[self.view addSubview:toolMsg];
	//[tool release];
	[toolMsg release];
	//NSArray *arr = [[NSArray alloc]initWithObjects:@"Friends",@"Requests",nil];
	NSArray *arr = [[NSArray alloc]initWithObjects:@"Friends",@"Everyone",@"Request",nil];

	
	UISegmentedControl *styleSegmentedControlsent = [[UISegmentedControl alloc] initWithItems:arr];
	[styleSegmentedControlsent addTarget:self action:@selector(didSelectPaymentMode:) forControlEvents:UIControlEventValueChanged];
	styleSegmentedControlsent.segmentedControlStyle = UISegmentedControlStyleBar;
	styleSegmentedControlsent.backgroundColor = [UIColor clearColor];
	styleSegmentedControlsent.tintColor=[UIColor colorWithRed:94.0/255.0 green:158.0/255.0 blue:84.0/255.0 alpha:0.5];
	styleSegmentedControlsent.selectedSegmentIndex=0;
	[styleSegmentedControlsent sizeToFit];
	styleSegmentedControlsent.frame = CGRectMake(60,330,200,32);
	[self.view addSubview:styleSegmentedControlsent];
	rqstCtrl = nil;
	rqstCtrl = styleSegmentedControlsent;
	[styleSegmentedControlsent release], styleSegmentedControlsent=nil;
	[arr release], arr = nil;
	//friend request count
	if (strFriendCount!=0) {
		
	
	UILabel *lblfReqstCount=[[UILabel alloc]init];
	CALayer * l = [lblfReqstCount layer];
	[l setMasksToBounds:YES];
	[l setCornerRadius:18.0];
	lblfReqstCount.frame=CGRectMake(240, 322, 26, 26);
	lblfReqstCount.textAlignment=UITextAlignmentCenter;
	lblfReqstCount.textColor=[UIColor whiteColor];
	lblfReqstCount.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"red_notification_icon.png"]];
	//[btnChatButton addSubview:lblChatCount];
	[self.view addSubview:lblfReqstCount];
	//app.strChatCountShow=[[arrNewResponse objectAtIndex:0] stringByAppendingFormat:@"%@",@"+"];
	lblfReqstCount.text=strFriendCount;
	[lblfReqstCount release],lblfReqstCount=nil;
		}
	
	
}
-(void)didSelectPaymentMode:(id)sender
{
	UISegmentedControl *seg = (UISegmentedControl*)sender;
	switch (seg.selectedSegmentIndex) {
		case 0:{
			
			//seg.selectedSegmentIndex=-1;
		}
			break;
		case 1:{
			spinner = [[UIActivityIndicatorView alloc]
					   initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
			spinner.center = CGPointMake(170,346);
			spinner.autoresizingMask = (UIViewAutoresizingFlexibleLeftMargin |
										UIViewAutoresizingFlexibleRightMargin |
										UIViewAutoresizingFlexibleTopMargin |
										UIViewAutoresizingFlexibleBottomMargin);
			spinner.backgroundColor=[UIColor clearColor];
			spinner.opaque=YES;
			[self.view addSubview:spinner];
			[spinner startAnimating];
			
			
			NSDictionary *response = [SKIIPHelperObject getData];
			NSLog(@"Raeponse : %@",response);
			NSMutableDictionary *dictResponse=[[NSDictionary alloc]initWithDictionary:[response objectForKey:@"skiip"]];
			//dictResponse=[response objectForKey:@"skiip"];
			NSArray *arrResponse=[NSArray arrayWithArray:(NSArray*)[dictResponse objectForKey:@"login_info"]];
			NSString *strId=[[arrResponse objectAtIndex:0]valueForKey:@"sk_id" ];
			NSLog(@"print id**********%@",strId);
			[dictResponse release];
			FriendListSearchParse *aFriendListSearchParse=[[FriendListSearchParse alloc]initWithFriendResult:self sndr:@selector(frndSearchResult:) sndrError:@selector(getErrorResponse) Uid:strId];
			[aFriendListSearchParse friendSearchConnection];
			[aFriendListSearchParse release];
			
			
					}
			break;
			
			case 2:{
								
				spinner = [[UIActivityIndicatorView alloc]
						   initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
				spinner.center = CGPointMake(230,346);
				spinner.autoresizingMask = (UIViewAutoresizingFlexibleLeftMargin |
											UIViewAutoresizingFlexibleRightMargin |
											UIViewAutoresizingFlexibleTopMargin |
											UIViewAutoresizingFlexibleBottomMargin);
				spinner.backgroundColor=[UIColor clearColor];
				spinner.opaque=YES;
				[self.view addSubview:spinner];
				[spinner startAnimating];
				
				
				NSDictionary *response = [SKIIPHelperObject getData];
				NSLog(@"Raeponse : %@",response);
				NSMutableDictionary *dictResponse=[[NSDictionary alloc]initWithDictionary:[response objectForKey:@"skiip"]];
				//dictResponse=[response objectForKey:@"skiip"];
				NSArray *arrResponse=[NSArray arrayWithArray:(NSArray*)[dictResponse objectForKey:@"login_info"]];
				NSString *strId=[[arrResponse objectAtIndex:0]valueForKey:@"sk_id" ];
				NSLog(@"print id**********%@",strId);
				//uid = [[NSString alloc]initWithString:strId];
				//[uid retain];
				[dictResponse release];
				FriendsRequestConnectionParse *aFriendsRequestConnectionParse=[[FriendsRequestConnectionParse alloc]initWithFrndRequest:self sndr:@selector(FrndRequestDetails:) UId:strId];
				[aFriendsRequestConnectionParse friendRequestConnection];
				[aFriendsRequestConnectionParse release];
				
				
				//seg.selectedSegmentIndex=-1;
				
		
			
		}
				break;

		default:
			break;
	}                
}
- (void) goHome:(id)sender{
	[self.navigationController popViewControllerAnimated:YES];
	
}
-(void)frndSearchResult:(NSMutableDictionary*)dictResponse
{
	[spinner stopAnimating];
	dictFrndSearch=dictResponse;
	NSLog(@"friend search description %@",dictFrndSearch);
	if ([[dictFrndSearch valueForKey:@"result"] isEqualToString:@"true"]) 
	{
		FriendListSearchViewController *aFriendListSearchViewController=[[[FriendListSearchViewController alloc]initWithFrndDict:dictFrndSearch]autorelease];
		[self.navigationController pushViewController:aFriendListSearchViewController animated:YES];
		//[aFriendListSearchViewController release];
		
		NSLog(@"success");
	}
}
-(void)getErrorResponse
{
	UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:@"Info" 
														  message:@"Connection Failed" 
														 delegate:self 
												cancelButtonTitle:@"OK" 
												otherButtonTitles:nil];
	[alertWarning show];
	[alertWarning release];
}

//show friendslist
//- (void) showSkiipFriends{
//	NSDictionary *response = [SKIIPHelperObject getData];
//	NSLog(@"Raeponse : %@",response);
//	NSMutableDictionary *dictResponse=[[NSDictionary alloc]initWithDictionary:[response objectForKey:@"skiip"]];
//	//dictResponse=;
//	NSArray *arrResponse=[NSArray arrayWithArray:(NSArray*)[dictResponse objectForKey:@"login_info"]];
//	NSString *strId=[[arrResponse objectAtIndex:0]valueForKey:@"sk_id" ];
//	NSLog(@"print id**********%@",strId);
//	uid = [NSString stringWithFormat:@"%@",strId];
//	[dictResponse release];
//	FriendListConnectionParse *aFriendListConnectionParse=[[FriendListConnectionParse alloc]initWithFriendList:self sndr:@selector(friendListView:) UId:strId];
//	[aFriendListConnectionParse FriendConnection];
//	[aFriendListConnectionParse release];
//	NSLog(@"Friends");	
//}
//
//-(void)friendListView:(NSMutableDictionary*)dictResponse{
//	//dictFriendResponse=dictResponse;
//	if ([[dictResponse objectForKey:@"result"] isEqualToString:@"true"]) {
//		ShowFriedsProfileViewController *aShowFriedsProfileViewController=[[[ShowFriedsProfileViewController alloc]initWithDict:dictResponse]autorelease];
//		[self.navigationController pushViewController:aShowFriedsProfileViewController animated:YES];
//		//[aShowFriedsProfileViewController release];
//	}
//	
//}

-(void)FrndRequestDetails:(NSMutableDictionary*)dictResponse
{
	[spinner stopAnimating];
	dictFriendRequest=dictResponse;
	if ([[dictFriendRequest objectForKey:@"result"] isEqualToString:@"true"]) 
	{
		ShowFriendRequestViewController *aShowFriendRequestViewController=[[[ShowFriendRequestViewController alloc]initWithDictFriend:dictFriendRequest]autorelease];
		[self.navigationController pushViewController:aShowFriendRequestViewController animated:YES];
		NSLog(@"friend request");
	}
	else {
		UIAlertView *alertWarning = [[UIAlertView alloc]initWithTitle:@"Info" 
															  message:@"No Friend Request Found" 
															 delegate:self 
													cancelButtonTitle:@"OK" 
													otherButtonTitles:nil];
		[alertWarning show];
		[alertWarning release];
	}

	
}
#pragma mark -
#pragma mark UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
	[textField resignFirstResponder];
	return YES;
}

#pragma mark -
#pragma mark UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
	if (searching) {
		return 1;
	}
	else {
		return [secContent count];
	}
	
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
	if (searching) {
		return [NSString stringWithString:@""];	
	}
	else if ([[sectionContent objectForKey:[NSString stringWithFormat:@"%@",[secContent objectAtIndex:section]]] count] == 0) {
		return [NSString stringWithString:@""];
	}
	else{
		return [secContent objectAtIndex:section];
	}
	
}

#pragma mark -
#pragma mark UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
	return 80;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
	if (searching) {
		return [arrAfterSearch count];
	}
	else {
		return [[sectionContent objectForKey:[NSString stringWithFormat:@"%@",[secContent objectAtIndex:section]]] count];
	}
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
	static NSString *nilCellIdentifier = @"nil";
	static NSString *cellIdentifier = @"Cell";
	UITableViewCell *cell;
	UIView *cellView = [[UIView alloc]initWithFrame:CGRectMake(0, 2, 300, 50)];
	UILabel *cellLabel = [[UILabel alloc]initWithFrame:CGRectMake(80, 5, 200, 40)];
	if (cell == nil) {
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nilCellIdentifier] autorelease];
		//cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
		cell.selectionStyle = UITableViewCellSelectionStyleGray;
	}
	else {
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
		//cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
		cell.selectionStyle = UITableViewCellSelectionStyleGray;
	}
	if (searching) {
		cellLabel.text = [arrAfterSearch objectAtIndex:indexPath.row];
	}
	else {
		cellLabel.text = [[sectionContent objectForKey:[NSString stringWithFormat:@"%@",[secContent objectAtIndex:indexPath.section]]] objectAtIndex:indexPath.row];
	}
	//asynchronous image********
	NSMutableArray *arr1 = [[NSMutableArray alloc] init];
	bcheck=NO;
	int i;
	for(i=0;i<[arrForCheck count];i++)
	{
		if(indexPath.row==[[[arrForCheck objectAtIndex:i] objectAtIndex:1] intValue] && indexPath.section==[[[arrForCheck objectAtIndex:i] objectAtIndex:2] intValue])
		{
			bcheck=YES;
			break;
		}
	}
	NSMutableString *strmImageLogo=[[NSMutableString alloc] initWithString:strImageUrl];
	id data=[arrList objectAtIndex:indexPath.row];
	NSDictionary *dictTemp=(NSDictionary*)data;
	data=nil;
	data=[dictTemp valueForKey:@"profile_img"];
	
	NSString *strImage=(NSString*)data;
	//[NSString stringWithString:[[arrresponse objectAtIndex:indexPath.row]objectForKey:@"profile_img"]];
	[strmImageLogo appendString:strImage];
	NSLog(@"show image url*********%@",strImage);
	//strImageLogo = [strImageLogo stringByAppendingString:strImage];
	NSLog(@"Url : %@",strmImageLogo);
	AsyncImageView* asyncImage = [[[AsyncImageView alloc] initWithFrame:CGRectMake(2, 10, 60, 60)] autorelease];
	if(!bcheck)
	{
		[asyncImage loadImageFromURL:[NSURL URLWithString:strmImageLogo]];
		[cell.contentView addSubview:asyncImage];
		[arr1 addObject:asyncImage];
	}
	else
	{
		[cell.contentView addSubview:[[arrForCheck objectAtIndex:i] objectAtIndex:0]];
	}	
	
	if(!bcheck)
	{
		[arr1 addObject:[NSString stringWithFormat:@"%d",indexPath.row]];
		[arr1 addObject:[NSString stringWithFormat:@"%d",indexPath.section]];
		[arrForCheck addObject:arr1];
		[arrForCheck retain];
	}
	else
		bcheck = NO; //***********changed
	[arr1 release],arr1=nil; 
	cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
	
    cellLabel.font = [UIFont boldSystemFontOfSize:20];
	[cellView addSubview:cellLabel];
	[cellLabel release];
	[cell addSubview:cellView];
	[cellView release];
	return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath 
{
	//uid = [NSString stringWithFormat:@"%@",[[arrList objectAtIndex:indexPath.row]objectForKey:@"sk_id"]];
	//NSLog(@"SK_ID: %@",uid);
	NSString *strSection=[NSString stringWithString:[secContent objectAtIndex:indexPath.section]];
	//NSLog(@"printtttttttttttt==%@",strSection);
	NSMutableArray *arrtemp=[[NSMutableArray alloc]initWithArray:[detialsDict objectForKey:strSection]];
	NSDictionary *dictFriend=[NSDictionary dictionaryWithDictionary:(NSDictionary*)[arrList objectAtIndex:indexPath.row]];
	NSLog(@"Details : %@",arrtemp);
	NSLog(@"DiCtFriend:%@",dictFriend);
	NSString *key = [NSString stringWithFormat:@"%@",[[arrtemp objectAtIndex:indexPath.row] objectForKey:@"sk_type"]];
	if ([key isEqualToString:@"1"]) {
		SkiiperProfileViewController *aSkiiperProfile = [[[SkiiperProfileViewController alloc]initWithDetails:[arrtemp objectAtIndex:indexPath.row] andUid:[[arrtemp objectAtIndex:indexPath.row] objectForKey:@"sk_id"]]autorelease];
		//[FriendListConnectionParse setCurrentUserId:[[arrtemp objectAtIndex:indexPath.row] objectForKey:@"sk_id"]];
		[self.navigationController pushViewController:aSkiiperProfile animated:YES];
	}
	else {
		//NSLog(@"description of the dictionary *************%@",[dictFriend description]);
		PromoterProfileViewController *aPromoter=[[[PromoterProfileViewController alloc]initWithDetails:[arrtemp objectAtIndex:indexPath.row] isPromoter:NO]autorelease];
		[self.navigationController pushViewController:aPromoter animated:YES];
		[FriendListConnectionParse setCurrentUserId:[[arrtemp objectAtIndex:indexPath.row] objectForKey:@"sk_id"]];
	}
	[arrtemp release];
	
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
