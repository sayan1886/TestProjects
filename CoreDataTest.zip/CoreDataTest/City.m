// 
//  City.m
//  CoreDataTest
//
//  Created by Björn Sållarp on 2009-06-10.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "City.h"

#import "Province.h"

@implementation City 

@dynamic Name;
@dynamic CityToProvince;

@end
