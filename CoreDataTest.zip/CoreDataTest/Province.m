// 
//  Province.m
//  CoreDataTest
//
//  Created by Björn Sållarp on 2009-06-10.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "Province.h"


@implementation Province 

@dynamic Name;
@dynamic ProvinceToCity;
@dynamic ProvinceToCounty;

@end
