// 
//  County.m
//  CoreDataTest
//
//  Created by Björn Sållarp on 2009-06-10.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "County.h"

#import "Province.h"

@implementation County 

@dynamic Name;
@dynamic CountyToProvince;

@end
