//
//  SHTAppDelegate.h
//  SHTestTweet
//
//  Created by Sayan on 11/10/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class SHTViewController;

@interface SHTAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) SHTViewController *viewController;

@end
