//
//  SHTViewController.h
//  SHTestTweet
//
//  Created by Sayan on 11/10/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SHTViewController : UIViewController
- (IBAction)Tweet:(id)sender;
- (IBAction)facebook:(id)sender;

@end
