//
//  SHTViewController.m
//  SHTestTweet
//
//  Created by Sayan on 11/10/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "SHTViewController.h"
#import "DETweetComposeViewController.h"
#import "DEFacebookComposeViewController.h"
#import <FacebookSDK/FacebookSDK.h>

@interface SHTViewController ()

@end

@implementation SHTViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (IBAction)Tweet:(id)sender {
    
    DETweetComposeViewControllerCompletionHandler completionHandler = ^(DETweetComposeViewControllerResult result) {
        switch (result) {
            case DETweetComposeViewControllerResultCancelled:
                NSLog(@"Twitter Result: Cancelled");
                break;
            case DETweetComposeViewControllerResultDone:
                NSLog(@"Twitter Result: Sent");
                break;
        }
        [self dismissModalViewControllerAnimated:YES];
    };
    
    DETweetComposeViewController *tcvc = [[[DETweetComposeViewController alloc] init] autorelease];
    self.modalPresentationStyle = UIModalPresentationCurrentContext;
    [self addTweetContent:tcvc];
    tcvc.completionHandler = completionHandler;
    
    // Optionally, set alwaysUseDETwitterCredentials to YES to prevent using
    //  iOS5 Twitter credentials.
    //    tcvc.alwaysUseDETwitterCredentials = YES;
    [self presentModalViewController:tcvc animated:YES];
}

- (void)addTweetContent:(id)tcvc
{
    [tcvc addImage:[UIImage imageNamed:@"image.PNG"]];
    [tcvc addURL:[NSURL URLWithString:@"http://www.objectsol.in/"]];
    NSString *tweetText = @"Dummy Text";
    [tcvc setInitialText:tweetText];
}


- (IBAction)facebook:(id)sender {
    DEFacebookComposeViewController *facebookViewComposer = [[DEFacebookComposeViewController alloc] init];
    self.modalPresentationStyle = UIModalPresentationCurrentContext;
    [facebookViewComposer setInitialText:@"Dummy Text"];
    
    // optional
    [facebookViewComposer addImage:[UIImage imageNamed:@"image.PNG"]];
    // or
    // optional
    //    [facebookViewComposer addURL:@"http://applications.3d4medical.com/heart_pro.php"];
    
    [facebookViewComposer setCompletionHandler:^(DEFacebookComposeViewControllerResult result) {
        switch (result) {
            case DEFacebookComposeViewControllerResultCancelled:
                NSLog(@"Facebook Result: Cancelled");
                break;
            case DEFacebookComposeViewControllerResultDone:
                NSLog(@"Facebook Result: Sent");
                break;
        }
        
        [self dismissModalViewControllerAnimated:YES];
    }];
    
    [self presentViewController:facebookViewComposer animated:YES completion:^{ }];
    
    [facebookViewComposer release];
}


@end
