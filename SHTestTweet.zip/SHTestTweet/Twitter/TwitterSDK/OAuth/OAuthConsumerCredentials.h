//#error Use your Twitter keys from developer.twitter.com

#define kDEConsumerKey @"48Ii81VO5NtDKIsQDZ3Ggw"

#define kDEConsumerSecret @"WYc2HSatOQGXlUCsYnuW3UjrlqQj0xvkvvOIsKek32g"
