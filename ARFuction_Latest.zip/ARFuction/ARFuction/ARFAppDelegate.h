//
//  ARFAppDelegate.h
//  ARFuction
//
//  Created by Sayan on 14/06/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

	//com.visualized.Silkeborg


@class ARFViewController;

@interface ARFAppDelegate : UIResponder <UIApplicationDelegate>{
		    BOOL beforeWasLandscape;

}

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ARFViewController *viewController;

-(void)setViewToLandscape:(UIView*)viewObject;
-(void)setViewToPortrait:(UIView*)viewObject;

@end
