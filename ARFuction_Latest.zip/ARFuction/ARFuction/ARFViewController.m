//
//  ARFViewController.m
//  ARFuction
//
//  Created by Sayan on 14/06/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ARFViewController.h"
#import "JsonHandler.h"
#import "DataSource.h"
#import <QuartzCore/QuartzCore.h>

#define VIEWPORT_WIDTH_RADIANS 0.5
#define VIEWPORT_HEIGHT_RADIANS .7392
#define RADIUSKEY @"radius"
#define kFilteringFactor 0.05
#define BOX_WIDTH 150
#define BOX_HEIGHT 100
#define CAMERA_TRANSFORM 1.12412
#define degreesToRadian(x) (M_PI * (x) / 180.0)

@interface ARFViewController ()

@end

@implementation ARFViewController

@synthesize centerCoordinate;
@synthesize centerLocation;
@synthesize data;
@synthesize scaleViewsBasedOnDistance;
@synthesize rotateViewsBasedOnPerspective;
@synthesize maximumScaleDistance;
@synthesize minimumScaleFactor;
@synthesize maximumRotationAngle;
@synthesize locationManager;
@synthesize accelerometerManager;
@synthesize coordinates = ar_coordinates;
@synthesize cameraController;

#pragma mark - ViewLifeCycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
	ar_overlayView = (MarkerView *)[[UIView alloc] initWithFrame:CGRectZero];
	radarView = [[Radar alloc]initWithFrame:CGRectMake(10, 10, 61, 61)];	
    radarViewPort = [[RadarViewPortView alloc]initWithFrame:CGRectMake(10, 10, 61, 61)];
	self.view = ar_overlayView;
	[ar_overlayView addSubview:radarView];
	[ar_overlayView addSubview:radarViewPort];
	[ar_overlayView addSubview:controlView];
	scaleViewsBasedOnDistance = YES;
	minimumScaleFactor = 0.6;
	rotateViewsBasedOnPerspective = YES;
	((UISlider *)[controlView viewWithTag:11]).value = [[[NSUserDefaults standardUserDefaults] valueForKey:RADIUSKEY] floatValue];
	((UILabel *)[self.view viewWithTag:12]).text = [NSString stringWithFormat:@"%.2f km",((UISlider *)[controlView viewWithTag:11]).value];
	[self startListening];

}

- (void)viewDidUnload
{
	[controlView release];
	controlView = nil;
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (void) viewDidAppear:(BOOL)animated{
	[super viewDidAppear:animated];
	if (!_updateTimer) {
		_updateTimer = [[NSTimer scheduledTimerWithTimeInterval:self.updateFrequency
														 target:self
													   selector:@selector(updateLocations:)
													   userInfo:nil
														repeats:YES] retain];
	}
	[self openCameraView];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return YES;
		//(interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}


#pragma mark - Initializer

- (id) initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil andLocationManager:(CLLocationManager *)manager {
	
	if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {	
		//use the passed in location manager instead of ours.
		ar_coordinates = [[NSMutableArray alloc] init];
		ar_coordinateViews = [[NSMutableArray alloc] init];
		
		_updateTimer = nil;
		self.updateFrequency = 1 / 20.0;
		
#if !TARGET_IPHONE_SIMULATOR
		
		self.cameraController = [[[UIImagePickerController alloc] init] autorelease];
		self.cameraController.sourceType = UIImagePickerControllerSourceTypeCamera;
		CGAffineTransform cameraTransform = CGAffineTransformMakeScale(1.232, 1.232);
		self.cameraController.cameraViewTransform = cameraTransform;//CGAffineTransformScale(self.cameraController.cameraViewTransform, 1.23f,  1.23f);
		
		self.cameraController.showsCameraControls = NO;
		self.cameraController.navigationBarHidden = YES;
#endif
		self.scaleViewsBasedOnDistance = NO;
		self.maximumScaleDistance = 0.0;
		self.minimumScaleFactor = 1.5;
		
		self.rotateViewsBasedOnPerspective = YES;
		self.maximumRotationAngle = M_PI / 6.0;
		
		self.wantsFullScreenLayout = NO;
		oldHeading = 0;

		self.locationManager = manager;
	}
	return self;
}

#pragma  mark - GetterSetter

- (double) updateFrequency{
	return updateFrequency;
}

- (void)setUpdateFrequency:(double)newUpdateFrequency {
	
	updateFrequency = newUpdateFrequency;
	
	if (!_updateTimer) return;
	
	[_updateTimer invalidate];
	[_updateTimer release];
	
	_updateTimer = [[NSTimer scheduledTimerWithTimeInterval:self.updateFrequency
													 target:self
												   selector:@selector(updateLocations:)
												   userInfo:nil
													repeats:YES] retain];
}

#pragma mark - ClassMethods

- (void)setCenterLocation:(CLLocation *)newLocation {
	[centerLocation release];
	centerLocation = [newLocation retain];
	
	for (PhysicalPlace *geoLocation in self.coordinates) {
		if ([geoLocation isKindOfClass:[PhysicalPlace class]]) {
			[geoLocation calibrateUsingOrigin:centerLocation];
			
			if (geoLocation.radialDistance > self.maximumScaleDistance) {
				self.maximumScaleDistance = geoLocation.radialDistance;
			}
		}
	}
}

- (IBAction)radiusChanged:(UISlider *)sender {
	NSLog(@"RADIUS : %.2f",sender.value);
	[self removeCoordinates:data];
	((UILabel *)[self.view viewWithTag:12]).text = [NSString stringWithFormat:@"%.2f km",sender.value];
	[[NSUserDefaults standardUserDefaults] setValue:[NSString stringWithFormat:@"%.2f",sender.value] forKey:RADIUSKEY];
	[[NSUserDefaults standardUserDefaults] synchronize];
}


#pragma mark - Controls

- (void) openCameraView{
#if !TARGET_IPHONE_SIMULATOR
	[self.cameraController setCameraOverlayView:ar_overlayView];
	[self presentModalViewController:self.cameraController animated:NO];
	
	[ar_overlayView setFrame:self.cameraController.view.bounds];
#endif
}

-(void)closeCameraView{
#if !TARGET_IPHONE_SIMULATOR
	[self.cameraController.view removeFromSuperview];
#endif
}

-(void)stopListening{
	if(self.locationManager != nil){
		[locationManager stopUpdatingHeading];
		[locationManager stopUpdatingLocation];
	}
}
- (void)startListening {
	
		//start our heading readings and our accelerometer readings.
	
	if (!self.locationManager) {
		self.locationManager = [[[CLLocationManager alloc] init] autorelease];
	}
		//we want every move.
	self.locationManager.headingFilter = kCLHeadingFilterNone;
	self.locationManager.desiredAccuracy = kCLLocationAccuracyBest;
	[self.locationManager startUpdatingLocation];
	[self.locationManager startUpdatingHeading];
	
	
		//steal back the delegate.
	self.locationManager.delegate = self;
	
	if (!self.accelerometerManager) {
		self.accelerometerManager = [UIAccelerometer sharedAccelerometer];
		self.accelerometerManager.updateInterval = 0.01;
		self.accelerometerManager.delegate = self;
	}
	
	if (!self.centerCoordinate) {
		self.centerCoordinate = [PoiItem coordinateWithRadialDistance:0 inclination:0 azimuth:0];
	}
}

#pragma mark - Download POI'S

- (void) downloadPOIS{
	JsonHandler *jHandler = [[JsonHandler alloc]init];
		//CLLocation * pos = userCurrentLocation;
	NSString * wikiData = @"";
		//    NSString * mixareData = nil;
		//    NSString * twitterData;
		//	NSString * buzzData;
	UISlider *slider = ((UISlider *)[self.view viewWithTag:11]);
    float radius = slider.value;

	if([self checkIfDataSourceIsEanabled:@"Wikipedia"]){
        NSLog(@"Downloading WIki data");
        NSString   *language = [[NSLocale preferredLanguages] objectAtIndex:0];
        NSLog(@"Language: %@",language);
        wikiData = [[NSString alloc]initWithContentsOfURL:[NSURL URLWithString:[DataSource createRequestURLFromDataSource:@"WIKIPEDIA" Lat:centerLocation.coordinate.latitude Lon:centerLocation.coordinate.longitude Alt:centerLocation.altitude radius:radius Lang:language]] encoding:NSUTF8StringEncoding error:nil];
        NSLog(@"Download done");
    }else {
        wikiData = nil;
    }
	[data removeAllObjects];
    if(wikiData != nil){
        self.data= [jHandler processWikipediaJSONData:wikiData];
        NSLog(@"data count: %d", [data count]);
        [wikiData release];
    }
	[jHandler release];
	[self mapData];
}

-(BOOL)checkIfDataSourceIsEanabled: (NSString *)source{
    BOOL ret = NO;
    if(![source isEqualToString:@""]){
        if([[NSUserDefaults standardUserDefaults] objectForKey:source]!=nil){
            if([[[NSUserDefaults standardUserDefaults] objectForKey:source] isEqualToString:@"TRUE"]){
                ret = YES;
            }
        }
    }
    return ret;
}

-(void)mapData{
	if(data != nil){
		NSMutableArray *tempLocationArray = [[NSMutableArray alloc] initWithCapacity:[data count]];
		CLLocation *tempLocation;
		PhysicalPlace *tempCoordinate;
		for(NSDictionary *poi in data){
			CGFloat alt = [[poi valueForKey:@"alt"]floatValue];
			if(alt ==0.0){
				alt = centerLocation.altitude+50;
			}
			float lat = [[poi valueForKey:@"lat"]floatValue];
			float lon = [[poi valueForKey:@"lon"]floatValue];
			
			tempLocation = [[CLLocation alloc] initWithCoordinate:CLLocationCoordinate2DMake(lat, lon) altitude:alt horizontalAccuracy:1.0 verticalAccuracy:1.0 timestamp:nil];
			tempCoordinate = [PhysicalPlace coordinateWithLocation:tempLocation];
			tempCoordinate.title = [poi valueForKey:@"title"];
			tempCoordinate.source = [poi valueForKey:@"source"];
            tempCoordinate.url = [poi valueForKey:@"url"];
			[tempLocationArray addObject:tempCoordinate];
			[tempLocation release];
		}
		[self addCoordinates:tempLocationArray];
		[tempLocationArray release];
	}else NSLog(@"no data received");
}


#pragma mark - POI'S Realated Methods

NSComparisonResult LocationSortClosestFirst(PoiItem *s1, PoiItem *s2, void *ignore) {
    if (s1.radialDistance < s2.radialDistance) {
		return NSOrderedAscending;
	} else if (s1.radialDistance > s2.radialDistance) {
		return NSOrderedDescending;
	} else {
		return NSOrderedSame;
	}
}

- (BOOL)viewportContainsCoordinate:(PoiItem *)coordinate {
	double centerAzimuth = self.centerCoordinate.azimuth;
	double leftAzimuth = centerAzimuth - VIEWPORT_WIDTH_RADIANS / 2.0;
	
	if (leftAzimuth < 0.0) {
		leftAzimuth = 2 * M_PI + leftAzimuth;
	}
	
	double rightAzimuth = centerAzimuth + VIEWPORT_WIDTH_RADIANS / 2.0;
	
	if (rightAzimuth > 2 * M_PI) {
		rightAzimuth = rightAzimuth - 2 * M_PI;
	}
	
	BOOL result = (coordinate.azimuth > leftAzimuth && coordinate.azimuth < rightAzimuth);
	
	if(leftAzimuth > rightAzimuth) {
		result = (coordinate.azimuth < rightAzimuth || coordinate.azimuth > leftAzimuth);
	}
	
	double centerInclination = self.centerCoordinate.inclination;
	double bottomInclination = centerInclination - VIEWPORT_HEIGHT_RADIANS / 2.0;
	double topInclination = centerInclination + VIEWPORT_HEIGHT_RADIANS / 2.0;
	
		//check the height.
	result = result && (coordinate.inclination > bottomInclination && coordinate.inclination < topInclination);
	
		//NSLog(@"coordinate: %@ result: %@", coordinate, result?@"YES":@"NO");
	
	return result;
}

- (MarkerView *)viewForCoordinate:(PoiItem *)coordinate {
	
	CGRect theFrame = CGRectMake(0, 0, BOX_WIDTH, BOX_HEIGHT);
	MarkerView *tempView = [[MarkerView alloc] initWithFrame:theFrame];
	UIImageView *pointView = [[UIImageView alloc] initWithFrame:CGRectZero];
    tempView.backgroundColor = [UIColor grayColor];
	if([coordinate.source isEqualToString:@"WIKIPEDIA"]|| [coordinate.source isEqualToString:@"MIXARE"]){
		pointView.image = [UIImage imageNamed:@"circle.png"];
	}else if([coordinate.source isEqualToString:@"TWITTER"]){
        pointView.image = [UIImage imageNamed:@"twitter_logo.png"];
	}else if([coordinate.source isEqualToString:@"BUZZ"]){
        pointView.image = [UIImage imageNamed:@"buzz_logo.png"];
	}
	
    
	pointView.frame = CGRectMake((int)(BOX_WIDTH / 2.0-pointView.image.size.width / 2.0), 0, pointView.image.size.width, pointView.image.size.height);
	UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, BOX_HEIGHT / 2.0 , BOX_WIDTH, 20.0)];
	titleLabel.backgroundColor = [UIColor colorWithWhite:.3 alpha:.8];
	titleLabel.textColor = [UIColor whiteColor];
	titleLabel.textAlignment = UITextAlignmentCenter;
	titleLabel.text = coordinate.title;
    if([coordinate.source isEqualToString:@"BUZZ"]){
			//wrapping long buzz messages
        titleLabel.lineBreakMode = UILineBreakModeCharacterWrap;
        titleLabel.numberOfLines = 0;
        CGRect frame = [titleLabel frame];
        CGSize size = [titleLabel.text sizeWithFont:titleLabel.font	constrainedToSize:CGSizeMake(frame.size.width, 9999) lineBreakMode:UILineBreakModeClip];
        frame.size.height = size.height;
        [titleLabel setFrame:frame];
    }else{
			//Markers get automatically resized
        [titleLabel sizeToFit];
	}
	titleLabel.frame = CGRectMake(BOX_WIDTH / 2.0 - titleLabel.frame.size.width / 2.0 - 4.0,  pointView.image.size.height + 5, titleLabel.frame.size.width + 8.0, titleLabel.frame.size.height + 8.0);
	
	
    tempView.url = coordinate.url;
	[tempView addSubview:titleLabel];
	[tempView addSubview:pointView];
	[pointView release];
	[titleLabel release];
    tempView.userInteractionEnabled = YES;
    
	return [tempView autorelease];
}

- (CGPoint)pointInView:(MarkerView *)realityView forCoordinate:(PoiItem *)coordinate {
	
	CGPoint point;
	
		//x coordinate.
	
	double pointAzimuth = coordinate.azimuth;
	
		//our x numbers are left based.
	double leftAzimuth = self.centerCoordinate.azimuth - VIEWPORT_WIDTH_RADIANS / 2.0;
	
	if (leftAzimuth < 0.0) {
		leftAzimuth = 2 * M_PI + leftAzimuth;
	}
	
	if (pointAzimuth < leftAzimuth) {
			//it's past the 0 point.
		point.x = ((2 * M_PI - leftAzimuth + pointAzimuth) / VIEWPORT_WIDTH_RADIANS) * realityView.frame.size.width;
	} else {
		point.x = ((pointAzimuth - leftAzimuth) / VIEWPORT_WIDTH_RADIANS) * realityView.frame.size.width;
	}
	
		//y coordinate.
	
	double pointInclination = coordinate.inclination;
	
	double topInclination = self.centerCoordinate.inclination - VIEWPORT_HEIGHT_RADIANS / 2.0;
	
	point.y = realityView.frame.size.height - ((pointInclination - topInclination) / VIEWPORT_HEIGHT_RADIANS) * realityView.frame.size.height;
    
	return point;
}

-(CGPoint) rotatePointAboutOrigin:(CGPoint) point angle: (float) angle{
    float s = sinf(angle);
    float c = cosf(angle);
    return CGPointMake(c * point.x - s * point.y, s * point.x + c * point.y);
}

- (void)updateLocations:(NSTimer *)timer {
		//update locations!
	
	if (!ar_coordinateViews || ar_coordinateViews.count == 0) {
		return;
	}
	
	int index = 0;
    NSMutableArray * radarPointValues= [[NSMutableArray alloc]initWithCapacity:[ar_coordinates count]];
    
	for (PoiItem *item in ar_coordinates) {
		
		MarkerView *viewToDraw = [ar_coordinateViews objectAtIndex:index];
		
		if ([self viewportContainsCoordinate:item]) {
			
			CGPoint loc = [self pointInView:ar_overlayView forCoordinate:item];
			CGFloat scaleFactor = 1.5;
			if (self.scaleViewsBasedOnDistance) {
				scaleFactor = 1.0 - self.minimumScaleFactor * (item.radialDistance / self.maximumScaleDistance);
			}
			
			float width = viewToDraw.bounds.size.width * scaleFactor;
			float height = viewToDraw.bounds.size.height * scaleFactor;
			
			viewToDraw.frame = CGRectMake(loc.x - width / 2.0, loc.y-height / 2.0, width, height);
			
			CATransform3D transform = CATransform3DIdentity;
			
				//set the scale if it needs it.
			if (self.scaleViewsBasedOnDistance) {
					//scale the perspective transform if we have one.
				transform = CATransform3DScale(transform, scaleFactor, scaleFactor, scaleFactor);
			}
			
			if (self.rotateViewsBasedOnPerspective) {
				transform.m34 = 1.0 / 300.0;
				
				double itemAzimuth = item.azimuth;
				double centerAzimuth = self.centerCoordinate.azimuth;
				if (itemAzimuth - centerAzimuth > M_PI) centerAzimuth += 2*M_PI;
				if (itemAzimuth - centerAzimuth < -M_PI) itemAzimuth += 2*M_PI;
				
				double angleDifference = itemAzimuth - centerAzimuth;
				transform = CATransform3DRotate(transform, self.maximumRotationAngle * angleDifference / (VIEWPORT_HEIGHT_RADIANS / 2.0) , 0, 1, 0);
			}
			
			viewToDraw.layer.transform = transform;
			
				//if we don't have a superview, set it up.
			if (!(viewToDraw.superview)) {
				[ar_overlayView addSubview:viewToDraw];
				[ar_overlayView sendSubviewToBack:viewToDraw];
			}
		} else {
			[viewToDraw removeFromSuperview];
			viewToDraw.transform = CGAffineTransformIdentity;
		}
        [radarPointValues addObject:item];
		index++;
	}
    float radius = [[[NSUserDefaults standardUserDefaults] objectForKey:@"radius"] floatValue];
    if(radius <= 0 || radius > 20){
        radius = 5.0;
    }
    
    radarView.pois = radarPointValues;
    radarView.radius = radius;
    [radarView setNeedsDisplay];
	[radarPointValues release];
	[self startListening];
}

#pragma mark - ADD REMOVE POI'S

- (void)addCoordinate:(PoiItem *)coordinate {
	[self addCoordinate:coordinate animated:YES];
}

- (void)addCoordinate:(PoiItem *)coordinate animated:(BOOL)animated {
		//do some kind of animation?
	[ar_coordinates addObject:coordinate];
	
	if (coordinate.radialDistance > self.maximumScaleDistance) {
		self.maximumScaleDistance = coordinate.radialDistance;
	}
	
	[ar_coordinateViews addObject:[self viewForCoordinate:coordinate]];
}

- (void)addCoordinates:(NSArray *)newCoordinates {
	
		//go through and add each coordinate.
	for (PoiItem *coordinate in newCoordinates) {
		[self addCoordinate:coordinate animated:NO];
	}
}

- (void)removeCoordinate:(PoiItem *)coordinate {
	[self removeCoordinate:coordinate animated:YES];
}

- (void)removeCoordinate:(PoiItem *)coordinate animated:(BOOL)animated {
		//do some kind of animation?
	[ar_coordinates removeObject:coordinate];
}

- (void)removeCoordinates:(NSMutableArray *)coordinates {	
	[ar_coordinates removeAllObjects];
	[ar_coordinateViews removeAllObjects];
    for (UIView * view in ar_overlayView.subviews){
		if ([view isKindOfClass:[MarkerView class]]) {
			[view removeFromSuperview];
		}
    }
}

#pragma mark - CLLocationManagerDelegate

- (void)locationManager:(CLLocationManager *)manager didUpdateHeading:(CLHeading *)newHeading {
	self.centerCoordinate.azimuth = fmod(newHeading.magneticHeading, 360.0) * (2 * (M_PI / 360.0));
    if([[UIDevice currentDevice] orientation] == UIDeviceOrientationLandscapeLeft){
        if(self.centerCoordinate.azimuth <(3*M_PI/2)){
            self.centerCoordinate.azimuth += (M_PI/2);
        }else{
            self.centerCoordinate.azimuth = fmod(self.centerCoordinate.azimuth + (M_PI/2),360);
            
        }
        
    }
    int gradToRotate= newHeading.trueHeading-90-22.5;
    if([[UIDevice currentDevice] orientation] == UIDeviceOrientationLandscapeLeft){
        gradToRotate+=90;
    }
    if(gradToRotate <0){
        gradToRotate= 360+gradToRotate;
    }
	radarViewPort.referenceAngle = gradToRotate;
    [radarViewPort setNeedsDisplay];
    oldHeading = newHeading.trueHeading;
	
}

- (BOOL)locationManagerShouldDisplayHeadingCalibration:(CLLocationManager *)manager {
	return YES;
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation {
	self.centerLocation = newLocation;
	[self downloadPOIS];
	[self stopListening];
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error {
	[[[[UIAlertView alloc] initWithTitle:@"Location Error!" message:@"Your Location Could not be Determined." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] autorelease] show];
}

#pragma mark - UIAccelerometerDelegate

- (void)accelerometer:(UIAccelerometer *)accelerometer didAccelerate:(UIAcceleration *)acceleration {
		// -1 face down.
		// 1 face up.
	
		//update the center coordinate.
	
		//NSLog(@"x: %f y: %f z: %f", acceleration.x, acceleration.y, acceleration.z);
	
		//this should be different based on orientation.
	if([[UIDevice currentDevice] orientation] == UIDeviceOrientationLandscapeLeft){
        rollingZ  = (acceleration.z * kFilteringFactor) + (rollingZ  * (1.0 - kFilteringFactor));
        rollingX = (acceleration.x * kFilteringFactor) + (rollingX * (1.0 - kFilteringFactor));
    }else{
        rollingZ  = (acceleration.z * kFilteringFactor) + (rollingZ  * (1.0 - kFilteringFactor));
        rollingX = (acceleration.y * kFilteringFactor) + (rollingX * (1.0 - kFilteringFactor));
	}
	if (rollingZ > 0.0) {
		self.centerCoordinate.inclination = atan(rollingX / rollingZ) + M_PI / 2.0;
	} else if (rollingZ < 0.0) {
		self.centerCoordinate.inclination = atan(rollingX / rollingZ) - M_PI / 2.0;// + M_PI;
	} else if (rollingX < 0) {
		self.centerCoordinate.inclination = M_PI/2.0;
	} else if (rollingX >= 0) {
		self.centerCoordinate.inclination = 3 * M_PI/2.0;
	}
	
	
}


- (void)dealloc {
	[controlView release];
	[super dealloc];
}
@end
