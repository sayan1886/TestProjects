//
//  ARFViewController.h
//  ARFuction
//
//  Created by Sayan on 14/06/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MarkerView.h"
#import <CoreLocation/CoreLocation.h>
#import "Radar.h"
#import "PoiItem.h"
#import "RadarViewPortView.h"

@interface ARFViewController : UIViewController<UIAccelerometerDelegate, CLLocationManagerDelegate> {
	CLLocationManager *locationManager;
	UIAccelerometer *accelerometerManager;
	
	PoiItem *centerCoordinate;
	
	UIImagePickerController *cameraController;
	CLLocation *centerLocation;
	
	BOOL scaleViewsBasedOnDistance;
	double maximumScaleDistance;
	double minimumScaleFactor;
	
		//defaults to 20hz;
	double updateFrequency;
	
	BOOL rotateViewsBasedOnPerspective;
	double maximumRotationAngle;
	
	NSMutableArray *data;
	
@private
	IBOutlet UIView *controlView;
	int oldHeading;
	NSTimer *_updateTimer;
	
	MarkerView *ar_overlayView;
	Radar * radarView;
    RadarViewPortView * radarViewPort;
	
	NSMutableArray *ar_coordinates;
	NSMutableArray *ar_coordinateViews;
	
	UIAccelerationValue rollingX, rollingZ;
}

@property (readonly) NSArray *coordinates;
@property (nonatomic, retain) NSMutableArray *data;

@property BOOL scaleViewsBasedOnDistance;
@property double maximumScaleDistance;
@property double minimumScaleFactor;

@property BOOL rotateViewsBasedOnPerspective;
@property double maximumRotationAngle;

@property double updateFrequency;

@property (nonatomic, retain) UIImagePickerController *cameraController;
@property (nonatomic, retain) CLLocation *centerLocation;
@property (retain) PoiItem *centerCoordinate;

@property (nonatomic, retain) UIAccelerometer *accelerometerManager;
@property (nonatomic, retain) CLLocationManager *locationManager;

- (id) initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil andLocationManager:(CLLocationManager *)manager;
	//adding coordinates to the underlying data model.
- (void)addCoordinate:(PoiItem *)coordinate;
- (void)addCoordinate:(PoiItem *)coordinate animated:(BOOL)animated;

- (void)addCoordinates:(NSArray *)newCoordinates;


	//removing coordinates
- (void)removeCoordinate:(PoiItem *)coordinate;
- (void)removeCoordinate:(PoiItem *)coordinate animated:(BOOL)animated;
- (void)removeCoordinates:(NSArray *)coordinates;

- (void)startListening;
-(void) stopListening;
- (void)updateLocations:(NSTimer *)timer;
-(void)closeCameraView;
- (CGPoint) rotatePointAboutOrigin:(CGPoint) point angle: (float) angle;
- (CGPoint)pointInView:(UIView *)realityView forCoordinate:(PoiItem *)coordinate;

- (BOOL)viewportContainsCoordinate:(PoiItem *)coordinate;

- (IBAction)radiusChanged:(UISlider *)sender;



@end



