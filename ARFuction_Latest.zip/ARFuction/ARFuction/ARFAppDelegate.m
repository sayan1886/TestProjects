//
//  ARFAppDelegate.m
//  ARFuction
//
//  Created by Sayan on 14/06/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ARFAppDelegate.h"

#import "ARFViewController.h"


	
#define CAMERA_TRANSFORM 1.12412
#define degreesToRadian(x) (M_PI * (x) / 180.0)

@implementation ARFAppDelegate

@synthesize window = _window;
@synthesize viewController = _viewController;


- (void)dealloc
{
    [_window release];
    [_viewController release];
    [super dealloc];
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
	[[NSUserDefaults standardUserDefaults] setObject:@"TRUE" forKey:@"Wikipedia"];
	beforeWasLandscape = NO;
	[[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didRotate:) name:@"UIDeviceOrientationDidChangeNotification" object:nil];
	
    self.window = [[[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]] autorelease];
    // Override point for customization after application launch.
	CLLocationManager *loactionManager = [[[CLLocationManager alloc] init] autorelease];
    self.viewController = [[[ARFViewController alloc] initWithNibName:@"ARFViewController" bundle:nil andLocationManager:loactionManager] autorelease] ;
	self.window.rootViewController = self.viewController;
    [self.window makeKeyAndVisible];
	
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

#pragma mark -
#pragma  mark URL Handler
- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url {
	NSLog(@"the url: %@", [url absoluteURL]);
	if (!url) {  return NO; }
    NSString *URLString = [url absoluteString];
    [[NSUserDefaults standardUserDefaults] setObject:URLString forKey:@"extern_url"];
    [[NSUserDefaults standardUserDefaults] synchronize];
	//[self downloadData];
    return YES;
}


#pragma mark - class methods

-(void) didRotate:(NSNotification *)notification{ 
    //Maintain the camera in Landscape orientation [[UIDevice currentDevice] setOrientation:UIInterfaceOrientationLandscapeRight];
    //UIDeviceOrientation orientation = [[UIDevice currentDevice] orientation];
    if([[UIDevice currentDevice] orientation] == UIDeviceOrientationLandscapeLeft){
        [self setViewToLandscape:_viewController.view];
        beforeWasLandscape = YES;
    }
    if([[UIDevice currentDevice] orientation] == UIDeviceOrientationPortrait && beforeWasLandscape){
        [self setViewToPortrait:_viewController.view];
        beforeWasLandscape = NO;
    }
    
}

-(void)setViewToLandscape:(UIView*)viewObject {
    [viewObject setCenter:CGPointMake(160, 240)];
    CGAffineTransform cgCTM = CGAffineTransformMakeRotation(degreesToRadian(90));
    viewObject.transform = cgCTM;
    viewObject.bounds = CGRectMake(0, 0, 480, 320);
}

-(void)setViewToPortrait:(UIView*)viewObject{
    CGAffineTransform tr = viewObject.transform; // get current transform (portrait)
    tr = CGAffineTransformRotate(tr, -(M_PI / 2.0)); // rotate -90 degrees to go portrait
    viewObject.transform = tr; // set current transform 
    CGRectMake(0, 0, 320, 480);
    [viewObject setCenter:CGPointMake(240, 160)];
	
}

@end
