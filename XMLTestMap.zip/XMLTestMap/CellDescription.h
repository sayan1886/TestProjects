//
//  CellDescription.h
//  SPLibrary
//
//  Created by Sumit Kr Prasad on 30/09/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SuperDictionary.h"

@interface CellDescription : NSObject 
{
	NSString *type;
	SuperDictionary *data;
	int height;
	NSString *contentID;
	NSString *contentType;
}

@property (readonly)  NSString *type;
@property (readonly)  SuperDictionary *data;
@property (readwrite) int height;
@property (readonly) NSString *contentID;
@property (readonly) NSString *contentType;

- (id)initWithType:(NSString*) cellType  
			  data:(SuperDictionary*) cellData 
			height:(int) cellHeight
		 contentID:(NSString*)cellContentID
	   contentType:(NSString*)cellContentType;
@end
