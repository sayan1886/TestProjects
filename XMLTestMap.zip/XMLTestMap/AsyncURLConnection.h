//
//  AsyncURLConnection.h
//  XMLTest
//
//  Created by Sayan Chatterjee on 31/01/11.
//  Copyright 2011 ObjectSol. All rights reserved.
//

#import <Foundation/Foundation.h>

@class MyTools;

@protocol CallBack <NSObject>

	@optional
	- (void) handleSuccess;
	- (void) handleError;

@end


@interface AsyncURLConnection : NSObject {

	//NSMutableString *urlToBuffer;
	NSMutableString *bufferedURL;
	NSMutableData *resultBuffer;
	NSURLConnection *toServerConnection;
	int flag;
	id<CallBack> callback;
	UIActivityIndicatorView *spinner;
	NSString *url;
	
}

@property (nonatomic,retain) NSMutableData *resultBuffer;
@property (nonatomic,retain) NSMutableString *bufferedURL;
@property (nonatomic,retain)	NSURLConnection *toServerConnection;
@property (nonatomic,retain) 	NSMutableString *urlToBuffer;
@property (nonatomic,assign) int flag;
@property (nonatomic,retain) 	id<CallBack> callback;

- (void) connectToURL;
- (id) initWithUrl:(NSString *)url_ ;

//-(NSMutableData *) getResultBuffer;

@end
