//
//  SPUITableViewController.h
//  SPLibrary
//
//  Created by Sumit Kr Prasad on 01/10/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CellDescription.h"
#import "SPTableCellProtocol.h"

#define SPTCProtocol UITableViewCell <SPTableCellProtocol>

@interface SPUITableViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>
{
	UITableView *tableView;
	NSMutableArray *cellDescriptions;
}

@property (nonatomic, retain)  UITableView *tableView;

-(SPTCProtocol *) spCellForType:(NSString *)type;
-(void)setupTableView;
@end
