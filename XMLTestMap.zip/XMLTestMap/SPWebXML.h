//
//  SPWebXML.h
//  SPLibrary
//
//  Created by Sumit Kr Prasad on 01/10/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <libxml/xmlmemory.h>
#import <libxml/parser.h>
#import <libxml/xpath.h>
@interface SPWebXML : NSObject 
{
	xmlDocPtr doc;
}
-(id) initWithString:(NSString*)xml_str;

- (NSString*) firstValueWithPath:(NSString*)xpath;
- (NSString*) firstValueWithPath:(NSString*)xpath fromNode:(xmlNodePtr)contextNode;


- (xmlNodeSetPtr) nodeSetWithPath:(NSString*)xpath;
- (xmlNodeSetPtr) nodeSetWithPath:(NSString*)xpath fromNode:(xmlNodePtr)contextNode;


- (NSString*) valueWithPath:(NSString*)xpath fromNode:(xmlNodePtr)contextNode atIndex:(int)index;


-(bool) elementExistsForPath:(NSString*)xpath;
@end
