//
//  SPImageView.h
//  SPLibrary
//
//  Created by Sumit Kr Prasad on 01/10/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface SPImageView : UIImageView
{
	NSString *strImageName;
	BOOL isAllocationsAndDeallocations;
}

-(id)initWithImageNamed:(NSString *)imageName memLog:(BOOL)memlog;
@end
