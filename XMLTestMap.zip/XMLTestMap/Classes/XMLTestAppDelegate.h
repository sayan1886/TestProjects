//
//  XMLTestAppDelegate.h
//  XMLTest
//
//  Created by Sayan Chatterjee on 18/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class XMLTestViewController;

@interface XMLTestAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    XMLTestViewController *viewController;
	UINavigationController *navController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet XMLTestViewController *viewController;





@property (nonatomic, retain) UINavigationController *navController;

@end

