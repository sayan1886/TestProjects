//
//  XMLTestViewController.h
//  XMLTest
//
//  Created by Sayan Chatterjee on 18/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class XPathParser;

@class MyTools;

@interface XMLTestViewController : UIViewController<UITextFieldDelegate> {

	XPathParser *xpathParser;
	UIActivityIndicatorView *spinner; 
	MyTools *aTools;
	UIView *loadingView;
	UITextField *start;
	UITextField *end;
	
}

- (void) startParsing;
- (void) stopParsing;

@property (nonatomic,retain) XPathParser *xpathParser;


@end

