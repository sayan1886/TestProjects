//
//  XMLTestViewController.m
//  XMLTest
//
//  Created by Sayan Chatterjee on 18/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "XMLTestViewController.h"
#import "XPathParser.h"
#import "MyTools.h"
#import "MapViewController.h"


@implementation XMLTestViewController

@synthesize xpathParser;

/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/



// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	
	[super viewDidLoad];
	//[self.na]
	self.view.backgroundColor = [UIColor blackColor];
	spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
	spinner.center = CGPointMake(320 / 2, 480 / 2);
	[self.view addSubview:spinner];
	start = [[UITextField alloc]initWithFrame:CGRectMake(20, 20, 300, 50)];
	[start setBorderStyle:UITextBorderStyleRoundedRect];
	start.placeholder = @"Start Point";
    start.text = @"Kolkata";
	start.delegate = self;
	[start setAdjustsFontSizeToFitWidth:YES];
	[start setAutocorrectionType:UITextAutocorrectionTypeNo];
	start.clearButtonMode = UITextFieldViewModeWhileEditing;
	[self.view addSubview:start];
	end	= [[UITextField alloc]initWithFrame:CGRectMake(20, 80, 300, 50)];
	[end setBorderStyle:UITextBorderStyleRoundedRect];
	end.placeholder = @"End Point";
    end.text = @"Kalyani";
	[end setAdjustsFontSizeToFitWidth:YES];
	[end setAutocorrectionType:UITextAutocorrectionTypeNo];
	end.clearButtonMode = UITextFieldViewModeWhileEditing;
	end.delegate = self;
	[self.view addSubview:end];
	UIButton *routeButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
	routeButton.frame = CGRectMake(110, 150, 100, 50);
	[routeButton setTitle:@"Show Route" forState:UIControlStateNormal];
	[routeButton addTarget:self action:@selector(startParsing) forControlEvents:UIControlEventTouchUpInside];
	[self.view addSubview:routeButton];
	//[self startParsing];
	
}


- (void) startParsing{
	[spinner startAnimating];
	[aTools startLoading:self.view childView:loadingView text:@"Loading....Please Wait…"];
	
	NSString	*url = [NSString stringWithFormat:@"http://maps.googleapis.com/maps/api/directions/xml?origin=%@&destination=%@&region=es&sensor=true",start.text,end.text];
   // NSString	*url = [NSString stringWithFormat:@"https://www.google.com/ig/api?weather=kolkata"];
	XPathParser *localParser  = [[XPathParser alloc] initWithTarget:self andUrl:url];
	//[xpathParser init];
	self.xpathParser = localParser;
	//[localParser release];
	[self.xpathParser doParse:@"//start_location"];//@"//forecast_conditions"];
	//NSArray *arr = [self.xpathParser element];
	[localParser release];
	//[arr release];
	//NSLog(@"Element  : %@",self.xpathParser.element);
	//NSLog(@"Elements : %@",arr);
	[self stopParsing];
	
}
- (void) stopParsing{
	
	[aTools stopLoading:loadingView];

}

- (void)getData:(NSArray *)resultArr{

    NSLog(@"RESULT : %@",resultArr);
	NSMutableArray *latArr = [NSMutableArray new];
	NSMutableArray *longArr = [NSMutableArray new];
	
	
	
	
	for (int i = 0; i < [resultArr count]; i++) {
		[latArr addObject:[[[[resultArr objectAtIndex:i] objectForKey:@"nodeChildArray"] objectAtIndex:0] objectForKey:@"nodeContent"]];
		[longArr addObject:[[[[resultArr objectAtIndex:i] objectForKey:@"nodeChildArray"] objectAtIndex:1] objectForKey:@"nodeContent"]];
	}
	[spinner stopAnimating];
	MapViewController *map = [[MapViewController alloc] initWithLocationLatitude:(NSArray *)latArr andLongitude:(NSArray *)longArr];
		//UINavigationController *navCtrl  =[[UINavigationController alloc] initWithRootViewController:self];
	[self.navigationController pushViewController:map animated:YES];
	[latArr release];
	[longArr release];
    [map release];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
	[textField resignFirstResponder];
	return YES;
}              // called when 'return' key pressed. return NO to ignore.


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[xpathParser release];
	[super dealloc];
}

@end
