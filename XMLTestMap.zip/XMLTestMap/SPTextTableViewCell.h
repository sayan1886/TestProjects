//
//  SPTextTableViewCell.h
//  SPLibrary
//
//  Created by Sumit Kr Prasad on 01/10/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SuperDictionary.h"

@interface SPTextTableViewCell : UITableViewCell 
{
	NSString *titleText;
	UILabel *lblTitleText;
	SuperDictionary* dictionary;
}
-(void)setDictionary:(SuperDictionary *)dict;
-(SuperDictionary *)dictionary;

+(NSString *) cellType;
+(int) cellHeight;

@property (assign) NSString *titleText;
@end
