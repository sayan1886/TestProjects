//
//  AsyncURLConnection.m
//  XMLTest
//
//  Created by Sayan Chatterjee on 31/01/11.
//  Copyright 2011 ObjectSol. All rights reserved.
//

#import "AsyncURLConnection.h"
#import "XPathParser.h"
#import "MyTools.h"


@implementation AsyncURLConnection

@synthesize resultBuffer,toServerConnection,urlToBuffer,bufferedURL,flag;
@synthesize callback;




- (id) initWithUrl:(NSString *)url_ {
	if (self) {
		// initialize variables 
		[super init];
		self.toServerConnection = nil;
		self.resultBuffer = nil;
		//self.urlToBuffer = (NSMutableString *)@"http://dev.mobiletakeout.com/export/locations/data.xml";
		//http://maps.googleapis.com/maps/api/directions/xml?origin=22.80,88.39&destination=28.38,77.12&region=es&sensor=true
		//self.urlToBuffer = (NSMutableString *)@"http://maps.googleapis.com/maps/api/directions/xml?origin=kolkata&destination=dhaka&region=es&sensor=true";
		self.bufferedURL = (NSMutableString *)@"";
		self.flag = 0;
		url = [NSString stringWithString:url_];
		spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
	}
	return self;
}

/*- (NSMutableData *) getResultBuffer{
	NSLog(@"SAYAN!!!!!");
	return [self.resultBuffer autorelease];
}*/

- (void) connectToURL{
	//if (self.toServerConnection == nil) {
		self.resultBuffer = [[NSMutableData new] autorelease];
		self.toServerConnection =[NSURLConnection connectionWithRequest:
									[NSURLRequest requestWithURL:
											[NSURL URLWithString:url]] 
											                      delegate:self];
	[spinner startAnimating];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
	[resultBuffer appendData:data];
}

- (void) initializeVariablesAgain {
	[resultBuffer release], resultBuffer = nil;
	toServerConnection = nil;	
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
	NSString *localStr = [[NSString alloc] initWithData:resultBuffer encoding:NSASCIIStringEncoding];
	self.bufferedURL = (NSMutableString *)localStr;
	//[self.bufferedURL setString:[NSMutableString alloc] ];
	//NSLog(@"XMLSTring: %@",bufferedURL);
	//XPathParser *xpathParser = [[XPathParser alloc] init];
	//xpathParser.element = bufferedURL;
	self.flag = 0;
	if (self.callback) {
		if ([self.callback respondsToSelector:@selector(handleSuccess)]) {
			[self.callback handleSuccess];
		}
	}
	[spinner stopAnimating];
    [localStr release];
	//[self initializeVariablesAgain];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
	//[self.bufferedURL setString:[error localizedDescription]];
	NSString *localStr = [[NSString alloc] initWithData:resultBuffer encoding:NSASCIIStringEncoding];
	self.bufferedURL = (NSMutableString *)localStr;
	//NSLog(@"XMLSTring: %@",bufferedURL);
	self.flag = 1;
	//[self initializeVariablesAgain];
	if (self.callback) {
		if ([self.callback respondsToSelector:@selector(handleError)]) {
			[self.callback handleError];
		}
	}
	[spinner stopAnimating];
    [localStr release];
}

- (void) dealloc{

	[resultBuffer release], resultBuffer = nil;
	toServerConnection = nil;
	[super dealloc];
}

@end
