    //
//  SPUITableViewController.m
//  SPLibrary
//
//  Created by Sumit Kr Prasad on 01/10/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "SPUITableViewController.h"
#import "SPTextTableViewCell.h"
#import "SPUtils.h"

@implementation SPUITableViewController
@synthesize tableView;
/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad 
{
    [super viewDidLoad];
	[self setupTableView];
}

-(void)setupTableView
{
	self.tableView=[[[UITableView alloc] initWithFrame:CGRectMake(0, 39, 320, 329) 
												 style:UITableViewStylePlain] autorelease];
	[self.view addSubview:self.tableView];
	tableView.delegate=self;
	tableView.dataSource=self;
	tableView.contentInset=UIEdgeInsetsMake(-22, 0, -22, 0);
}

- (CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	CellDescription* cd = [cellDescriptions objectAtIndex:indexPath.row];
	return cd.height;
	
}
#pragma mark Table view methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *) tableView 
{
    return 1;
}
- (SPTCProtocol*) spCellForType:(NSString*)type
{
		
}
// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
    return   [cellDescriptions count];
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)_tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath 
{
	
	SPTCProtocol* cell;
	CellDescription* cd = [cellDescriptions objectAtIndex:indexPath.row];
	
	NSString* cellType = cd.type;
	cell = (SPTCProtocol*)[tableView dequeueReusableCellWithIdentifier:cellType];
	if(cell == nil ) cell = [self spCellForType:cellType];
	[cell setDictionary:[cd data]];
	
	return cell;	
	
	//return [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"Fox"];
	
}


- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
	[tableView deselectRowAtIndexPath:[tableView indexPathForSelectedRow] animated:YES];
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    if (!self.view.superview && [SPUtils isPad]) {
        self.view = nil;
        [self viewDidUnload];
    }
	
	// Release any cached data, images, etc that aren't in use.
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/



- (void)viewDidUnload {
    [super viewDidUnload];
	self.tableView=nil;
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
