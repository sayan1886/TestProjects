//
//  MapViewController.h
//  SKIIP
//
//  Created by Sayan Chatterjee on 15/04/11.
//  Copyright 2011 ObjectSol. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>


@interface MapViewController : UIViewController <MKMapViewDelegate,MKReverseGeocoderDelegate,CLLocationManagerDelegate> {

	MKMapView *map;
	MKReverseGeocoder *coder;
	CLLocationCoordinate2D startLocation;
	CLLocationCoordinate2D endLocation;
	BOOL loc;
	CLLocationManager *locationManager;
	MKPolyline *lineOverLay;
	NSMutableArray *latArr;
	NSMutableArray *longArr;

}

- (id)initWithLocationLatitude:(NSArray *)latitude andLongitude:(NSArray *)longitude ;
-(void)getCurrentLocation;
- (MKPolyline *) createRouteStartingFrom:(CLLocationCoordinate2D)startLocation_  toEnd:(CLLocationCoordinate2D)endLocation_;


@property (nonatomic,retain) MKMapView *map;
@property (nonatomic,retain) MKReverseGeocoder *coder;
@property (nonatomic,retain) MKPolyline *lineOverLay;
@property (nonatomic,retain) NSMutableArray *latArr;
@property (nonatomic,retain) NSMutableArray *longArr;


@end
