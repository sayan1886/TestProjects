//
//  APIResponceHandler.h
//  GoalGetter
//
//  Created by Sumit Kr Prasad on 19/12/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SPRequester.h"

@interface APIResponseHandler : NSObject
{
	id target; // the calling object (of the api method)
	SEL success; // the callback method to invoke on the calling object
	SEL failure; // the API response handler method
	NSString* response; // api response
	NSError* error; // connection error
	SEL responseHandler; // the API method that will process the returned XML
	SEL failureHandler; // the API method that will process the connection error
	SPRequester* requester;
	id extra;
}

//::Public
- (id)initWithResponseHandler:(SEL)rh failureHanlder:(SEL)fh target:(id)t success_cb:(SEL)s failure_cb:(SEL)f;
- (id)initWithResponseHandler:(SEL)rh failureHanlder:(SEL)fh target:(id)t success_cb:(SEL)s failure_cb:(SEL)f extra:extraOrNil;
+ (void) changeAvatar:(NSString*)contentID responstTarget:(id)target success_cb:(SEL)success failure_cb:(SEL)failure;
@property(assign, readonly) NSString* response;
@property(assign, readonly) NSError* error;
@property(assign, readonly) id target;
@property(assign, readonly) SEL success; 
@property(assign, readonly) SEL failure;
@property(retain, readonly) id extra;
@property(assign) SPRequester* requester;


//::Private
- (void) onResponse:(NSString*)apiResponse requester:(SPRequester*)requester; // treemo api http response
- (void) onFailure:(NSError*)connectionError requester:(SPRequester*)requester; // io error

@end

