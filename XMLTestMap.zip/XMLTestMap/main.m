//
//  main.m
//  XMLTest
//
//  Created by Sayan Chatterjee on 18/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    int retVal = 0;
    @try {
        NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
        retVal = UIApplicationMain(argc, argv, nil, nil);
        [pool release];

    }
    @catch (NSException *exception) {
        NSLog(@"<<<<<<<<<<<<<<<<<<<<<<<<<< EXECEPTION CAUSE >>>>>>>>>>>>>>>>>>>>>>>>>>>\n");
        NSLog(@"%@\n",exception);
        NSLog(@"<<<<<<<<<<<<<<<<<<<<<<<<<< END EXCEPION CAUSE >>>>>>>>>>>>>>>>>>>>>>>>>>>\n");
    }
    return retVal;
}
