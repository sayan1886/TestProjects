//
//  Tree1.h
//  XMLTest
//
//  Created by Sayan Chatterjee on 11/04/11.
//  Copyright 2011 ObjectSol. All rights reserved.
//

#include <stdio.h>
#include <libxml/parser.h>
#include <libxml/tree.h>

static void print_element_names(xmlNode * a_node);
void initTree1(xmlDoc *doc);
