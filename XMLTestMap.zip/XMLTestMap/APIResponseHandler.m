//
//  APIResponceHandler.m
//  GoalGetter
//
//  Created by Sumit Kr Prasad on 19/12/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "APIResponseHandler.h"
#import "ApplicationAPIBinding.h"

@implementation APIResponseHandler
- (id)initWithResponseHandler:(SEL)rh failureHanlder:(SEL)fh target:(id)t success_cb:(SEL)s failure_cb:(SEL)f
{
	return [self initWithResponseHandler:rh 
						  failureHanlder:fh 
								  target:t
							  success_cb:s 
							  failure_cb:f 
								   extra:nil];	
}

- (id)initWithResponseHandler:(SEL)rh failureHanlder:(SEL)fh target:(id)t success_cb:(SEL)s failure_cb:(SEL)f extra:extraOrNil
{
	if(self = [super init])
	{	
		responseHandler = rh;
		failureHandler = fh;
		target = t;
		success = s;
		failure = f;
		extra = [extraOrNil retain];
		//////////NSLog(@"Response Handler Created");
	}
	return self;
}

@synthesize response;
@synthesize requester;
@synthesize error;
@synthesize target;
@synthesize success;
@synthesize failure;
@synthesize extra;

- (void) onResponse:(NSString*)apiResponse requester:(SPRequester*)requester
{
	//////////NSLog(@"API Responded: %@", apiResponse);
	response = apiResponse;
	[[response retain] autorelease];
	//[requester release];
	[ApplicationAPIBinding performSelector:responseHandler  withObject:self];
	//[requester release];
}

- (void) onFailure:(NSError*)connectionError requester:(SPRequester*)_requester
{
	error = connectionError;
	[error retain];
	//[requester release];
	[ApplicationAPIBinding performSelector:failureHandler withObject:self withObject:_requester];
	//[requester release];
}

- (void)dealloc 
{
	[response release];
	[error release];
	[extra release];
	[super dealloc];
}

@end
