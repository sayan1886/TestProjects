//
//  SPRequester.h
//  GoalGetter
//
//  Created by Sumit Kr Prasad on 19/12/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SPUtils.h"

@interface SPRequester : NSObject {
	NSString* requestURL;
	NSString* multipartBoundry;
	
	NSData* uploadData;
	NSMutableData* receivedData;
	NSString* uploadFieldName;
	NSString* uploadFileName;
	NSURLConnection* myConnection;
	
	//vars and method saved for retry
	NSString* requestMethod;
	NSDictionary* requestVars;
	
	BOOL canceled;
	BOOL requestFailed;
	//Actions
	id progressTarget;
	id actionTarget;
	SEL onResponse;
	SEL onFailure;
}


@property(assign, readwrite) SEL onResponse;
@property(assign, readwrite) SEL onFailure;
@property(readonly) NSString* requestURL;
@property(assign) id progressTarget;
//:::Public
- (id) initWithURL:(NSString*)url actionTarget:(id)target;
- (void) retry;
// It is safe to release Requester after submit has been invoked.
// (Requester retains self after submit is invoked. 
//  On response/failure complete Requester releases self.)
- (void) submit:(NSDictionary*)vars requestMethod:(NSString*)method;
- (void) attachData:(NSData*)data withFieldName:(NSString*)fieldName andFileName:(NSString*)filename;
-(void)cancel;
+ (NSString*) urlEncodeVars:(NSDictionary *)vars; // used for making requests in browser control

//:::Private
- (NSData *) multipartEncodeVars:(NSDictionary*)vars;
+ (NSString*) urlEncodeValue:(NSString*)str;
- (NSURLRequest*) buildPostRequestWithVars:(NSDictionary *)vars;
- (NSURLRequest*) buildGetRequestWithVars:(NSDictionary *)vars;
- (void)connectionDidFinishLoading:(NSURLConnection *)connection;
@end
