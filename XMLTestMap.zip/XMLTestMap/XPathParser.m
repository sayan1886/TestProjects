//
//  XPathParser.m
//  XMLTest
//
//  Created by Sayan Chatterjee on 31/01/11.
//  Copyright 2011 ObjectSol. All rights reserved.
//

#import "XPathParser.h"
#import "XPathQuery.h"
#import "AsyncURLConnection.h"
#import <libxml/HTMLparser.h>
#import "Tree1.h"
#import "Tree2.h"
#import "XMLInputOutput2.h"
#import "XMLInputOutPut1.h"
#import "MapViewController.h"

@implementation XPathParser

@synthesize conn,element,parseQuery;

- (id) initWithTarget:(id)target andUrl:(NSString *)url{
	if (self) {
		[super init];
		//[self.conn init];
		self.element = [NSArray array];
		selectedTarget = target;
		conn = [[AsyncURLConnection alloc] initWithUrl:(NSString *)url];
	}
	return self;
}

-(void) doParse:(NSString *)query{

	
	
	conn.callback = self;
	//[myCon release];
	[self.conn connectToURL];
	self.parseQuery = query;
		
}

- (void) handleSuccess{
	NSLog(@"SAYAN");
	//NSLog(@"XML : %@",self.element);
	NSData *xmlData = [self.conn resultBuffer];
	//NSArray	*errorArr = []
	NSArray *xmlArr  = [[NSArray alloc] initWithArray: PerformXMLXPathQuery(xmlData, self.parseQuery)];
	self.element = xmlArr;
	[xmlArr release];
	NSLog(@"Xml String : %@",self.conn.bufferedURL);
	//NSLog(@"XML DATA : %@",xmlData);
	NSLog(@"Parse® data : %@",self.element);
	/* Load XML document */
	/*xmlDoc *doc = htmlReadMemory([xmlData bytes], [xmlData length], "", NULL, HTML_PARSE_NOWARNING | HTML_PARSE_NOERROR);
	initTree1(doc);
	NSLog(@"Tree@ >>>>>>>>>>>>>>>>>>>");
	initTree2(@"Sayan");
	NSLog(@"Writter@ >>>>>>>>>>>>>>>>>>>");
	initXMLWritter();
	NSLog(@"Input1@ >>>>>>>>>>>>>>>>>>>");
	initXMLInputOutput1();
	NSLog(@"Input2@ >>>>>>>>>>>>>>>>>>>");
	initXMLInputOutput2();*/
	[selectedTarget performSelector:@selector(getData:) withObject:element]; 
	/*NSMutableArray *latArr = [NSMutableArray new];
	NSMutableArray *longArr = [NSMutableArray new];
	
	
	
	
	for (int i = 0; i < [element count]; i++) {
		[latArr addObject:[[[[element objectAtIndex:i] objectForKey:@"nodeChildArray"] objectAtIndex:0] objectForKey:@"nodeContent"]];
		[longArr addObject:[[[[element objectAtIndex:i] objectForKey:@"nodeChildArray"] objectAtIndex:1] objectForKey:@"nodeContent"]];
	}
	
	MapViewController *map = [[MapViewController alloc] initWithLocationLatitude:(NSArray *)latArr andLongitude:(NSArray *)longArr];
	UINavigationController *navCtrl  =[[UINavigationController alloc] initWithRootViewController:self];*/
	//[self present]
}

- (void) handleError{

}

/*- (NSArray *)  element{
	NSLog(@"SAYAN....");
	return [self.element autorelease];
}*/

- (void) dealloc{
	[conn release];
	[element release];
	[super dealloc];
}

@end
