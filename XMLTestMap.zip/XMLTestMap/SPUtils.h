//
//  SPUtils.h
//  SPLibrary
//
//  Created by Sumit Kr Prasad on 01/10/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreFoundation/CoreFoundation.h>
#import <QuartzCore/QuartzCore.h>
#import <math.h>
#import "SPImageView.h"
#import <math.h>

@interface UINavigationBar (BackgroundImage)

- (void)scInsertSubview:(UIView *)view atIndex:(NSInteger)index;
- (void)scSendSubviewToBack:(UIView *)view;

@end
@interface SPUtils : NSObject {

}

+ (void)customizeNavigationController:(UINavigationController *)navController;
+ (void)customizeNavigationController:(UINavigationController *)navController withImageNamed:(NSString*)imageName;


//Swizzling
+ (void)swizzleSelector:(SEL)orig ofClass:(Class)c withSelector:(SEL)new;


+ (BOOL) isPad ;
+ (NSIndexPath*)indexPathWithIndex:(int)indexOne withIndex:(int)indexTwo;
+ (UIColor*) colorFromImageName:(NSString*)imageName;
+ (UIColor*)colorFromHex:(int) hexColor;
+ (UIImageView*) imageViewWithImageName:(NSString*)imageName;
+ (UIImageView*) imageViewWithImageName:(NSString*)imageName memlog:(BOOL)memlog;
+ (UIImageView*) imageViewWithImageName:(NSString*)imageName x:(float)x y:(float)y;
+ (UIImageView*) imageViewWithImageName:(NSString*)imageName x:(float)x y:(float)y memlog:(BOOL)memlog;
+ (UIImageView*) imageViewFromView:(UIView*)view;

+ (void) drawBorderAroundView:(UIView*)view;
+ (UIView*) centerView:(UIView*)smallView inView:(UIView*)largerView;
+ (void) view:(UIView*)view setX:(float)x;
+ (void) view:(UIView*)view setY:(float)y;
+ (void) view:(UIView*)view setX:(float)x setY:(float)y;
+ (void) view:(UIView*)view setWidth:(float)width;
+ (void) view:(UIView*)view resizeWidthToFitText:(NSString*)text withFont:(UIFont*)font;
+ (CGRect) rectWithRect:(CGRect)rect height:(float)height;
+ (CGRect) rectWithRect:(CGRect)rect width:(float)width;
+ (CGRect) rectWithRect:(CGRect)rect y:(float)y;
+ (CGRect) rectWithRect:(CGRect)rect x:(float)x;

+ (void) addNetworkUsage;
+ (void) removeNetworkUsage;

+ (NSInvocation*) makeInv:(SEL)selector target:(id)target;


+ (BOOL) string:(NSString*)str containsSubstring:(NSString*)substr;
+ (NSString*) string:(NSString*)str 
	replaceSubstring:(NSString*)substr 
		  withString:(NSString*)repstr 
	adjacentAsSingle:(BOOL)adjacentAsSingle;

+ (NSString*) urlStringFromWebSafeURL:(NSString*)string;
+ (NSArray*) splitString:(NSString*)str 
				onString:(NSString*)splitStr 
handleAdjacentDelimiterAsSingleDelimiter:(BOOL)adjacentAsSingle; 

+ (NSString*) trimString:(NSString*)str;
+ (NSArray*) splitString:(NSString*)str onString:(NSString*)splitStr;
+ (NSString*) joinArray:array byString:(NSString*)byStr;
+ (NSString*) nameStringFromString:(NSString*)str;
+ (NSString*) truncateAndAddEllipsisWithString:(NSString*)str maxLengthIncludingEllipsis:(int)maxLength;
+ (NSString*) commaFormatedStringFromString:(NSString*)str;
+ (NSString*) string:(NSString*)str replaceSubstring:(NSString*)substr withString:(NSString*)repstr;


+(UIButton *)roundedRectButonWithFrame:(CGRect)frame
								 title:(NSString *)title
								target:(id)target
								action:(SEL)action;
+(UIButton *) buttonWithTitle:(NSString *)title
					   target:(id)target
					 selector:(SEL)selector
						frame:(CGRect)frame
						image:(UIImage *)image
				 imagePressed:(UIImage *)imagePressed
				darkTextColor:(BOOL)darkTextColor;
+ (UIButton *) buttonWithFrame:(CGRect)frame 
						 label:(NSString*)label
				  actionTarget:(id)target
						 onTap:(SEL)onTap_cb;
+ (UIButton*) buttonWithNormalImageNamed:(NSString*)normalImageName
						pressedImageName:(NSString*)pressedImageName
							actionTarget:(id)actionTarget
								selector:(SEL)selector
									   x:(float)x
									   y:(float)y;

+ (UIActivityIndicatorView*) activityInidicatorCenteredInSize:(CGSize)size white:(BOOL)white;
+ (UIActivityIndicatorView*) activityInidicatorCenteredInSize:(CGSize)size ;
+ (UIActivityIndicatorView*) activityIndicatorGrayWithX:(float)x y:(float)y;
+ (UIActivityIndicatorView*) activityIndicatorWhite;
+ (UIActivityIndicatorView*) activityIndicatorWhiteWithX:(float)x y:(float)y;

+(UILabel*) labelWithFrame:(CGRect)frame 
					  text:(NSString*)textOrNill
				 textColor:(UIColor*)textColorOrNil 
				  fontName:(NSString*)fontNameOrNil
				  fontSize:(CGFloat)fontSize ;

+(UILabel*) labelWithFrame:(CGRect)frame 
					  text:(NSString*)textOrNill
				 textColor:(UIColor*)textColorOrNil 
				  fontName:(NSString*)fontNameOrNil
				  fontSize:(CGFloat)fontSize 
					  bold:(BOOL)bold;
@end
