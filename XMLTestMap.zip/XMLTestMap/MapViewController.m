    //
//  MapViewController.m
//  SKIIP
//
//  Created by Sayan Chatterjee on 15/04/11.
//  Copyright 2011 ObjectSol. All rights reserved.
//

#import "MapViewController.h"
#import "MyAnnotation.h"


@implementation MapViewController

@synthesize map,coder,lineOverLay;
@synthesize latArr,longArr;

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/

- (id)initWithLocationLatitude:(NSArray *)latitude andLongitude:(NSArray *)longitude {
    self = [super init];
    if (self) {
        // Custom initialization.//
//		location.latitude = [latitude doubleValue];
//		location.longitude = [longitude doubleValue];
//		loc = loc_;
		latArr = [NSMutableArray arrayWithArray:latitude];
		longArr = [NSMutableArray arrayWithArray:longitude];
		
    }
    return self;
}

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	self.title = @"Map";
	MKMapView *aMap = [[MKMapView alloc] initWithFrame:self.view.bounds];
	aMap.showsUserLocation = YES;
	aMap.delegate = self;
	
	//for (int i = 0 ; i < [arrLat count]; i++) {
	
	startLocation.latitude = [[latArr objectAtIndex:0] doubleValue];
	startLocation.longitude = [[longArr objectAtIndex:0] doubleValue];
	endLocation.latitude = [[latArr objectAtIndex:([latArr count] -2)] doubleValue];
	endLocation.longitude = [[longArr objectAtIndex:([longArr count] -2)] doubleValue];
	MKCoordinateSpan mapSpan;
	MKCoordinateRegion mapRegion;
		
	mapSpan.latitudeDelta = 0.01f;
	mapSpan.longitudeDelta = 0.01f;
	
	mapRegion.span = mapSpan;
	mapRegion.center = startLocation;
	
	[aMap setRegion:mapRegion];
	[aMap regionThatFits:mapRegion];
	aMap.userInteractionEnabled = YES;
	/*
	if (self.coder) {
		self.coder = nil;
	}
	if (!self.coder) {
		MKReverseGeocoder *aCoder = [[MKReverseGeocoder alloc] initWithCoordinate:startLocation];
		[aCoder start];
		aCoder.delegate = self;
		self.coder = nil;
		self.coder = aCoder;
		[aCoder release];
	}
	 */
	
		//}
	
	aMap.multipleTouchEnabled = NO;
	self.map = nil;
	self.map = aMap;
	[aMap release];
	[self.view addSubview:self.map];
	/*if (loc) {
		
		[self getCurrentLocation];
	}*/
	NSMutableArray *pointsArr = [NSMutableArray array];
	MyAnnotation *anAnnotation = [[MyAnnotation alloc] init];
	anAnnotation.coordinate = startLocation ;
	anAnnotation.title = @"";
	anAnnotation.subtitle = @"Start Point";
    anAnnotation.pinColor = MKPinAnnotationColorRed;
	[pointsArr addObject:anAnnotation];
	[anAnnotation release],anAnnotation = nil;
    
    anAnnotation = [[MyAnnotation alloc] init];
	anAnnotation.coordinate = endLocation ;
	anAnnotation.title = @"";
	anAnnotation.subtitle = @"End Point";
    anAnnotation.pinColor = MKPinAnnotationColorGreen;
	[pointsArr addObject:anAnnotation];
	[anAnnotation release],anAnnotation = nil;
    
    [map addAnnotations:pointsArr];
     NSMutableArray *points = [NSMutableArray array];
    @try {
        for (int i = 0; i < [latArr count] - 2; i++) {
           
            CLLocation *location = [[CLLocation alloc] initWithCoordinate:CLLocationCoordinate2DMake([[latArr objectAtIndex:i] doubleValue], [[longArr objectAtIndex:i] doubleValue]) altitude:0.0 horizontalAccuracy:0.0 verticalAccuracy:0.0 timestamp:[NSDate date]];
            [points addObject:location];
            [location release];
            
        }
    }
    @catch (NSException *exception) {
        NSLog(@"EXCEPTION 1 : %@",exception);
    }
    @finally {
        ;
    }
		
	//lineOverLay = [self createRouteStartingFrom:CLLocationCoordinate2DMake([[latArr objectAtIndex:i] doubleValue], [[longArr objectAtIndex:i] doubleValue])  toEnd:CLLocationCoordinate2DMake([[latArr objectAtIndex:(i + 1)] doubleValue], [[longArr objectAtIndex:(i + 1)] doubleValue]) ] ; //buugyy 
    lineOverLay = [self createRouteFromPointsArray:(NSArray *)points];
    [map addOverlay:lineOverLay];
	
	
	
//	if (self.coder) {
//		self.coder = nil;
//	}
//	
//	if (!self.coder) {
//		MKReverseGeocoder *aCoder = [[MKReverseGeocoder alloc] initWithCoordinate:endLocation];
//		[aCoder start];
//		aCoder.delegate = self;
//		self.coder = nil;
//		self.coder = aCoder;
//		[aCoder release];
//	}
	 
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

//callout comes up without touching the pin
- (void)displayPinCallOutView:(	id <MKAnnotation>)annotation{
	[self.map selectAnnotation:annotation animated:YES];
}

-(void)getCurrentLocation
{
	if(locationManager)
	{
		[locationManager release];
		locationManager=nil;
	}
	
	locationManager=[[CLLocationManager alloc] init];
	locationManager.delegate=self;
	locationManager.distanceFilter = kCLLocationAccuracyNearestTenMeters;//25.0f;//kCLDistanceFilterNone;
	locationManager.desiredAccuracy= kCLLocationAccuracyBest;//kCLLocationAccuracyBest;
	[locationManager startUpdatingLocation];//need to open
	//hiddenLabel.hidden = NO;
	//[spinner startAnimating];
	// Start heading updates.
	
	
	//self.latitude=@"22.639875";//Airport 1 no
	//self.longitude=@"88.428149";//Airport 1 no
	//[self.delegate locationFound];
}

- (MKPolyline *) createRouteStartingFrom:(CLLocationCoordinate2D)startLocation_  toEnd:(CLLocationCoordinate2D)endLocation_
{
	// Define an overlay that covers Colorado.
    CLLocationCoordinate2D points[2];
	
    points[0] = startLocation_;
    points[1] = endLocation_;
    //points[2] = CLLocationCoordinate2DMake(22.42, 88.42);
    //points[3] = CLLocationCoordinate2DMake(36.99892, -109.045267);
	
    MKPolyline* poly = [MKPolyline polylineWithCoordinates:points count:2];
    poly.title = @"Route";
	
    return poly;
}

- (MKPolyline *) createRouteFromPointsArray:(NSArray *)points{
    int count = [points count];
    CLLocationCoordinate2D coordinates[count];
    for (int i = 0 ; i < count; i++) {
        coordinates[i] = ((CLLocation *)[points objectAtIndex:i]).coordinate;
    }
    MKPolyline* poly = [MKPolyline polylineWithCoordinates:coordinates count:[points count]];
    poly.title = @"Route";
	
    return poly;
}


#pragma mark  -
#pragma mark MKMapView and MKReverseGeocoder Delegates

- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>)annotation;
{
	
	if(annotation == mapView.userLocation)	{
		MKAnnotationView *pin = [[MKAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"pin"];
        pin.image = [UIImage imageNamed:@"pin"];
        return pin;
	}
	else if([annotation isKindOfClass:[MKPlacemark class]]){
        MKAnnotationView *pin = [[MKAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"pin"];
        pin.image = [UIImage imageNamed:@"pin"];
        pin.canShowCallout = YES;
        return pin;
    }else if ([annotation isKindOfClass:[MyAnnotation class]])
	{		
		// Set up the Right callout
		//MKPinAnnotationView *localPin = [[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"Local"];
		//UIButton *detailButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
		//[detailButton addTarget:self action:@selector(markerClicked:) forControlEvents:UIControlEventTouchUpInside];
        MKPinAnnotationView *pin = [[[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"pinloc"]autorelease];
		pin.animatesDrop = YES;
		pin.canShowCallout = YES;
		//pin.rightCalloutAccessoryView = detailButton;
        if ([annotation isKindOfClass:[MyAnnotation class]]) {
            pin.pinColor = ((MyAnnotation *)annotation).pinColor;
        }
		
		//pin.image = [UIImage imageNamed:@"map-pin.png"];
		pin.draggable = YES;
		pin.dragState = YES;
        [self performSelector:@selector(displayPinCallOutView:) withObject:annotation afterDelay:0.3];
		return pin;
		/*
		//pan gesture
		UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(dragPin:)];
		[panGesture setMaximumNumberOfTouches:1];
		[panGesture setMinimumNumberOfTouches:1];
		panGesture.delegate = self;
		[pin addGestureRecognizer:panGesture];
		[panGesture release];
		self.preAnnotation = annotation;*/
		
	}
	
	
}


- (void)reverseGeocoder:(MKReverseGeocoder *)geocoder didFindPlacemark:(MKPlacemark *)placemark{
	
	NSLog(@"Geocoder Succesfull....");
	//self.place = placemark;
	[self.map addAnnotation:placemark];
	//self.detailsLocation.place = placemark;
	
}

- (void)reverseGeocoder:(MKReverseGeocoder *)geocoder didFailWithError:(NSError *)error{
	
	NSLog(@"Geocoder failed....");
	NSLog(@"Error : %@",[error description]);
	/*CLLocationCoordinate2D coordinate = [self.map convertPoint:location toCoordinateFromView:self.view];
	 CKPlaceMark *aPlace = [[CKPlaceMark alloc] initWithCoordinate:coordinate addressDictionary:nil];
	 aPlace.title = @"Unknown";
	 [self.map addAnnotation:aPlace];
	 //[self.coder start];*/
}

- (MKOverlayView *)mapView:(MKMapView *)mapView viewForOverlay:(id <MKOverlay>)overlay
{
	if (lineOverLay) {
		[map removeOverlay:lineOverLay];
	}
    if ([overlay isKindOfClass:[MKPolyline class]])
    {
		//MKPolygonView* aView = [[[MKPolygonView alloc] initWithPolygon:(MKPolygon*)overlay] autorelease];
		MKPolylineView* aView = [[[MKPolylineView alloc] initWithPolyline:(MKPolyline *)overlay]autorelease];
		
        //aView.fillColor = [[UIColor cyanColor] colorWithAlphaComponent:0.2];
        aView.strokeColor = [[UIColor blueColor] colorWithAlphaComponent:0.7];
        aView.lineWidth = 2;
	//self.lineOverLay = aView;
        return aView;
    }
	
    return nil;
}


#pragma mark -
#pragma mark CLLocationManagerDelegate

- (void)locationManager:(CLLocationManager *)manager didUpdateHeading:(CLHeading *)newHeading { 
	
}
-(void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation{
	
	//[spinner stopAnimating];
	//hiddenLabel.hidden = YES;
	CLLocationCoordinate2D coordinate = newLocation.coordinate;
	if (self.coder) {
		self.coder = nil;
	}
	if (!self.coder) {
		//
		//location = loc;
		MKReverseGeocoder *aCoder = [[MKReverseGeocoder alloc] initWithCoordinate:coordinate];
		[aCoder start];
		aCoder.delegate = self;
		self.coder = nil;
		self.coder = aCoder;
		[aCoder release];
		//lineOverLay = [self createRoute:coordinate];
		//lineOverLay.delegate = self;
		//[map addOverlay:lineOverLay];
        
	}
	[locationManager stopUpdatingLocation];
}
-(void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error{
	//[spinner stopAnimating];
	//hiddenLabel.hidden = YES;
	UIAlertView *locationAlert = [[UIAlertView alloc] initWithTitle:@"" 
															message:@"Your Location Could Not Be Determined" 
														   delegate:nil
												  cancelButtonTitle:@"Ok" 
												  otherButtonTitles:nil];
	[locationAlert show];
	[locationAlert release];
}


- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
