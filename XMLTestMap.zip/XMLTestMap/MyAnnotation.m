//
//  MyAnnotation.m
//  carfinder
//
//  Created by Sucharita on 13/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MyAnnotation.h"


@implementation MyAnnotation

@synthesize title;
@synthesize subtitle;
@synthesize coordinate;
@synthesize pinColor;
//@synthesize latitude, longitude;
@synthesize tag;
- (void)dealloc 
{
	[super dealloc];
	self.title = nil;
	self.subtitle = nil;
}



@end
