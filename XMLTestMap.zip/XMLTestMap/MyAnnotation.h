//
//  MyAnnotation.h
//  carfinder
//
//  Created by Sucharita on 13/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>



#import <MapKit/MapKit.h>


@interface MyAnnotation : NSObject<MKAnnotation> {
	
	CLLocationCoordinate2D	coordinate;
	//float latitude;
	//float longitude;
	NSString*				title;
	NSString*				subtitle;
	int tag;
    MKPinAnnotationColor pinColor;
}
@property (nonatomic,assign) int tag;
@property (nonatomic,assign) MKPinAnnotationColor pinColor;
@property (nonatomic, assign)	CLLocationCoordinate2D	coordinate;
//@property (assign) float latitude;
//@property (assign) float longitude;
@property (nonatomic, copy)		NSString*				title;
@property (nonatomic, copy)		NSString*				subtitle;
@end