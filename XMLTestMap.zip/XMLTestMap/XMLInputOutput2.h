//
//  XMLInputOutput2.h
//  XMLTest
//
//  Created by Sayan Chatterjee on 11/04/11.
//  Copyright 2011 ObjectSol. All rights reserved.
//

void initXMLInputOutput2(void);

