//
//  XMLWritter.h
//  XMLTest
//
//  Created by Sayan Chatterjee on 11/04/11.
//  Copyright 2011 ObjectSol. All rights reserved.
//


#include <stdio.h>
#include <string.h>
#include <libxml/encoding.h>
#include <libxml/xmlwriter.h>

void initXMLWritter(void);
void testXmlwriterFilename(const char *uri);
void testXmlwriterMemory(const char *file);
void testXmlwriterDoc(const char *file);
void testXmlwriterTree(const char *file);
xmlChar *ConvertInput(const char *in, const char *encoding);


