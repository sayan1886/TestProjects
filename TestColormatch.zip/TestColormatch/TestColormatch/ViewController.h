//
//  ViewController.h
//  TestColormatch
//
//  Created by Sayan on 22/12/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController{
    
}

- (CGContextRef) CreateARGBBitmapContext:(CGImageRef) inImage;
- (CGContextRef) createARGBBitmapContextFromImage:(CGImageRef) inImage;
@end
