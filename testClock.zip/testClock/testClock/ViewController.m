//
//  ViewController.m
//  testClock
//
//  Created by sbhuin on 11/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"
#import "ClockView.h"

int counter;

@implementation ViewController

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    counter = 1;
	// Do any additional setup after loading the view, typically from a nib.
    
    cv = [[ClockView alloc] initWithFrame:CGRectMake(20, 20, 120, 120)];
    cv.backgroundColor = [UIColor yellowColor];
    [self.view addSubview:cv];
    
    //[self performSelector:@selector(doOp:) withObject:cv afterDelay:1.0];
    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(doOp) userInfo:nil repeats:YES];
}

- (void)doOp{
    [cv setSecond:counter++];
    if (counter >= 60) {
        counter = 1;
    }
    //[self performSelector:@selector(doOp:) withObject:view afterDelay:1.0];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
