//
//  ClockView.m
//  testClock
//
//  Created by sbhuin on 11/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ClockView.h"
#import <math.h>

@implementation ClockView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        secondView = [[UIImageView alloc] init];
        CGFloat midx = frame.size.width/2;
        CGFloat midy = frame.size.height/2;
        UIImage *image = [UIImage imageNamed:@"clock.png"];
        secondView.image = image;
        secondView.frame = CGRectMake(midx-image.size.width/2, midy-image.size.height/2, image.size.width, image.size.height);
        [self addSubview:secondView];
        _rotation = 0;
        [self setClipsToBounds:YES];
    }
    return self;
}


- (void)setSecond:(int)second {
    _rotation = second*6*(M_PI/180);
    [self setNeedsDisplay];
}

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    
    // Drawing code
    secondView.transform = CGAffineTransformIdentity;
    secondView.transform = CGAffineTransformMakeRotation(_rotation);
}


-(void)dealloc {
    [secondView release];
    [super dealloc];
}

@end
