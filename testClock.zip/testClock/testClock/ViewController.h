//
//  ViewController.h
//  testClock
//
//  Created by sbhuin on 11/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ClockView;
@interface ViewController : UIViewController
{
    ClockView *cv;
}
@end
