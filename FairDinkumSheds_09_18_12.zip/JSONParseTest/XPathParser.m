//
//  XPathParser.m
//  XMLTest
//
//  Created by Sayan Chatterjee on 31/01/11.
//  Copyright 2011 ObjectSol. All rights reserved.
//

#import "XPathParser.h"
#import "XPathQuery.h"

@implementation XPathParser

@synthesize parseQuery,recievedData;

/*- (id) init{
	if (self) {
		[super init];
		//[self.conn init];
		self.element = [[NSArray alloc]init];
	}
	return self;
}

-(void) doParse:(NSString *)query{

	AsyncURLConnection *myCon = [[AsyncURLConnection alloc] init];
	self.conn	 = myCon;
	myCon.callback = self;
	[myCon release];
	[self.conn connectToURL];
	self.parseQuery = query;
		
}

- (void) handleSuccess{
	NSLog(@"SAYAN");
	//NSLog(@"XML : %@",self.element);
	NSData *xmlData = [[NSData alloc] init];
	xmlData = [self.conn resultBuffer];
	NSArray *xmlArr  = [[NSArray alloc] initWithArray: PerformXMLXPathQuery(xmlData, self.parseQuery)];
	self.element = xmlArr;
	[xmlArr release];
	NSLog(@"Xml String : %@",self.conn.bufferedURL);
	NSLog(@"XML DATA : %@",xmlData);
	NSLog(@"Parse® data : %@",self.element);
}

- (void) handleError{

}

- (NSArray *)  element{
	NSLog(@"SAYAN....");
	return [self.element autorelease];
}

- (void) dealloc{
	[self.conn release];
	[self.element release];
	[super dealloc];
}*/

-(id)initWithTarget:(id)sender{
	
	target = sender;
    hasAction = NO;
	recievedData = [NSMutableData new];
	if ([target isKindOfClass:[UIViewController class]] || [target isKindOfClass:[UIView class]]) {
		loadingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
		loadingView.backgroundColor = [UIColor colorWithRed:0.0 green:0.0 blue:0.0 alpha:0.5];
		spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
		[loadingView addSubview:spinner];
		spinner.center = CGPointMake(160, 240);
		if([target isKindOfClass:[UIViewController class]]){
			UIViewController *tempView = (UIViewController *)target;
			[tempView.view addSubview:loadingView];
		}
		else {
			UIView *tempView = (UIView *)target;
			[tempView addSubview:loadingView];
		}
		
	}
	return [self autorelease];
}

-(id)initWithTarget:(id)sender action:(SEL)action{
    target = sender;
    action_ = action;
    hasAction = YES;
	recievedData = [NSMutableData new];
	if ([target isKindOfClass:[UIViewController class]] || [target isKindOfClass:[UIView class]]) {
		loadingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
		loadingView.backgroundColor = [UIColor colorWithRed:0.0 green:0.0 blue:0.0 alpha:0.5];
		spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
		[loadingView addSubview:spinner];
		spinner.center = CGPointMake(160, 240);
		if([target isKindOfClass:[UIViewController class]]){
			UIViewController *tempView = (UIViewController *)target;
			[tempView.view addSubview:loadingView];
		}
		else {
			UIView *tempView = (UIView *)target;
			[tempView addSubview:loadingView];
		}
		
	}
	return [self autorelease];
}

- (void) parseXML {
	    if (hasAction) {
        [target performSelector:action_ withObject:PerformXMLXPathQuery(recievedData, parseQuery)];
    }
    else{
        [target performSelector:@selector(getXMLArray:) withObject:PerformXMLXPathQuery(recievedData, parseQuery)];
    }
}

- (void ) downloadXMLFromURL:(NSString *)urlString andQuery:(NSString *)query{
	self.parseQuery = query;
	if (loadingView) {
		[spinner startAnimating];
		UILabel *lab = [[UILabel alloc] initWithFrame:CGRectMake(35, 260, 250, 50)];
		lab.text = @"Page is Loading....Please Wait.";
		lab.textColor = [UIColor whiteColor];
		lab.font = [UIFont boldSystemFontOfSize:14];
		lab.textAlignment = UITextAlignmentCenter;
		lab.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		lab.backgroundColor = [UIColor clearColor];
		[loadingView addSubview:lab];
		[lab release];
	}
	
	NSLog(@"URL : %@",urlString);
	NSURLRequest *urlRequest = [NSURLRequest requestWithURL:[NSURL URLWithString:urlString]
												cachePolicy:NSURLRequestReturnCacheDataElseLoad
											timeoutInterval:30];
	
	// Fetch the JSON response Using A Asyncronus Connection
	
	[NSURLConnection connectionWithRequest:urlRequest delegate:self];
}

#pragma mark -
#pragma mark NSURLConnectionDelegate

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response{
	
	NSLog(@"HERE RESPONSE: %d",[(NSHTTPURLResponse*) response statusCode]);
	NSLog(@"response: %@",[response description]);
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data{
	
	[recievedData appendData:data];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection{
	
	//NSString *xmlString = [[NSString alloc] initWithData:recievedData encoding:NSUTF8StringEncoding];
	[self performSelector:@selector(parseXML) ];
	if (loadingView) {
		[spinner stopAnimating];
		[loadingView removeFromSuperview];
	}
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error{
	
	NSLog(@"ERROR: %@",[error description]);
	NSString *errorString = [error localizedDescription];
	NSDictionary *dict = [NSDictionary dictionaryWithObject:errorString forKey:@"error"];
	NSArray *arr = [NSArray arrayWithObject:dict];
	[target performSelector:@selector(getXMLArray:) withObject:arr];
	if (loadingView) {
		[spinner stopAnimating];
		[loadingView removeFromSuperview];
	}
}

-(void)dealloc{
	
	[recievedData release], recievedData = nil;
	[loadingView release], loadingView = nil;
	[super dealloc];
}

@end



