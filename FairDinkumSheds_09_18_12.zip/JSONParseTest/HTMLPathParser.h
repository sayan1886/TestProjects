//
//  HTMLPathParser.h
//  JSONParseTest
//
//  Created by Sayan Chatterjee on 18/03/11.
//  Copyright 2011 ObjectSol. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AsyncURLConnection.h"

@interface HTMLPathParser : NSObject <CallBack> {

	AsyncURLConnection *conn;
	NSArray *element;
	NSString *parseQuery;
	
	
}

//- (NSArray *) element;
-(void) doParse:(NSString *)query;

@property (nonatomic,retain) AsyncURLConnection *conn;
@property (nonatomic,retain) NSArray *element;
@property (nonatomic,retain) 	NSString *parseQuery;
@end
