//
//  JSONParseTestAppDelegate.h
//  JSONParseTest
//
//  Created by Sayan Chatterjee on 18/03/11.
//  Copyright 2011 ObjectSol. All rights reserved.
//

#import <UIKit/UIKit.h>

@class JSONParseTestViewController;

@interface JSONParseTestAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    JSONParseTestViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet JSONParseTestViewController *viewController;

@end

