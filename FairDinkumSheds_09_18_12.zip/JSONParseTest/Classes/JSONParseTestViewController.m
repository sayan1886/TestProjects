//
//  JSONParseTestViewController.m
//  JSONParseTest
//
//  Created by Sayan Chatterjee on 18/03/11.
//  Copyright 2011 ObjectSol. All rights reserved.
//

#import "JSONParseTestViewController.h"
#import "JSONParser.h"
#import "XPathParser.h"

@implementation JSONParseTestViewController


#pragma mark -
#pragma mark viewLifeCycle

/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/



// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    
	[super viewDidLoad];
	
	//UIWebView *webView = [[UIWebView alloc]initWithFrame:CGRectMake(0, 0, 320, 480)];
//	spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
//	[spinner setCenter:CGPointMake(320/2.0, 480/2.0)]; 
//	[self.view addSubview:spinner];
	//[spinner startAnimating];
	
	//NSMutableDictionary *jsonDict = [[NSDictionary alloc]initWithDictionary:[parser downloadJSONFromURL:@"http://fluorescent-monkey.com/app.php?action=getfaq"]];
	//NSURL *url = [NSURL URLWithString:@"http://fluorescent-monkey.com/app.php?action=getfaq"];
	//NSString *page = [jsonDict objectForKey:@"faq_content"];  // get fragment from RSS feed
	//[page autorelease]; // if not already autoreleased to prevent a memory leak
	
	/*page = [page stringByReplacingOccurrencesOfString:@"&lt;" withString:@"<"];
	page = [page stringByReplacingOccurrencesOfString:@"&gt;" withString:@">"];
	page = [page stringByReplacingOccurrencesOfString:@"&amp;" withString:@"&"];
	page = [page stringByReplacingOccurrencesOfString:@"&quot;" withString:@"\""];

	NSLog(@"data: %@",page);
	[webView loadHTMLString:page baseURL:url];
	[self.view addSubview:webView];
	[spinner stopAnimating];*/
	
	
	UIButton *btn1 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
	btn1.frame = CGRectMake(60, 150, 200, 50);
	[btn1 setTitle:@"Parse JSON Data" forState:UIControlStateNormal];
	[btn1 addTarget:self action:@selector(parseJSONData:) forControlEvents:UIControlEventTouchUpInside];
	[self.view addSubview:btn1];
	
	UIButton *btn2 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
	btn2.frame = CGRectMake(60, 250, 200, 50);
	[btn2 setTitle:@"Parse XML Data" forState:UIControlStateNormal];
	[btn2 addTarget:self action:@selector(parseXMLData:) forControlEvents:UIControlEventTouchUpInside];
	[self.view addSubview:btn2];
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

#pragma mark -
#pragma mark parseJSONData

- (void)parseJSONData:(id)sender{
	
	JSONParser *parser = [[JSONParser alloc]initWithTarget:self];
	[parser downloadJSONFromURL:@"http://www.skiipmobile.com/skiip/user.php?action=guestlist_event&pid=2&event_id=2"];
}

- (void)getJSONDictionary:(NSDictionary *)jsonDict{

	if ([jsonDict objectForKey:@"error"]) {
		NSLog(@"ERROR: %@",[jsonDict objectForKey:@"error"]);
	}
	else {
		NSLog(@"JSON : %@",jsonDict);

	}

}

#pragma mark -
#pragma mark parseXMLData

- (void)parseXMLData:(id)sender{
	XPathParser *parser = [[XPathParser alloc]initWithTarget:self];
//	[parser downloadXMLFromURL:@"http://maps.googleapis.com/maps/api/directions/xml?origin=kolkata&destination=delhi&region=es&sensor=true"
//					  andQuery:@"//start_location"];	
    [parser downloadXMLFromURL:@"https://www.google.com/ig/api?weather=kolkata" andQuery:@"//weather"];
}

- (void)getXMLArray:(NSArray *)xmlArr{
	
	if ([[xmlArr objectAtIndex:0] objectForKey:@"error"]) {
		NSLog(@"ERROR: %@",[[xmlArr objectAtIndex:0] objectForKey:@"error"]);
	}
	else {
        NSLog(@"ITEMS : %d",[[((NSDictionary *)[xmlArr objectAtIndex:0]) objectForKey:@"nodeChildArray"] count]);
        int i = 1;
        for (NSDictionary *dict in [((NSDictionary *)[xmlArr objectAtIndex:0]) objectForKey:@"nodeChildArray"]) {
            NSLog(@"Item%d :  %@",i++,dict);
        }
//		NSLog(@"ForeCast Info : %@",[[[((NSDictionary *)[xmlArr objectAtIndex:0]) objectForKey:@"nodeChildArray"] objectAtIndex:0] objectForKey:@"nodeChildArray"]);
//		NSLog(@"XML : %@",[[[((NSDictionary *)[xmlArr objectAtIndex:0]) objectForKey:@"nodeChildArray"] objectAtIndex:1] objectForKey:@"nodeChildArray"]);
	}
	
}

#pragma mark -
#pragma mark WebViewControllerDelegate

- (void)webViewDidStartLoad:(UIWebView *)webView_{
	
	//[spinner startAnimating];
	//[aTools startLoading:self.view childView:loadingView text:@"Loading....Please Wait…"];
}
- (void)webViewDidFinishLoad:(UIWebView *)webView_{
	//[spinner stopAnimating];
	//[aTools stopLoading:loadingView];

}
- (void)webView:(UIWebView *)webView_ didFailLoadWithError:(NSError *)error{
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" 
													message:(@"%@",[error description]) 
												   delegate:nil 
										  cancelButtonTitle:@"OK" 
										  otherButtonTitles:nil];
	[alert show];
	[alert release];
}


#pragma mark -
#pragma mark memoryManagement

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}

@end
