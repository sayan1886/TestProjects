//
//  HTMLPathParser.m
//  JSONParseTest
//
//  Created by Sayan Chatterjee on 18/03/11.
//  Copyright 2011 ObjectSol. All rights reserved.
//

#import "HTMLPathParser.h"


@implementation HTMLPathParser

@synthesize conn,element,parseQuery;

- (id) init{
	if (self) {
		[super init];
		//[self.conn init];
		self.element = [[NSArray alloc]init];
	}
	return self;
}

-(void) doParse:(NSString *)query{
	
	AsyncURLConnection *myCon = [[AsyncURLConnection alloc] initWithURLString:@"http://fluorescent-monkey.com/app.php?action=getfaq"];
	self.conn	 = myCon;
	myCon.callback = self;
	[myCon release];
	[self.conn connectToURL];
	self.parseQuery = query;
	
}

- (void) handleSuccess{
	NSLog(@"SAYAN");
	//NSLog(@"XML : %@",self.element);
	NSData *htmlData = [[NSData alloc] init];
	htmlData = [self.conn resultBuffer];
	NSArray *htmlArr  = [[NSArray alloc] initWithArray: PerformHTMLXPathQuery(htmlData, self.parseQuery)];
	self.element = htmlArr;
	[htmlArr release];
	NSLog(@"Xml String : %@",self.conn.bufferedURL);
	NSLog(@"XML DATA : %@",htmlData);
	NSLog(@"Parse® data : %@",self.element);
	[htmlData release];
}

- (void) handleError{
	
}

/*- (NSArray *)  element{
 NSLog(@"SAYAN....");
 return [self.element autorelease];
 }*/

- (void) dealloc{
	[self.conn release];
	[self.element release];
	[super dealloc];
}


@end
