//
//  XPathParser.h
//  XMLTest
//
//  Created by Sayan Chatterjee on 31/01/11.
//  Copyright 2011 ObjectSol. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface XPathParser : NSObject {

	id target;
    SEL action_;
    BOOL hasAction;
	NSMutableData *recievedData;
	UIActivityIndicatorView *spinner;
	UIView *loadingView;
	//NSArray *element;
	NSString *parseQuery;
	
	
}

//@property (nonatomic,retain) NSArray *element;
@property (nonatomic,retain) 	NSString *parseQuery;
@property (nonatomic,retain) NSMutableData *recievedData;

-(id)initWithTarget:(id)sender;
-(id)initWithTarget:(id)sender action:(SEL)action;
- (void) parseXML ;
- (void ) downloadXMLFromURL:(NSString *)urlString andQuery:(NSString *)query;
//-(void) doParse:(NSString *)query;


@end
