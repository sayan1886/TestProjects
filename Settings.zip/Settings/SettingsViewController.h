//
//  SettingsViewController.h
//  BigGameRegs
//
//  Created by Sayan on 01/03/11.
//  Copyright 2011 Sportsmanregs LLC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>

@interface SettingsViewController : UIViewController <MFMailComposeViewControllerDelegate>{

	NSArray *tabContent;
	NSArray *sectionContent1;
	NSArray *sectionContent2;
	NSArray *sectionContent3;
}

@property (nonatomic,retain) 	NSArray *tabContent;
@property (nonatomic,retain) NSArray *sectionContent1;
@property (nonatomic,retain) NSArray *sectionContent2;
@property (nonatomic,retain) NSArray *sectionContent3;

-(void)callForSendingMail;
-(void)displayComposerSheet;
-(void)launchMailAppOnDevice;

@end
