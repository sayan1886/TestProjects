//
//  SeasonColorViewController.m
//  BigGameRegs
//
//  Created by Sayan on 07/03/11.
//  Copyright 2011 Sportsmanregs LLC. All rights reserved.
//

#import "SeasonColorViewController.h"
//#import "PickerIndex.h"
//#import "CustomUITableViewCell.h"
#import <QuartzCore/QuartzCore.h>
//#import "UserSettings.h"
#import "constant.h"
#import "BigGameSettings.h"

@implementation SeasonColorViewController

@synthesize tabView,tabContent,colorArr,scroll;
@synthesize colorBox1,colorBox2,colorBox3,colorBox4,colorBox5,lab;
@synthesize button1,button2,button3,button4,button5;
@synthesize dataDict,colorArray;
//@synthesize colorSwatch;

//int checkBoxToggle = 0;
//int noOfSection = 1;
int checkBoxTag = 0;
int selectedColorTag = 1;
//UIColor *color;

#pragma mark -
#pragma mark viewLifeCycle

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	self.title = @"Hunt Color";
	self.view.backgroundColor = [UIColor groupTableViewBackgroundColor];
    scroll.backgroundColor = [UIColor groupTableViewBackgroundColor];
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, scroll.frame.size.height, 1024, 200)];
    view.backgroundColor = [UIColor groupTableViewBackgroundColor];
    view.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleHeight;
    view.autoresizesSubviews = YES;
	[self.view addSubview:view];
    [view release];
	tabContent = [[NSArray alloc] initWithObjects:@"Weapon",@"Animal Characteristics",@"Classification",@"Subspecies",nil] ;
	colorArr = [[NSArray alloc]initWithObjects:@"color_1.png",@"color_2.png",@"color_3.png",@"color_4.png",@"color_5.png",nil ];
	dataDict = [[NSMutableDictionary alloc] init];
	colorArray = [[NSMutableArray alloc] init];
	for (int i = 0; i < [tabContent count]; i++) {
		if([[[[BigGameSettings appSettings] getSeasonColorData]objectForKey:@"row"] isEqualToString:[tabContent objectAtIndex:i]]){
			checkBoxTag = i;
			break;
		}
			
	}
	selectedRowIndex = checkBoxTag;
	selectedColorTag = [[[[BigGameSettings appSettings] getSeasonColorData] objectForKey:@"color"] intValue];
	NSLog(@"SelectedColor Tag: %d",selectedColorTag);
	[self	 createGUI];	
	
}



// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
	if (interfaceOrientation == UIInterfaceOrientationLandscapeLeft || 
		interfaceOrientation == UIInterfaceOrientationLandscapeRight) {
        if(IS_iPAD()){
            self.view.frame = CGRectMake(0, 0, 1024, 768);
            scroll.frame = CGRectMake(0, 0, 1024, 768);
            colorBox1.frame = CGRectMake(497, 250, 30, 30);
            colorBox2.frame = CGRectMake(497, 290, 30, 30);
            colorBox3.frame = CGRectMake(497, 330, 30, 30);
            colorBox4.frame = CGRectMake(497, 370, 30, 30);
            colorBox5.frame = CGRectMake(497, 410, 30, 30);
            button1.frame = CGRectMake(497, 250, 30, 30);
            button2.frame = CGRectMake(497, 290, 30, 30);
            button3.frame = CGRectMake(497, 330, 30, 30);
            button4.frame = CGRectMake(497, 370, 30, 30);
            button5.frame = CGRectMake(497, 410, 30, 30);
        }
        else{
            scroll.frame = CGRectMake(0, 0, 480, 320);
            scroll.contentSize = CGSizeMake(480, 480);
            tabView.frame = CGRectMake(0, 0, 480, 300);
            colorBox1.frame = CGRectMake(225, 200, 30, 30);
            colorBox2.frame = CGRectMake(225, 240, 30, 30);
            colorBox3.frame = CGRectMake(225, 280, 30, 30);
            colorBox4.frame = CGRectMake(225, 320, 30, 30);
            colorBox5.frame = CGRectMake(225, 360, 30, 30);
            button1.frame = CGRectMake(225, 200, 30, 30);
            button2.frame = CGRectMake(225, 240, 30, 30);
            button3.frame = CGRectMake(225, 280, 30, 30);
            button4.frame = CGRectMake(225, 320, 30, 30);
            button5.frame = CGRectMake(225, 360, 30, 30);
            
            
        }
		
	}
	else {
        if(IS_iPAD()){
            self.view.frame = CGRectMake(0, 0, 768, 1024);
            scroll.frame = CGRectMake(0, 0, 768, 1024);
            colorBox1.frame = CGRectMake(345, 250, 30, 30);
            colorBox2.frame = CGRectMake(345, 290, 30, 30);
            colorBox3.frame = CGRectMake(345, 330, 30, 30);
            colorBox4.frame = CGRectMake(345, 370, 30, 30);
            colorBox5.frame = CGRectMake(345, 410, 30, 30);
            button1.frame = CGRectMake(345, 250, 30, 30);
            button2.frame = CGRectMake(345, 290, 30, 30);
            button3.frame = CGRectMake(345, 330, 30, 30);
            button4.frame = CGRectMake(345, 370, 30, 30);
            button5.frame = CGRectMake(345, 410, 30, 30);
        }
        else{
            scroll.frame = CGRectMake(0, 0, 320, 480);
            scroll.contentSize = CGSizeMake(320, 480);
            tabView.frame = CGRectMake(0, 0, 320, 300);
            colorBox1.frame = CGRectMake(145, 200, 30, 30);
            colorBox2.frame = CGRectMake(145, 240, 30, 30);
            colorBox3.frame = CGRectMake(145, 280, 30, 30);
            colorBox4.frame = CGRectMake(145, 320, 30, 30);
            colorBox5.frame = CGRectMake(145, 360, 30, 30);
            button1.frame = CGRectMake(145, 200, 30, 30);
            button2.frame = CGRectMake(145, 240, 30, 30);
            button3.frame = CGRectMake(145, 280, 30, 30);
            button4.frame = CGRectMake(145, 320, 30, 30);
            button5.frame = CGRectMake(145, 360, 30, 30);
        }
        
	}
    return YES;	
}

- (void) didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation{
	if (fromInterfaceOrientation == UIInterfaceOrientationPortraitUpsideDown || fromInterfaceOrientation == UIInterfaceOrientationPortrait) {
		if(IS_iPAD()){
            self.view.frame = CGRectMake(0, 0, 1024, 768);
            scroll.frame = CGRectMake(0, 0, 1024, 768);
            colorBox1.frame = CGRectMake(497, 250, 30, 30);
            colorBox2.frame = CGRectMake(497, 290, 30, 30);
            colorBox3.frame = CGRectMake(497, 330, 30, 30);
            colorBox4.frame = CGRectMake(497, 370, 30, 30);
            colorBox5.frame = CGRectMake(497, 410, 30, 30);
            button1.frame = CGRectMake(497, 250, 30, 30);
            button2.frame = CGRectMake(497, 290, 30, 30);
            button3.frame = CGRectMake(497, 330, 30, 30);
            button4.frame = CGRectMake(497, 370, 30, 30);
            button5.frame = CGRectMake(497, 410, 30, 30);
        }
        else{
            scroll.frame = CGRectMake(0, 0, 480, 320);
            scroll.contentSize = CGSizeMake(480, 480);
            tabView.frame = CGRectMake(0, 0, 480, 300);
            colorBox1.frame = CGRectMake(225, 200, 30, 30);
            colorBox2.frame = CGRectMake(225, 240, 30, 30);
            colorBox3.frame = CGRectMake(225, 280, 30, 30);
            colorBox4.frame = CGRectMake(225, 320, 30, 30);
            colorBox5.frame = CGRectMake(225, 360, 30, 30);
            button1.frame = CGRectMake(225, 200, 30, 30);
            button2.frame = CGRectMake(225, 240, 30, 30);
            button3.frame = CGRectMake(225, 280, 30, 30);
            button4.frame = CGRectMake(225, 320, 30, 30);
            button5.frame = CGRectMake(225, 360, 30, 30);
            
        }	}
	else {
		if(IS_iPAD()){
            self.view.frame = CGRectMake(0, 0, 768, 1024);
            scroll.frame = CGRectMake(0, 0, 768, 1024);
            colorBox1.frame = CGRectMake(345, 250, 30, 30);
            colorBox2.frame = CGRectMake(345, 290, 30, 30);
            colorBox3.frame = CGRectMake(345, 330, 30, 30);
            colorBox4.frame = CGRectMake(345, 370, 30, 30);
            colorBox5.frame = CGRectMake(345, 410, 30, 30);
            button1.frame = CGRectMake(345, 250, 30, 30);
            button2.frame = CGRectMake(345, 290, 30, 30);
            button3.frame = CGRectMake(345, 330, 30, 30);
            button4.frame = CGRectMake(345, 370, 30, 30);
            button5.frame = CGRectMake(345, 410, 30, 30);
        }
        else{
            scroll.frame = CGRectMake(0, 0, 320, 480);
            scroll.contentSize = CGSizeMake(320, 480);
            tabView.frame = CGRectMake(0, 0, 320, 300);
            colorBox1.frame = CGRectMake(145, 200, 30, 30);
            colorBox2.frame = CGRectMake(145, 240, 30, 30);
            colorBox3.frame = CGRectMake(145, 280, 30, 30);
            colorBox4.frame = CGRectMake(145, 320, 30, 30);
            colorBox5.frame = CGRectMake(145, 360, 30, 30);
            button1.frame = CGRectMake(145, 200, 30, 30);
            button2.frame = CGRectMake(145, 240, 30, 30);
            button3.frame = CGRectMake(145, 280, 30, 30);
            button4.frame = CGRectMake(145, 320, 30, 30);
            button5.frame = CGRectMake(145, 360, 30, 30);
        }
		
	}
}


- (void) viewWillAppear:(BOOL)animated{
	
}

- (void) viewWillDisappear:(BOOL)animated{
	[dataDict setObject:[tabContent objectAtIndex:selectedRowIndex] forKey:@"row"];
	NSMutableArray *tempArr = [[NSMutableArray alloc] init];
	for (int i = 0; i < 5; i++) {
		NSString *key = [NSString stringWithFormat:@"Color%d",(i + 1)];
		NSData *colorData = [[NSUserDefaults standardUserDefaults] objectForKey:key];
		UIColor *color;
		if (colorData!=nil) {
			// If the data object is valid, unarchive the color we've stored in it.
			color = (UIColor *)[NSKeyedUnarchiver unarchiveObjectWithData:colorData];
		} else {
			// If the data's not valid, the user default wasn't set, or there was an error retrieving the default value.
			
			// This is not the Apple-sanctioned way to set up defaults, but it _is_ permissible
			// The correct way to do it would be to register 'fall-back' defaults when the app launches for the first time,
			// usually via the app delegate.
			//
			// I've done it this way to consolidate initial defaults with error-checking code.
			
			// Create a new color 
			if (i == 0) {
                color = [UIColor colorWithRed:0.210479 green:0.755696 blue:0.949 alpha:1.0];
                colorData = [NSKeyedArchiver archivedDataWithRootObject:color];
            }
            if (i == 1) {
                color = [UIColor colorWithRed:0.856667 green:0.3 blue:0.378456 alpha:1.0];
                colorData = [NSKeyedArchiver archivedDataWithRootObject:color];
            }
            if (i == 2) {
                color = [UIColor colorWithRed:0.346214 green:0.83 blue:0.248677 alpha:1.0];;
                colorData = [NSKeyedArchiver archivedDataWithRootObject:color];
            }
            if (i == 3) {
                color = [UIColor colorWithRed:0.882738 green:0.886 blue:0.399907 alpha:1.0];;
                colorData = [NSKeyedArchiver archivedDataWithRootObject:color];
            }
            if (i == 4) {
                color = [UIColor colorWithRed:0.806667 green:0.710965 blue:0.621479 alpha:1.0];
                colorData = [NSKeyedArchiver archivedDataWithRootObject:color];
            }
			
		}
		[tempArr addObject:colorData];
	}
	[dataDict setObject:tempArr forKey:@"colors"];
	[dataDict setObject:[NSString stringWithFormat:@"%d",selectedColorTag] forKey:@"color"];
	[tempArr release];
	//NSLog(@"DATADICT : %@",dataDict);
	NSDictionary *saveDict = [NSDictionary dictionaryWithDictionary:dataDict];
	[[BigGameSettings appSettings] setSeasonColorData:saveDict];
	/*
	[[NSUserDefaults standardUserDefaults] setObject:saveDict forKey:@"colors"];
	[[NSUserDefaults standardUserDefaults] setObject:[tabContent objectAtIndex:selectedRowIndex] forKey:@"row"];
	[[NSUserDefaults standardUserDefaults] setObject:[NSString stringWithFormat:@"%d",selectedColorTag] forKey:@"color"];*/
		
}

#pragma mark -
#pragma mark classMethod
- (void) createGUI{
	
	NSDictionary *dict = [NSDictionary dictionaryWithDictionary:[[BigGameSettings appSettings] getSeasonColorData]];
	NSArray *arr = [dict objectForKey:@"colors"];
    
	colorBox1 = [[UILabel alloc] initWithFrame:CGRectMake(140 , 200 , 30, 30)];
	colorBox1.backgroundColor = (UIColor *)[NSKeyedUnarchiver unarchiveObjectWithData:[arr objectAtIndex:0]];	//[UIColor
	[scroll addSubview:colorBox1];
	
	UIButton *btn1 = [UIButton buttonWithType:UIButtonTypeCustom];
	btn1.frame = CGRectMake(140 , 200 , 30, 30);
	[btn1 setShowsTouchWhenHighlighted:YES];
	btn1.tag = 1;
    self.button1 = btn1;
	//btn1.highlighted = YES;
	[btn1 addTarget:self action:@selector(selectColor:) forControlEvents:UIControlEventTouchUpInside];
	[scroll addSubview:btn1];
	
	[[colorBox1 layer] setCornerRadius: 5 ];
	[[colorBox1 layer] setBorderWidth:1];
	[[colorBox1 layer] setBorderColor:[[ UIColor blackColor] CGColor]];
	//[colorBox1 release];
	
	colorBox2 = [[UILabel alloc] initWithFrame:CGRectMake(140 , 240 , 30, 30)];
	colorBox2.backgroundColor = (UIColor *)[NSKeyedUnarchiver unarchiveObjectWithData:[arr objectAtIndex:1]];	//[UIColor
	[scroll addSubview:colorBox2];
	
	UIButton *btn2 = [UIButton buttonWithType:UIButtonTypeCustom];
	btn2.frame = CGRectMake(140 , 240 , 30, 30);
	[btn2 setShowsTouchWhenHighlighted:YES];
	btn2.tag = 2;
    self.button2 = btn2;
	//btn2.highlighted = YES;
	[btn2 addTarget:self action:@selector(selectColor:) forControlEvents:UIControlEventTouchUpInside];
	[scroll addSubview:btn2];
	
	[[colorBox2 layer] setCornerRadius: 5 ];
	[[colorBox2 layer] setBorderWidth:1];
	[[colorBox2 layer] setBorderColor:[[ UIColor blackColor] CGColor]];
	//[colorBox2 release];
	
	colorBox3 = [[UILabel alloc] initWithFrame:CGRectMake(140 , 280 , 30, 30)];
	colorBox3.backgroundColor = (UIColor *)[NSKeyedUnarchiver unarchiveObjectWithData:[arr objectAtIndex:2]];	//[UIColor
	[scroll addSubview:colorBox3];
	
	UIButton *btn3 = [UIButton buttonWithType:UIButtonTypeCustom];
	btn3.frame = CGRectMake(140 , 280 , 30, 30);
	[btn3 setShowsTouchWhenHighlighted:YES];
	btn3.tag = 3;
    self.button3 = btn3;
	//btn3.highlighted = YES;
	[btn3 addTarget:self action:@selector(selectColor:) forControlEvents:UIControlEventTouchUpInside];
	[scroll addSubview:btn3];
	
	[[colorBox3 layer] setCornerRadius: 5 ];
	[[colorBox3 layer] setBorderWidth:1];
	[[colorBox3 layer] setBorderColor:[[ UIColor blackColor] CGColor]];
	//[colorBox3 release];
	
	colorBox4 = [[UILabel alloc] initWithFrame:CGRectMake(140 , 320 , 30, 30)];
	colorBox4.backgroundColor = (UIColor *)[NSKeyedUnarchiver unarchiveObjectWithData:[arr objectAtIndex:3]];	//[UIColor
	[scroll addSubview:colorBox4];
	
	UIButton *btn4 = [UIButton buttonWithType:UIButtonTypeCustom];
	btn4.frame = CGRectMake(140 , 320 , 30, 30);
	[btn4 setShowsTouchWhenHighlighted:YES];
	btn4.tag = 4;
    self.button4 = btn4;
	//btn4.highlighted = YES;
	[btn4 addTarget:self action:@selector(selectColor:) forControlEvents:UIControlEventTouchUpInside];
	[scroll addSubview:btn4];
	
	[[colorBox4 layer] setCornerRadius: 5 ];
	[[colorBox4 layer] setBorderWidth:1];
	[[colorBox4 layer] setBorderColor:[[ UIColor blackColor] CGColor]];
	//[colorBox4 release];
	
	colorBox5 = [[UILabel alloc] initWithFrame:CGRectMake(140 , 360 , 30, 30)];
	colorBox5.backgroundColor = (UIColor *)[NSKeyedUnarchiver unarchiveObjectWithData:[arr objectAtIndex:4]];	//[UIColor
	[scroll addSubview:colorBox5];
	
	UIButton *btn5 = [UIButton buttonWithType:UIButtonTypeCustom];
	btn5.frame = CGRectMake(140 , 360 , 30, 30);
	[btn5 setShowsTouchWhenHighlighted:YES];
	btn5.tag = 5;
    self.button5 = btn5;
	//btn5.highlighted = YES;
	[btn5 addTarget:self action:@selector(selectColor:) forControlEvents:UIControlEventTouchUpInside];
	[scroll addSubview:btn5];
	
	
	[[colorBox5 layer] setCornerRadius: 5 ];
	[[colorBox5 layer] setBorderWidth:1];
	[[colorBox5 layer] setBorderColor:[[ UIColor blackColor] CGColor]];
	//[colorBox5 release];
	
}

- (void) changeColor{
    NSDictionary *dict = [NSDictionary dictionaryWithDictionary:[[BigGameSettings appSettings] getSeasonColorData]];
	NSArray *arr = [dict objectForKey:@"colors"];
    colorBox1.backgroundColor = (UIColor *)[NSKeyedUnarchiver unarchiveObjectWithData:[arr objectAtIndex:0]];
    colorBox2.backgroundColor = (UIColor *)[NSKeyedUnarchiver unarchiveObjectWithData:[arr objectAtIndex:1]];
    colorBox3.backgroundColor = (UIColor *)[NSKeyedUnarchiver unarchiveObjectWithData:[arr objectAtIndex:2]];
    colorBox4.backgroundColor = (UIColor *)[NSKeyedUnarchiver unarchiveObjectWithData:[arr objectAtIndex:3]];
    colorBox5.backgroundColor = (UIColor *)[NSKeyedUnarchiver unarchiveObjectWithData:[arr objectAtIndex:4]];
}

-(void) selectColor:(id)sender {
	
	UIButton *btn = (UIButton *)sender;
	/**
	if (lab) {
		self.lab = nil;
	}
	lab = [[UILabel alloc] init];
	lab.frame = btn.frame;
	lab.backgroundColor = [UIColor blueColor];
	[[lab layer] setCornerRadius: 5 ];
	[[lab layer] setBorderWidth:1];
	[[lab layer] setBorderColor:[[ UIColor blackColor] CGColor]];
	[self.view addSubview:lab];*/
	//btn.highlighted = YES;
	[btn setTitleColor:[UIColor whiteColor] forState:UIControlStateHighlighted];
	NSString *key = [NSString stringWithFormat:@"Color%d",btn.tag];
	NSLog(@"KEY : %@",key);
	selectedColorTag = btn.tag;
	
	
#ifdef IPHONE_COLOR_PICKER_SAVE_DEFAULT
    // Retrieve saved user default for the color swatch - Must be archived before stored as a preference
    // Retrieve data object
    NSData *colorData = [[NSUserDefaults standardUserDefaults] objectForKey:key];
    UIColor *color;
    if (colorData!=nil) {
        // If the data object is valid, unarchive the color we've stored in it.
        color = (UIColor *)[NSKeyedUnarchiver unarchiveObjectWithData:colorData];
    } else {
        // If the data's not valid, the user default wasn't set, or there was an error retrieving the default value.
        
        // This is not the Apple-sanctioned way to set up defaults, but it _is_ permissible
        // The correct way to do it would be to register 'fall-back' defaults when the app launches for the first time,
        // usually via the app delegate.
        //
        // I've done it this way to consolidate initial defaults with error-checking code.
        
        // Create a new color 
		if (btn.tag == 1) {
			color = [UIColor colorWithRed:0.210479 green:0.755696 blue:0.949 alpha:1.0];
		}
		if (btn.tag == 2) {
			color = [UIColor colorWithRed:0.856667 green:0.3 blue:0.378456 alpha:1.0];
		}
		if (btn.tag == 3) {
			color = [UIColor colorWithRed:0.346214 green:0.83 blue:0.248677 alpha:1.0];
		}
		if (btn.tag == 4) {
			color = [UIColor colorWithRed:0.882738 green:0.886 blue:0.399907 alpha:1];
		}
		if (btn.tag == 5) {
			color = [UIColor colorWithRed:0.806667 green:0.710965 blue:0.621479 alpha:1];
		}
        // Archive the color into an NSData object
        colorData = [NSKeyedArchiver archivedDataWithRootObject:color];
        // Store the NSData into the user defaults
        [[NSUserDefaults standardUserDefaults] setObject:colorData forKey:key];
    }
	// Set the label color

	if (btn.tag == 1) {
		colorBox1.backgroundColor = color;
	}
	if (btn.tag == 2) {
		colorBox2.backgroundColor = color;
	}
	if (btn.tag == 3) {
		colorBox3.backgroundColor = color;
	}
	if (btn.tag == 4) {
		colorBox4.backgroundColor = color;
	}
	if (btn.tag == 5) {
		colorBox5.backgroundColor = color;
	}
#else
    // Set some arbitrary default color
    // Attention: This is not they way you should do it. Because everytime the ViewDidUnload
    // the color information will be lost. It's just the easy way for demonstration purposes
	if (btn.tag == 1) {
		colorBox1.backgroundColor = [UIColor colorWithRed:0.210479 green:0.755696 blue:0.949 alpha:1.0];
	}
	if (btn.tag == 2) {
		colorBox2.backgroundColor = [UIColor colorWithRed:0.856667 green:0.3 blue:0.378456 alpha:1.0];
	}
	if (btn.tag == 3) {
		colorBox3.backgroundColor = [UIColor colorWithRed:0.346214 green:0.83 blue:0.248677 alpha:1.0];
	}
	if (btn.tag == 4) {
		colorBox4.backgroundColor = [UIColor colorWithRed:0.882738 green:0.886 blue:0.399907 alpha:1];
	}
	if (btn.tag == 5) {
		colorBox5.backgroundColor = [UIColor colorWithRed:0.806667 green:0.710965 blue:0.621479 alpha:1];
	}
    //colorBox1.backgroundColor = [UIColor redColor];
#endif
	ColorPickerViewController *colorPickerViewController = 
	[[ColorPickerViewController alloc] initWithNibName:@"ColorPickerViewController" bundle:nil];
	colorPickerViewController.delegate = self;
	colorPickerViewController.tag = btn.tag;
	
#ifdef IPHONE_COLOR_PICKER_SAVE_DEFAULT
	if (btn.tag == 1) {
		colorPickerViewController.defaultsKey = @"Color1";
	}
	if (btn.tag == 2) {
		colorPickerViewController.defaultsKey = @"Color2";
	}
	if (btn.tag == 3) {
		colorPickerViewController.defaultsKey = @"Color3";
	}
	if (btn.tag == 4) {
		colorPickerViewController.defaultsKey = @"Color4";
	}
	if (btn.tag == 5) {
		colorPickerViewController.defaultsKey = @"Color5";
	}
#else
    // We re-use the current value set to the background of this demonstration view
	if (btn.tag == 1) {
		colorPickerViewController.defaultsColor = colorBox1.backgroundColor;
	}
	if (btn.tag == 2) {
		colorPickerViewController.defaultsColor = colorBox2.backgroundColor;
	}
	if (btn.tag == 3) {
		colorPickerViewController.defaultsColor = colorBox3.backgroundColor;
	}
	if (btn.tag == 4) {
		colorPickerViewController.defaultsColor = colorBox4.backgroundColor;
	}
	if (btn.tag == 5) {
		colorPickerViewController.defaultsColor = colorBox5.backgroundColor;
	}
    //colorPickerViewController.defaultsColor = colorBox1.backgroundColor;
#endif
    [self presentModalViewController:colorPickerViewController animated:YES];
    [colorPickerViewController release];
}



- (void) checkBoxClicked:(id)sender{
	UIButton *btn = sender;
	//if (checkBoxToggle == 0) {
		if(btn.currentBackgroundImage==[UIImage imageNamed:@"unchecked.png"]){
			[btn setBackgroundImage:[UIImage imageNamed:@"checked.png"] forState:UIControlStateNormal];	
			[tabView reloadData];
			checkBoxTag = btn.tag ;
		}
		else 	{
			[btn setBackgroundImage:[UIImage imageNamed:@"unchecked.png"] forState:UIControlStateNormal];	
			[tabView reloadData];
		}

}


#pragma mark -
#pragma mark ColorPickerViewControllerDelegate

- (void)colorPickerViewController:(ColorPickerViewController *)colorPicker didSelectColor:(UIColor *)color forLabel:(int)label{
	//[lab removeFromSuperview];
	//[self	 createGUI];
	[self changeColor];

    NSLog(@"Color: %@",color);
    
#ifdef IPHONE_COLOR_PICKER_SAVE_DEFAULT
    NSData *colorData = [NSKeyedArchiver archivedDataWithRootObject:color];
    [[NSUserDefaults standardUserDefaults] setObject:colorData forKey:colorPicker.defaultsKey];
    
	if ([colorPicker.defaultsKey isEqualToString:@"Color1"]) {
        colorBox1.backgroundColor = color;
	}
	if ([colorPicker.defaultsKey isEqualToString:@"Color2"]) {
        colorBox2.backgroundColor = color;
	}
	if ([colorPicker.defaultsKey isEqualToString:@"Color3"]) {
        colorBox3.backgroundColor = color;
	}
	if ([colorPicker.defaultsKey isEqualToString:@"Color4"]) {
        colorBox4.backgroundColor = color;
	}
	if ([colorPicker.defaultsKey isEqualToString:@"Color5"]) {
        colorBox5.backgroundColor = color;
	}
#else
    // No storage & check, just assign back the color
	switch (label) {
		case 1:
			colorBox1.backgroundColor = color;
			break;
		case 2:
			colorBox2.backgroundColor = color;
			break;
		case 3:
			colorBox3.backgroundColor = color;
			break;
		case 4:
			colorBox4.backgroundColor = color;
			break;
		case 5:
			colorBox5.backgroundColor = color;
			break;
		default:
			break;
	}
#endif
	
	
    [colorPicker dismissModalViewControllerAnimated:YES];
}


#pragma mark -
#pragma mark tableview DataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
	return [tabContent count];
	//return 1;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
	
	static NSString *CellIdentifier = @"Cell";
	//CustomUITableViewCell *cell = [[[CustomUITableViewCell alloc] initWithStyle:UITableViewStyleGrouped reuseIdentifier:CellIdentifier] autorelease];
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	
	if (cell == nil) {
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
		//cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
		cell.selectionStyle = UITableViewCellSelectionStyleBlue;
		
	}
	if (indexPath.section == 0) {
		// Configure the cell...
		UIView *cellView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 300, 50)];
		
		//UIImageView *checkImage;
		
		if (indexPath.row == checkBoxTag) {
			//checkImage  = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"checked.png"]];
			[cell.imageView setImage:[UIImage imageNamed:@"checked.png"]];
		}
		else {
			//checkImage  = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"unchecked.png"]];
			[cell.imageView setImage:[UIImage imageNamed:@"unchecked.png"]];

		}
		//checkImage.frame = CGRectMake(20, 20, 16, 11);
		//[cellView addSubview:checkImage];
		//[checkImage release];
		
		UILabel *lbl=[[UILabel alloc]initWithFrame:CGRectMake(50,10,220,30)];
		lbl.text=[tabContent objectAtIndex:indexPath.row];
		[cellView addSubview:lbl];
		[lbl release];
		cell.accessoryView = cellView;
		//[cell.contentView addSubview:cellView];
		[cellView release];
	}
	/*if (indexPath.section == 1) {
		UIButton *colorBox = [UIButton	 buttonWithType:UIButtonTypeCustom];
		colorBox.frame = CGRectMake(10, 140, 30, 30);
		[colorBox addTarget:self action:@selector(selectColor:) forControlEvents:UIControlEventTouchUpInside];
		[colorBox setBackgroundImage:[UIImage imageNamed:[colorArr objectAtIndex:(indexPath.row)]] forState:UIControlStateNormal];	
		colorBox.tag = (indexPath.row + 1);
		cell.backgroundColor = [UIColor groupTableViewBackgroundColor];
		cell.accessoryView = colorBox;
	}*/
	return cell;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
	
	return 1;
}              // Default is 1 if not implemented


#pragma mark -
#pragma mark tableview DataSource


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
	[[tableView cellForRowAtIndexPath: indexPath] setSelected:NO animated:YES];
	selectedRowIndex = indexPath.row;
	//CustomUITableViewCell *cell = (CustomUITableViewCell *)[tableView cellForRowAtIndexPath:indexPath];
	UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
	//if([cell getImage] == [UIImage imageNamed:@"unchecked.png"]){
	if (cell.imageView.image == [UIImage imageNamed:@"unchecked.png"]) {
		//[btn setBackgroundImage:[UIImage imageNamed:@"checked.png"] forState:UIControlStateNormal];
		//[cell setImage:[UIImage imageNamed:@"checked.png"]];
		[cell.imageView setImage:[UIImage imageNamed:@"checked.png"]];
		[tabView reloadData];
		checkBoxTag = indexPath.row;
	}
	else 	{
		//[btn setBackgroundImage:[UIImage imageNamed:@"unchecked.png"] forState:UIControlStateNormal];
		//[cell setImage:[UIImage imageNamed:@"unchecked.png"]];
		[cell.imageView setImage:[UIImage imageNamed:@"unchecked.png"]];
		[tabView reloadData];
		//checkBoxTag = indexPath.row;
		//[tabView reloadData];
	}
	
}

#pragma mark -
#pragma mark memory management

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
	self.tabView = nil;
	self.scroll = nil;
	self.tabView.delegate = nil;
	self.tabView.dataSource = nil;
	self.colorBox1 = nil;
	self.colorBox2 = nil;
	self.colorBox3 = nil;
	self.colorBox4 = nil;
	self.colorBox5 = nil;
    self.button1 = nil;
    self.button2 = nil;
    self.button3 = nil;
    self.button4 = nil;
    self.button5 = nil;
	self.tabContent = nil;
	self.colorArr = nil;
	self.dataDict = nil;
	self.colorArray = nil;
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	self.tabView = nil;
	self.scroll = nil;
	self.tabView.delegate = nil;
	self.tabView.dataSource = nil;
	self.lab = nil;
	self.colorBox1 = nil;
	self.colorBox2 = nil;
	self.colorBox3 = nil;
	self.colorBox4 = nil;
	self.colorBox5 = nil;
    self.button1 = nil;
    self.button2 = nil;
    self.button3 = nil;
    self.button4 = nil;
    self.button5 = nil;
	[tabContent release];//,self.tabContent = nil;
	[colorArr release];//,self.colorArr = nil;
	[dataDict release];//,self.dataDict = nil;
	[colorArray release];//, self.colorArray = nil;
    [super dealloc];
}


@end
