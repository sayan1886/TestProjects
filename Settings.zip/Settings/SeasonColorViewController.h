//
//  SeasonColorViewController.h
//  BigGameRegs
//
//  Created by Sayan on 07/03/11.
//  Copyright 2011 Sportsmanregs LLC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ColorPickerViewController.h"


@interface SeasonColorViewController : UIViewController <ColorPickerViewControllerDelegate> {
	IBOutlet UITableView *tabView;
	IBOutlet UIScrollView *scroll;
	NSArray *tabContent;
	NSArray *colorArr;
	
	UILabel *colorBox1;
	UILabel *colorBox2;
	UILabel *colorBox3;
	UILabel *colorBox4;
	UILabel *colorBox5;
    
    UIButton *button1;
    UIButton *button2;
    UIButton *button3;
    UIButton *button4;
    UIButton *button5;
    
	UILabel *lab;
	//UIView *colorSwatch;
	NSMutableDictionary *dataDict;
	NSMutableArray *colorArray;
	
	int selectedRowIndex;
}

@property (nonatomic,retain) 	IBOutlet UITableView *tabView;
@property (nonatomic,retain) 	IBOutlet UIScrollView *scroll;
@property (nonatomic,retain) 	NSArray *tabContent;
@property (nonatomic,retain) 	NSArray *colorArr;
@property (nonatomic,retain) UILabel *colorBox1;
@property (nonatomic,retain) UILabel *colorBox2;
@property (nonatomic,retain) UILabel *colorBox3;
@property (nonatomic,retain) UILabel *colorBox4;
@property (nonatomic,retain) UILabel *colorBox5;
@property (nonatomic,retain) UIButton *button1;
@property (nonatomic,retain) UIButton *button2;
@property (nonatomic,retain) UIButton *button3;
@property (nonatomic,retain) UIButton *button4;
@property (nonatomic,retain) UIButton *button5;
@property (nonatomic,retain) UILabel *lab;
@property (nonatomic,retain) NSMutableDictionary *dataDict;
@property (nonatomic,retain) NSMutableArray *colorArray;
//@property (readwrite,nonatomic,retain) UIView *colorSwatch;

- (void) checkBoxClicked:(id)sender;
- (void) createGUI;

@end
