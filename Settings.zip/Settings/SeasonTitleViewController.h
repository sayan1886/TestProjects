//
//  SeasonTitleViewController.h
//  BigGameRegs
//
//  Created by Sayan on 10/03/11.
//  Copyright 2011 Sportsmanregs LLC. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface SeasonTitleViewController : UIViewController <UITableViewDelegate,UITableViewDataSource>{
	IBOutlet UITableView *tabView;
	IBOutlet UIScrollView *scroll;
	IBOutlet UILabel *selectedLab;
	NSMutableArray *tabContent;
	
	NSMutableDictionary *tabContentDict;
	NSMutableDictionary *checkedContentDict;
	NSMutableArray *checkedItems;
	
	NSMutableArray *content;
	NSMutableArray *indexPathArr;
	NSUserDefaults *userDefaults;
}

@property (nonatomic,retain) IBOutlet UITableView *tabView;
@property (nonatomic,retain) IBOutlet UIScrollView *scroll;
//@property (nonatomic,retain) 	UILabel *selectedLab;
@property (nonatomic,retain) 	NSMutableArray *tabContent;
@property (nonatomic,retain) NSMutableArray *checkedItems;
@property (nonatomic,retain,readwrite) 	NSMutableArray *content;
@property (nonatomic,retain) 	IBOutlet UILabel *selectedLab;

- (void) textForLabel;

@end

