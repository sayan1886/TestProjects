//
//  SeasonTitleViewController.m
//  BigGameRegs
//
//  Created by Sayan on 10/03/11.
//  Copyright 2011 Sportsmanregs LLC. All rights reserved.
//

#import "SeasonTitleViewController.h"
#import "constant.h"
#import "BigGameSettings.h"
//#import "UserSettings.h"


@implementation SeasonTitleViewController

@synthesize tabView,selectedLab,tabContent,checkedItems,content,scroll;	


#pragma mark -
#pragma mark view lifeCycle

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	self.title = @"Hunt Title";
    self.view.backgroundColor = [UIColor groupTableViewBackgroundColor];
	scroll.backgroundColor = [UIColor groupTableViewBackgroundColor];
	self.navigationController.navigationItem.hidesBackButton = YES;
    
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, scroll.frame.size.height, 1024, 200)];
    view.backgroundColor = [UIColor groupTableViewBackgroundColor];
    view.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleHeight;
    view.autoresizesSubviews = YES;
	[self.view addSubview:view];
    [view release];
	UIBarButtonItem *doneBarItem = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleDone target:self action:@selector(doneClicked:)];
	self.navigationItem.leftBarButtonItem = doneBarItem;
	[doneBarItem release];
	
	NSString *text = [NSString stringWithString:@""];
	
    NSDictionary *seasonTitleDict = [[BigGameSettings appSettings] getSeasonTitleDetails];
    
	//userDefaults = [NSUserDefaults standardUserDefaults];
	//if ([userDefaults objectForKey:@"content"]) {
    if ([seasonTitleDict objectForKey:@"tablecontent"]) {
		NSMutableArray *contentArr = [[NSMutableArray alloc] initWithArray:[seasonTitleDict objectForKey:@"tablecontent"]];
        self.content = nil;
        self.content = contentArr;
        [contentArr release];
		self.tabContent = [content objectAtIndex:0];
		self.checkedItems = [content objectAtIndex:1];
		for (int i = 0; i < [tabContent count]; i++) {
			if ([[checkedItems objectAtIndex:i] isEqualToString:@"YES"]) {
				text = [text stringByAppendingFormat:@"\"%@\" ",[tabContent objectAtIndex:i]];
			}
		}
	}
	else {
		NSArray *arr = [NSArray arrayWithObjects:@"Weapon",@"Classification",@"Animal Characteristics",@"Season Name",@"Animals",@"Subspecies",nil];
		self.tabContent = nil;
		self.tabContent = [[NSMutableArray alloc] initWithArray:arr];
		checkedItems = [[NSMutableArray alloc] init];
		for(int i=0;i<[tabContent count];i++){
			if(i <= 1)
				[checkedItems addObject:@"YES"];
			else
				[checkedItems addObject:@"NO"];
		}
		
		content = [[NSMutableArray alloc] init];
		[content addObject:tabContent];
		[content addObject:checkedItems];
		for (int i = 0; i < [tabContent count]; i++) {
			if ([[checkedItems objectAtIndex:i] isEqualToString:@"YES"]) {
				text = [text stringByAppendingFormat:@"\"%@\" ",[tabContent objectAtIndex:i]];
			}
		}
		//[content retain];
	}
	
	NSLog(@"CONTENT : %@",content);
	indexPathArr = [[NSMutableArray	alloc] init];
	tabView.delegate = self;
	tabView.dataSource = self;
	tabView.scrollEnabled = NO;
	tabView.allowsSelectionDuringEditing = YES;
	tabView.frame = CGRectMake(0, 0, 320, 300);
	[tabView setEditing:YES animated:YES];
	
	
	
	/*UILabel *lab = [[UILabel alloc]initWithFrame:CGRectMake(10, 320, 300, 80)];
	lab.font = [UIFont systemFontOfSize:12];
	lab.numberOfLines = 0;
	lab.backgroundColor = [UIColor clearColor];
	lab.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
	lab.textAlignment = UITextAlignmentCenter;
	lab.text = text;//[UserSettings getSeasonTitle];
	[self.view addSubview:lab];
	self.selectedLab = lab;
	[lab release];*/
	
	selectedLab.font = [UIFont systemFontOfSize:12];
	selectedLab.numberOfLines = 0;
	selectedLab.backgroundColor = [UIColor clearColor];
	selectedLab.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
	selectedLab.textAlignment = UITextAlignmentCenter;
	selectedLab.text = text;
	
}

- (void) viewWillAppear:(BOOL)animated{
	self.navigationController.navigationItem.hidesBackButton = YES;
}

- (void) viewWillDisappear:(BOOL)animated{
	
	//[userDefaults setObject:checkedItems forKey:@"checked"];
	NSMutableArray *arr = [[NSMutableArray alloc] init];
	NSMutableArray *textArr = [[NSMutableArray alloc] init];
    NSMutableDictionary *seasonTitleDict = [NSMutableDictionary new];
	for (int i = 0; i < [tabContent count]; i++) {
		UITableViewCell *cell  = [tabView cellForRowAtIndexPath:[indexPathArr objectAtIndex:i]];
		
		if (cell.imageView.image == [UIImage imageNamed:@"checked.png"]) {
			[arr addObject:@"YES"];
		}
		else {
			[arr addObject:@"NO"];
		}
		[textArr addObject:cell.textLabel.text];

	}
	[content replaceObjectAtIndex:0 withObject:textArr];
	[content replaceObjectAtIndex:1 withObject:arr];
	//NSLog(@"CONTENt : %@",content);
    [seasonTitleDict setObject:content forKey:@"tablecontent"];
	//[userDefaults setObject:(NSArray *)content forKey:@"content"];
	[textArr release];
	[arr release];
	//NSLog(@"LABEL : %@",selectedLab.text);
	//NSString *str = [selectedLab.text stringByReplacingOccurrencesOfString:@" " withString:@""];
	NSArray *dummyArr = [selectedLab.text componentsSeparatedByString:@"\""];
	//NSLog(@"ARRAY : %@",dummyArr);

	int i = 1;
	NSString *text = @"";
	while (i < ([dummyArr count] - 1)) {
		if (i == ([dummyArr count] - 2)) {
			text = [text stringByAppendingString:[dummyArr objectAtIndex:i]];
		}
		else {
			text = [text stringByAppendingFormat:@"%@,",[dummyArr objectAtIndex:i]];
		}
		i += 2;
	}
	NSLog(@"TEST STR : %@",text);
	/*NSString *text = [selectedLab.text stringByReplacingOccurrencesOfString:@"\"" withString:@""];
	text = [text stringByReplacingOccurrencesOfString:@" " withString:@","];
	NSLog(@"TEXT : %@",text);*/
	[seasonTitleDict setObject:text forKey:@"title"];
	//[userDefaults setObject:text forKey:@"SeasonTitle"];
    [[BigGameSettings appSettings] setSeasonTitleDetails:(NSDictionary *)seasonTitleDict];
    [seasonTitleDict release];
}


// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
	if (interfaceOrientation == UIInterfaceOrientationLandscapeLeft || 
		interfaceOrientation == UIInterfaceOrientationLandscapeRight) {
        if(IS_iPAD()){
            self.view.frame = CGRectMake(0, 0, 1024, 768);
        }
        else{
            scroll.frame = CGRectMake(0, 0, 480, 320);
            scroll.contentSize = CGSizeMake(480, 480);
            tabView.frame = CGRectMake(0, 0, 480, 300);
            selectedLab.frame = CGRectMake(10, 320, 460, 80);
            //selectedLab.backgroundColor = [UIColor redColor];
        }
		
	}
	else {
        if(IS_iPAD()){
            self.view.frame = CGRectMake(0, 0, 768, 1024);
        }
        else{
            scroll.frame = CGRectMake(0, 0, 320, 480);
            scroll.contentSize = CGSizeMake(320, 480);
            tabView.frame = CGRectMake(0, 0, 320, 300);
            selectedLab.frame = CGRectMake(10, 320, 300, 80);
        }
				
	}
    return YES;
	
}

- (void) didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation{
	if (fromInterfaceOrientation == UIInterfaceOrientationPortraitUpsideDown || fromInterfaceOrientation == UIInterfaceOrientationPortrait) {
		if(IS_iPAD()){
            self.view.frame = CGRectMake(0, 0, 1024, 768);
        }
        else{
            scroll.frame = CGRectMake(0, 0, 480, 320);
            scroll.contentSize = CGSizeMake(480, 480);
            tabView.frame = CGRectMake(0, 0, 480, 300);
            selectedLab.frame = CGRectMake(10, 320, 460, 80);
            //selectedLab.backgroundColor = [UIColor redColor];
        }
	}
	else {
		if(IS_iPAD()){
            self.view.frame = CGRectMake(0, 0, 768, 1024);
        }
        else{
            scroll.frame = CGRectMake(0, 0, 320, 480);
            scroll.contentSize = CGSizeMake(320, 480);
            tabView.frame = CGRectMake(0, 0, 320, 300);
            selectedLab.frame = CGRectMake(10, 320, 300, 80);
        }
	}
}


#pragma mark -
#pragma mark class methods


- (void) doneClicked:(id)sender{
	[self.navigationController popViewControllerAnimated:YES];
}

- (void) textForLabel{
	NSString *text = [NSString stringWithString:@""];
	for (int i = 0; i < [tabContent count]; i++) {
		UITableViewCell *tempCell = [tabView cellForRowAtIndexPath:[indexPathArr objectAtIndex:i]];
		if(tempCell.imageView.image == [UIImage imageNamed:@"checked.png"])
			text = [text stringByAppendingFormat:@"\"%@\" ",tempCell.textLabel.text];
	}
	selectedLab.text = text;
}

#pragma mark -
#pragma mark Override
- (void)setEditing:(BOOL)editing animated:(BOOL)animated {
	[super setEditing:editing animated:animated];
	[tabView setEditing:editing animated:animated];
	//tabView.
}

#pragma mark -
#pragma mark UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
	return 45.0;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

	[tableView deselectRowAtIndexPath:indexPath animated:YES];
	int count = 0;
	UITableViewCell *cell=[tableView cellForRowAtIndexPath:indexPath];
	for (int i = 0; i < [tabContent count]; i++) {
		UITableViewCell *tempCell = [tableView cellForRowAtIndexPath:[indexPathArr objectAtIndex:i]];
		if(tempCell.imageView.image == [UIImage imageNamed:@"checked.png"])
			++count;
	}
	if (count == 1 && cell.imageView.image ==  [UIImage imageNamed:@"checked.png"])  {
		
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"" message:@"You Must Select At Least One Tiltle" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
		[alert show];
		[alert release];
	}
	else {
		
		if(cell.imageView.image == [UIImage imageNamed:@"checked.png"])
		{
			//[checkedItems replaceObjectAtIndex:indexPath.row withObject:@"YES"];
			cell.imageView.image= [UIImage imageNamed:@"unchecked.png"];
		}
		else {
			//[checkedItems replaceObjectAtIndex:indexPath.row withObject:@"NO"];
			cell.imageView.image=[UIImage imageNamed:@"checked.png"];
		}
	}

	/*NSString *text = [NSString stringWithString:@""];
	for (int i = 0; i < [tabContent count]; i++) {
		UITableViewCell *tempCell = [tableView cellForRowAtIndexPath:[indexPathArr objectAtIndex:i]];
		if(tempCell.imageView.image == [UIImage imageNamed:@"checked.png"])
			text = [text stringByAppendingFormat:@"\"%@\" ",[tabContent objectAtIndex:i]];
	}
	selectedLab.text = text;*/
	[self textForLabel];
	
}


- (void)tableView:(UITableView*)tableView didEndEditingRowAtIndexPath:(NSIndexPath *)indexPath{

	NSString *text = [NSString stringWithString:@"\""];
	for (int i = 0; i < [tabContent count]; i++) {
		UITableViewCell *tempCell = [tableView cellForRowAtIndexPath:[indexPathArr objectAtIndex:i]];
		if(tempCell.imageView.image == [UIImage imageNamed:@"checked.png"])
			text = [text stringByAppendingFormat:@"%@ \" ",tempCell.textLabel.text];
	}
	selectedLab.text = text;
}


- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath{
	return UITableViewCellEditingStyleNone;
}

// Allows customization of the target row for a particular row as it is being moved/reordered
- (NSIndexPath *)tableView:(UITableView *)tableView 
targetIndexPathForMoveFromRowAtIndexPath:(NSIndexPath *)sourceIndexPath 
	   toProposedIndexPath:(NSIndexPath *)proposedDestinationIndexPath{
	
	NSUInteger sectionCount = [tabContent count];
	
	if (sourceIndexPath.section != proposedDestinationIndexPath.section) {
		
		NSUInteger rowInSourceSection = (sourceIndexPath.section > proposedDestinationIndexPath.section) ? 0 : sectionCount - 1;
		return [NSIndexPath indexPathForRow:rowInSourceSection inSection:sourceIndexPath.section];
		
	} else if (proposedDestinationIndexPath.row >= sectionCount) {
		
		return [NSIndexPath indexPathForRow:sectionCount - 1 inSection:sourceIndexPath.section];
		
	}
	
	// Allow the proposed destination.
	
	return proposedDestinationIndexPath;
}


#pragma mark -
#pragma mark UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
	
	return [tabContent count];
}

// Allows the reorder accessory view to optionally be shown for a particular row. By default, the reorder control will be shown only if the datasource implements -tableView:moveRowAtIndexPath:toIndexPath:
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath{
	return YES;
}

// Data manipulation - reorder / moving support

- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)sourceIndexPath 
	  toIndexPath:(NSIndexPath *)destinationIndexPath{
	
	
	/*NSString *text = [NSString stringWithString:@"\""];
	for (int i = 0; i < [tabContent count]; i++) {
		UITableViewCell *tempCell = [tableView cellForRowAtIndexPath:[indexPathArr objectAtIndex:i]];
		if(tempCell.imageView.image == [UIImage imageNamed:@"checked.png"])
			text = [text stringByAppendingFormat:@"%@ \" ",tempCell.textLabel.text];
	}
	selectedLab.text = text;*/
	[self performSelector:@selector(textForLabel) withObject:nil afterDelay:0.3];
}

// Individual rows can opt out of having the -editing property set for them. If not implemented, all rows are assumed to be editable.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath{
	return YES;
}

// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
	
	static NSString *CellIdentifier = @"Cell";
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	
	if (cell == nil) {
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
		cell.selectionStyle = UITableViewCellSelectionStyleBlue;
		
	}
	
	
	if([[checkedItems objectAtIndex:indexPath.row] isEqualToString:@"YES"])
	{
		cell.imageView.image=[UIImage imageNamed:@"checked.png"];
	}
	else {
		cell.imageView.image=[UIImage imageNamed:@"unchecked.png"];
	}

	cell.textLabel.text = [tabContent objectAtIndex:indexPath.row];
	cell.textLabel.font = [UIFont systemFontOfSize:16];
	[indexPathArr addObject:indexPath];
	return cell;
}


- (BOOL)tableView:(UITableView *)tableView shouldIndentWhileEditingRowAtIndexPath:(NSIndexPath *)indexPath 
{
    return NO;
}


#pragma mark -
#pragma mark memory management

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    self.tabView = nil;
    self.tabView.delegate = nil;
    self.tabView.dataSource = nil;
	self.selectedLab = nil;
	self.tabContent = nil;
    
	self.scroll = nil;
	
	RELEASE_SAFELY(tabContentDict);
	RELEASE_SAFELY(checkedContentDict);
	self.checkedItems = nil;
    self.content = nil;
	
	RELEASE_SAFELY(indexPathArr);
	RELEASE_SAFELY(userDefaults);    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	self.tabView = nil;
    self.tabView.delegate = nil;
    self.tabView.dataSource = nil;
	self.selectedLab = nil;
	self.tabContent = nil;
    
	self.scroll = nil;
	
	RELEASE_SAFELY(tabContentDict);
	RELEASE_SAFELY(checkedContentDict);
	self.checkedItems = nil;
    self.content = nil;
	
	RELEASE_SAFELY(indexPathArr);
	RELEASE_SAFELY(userDefaults);
    [super dealloc];
}


@end
