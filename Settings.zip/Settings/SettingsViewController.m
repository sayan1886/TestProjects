//
//  SettingsViewController.m
//  BigGameRegs
//
//  Created by Sayan on 01/03/11.
//  Copyright 2011 Sportsmanregs LLC. All rights reserved.
//

#import "SettingsViewController.h"
#import "WebViewController.h"
#import "SeasonColorViewController.h"
#import "SeasonTitleViewController.h"


@implementation SettingsViewController

@synthesize tabContent,sectionContent1,sectionContent2,sectionContent3;

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	self.view.backgroundColor =  [UIColor groupTableViewBackgroundColor];
	self.title = @"Settings";
    
    NSString*	version = @"Version ";
   version = [version stringByAppendingString: [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleVersion"]];
	sectionContent1 = [[NSArray alloc] initWithObjects:@"Hunt Title",@"Hunt Colors",nil];
	//sectionContent2 = [[NSArray alloc] initWithObjects: @"Manage",nil];
	sectionContent3 = [[NSArray alloc] initWithObjects:@"Help",@"Legal",@"About",/*@"Version 1.0.0"*/version,@"Sportsmanregs.com",@"Email Us",nil];
	tabContent = [[NSArray alloc] initWithObjects:sectionContent1,sectionContent3,nil];
	
}

- (void) viewWillAppear:(BOOL)animated{

}
/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/


#pragma mark -
#pragma mark tableview DataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
	int row = 0;
	if (section == 0) {
		row = [sectionContent1 count];
	}
	if (section == 1) {
		row = [sectionContent3 count];
	}
	/*if (section == 2) {
		row = [sectionContent3 count];
	}*/
	return row;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
	
	static NSString *CellIdentifier = @"Cell";
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	
	if (cell == nil) {
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
		cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
		//cell.selectionStyle = UITableViewCellSelectionStyleNone;
	}
	if (indexPath.section == 0) {
		//UILabel *lbl=[[UILabel alloc]initWithFrame:CGRectMake(10,10,220,20)];
//		lbl.text=[sectionContent1 objectAtIndex:indexPath.row];
//		[cell.contentView addSubview:lbl];
//		[lbl release];
		cell.textLabel.frame = CGRectMake(10,10,220,20);
		cell.textLabel.text = [sectionContent1 objectAtIndex:indexPath.row];
		cell.textLabel.font = [UIFont boldSystemFontOfSize:14];
	}
	/*if (indexPath.section == 1) {
		//UILabel *lbl=[[UILabel alloc]initWithFrame:CGRectMake(10,10,220,20)];
//		lbl.text=[sectionContent2 objectAtIndex:indexPath.row];
//		[cell.contentView addSubview:lbl];
//		[lbl release];
		cell.textLabel.frame = CGRectMake(10,10,220,20);
		cell.textLabel.text = [sectionContent2 objectAtIndex:indexPath.row];
		cell.textLabel.font = [UIFont boldSystemFontOfSize:14];
	}*/
	if(indexPath.section == 1){
		/*if(indexPath.row == 3){
			UIView *cellView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 300, 50)];
			cell.accessoryType = UITableViewCellAccessoryNone;
			UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(7, 15, 200, 20)];
			lbl.text = [sectionContent3 objectAtIndex:indexPath.row];
			lbl.font = [UIFont boldSystemFontOfSize:14];
			[cellView addSubview:lbl];
			[lbl release];
			lbl = [[UILabel alloc] initWithFrame:CGRectMake(255, 15, 40, 20)];
			lbl.text = @"1.01";
			lbl.font = [UIFont boldSystemFontOfSize:14];
			[cellView addSubview:lbl];
			[lbl release];
			cell.accessoryView = cellView;
		}else{*/
			// Configure the cell...
			//UILabel *lbl=[[UILabel alloc]initWithFrame:CGRectMake(10,10,220,20)];
//			lbl.text=[sectionContent3 objectAtIndex:indexPath.row];
//			[cell.contentView addSubview:lbl];
//			[lbl release];
			cell.textLabel.frame = CGRectMake(10,10,220,20);
			cell.textLabel.text = [sectionContent3 objectAtIndex:indexPath.row];
			cell.textLabel.font = [UIFont boldSystemFontOfSize:14];
		//}
	}
	return cell;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
	
	return [tabContent count];
}              // Default is 1 if not implemented

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
	
	return 50.0;
}

/*- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger) section{
	NSLog(@"Section : %d",section);
	
	UILabel *headerLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, 0, 300, 70)];
	NSString *str = [FlagDetailViewController areaNameForTable];
	headerLabel.text = str;
	headerLabel.textAlignment = UITextAlignmentCenter;
	headerLabel.textColor = [UIColor blueColor];
	headerLabel.backgroundColor = [UIColor clearColor];
	headerLabel.font = [UIFont boldSystemFontOfSize:20];
	
	return [headerLabel autorelease];
	
}*/
// fixed font style. use custom view (UILabel) if you want something different

#pragma mark -
#pragma mark tableview DataSource

- (void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath{
	
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
	[[tableView cellForRowAtIndexPath: indexPath] setSelected:NO animated:YES];
	WebViewController *web;
	SeasonColorViewController *seasonColor;
	SeasonTitleViewController *seasonTitle;
	if (indexPath.section == 0) {
		switch (indexPath.row) {
			case 0:
				seasonTitle = [[[SeasonTitleViewController alloc] initWithNibName:@"SeasonTitleViewController" bundle:nil]autorelease];
				seasonTitle.hidesBottomBarWhenPushed = YES;
				[self.navigationController pushViewController:seasonTitle animated:YES];
				break;
			case 1:
				seasonColor = [[[SeasonColorViewController alloc] initWithNibName:@"SeasonColorViewController" bundle:nil]autorelease];
				seasonColor.hidesBottomBarWhenPushed = YES;
				[self.navigationController pushViewController:seasonColor animated:YES];
				break;
			default:
				break;
		}		
	}

    
	if (indexPath.section == 1) {
		switch (indexPath.row) {
			case 0:
				web = [[WebViewController alloc] initWithNibName:@"WebViewController" bundle:nil pageName:@"htmlmain/HelpConcepts" isDownloaded:NO];
				web.hidesBottomBarWhenPushed = YES;
				[self.navigationController pushViewController:web animated:YES];
				[web release];
				break;
			case 1:
				web = [[WebViewController alloc] initWithNibName:@"WebViewController" bundle:nil pageName:@"htmlmain/Legal" isDownloaded:NO];
				web.hidesBottomBarWhenPushed = YES;
				[self.navigationController pushViewController:web animated:YES];
				[web release];
				break;
			case 2:
				web = [[WebViewController alloc] initWithNibName:@"WebViewController" bundle:nil pageName:@"htmlmain/About" isDownloaded:NO];
				web.hidesBottomBarWhenPushed = YES;
				[self.navigationController pushViewController:web animated:YES];
				[web release];
				break;
			case 3:
				web = [[WebViewController alloc] initWithNibName:@"WebViewController" bundle:nil pageName:@"htmlmain/Version" isDownloaded:NO];
				web.hidesBottomBarWhenPushed = YES;
				[self.navigationController pushViewController:web animated:YES];
				[web release];
				break;
			case 4:{
					web = [[WebViewController alloc] initWithNibName:@"WebViewController" bundle:nil pageName:nil isDownloaded:NO];
					web.hidesBottomBarWhenPushed = YES;
					[self.navigationController pushViewController:web animated:YES];
					[web release];
                
			/* This peace of code opens Safari   keep for reference
					NSURL *url = [NSURL URLWithString:@"http://www.sportsmanregs.com/"];
					if (![[UIApplication sharedApplication] openURL:url]){
						NSLog(@"%@%@",@"Failed to open url:",[url description]);
						UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" 
																	message:[NSString stringWithFormat:@"Failed to Open%@",[url description]] 
																   delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
						[alert show];
						[alert release];
					}
					else {
					[[UIApplication sharedApplication] openURL:url];
					}
			 */
				}
			
				break;
			case 5:
				[self callForSendingMail];
				break;
			default:
				break;
		}
	}
}

#pragma mark -

#pragma mark Send mail


-(void)callForSendingMail

{
	
	Class mailClass = (NSClassFromString(@"MFMailComposeViewController"));
	
	if (mailClass != nil)
		
	{
		
		// We must always check whether the current device is configured for sending emails
		
		if ([mailClass canSendMail])
			
		{
			
			[self displayComposerSheet];
			
		}
		
		else
			
		{
			
			[self launchMailAppOnDevice];
			
		}
		
	}
	
	else
		
	{
		
		[self launchMailAppOnDevice];
		
	}
	
}



#pragma mark Compose Mail


// Displays an email composition interface inside the application. Populates all the Mail fields. 

-(void)displayComposerSheet 

{
	
	MFMailComposeViewController *picker = [[MFMailComposeViewController alloc] init];
	
	picker.mailComposeDelegate = self;
	
	NSString *tostr  = @"support@sportsmanregs.com";	//=[[[[mycarSearchDetailsdata valueForKey:@"items"] objectAtIndex:0]valueForKey:@"data"]valueForKey:@"email"];
	
	[picker setToRecipients:[NSArray arrayWithObjects:tostr,nil]];
	
	NSString *emailBody = @"";
	
	[picker setMessageBody:emailBody isHTML:NO];
	
	[self presentModalViewController:picker animated:YES];
	
	[picker release];
	
}




// Dismisses the email composition interface when users tap Cancel or Send. Proceeds to update the message field with the result of the operation.

- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error 

{
	
	// Notifies users about errors associated with the interface
	
	switch (result)
	
	{
			
		case MFMailComposeResultCancelled:
			
			NSLog(@"%@", @"Result: canceled");
			
			break;
			
		case MFMailComposeResultSaved:
			
			NSLog(@"%@", @"Result: saved");
			
			break;
			
		case MFMailComposeResultSent:
			
			NSLog(@"%@", @"Result: sent");
			
			break;
			
		case MFMailComposeResultFailed:
			
			NSLog(@"%@", @"Result: failed");
			
			break;
			
		default:
			
			NSLog(@"%@", @"Result: not sent");
			
			break;
			
	}
	
	[self dismissModalViewControllerAnimated:YES];
	
}

-(void)launchMailAppOnDevice

{
	
	//NSString *strToRecipent=nil;
	
	NSString *strSub=@"";
	
	NSString *tostr=	@"support@sportsmanregs.com";	//[[[[mycarSearchDetailsdata valueForKey:@"items"] objectAtIndex:0]valueForKey:@"data"]valueForKey:@"email"];
	
	
	NSString *emailBody = @"";
	
	NSString *recipients = [NSString stringWithFormat:@"mailto:?to=%@&subject=%@",tostr,strSub];
	
	NSString *body = [NSString stringWithFormat:@"&body=%@",emailBody];
	
	NSString *email = [NSString stringWithFormat:@"%@%@", recipients, body];
	
	email = [email stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
	
	[[UIApplication sharedApplication] openURL:[NSURL URLWithString:email]];
	
}



#pragma mark -
#pragma mark memory management

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
	sectionContent1 = nil,[sectionContent1 release];
	sectionContent2 = nil,[sectionContent2 release];
	sectionContent3 = nil,[sectionContent3 release];
	tabContent = nil,[tabContent release];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	sectionContent1 = nil,[sectionContent1 release];
	sectionContent2 = nil,[sectionContent2 release];
	sectionContent3 = nil,[sectionContent3 release];
	tabContent = nil,[tabContent release];
    [super dealloc];
}


@end
