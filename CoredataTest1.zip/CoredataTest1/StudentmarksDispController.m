    //
//  StudentmarksDispController.m
//  CoredataTest
//
//  Created by Sayan Chatterjee on 04/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "StudentmarksDispController.h"
#import "Student.h"
#import "Marks.h"

@implementation StudentmarksDispController

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	studmarksdisp = [[StudentMarksDisp alloc] initWithFrame:CGRectMake(50, 50, 220, 160)];
	studmarksdisp.studinfoDelegate = self;
	[self.view addSubview:studmarksdisp];
}


-(void)didSelectDisp:(NSNumber *)studid{
	//NSLog(@"SAYAN");
	app = [[CoredataTestAppDelegate alloc] init];
	//NSManagedObjectContext *moc = [[NSManagedObjectContext alloc] init];
//	moc = [app managedObjectContext];
	//NSEntityDescription *entityDescription = [[NSEntityDescription alloc] init];
//	entityDescription =  [NSEntityDescription entityForName:@"Student" inManagedObjectContext:app.managedObjectContext];
//	NSFetchRequest *fetchData = [[NSFetchRequest alloc] init];
//	[fetchData setEntity:entityDescription];
//	//[moc release];
//	[entityDescription release];
//	
//	NSString *name = [[NSString alloc] init];
//	
//	NSPredicate *predicate = [[NSPredicate alloc] init];
//	predicate = [NSPredicate predicateWithFormat:@"sid == 1 ",name];
//	[fetchData setPredicate:predicate];
//	[predicate release];
//	NSLog(@"%@",name);
//	[name release];
	
	//NSString *name = [app.managedObjectContext]
	NSManagedObjectModel *model = [[app.managedObjectContext persistentStoreCoordinator]managedObjectModel];
	NSLog(@"%@",[model entities]);
	NSEntityDescription *entity = [NSEntityDescription entityForName:@"Student" inManagedObjectContext:app.managedObjectContext]; 
	//NSEntityDescription *entity = [[model entities] objectAtIndex:[studid intValue]];
	NSFetchRequest *request = [[[NSFetchRequest alloc] init] autorelease];
	[request setEntity:entity];
	NSString *query = [NSString stringWithString:@"sid == "];
	query = [query stringByAppendingFormat:@"%@",studid];
	
	[request setPredicate:[NSPredicate predicateWithFormat:query]];
	NSError *error = nil;
	NSMutableArray *studResults = [[app.managedObjectContext executeFetchRequest:request error:&error] mutableCopy];
	
	entity = [NSEntityDescription entityForName:@"Marks" inManagedObjectContext:app.managedObjectContext]; 
	//NSEntityDescription *entity = [[model entities] objectAtIndex:[studid intValue]];
	request = [[[NSFetchRequest alloc] init] autorelease];
	[request setEntity:entity];
	query = [NSString stringWithString:@"sid == "];
	query = [query stringByAppendingFormat:@"%@",studid];
	
	[request setPredicate:[NSPredicate predicateWithFormat:query]];
	
	NSMutableArray *marksResults = [[app.managedObjectContext executeFetchRequest:request error:&error] mutableCopy];
	
	Student *aStudent = nil;
	Marks *gotMarks = nil;
	NSArray *toReturn;
	if ([studResults count] > 0) {
		NSLog(@"results : %@", studResults);
		aStudent = [studResults objectAtIndex:0];
		//gotMarks = aStudent.gotMarks;
		if ([marksResults count] > 0) {
			gotMarks = [marksResults objectAtIndex:0];
		}
		NSLog(@"name : %@",aStudent.sname);
		NSLog(@"Marks : %@",gotMarks.totalmarks);
		toReturn = [[[NSArray alloc] initWithObjects:aStudent.sname, gotMarks.totalmarks,nil]autorelease];
		[studmarksdisp changeView:toReturn];
	}
	else {
		NSLog(@"Error : %@",[error localizedDescription]);
		UIAlertView *saveAlert = [[UIAlertView alloc] initWithTitle:@"Error!" message:@"The Data You Want To Access Is Not In Database" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		[saveAlert show];
		saveAlert.tag=100;
		[saveAlert release];
		[studmarksdisp createView:CGRectMake(50, 50, 220, 160)];
	}
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}





@end
