//
//  StudentMarksDisp.h
//  CoredataTest
//
//  Created by Sayan Chatterjee on 04/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>


@protocol StudentInfoDisplayDelegate <NSObject>

-(void)didSelectDisp:(NSNumber *)studid;

@end

@interface StudentMarksDisp : UIView <UITextFieldDelegate>{

	id trgt;
	@private
	UITextField *sid;
	UILabel *sname;
	UILabel *marks;
	UIButton *disp;
	id<StudentInfoDisplayDelegate> studinfoDelegate;
	NSNumber *studid;


}

-(void)createView:(CGRect)frm;
-(void)changeView:(NSArray *)details;
-(id)initWithFrame:(CGRect)frm;

@property (nonatomic,assign) id<StudentInfoDisplayDelegate> studinfoDelegate; 


@end
