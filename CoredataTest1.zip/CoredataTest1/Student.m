// 
//  Student.m
//  CoredataTest
//
//  Created by Sayan Chatterjee on 04/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Student.h"

#import "Marks.h"

@implementation Student 

@dynamic sid;
@dynamic sname;
@dynamic gotMarks;

- (void) dealloc {
	self.sid = nil;
	self.sname = nil;
	self.gotMarks = nil;
	[super dealloc];
}

@end
