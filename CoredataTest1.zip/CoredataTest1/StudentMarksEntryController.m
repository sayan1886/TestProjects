    //
//  StudentMarksEntryController.m
//  CoredataTest
//
//  Created by Sayan Chatterjee on 04/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "StudentMarksEntryController.h"
#import "Marks.h"
#import "Student.h"
#import "CoredataTestAppDelegate.h"


@implementation StudentMarksEntryController

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	studmarksentry = [[StudentMarksEntry alloc] initWithFrame:CGRectMake(50, 50, 220, 160)];
	studmarksentry.studmarksDelegate = self;
	[self.view addSubview:studmarksentry]; 
}

-(void)didSelectStudMarksSave:(NSMutableArray *)marksArr{

	NSLog(@"MarksArr : %@", marksArr);
	CoredataTestAppDelegate *app = (CoredataTestAppDelegate*)[[UIApplication sharedApplication]delegate];
	Marks *aMarks = nil;
	aMarks = (Marks*)[NSEntityDescription insertNewObjectForEntityForName:@"Marks" inManagedObjectContext:[app managedObjectContext]];
	Student *aStudent = nil;
	// aStudent = (Student*)[NSEntityDescription insertNewObjectForEntityForName:@"Student" inManagedObjectContext:[app managedObjectContext]];
	
	//[aStudent setValue:1 forKey:@"Test"];
	NSManagedObjectModel *model = [[app.managedObjectContext persistentStoreCoordinator]managedObjectModel];
	NSLog(@"%@",[model entities]);
	NSEntityDescription *entity = [NSEntityDescription entityForName:@"Student" inManagedObjectContext:app.managedObjectContext]; 
	//NSEntityDescription *entity = [[model entities] objectAtIndex:[studid intValue]];
	NSFetchRequest *request = [[[NSFetchRequest alloc] init] autorelease];
	[request setEntity:entity];
	NSString *query = [NSString stringWithString:@"sid == "];
	query = [query stringByAppendingFormat:@"%@",[marksArr objectAtIndex:0]];
	
	[request setPredicate:[NSPredicate predicateWithFormat:query]];
	NSError *error = nil;
	NSMutableArray *results = [[app.managedObjectContext executeFetchRequest:request error:&error] mutableCopy];
	if ([results count] > 0) {
		NSNumber *sid = [[NSNumber alloc] initWithInt:[[marksArr objectAtIndex:0] intValue]];
		NSNumber *marks = [[NSNumber alloc] initWithInt:[[marksArr objectAtIndex:1]intValue]];
		[aMarks setSid:sid];
		[aMarks setTotalmarks:marks];
		aStudent = (Student*)[NSEntityDescription insertNewObjectForEntityForName:@"Student" inManagedObjectContext:[app managedObjectContext]];
		[aStudent setSid:sid];
		NSLog(@"%@",aStudent.sid);
		[aMarks setHasSid:aStudent];
		//[aMarks setValue:aStudent forKey:@"hasSid"];
		[sid release];
		[marks release];
		NSLog(@"id : %@",aMarks.sid);
		NSLog(@"marks : %@",aMarks.totalmarks);
		NSLog(@"student id : %@",aStudent.sid);
		NSError *error;
		if([app.managedObjectContext save:&error])
			NSLog(@"Saved");
		else
			NSLog(@"Not Saved");
		UIAlertView *saveAlert = [[UIAlertView alloc] initWithTitle:@"INFO SAVED" message:@"INFORMATION IS SAVED...." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		[saveAlert show];
		saveAlert.tag=100;
		[saveAlert release];
	}
	else {
		UIAlertView *saveAlert = [[UIAlertView alloc] initWithTitle:@"ERROR!" message:@"The Id Is Not In Database...." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		[saveAlert show];
		saveAlert.tag=100;
		[saveAlert release];
	}

	
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
