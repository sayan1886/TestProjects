    //
//  CoreDataTestViewController.m
//  CoredataTest
//
//  Created by Sayan Chatterjee on 03/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "CoreDataTestViewController.h"
#import "FirstView.h"


@implementation CoreDataTestViewController

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	/*frstAlert = [[UIAlertView alloc] initWithTitle:@"Student Database" 
										 message:@"Enter/Display Student Records"
										delegate:self 
							   cancelButtonTitle:@"Enter" 
							   otherButtonTitles:@"Display",nil];
	[frstAlert show];
	frstAlert.tag=100;
	[frstAlert release]; */
	self.view.backgroundColor = [UIColor clearColor];
	frstview = [[FirstView alloc] initWithFrame:CGRectMake(50, 50, 220, 160)];
	frstview.frstdelegate = self;
	[self.view addSubview:frstview];
	//navbar = [[UINavigationController alloc] initWithRootViewController:self];
	//[self.view addSubview:navbar];
	//[frstview release];
}

-(void)createView{

	
}


-(void)didSelectBtn:(NSInteger)btnIndex{
	//NSLog(@"Ayon Das");
	switch (btnIndex) {
		case 1:
			studentryctrl = [[StudentEntryController alloc] init];
			[self.navigationController pushViewController:studentryctrl animated:YES];
			//[navbar.navigationController pushViewController:self];

			//[navbar]
			break;
		case 2:
			studmarksentryctrl = [[StudentMarksEntryController alloc] init];
			[self.navigationController pushViewController:studmarksentryctrl animated:YES];
			break;
		case 3:
			studmarksdispctrl = [[StudentmarksDispController alloc] init];
			[self.navigationController pushViewController:studmarksdispctrl animated:YES];
			break;
		default:
			break;
	}
}



- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
	if (alertView.tag == 100 ) {
		
		if (buttonIndex == 0) {
			
			//[self createTableView];
		}
		else {
			//[self openAddBook];
		}
		
	}
	else {
		//NSLog(@"Sayan....");
		[self viewDidLoad];
	}
	
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
