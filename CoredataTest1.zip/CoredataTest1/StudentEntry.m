//
//  StudentEntry.m
//  CoredataTest
//
//  Created by Sayan Chatterjee on 04/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "StudentEntry.h"


@implementation StudentEntry
@synthesize studDelegate;


-(id)initWithFrame:(CGRect)frm {
    
    self = [super initWithFrame:frm];
	self.frame = frm;
    if (self) {
        // Initialization code.
		[self createView:frm];
	}
	return self;
}


-(void)createView:(CGRect)frm{
	//UIView *myView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
	sid = [[UITextField alloc] initWithFrame:CGRectMake(10,10,200,40)];
	sid.placeholder = @"STUDENT ID"; 
	[sid setBorderStyle:UITextBorderStyleRoundedRect];
	[sid setAdjustsFontSizeToFitWidth:YES];
	sid.delegate = self;
	[self addSubview:sid];
	
	sname = [[UITextField alloc] initWithFrame:CGRectMake(10, 60, 200,40)];
	sname.placeholder = @"STUDENT NAME"; 
	[sname setBorderStyle:UITextBorderStyleRoundedRect];
	[sname setAdjustsFontSizeToFitWidth:YES];
	sname.delegate = self;
	[self addSubview:sname];

	save = [UIButton buttonWithType:UIButtonTypeRoundedRect];
	save.frame=CGRectMake(40,110,140,40);
	save.backgroundColor=[UIColor whiteColor];
	[save setTitle:@"ADD INFO" forState:UIControlStateNormal];
	[save addTarget:self action:@selector(readInputs) forControlEvents:UIControlEventTouchUpInside];
	[self addSubview:save];

	self.backgroundColor = [UIColor clearColor];
	[[self layer] setCornerRadius: 14 ];
	[[self layer] setBorderWidth:3];
	[[self layer] setBorderColor:[[ UIColor blackColor] CGColor]];
	
}

-(void)readInputs{
	studArr = [[NSMutableArray alloc] init];
	[studArr addObject:sid.text];
	[studArr addObject:sname.text];
	sid.text = @"";
	sname.text = @"";
	//UIButton *btn = (UIButton*)sender;
	if (self.studDelegate) {
		if ([self.studDelegate respondsToSelector:@selector(didSelectSaveStudEntry:)]) {
			//if (self.studDelegate (didSelectSaveStudEntry:studArr)) {
				[self.studDelegate didSelectSaveStudEntry:studArr];
			//}
		}
	}
	
	
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField{
	//vals = [NSMutableArray	arrayWithObject:textField.text];
	[textField resignFirstResponder];
	return YES;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code.
}
*/

- (void)dealloc {
    [super dealloc];
}


@end
