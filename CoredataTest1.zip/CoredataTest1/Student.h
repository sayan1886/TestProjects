//
//  Student.h
//  CoredataTest
//
//  Created by Sayan Chatterjee on 04/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <CoreData/CoreData.h>

@class Marks;

@interface Student :  NSManagedObject  
{
	NSNumber * sid;
	NSString * sname;
	Marks * gotMarks;
}

@property (nonatomic, retain) NSNumber * sid;
@property (nonatomic, retain) NSString * sname;
@property (nonatomic, retain) Marks * gotMarks;

@end



