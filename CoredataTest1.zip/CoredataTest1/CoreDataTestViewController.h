//
//  CoreDataTestViewController.h
//  CoredataTest
//
//  Created by Sayan Chatterjee on 03/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FirstView.h"
#import "StudentEntryController.h"
#import "StudentMarksEntryController.h"
#import "StudentmarksDispController.h"
#import "StudentMarksEntry.h"
#import "StudentEntry.h"

//@class StudentEntry,StudentMarksEntry,StudentMarksDisp;

@interface CoreDataTestViewController : UIViewController <controlFlowDelegate>  {

	@private
	UIAlertView *frstAlert;
	UIAlertView *scndtAlert;
	
	FirstView *frstview;
	StudentMarksEntry *studmarks;
	StudentEntry *studentry;
	StudentEntryController *studentryctrl;
	StudentMarksEntryController *studmarksentryctrl;
	StudentmarksDispController *studmarksdispctrl;
}

-(void)createView;
@end
