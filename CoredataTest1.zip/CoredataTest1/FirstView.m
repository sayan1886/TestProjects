//
//  FirstView.m
//  CoredataTest
//
//  Created by Sayan Chatterjee on 04/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "FirstView.h"


@implementation FirstView
@synthesize frstdelegate;

-(id)initWithFrame:(CGRect)frm {
    
    self = [super initWithFrame:frm];
	self.frame = frm;
    if (self) {
        // Initialization code.
		[self createView:frm];
	}
		    return self;
}

-(void)createView:(CGRect)frm{

	studentry = [UIButton buttonWithType:UIButtonTypeRoundedRect];
	studentry.frame=CGRectMake(10,10,200,40);
	studentry.backgroundColor=[UIColor whiteColor];
	studentry.tag=1;
	[studentry setTitle:@"STUDENT ENTRY" forState:UIControlStateNormal];
	[studentry addTarget:self action:@selector(readInputs:) forControlEvents:UIControlEventTouchUpInside];
	[self addSubview:studentry];
	
	studmarks = [UIButton buttonWithType:UIButtonTypeRoundedRect];
	studmarks.frame=CGRectMake(10,60,200,40);
	studmarks.tag=2;
	studmarks.backgroundColor=[UIColor whiteColor];
	[studmarks setTitle:@"STUDENT MARKS ENTRY" forState:UIControlStateNormal];
	[studmarks addTarget:self action:@selector(readInputs:) forControlEvents:UIControlEventTouchUpInside];
	[self addSubview:studmarks];
	
	studdisp = [UIButton buttonWithType:UIButtonTypeRoundedRect];
	studdisp.frame=CGRectMake(10,110,200,40);
	studdisp.tag=3;
	studdisp.backgroundColor=[UIColor whiteColor];
	[studdisp setTitle:@"STUDENT MARKS DISPLAY" forState:UIControlStateNormal];
	[studdisp addTarget:self action:@selector(readInputs:) forControlEvents:UIControlEventTouchUpInside];
	[self addSubview:studdisp];
	
	self.backgroundColor = [UIColor clearColor];
	[[self layer] setCornerRadius: 14 ];
	[[self layer] setBorderWidth:3];
	[[self layer] setBorderColor:[[ UIColor blackColor] CGColor]];

	
	//return myView;
}

-(void)readInputs:(id)sender
{
	UIButton *btn = (UIButton*)sender;
	if (self.frstdelegate) {
		if ([self.frstdelegate respondsToSelector:@selector(didSelectBtn:)]) {
			[self.frstdelegate didSelectBtn:btn.tag];
		}
	}

	
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code.
}
*/

- (void)dealloc {
    [super dealloc];
}


@end
