//
//  StudentMarksEntry.m
//  CoredataTest
//
//  Created by Sayan Chatterjee on 04/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "StudentMarksEntry.h"


@implementation StudentMarksEntry


@synthesize studmarksDelegate,marksArr;


-(id)initWithFrame:(CGRect)frm {
    
    self = [super initWithFrame:frm];
	self.frame = frm;
    if (self) {
        // Initialization code.
		[self createView:frm];
	}
	return self;
}


-(void)createView:(CGRect)frm{
	//UIView *myView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
	sid = [[UITextField alloc] initWithFrame:CGRectMake(10,10,200,40)];
	sid.placeholder = @"STUDENT ID"; 
	[sid setBorderStyle:UITextBorderStyleRoundedRect];
	[sid setAdjustsFontSizeToFitWidth:YES];
	sid.delegate = self;
	[self addSubview:sid];
	
	marks = [[UITextField alloc] initWithFrame:CGRectMake(10, 60, 200,40)];
	marks.placeholder = @"TOTAL MARKS"; 
	[marks setBorderStyle:UITextBorderStyleRoundedRect];
	[marks setAdjustsFontSizeToFitWidth:YES];
	marks.delegate = self;
	[self addSubview:marks];
	
	save = [UIButton buttonWithType:UIButtonTypeRoundedRect];
	save.frame=CGRectMake(40,110,140,40);
	save.backgroundColor=[UIColor whiteColor];
	[save setTitle:@"ADD INFO" forState:UIControlStateNormal];
	[save addTarget:self action:@selector(readInputs) forControlEvents:UIControlEventTouchUpInside];
	[self addSubview:save];
	
	self.backgroundColor = [UIColor clearColor];
	[[self layer] setCornerRadius: 14 ];
	[[self layer] setBorderWidth:3];
	[[self layer] setBorderColor:[[ UIColor blackColor] CGColor]];
	
}

-(void)readInputs{
	//UIButton *btn = (UIButton*)sender;
	marksArr = [[NSMutableArray alloc] init];
	[marksArr addObject:sid.text];
	[marksArr addObject:marks.text];
	if (self.studmarksDelegate) {
		if ([self.studmarksDelegate respondsToSelector:@selector(didSelectStudMarksSave:)]) {
			[self.studmarksDelegate didSelectStudMarksSave:marksArr];
		}
	}
	sid.text = @"";
	marks.text = @"";

}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
	//vals = [NSMutableArray	arrayWithObject:textField.text];
	[textField resignFirstResponder];
	return YES;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code.
}
*/

- (void)dealloc {
    [super dealloc];
}


@end
