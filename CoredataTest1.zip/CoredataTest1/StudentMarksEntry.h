//
//  StudentMarksEntry.h
//  CoredataTest
//
//  Created by Sayan Chatterjee on 04/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>


@protocol StudentMarksEntryDelegate <NSObject>

-(void)didSelectStudMarksSave:(NSMutableArray *)marksArr;

@end

@interface StudentMarksEntry : UIView <UITextFieldDelegate>{

	
	@private	
	UITextField *sid;
	UITextField *marks;
	UIButton *save;
	id<StudentMarksEntryDelegate> studmarksDelegate;
	NSMutableArray *marksArr;
}

-(void)createView:(CGRect)frm;
-(id)initWithFrame:(CGRect)frm;

@property (nonatomic,assign) id<StudentMarksEntryDelegate> studmarksDelegate; 
@property (nonatomic,retain) 	NSMutableArray *marksArr;

@end
