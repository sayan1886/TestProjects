//
//  StudentEntry.h
//  CoredataTest
//
//  Created by Sayan Chatterjee on 04/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@protocol StudentEntryDelegate <NSObject>

-(void)didSelectSaveStudEntry:(NSMutableArray *)arr;

@end


@interface StudentEntry : UIView <UITextFieldDelegate>{
	
	@private
	
	UITextField *sid;
	UITextField *sname;
	UIButton *save;
	id<StudentEntryDelegate> studDelegate;
	NSMutableArray *studArr;
}

-(void)createView:(CGRect)frm;
-(id)initWithFrame:(CGRect)frm;

@property (nonatomic,assign) id<StudentEntryDelegate> studDelegate; 

@end
