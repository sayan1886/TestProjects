//
//  StudentEntryController.h
//  CoredataTest
//
//  Created by Sayan Chatterjee on 04/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "StudentEntry.h"
#import "CoredataTestAppDelegate.h"

@interface StudentEntryController : UIViewController <StudentEntryDelegate>{

	StudentEntry *studentry;
	CoredataTestAppDelegate *app;
}

@end
