//
//  CoredataTestAppDelegate.h
//  CoredataTest
//
//  Created by Sayan Chatterjee on 03/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
//

@class CoreDataTestViewController;

@interface CoredataTestAppDelegate : NSObject <UIApplicationDelegate> {
    
    UIWindow *window;
	CoreDataTestViewController *viewController;
    
@private
    NSManagedObjectContext *managedObjectContext_;
    NSManagedObjectModel *managedObjectModel_;
    NSPersistentStoreCoordinator *persistentStoreCoordinator_;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@property (nonatomic, retain, readonly) NSManagedObjectContext *managedObjectContext;
@property (nonatomic, retain, readonly) NSManagedObjectModel *managedObjectModel;
@property (nonatomic, retain, readonly) NSPersistentStoreCoordinator *persistentStoreCoordinator;
@property (nonatomic, retain) CoreDataTestViewController *viewController;
- (NSURL *)applicationDocumentsDirectory;
- (void)saveContext;

@end

