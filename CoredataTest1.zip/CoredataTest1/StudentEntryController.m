    //
//  StudentEntryController.m
//  CoredataTest
//
//  Created by Sayan Chatterjee on 04/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "StudentEntryController.h"
#import "Student.h"
#import "Marks.h"


@implementation StudentEntryController

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	studentry = [[StudentEntry alloc] initWithFrame:CGRectMake(50, 50, 220, 160)];
	studentry.studDelegate = self;
	app = (CoredataTestAppDelegate*)[[UIApplication sharedApplication]delegate];
	[self.view addSubview:studentry]; 
}

-(void)didSelectSaveStudEntry:(NSMutableArray *)studArr{
	
	NSLog(@"Studarr : %@", studArr);
	
	Student *aStudent = nil;
	 aStudent = (Student*)[NSEntityDescription insertNewObjectForEntityForName:@"Student" inManagedObjectContext:[app managedObjectContext]];
	 
	//[aStudent setValue:1 forKey:@"Test"];
	//NSNumber *sid = ;
	//NSString *sname = [NSString initWithString:];
	[aStudent setSid:[NSNumber numberWithInt:[[studArr objectAtIndex:0] intValue]]];
	[aStudent setSname:[studArr objectAtIndex:1]];
	//[sid release];
	//[sname release];
	NSError *error;
	if([app.managedObjectContext save:&error])
		NSLog(@"Saved");
	else
		NSLog(@"Not Saved");
	UIAlertView *saveAlert = [[UIAlertView alloc] initWithTitle:@"INFO SAVED" message:@"INFORMATION IS SAVED...." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
	[saveAlert show];
	saveAlert.tag=100;
	[saveAlert release];
	 
	// NSFetchRequest *fetchData = [[NSFetchRequest alloc]init];
	 
	
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{

}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
