//
//  StudentMarksEntryController.h
//  CoredataTest
//
//  Created by Sayan Chatterjee on 04/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "StudentMarksEntry.h"

@interface StudentMarksEntryController : UIViewController <StudentMarksEntryDelegate> {

	StudentMarksEntry *studmarksentry;
}

@end
