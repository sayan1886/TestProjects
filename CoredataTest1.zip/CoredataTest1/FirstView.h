//
//  FirstView.h
//  CoredataTest
//
//  Created by Sayan Chatterjee on 04/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@protocol controlFlowDelegate <NSObject>

-(void)didSelectBtn:(NSInteger)btnIndex;

@end

@interface FirstView : UIView {
	
	
	@private
	UIButton *studentry;
	UIButton *studmarks;
	UIButton *studdisp;
	id<controlFlowDelegate> frstdelegate;
}

-(void)createView:(CGRect)frm;
-(id)initWithFrame:(CGRect)frm;

@property (nonatomic,assign) id<controlFlowDelegate> frstdelegate; 

@end
