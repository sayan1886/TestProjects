// 
//  Marks.m
//  CoredataTest
//
//  Created by Sayan Chatterjee on 04/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Marks.h"
#import "Student.h"

@implementation Marks 

@dynamic sid;
@dynamic totalmarks;
@dynamic hasSid;

- (void) setHasSid:(Student *)aStudent{
	hasSid = aStudent;
	hasSid.sid = aStudent.sid;
	hasSid.sname = aStudent.sname;
	NSLog(@"%@,%@",hasSid.sid,hasSid.sname);
}

- (Student *)hasSid{
	return hasSid;
}

- (void) dealloc {
	self.sid = nil;
	self.hasSid = nil;
	self.totalmarks = nil;
	[super dealloc];
}

@end
