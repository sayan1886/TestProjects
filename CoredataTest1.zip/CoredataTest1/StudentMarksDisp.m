//
//  StudentMarksDisp.m
//  CoredataTest
//
//  Created by Sayan Chatterjee on 04/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "StudentMarksDisp.h"


@implementation StudentMarksDisp

@synthesize studinfoDelegate;


-(id)initWithFrame:(CGRect)frm {
    
    self = [super initWithFrame:frm];
	self.frame = frm;
    if (self) {
        // Initialization code.
		[self createView:frm];
	}
	return self;
}


-(void)createView:(CGRect)frm{
	//UIView *myView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
	sid = [[UITextField alloc] initWithFrame:CGRectMake(10,10,200,40)];
	sid.placeholder = @"STUDENT ID"; 
	[sid setBorderStyle:UITextBorderStyleRoundedRect];
	[sid setAdjustsFontSizeToFitWidth:YES];
	sid.delegate = self;
	[self addSubview:sid];
	
	sname = [[UILabel alloc] initWithFrame:CGRectMake(10, 50, 200,30)];
	//[sname setBorderStyle:UITextBorderStyleRoundedRect];
	sname.text = @"STUDENT NAME";
	[sname setAdjustsFontSizeToFitWidth:YES];
	[self addSubview:sname];
	
	
	marks = [[UILabel alloc] initWithFrame:CGRectMake(10, 80, 200,30)];
	//[marks setBorderStyle:UITextBorderStyleRoundedRect];
	marks.text = @"TOTAL MARKS";
	[marks setAdjustsFontSizeToFitWidth:YES];
	[self addSubview:marks];
	
	disp = [UIButton buttonWithType:UIButtonTypeRoundedRect];
	disp.frame=CGRectMake(40,110,140,40);
	disp.backgroundColor=[UIColor whiteColor];
	[disp setTitle:@"DISPLAY INFO" forState:UIControlStateNormal];
	[disp addTarget:self action:@selector(readInputs) forControlEvents:UIControlEventTouchUpInside];
	[self addSubview:disp];
	
	self.backgroundColor = [UIColor clearColor];
	[[self layer] setCornerRadius: 14 ];
	[[self layer] setBorderWidth:3];
	[[self layer] setBorderColor:[[ UIColor blackColor] CGColor]];
	
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
	//vals = [NSMutableArray	arrayWithObject:textField.text];
	[textField resignFirstResponder];
	return YES;
}


-(void)readInputs{
	//UIButton *btn = (UIButton*)sender;
	[sname resignFirstResponder];
	[marks resignFirstResponder];
	studid = [[NSNumber alloc] initWithInt:[sid.text intValue]];
	if (self.studinfoDelegate) {
		if ([self.studinfoDelegate respondsToSelector:@selector(didSelectDisp:)]) {
			[self.studinfoDelegate didSelectDisp:studid];
		}
	}
}

- (void) changeView:(NSArray *)details{
	//NSLog(@"%@,%@",details);
	if (details == 0) {
		
	}
	if ([details count] == 1) {
		sname.text = [details objectAtIndex:0];
	}
	if ([details count] == 2) {
		sname.text = [details objectAtIndex:0];
		marks.text = [NSString stringWithFormat:@"%@", [details objectAtIndex:1]];
	}

}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code.
}
*/

- (void)dealloc {
    [super dealloc];
}


@end
