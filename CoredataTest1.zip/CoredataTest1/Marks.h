//
//  Marks.h
//  CoredataTest
//
//  Created by Sayan Chatterjee on 04/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <CoreData/CoreData.h>

@class Student;

@interface Marks :  NSManagedObject  
{
	NSNumber * sid;
	NSNumber * totalmarks;
	Student * hasSid;
	
}

@property (nonatomic, retain) NSNumber * sid;
@property (nonatomic, retain) NSNumber * totalmarks;
@property (nonatomic, retain) Student * hasSid;

@end



