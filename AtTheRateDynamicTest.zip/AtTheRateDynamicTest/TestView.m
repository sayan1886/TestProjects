//
//  TestView.m
//  testABC
//
//  Created by Sayan on 22/06/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "TestView.h"
#import <QuartzCore/QuartzCore.h>

@implementation TestView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.backgroundColor = [UIColor clearColor];
    }
    return self;
}


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect_
{
    // Drawing code
    
    //Left Chat Bubble
    CGContextRef context = UIGraphicsGetCurrentContext();
    //CGRect rect = self.bounds;
    CGFloat radius = 10.0;
    CGRect rect = CGRectMake(0, 0, 80, 80);;
    
    
    CGFloat originBufferX = 4.0;
    CGFloat originBufferY = 4.0; //2.0
    CGFloat rightAngleTriangleWidth = 10.0;
    CGFloat rightAngleTriangleHeight = 10.0;
    
    CGFloat fullRectWidth = rect.size.width - 8.0;//-2;
    CGFloat fullRectHeight = rect.size.height - 8.0;//subho
    
    CGPoint pointZero = CGPointMake(originBufferX, fullRectHeight + 4);
    CGPoint pointOne = CGPointMake(originBufferX + rightAngleTriangleWidth, fullRectHeight - rightAngleTriangleHeight);
    CGPoint pointTwo = CGPointMake(originBufferX + rightAngleTriangleWidth, radius + originBufferY);
    CGPoint pointThree = CGPointMake(originBufferX + fullRectWidth - radius, originBufferY + 4);
    CGPoint pointFour = CGPointMake(fullRectWidth, originBufferY + fullRectHeight - radius);    
    
    // CGContextSetRGBStrokeColor(context, 0.8, 0.8, 0.8, 0.3);//subho
    
    CGMutablePathRef path = CGPathCreateMutable();
    CGPathMoveToPoint(path, NULL, pointZero.x, pointZero.y);
    
    CGPathAddLineToPoint(path, NULL, pointOne.x, pointOne.y);
    
    CGPathAddLineToPoint(path, NULL, pointTwo.x, pointTwo.y);
    
    CGPathAddArc(path, NULL, rightAngleTriangleWidth + radius + 4, originBufferY + radius + 4, radius, M_PI, -M_PI_2, 0);
    
    CGPathAddLineToPoint(path, NULL, pointThree.x, pointThree.y);
    
    CGPathAddArc(path, NULL, fullRectWidth - radius, originBufferY + radius + 4, radius, -M_PI_2, 0.0f, 0);
    
    CGPathAddLineToPoint(path, NULL, pointFour.x, pointFour.y);
    
    CGPathAddArc(path, NULL, fullRectWidth - radius, originBufferY + fullRectHeight - radius, radius, 0.0f, M_PI_2, 0);
    
    CGPathAddLineToPoint(path, NULL, pointZero.x, pointZero.y);
    
    CGContextSaveGState(context);
    CGContextAddPath(context, path);
    
    CGContextSetLineWidth(context, 1.5f);
    //CGContextSetRGBFillColor(context, 1.0f, 1.0f, 1.0f, 0.1f);
    CGContextSetRGBFillColor(context, 1.0, 1.0, 1.0, 1.0); //white fill
    CGContextSetRGBStrokeColor(context, 0.0, 0.0, 0.0, 1.0); //black stroke
    //   CGContextStrokeRect(context, rect);  
    //CGContextFillPath(context);
    
    CGContextAddPath(context, path);
    CGContextStrokePath(context);
    
    /* //Right Chat bubble
        CGContextRef context = UIGraphicsGetCurrentContext();
        CGRect rect = CGRectMake(0, 0, 80, 80);
        CGFloat radius = 10.0;
        
        CGFloat originBufferX = 4.0;
        CGFloat originBufferY = 4.0;
        CGFloat rightAngleTriangleWidth = 10.0;
        CGFloat rightAngleTriangleHeight = 10.0;
        CGFloat fullRectWidth = rect.size.width - 8.0;
        CGFloat fullRectHeight = rect.size.height - 8.0;
        
        
        CGPoint pointZero = CGPointMake(originBufferX   , fullRectHeight - radius);
        CGPoint pointOne = CGPointMake(originBufferX  , originBufferY + radius );
        CGPoint pointTwo = CGPointMake(fullRectWidth - radius ,originBufferY);

        CGPoint pointThree = CGPointMake(fullRectWidth ,  fullRectHeight - rightAngleTriangleHeight );
        CGPoint pointFour = CGPointMake(fullRectWidth + rightAngleTriangleWidth,  fullRectHeight);   
        CGPoint pointFive = CGPointMake(radius, fullRectHeight);
        
        
        CGMutablePathRef path = CGPathCreateMutable();
        CGPathMoveToPoint(path, NULL, pointZero.x, pointZero.y);
        
        CGPathAddLineToPoint(path, NULL, pointOne.x, pointOne.y);
        //add top left arc
        CGPathAddArc(path, NULL, radius + 4 ,  radius + 4, radius, M_PI, -M_PI_2, 0);
        CGPathAddLineToPoint(path, NULL, pointTwo.x, pointTwo.y);
    //add top right arc
        CGPathAddArc(path, NULL, fullRectWidth - radius, originBufferY + radius , radius, -M_PI_2, 0.0f, 0);
        
        CGPathAddLineToPoint(path, NULL, pointThree.x, pointThree.y);
        
        
       CGPathAddLineToPoint(path, NULL, pointFour.x, pointFour.y);
        
       CGPathAddLineToPoint(path, NULL, pointFive.x, pointFive.y);    
    
    //add bottom left arc
        CGPathAddArc(path, NULL,  radius + 4, fullRectHeight - radius , radius, M_PI_2, -M_PI, 0);
        
        CGContextSaveGState(context);
        CGContextAddPath(context, path);
        
        CGContextSetLineWidth(context, 1.0f);
        CGContextSetRGBFillColor(context, 0.0, 1.0, 0.0, 1.0); //white fill
        CGContextSetRGBStrokeColor(context, 0.0, 0.0, 0.0, 1.0); //black stroke
        //CGContextFillPath(context);
        
        CGContextAddPath(context, path);
        CGContextStrokePath(context);
        self.backgroundColor = [UIColor clearColor];
       */ 
    
    CGContextAddPath(context, path);
    CGContextClosePath(context);
    CGContextClip(context);
    
    CGGradientRef gradient = NULL;
    CGColorSpaceRef rgb = CGColorSpaceCreateDeviceRGB();
    CGFloat colors[] =
    {
        //        237.0 / 255.0, 237.0 / 255.0, 237.0 / 255.0, 1.0,
        //        204.0 / 255.0, 224.0 / 255.0, 244.0 / 255.0, 1.00,
        //        203.0 / 255.0, 203.0 / 255.0, 203.0 / 255.0, 1.0,
        
        237.0 / 255.0, 237.0 / 255.0, 237.0 / 255.0, 1.00,
        203.0 / 255.0, 203.0 / 255.0, 203.0 / 255.0, 1.00,
        185.0 / 255.0, 185.0 / 255.0, 185.0 / 255.0, 1.00,
        
    };
    gradient = CGGradientCreateWithColorComponents(rgb, colors, NULL, sizeof(colors)/(sizeof(colors[0])*4));
    CGColorSpaceRelease(rgb);
    CGContextDrawLinearGradient(context, gradient, pointZero, pointOne, 3);
}

static void addRoundedRectToPath(CGContextRef context, CGRect rect,
                                 float ovalWidth,float ovalHeight)
{
    float fw, fh;
    if (ovalWidth == 0 || ovalHeight == 0) { // 1
        CGContextAddRect(context, rect);
        return;
    }
    CGContextSaveGState(context); // 2
    CGContextTranslateCTM (context, CGRectGetMinX(rect), // 3
                           CGRectGetMinY(rect));
    CGContextScaleCTM (context, ovalWidth, ovalHeight); // 4
    fw = CGRectGetWidth (rect) / ovalWidth; // 5
    fh = CGRectGetHeight (rect) / ovalHeight; // 6
    CGContextMoveToPoint(context, fw, fh/2);  // 7
    CGContextAddArcToPoint(context, fw, fh, fw/2, fh, 1); // 8
    CGContextAddArcToPoint(context, 0, fh, 0, fh/2, 1); // 9
    CGContextAddArcToPoint(context, 0, 0, fw/2, 0, 1); // 10
    CGContextAddArcToPoint(context, fw, 0, fw, fh/2, 1);  // 11
    CGContextClosePath(context); // 12
    CGContextRestoreGState(context); // 13
}


@end
