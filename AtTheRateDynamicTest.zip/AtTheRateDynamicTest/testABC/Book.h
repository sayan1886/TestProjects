//
//  Book.h
//  testABC
//
//  Created by Sayan on 19/06/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Book : NSObject
{
    NSMutableDictionary *data;
}
@property (retain) NSString *title;
@property (retain) NSString *author;
@end
