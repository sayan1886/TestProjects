//
//  ITARAppDelegate.h
//  testABC
//
//  Created by Sayan on 20/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ITARViewController;

@interface ITARAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ITARViewController *viewController;

@end
