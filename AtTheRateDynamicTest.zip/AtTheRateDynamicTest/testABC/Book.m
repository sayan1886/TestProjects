//
//  Book.m
//  testABC
//
//  Created by Sayan on 19/06/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Book.h"
#import <objc/runtime.h>

@implementation Book
@dynamic title, author;

- (id)init
{
    if ((self = [super init])) {
        data = [[NSMutableDictionary alloc] init];
        [data setObject:@"Tom Sawyer" forKey:@"title"];
        [data setObject:@"Mark Twain" forKey:@"author"];
    }
    return self;
}

- (void)dealloc
{
    [data release];
    [super dealloc];
}

- (id) valueForKey:(NSString *)key{
    return [data objectForKey:key];
}

- (void) setValue:(id)value forKey:(NSString *)key{
    [data setValue:value forKey:key];
}


//+ (BOOL) resolveClassMethod:(SEL)sel{
//    if (sel == @selector(setTitle:)) {
//        class_addMethod([self class], sel, (IMP) dynamicMethodIMP, "v@:@");
//    }
//    return [super resolveClassMethod:sel];
//}

//@ -> object v -> void c -> char
- (NSMethodSignature *)methodSignatureForSelector:(SEL)selector{
    NSString *sel = NSStringFromSelector(selector);
    if ([sel rangeOfString:@"set"].location == 0) {
        //return [NSMethodSignature signatureWithObjCTypes:"v@:@"];
        return [NSMethodSignature methodSignatureForSelector:@selector(setValue:forKey:)];
    } else {
        //return [NSMethodSignature signatureWithObjCTypes:"@@:"];
        return [NSMethodSignature methodSignatureForSelector:@selector(valueForKey:)];
    }
}

- (void)forwardInvocation:(NSInvocation *)invocation{
    NSString *key = NSStringFromSelector([invocation selector]);
    
    
    if ([key rangeOfString:@"set"].location == 0) {
        [invocation setSelector:@selector(setValue:forKey:)];
//        NSString *obj;
//        [invocation getArgument:&obj atIndex:2];
//        [invocation setArgument: &obj atIndex:2];
        key = [[key substringWithRange:NSMakeRange(3, [key length]-4)] lowercaseString];
        [invocation setArgument:&key atIndex:3];
        //[data setValue:obj forKey:key];
    } else {
        [invocation setSelector:@selector(valueForKey:)];
        [invocation setArgument:&key atIndex:2];
        //key = [[key substringWithRange:NSMakeRange(3, [key length]-4)] lowercaseString];
        //NSString *obj;
        //[invocation getArgument:&obj atIndex:2];
//        NSString *obj = [data objectForKey:key];
//        [invocation setReturnValue:&obj];
    }
    [invocation invoke];
    //[invocation invokeWithTarget:self];
}
 

@end
