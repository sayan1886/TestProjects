//
//  Tenant.m
//  RentTracker
//
//  Created by Manas Kumar Mandal on 18/04/12.
//  Copyright (c) 2012 ObjectSol Technologies. All rights reserved.
//

#import "Tenant.h"
#import "Building.h"
#import "Payment.h"


@implementation Tenant

@dynamic deposit_amount;
@dynamic dep_paid_date;
@dynamic postal_code;
@dynamic work_phone;
@dynamic image;
@dynamic leaseStartDate;
@dynamic last;
@dynamic first;
@dynamic home_phone;
@dynamic city;
@dynamic rentDueDay;
@dynamic rentAmount;
@dynamic cause;
@dynamic leasePeriod;
@dynamic state;
@dynamic lastPaymentMade;
@dynamic paymentForIndex;
@dynamic lastPaymentYear;
@dynamic email;
@dynamic mobile;
@dynamic rentDue;
@dynamic note;
@dynamic moveOut;
@dynamic move_in_date;
@dynamic address;
@dynamic building;
@dynamic payments;

@end
