//
//  IAPHelper.m
//  TestInAppPurchase
//
//  Created by ASHIM SAMANTA on 09/02/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import "IAPHelper.h"

@implementation IAPHelper

@synthesize productIdentifiers = _productIdentifiers;
@synthesize products = _products;
@synthesize purchasedProducts = _purchasedProducts;
@synthesize request = _request;

// In dealloc
- (void)dealloc
{
    [_productIdentifiers release];
    _productIdentifiers = nil;
    [_products release];
    _products = nil;
    [_purchasedProducts release];
    _purchasedProducts = nil;
    [_request release];
    _request = nil;
    [super dealloc];
}

- (void)requestProducts 
{	
    self.request = [[[SKProductsRequest alloc] initWithProductIdentifiers:_productIdentifiers] autorelease];
    _request.delegate = self;
    [_request start];	
}

- (void)productsRequest:(SKProductsRequest *)request didReceiveResponse:(SKProductsResponse *)response {
	
    NSLog(@"Received products results... %@",response.products);
    //self.products = response.products;
     self.products = [response.products sortedArrayUsingComparator:^(id obj1, id obj2)
     {
         int num1 = [((SKProduct *)obj1).price intValue];
         int num2 = [((SKProduct *)obj2).price intValue];
         if(num1 > num2)
             return NSOrderedDescending;
         else if(num1 == num2)
            return NSOrderedSame;
         else
             return NSOrderedAscending;
     }];
    self.request = nil;    
	
    [[NSNotificationCenter defaultCenter] postNotificationName:kProductsLoadedNotification object:self.products];    
}

- (id)initWithProductIdentifiers:(NSSet *)productIdentifiers 
{
    if ((self = [super init])) 
	{
        // Store product identifiers
        _productIdentifiers = [productIdentifiers retain];
    }
    return self;
}

- (void)recordTransaction:(SKPaymentTransaction *)transaction {    
    // Optional: Record the transaction on the server side...    
}

- (void)provideContent:(NSString *)productIdentifier 
{
    NSLog(@"Toggling flag for: %@", productIdentifier);
    [[NSUserDefaults standardUserDefaults] setBool:TRUE forKey:productIdentifier];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [_purchasedProducts addObject:productIdentifier];
	
    [[NSNotificationCenter defaultCenter] postNotificationName:kProductPurchasedNotification object:productIdentifier];
}

-(void)saveData:(SKPaymentTransaction *)transaction
{
    NSLog(@"Save transaction data...");
	[[NSNotificationCenter defaultCenter] postNotificationName:kProductPurchasedNotification object:transaction.payment.productIdentifier];
}

- (void)completeTransaction:(SKPaymentTransaction *)transaction {
	
    NSLog(@"completeTransaction...");
	
    [self recordTransaction: transaction];
    [self provideContent: transaction.payment.productIdentifier];
    [[SKPaymentQueue defaultQueue] finishTransaction: transaction];
	
}

- (void)restoreTransaction:(SKPaymentTransaction *)transaction 
{
    NSLog(@"restoreTransaction...");
    [self recordTransaction: transaction];
    [self provideContent: transaction.originalTransaction.payment.productIdentifier];
    [[SKPaymentQueue defaultQueue] finishTransaction: transaction];
}

- (void)failedTransaction:(SKPaymentTransaction *)transaction {
	
    if (transaction.error.code != SKErrorPaymentCancelled)
    {
        NSLog(@"Transaction error: %@", transaction.error.localizedDescription);
    }
	
    [[NSNotificationCenter defaultCenter] postNotificationName:kProductPurchaseFailedNotification object:transaction];
    [[SKPaymentQueue defaultQueue] finishTransaction: transaction];
}

- (void)paymentQueue:(SKPaymentQueue *)queue updatedTransactions:(NSArray *)transactions
{
    
    for (SKPaymentTransaction *transaction in transactions)
    {
        NSLog(@"updatedTransactions...code = %d",transaction.transactionState);
        switch (transaction.transactionState)
        {
            case SKPaymentTransactionStatePurchased:
                [[SKPaymentQueue defaultQueue] finishTransaction: transaction];
				[self saveData:transaction];
                break;
            case SKPaymentTransactionStateFailed:
                [self failedTransaction:transaction];
                break;
            case SKPaymentTransactionStateRestored:
               // [self restoreTransaction:transaction];
                break;
            default:
                break;
        }
    }
}

- (void)buyProductIdentifier:(NSString *)productIdentifier {
	
    NSLog(@"buyProductIdentifier %@...", productIdentifier);
	
    SKPayment *payment = [SKPayment paymentWithProductIdentifier:productIdentifier];
    [[SKPaymentQueue defaultQueue] addPayment:payment];
	
}

@end
