//
//  mail.m
//  Restroom_project
//
//  Created by Raju on 21/11/11.
//  Copyright 2011 kapildeb.chowdhury@gmail.com. All rights reserved.
//

#import "mail.h"
#import "Utility.h"

@implementation mail
@synthesize con;

-(void)mailWithData:(NSString*)fileName 
{
	MFMailComposeViewController *controller = [[MFMailComposeViewController alloc] init];
	controller.mailComposeDelegate = self;
	controller.title = fileName;
	
	NSArray * toBody = [[NSArray alloc] init];
	[controller setMessageBody:@"" isHTML:NO];
	[controller setToRecipients:toBody ];
	controller.modalPresentationStyle=UIModalPresentationFullScreen;
	[controller setEditing:TRUE];
	[controller setSubject:@"Report for you!"];
	
	NSString *path = [Utility applicationDocumentsDirectory];
	path = [path stringByAppendingString:fileName];
	NSData *data = [NSData dataWithContentsOfFile:path];
	[controller addAttachmentData:data mimeType:@"application/pdf" fileName:fileName];

	if(!controller)
	{
		[self launchMailAppOnDevice];
	}
	else 
	{
		[self.con presentModalViewController:controller animated:YES];
		[controller release];
	}
}

-(void)callForSendingMail
{
	
	Class mailClass = (NSClassFromString(@"MFMailComposeViewController"));
	if (mailClass != nil)
	{
		// We must always check whether the current device is configured for sending emails
		if ([mailClass canSendMail])
		{
			//[self foo];
		}
		else
		{
			[self launchMailAppOnDevice];
		}
	}
	else
	{
		[self launchMailAppOnDevice];
	}
}
-(void)launchMailAppOnDevice
{
	NSString *emailBody = @"";
	NSString *recipients = [NSString stringWithFormat:@"mailto:?to=%@&subject=%@",@"",@""];
	NSString *body = [NSString stringWithFormat:@"&body=%@",emailBody];
	
	NSString *email = [NSString stringWithFormat:@"%@%@", recipients, body];
	email = [email stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
	
	[[UIApplication sharedApplication] openURL:[NSURL URLWithString:email]];
}

#pragma mark Compose Mail
// Dismisses the email composition interface when users tap Cancel or Send. Proceeds to update the message field with the result of the operation.
- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error 
{		
	// Notifies users about errors associated with the interface
	switch (result)
	{
		case MFMailComposeResultCancelled:
			NSLog(@"%@", @"Result: canceled");
			break;
		case MFMailComposeResultSaved:
			NSLog(@"%@", @"Result: saved");
			break;
		case MFMailComposeResultSent:
			NSLog(@"%@", @"Result: sent");
			break;
		case MFMailComposeResultFailed:
			NSLog(@"%@", @"Result: failed");
			break;
		default:
			NSLog(@"%@", @"Result: not sent");
			break;
	}
	[self.con dismissModalViewControllerAnimated:YES];
}

@end
