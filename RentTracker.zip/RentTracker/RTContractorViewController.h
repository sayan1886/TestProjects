//
//  RTContractorViewController.h
//  RentTracker
//
//  Created by ASHIM SAMANTA on 06/03/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface RTContractorViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate>
{
	UITableView *rtContractorTableView_;
	NSMutableArray *array_;
	NSMutableArray *searchText_;
	
	NSMutableDictionary *resultdict_;
 }
@property (nonatomic, retain) IBOutlet UITableView *rtContractorTableView;
@property (nonatomic, retain) NSMutableArray *searchText;
@property (nonatomic, retain) NSMutableArray *array;
@property (nonatomic, retain) NSMutableDictionary *resultdict;

-(void)getValueFromContext;

@end
