//
//  CreatePDF.m
//  VehicleInspection
//
//  Created by Avik on 10/02/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//


#define kDefaultPageHeight 792
#define kDefaultPageWidth  712
#define kMargin 50
#define kColumnMargin 10
#define kLeftMergin 20
#define kRightMergin kLeftMergin
#define kTopBoxHeight 300.0
#define leftBoxWidth 230.0
#define rightBoxWidth kDefaultPageWidth - leftBoxWidth

#define rightBoxPartHeight 300.0/4

#import "CreatePDF.h"
#import "Settings.h"
#import "Building.h"
#import "Tenant.h"
#import "Owner.h"
#import "AppDelegate_iPhone.h"
#import "CoreDataHelper.h"
#import "Constant.h"
#import "Utility.h"
#import "Payment.h"
#import "Expenses.h"


@implementation CreatePDF

@synthesize setting;
@synthesize reportedFor;
@synthesize reportedBy;
@synthesize reportedFrom;
@synthesize reportedTo;
@synthesize noOfCol;
@synthesize arrayOfAttribute;
@synthesize arrOfTag;
@synthesize entityName;
@synthesize tenant;
@synthesize reportTypesTag;
@synthesize owner;

@synthesize building;

- (void)drawString:(NSString *)str  atRect:(CGRect)rect
{
	UIFont *font=[UIFont systemFontOfSize:10];
	[str drawInRect:rect withFont:font lineBreakMode:UILineBreakModeWordWrap];
}	

- (void)drawDisclaimerString:(NSString *)str  atRect:(CGRect)rect
{
	CGContextRef  context=UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [[UIColor grayColor] CGColor]);
    UIFont *font=[UIFont italicSystemFontOfSize:8];
	[str drawInRect:rect withFont:font lineBreakMode:UILineBreakModeWordWrap];
}	

- (void)drawBoldString:(NSString *)str  atRect:(CGRect)rect
{
	UIFont *font=[UIFont boldSystemFontOfSize:10];
	[str drawInRect:rect withFont:font lineBreakMode:UILineBreakModeWordWrap];
}	

- (void)drawHeading:(NSString *)str  atRect:(CGRect)rect
{
	UIFont *font=[UIFont boldSystemFontOfSize:16];
	[str drawInRect:rect withFont:font lineBreakMode:UILineBreakModeWordWrap];
}	

- (void)drawImage:(UIImage *)img  atPoint:(CGPoint)point inContext:(CGContextRef)ctx
{
    UIImage *myImage = (UIImage *)img;
    [myImage drawAtPoint:point];
    [myImage release];
}	

- (void)drawImage:(UIImage *)img  atRect:(CGRect)rect inContext:(CGContextRef)ctx
{
	UIImage *myImage = (UIImage *)img;
    [myImage drawInRect:rect];
   // [myImage release];
    //[myImage retain];

}	

- (void)drawRect:(CGRect) rect atContext:(CGContextRef)context
{
    CGContextSetStrokeColorWithColor(context, [[UIColor blackColor] CGColor]);
    CGContextAddRect(context, rect) ; 
    CGContextStrokePath(context);
}

- (void)drawLineFromPoint:(CGPoint)startPonit toPoint:(CGPoint)endPoint atContext:(CGContextRef)context
{
    CGContextSetStrokeColorWithColor(context, [[UIColor blackColor] CGColor]);
    CGContextMoveToPoint(context, startPonit.x, startPonit.y);
    CGContextAddLineToPoint(context, endPoint.x, endPoint.y);
    CGContextStrokePath(context);
}
-(void)drawItalicString:(NSString *)str atRect:(CGRect)rect
{
    UIFont *font=[UIFont italicSystemFontOfSize:10];
	
	[str drawInRect:rect withFont:font lineBreakMode:UILineBreakModeWordWrap];
}

- (void) createPDFWithFileName:(NSString *)filePath
{
	NSString *pdfFilePath = [Utility applicationDocumentsDirectory];
	pdfFilePath = [pdfFilePath stringByAppendingString:filePath];
    CGFloat currentPageY = kMargin;
    CGFloat currentX=kLeftMergin;
    //CGFloat maxWidth = kDefaultPageWidth - (kLeftMergin + kRightMergin);
    CGFloat maxHeight = kDefaultPageHeight - kMargin * 2;
    CGFloat totalHeight = 0.0;
	
	CGFloat spaceBetweenCol = (712 - 2*(kLeftMergin))/self.noOfCol;
    
    UIGraphicsBeginPDFContextToFile(pdfFilePath, CGRectZero, nil);
    UIGraphicsBeginPDFPageWithInfo(CGRectMake(0, 0, kDefaultPageWidth, kDefaultPageHeight), nil);
    CGContextRef    currentContext = UIGraphicsGetCurrentContext();
	AppDelegate_iPhone *app = (AppDelegate_iPhone *)[[UIApplication sharedApplication] delegate];
//================================================= Top Box Contains report Info =============================================================
/*	_____________________________________
	|		|___________________________|
	|		|___________________________|
	|		|	top Box to be drawn	    |
	|_______|___________________________|*/
	
	[self drawLineFromPoint:CGPointMake(currentX, currentPageY) toPoint:CGPointMake(kDefaultPageWidth, currentPageY) atContext:currentContext];
    [self drawLineFromPoint:CGPointMake(currentX, currentPageY) toPoint:CGPointMake(currentX, kTopBoxHeight) atContext:currentContext];
	[self drawLineFromPoint:CGPointMake(leftBoxWidth, currentPageY	) toPoint:CGPointMake(leftBoxWidth, kTopBoxHeight ) atContext:currentContext];
	[self drawLineFromPoint:CGPointMake(currentX,kTopBoxHeight) toPoint:CGPointMake(kDefaultPageWidth,kTopBoxHeight) atContext:currentContext];
	[self drawLineFromPoint:CGPointMake(kDefaultPageWidth,currentPageY) toPoint:CGPointMake(kDefaultPageWidth,kTopBoxHeight) atContext:currentContext];
	
	//logo
	NSMutableArray *ar  = [CoreDataHelper getObjectsFromContext:ENTITY_KEY_SETTINGS :nil :NO :app.managedObjectContext];
	self.setting = [ar lastObject];
	[self drawImage:[UIImage imageWithData:self.setting.logo] atRect:CGRectMake(currentX+10, currentPageY+10, 73, 73) inContext:currentContext];
	currentPageY += 93;
	[self drawString:self.setting.compName atRect:CGRectMake(currentX+10, currentPageY+10, 200, 20)];
	currentPageY += 30;
	[self drawString:self.setting.propertyExperts atRect:CGRectMake(currentX+10, currentPageY+10, 200, 20)];
	currentPageY += 30;
	[self drawString:self.setting.street atRect:CGRectMake(currentX+10, currentPageY+10, 200, 20)];
	currentPageY += 30;
	[self drawString:self.setting.town atRect:CGRectMake(currentX+10, currentPageY+10, 200, 20)];
	currentPageY += 30;
	[self drawString:self.setting.country atRect:CGRectMake(currentX+10, currentPageY+10, 200, 20)];
//date time
	NSDate *date = [NSDate date];
	NSDateFormatter *form = [[NSDateFormatter alloc] init];
	[form setDateFormat:@"MM/dd/yyyy"];
	
	NSDateFormatter *format = [[NSDateFormatter alloc] init];
	[format setDateFormat:@"hh:mm:ss a"];
	
	NSString *dateStr = @"Date Printed: ";
	currentPageY = kMargin;
	dateStr = [dateStr stringByAppendingFormat:@"%@, Time: %@", [form stringFromDate:date], [format stringFromDate:date]];
	[self drawString:dateStr atRect:CGRectMake(leftBoxWidth + 10, currentPageY + 10 , rightBoxWidth , 20)];
	[self drawLineFromPoint:CGPointMake(leftBoxWidth,rightBoxPartHeight ) toPoint:CGPointMake(kDefaultPageWidth, rightBoxPartHeight) atContext:currentContext];
	CGFloat curY = currentPageY + 10 + 45;
	//Reported By
	[self drawHeading:self.reportedBy atRect:CGRectMake(leftBoxWidth +10 , curY , (rightBoxWidth) , 30)];
	[self drawLineFromPoint:CGPointMake(leftBoxWidth,(rightBoxPartHeight) * 2 ) toPoint:CGPointMake(kDefaultPageWidth, (rightBoxPartHeight) * 2 ) atContext:currentContext];
	
	curY+=25;
	//Reported For
	[self drawHeading:self.reportedFor atRect:CGRectMake(leftBoxWidth + 10, curY +45 , (rightBoxWidth) , 30)];
	[self drawLineFromPoint:CGPointMake(leftBoxWidth,(rightBoxPartHeight) * 3 ) toPoint:CGPointMake(kDefaultPageWidth, (rightBoxPartHeight) * 3 ) atContext:currentContext];
	
	curY+=85;
	//Report From
	if(self.reportedFrom && self.reportedTo)
	{
		NSString *reportStr = [NSString stringWithFormat:@"REPORT FOR %@ TO %@",self.reportedFrom, self.reportedTo];
		[self drawHeading:reportStr atRect:CGRectMake(leftBoxWidth +  10, curY + 45  , (rightBoxWidth) , 30)];
		reportStr = nil;
	}
	[self drawLineFromPoint:CGPointMake(leftBoxWidth, (rightBoxPartHeight) * 4 ) toPoint:CGPointMake(kDefaultPageWidth, (rightBoxPartHeight) * 4 ) atContext:currentContext];
	
	
	[self drawLineFromPoint:CGPointMake(0, kTopBoxHeight + 30 ) toPoint:CGPointMake(712.0, kTopBoxHeight + 30) atContext:currentContext];
	totalHeight = (kTopBoxHeight) + 60;
	
//============================= Top Box Done ===============================================================================================================================================
	
/*============================= Report Data  ===============================================================*/	
	currentX = kLeftMergin;
	for(NSString *str in self.arrayOfAttribute)
	{
		[self drawString:[str uppercaseString] atRect:CGRectMake(currentX, totalHeight, spaceBetweenCol, 36.0)];
		currentX += spaceBetweenCol;
	}
	totalHeight += 46;
	currentX = kLeftMergin;
// need modify //////
	switch (self.reportTypesTag) 
	{
		case INCOME_REPORT_BY_BUILDING:
			[self incomeReportByBuilding:totalHeight CurrX:currentX MaxHeight:maxHeight Width:spaceBetweenCol];
			break;
		
		case INCOME_REPORT_BY_OWNER:
			[self incomeReportByOwner:totalHeight CurrX:currentX MaxHeight:maxHeight Width:spaceBetweenCol];
			break;
		
		case EXPENSE_REPORT_BY_BUILDING:
			[self expenseReportByBuilding:totalHeight CurrX:currentX MaxHeight:maxHeight Width:spaceBetweenCol];
			break;

		case EXPENSE_REPORT_BY_OWNER:
			[self expenseReportByOwner:totalHeight CurrX:currentX MaxHeight:maxHeight Width:spaceBetweenCol];
			break;
		case TOTAL_FINANCE_BY_BUILDING:
			[self totalFinanceByBuilding:totalHeight CurrX:currentX MaxHeight:maxHeight Width:spaceBetweenCol];
			break;
			
		case TOTAL_FINANCE_BY_OWNER:
			[self totalFinanceByOwner:totalHeight CurrX:currentX MaxHeight:maxHeight Width:spaceBetweenCol];
			break;
			
		case TENANT_PAYMENT_REPORT:
			[self tenantPaymentReport:totalHeight CurrX:currentX MaxHeight:maxHeight Width:spaceBetweenCol];
			break;
			
		case LATE_TENANT_REPORT:
			[self lateTenantReport:totalHeight CurrX:currentX MaxHeight:maxHeight Width:spaceBetweenCol];
			break;
			
		case TENANT_PHONE_LIST:
			[self tenantPhoneList:totalHeight CurrX:currentX MaxHeight:maxHeight Width:spaceBetweenCol];
			break;
			
		case RENT_ROLL:
			[self rentRoll:totalHeight CurrX:currentX MaxHeight:maxHeight Width:spaceBetweenCol];
			break;
	}
		
	UIGraphicsEndPDFContext();
	date = nil; form = nil; format = nil; dateStr = nil;
}

-(BOOL)isDateBetweenReportedDate:(NSString *)date
{
	NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
	[formatter setDateFormat:@"MM/dd/yyyy"];

	NSDate *reportedDate = [formatter dateFromString:date];
	NSDate *reportedFromDate = [formatter dateFromString:self.reportedFrom];
	NSDate *reportedToDate = [formatter dateFromString:self.reportedTo];
	formatter = nil;
	if([reportedDate compare:reportedFromDate] == NSOrderedAscending)
		return NO;
	if([reportedDate compare:reportedToDate] == NSOrderedDescending)
		return NO;
	return YES;
}

#pragma mark -
#pragma mark expenseReportByBuilding

-(void)expenseReportByBuilding:(CGFloat) totalHeight CurrX:(CGFloat)currentX MaxHeight:(CGFloat)maxHeight Width:(CGFloat)spaceBetweenCol
{
	NSArray *arr = nil;
	float total = 0.0;
	
	currentX = kLeftMergin;
	arr = [self.building.expenses allObjects];
	EXPENSES_CATEGOTY expTag = UNKNOWN;
	arr = [Utility sortExpenseByDate:arr];
	NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
	for(Expenses *aObject in arr)
	{
		if(![self isDateBetweenReportedDate:aObject.date]) continue;
		expTag = [Utility expenseCategoryTag:aObject.category];
		
		NSMutableArray *arr = [dict objectForKey:[NSString stringWithFormat:@"%d",expTag]];
		if(!arr)
			arr = [[NSMutableArray alloc] init];
		[arr addObject:aObject];
		[dict setObject:arr forKey:[NSString stringWithFormat:@"%d",expTag]];
	}
	NSArray *arrKey = [dict allKeys];
	for(NSString *key in arrKey)
	{
		NSArray *arrObj = [dict objectForKey:key];
		float catTotal = 0.0;
		for(Expenses *aObject in arrObj)
		{
			catTotal += [[aObject valueForKey:@"amount"] floatValue];
            NSLog(@"catTotal = %.2f",catTotal);
			
			if(totalHeight > maxHeight) 
			{
				UIGraphicsBeginPDFPageWithInfo(CGRectMake(0, 0, kDefaultPageWidth, kDefaultPageHeight), nil);
				totalHeight = kMargin;
			}
			for(int ii = 0; ii < self.noOfCol; ii++ )
			{
				if(ii == self.noOfCol-1)
					[self drawString:[ NSString stringWithFormat:@"$%@",[aObject valueForKey:[self.arrOfTag objectAtIndex:ii]]] atRect:CGRectMake(currentX, totalHeight, spaceBetweenCol, 36.0)];
				else
					[self drawString:[aObject valueForKey:[self.arrOfTag objectAtIndex:ii]] atRect:CGRectMake(currentX, totalHeight, spaceBetweenCol, 36.0)];
				currentX += spaceBetweenCol;
			}
			totalHeight += 46;
			currentX=kLeftMergin;
		}
        total+=catTotal;
		[self drawBoldString:[NSString stringWithFormat:@"Category Total  \t    $%.2f",catTotal ]atRect:CGRectMake(4 * spaceBetweenCol + 40, totalHeight, 2 * spaceBetweenCol, 36.0)];
		totalHeight += 46;
	}
	if(totalHeight > maxHeight) 
	{
		UIGraphicsBeginPDFPageWithInfo(CGRectMake(0, 0, kDefaultPageWidth, kDefaultPageHeight), nil);
		totalHeight = kMargin;
	}
	
	[self drawBoldString:[NSString stringWithFormat:@"Total  \t    $%.2f",total ]atRect:CGRectMake(5 * spaceBetweenCol - 24 , totalHeight, 2 * spaceBetweenCol, 36.0)];
	arr = nil;dict = nil;arrKey = nil;
}

#pragma mark -
#pragma mark expenseReportByOwner

-(void)expenseReportByOwner:(CGFloat)totalHeight CurrX:(CGFloat)currentX MaxHeight:(CGFloat)maxHeight Width:(CGFloat)spaceBetweenCol
{
	NSArray *arr = nil;
	NSPredicate *predicate = [NSPredicate predicateWithFormat:@"self.owner == %@",self.owner];
	
	AppDelegate_iPhone *app = (AppDelegate_iPhone *)[[UIApplication sharedApplication] delegate];
	arr = [CoreDataHelper searchObjectsInContext:ENTITY_KEY_BUILDING :predicate :nil :NO :app.managedObjectContext];
	
	CGFloat total = 0.0;
	
	EXPENSES_CATEGOTY expTag = UNKNOWN;
	for(Building *build in arr)
	{
		NSMutableArray *oArray = [[NSMutableArray alloc] init];
		[oArray addObjectsFromArray:[build.expenses allObjects]];
		oArray = [Utility sortExpenseByDate:oArray];
		NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
		for(Expenses *aObject in oArray)
		{
			if(![self isDateBetweenReportedDate:aObject.date]) continue;
			expTag = [Utility expenseCategoryTag:aObject.category];
			
			NSMutableArray *arr = [dict objectForKey:[NSString stringWithFormat:@"%d",expTag]];
			if(!arr)
				arr = [[NSMutableArray alloc] init];
			[arr addObject:aObject];
			[dict setObject:arr forKey:[NSString stringWithFormat:@"%d",expTag]];
		}
		NSArray *arrKey = [dict allKeys];
		for(NSString *key in arrKey)
		{
			NSArray *arrObj = [dict objectForKey:key];
			float catTotal = 0.0;
			for(Expenses *expense in arrObj)
			{
				NSString *str = nil;
				catTotal += [[expense valueForKey:@"amount"] floatValue];
				
				if(totalHeight > maxHeight) 
				{
					UIGraphicsBeginPDFPageWithInfo(CGRectMake(0, 0, kDefaultPageWidth, kDefaultPageHeight), nil);
					totalHeight = kMargin;
				}
				for(int ii = 0; ii < self.noOfCol; ii++ )
				{
					if(ii == 0 )
						str = [build valueForKey:[self.arrOfTag objectAtIndex:ii]];
					else if(ii == self.noOfCol-1)
						str = [ NSString stringWithFormat:@"$%@",[expense valueForKey:[self.arrOfTag objectAtIndex:ii]]];
					else
						str = [expense valueForKey:[self.arrOfTag objectAtIndex:ii]];
					[self drawString:str atRect:CGRectMake(currentX, totalHeight, spaceBetweenCol, 36.0)];
					currentX += spaceBetweenCol;
				}
				totalHeight += 46;
				currentX=kLeftMergin;
			}
            total += catTotal;
			[self drawBoldString:[NSString stringWithFormat:@"Category Total  \t    $%.2f", catTotal]atRect:CGRectMake(4 * spaceBetweenCol+40 , totalHeight, 2 * spaceBetweenCol, 36.0)];
			totalHeight += 46;
		}
		oArray = nil;dict = nil;arrKey = nil;
	}
	arr = nil;
	if(totalHeight > maxHeight) 
	{
		UIGraphicsBeginPDFPageWithInfo(CGRectMake(0, 0, kDefaultPageWidth, kDefaultPageHeight), nil);
		totalHeight = kMargin;
	}

	[self drawBoldString:[NSString stringWithFormat:@"Total  \t    $%.2f", total]atRect:CGRectMake(5 * spaceBetweenCol-24, totalHeight, 2 * spaceBetweenCol, 36.0)];
	
}

#pragma mark -
#pragma mark incomeReportByBuilding

-(void)incomeReportByBuilding:(CGFloat) totalHeight CurrX:(CGFloat)currentX MaxHeight:(CGFloat)maxHeight Width:(CGFloat)spaceBetweenCol
{
	NSArray *arr = nil;
	NSPredicate *predicate = [NSPredicate predicateWithFormat:@"self.building == %@",self.building];
	
	AppDelegate_iPhone *app = (AppDelegate_iPhone *)[[UIApplication sharedApplication] delegate];
	arr = [CoreDataHelper searchObjectsInContext:ENTITY_KEY_TENANT :predicate :nil :NO :app.managedObjectContext];
	CGFloat total = 0.0;
    
	for(Tenant *ten in arr)
	{
		NSArray *tenArray = [ten.payments allObjects];
		for(Payment *payem in tenArray)
		{
			if(![self isDateBetweenReportedDate:payem.datePaid]) continue;
			NSString *str = nil;
			total += [[payem valueForKey:@"amount"] floatValue];
		
			if(totalHeight > maxHeight) 
			{
				UIGraphicsBeginPDFPageWithInfo(CGRectMake(0, 0, kDefaultPageWidth, kDefaultPageHeight), nil);
				totalHeight = kMargin;
			}
			for(int ii = 0; ii < self.noOfCol; ii++ )
			{
				if(ii == 3 || ii == 4 )
					str = [ten valueForKey:[self.arrOfTag objectAtIndex:ii]];
				else
					str = [payem valueForKey:[self.arrOfTag objectAtIndex:ii]];
				[self drawString:str atRect:CGRectMake(currentX, totalHeight, spaceBetweenCol, 36.0)];
				currentX += spaceBetweenCol;
			}
			totalHeight += 46;
			currentX=kLeftMergin;
		}
		tenArray = nil;
	}
	if(totalHeight > maxHeight) 
	{
		UIGraphicsBeginPDFPageWithInfo(CGRectMake(0, 0, kDefaultPageWidth, kDefaultPageHeight), nil);
		totalHeight = kMargin;
	}
	[self drawString:[NSString stringWithFormat:@"Total       $%.2f", total ]atRect:CGRectMake(5 * spaceBetweenCol-50, totalHeight, 2 * spaceBetweenCol, 36.0)];
	totalHeight+=46;
	arr = nil;
}

#pragma mark -
#pragma mark totalFinanceByBuilding

-(void)totalFinanceByBuilding:(CGFloat) totalHeight CurrX:(CGFloat)currentX MaxHeight:(CGFloat)maxHeight Width:(CGFloat)spaceBetweenCol
{
	NSArray *arr = nil;
	NSPredicate *predicate = [NSPredicate predicateWithFormat:@"self.building == %@",self.building];
	
	AppDelegate_iPhone *app = (AppDelegate_iPhone *)[[UIApplication sharedApplication] delegate];
	arr = [CoreDataHelper searchObjectsInContext:ENTITY_KEY_TENANT :predicate :nil :NO :app.managedObjectContext];
	
	NSArray *arrOfMonths = [NSArray arrayWithObjects:@"January",@"February",@"March",
							@"April", @"May", @"June", @"july", @"August", @"September",
							@"October", @"November", @"December",nil];
	NSString *str = nil;
	CGFloat income = 0.0;
	CGFloat expens = 0.0;
	CGFloat gTotal = 0.0;
	
	CGFloat coloumnTotalInc = 0.0;
	CGFloat coloumnTotalExp = 0.0;
	CGFloat colGtotal = 0.0;
	CGFloat total = 0.0;
 	for(int ii = 0; ii < 13; ii++)
	{		
		gTotal = 0;
		if(totalHeight > maxHeight) 
		{
			UIGraphicsBeginPDFPageWithInfo(CGRectMake(0, 0, kDefaultPageWidth, kDefaultPageHeight), nil);
			totalHeight = kMargin;
		}
		
		for(int jj = 0; jj < self.noOfCol; jj++ )
		{
			
			if(jj == 0)
			{
				if(ii == 12)
				{
					[self drawString:@"Coloumn Total : " atRect:CGRectMake(currentX, totalHeight, spaceBetweenCol, 36.0)];
					currentX += spaceBetweenCol;
					continue;
				}
				str = [arrOfMonths objectAtIndex:ii];
			}
			else if(jj == 1)
			{
				if(ii == 12)
				{
					[self drawString:[NSString stringWithFormat:@"%.2f",coloumnTotalInc] atRect:CGRectMake(currentX, totalHeight, spaceBetweenCol, 36.0)];
					currentX += spaceBetweenCol;
					continue;
				}
				for(Tenant *ten in arr)
				{
					income += [self incomeFromPaymentForMonth:[NSString stringWithFormat:@"%d",ii+1] ForTenant:ten];
				}
				
				str = [NSString stringWithFormat:@"%.2f",income];
			}
			else if(jj == 2)
			{
				if(ii == 12)
				{
					[self drawString:[NSString stringWithFormat:@"%.2f",coloumnTotalExp] atRect:CGRectMake(currentX, totalHeight, spaceBetweenCol, 36.0)];
					currentX += spaceBetweenCol;
					continue;
				}
				expens = [self expenseFromExpensesForMonth:[NSString stringWithFormat:@"%d",ii+1] ForBuilding:self.building];
				str = [NSString stringWithFormat:@"%.2f",expens];
			}
			else 
			{
				if(ii == 12)
				{
					[self drawString:[NSString stringWithFormat:@"%.2f",colGtotal] atRect:CGRectMake(currentX, totalHeight, spaceBetweenCol, 36.0)];
					currentX += spaceBetweenCol;
					continue;
				}
				gTotal = income - expens;
				colGtotal += gTotal;
				str = [NSString stringWithFormat:@"%.2f",gTotal];
			}

			[self drawString:str atRect:CGRectMake(currentX, totalHeight, spaceBetweenCol, 36.0)];
			currentX += spaceBetweenCol;
			total = gTotal;
		}
		
		totalHeight += 46;
		currentX=kLeftMergin;
		if(ii == 12) break;
		coloumnTotalInc += income;
		coloumnTotalExp += expens;
		income = 0.0;
	}
	if(totalHeight > maxHeight) 
	{
		UIGraphicsBeginPDFPageWithInfo(CGRectMake(0, 0, kDefaultPageWidth, kDefaultPageHeight), nil);
		totalHeight = kMargin;
	}
	
	[self drawString:[NSString stringWithFormat:@"Total       $%.2f", colGtotal ]atRect:CGRectMake(2 * spaceBetweenCol, totalHeight, 2 * spaceBetweenCol, 36.0)];
}

-(CGFloat) incomeFromPaymentForMonth:(NSString *)mnth ForTenant:(Tenant *)ten
{
    float totalPayment = 0.0;
	if([mnth length] == 1)
		mnth = [NSString stringWithFormat:@"0%@",mnth];
	NSArray *arrOfPayments = [ten.payments allObjects];
    NSString *str = @"";
	
	for(Payment *payment in arrOfPayments)
	{
		if(![self isDateBetweenReportedDate:payment.datePaid]) continue;
		str = [payment.datePaid substringToIndex:2];
		
		if([str isEqualToString:mnth])
		{
			totalPayment += [payment.amount floatValue];
		}
	}
	arrOfPayments = nil;str = nil;
	return totalPayment;
}

-(CGFloat) expenseFromExpensesForMonth:(NSString *)mnth ForBuilding:(Building *)build
{
    float totalExpense = 0.0;
	if([mnth length] == 1)
		mnth = [NSString stringWithFormat:@"0%@",mnth];
	NSArray *arrOfExpenses = [build.expenses allObjects];
	NSString *str = @"";
	for(Expenses *expen in arrOfExpenses)
	{
		if(![self isDateBetweenReportedDate:expen.date]) continue;
		
		str = [expen.date substringToIndex:2];
		if([str isEqualToString:mnth])
		{
			totalExpense += [expen.amount floatValue];
		}
	}
	arrOfExpenses = nil;str = nil;
	return totalExpense;
}

#pragma mark -
#pragma mark totalFinanceByOwner

-(void)totalFinanceByOwner:(CGFloat) totalHeight CurrX:(CGFloat)currentX MaxHeight:(CGFloat)maxHeight Width:(CGFloat)spaceBetweenCol
{
	NSArray *arr = nil;
	NSMutableArray *arrOfTenants = [[NSMutableArray alloc]init];
	NSPredicate *predicate = [NSPredicate predicateWithFormat:@"self.owner == %@",self.owner];
	
	AppDelegate_iPhone *app = (AppDelegate_iPhone *)[[UIApplication sharedApplication] delegate];
	arr = [CoreDataHelper searchObjectsInContext:ENTITY_KEY_BUILDING :predicate :nil :NO :app.managedObjectContext];
	
	for(Building *bb in arr)
	{
		predicate = [NSPredicate predicateWithFormat:@"self.building == %@",bb];
		[arrOfTenants addObjectsFromArray:[CoreDataHelper searchObjectsInContext:ENTITY_KEY_TENANT :predicate :nil :NO :app.managedObjectContext]];
	}
	
	predicate = nil;
	
	NSArray *arrOfMonths = [NSArray arrayWithObjects:@"January",@"February",@"March",
							@"April", @"May", @"June", @"july", @"August", @"September",
							@"October", @"November", @"December",nil];
	NSString *str = nil;
	CGFloat income = 0.0;
	CGFloat expens = 0.0;
	CGFloat gTotal = 0.0;
	
	CGFloat coloumnTotalInc = 0.0;
	CGFloat coloumnTotalExp = 0.0;
	CGFloat colGtotal = 0.0;
	CGFloat total = 0.0;
	
 	for(int ii = 0; ii < 13; ii++)
	{
		
		gTotal = 0;
		if(totalHeight > maxHeight) 
		{
			UIGraphicsBeginPDFPageWithInfo(CGRectMake(0, 0, kDefaultPageWidth, kDefaultPageHeight), nil);
			totalHeight = kMargin;
		}
		for(int jj = 0; jj < self.noOfCol; jj++ )
		{
			if(jj == 0)
			{
				if(ii == 12)
				{
					[self drawString:@"Column Total : " atRect:CGRectMake(currentX, totalHeight, spaceBetweenCol, 36.0)];
					currentX += spaceBetweenCol;
					continue;
				}
				str = [arrOfMonths objectAtIndex:ii];
			}
			else if(jj == 1)
			{
				if(ii == 12)
				{
					[self drawString:[NSString stringWithFormat:@"%.2f",coloumnTotalInc] atRect:CGRectMake(currentX, totalHeight, spaceBetweenCol, 36.0)];
					currentX += spaceBetweenCol;
					continue;
				}
				for(Tenant *tena in arrOfTenants)
					income += [self incomeFromPaymentForMonth:[NSString stringWithFormat:@"%d",ii+1] ForTenant:tena];
				str = [NSString stringWithFormat:@"%.2f",income];
			}
			else if(jj == 2)
			{
				if(ii == 12)
				{
					[self drawString:[NSString stringWithFormat:@"%.2f",coloumnTotalExp] atRect:CGRectMake(currentX, totalHeight, spaceBetweenCol, 36.0)];
					currentX += spaceBetweenCol;
					continue;
				}
				for(Building *build in arr)
					expens += [self expenseFromExpensesForMonth:[NSString stringWithFormat:@"%d",ii+1] ForBuilding:build];
				str = [NSString stringWithFormat:@"%.2f",expens];
			}
			else 
			{
				if(ii == 12)
				{
					[self drawString:[NSString stringWithFormat:@"%.2f",colGtotal] atRect:CGRectMake(currentX, totalHeight, spaceBetweenCol, 36.0)];
					currentX += spaceBetweenCol;
					continue;
				}
				gTotal = income - expens;
				colGtotal += gTotal;
				str = [NSString stringWithFormat:@"%.2f",gTotal];
			}
			
			[self drawString:str atRect:CGRectMake(currentX, totalHeight, spaceBetweenCol, 36.0)];
			currentX += spaceBetweenCol;
			total = gTotal;
		}
		totalHeight += 46;
		currentX=kLeftMergin;
        
		if(ii == 12) break;
		coloumnTotalInc += income;
		coloumnTotalExp += expens;
		income = 0.0;
        expens = 0.0;
	}
	if(totalHeight > maxHeight) 
	{
		UIGraphicsBeginPDFPageWithInfo(CGRectMake(0, 0, kDefaultPageWidth, kDefaultPageHeight), nil);
		totalHeight = kMargin;
	}
    
	[self drawString:[NSString stringWithFormat:@"Total       $%.2f", colGtotal]atRect:CGRectMake(2 * spaceBetweenCol, totalHeight, 2 * spaceBetweenCol, 36.0)];
}

#pragma mark -
#pragma mark incomeReportByOwner

-(void)incomeReportByOwner:(CGFloat) totalHeight CurrX:(CGFloat)currentX MaxHeight:(CGFloat)maxHeight Width:(CGFloat)spaceBetweenCol
{
	NSArray *arr = nil;
	NSPredicate *predicate = [NSPredicate predicateWithFormat:@"self.owner == %@",self.owner];
	CGFloat total = 0.0;
	AppDelegate_iPhone *app = (AppDelegate_iPhone *)[[UIApplication sharedApplication] delegate];
	arr = [CoreDataHelper searchObjectsInContext:ENTITY_KEY_BUILDING :predicate :nil :NO :app.managedObjectContext];
    for(Building *build in arr)
    {
        float subTotal = 0.0;
        predicate = [NSPredicate predicateWithFormat:@"self.building == %@",build];
        arr = [CoreDataHelper searchObjectsInContext:ENTITY_KEY_TENANT :predicate :nil :NO :app.managedObjectContext];
	
        for(Tenant *ten in arr)
        {
            NSArray *array = [ten.payments allObjects];
	
            for(Payment *payem in array)
            {
                if(![self isDateBetweenReportedDate:payem.datePaid]) continue;
                NSString *str = nil;
                subTotal += [[payem valueForKey:@"amount"] floatValue];
                if(totalHeight > maxHeight) 
                {
                    UIGraphicsBeginPDFPageWithInfo(CGRectMake(0, 0, kDefaultPageWidth, kDefaultPageHeight), nil);
                    totalHeight = kMargin;
                }
                for(int ii = 0; ii < self.noOfCol; ii++ )
                {
                    if(ii == 0)
                        str = [build valueForKey:[self.arrOfTag objectAtIndex:ii]];
                    else if(ii == 4 || ii == 5 )
                        str = [ten valueForKey:[self.arrOfTag objectAtIndex:ii]];
                    else
                        str = [payem valueForKey:[self.arrOfTag objectAtIndex:ii]];
                    [self drawString:str atRect:CGRectMake(currentX, totalHeight, spaceBetweenCol, 36.0)];
                    currentX += spaceBetweenCol;
                }
                totalHeight += 46;
                currentX=kLeftMergin;
            }
            array = nil;
        }
        if(totalHeight > maxHeight) 
        {
            UIGraphicsBeginPDFPageWithInfo(CGRectMake(0, 0, kDefaultPageWidth, kDefaultPageHeight), nil);
            totalHeight = kMargin;
        }
    
        [self drawString:[NSString stringWithFormat:@"Sub Total     $%.2f", subTotal ] atRect:CGRectMake(6 * spaceBetweenCol-50, totalHeight, 2 * spaceBetweenCol, 36.0)];
        totalHeight+=46;
        total+=subTotal;
        
    }
    
	[self drawString:[NSString stringWithFormat:@"Total       $%.2f", total ]atRect:CGRectMake(6 * spaceBetweenCol-50, totalHeight, 2 * spaceBetweenCol, 36.0)];
}


#pragma mark -
#pragma mark lateTenantReport

-(void)lateTenantReport:(CGFloat) totalHeight CurrX:(CGFloat)currentX MaxHeight:(CGFloat)maxHeight Width:(CGFloat)spaceBetweenCol
{
	AppDelegate_iPhone *app = (AppDelegate_iPhone *)[[UIApplication sharedApplication] delegate];
	NSMutableArray *arr = [CoreDataHelper getObjectsFromContext:ENTITY_KEY_TENANT :nil :NO :app.managedObjectContext];
	
	for(Tenant *aObject in arr)
	{
		if([aObject.moveOut boolValue]) continue;
			
		BOOL dueAmt = [Utility isDueForTenant:aObject];
		if(!dueAmt) continue;
		if(totalHeight > maxHeight) 
		{
			UIGraphicsBeginPDFPageWithInfo(CGRectMake(0, 0, kDefaultPageWidth, kDefaultPageHeight), nil);
			totalHeight = kMargin;
		}
		for(int ii = 0; ii < self.noOfCol; ii++)
		{
			//if(ii < self.noOfCol-1)
			[self drawString:[aObject valueForKey:[self.arrOfTag objectAtIndex:ii]] atRect:CGRectMake(currentX, totalHeight, spaceBetweenCol, 36.0)];
			/*else 
				[self drawString:[NSString stringWithFormat:@"%d",dueAmt] atRect:CGRectMake(currentX, totalHeight, spaceBetweenCol, 36.0)];*/
			currentX += spaceBetweenCol;
		}
		totalHeight += 46;
		currentX=kLeftMergin;
	}
	arr = nil;
	app = nil;
}

#pragma mark -
#pragma mark tenantPaymentReport

-(void)tenantPaymentReport:(CGFloat) totalHeight CurrX:(CGFloat)currentX MaxHeight:(CGFloat)maxHeight Width:(CGFloat)spaceBetweenCol
{
	NSString *str = @"";
	NSArray *arr =  [self.tenant.payments allObjects];
	for(Payment *aObject in arr)
	{
		if(![self isDateBetweenReportedDate:aObject.datePaid]) continue;
		if(totalHeight > maxHeight) 
		{
			UIGraphicsBeginPDFPageWithInfo(CGRectMake(0, 0, kDefaultPageWidth, kDefaultPageHeight), nil);
			totalHeight = kMargin;
		}
		for(int ii = 0; ii < self.noOfCol; ii++)
		{
			if(ii <= 1)
				str = [self.tenant valueForKey:[self.arrOfTag objectAtIndex:ii]];
			else
				str = [aObject valueForKey:[self.arrOfTag objectAtIndex:ii]];
			[self drawString:str atRect:CGRectMake(currentX, totalHeight, spaceBetweenCol, 36.0)];
			currentX += spaceBetweenCol;
		}
		totalHeight += 46;
		currentX=kLeftMergin;
	}
	arr = nil;
}

#pragma mark -
#pragma mark tenantPhoneList

-(void)tenantPhoneList:(CGFloat) totalHeight CurrX:(CGFloat)currentX MaxHeight:(CGFloat)maxHeight Width:(CGFloat)spaceBetweenCol
{
	AppDelegate_iPhone *app = (AppDelegate_iPhone *)[[UIApplication sharedApplication] delegate];
	NSMutableArray *arr = [CoreDataHelper getObjectsFromContext:ENTITY_KEY_TENANT :nil :NO :app.managedObjectContext];
	for(Tenant *aObject in arr)
	{
		if(totalHeight > maxHeight) 
		{
			UIGraphicsBeginPDFPageWithInfo(CGRectMake(0, 0, kDefaultPageWidth, kDefaultPageHeight), nil);
			totalHeight = kMargin;
		}
		for(int ii = 0; ii < self.noOfCol; ii++)
		{
			[self drawString:[aObject valueForKey:[self.arrOfTag objectAtIndex:ii]] atRect:CGRectMake(currentX, totalHeight, spaceBetweenCol, 36.0)];
			currentX += spaceBetweenCol;
		}
		totalHeight += 46;
		currentX=kLeftMergin;
	}
	arr = nil;
}

#pragma mark -
#pragma mark rentRoll

-(void)rentRoll:(CGFloat) totalHeight CurrX:(CGFloat)currentX MaxHeight:(CGFloat)maxHeight Width:(CGFloat)spaceBetweenCol
{
    float total = 0.0;
    
	AppDelegate_iPhone *app = (AppDelegate_iPhone *)[[UIApplication sharedApplication] delegate];
	NSMutableArray *arr = [CoreDataHelper getObjectsFromContext:ENTITY_KEY_TENANT :nil :NO :app.managedObjectContext];
	
	for(Tenant *tenant in arr)
	{
		NSString *str = nil;
        float gtotal = 0.0;
		NSArray *paymentArr = [tenant.payments allObjects];
		for(Payment *paym in paymentArr)
		{
            if(![self isDateBetweenReportedDate:paym.datePaid]) continue;
                gtotal += [[paym valueForKey:@"amount"] floatValue];
			if(totalHeight > maxHeight) 
			{
				UIGraphicsBeginPDFPageWithInfo(CGRectMake(0, 0, kDefaultPageWidth, kDefaultPageHeight), nil);
				totalHeight = kMargin;
			}
		
			for(int ii = 0; ii < self.noOfCol; ii++ )
			{
				if(ii <= 1)
					str = [tenant valueForKey:[self.arrOfTag objectAtIndex:ii]];
				else
					str = [paym valueForKey:[self.arrOfTag objectAtIndex:ii]];
				[self drawString:str atRect:CGRectMake(currentX, totalHeight, spaceBetweenCol, 36.0)];
				currentX += spaceBetweenCol;
			}
			totalHeight += 46;
			currentX=kLeftMergin;
		}
		if(totalHeight > maxHeight) 
		{
			UIGraphicsBeginPDFPageWithInfo(CGRectMake(0, 0, kDefaultPageWidth, kDefaultPageHeight), nil);
			totalHeight = kMargin;
		}
        [self drawString:[NSString stringWithFormat:@"Total       $%.2f", gtotal ]atRect:CGRectMake(5 * spaceBetweenCol-24, totalHeight, 2 * spaceBetweenCol, 36.0)];
        totalHeight += 46;
        currentX=kLeftMergin;
        total +=gtotal;
	}
    
    if(totalHeight > maxHeight) 
	{
		UIGraphicsBeginPDFPageWithInfo(CGRectMake(0, 0, kDefaultPageWidth, kDefaultPageHeight), nil);
		totalHeight = kMargin;
	}
	
	[self drawBoldString:[NSString stringWithFormat:@"Total  \t    $%.2f",total ]atRect:CGRectMake(5 * spaceBetweenCol - 24 , totalHeight, 2 * spaceBetweenCol, 36.0)];
}

-(void)dealloc
{
	self.setting = nil;
	self.reportedFor = nil;
	self.reportedBy = nil;
	self.reportedFrom = nil;
	self.reportedTo = nil;
	self.arrayOfAttribute = nil;
	self.arrOfTag = nil;
	
	[super dealloc];
}

@end
