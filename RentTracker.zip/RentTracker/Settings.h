//
//  Settings.h
//  RentTracker
//
//  Created by Manas Kumar Mandal on 18/04/12.
//  Copyright (c) 2012 ObjectSol Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface Settings : NSManagedObject

@property (nonatomic, retain) NSData * logo;
@property (nonatomic, retain) NSString * country;
@property (nonatomic, retain) NSString * street;
@property (nonatomic, retain) NSString * town;
@property (nonatomic, retain) NSString * compName;
@property (nonatomic, retain) NSString * propertyExperts;

@end
