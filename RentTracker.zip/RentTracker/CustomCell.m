//
//  untitled.m
//  RentTracker
//
//  Created by ASHIM SAMANTA on 02/03/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import "CustomCell.h"
#import "Constant.h"

@implementation CustomCell

@synthesize label = _label;
@synthesize textField = _textField;
@synthesize isReadOnly;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier ReadOnly:(BOOL)readOnly
{
	if(self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])
	{
		if(!labFont)
		{
			if(ISIPHONE)
				labFont = [UIFont systemFontOfSize:12];
			else
				labFont = [UIFont systemFontOfSize:17];
			
		}
		CGRect frame;
		if(ISIPHONE)
			frame = CGRectMake(5, 12, 100, 20);
		else
			frame = CGRectMake(5, 12, 200, 20);
		self.label = [[[UILabel alloc] initWithFrame:frame] autorelease];
		self.label.backgroundColor = [UIColor clearColor];
		[self.label setNumberOfLines:0];
		self.label.font = labFont;
		self.label.adjustsFontSizeToFitWidth = YES;
		
		if(ISIPHONE)			
			frame = CGRectMake(115, 12, 170, 20);
		else
			frame = CGRectMake(205, 12, 460, 20);
		
		self.textField = [[[UITextField alloc] initWithFrame:frame] autorelease];
		self.textField.backgroundColor = [UIColor clearColor];
		self.textField.borderStyle = UITextBorderStyleNone;
		self.textField.userInteractionEnabled = !readOnly;
		self.textField.autocorrectionType = UITextAutocorrectionTypeNo;
		[self.contentView addSubview:self.label];
		[self.contentView addSubview:self.textField];
		labFont = nil;
	}
	return self;
}
- (void)textFieldDidEndEditing:(UITextField *)textField
{
	NSLog(@"textField = %@", textField.text);
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code.
}
*/

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
	[super setSelected:NO animated:animated];
}


@end
