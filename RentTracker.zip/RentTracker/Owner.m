//
//  Owner.m
//  RentTracker
//
//  Created by Manas Kumar Mandal on 18/04/12.
//  Copyright (c) 2012 ObjectSol Technologies. All rights reserved.
//

#import "Owner.h"


@implementation Owner

@dynamic state;
@dynamic first;
@dynamic prefix;
@dynamic last;
@dynamic mobile;
@dynamic work_phone;
@dynamic address;
@dynamic image;
@dynamic city;
@dynamic home_phone;
@dynamic postal_code;
@dynamic email;

@end
