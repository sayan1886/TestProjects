//
//  RTBuildingAddViewController.h
//  RentTracker
//
//  Created by ASHIM SAMANTA on 29/02/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ImagePicker.h"
#import "AppDelegate_iPhone.h"

@interface RTBuildingAddViewController : UIViewController <UITableViewDelegate, 
											UITableViewDataSource, UITextFieldDelegate,
											CaptureImage, UIPickerViewDataSource, UIPickerViewDelegate>
{
	UITableView *rtBuildingTableView_;
	NSMutableDictionary *tempDict_;
	UIButton * btn;
	
	UITextField *tempTextField;
	UIPickerView *pickerView;
	
	NSMutableArray *array_;
	NSMutableArray *ownerArray_;
	
	UIView *pView;
	
	NSInteger selectedIndex;
	UITextField *txtFldOwnerName_;
	UITextField *txtFldAddress_;
	
	BOOL isPickerVisible;
	UITextField *txtFld;
}

@property (nonatomic, retain) IBOutlet UITableView *rtBuildingTableView;
@property (nonatomic, retain) NSMutableDictionary *tempDict;

@property (nonatomic, retain) NSMutableArray *array;
@property (nonatomic, retain) NSMutableArray *ownerArray;

@property (nonatomic, retain) UITextField *txtFldOwnerName;
@property (nonatomic, retain) UITextField *txtFldAddress;
@property (nonatomic, retain) UIButton * btn;

-(void)fetchData;
@end
