//
//  RTBuildingViewController.m
//  RentTracker
//
//  Created by ASHIM SAMANTA on 29/02/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import "RTBuildingViewController.h"
#import "Constant.h"
#import "RTBuildingAddViewController.h"
#import "RTBuildingEditViewController.h"
#import "Utility.h"
#import "AppDelegate_iPhone.h"
#import "CoreDataHelper.h"
#import "Building.h"
#import "Owner.h"


@implementation RTBuildingViewController

@synthesize rtBuildingTableView = rtBuildingTableView_;
@synthesize searchText = searchText_;
@synthesize array = array_;
@synthesize resultdict = resultdict_;
@synthesize arr = arr_;

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
		self.title = @"Building Address";
		UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(add:)];
		self.navigationItem.rightBarButtonItem = item;
		[item release];
    }
    return self;
}

-(void)add:(id)sender
{
	AppDelegate_iPhone *app = (AppDelegate_iPhone *)[[UIApplication sharedApplication]delegate];
	NSMutableArray *arrResult = [CoreDataHelper getObjectsFromContext:ENTITY_KEY_OWNER :nil :NO :app.managedObjectContext];
	if(!arrResult || [arrResult count] == 0)
	{
		[Utility showAlertViewWithTitle:TITLE Message:MESSAGE_NO_OWNER CancelTitle:@"Ok"];
		return ;
	}
	RTBuildingAddViewController *viewController = [[RTBuildingAddViewController alloc] initWithNibName:@"RTBuildingAddViewController" bundle:nil];
	[self.navigationController pushViewController:viewController animated:YES];
	[viewController release];viewController = nil;
}

-(void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	[self getValueFromContext];
	[self.rtBuildingTableView reloadData];
}

-(void)getValueFromContext
{
	AppDelegate_iPhone *app = (AppDelegate_iPhone *)[[UIApplication sharedApplication]delegate];
	self.array = [CoreDataHelper getObjectsFromContext:ENTITY_KEY_BUILDING :@"address" :YES :app.managedObjectContext];
	
	self.resultdict = [Utility arrangeList:self.array sortKey:@"address"];
	self.arr = [self.resultdict allKeys];
	self.arr = [self.arr sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	self.searchText = [[NSMutableArray alloc] init];
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
	AppDelegate_iPhone *app = (AppDelegate_iPhone *)[[UIApplication sharedApplication] delegate];
	NSArray *arrTodel = [self.resultdict allKeys];
	NSString *val = [arrTodel objectAtIndex:indexPath.section];
	arrTodel = [self.resultdict objectForKey:val];
	Building *build = [arrTodel objectAtIndex:indexPath.row];
	[app.managedObjectContext deleteObject:build];
	[app saveContext];
	
	[self getValueFromContext];
	[tableView reloadData];
}
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
	return YES;
}
- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return UITableViewCellEditingStyleDelete;	
}


- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
	return HEIGHT_FOR_HEADER;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
	if(![tableView isEqual:self.rtBuildingTableView]) return nil;
	
	UIView *header = [[[UIView alloc]initWithFrame:CONTACT_HEADER_FRAME] autorelease];
	header.backgroundColor = [UIColor colorWithPatternImage:[[UIImage imageNamed:CONTACT_HEADER_IMAGE] stretchableImageWithLeftCapWidth:0 topCapHeight:32]];
	
	UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, 6, 20, 20)];
	
	if([tableView isEqual:self.rtBuildingTableView])
	{
		label.text = [self.arr objectAtIndex:section];
	}
	
	label.backgroundColor = [UIColor clearColor];
	label.textColor = [UIColor whiteColor];
	
	[header addSubview:label];
	
	[label release];
	return header;
}

// return list of section titles to display in section index view (e.g. "ABCD...Z#")
-(NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView
{
	if(![tableView isEqual:self.rtBuildingTableView]) return nil;
	NSMutableArray *toBeReturned = [[NSMutableArray alloc]init];
    for(char c = 'A'; c <= 'Z'; c++) [toBeReturned addObject:[NSString stringWithFormat:@"%c",c]];
    return [toBeReturned autorelease];
}

// tell table which section corresponds to section title/index (e.g. "B",1))

-(NSInteger)tableView:(UITableView *)tableView sectionForSectionIndexTitle:(NSString *)title atIndex:(NSInteger)index
{
	NSLog(@"index = %d", index);
	return index;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	if([tableView isEqual:self.rtBuildingTableView])
	{
		NSArray *arrRes = [self.resultdict objectForKey:[self.arr objectAtIndex:section]];
		return [arrRes count];
	}
	return [self.searchText count];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	if([tableView isEqual:self.rtBuildingTableView])
	{
		return [self.arr count];
	}
	return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	static NSString *cellID = @"cellID";
	NSString *text = @"";
	if([tableView isEqual:self.rtBuildingTableView]) 
	{
		NSString *val = [self.arr objectAtIndex:indexPath.section];
		NSArray *tempArr = [self.resultdict objectForKey:val];
		Building *build = [tempArr objectAtIndex:indexPath.row];
		text = build.address;
		tempArr = nil;
	}
	else 
	{
		text = [[self.searchText objectAtIndex:indexPath.row] valueForKey:@"address"];
	}	
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID] ;
	if(!cell)
	{
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID] autorelease];
		
		cell.textLabel.text = text;
	}
	else
		cell.textLabel.text = text;
	return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	
	Building *building = nil;
	if([tableView isEqual:self.rtBuildingTableView])
	{
		NSString *val = [self.arr objectAtIndex:indexPath.section];
		NSArray *tempArr = [self.resultdict objectForKey:val];
		building = [tempArr objectAtIndex:indexPath.row];
		tempArr = nil;
	}
	else 
	{
		building = [self.searchText objectAtIndex:indexPath.row];
	}
	
	RTBuildingEditViewController *viewController = [[RTBuildingEditViewController alloc] initWithNibName:@"RTBuildingEditViewController" bundle:nil];
	viewController.building = building;
	[self.navigationController pushViewController:viewController animated:YES];
	[viewController release];viewController = nil;
}


#pragma mark -
#pragma mark SEARCH

- (BOOL)searchDisplayController:(UISearchDisplayController *)controller shouldReloadTableForSearchString:(NSString *)searchString
{    
    [self.searchText removeAllObjects];
    
    for (Building *building in self.array)
    {
		NSString *aStr = building.address;
		if ([[aStr lowercaseString] rangeOfString:[searchString lowercaseString]].location != NSNotFound)
            [self.searchText addObject:building];
    }
	
    [controller.searchResultsTableView reloadData];
    
    return NO;
}

- (void)searchDisplayControllerWillBeginSearch:(UISearchDisplayController *)controller
{
    self.rtBuildingTableView.hidden = YES;
}

- (void)searchDisplayControllerDidEndSearch:(UISearchDisplayController *)controller
{
    self.rtBuildingTableView.hidden = NO;
}
- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
	
 	self.rtBuildingTableView = nil;
	self.searchText = nil;
 	self.array = nil;
	self.resultdict = nil;
	self.arr = nil;
	
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	
	self.rtBuildingTableView = nil;
	self.searchText = nil;
 	self.array = nil;
	self.resultdict = nil;
	self.arr = nil;
	
    [super dealloc];
}


@end
