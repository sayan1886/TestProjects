//
//  Expenses.h
//  RentTracker
//
//  Created by Manas Kumar Mandal on 18/04/12.
//  Copyright (c) 2012 ObjectSol Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class Building;

@interface Expenses : NSManagedObject

@property (nonatomic, retain) NSString * amount;
@property (nonatomic, retain) NSString * category;
@property (nonatomic, retain) NSString * note;
@property (nonatomic, retain) NSString * descriptions;
@property (nonatomic, retain) NSString * date;
@property (nonatomic, retain) NSString * payee;
@property (nonatomic, retain) NSString * checkNo;
@property (nonatomic, retain) Building *building;

@end
