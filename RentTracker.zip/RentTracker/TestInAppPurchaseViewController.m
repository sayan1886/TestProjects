//
//  TestInAppPurchaseViewController.m
//  TestInAppPurchase
//
//  Created by ASHIM SAMANTA on 09/02/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import "TestInAppPurchaseViewController.h"
#import "TestIAPHelper.h"
#import <StoreKit/StoreKit.h>
#import "Utility.h"
#import "Constant.h"


@implementation TestInAppPurchaseViewController
@synthesize hud = _hud;

-(void)showHud
{
    self.hud = [MBProgressHUD showHUDAddedTo:[UIApplication sharedApplication].keyWindow animated:YES];
    self.hud.labelText = @"Loading...";
}

-(void)hideHud
{
    [self.hud removeFromSuperview];
    self.hud = nil;
}

-(void)viewWillAppear:(BOOL)animated
{
	self.tableView.hidden = NO;
	[super viewWillAppear:animated];
	
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(productsLoaded:) name:kProductsLoadedNotification object:nil];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(productPurchased:) name:kProductPurchasedNotification object:nil];
	[[NSNotificationCenter defaultCenter] addObserver:self selector: @selector(productPurchaseFailed:) name:kProductPurchaseFailedNotification object: nil];
    [self showHud];
	
    if ([Utility isNetworkAvailable]) 
	{    
		if ([TestIAPHelper sharedHelper].products == nil) 
		{			
			[[TestIAPHelper sharedHelper] requestProducts];
			
			[self performSelector:@selector(timeout:) withObject:nil afterDelay:30.0];			
		}
        else
        {
            [self hideHud];
        }
	} 
	else 
	{        
        [self hideHud];
        UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"Error!" 
                                                         message:@"Connection failure. Please try again later."
                                                         delegate:nil 
                                               cancelButtonTitle:nil 
                                               otherButtonTitles:@"OK", nil] autorelease];
		
        [alert show];     
	}
}

-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)productPurchased:(NSNotification *)notification 
{
    [NSObject cancelPreviousPerformRequestsWithTarget:self];
    [self hideHud];
    NSString *productIdentifier = (NSString *) notification.object;
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSInteger totalProduct = [userDefaults integerForKey:PURCHASED_TENANT];
    NSLog(@"total Tenant Purchased = %d", totalProduct);
    if([productIdentifier isEqualToString:ONE_TENANT_PROCUCT_ID])
    {
        totalProduct++;
    }
    else if([productIdentifier isEqualToString:TEN_TENANT_PRODUCTID])
    {
        totalProduct+=10;
    }
    else if([productIdentifier isEqualToString:FIFTY_TENANT_PRODUCTID])
    {
        totalProduct+=50;
    }
    
    [userDefaults setInteger:totalProduct forKey:PURCHASED_TENANT];
	[userDefaults synchronize];
    
    NSLog(@"Alert.");
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Inapp" message:@"In Purchased Successfull" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
    [alert show];
    alert = nil;
        
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)productPurchaseFailed:(NSNotification *)notification {
	
    [NSObject cancelPreviousPerformRequestsWithTarget:self];
    [self hideHud];
	
    SKPaymentTransaction * transaction = (SKPaymentTransaction *) notification.object;    
    if (transaction.error.code != SKErrorPaymentCancelled) {    
        UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"Error!" 
                                                         message:transaction.error.localizedDescription 
                                                        delegate:nil 
                                               cancelButtonTitle:nil 
                                               otherButtonTitles:@"OK", nil] autorelease];
		
        [alert show];
    }
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithTitle:@"Usage" style:UIBarButtonItemStylePlain target:self action:@selector(seeUsage:)];
    [self.navigationItem setRightBarButtonItem:item animated:YES];
    [item release]; item = nil;
    
	self.title = @"In App Purchase";
    
}

-(void)seeUsage:(id)sender
{
    NSUserDefaults *standardDefaults = [NSUserDefaults standardUserDefaults];
    NSInteger totalNoOfTenantPurchased = [standardDefaults integerForKey:PURCHASED_TENANT];
    NSInteger usedTenant = [standardDefaults integerForKey:TOTAL_ADDED_TENANT];
    int remainTenant = totalNoOfTenantPurchased - usedTenant;
    NSString *str = [NSString stringWithFormat:@"Used %d Tenant Records - %d Remaining", usedTenant, remainTenant];
    [Utility showAlertViewWithTitle:@"Tenant usage!" Message:str CancelTitle:@"Ok"];
}

- (void)dismissHUD:(id)arg
{
    [MBProgressHUD hideHUDForView:self.view animated:YES];
    self.hud = nil;
}

- (void)productsLoaded:(NSNotification *)notification 
{
    [NSObject cancelPreviousPerformRequestsWithTarget:self];
    [self hideHud];
    self.tableView.hidden = FALSE;    
	
    [self.tableView reloadData];
}

- (void)timeout:(id)arg 
{	
    self.hud.labelText = @"Timeout!";
    self.hud.detailsLabelText = @"Please try again later.";
    self.hud.customView = [[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"37x-Checkmark.jpg"]] autorelease];
	self.hud.mode = MBProgressHUDModeCustomView;
    [self performSelector:@selector(hideHud) withObject:nil afterDelay:3.0];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	return [[TestIAPHelper sharedHelper].products count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	static NSString *CellIdentifier = @"CellIdentifier";
	// In cellForRowAtIndexPath, change cell style to "subtitle":
	UITableViewCell *cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier] autorelease];
	
	// In cellForRowAtIndexPath, under "Configure the cell"
	SKProduct *product = [[TestIAPHelper sharedHelper].products objectAtIndex:indexPath.row];
	
	NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
	[numberFormatter setFormatterBehavior:NSNumberFormatterBehavior10_4];
	[numberFormatter setNumberStyle:NSNumberFormatterCurrencyStyle];
	[numberFormatter setLocale:product.priceLocale];
	NSString *formattedString = [numberFormatter stringFromNumber:product.price];
	
	cell.textLabel.text = product.localizedTitle;
	cell.detailTextLabel.text = formattedString;
	
	UIButton *buyButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
	buyButton.frame = CGRectMake(0, 0, 72, 37);
	[buyButton setTitle:@"Buy" forState:UIControlStateNormal];
	buyButton.tag = indexPath.row;
	[buyButton addTarget:self action:@selector(buyButtonTapped:) forControlEvents:UIControlEventTouchUpInside];
	cell.accessoryType = UITableViewCellAccessoryNone;
	cell.accessoryView = buyButton;     
	
	return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    SKProduct *product = [[TestIAPHelper sharedHelper].products objectAtIndex:indexPath.row];
	
    NSLog(@"Buying %@...", product.productIdentifier);
    [[TestIAPHelper sharedHelper] buyProductIdentifier:product.productIdentifier];
	
    [self showHud];
    self.hud.labelText = @"Buying...";
    [self performSelector:@selector(timeout:) withObject:nil afterDelay:60*5];
}

-(void)buyButtonTapped:(id)sender
{
	UIButton *btn = (UIButton *)sender;
	SKProduct *product = [[TestIAPHelper sharedHelper].products objectAtIndex:btn.tag];
	
    NSLog(@"Buying %@...", product.productIdentifier);
    [[TestIAPHelper sharedHelper] buyProductIdentifier:product.productIdentifier];
	
    [self showHud];
    self.hud.labelText = @"Buying...";
    [self performSelector:@selector(timeout:) withObject:nil afterDelay:60*5];
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	self.hud = nil;
    
    [super viewDidUnload];
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[_hud release];
	_hud = nil;
    [super dealloc];
}

@end
