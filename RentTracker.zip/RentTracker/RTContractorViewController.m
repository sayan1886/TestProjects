//
//  RTContractorViewController.m
//  RentTracker
//
//  Created by ASHIM SAMANTA on 06/03/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//ssss

#import "RTContractorViewController.h"
#import "RTContractorAddViewController.h"
#import "RTContractorEditViewController.h"
#import "Constant.h"
#import "Contractor.h"
#import "CoreDataHelper.h"
#import "AppDelegate_iPhone.h"
#import "Utility.h"

@implementation RTContractorViewController
@synthesize rtContractorTableView = rtContractorTableView_;
@synthesize searchText = searchText_;
@synthesize array = array_;
@synthesize resultdict = resultdict_;

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"Contractor";
		UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(add:)];
		self.navigationItem.rightBarButtonItem = item;
		[item release];
    }
    return self;
}

-(void)add:(id)sender
{
	RTContractorAddViewController *viewController = [[RTContractorAddViewController alloc] initWithNibName:@"RTContractorAddViewController" bundle:nil];
	[self.navigationController pushViewController:viewController animated:YES];
	[viewController release];
}


#pragma mark -
#pragma mark TableView delegate method

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
	return HEIGHT_FOR_HEADER;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
	if(![tableView isEqual:self.rtContractorTableView]) return nil;
	UIView *header = [[UIView alloc]initWithFrame:CONTACT_HEADER_FRAME];
	header.backgroundColor = [UIColor colorWithPatternImage:[[UIImage imageNamed:CONTACT_HEADER_IMAGE] stretchableImageWithLeftCapWidth:0 topCapHeight:32]];
	
	UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, 6, 20, 20)];
	
	if([tableView isEqual:self.rtContractorTableView])
	{
		NSArray *arr = [self.resultdict allKeys];
		label.text = [arr objectAtIndex:section];
	}
	
	label.backgroundColor = [UIColor clearColor];
	label.textColor = [UIColor whiteColor];
	
	[header addSubview:label];
	
	[label release];
	return header;
}

// return list of section titles to display in section index view (e.g. "ABCD...Z#")
-(NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView
{
	if(![tableView isEqual:self.rtContractorTableView]) return nil;
	NSMutableArray *toBeReturned = [[NSMutableArray alloc]init];
    for(char c = 'A'; c <= 'Z'; c++) [toBeReturned addObject:[NSString stringWithFormat:@"%c",c]];
    return [toBeReturned autorelease];
}

// tell table which section corresponds to section title/index (e.g. "B",1))

-(NSInteger)tableView:(UITableView *)tableView sectionForSectionIndexTitle:(NSString *)title atIndex:(NSInteger)index
{
	NSLog(@"index = %d", index);
	return index;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	if([tableView isEqual:self.rtContractorTableView])
	{
		NSArray *arr = [self.resultdict allKeys];
		NSArray *arrRes = [self.resultdict objectForKey:[arr objectAtIndex:section]];
		return [arrRes count];
	}
	return [self.searchText count];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	if([tableView isEqual:self.rtContractorTableView])
	{
		NSArray *arr = [self.resultdict allKeys];
		
		return [arr count];
	}
	return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	static NSString *cellID = @"cellID";
	NSString *text = @"";
	if([tableView isEqual:self.rtContractorTableView]) 
	{
		NSArray *arr = [self.resultdict allKeys];
		NSString *val = [arr objectAtIndex:indexPath.section];
		arr = [self.resultdict objectForKey:val];
		Contractor *con = [arr objectAtIndex:indexPath.row];
		text = con.name;
	}
	else 
	{
		text = [[self.searchText objectAtIndex:indexPath.row] valueForKey:@"name"];
	}
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID] ;
	if(!cell)
	{
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewStylePlain reuseIdentifier:cellID] autorelease];
		
		cell.textLabel.text = text;
	}
	else
		cell.textLabel.text = text;
	return cell;
}
#pragma mark -
#pragma mark deleteContractor

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
	AppDelegate_iPhone *app = (AppDelegate_iPhone *)[[UIApplication sharedApplication] delegate];
	NSArray *arr = [self.resultdict allKeys];
	
	NSString *val = [arr objectAtIndex:indexPath.section];
	arr = nil;
	arr = [self.resultdict objectForKey:val];
	
	Contractor *con = [arr objectAtIndex:indexPath.row];
	[app.managedObjectContext deleteObject:con];
	[app saveContext];
	arr = nil;
	[self getValueFromContext];
	[tableView reloadData];
}
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
	return YES;
}
- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return UITableViewCellEditingStyleDelete;	
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	
	Contractor *cont = nil;
	if([tableView isEqual:self.rtContractorTableView])
	{
		NSArray *arr = [self.resultdict allKeys];
		NSString *val = [arr objectAtIndex:indexPath.section];
		arr = [self.resultdict objectForKey:val];
		cont = [arr objectAtIndex:indexPath.row];
	}
	else 
	{
		cont = [self.searchText objectAtIndex:indexPath.row];
	}
	
	RTContractorEditViewController *viewController = [[RTContractorEditViewController alloc] initWithNibName:@"RTContractorEditViewController" bundle:nil];
	viewController.contractor = cont;
	[self.navigationController pushViewController:viewController animated:YES];
	[viewController release];viewController = nil;
}


#pragma mark -
#pragma mark SEARCH

- (BOOL)searchDisplayController:(UISearchDisplayController *)controller shouldReloadTableForSearchString:(NSString *)searchString
{    
    [self.searchText removeAllObjects];
    
    for (Contractor *contractor in self.array)
    {
		NSString *aStr = contractor.name;
		aStr = [aStr lowercaseString];
		if ([aStr rangeOfString:[searchString lowercaseString]].location != NSNotFound)
            [self.searchText addObject:contractor];
    }
	
    [controller.searchResultsTableView reloadData];
    
    return NO;
}

- (void)searchDisplayControllerWillBeginSearch:(UISearchDisplayController *)controller
{
    self.rtContractorTableView.hidden = YES;
}

- (void)searchDisplayControllerDidEndSearch:(UISearchDisplayController *)controller
{
    self.rtContractorTableView.hidden = NO;
}




// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	self.searchText = [[NSMutableArray alloc] init];
}

-(void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	[self getValueFromContext];
	[self.rtContractorTableView reloadData];
}

-(void)getValueFromContext
{
	AppDelegate_iPhone *app = (AppDelegate_iPhone *)[[UIApplication sharedApplication]delegate];
	self.array = [CoreDataHelper getObjectsFromContext:ENTITY_KEY_CONTRACTOR :@"name" :YES :app.managedObjectContext];
	self.resultdict = [Utility arrangeList:self.array sortKey:@"name"];
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    
	self.rtContractorTableView = nil;
	self.searchText = nil;
	self.array = nil;
	self.resultdict = nil;
	
	[super viewDidUnload];
	
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	
	self.rtContractorTableView = nil;
	self.searchText = nil;
	self.array = nil;
	self.resultdict = nil;
	
    [super dealloc];
}


@end
