//
//  Building.m
//  RentTracker
//
//  Created by Manas Kumar Mandal on 20/04/12.
//  Copyright (c) 2012 ObjectSol Technologies. All rights reserved.
//

#import "Building.h"
#import "Expenses.h"
#import "Owner.h"


@implementation Building

@dynamic address;
@dynamic postal_code;
@dynamic deleted;
@dynamic city;
@dynamic no_of_units;
@dynamic image;
@dynamic state;
@dynamic owner;
@dynamic expenses;

@end
