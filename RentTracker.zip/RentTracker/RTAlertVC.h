//
//  RTAlertVC.h
//  RentTracker
//
//  Created by Manas Kumar Mandal on 13/06/12.
//  Copyright (c) 2012 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RTAlertVC : UIViewController <UITableViewDataSource, UITableViewDelegate>
{
    
}
@property (retain, nonatomic) IBOutlet UITableView *aTableView;
@property (nonatomic, retain) NSMutableArray *arr;

@end
