//
//  Constant.h
//  RentTracker
//
//  Created by ASHIM SAMANTA on 28/02/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

typedef enum{
	BUILDING, FIRST, LAST,
	ADDRESS,CITY, STATE, POSTALCODE,
	HOME_PHONE, WORK_PHONE, MOBILE, EMAIL,RENT_AMT,
	DEPOSIT_AMT, DEP_PAID_DATE, MOVE_IN_DATE,
	LEASE_START_DATE, LEASE_PERIOD, RENT_DUE_DAY,
	NOTE, MOVE_OUT
	
}TENANT_TEXTFIELD_TAG;

typedef enum{
	BUILDING_OWNER, BUILDING_NO_OF_UNITS,
	BUILDING_ADDRESS, BUILDING_CITY, BUILDING_STATE, BUILDING_POSTAL_CODE,
}BUILDING_TEXTFIELD_TAG;

typedef enum{
	OWNER_PREFIX, OWNER_FIRST, OWNER_LAST,
	OWNER_ADDRESS, OWNER_CITY, OWNER_STATE, OWNER_POSTAL_CODE,
	OWNER_HOME_PHONE, OWNER_WORK_PHONE, OWNER_MOBILE, 
	OWNER_EMAIL
	
}OWNER_TEXTFIELD_TAG;

typedef enum{
	EXENCES_BUILDING,
	EXENCES_DESCRIPTION, EXENCES_PAYEE,
	EXENCES_AMOUNT, EXENCES_DATE,
	EXENCES_CHECK_NO,	 
	EXENCES_NOTE,
	
	EXENCES_CATEGORIES
}EXENCES_TEXTFIELD_TAG;

typedef enum{
	CONTRACTOR_NAME,
	
	CONTRACTOR_WEBSITE,
	CONTRACTOR_ADDRESS,
	CONTRACTOR_CITY,
	CONTRACTOR_STATE,
	CONTRACTOR_POSTAL_CODE,
	
	CONTRACTOR_WORK_PHONE,
	CONTRACTOR_CELL_PHONE,
	CONTRACTOR_FAX,
	CONTRACTOR_EMAIL,
	
	CONTRACTOR_NOTES
}CONTRACTOR_TEXTFIELD_TAG;

typedef enum{
	PAYMENT_AMOUNT, PAYMENT_DATE_PAID, PAYMENT_YEAR,
	PAYMENT_FOR, PAYMENT_NOTE
}PAYMENT_TEXTFIELD_TAG;

typedef enum{
	FROM,
	TO,
	REPORT,
	SELECT
}REPORT_TAG;

typedef enum{
	BUILDING_TAG,
	OWNER_TAG,
	TENANT_TAG
}SELECT_TAG;

typedef enum{
	DATE_PICKER,
	PICKER,
	LEASE_PERIOD_PICKER,
	RENT_DUE_DAY_PICKER,
	CONTRACTOR_PICKER
	
}PICKER_TAG;

typedef enum{
	
	INCOME_REPORT_BY_BUILDING = 0,
	INCOME_REPORT_BY_OWNER,
	EXPENSE_REPORT_BY_BUILDING,
	EXPENSE_REPORT_BY_OWNER,
	TOTAL_FINANCE_BY_BUILDING,
	TOTAL_FINANCE_BY_OWNER,
	TENANT_PAYMENT_REPORT,
	LATE_TENANT_REPORT,
	TENANT_PHONE_LIST,
	RENT_ROLL
	
}REPORT_TYPES_TAG;


typedef enum{
	Advertising = 0,
	Travel,
	Cleaning,
	Commissions,
	Insurance,
	Professional_Fees,
	Management_Fees,
	Repairs,
	Supplies,
	Real_Estate_Taxes,
	Other_Taxes,
	Utilities,
    Depreciable_Expense,
	UNKNOWN
	
}EXPENSES_CATEGOTY;

typedef enum{
    JAN = 1,
    FEB,
    MAR,
    APR,
    MAY,
    JUNE,
    JULY,
    AUG,
    SEP,
    OCT,
    NOV,
    DEC,
    UNKNOWN_MONTH
}MONTHS;

#pragma mark -
#pragma mark CONTACT_HEADER_FRAME

#if UI_USER_INTERFACE_IDIOM == UIUserInterfaceIdiomPhone
	#define CONTACT_HEADER_FRAME CGRectMake(0, 0, 320, 38)
#elif
	#define CONTACT_HEADER_FRAME CGRectMake(0, 0, 768, 38)
#endif

 
#define ISIPHONE UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone



#define CONTACT_HEADER_IMAGE @"bar.png"
#define ORIGINAL_FRAME_IPHONE CGRectMake(0, 0, 320, 416)
#define MODIFIED_FRAME_IPHONE CGRectMake(0, 0, 320, 200)

#define HEIGHT_FOR_HEADERFOOTER = 20;
#define HEIGHT_FOR_HEADER 32.0
#define HEIGHT_FOR_ROW 44.0
#define HEIGHT_FOR_NOTE_ROW HEIGHT_FOR_ROW*3

#define TENANT_NO_OF_SECTION 6
#define BUILDING_NO_OF_SECTION 3
#define OWNER_NO_OF_SECTION 5
#define CONTRACTOR_NO_OF_SECTION 4
#define EXENCES_NO_OF_SECTION 6
#define PAYMENT_NO_OF_SECTION 3;

#define KEY_IMAGE @"Image"
#define BG_IMAGE_IPHONE @"bg_iphone.png"
#define BG_IMAGE_IPAD @"bg_ipad.png"
#define HOUSE_ICON @"houseIcon.png"


#define ENTITY_KEY_TENANT @"Tenant"
#define ENTITY_KEY_BUILDING @"Building"
#define ENTITY_KEY_OWNER @"Owner"
#define ENTITY_KEY_CONTRACTOR @"Contractor"
#define ENTITY_KEY_EXPENSES @"Expenses"
#define ENTITY_KEY_PAYMENT @"Payment"
#define ENTITY_KEY_SETTINGS @"Settings"

#define TITLE @"Error!!!"
#define TITLE_MANDATORY_FIELD @"Mandatory Field!!!"

#define MESSAGE_NO_BUILDING @"Must add a Building first!"
#define MESSAGE_NO_OWNER @"Must add an Owner first!"
#define MESSAGE_NO_CONTRACTOR @"Must add an Contractor first!"

#define MESSAGE_OWNER_MANDATORY_FIELD @"Must fillup First and Last field."
#define MESSAGE_BUILDING_MANDATORY_FIELD @"Must fillup Address and Owner field."
#define MESSAGE_TENANT_MANDATORY_FIELD @"Must fillup Building, Name, Rent Amount, Lease Start Date, Lease Period And RentDue day field."
#define MESSAGE_CONTRACTOR_MANDATORY_FIELD @"Must fillup Name field."
#define MESSAGE_EXPENSE_MANDATORY_FIELD @"Must fillup Description field."

//message and title for in app puchase
#define MESSAGE_NEED_INAPP_PURCHASE @"Must make In-App Purchase for Additional Tenant. Continue?"
#define TITLE_NEED_INAPP_PURCHASE @"In-App Purchase!!!"
#define INAPP_PURCHASE_OK_TITLE @"Ok"
#define INAPP_PURCHASE_CANCEL_TITLE @"Cancel"

#define MESSAGE_INVALID_EMAIL_ID @"Please provide a valid Email Id."

#define CANCEL_TITLE @"Ok"

#define VALID_INTEGER @"0123456789"
#define VALID_FLOAT @"0123456789."
#define VALID_MAIL_REGEX @"(?:[a-z0-9!#$%\\&'*+/=?\\^_`{|}~-]+(?:\\.[a-z0-9!#$%\\&'*+/=?\\^_`{|}"\
	@"~-]+)*|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\"\
	@"x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[a-z0-9](?:[a-"\
	@"z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\\[(?:(?:25[0-5"\
	@"]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-"\
	@"9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21"\
	@"-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])"\

//For In App Purchase

#define TOTAL_ADDED_TENANT @"addedTenant"
#define PURCHASED_TENANT @"totalTanant"

#define ONE_TENANT_PROCUCT_ID @"OneTenant"
#define TEN_TENANT_PRODUCTID @"TenTenant"
#define FIFTY_TENANT_PRODUCTID @"FiftyTenant"
