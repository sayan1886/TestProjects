//
//  RTExpenseEditViewController.h
//  RentTracker
//
//  Created by ASHIM SAMANTA on 22/03/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Building.h"
#import "Expenses.h"
#import "Constant.h"

@interface RTExpenseEditViewController : UIViewController <UITableViewDataSource, UITableViewDelegate,
UITextFieldDelegate,UITextViewDelegate, UIPickerViewDataSource, UIPickerViewDelegate >
{
	UITableView *rtExpenseEditTableView_;
	NSMutableDictionary *tempDict_;
	
	NSMutableArray *pickerArray;
	UITextField *tempTextField;
	NSMutableArray *contractorPickerArray_;
	UITextView *tempTextView;
	
	Building *building_;
	Expenses *expenses_;
	
	UIBarButtonItem *rightItem_;
	BOOL isReadOnly;

// for picker	
	UIView *pView_;
	PICKER_TAG pickerTag;
	UIDatePicker *datePicker_;
	UIPickerView *pickerView_;
	UITextField *textFieldToHidePicker_;
	NSInteger selectedIndex;
}
@property (nonatomic, retain) IBOutlet UITableView *rtExpenseEditTableView;
@property (nonatomic, retain) NSMutableDictionary *tempDict;
@property (nonatomic, retain) Building *building;
@property (nonatomic, retain) Expenses *expenses;
@property (nonatomic, retain) UIBarButtonItem *rightItem;

@property (nonatomic, retain) UIView *pView;
@property (nonatomic, retain) UIDatePicker *datePicker;
@property (nonatomic, retain) UIPickerView *pickerView;
@property (nonatomic, retain) UITextField *textFieldToHidePicker;
@property (nonatomic, retain) NSMutableArray *contractorPickerArray;

-(void)fetchManagedObject;
-(void)loadValues;
-(void)updateData;
@end
