//
//  RTPaymentEditViewController.h
//  RentTracker
//
//  Created by ASHIM SAMANTA on 26/03/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Constant.h"
#import "Tenant.h"
#import "Payment.h"
#import <MessageUI/MFMailComposeViewController.h>
 
@interface RTPaymentEditViewController : UIViewController <UITableViewDelegate, UITableViewDataSource,
UITextFieldDelegate, UITextViewDelegate, UIPickerViewDelegate, UIPickerViewDataSource, MFMailComposeViewControllerDelegate >
{
	UITableView *rtPaymentEditTableView_;
//paymentFor 	
	UIPickerView *pickerPaymentFor_;
	NSMutableArray *arrayPaymentFor_;
//tenant
	Tenant *tenant_;
	Payment *payment_;
//for all data management
	NSMutableDictionary *tempDict_;
//For picker
	UIView *pView_;
	UIPickerView *pickerView_;
	UIDatePicker *datePicker_;
	PICKER_TAG pickerTag;
//Note
	UITextView *txtNote_;
//
	UITextField *tempTextField_;
	
	NSInteger selectedIndex;
	UITextField *textFieldToHidePicker_;
	
	UIBarButtonItem *rightItem_;
	BOOL isReadOnly;
}

@property (nonatomic, retain) IBOutlet UITableView *rtPaymentEditTableView;
@property (nonatomic, retain) UIPickerView *pickerPaymentFor;
@property (nonatomic, retain) NSMutableArray *arrayPaymentFor;
@property (nonatomic, retain) Tenant *tenant;
@property (nonatomic, retain) Payment *payment;
@property (nonatomic, retain) NSMutableDictionary *tempDict;
@property (nonatomic, retain) UIView *pView;
@property (nonatomic, retain) UIPickerView *pickerView;
@property (nonatomic, retain) UIDatePicker *datePicker;
@property (nonatomic, retain) UITextView *txtNote;
@property (nonatomic, retain) UITextField *tempTextField;
@property (nonatomic, retain) UITextField *textFieldToHidePicker;
@property (nonatomic, retain) UIBarButtonItem *rightItem;
@property (nonatomic, retain) UITextField *txtField;

-(void)launchMailAppOnDevice;
-(void)loadValues;
-(void)fetchManagedObject;
-(void)updateData;
@end
