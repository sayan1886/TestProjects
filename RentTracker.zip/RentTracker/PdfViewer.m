//
//  PdfViewer.m
//  RentTracker
//
//  Created by ASHIM SAMANTA on 03/04/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import "PdfViewer.h"
#import "Utility.h"
#import "mail.h"
#import "Constant.h"

@implementation PdfViewer

@synthesize url;
// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/
-(void)cancel:(id)sender
{
	[self dismissModalViewControllerAnimated:YES];
}

-(void)email:(id)sender
{
//	[self dismissModalViewControllerAnimated:YES];
	mail *email = [[mail alloc] init];
	email.con = self;
	[email mailWithData:self.url];
	
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	if(!ISIPHONE)
		self.view.frame = CGRectMake(0, 0, 768, 1004);
	
	UIToolbar *toolBar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 44)];
	toolBar.barStyle = UIBarStyleBlackTranslucent;
	
	NSMutableArray *array = [[NSMutableArray alloc] init];
	UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(cancel:)];
	[array addObject:item];
	item = nil;
	
	item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
	[array addObject:item];
	item = nil;
	
	item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemReply target:self action:@selector(email:)];
	[array addObject:item];
	item = nil;
	
	[toolBar setItems:array animated:YES];
	[self.view addSubview:toolBar];
	toolBar = nil;
	
	NSString *path = [Utility applicationDocumentsDirectory];
	path = [path stringByAppendingFormat:@"%@",url];
    NSURL *fileURL = [[NSURL alloc] initFileURLWithPath:path];
	
	UIWebView *webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, 44.0, self.view.frame.size.width, self.view.frame.size.height - 44.0)];
	
	[self.view addSubview:webView];
	
	NSURLRequest *request = [NSURLRequest requestWithURL:fileURL];
	[webView loadRequest:request];
	
	webView.scalesPageToFit = YES;
	
	[webView release];
	
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    
	self.url = nil;
	
	[super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
	
}


- (void)dealloc {
	
	url = nil;
    [super dealloc];
}


@end
