//
//  Contractor.h
//  RentTracker
//
//  Created by Manas Kumar Mandal on 18/04/12.
//  Copyright (c) 2012 ObjectSol Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface Contractor : NSManagedObject

@property (nonatomic, retain) NSString * state;
@property (nonatomic, retain) NSString * webSite;
@property (nonatomic, retain) NSString * fax;
@property (nonatomic, retain) NSString * address;
@property (nonatomic, retain) NSString * notes;
@property (nonatomic, retain) NSString * city;
@property (nonatomic, retain) NSString * postalCode;
@property (nonatomic, retain) NSString * workPhone;
@property (nonatomic, retain) NSData * image;
@property (nonatomic, retain) NSString * cellPhone;
@property (nonatomic, retain) NSString * email;
@property (nonatomic, retain) NSString * name;

@end
