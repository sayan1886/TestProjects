//
//  RTOwnerViewController.h
//  RentTracker
//
//  Created by ASHIM SAMANTA on 06/03/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface RTOwnerViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate> {
	UITableView *rtOwnerTableView_;
	NSMutableArray *array_;
	NSMutableArray *searchText_;
	NSMutableDictionary *resultdict_;
	
	NSArray *arr_;

}

@property (nonatomic, retain) IBOutlet UITableView *rtOwnerTableView;
@property (nonatomic, retain) NSMutableArray *searchText;
@property (nonatomic, retain) NSMutableArray *array;
@property (nonatomic, retain) NSMutableDictionary *resultdict;

@property (nonatomic, retain) NSArray *arr;

-(void)getValuesFromContext;

@end
