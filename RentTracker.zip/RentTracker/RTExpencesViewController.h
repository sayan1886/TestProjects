//
//  RTExpencesViewController.h
//  RentTracker
//
//  Created by ASHIM SAMANTA on 06/03/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface RTExpencesViewController : UIViewController {
	UITableView *rtExpencesTableView_;
	NSMutableArray *searchText_;
	NSMutableArray *array_;
	NSMutableDictionary *resultdict_;
	
	NSArray *arr_;
}


@property (nonatomic, retain) IBOutlet UITableView *rtExpencesTableView;
@property (nonatomic, retain) NSMutableArray *searchText;
@property (nonatomic, retain) NSMutableArray *array;
@property (nonatomic, retain) NSMutableDictionary *resultdict;
@property (nonatomic, retain) NSArray *arr;

@end
