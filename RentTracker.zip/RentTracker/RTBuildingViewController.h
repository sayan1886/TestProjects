//
//  RTBuildingViewController.h
//  RentTracker
//
//  Created by ASHIM SAMANTA on 29/02/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface RTBuildingViewController : UIViewController 
{
	UITableView *rtBuildingTableView_;
	NSMutableArray *searchText_;
	NSMutableArray *array_;
	NSMutableDictionary *resultdict_;
	
	NSArray *arr_;
}

@property (nonatomic, retain) IBOutlet UITableView *rtBuildingTableView;
@property (nonatomic, retain) NSMutableArray *searchText;
@property (nonatomic, retain) NSMutableArray *array;
@property (nonatomic, retain) NSMutableDictionary *resultdict;
@property (nonatomic, retain) NSArray *arr;

-(void)getValueFromContext;

@end
