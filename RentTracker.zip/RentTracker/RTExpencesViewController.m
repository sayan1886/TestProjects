//
//  RTExpencesViewController.m
//  RentTracker
//
//  Created by ASHIM SAMANTA on 06/03/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import "RTExpencesViewController.h"
#import "RTExpencesAddViewController.h"
#import "RTExpensesListViewController.h"
#import "Constant.h"
#import "AppDelegate_iPhone.h"
#import "Utility.h"
#import "CoreDataHelper.h"
#import "Expenses.h"
#import "Building.h"

@implementation RTExpencesViewController

@synthesize rtExpencesTableView = rtExpencesTableView_;
@synthesize searchText = searchText_;
@synthesize array = array_;
@synthesize resultdict = resultdict_;
@synthesize arr = arr_;

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"Select Building";
		/*UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(add:)];
		self.navigationItem.rightBarButtonItem = item;
		[item release];*/
    }
    return self;
}

-(void)add:(id)sender
{
	RTExpencesAddViewController *viewController = [[RTExpencesAddViewController alloc] initWithNibName:@"RTExpencesAddViewController" bundle:nil];
	[self.navigationController pushViewController:viewController animated:YES];
	[viewController release];
}



#pragma mark -
#pragma mark TableView delegate method

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
	return HEIGHT_FOR_HEADER;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
	
	if(![tableView isEqual:self.rtExpencesTableView]) return nil;
	
	UIView *header = [[[UIView alloc]initWithFrame:CONTACT_HEADER_FRAME] autorelease];
	header.backgroundColor = [UIColor colorWithPatternImage:[[UIImage imageNamed:CONTACT_HEADER_IMAGE] stretchableImageWithLeftCapWidth:0 topCapHeight:32]];
	
	UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, 6, 20, 20)];
	
	if([tableView isEqual:self.rtExpencesTableView])
	{
		label.text = [self.arr objectAtIndex:section];
	}
	
	label.backgroundColor = [UIColor clearColor];
	label.textColor = [UIColor whiteColor];
	
	[header addSubview:label];
	
	[label release];
	return header;
}

// return list of section titles to display in section index view (e.g. "ABCD...Z#")
-(NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView
{
	if(![tableView isEqual:self.rtExpencesTableView]) return nil;
	NSMutableArray *toBeReturned = [[NSMutableArray alloc]init];
    for(char c = 'A'; c <= 'Z'; c++) [toBeReturned addObject:[NSString stringWithFormat:@"%c",c]];
    return [toBeReturned autorelease];
}
/*
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
 {
 NSLog(@"DELETED!!!");
 }
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
 {
 return YES;
 }
 - (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
 {
 return UITableViewCellEditingStyleDelete;	
 }*/

// tell table which section corresponds to section title/index (e.g. "B",1))

-(NSInteger)tableView:(UITableView *)tableView sectionForSectionIndexTitle:(NSString *)title atIndex:(NSInteger)index
{
	NSLog(@"index = %d", index);
	return index;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	if([tableView isEqual:self.rtExpencesTableView])
	{
		NSArray *arrRes = [self.resultdict objectForKey:[self.arr objectAtIndex:section]];
		return [arrRes count];
	}
	return [self.searchText count];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	if([tableView isEqual:self.rtExpencesTableView])
	{
		return [self.arr count];
	}
	return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	NSString *text = @"";
	if([tableView isEqual:self.rtExpencesTableView]) 
	{
		NSString *val = [self.arr objectAtIndex:indexPath.section];
		NSArray *tempArr = [self.resultdict objectForKey:val];
		Building *build = [tempArr objectAtIndex:indexPath.row];
		text = build.address;
		tempArr = nil;
	}
	else 
	{
		text = [[self.searchText objectAtIndex:indexPath.row] valueForKey:@"address"];
	}	
	UITableViewCell *cell = cell = [[[UITableViewCell alloc] initWithStyle:UITableViewStylePlain reuseIdentifier:nil] autorelease];
	cell.textLabel.text = text;
	return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	Building *build = nil;
	if([tableView isEqual:self.rtExpencesTableView])
	{
		NSString *val = [self.arr objectAtIndex:indexPath.section];
		NSArray *tempArr = [self.resultdict objectForKey:val];
		build = [tempArr objectAtIndex:indexPath.row];
		tempArr = nil;
	}
	else 
	{
		build = [self.searchText objectAtIndex:indexPath.row];
	}
	
	RTExpensesListViewController *viewController = [[RTExpensesListViewController alloc] initWithNibName:@"RTExpensesListViewController" bundle:nil];
	viewController.building = build;
	[self.navigationController pushViewController:viewController animated:YES];
	[viewController release];viewController = nil;
}


#pragma mark -
#pragma mark SEARCH

- (BOOL)searchDisplayController:(UISearchDisplayController *)controller shouldReloadTableForSearchString:(NSString *)searchString
{    
    [self.searchText removeAllObjects];
    
    for (Building *build in self.array)
    {
		NSString *aStr = [build.address lowercaseString];
		if ([aStr rangeOfString:[searchString lowercaseString]].location != NSNotFound)
            [self.searchText addObject:build];
    }
	
    [controller.searchResultsTableView reloadData];
    
    return NO;
}

- (void)searchDisplayControllerWillBeginSearch:(UISearchDisplayController *)controller
{
    self.rtExpencesTableView.hidden = YES;
}

- (void)searchDisplayControllerDidEndSearch:(UISearchDisplayController *)controller
{
    self.rtExpencesTableView.hidden = NO;
}

-(void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	AppDelegate_iPhone *app = (AppDelegate_iPhone *)[[UIApplication sharedApplication]delegate];
	self.array = [CoreDataHelper getObjectsFromContext:ENTITY_KEY_BUILDING :@"address" :YES :app.managedObjectContext];
	
	self.resultdict = [Utility arrangeList:self.array sortKey:@"address"];
	self.arr = [self.resultdict allKeys];
	self.arr = [self.arr sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
	[self.rtExpencesTableView reloadData];
}


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	self.searchText = [[NSMutableArray alloc] init];
	
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
	
	self.rtExpencesTableView = nil;
	self.searchText = nil;
	self.array = nil;
	self.resultdict = nil;
	self.arr = nil;
	
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	
	self.rtExpencesTableView = nil;
	self.searchText = nil;
	self.array = nil;
	self.resultdict = nil;
	self.arr = nil;
	
    [super dealloc];
}


@end
