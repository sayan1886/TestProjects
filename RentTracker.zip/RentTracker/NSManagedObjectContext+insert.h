//
//  NSManagedObjectContext+insert.h
//  RentTracker
//
//  Created by ASHIM SAMANTA on 13/03/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@interface NSManagedObjectContext(insert)

-(id) insertNewEntityWithName:(NSString *)name;

@end

