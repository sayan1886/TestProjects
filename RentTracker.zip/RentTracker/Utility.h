//
//  Utility.h
//  RentTracker
//
//  Created by ASHIM SAMANTA on 28/02/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomCell.h"
#import "Constant.h"
#import "AppDelegate_iPhone.h"
#import "Expenses.h"
#import "Payment.h"
#import "Tenant.h"
#import "Contractor.h"
#import "Expenses.h"
#import "Building.h"
#import "Owner.h"

@interface Utility : NSObject 
{

}

+(NSMutableDictionary *)arrangeList:(NSMutableArray *)list sortKey:(NSString *)sKey;
+(void)showDropDown:(UIView *)pickerView;
+(void)hidesDropDown:(UIView *)pickerView;

+(CustomCell *)cellForRowAtPathForTenantFirstTableView:( NSIndexPath *)path isReadOnly:(BOOL)readOnly;
+(CustomCell *)cellForRowAtPathForTenantSecondTableView:( NSIndexPath *)path isReadOnly:(BOOL) readOnly;

+(void)showAlertViewWithTitle:(NSString *)title Message:(NSString *)msg CancelTitle:(NSString *)cancelTitle;
+(BOOL)isEmailValid:(NSString *)emailID;

+(BOOL)makePhoneCallWithPhoneNumber:(NSString *)phoneNumber;
+(BOOL)launchMailWithTo:(NSString *)mailTo;
+(BOOL)launchMapWithAddress:(NSString *)address;
//+(UIViewController *)openURL:(NSString *)url;
+ (NSString *)applicationDocumentsDirectory;
//For Height Of TableView
+(void)increaseHeightOfTableView:(UITableView *)tableView;
+(void)decreaseHeightOfTableView:(UITableView *)tableView;

+(void)formatPhoneNumber:(UITextField *)textField withRange:(NSRange)range replacementString:(NSString *)string;

+(void)formatSSNNumber:(UITextField *)textField withRange:(NSRange)range replacementString:(NSString *)string;

+(EXPENSES_CATEGOTY)expenseCategoryTag:(NSString *)category;
+(NSArray *)sortExpenseByDate:(NSArray *)arrayToSort;

+(BOOL)isDueForTenant:(Tenant *)ten;
+(CGFloat)dueAmountForTenant:(Tenant *)ten;
+(BOOL)isLeasePeriodExpiredForTenant:(Tenant *)tenant;

+(void)didFindContractor:(Contractor *)contractor;
+(void)didFindOwner:(Owner *)owner;
+(void)didFindBuilding:(Building *)building;

+(BOOL)isNetworkAvailable;
+(void)updateRemainingTenant;

+(MONTHS)paymentMadeForMonth:(NSString *)paymentDate;

@end
