//
//  RTContractorEditViewController.h
//  RentTracker
//
//  Created by ASHIM SAMANTA on 06/03/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ImagePicker.h"
#import "Contractor.h"

@interface RTContractorEditViewController : UIViewController <UITableViewDelegate, UITableViewDataSource,
											UITextFieldDelegate, UITextViewDelegate, CaptureImage>
{
	UITableView *rtContractorEditTableView_;
	UIBarButtonItem *rightItem_;
	NSMutableDictionary *tempDict;
	UIButton *btn;
	
	UITextView *tempTextView;
	UITextField *tempTextField;
	BOOL isReadOnly;
	
	Contractor *contractor_;
	UITextField *name_;
	
	UITextField *txtFld;
}
@property (nonatomic, retain) IBOutlet UITableView *rtContractorEditTableView;
@property (nonatomic, retain) UIBarButtonItem *rightItem;
@property (nonatomic, retain) NSMutableDictionary *tempDict;
@property (nonatomic, retain) Contractor *contractor;
@property (nonatomic, retain) UITextField *name;
@property (nonatomic, retain) UIButton *btn;
@property (nonatomic, retain) UITextField *txtFld;

-(void)fetchManagedObject;
-(void)loadValues;
-(void)addToolBar:(UITextView *)textView;
-(void)updateData;
-(void)takePicture:(id)sender;


@end
