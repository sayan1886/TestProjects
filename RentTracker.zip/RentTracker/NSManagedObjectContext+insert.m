//
//  NSManagedObjectContext+insert.m
//  RentTracker
//
//  Created by ASHIM SAMANTA on 13/03/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import "NSManagedObjectContext+insert.h"

@implementation NSManagedObjectContext(insert)
-(id) insertNewEntityWithName:(NSString *)name
{
    return [NSEntityDescription insertNewObjectForEntityForName:name inManagedObjectContext:self];
}
@end

