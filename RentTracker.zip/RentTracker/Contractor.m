//
//  Contractor.m
//  RentTracker
//
//  Created by Manas Kumar Mandal on 18/04/12.
//  Copyright (c) 2012 ObjectSol Technologies. All rights reserved.
//

#import "Contractor.h"


@implementation Contractor

@dynamic state;
@dynamic webSite;
@dynamic fax;
@dynamic address;
@dynamic notes;
@dynamic city;
@dynamic postalCode;
@dynamic workPhone;
@dynamic image;
@dynamic cellPhone;
@dynamic email;
@dynamic name;

@end
