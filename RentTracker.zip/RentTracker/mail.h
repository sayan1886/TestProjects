//
//  mail.h
//  Restroom_project
//
//  Created by Raju on 21/11/11.
//  Copyright 2011 kapildeb.chowdhury@gmail.com. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MessageUI/MFMailComposeViewController.h>

@interface mail : NSObject<MFMailComposeViewControllerDelegate> {
	UIViewController* con;
}
@property (nonatomic, retain) UIViewController * con;

-(void)launchMailAppOnDevice;
-(void)callForSendingMail;
-(void)mailWithData:(NSString*)fileName;

@end
