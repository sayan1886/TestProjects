//
//  Tenant.h
//  RentTracker
//
//  Created by Manas Kumar Mandal on 18/04/12.
//  Copyright (c) 2012 ObjectSol Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class Building, Payment;

@interface Tenant : NSManagedObject

@property (nonatomic, retain) NSString * deposit_amount;
@property (nonatomic, retain) NSString * dep_paid_date;
@property (nonatomic, retain) NSString * postal_code;
@property (nonatomic, retain) NSString * work_phone;
@property (nonatomic, retain) NSData * image;
@property (nonatomic, retain) NSString * leaseStartDate;
@property (nonatomic, retain) NSString * last;
@property (nonatomic, retain) NSString * first;
@property (nonatomic, retain) NSString * home_phone;
@property (nonatomic, retain) NSString * city;
@property (nonatomic, retain) NSString * rentDueDay;
@property (nonatomic, retain) NSString * rentAmount;
@property (nonatomic, retain) NSString * cause;
@property (nonatomic, retain) NSString * leasePeriod;
@property (nonatomic, retain) NSString * state;
@property (nonatomic, retain) NSString * lastPaymentMade;
@property (nonatomic, retain) NSNumber * paymentForIndex;
@property (nonatomic, retain) NSString * lastPaymentYear;
@property (nonatomic, retain) NSString * email;
@property (nonatomic, retain) NSString * mobile;
@property (nonatomic, retain) NSNumber * rentDue;
@property (nonatomic, retain) NSString * note;
@property (nonatomic, retain) NSString * moveOut;
@property (nonatomic, retain) NSString * move_in_date;
@property (nonatomic, retain) NSString * address;
@property (nonatomic, retain) Building *building;
@property (nonatomic, retain) NSSet *payments;
@end

@interface Tenant (CoreDataGeneratedAccessors)

- (void)addPaymentsObject:(Payment *)value;
- (void)removePaymentsObject:(Payment *)value;
- (void)addPayments:(NSSet *)values;
- (void)removePayments:(NSSet *)values;
@end
