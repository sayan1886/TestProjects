//
//  Payment.m
//  RentTracker
//
//  Created by Manas Kumar Mandal on 18/04/12.
//  Copyright (c) 2012 ObjectSol Technologies. All rights reserved.
//

#import "Payment.h"


@implementation Payment

@dynamic amount;
@dynamic datePaid;
@dynamic year;
@dynamic note;
@dynamic paymentFor;

@end
