//
//  RTReportViewController.h
//  RentTracker
//
//  Created by ASHIM SAMANTA on 07/03/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Constant.h"

@interface RTReportViewController : UIViewController <UITextFieldDelegate,
										UIPickerViewDataSource, UIPickerViewDelegate> 
{
	UITextField *txtFldFrom_;
	UITextField *txtFldTo_;
	UITextField *txtFldReport_;
	UITextField *txtFldSelect_;
	
	UIButton *btnRunReport;
	
	UILabel *lblSelect_;
	
	UIDatePicker *datePicker_;
	UIPickerView *reportPicker_;
	UIPickerView *selectPicker_;
	
	NSMutableArray *arrOfReportTypes;
	NSMutableArray *arrOfSelect_;
	NSMutableArray *arrOfObjects_;
	UIBarButtonItem *rightItem_;
	
	
	REPORT_TAG reportTag;
	SELECT_TAG selectedTag;
	REPORT_TYPES_TAG reportTypesTag;

//For selectTextField;
	NSInteger selectedIndex;

	
}

@property (nonatomic, retain) IBOutlet UITextField *txtFldFrom;
@property (nonatomic, retain) IBOutlet UITextField *txtFldTo;
@property (nonatomic, retain) IBOutlet UITextField *txtFldReport;
@property (nonatomic, retain) IBOutlet UITextField *txtFldSelect;
@property (nonatomic, retain) IBOutlet UILabel *lblSelect;
@property (nonatomic,retain) IBOutlet UIButton *btnRunReport;

@property (nonatomic, retain) IBOutlet UIDatePicker *datePicker;
@property (nonatomic, retain) IBOutlet UIPickerView *reportPicker;

@property (nonatomic, retain) UIBarButtonItem *rightItem;

@property (nonatomic, retain) UIView *pView;
@property (nonatomic, retain) UIPickerView *pickerView;
@property (nonatomic, retain) UITextField *tempTextField;
@property (nonatomic, retain) NSMutableArray *arrOfSelect;
@property (nonatomic, retain) UIPickerView *selectPicker;
@property (nonatomic, retain) NSMutableArray *arrOfObjects;

-(IBAction)runReport:(id)sender;
-(void)showSelectTextAndLabel:(NSInteger)rowNum WithLabel:(NSString *)labelText;

- (void)showLoadingView;
- (void)hideLoadingView;
-(void)loadDataForSelection;
-(void)loadAllDataForEntity:(NSString *)entityName;


@end
