//
//  RTPaymentEditViewController.m
//  RentTracker
//
//  Created by ASHIM SAMANTA on 26/03/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import "RTPaymentEditViewController.h"
#import "AppDelegate_iPhone.h"
#import "CustomCell.h"
#import "CoreDataHelper.h"
#import "Utility.h"


@implementation RTPaymentEditViewController

@synthesize rtPaymentEditTableView = rtPaymentEditTableView_;
@synthesize pickerPaymentFor = pickerPaymentFor_;
@synthesize arrayPaymentFor = arrayPaymentFor_;
@synthesize tenant = tenant_;
@synthesize payment = payment_;
@synthesize tempDict = tempDict_;
@synthesize pView = pView_;
@synthesize pickerView = pickerView_;
@synthesize datePicker = datePicker_;
@synthesize txtNote = txtNote_;
@synthesize tempTextField = tempTextField_;
@synthesize textFieldToHidePicker = textFieldToHidePicker_;
@synthesize rightItem = rightItem_;
@synthesize txtField;

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.rightItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem: UIBarButtonSystemItemEdit  target:self action:@selector(edit:)];
		self.navigationItem.rightBarButtonItem = self.rightItem;
		isReadOnly = YES;
    }
    return self;
}

#pragma mark -
#pragma mark edit

-(void)edit:(id)sender
{
	isReadOnly = NO;
	[self.rtPaymentEditTableView reloadData];
	
	UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem: UIBarButtonSystemItemDone  target:self action:@selector(done:)];
	[self.navigationItem setRightBarButtonItem:item animated:YES];
	[item release];item = nil;
	
	[self.navigationItem setHidesBackButton:YES animated:YES];
	item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem: UIBarButtonSystemItemCancel  target:self action:@selector(cancelItem:)];
	[self.navigationItem setLeftBarButtonItem:item animated:YES];
	[item release];item = nil;
}

#pragma mark -
#pragma mark done

-(void)done:(id)sender
{
    if(self.txtField)
        [self.txtField resignFirstResponder];
	[self updateData];
	[Utility increaseHeightOfTableView:self.rtPaymentEditTableView];
	isReadOnly = YES;
	[self.rtPaymentEditTableView reloadData];
	
	[self.navigationItem setRightBarButtonItem:self.rightItem animated:YES];
	[self.navigationItem setLeftBarButtonItem:nil animated:YES];
	[self.navigationItem setHidesBackButton:NO animated:YES];
}

-(void)cancelItem:(id)sender
{
	[Utility increaseHeightOfTableView:self.rtPaymentEditTableView];
	isReadOnly = YES;
	if([self.textFieldToHidePicker isFirstResponder])
		[self.textFieldToHidePicker resignFirstResponder];
	
	[self loadValues];
	[self.navigationItem setRightBarButtonItem:self.rightItem animated:YES];
	[self.navigationItem setLeftBarButtonItem:nil animated:YES];
	[self.navigationItem setHidesBackButton:NO animated:YES];
	[self.rtPaymentEditTableView reloadData];
}

#pragma mark -
#pragma mark updateData

-(void)updateData
{
	AppDelegate_iPhone *appDelegate =  (AppDelegate_iPhone *)[[UIApplication sharedApplication] delegate];
	
	if(self.tenant && self.tempDict)
	{
		self.payment.amount = [self.tempDict valueForKey:[NSString stringWithFormat:@"%d",PAYMENT_AMOUNT]];
		self.payment.datePaid =	[self.tempDict valueForKey:[NSString stringWithFormat:@"%d",PAYMENT_DATE_PAID]];
		self.payment.note =	[self.tempDict valueForKey:[NSString stringWithFormat:@"%d",PAYMENT_NOTE]];
		self.payment.paymentFor = [self.tempDict valueForKey:[NSString stringWithFormat:@"%d",PAYMENT_FOR]];
		self.payment.year = [self.tempDict valueForKey:[NSString stringWithFormat:@"%d",PAYMENT_YEAR]];
	
		[appDelegate saveContext];
	}
}

#pragma mark -
#pragma mark viewDidLoad
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	self.arrayPaymentFor = [[NSMutableArray alloc] init];
	[self.arrayPaymentFor addObject:[NSString stringWithFormat:@"Jan %@ - Feb %@",self.tenant.rentDueDay,self.tenant.rentDueDay]];
	[self.arrayPaymentFor addObject:[NSString stringWithFormat:@"Feb %@ - Mar %@",self.tenant.rentDueDay,self.tenant.rentDueDay]];
	[self.arrayPaymentFor addObject:[NSString stringWithFormat:@"Mar %@ - Apr %@",self.tenant.rentDueDay,self.tenant.rentDueDay]];
	[self.arrayPaymentFor addObject:[NSString stringWithFormat:@"Apr %@ - May %@",self.tenant.rentDueDay,self.tenant.rentDueDay]];
	[self.arrayPaymentFor addObject:[NSString stringWithFormat:@"May %@ - Jun %@",self.tenant.rentDueDay,self.tenant.rentDueDay]];
	[self.arrayPaymentFor addObject:[NSString stringWithFormat:@"Jun %@ - Jul %@",self.tenant.rentDueDay,self.tenant.rentDueDay]];
	[self.arrayPaymentFor addObject:[NSString stringWithFormat:@"Jul %@ - Aug %@",self.tenant.rentDueDay,self.tenant.rentDueDay]];
	[self.arrayPaymentFor addObject:[NSString stringWithFormat:@"Aug %@ - Sep %@",self.tenant.rentDueDay,self.tenant.rentDueDay]];
	[self.arrayPaymentFor addObject:[NSString stringWithFormat:@"Sep %@ - Oct %@",self.tenant.rentDueDay,self.tenant.rentDueDay]];
	[self.arrayPaymentFor addObject:[NSString stringWithFormat:@"Oct %@ - Nov %@",self.tenant.rentDueDay,self.tenant.rentDueDay]];
	[self.arrayPaymentFor addObject:[NSString stringWithFormat:@"Nov %@ - Dec %@",self.tenant.rentDueDay,self.tenant.rentDueDay]];
	[self.arrayPaymentFor addObject:[NSString stringWithFormat:@"Dec %@ - Jan %@",self.tenant.rentDueDay,self.tenant.rentDueDay]];
	CGRect frame;
	if(ISIPHONE)
		frame = CGRectMake(0, 460, 320, 480);
	else
		frame = CGRectMake(0, 1024, 768, 1024);
	
	self.pView = [[UIView alloc] initWithFrame:frame];
	self.pView.backgroundColor = [UIColor clearColor];
	
	if(ISIPHONE)
		frame = CGRectMake(0, 199, 320, 45);
	else
		frame = CGRectMake(0, 723, 768, 65);
	
	NSMutableArray *arr = [[NSMutableArray alloc] init];
	
	UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(cancelPickerView)];
	[arr addObject:item];
	[item release]; item = nil;
	
	item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
	[arr addObject:item];
	[item release]; item = nil;
	
	item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(hidePickerView)];
	[arr addObject:item];
	[item release]; item = nil;
	UIToolbar *toolBar = [[UIToolbar alloc] initWithFrame:frame];
	[toolBar setItems:arr animated:YES];
	
	if(ISIPHONE)
		frame = CGRectMake(0, 244, 320, 216);
	else
		frame = CGRectMake(0, 788, 768, 216);
	
	self.pickerView = [[UIPickerView alloc] initWithFrame:frame];
	self.pickerView.showsSelectionIndicator = YES;
	self.pickerView.delegate = self;
	self.pickerView.dataSource = self;
	
	self.datePicker = [[UIDatePicker alloc] initWithFrame:frame];
	self.datePicker.datePickerMode = UIDatePickerModeDate;
	
	[self.pView addSubview:toolBar];
	
	[self.view addSubview:self.pView];
	
	self.tempDict = [[NSMutableDictionary alloc] init];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return PAYMENT_NO_OF_SECTION;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	switch (section) 
	{
		case 0:
			return 4;
		case 1:
			return 1;
		case 2:
			return 1;
			
	}
	return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	if(indexPath.section == 1) return HEIGHT_FOR_NOTE_ROW;
	return HEIGHT_FOR_ROW;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	//static NSString *cellIdentifier = @"CellID";
	CustomCell *cell = [[[CustomCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil ReadOnly:isReadOnly] autorelease ];
	cell.textField.delegate = self;
	NSDateFormatter *form = nil;
	switch(indexPath.section)
	{			
			
		case 0:					
		switch(indexPath.row)
		{
			case 0:
				cell.label.text = @"Payment Amount :";
				cell.textField.placeholder = @"Payment Amount";
				cell.textField.tag = PAYMENT_AMOUNT;
				cell.textField.keyboardType = UIKeyboardTypeDecimalPad;
				cell.textField.text = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",cell.textField.tag]];
				return cell;
			case 1:
				cell.label.text = @"Payment date: ";
				cell.textField.placeholder = @"mm/dd/yyyy";
				cell.textField.tag = PAYMENT_DATE_PAID;
				cell.textField.text = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",cell.textField.tag]];
				return cell;
			case 2:
				cell.label.text = @"Payment for month:";
				cell.textField.placeholder = @"payment for";
				cell.textField.tag = PAYMENT_FOR;
				cell.textField.text = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",cell.textField.tag]];
				return cell;
			case 3:
				cell.label.text = @"Payment for Year: ";
				form = [[NSDateFormatter alloc] init];
				[form setDateFormat:@"yyyy"];
				
				cell.textField.text = [form stringFromDate:[NSDate date]];
				[form release]; form = nil;
				cell.textField.placeholder = @"yyyy";
				cell.textField.tag = PAYMENT_YEAR;
				cell.textField.keyboardType = UIKeyboardTypeNumberPad;
				if([self.tempDict objectForKey:[NSString stringWithFormat:@"%d",cell.textField.tag]])
					cell.textField.text = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",cell.textField.tag]];
				return cell;
			
		}
			
		case 1:
			[[cell.contentView subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
			cell.textLabel.text = @"NOTE :";
			CGRect frame;
			if(ISIPHONE)
				frame = CGRectMake(100, 5, 200, 122.0);
			else
				frame = CGRectMake(100, 5, 560, 122.0);
			self.txtNote = [[UITextView alloc] initWithFrame:frame];
			self.txtNote.backgroundColor = [UIColor clearColor];
			[cell.contentView addSubview:self.txtNote];
			self.txtNote.delegate = self;
			self.txtNote.tag = PAYMENT_NOTE;
			self.txtNote.userInteractionEnabled = !isReadOnly;
			self.txtNote.text = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",self.txtNote.tag]];
			return cell;

		case 2:
			[[cell.contentView subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
			cell.textLabel.text = @" Click to Send Receipt";
	}
	return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	if(indexPath.section == 2)
	{
		MFMailComposeViewController *controller = [[MFMailComposeViewController alloc] init];
		controller.mailComposeDelegate = self;
		controller.title = @"Payment Receipt";
		[controller setToRecipients:[NSArray arrayWithObject:self.tenant.email?self.tenant.email : @" "]];
		[controller setSubject:@"Payment Receipt."];
		NSString *strAmt = ((CustomCell *)[self.rtPaymentEditTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]]).textField.text;
		NSString *strPaymentOn = ((CustomCell *)[self.rtPaymentEditTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:1 inSection:0]]).textField.text;
		NSString *strPaymentForMonth = ((CustomCell *)[self.rtPaymentEditTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:2 inSection:0]]).textField.text;
		NSString *strPaymentForYear = ((CustomCell *)[self.rtPaymentEditTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:3 inSection:0]]).textField.text;

		NSString *strBody = [NSString stringWithFormat:@"Receipt for $%@ payment on %@ for %@ %@", strAmt, strPaymentOn, strPaymentForMonth, strPaymentForYear];
		[controller setMessageBody:strBody isHTML:NO];
		strAmt = nil;
		strPaymentOn = nil;
		strPaymentForMonth = nil;
		strPaymentForYear = nil;
		controller.modalPresentationStyle=UIModalPresentationFullScreen;
		if(!controller)
		{
			[self launchMailAppOnDevice];
		}
		else 
		{
			[self presentModalViewController:controller animated:YES];
			[controller release]; controller = nil;
		}
	}
}

- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error 
{		
	// Notifies users about errors associated with the interface
	switch (result)
	{
		case MFMailComposeResultCancelled:
			NSLog(@"%@", @"Result: canceled");
			break;
		case MFMailComposeResultSaved:
			NSLog(@"%@", @"Result: saved");
			break;
		case MFMailComposeResultSent:
			NSLog(@"%@", @"Result: sent");
			break;
		case MFMailComposeResultFailed:
			NSLog(@"%@", @"Result: failed");
			break;
		default:
			NSLog(@"%@", @"Result: not sent");
			break;
	}
	[self dismissModalViewControllerAnimated:YES];
}

-(void)launchMailAppOnDevice
{
	NSString *emailBody = @"";
	NSString *recipients = [NSString stringWithFormat:@"mailto:?to=%@&subject=%@",@"",@""];
	NSString *body = [NSString stringWithFormat:@"&body=%@",emailBody];
	
	NSString *email = [NSString stringWithFormat:@"%@%@", recipients, body];
	email = [email stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
	
	[[UIApplication sharedApplication] openURL:[NSURL URLWithString:email]];
}

-(void)addToolBar:(UITextView *)textView
{
	UIToolbar *toolBar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, 100, 35)];
	NSMutableArray *arr = [[NSMutableArray alloc] init];
	UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(ok)];
	[arr addObject:item];
	[item release];item = nil;
	
	item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
	[arr addObject:item];
	[item release];item = nil;
	
	item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(cancel:)];
	[arr addObject:item];
	[item release];item = nil;
	
	toolBar.items = arr;
	
	[arr release];arr = nil;
	
	textView.inputAccessoryView = toolBar;
}

-(void)cancel:(id)sender
{
	self.txtNote.text = @"";
	[self.txtNote resignFirstResponder];
}
-(void)ok
{
	[self.txtNote resignFirstResponder];
}
- (BOOL)textViewShouldBeginEditing:(UITextView *)textView
{
	if(textView.tag == PAYMENT_NOTE)
	{
		[self addToolBar:textView];
		[Utility decreaseHeightOfTableView:self.rtPaymentEditTableView];
	}
	return YES;
}

- (void)textViewDidEndEditing:(UITextView *)textView
{
	CGRect frame = self.rtPaymentEditTableView.frame;
	frame.size.height = 416;
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.3];
	self.rtPaymentEditTableView.frame = frame;
	[UIView commitAnimations];
	if(textView.text)
		[self.tempDict setObject:textView.text forKey:[NSString stringWithFormat:@"%d",textView.tag]];
}


// returns the number of 'columns' to display.
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
	return 1;
}

// returns the # of rows in each component..
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
	return [self.arrayPaymentFor count];
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
	return [self.arrayPaymentFor objectAtIndex:row];
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
	self.tempTextField.text = [self.arrayPaymentFor objectAtIndex:row];
	selectedIndex = row;
}

-(void)hidePickerView
{
	NSDateFormatter *formatter = nil;
	switch (pickerTag) 
	{
		case PICKER:
			self.tempTextField.text = [self.arrayPaymentFor objectAtIndex:selectedIndex];
			break;
		case DATE_PICKER:
			formatter = [[NSDateFormatter alloc] init];
			[formatter setDateFormat:@"MM/dd/yyyy"];
			self.tempTextField.text = [formatter stringFromDate:self.datePicker.date];
			break;
	}
	if(self.tempTextField.text)
		[self.tempDict setObject:self.tempTextField.text forKey:[NSString stringWithFormat:@"%d",self.tempTextField.tag]];
	[Utility hidesDropDown:self.pView];
}

-(void)cancelPickerView
{
	//self.tempTextField.text = @"";
	[Utility hidesDropDown:self.pView];
}

#pragma mark -
#pragma mark TextField Delegate Method

// return NO to disallow editing.
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
	if(textField.tag == PAYMENT_DATE_PAID)
	{
		if([self.pickerView superview])
			[self.pickerView removeFromSuperview];
		if([self.datePicker superview])
			[self.datePicker removeFromSuperview];
		if([self.textFieldToHidePicker isFirstResponder])
		{
			[self.textFieldToHidePicker resignFirstResponder];
			[Utility increaseHeightOfTableView:self.rtPaymentEditTableView];
		}
		
		self.tempTextField = textField;
		pickerTag = DATE_PICKER;
		[self.pView addSubview:self.datePicker];
		[Utility showDropDown:self.pView];
		return NO;
	}
	if(textField.tag == PAYMENT_FOR)
	{
		if([self.pickerView superview])
			[self.pickerView removeFromSuperview];
		if([self.datePicker superview])
			[self.datePicker removeFromSuperview];
		if([self.textFieldToHidePicker isFirstResponder])
		{
			[self.textFieldToHidePicker resignFirstResponder];
			[Utility increaseHeightOfTableView:self.rtPaymentEditTableView];
		}
		
		self.tempTextField = textField;
		pickerTag = PICKER;
		[self.pView addSubview:self.pickerView];
		[Utility showDropDown:self.pView];
		return NO;
	}
	
	[Utility decreaseHeightOfTableView:self.rtPaymentEditTableView];
	self.txtField = textField;
	self.textFieldToHidePicker = textField;
	return YES;
}

// became first responder
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
	
}

// return YES to allow editing to stop and to resign first responder status. NO to disallow the editing session to end
- (BOOL)textFieldShouldEndEditing:(UITextField *)textField         
{
	
	return YES;
}

// may be called if forced even if shouldEndEditing returns NO (e.g. view removed from window) or endEditing:YES called
- (void)textFieldDidEndEditing:(UITextField *)textField             
{
	[self.tempDict setObject:textField.text forKey:[NSString stringWithFormat:@"%d",textField.tag]];
	[textField resignFirstResponder];
}

// called when clear button pressed. return NO to ignore (no notifications)
- (BOOL)textFieldShouldClear:(UITextField *)textField
{
	return YES;
}

// called when 'return' key pressed. return NO to ignore.
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
	[textField resignFirstResponder];
	
	[Utility increaseHeightOfTableView:self.rtPaymentEditTableView];
	
	return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
	if(textField.tag == PAYMENT_AMOUNT)
	{
		NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:VALID_FLOAT] invertedSet];
		NSString *filtered = [[string componentsSeparatedByCharactersInSet:cs] componentsJoinedByString:@""];
		return [string isEqualToString:filtered];
	}
	
	return YES;
}

#pragma mark -
#pragma mark viewWillAppear

-(void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	
	[self fetchManagedObject];
	[self loadValues];
}

-(void)fetchManagedObject
{
	AppDelegate_iPhone *app = (AppDelegate_iPhone *)[[UIApplication sharedApplication] delegate];
	NSPredicate *predicate = [NSPredicate predicateWithFormat:@"self == %@",self.tenant];
	NSMutableArray *arr = [CoreDataHelper searchObjectsInContext:ENTITY_KEY_TENANT :predicate :nil :NO :app.managedObjectContext];
	self.tenant = [arr objectAtIndex:0];
	NSArray *tempArr = [self.tenant.payments allObjects];
	for(Payment *payem in tempArr)
	{
		if([self.payment isEqual:payem])
		{
			self.payment = payem;
			break;
		}
	}
}

-(void)loadValues
{	
	if(self.payment.amount)
		[self.tempDict setValue:self.payment.amount forKey:[NSString stringWithFormat:@"%d",PAYMENT_AMOUNT]];
	
	if(self.payment.datePaid)
		[self.tempDict setValue:self.payment.datePaid forKey:[NSString stringWithFormat:@"%d",PAYMENT_DATE_PAID]];
	
	if(self.payment.note)
		[self.tempDict setValue:self.payment.note forKey:[NSString stringWithFormat:@"%d",PAYMENT_NOTE]];
	
	if(self.payment.paymentFor)
		[self.tempDict setValue:self.payment.paymentFor forKey:[NSString stringWithFormat:@"%d",PAYMENT_FOR]];
	
	if(self.payment.year)
		[self.tempDict setValue:self.payment.year forKey:[NSString stringWithFormat:@"%d",PAYMENT_YEAR]];
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    self.txtField = nil;
    [super dealloc];
}


@end
