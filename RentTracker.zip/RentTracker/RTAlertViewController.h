//
//  RTAlertViewController.h
//  RentTracker
//
//  Created by ASHIM SAMANTA on 07/03/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface RTAlertViewController : UIViewController {

	UITableView *rtAlertTableView_;
	
	NSMutableArray *searchText_;
	UISegmentedControl *segmentController_;
	
	NSMutableArray *array_;
	NSMutableDictionary *resultdict_;
	
	NSArray *arr_;
	
	NSMutableArray *arrOfTenant_;
	
}
@property (nonatomic, retain) IBOutlet UITableView *rtAlertTableView;
@property (nonatomic, retain) NSMutableArray *searchText;

@property (nonatomic, retain) NSMutableArray *array;
@property (nonatomic, retain) NSMutableDictionary *resultdict;

@property (nonatomic, retain) NSArray *arr;

@property (nonatomic, retain) NSMutableArray *arrOfTenant;
@property (nonatomic, assign) BOOL isLateTenant;
@end
