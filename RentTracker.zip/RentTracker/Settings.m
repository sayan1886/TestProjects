//
//  Settings.m
//  RentTracker
//
//  Created by Manas Kumar Mandal on 18/04/12.
//  Copyright (c) 2012 ObjectSol Technologies. All rights reserved.
//

#import "Settings.h"


@implementation Settings

@dynamic logo;
@dynamic country;
@dynamic street;
@dynamic town;
@dynamic compName;
@dynamic propertyExperts;

@end
