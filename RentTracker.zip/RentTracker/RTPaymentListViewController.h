//
//  RTPaymentListViewController.h
//  RentTracker
//
//  Created by ASHIM SAMANTA on 23/03/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Tenant.h"

@interface RTPaymentListViewController : UIViewController 
{
	UITableView *rtPaymentListTableView_;
	NSMutableArray *searchText_;
	Tenant *tenant_;
	
	NSMutableDictionary *resultdict_;
	NSArray *arr_;
	NSArray *array_;
}

@property (nonatomic, retain) IBOutlet UITableView *rtPaymentListTableView;
@property (nonatomic, retain) NSMutableArray *searchText;
@property (nonatomic, retain) Tenant *tenant;
@property (nonatomic, retain) NSMutableDictionary *resultdict;
@property (nonatomic, retain) NSArray *arr;
@property (nonatomic, retain) NSArray *array;

-(void)getValues;
-(NSMutableDictionary *)groupPayments:(NSArray *)arrToSort;
-(NSArray *)sortPaymentByDate:(NSArray *)arrayToSort;
-(int)monthNumber:(NSString *)text;
-(NSArray *)sortArrayForMonth:(NSArray *)arrToSort;

@end
