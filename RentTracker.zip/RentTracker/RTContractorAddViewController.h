//
//  RTContractorAddViewController.h
//  RentTracker
//
//  Created by ASHIM SAMANTA on 06/03/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ImagePicker.h"

@interface RTContractorAddViewController : UIViewController<UITableViewDelegate, UITableViewDataSource,
											UITextFieldDelegate, UITextViewDelegate, CaptureImage> 
{
	UITableView *rtContractorAddTableView_;
	NSMutableDictionary *tempDict_;
	UIButton * btn;
	
	UITextView *tempTextView;
	
	UITextField *name_;
	
	UITextField *txtFld;
}
@property (nonatomic, retain) IBOutlet UITableView *rtContractorAddTableView;
@property (nonatomic, retain) NSMutableDictionary *tempDict;
@property (nonatomic, retain) UITextField *name;
@property (nonatomic, retain) UIButton * btn;
@property (nonatomic, retain) UITextField *txtFld;

@end
