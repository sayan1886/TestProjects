//
//  untitled.h
//  RentTracker
//
//  Created by ASHIM SAMANTA on 02/03/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface CustomCell : UITableViewCell<UITextFieldDelegate> {
	
	UILabel *_label;
	UITextField *_textField;
	
	UIFont *labFont;
}

@property (nonatomic, retain) IBOutlet UILabel *label;
@property (nonatomic, retain) IBOutlet UITextField *textField;
@property (nonatomic) BOOL isReadOnly;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier ReadOnly:(BOOL)readOnly;

@end
