//
//  RTReportSettingViewController.m
//  RentTracker
//
//  Created by ASHIM SAMANTA on 28/03/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import "RTReportSettingViewController.h"
#import "UIImage+TKCategory.h"
#import "Constant.h"
#import "AppDelegate_iPhone.h"
#import "CoreDataHelper.h"
#import "Settings.h"
#import "NSManagedObjectContext+insert.h"

@implementation RTReportSettingViewController

@synthesize compName = compName_;
@synthesize propExperts = propExperts_;
@synthesize street = street_;
@synthesize town = town_;
@synthesize country = country_;
@synthesize logoView = logoView_;
@synthesize setting = setting_;

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
#pragma mark -
#pragma mark selectLogo

-(IBAction)selectLogo:(id)sender
{
	UIButton *btn = (UIButton *)sender;
	btn.selected = !btn.selected;
	if(btn.selected)
		[self takePicture];
	else
		self.logoView.image = nil;
}

-(IBAction)appLogo:(id)sender
{
	self.logoView.image = [UIImage imageNamed:@"icon.png"];
}

-(void)takePicture
{
	ImagePicker *picker = [[ImagePicker alloc] init] ;
	picker.delegate = self;
	picker.vc = self;
	[picker clickAddPictureAtViewController:self.view];
}

-(void) didReceivePicture:(UIImage *)img
{
	img = [img fixOrientation];
	self.logoView.image = img;
}

-(void)loadSettings
{
	AppDelegate_iPhone *app = (AppDelegate_iPhone *)[[UIApplication sharedApplication]delegate];
	NSMutableArray *tempArr = [CoreDataHelper getObjectsFromContext:ENTITY_KEY_SETTINGS :nil :YES :app.managedObjectContext];
	if(tempArr && ([tempArr count] > 0))
	{
		self.setting = [tempArr lastObject];
		if(self.setting.logo)
			self.logoView.image = [UIImage imageWithData:self.setting.logo];
		self.town.text = self.setting.town;
		self.propExperts.text = self.setting.propertyExperts;
		self.street.text = self.setting.street;
		self.compName.text = self.setting.compName;
		self.country.text = self.setting.country;
	}
	tempArr = nil;
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	[self loadSettings];
}

-(void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
	
	[self saveData];
}

-(void)saveData
{
	AppDelegate_iPhone *app = (AppDelegate_iPhone *)[[UIApplication sharedApplication]delegate];
	if(!self.setting)
		self.setting = (Settings *)[app.managedObjectContext insertNewEntityWithName:ENTITY_KEY_SETTINGS];
	self.setting.logo = UIImagePNGRepresentation(self.logoView.image);
	self.setting.town = self.town.text;
	self.setting.propertyExperts = self.propExperts.text;
	self.setting.street = self.street.text;
	self.setting.compName = self.compName.text;
	self.setting.country = self.country.text;
	[app saveContext];
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
	CGRect frame = self.view.frame;
	frame.origin.y = -90;
	[UIView beginAnimations:nil context:nil	];
	[UIView setAnimationDuration:0.30];
	self.view.frame = frame;
	[UIView commitAnimations];
	return YES;
}
          
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
	CGRect frame = self.view.frame;
	frame.origin.y = 0;
	[UIView beginAnimations:nil context:nil	];
	[UIView setAnimationDuration:0.30];
	self.view.frame = frame;
	[UIView commitAnimations];
	[textField resignFirstResponder];
	return YES;
}
/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
