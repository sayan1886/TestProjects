//
//  RTTenantAddViewController.m
//  RentTracker
//
//  Created by ASHIM SAMANTA on 29/02/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import "RTTenantAddViewController.h"
#import "AppDelegate_iPhone.h"
#import "CustomCell.h"
#import "Constant.h"
#import "Utility.h"
#import "CoreDataHelper.h"
#import "Tenant.h"
#import "Building.h"
#import "NSManagedObjectContext+insert.h"
#import "UIImage+TKCategory.h"


@implementation RTTenantAddViewController
@synthesize rtTAddTableView = rtTAddTableView_;
@synthesize rtTAddTableViewFirst = rtTAddTableViewFirst_;
@synthesize rtAddScrollView = rtAddScrollView_;
@synthesize tempDict = tempDict_;
@synthesize btnIcon = btnIcon_;
@synthesize array = array_;
@synthesize buildingArray = buildingArray_;

@synthesize address = address_;
@synthesize city = city_;
@synthesize state = state_;
@synthesize postalCode = postalCode_;
@synthesize datePicker = datePicker_;
@synthesize depPaidDate = depPaidDate_;
@synthesize moveInDate = moveInDate_;

@synthesize building = building_;
@synthesize fName = fName_;
@synthesize lName = lName_;
@synthesize rentAmount = rentAmount_;

@synthesize note = note_;
@synthesize txtPickerField = txtPickerField_;

@synthesize rentDayArray = rentDayArray_;
@synthesize rentDueDay = rentDueDay_;
@synthesize leasePeriodArray = leasePeriodArray_;
@synthesize rentLeasePeriod = rentLeasePeriod_;
@synthesize txtLeaseStartDate = txtLeaseStartDate_;

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
		self.title = @"Add Tenant";
        UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(done:)];
		self.navigationItem.rightBarButtonItem = item;
		[item release];
		
    }
    return self;
}

-(BOOL)hasNameBuildingAndRentAmount
{
	NSString *fText = self.fName.text;
	NSString *lText = self.lName.text;
	NSString *bText = self.building.text;
	NSString *rText = self.rentAmount.text;
	NSString *rDueDay = self.rentDueDay.text;
    
    NSString *leaseStartDate = self.txtLeaseStartDate.text;
    NSString *rentPeriod = self.rentLeasePeriod.text;
    
	if(!fText) return NO;
	if(!lText) return NO;
	if(!bText) return NO;
	if(!rText) return NO;
	if(!rDueDay) return NO;
    
    if(!leaseStartDate) return NO;
	if(!rentPeriod) return NO;
	
	fText = [fText stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	lText = [lText stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	bText = [bText stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	rText = [rText stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	rDueDay = [rDueDay stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    leaseStartDate = [leaseStartDate stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	rentPeriod = [rentPeriod stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
	return (([fText length] > 0) && ([lText length] > 0) && ([bText length] > 0) && ([rText length] > 0) && ([rDueDay length] > 0)&& ([leaseStartDate length] > 0)&& ([rentPeriod length] > 0));
}

-(void)done:(id)sender
{
	if([tempTextField isFirstResponder])
		[tempTextField resignFirstResponder];
	if([self.note isFirstResponder])
		[self.note resignFirstResponder];
	NSLog(@" Temp Dict = %@", self.tempDict);
	if(![self hasNameBuildingAndRentAmount])
	{
		[Utility showAlertViewWithTitle:TITLE_MANDATORY_FIELD Message:MESSAGE_TENANT_MANDATORY_FIELD CancelTitle:CANCEL_TITLE];
		return ;
	}
	
	AppDelegate_iPhone *appDelegate =  (AppDelegate_iPhone *)[[UIApplication sharedApplication] delegate];
	Tenant *tenant = (Tenant *)[appDelegate.managedObjectContext insertNewEntityWithName:ENTITY_KEY_TENANT];
	NSString *key = [NSString stringWithFormat:@"%d",BUILDING];
	if(tenant && self.tempDict)
	{
		if ([self.tempDict objectForKey:KEY_IMAGE]) 
		{
			UIImage *img = [self.tempDict objectForKey:KEY_IMAGE];
			NSData *data = UIImagePNGRepresentation(img);
			tenant.image = data;
		}
		if([self.tempDict objectForKey:key])
		{
			if(selectedIndex != NSNotFound)
				tenant.building = [self.buildingArray objectAtIndex:selectedIndex];
		}
		key = nil;
		key = [NSString stringWithFormat:@"%d",FIRST];
			tenant.first = [self.tempDict objectForKey:key];
		key = nil;
		key = [NSString stringWithFormat:@"%d",LAST];
			tenant.last = [self.tempDict objectForKey:key];
		key = nil;
		key = [NSString stringWithFormat:@"%d",ADDRESS];
			tenant.address = [self.tempDict objectForKey:key];
		key = nil;
		key = [NSString stringWithFormat:@"%d",CITY];
			tenant.city = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",CITY]];
		key = nil;
		key = [NSString stringWithFormat:@"%d",STATE];
			tenant.state = [self.tempDict objectForKey:key];
		key = nil;
		key = [NSString stringWithFormat:@"%d",POSTALCODE];
			tenant.postal_code = [self.tempDict objectForKey:key];
		key = nil;
		key = [NSString stringWithFormat:@"%d",HOME_PHONE];
		
			tenant.home_phone = [self.tempDict objectForKey:key];
		key = nil;
		key = [NSString stringWithFormat:@"%d",WORK_PHONE];
			tenant.work_phone = [self.tempDict objectForKey:key];
		key = nil;
		key = [NSString stringWithFormat:@"%d",MOBILE];
			tenant.mobile = [self.tempDict objectForKey:key];
		key = nil;
		key = [NSString stringWithFormat:@"%d",RENT_AMT];
		tenant.rentAmount = [self.tempDict objectForKey:key];
		
		key = nil;
		key = [NSString stringWithFormat:@"%d",DEPOSIT_AMT];
			tenant.deposit_amount = [self.tempDict objectForKey:key];
		key = nil;
		key = [NSString stringWithFormat:@"%d",DEP_PAID_DATE];
		tenant.dep_paid_date = [self.tempDict objectForKey:key];

		tenant.moveOut = [NSString stringWithString:isMoveOut ? @"YES":@"NO"];
		
		key = nil;
		key = [NSString stringWithFormat:@"%d",MOVE_IN_DATE];
		tenant.move_in_date = [self.tempDict objectForKey:key];
		key = nil;
		key = [NSString stringWithFormat:@"%d",EMAIL];
		tenant.email = [self.tempDict objectForKey:key];
		key = nil;
		key = [NSString stringWithFormat:@"%d",NOTE];
		tenant.note = [self.tempDict objectForKey:key];
		key = nil;
		key = [NSString stringWithFormat:@"%d",LEASE_PERIOD];
		tenant.leasePeriod = [self.tempDict objectForKey:key];
		
		key = nil;
		key = [NSString stringWithFormat:@"%d",LEASE_START_DATE];

		tenant.leaseStartDate = [self.tempDict objectForKey:key];
		
		key = nil;
		key = [NSString stringWithFormat:@"%d",RENT_DUE_DAY];
		tenant.rentDueDay = [self.tempDict objectForKey:key];
		key = nil;
		[appDelegate saveContext];
	}
	NSUserDefaults *standardDefaults = [NSUserDefaults standardUserDefaults];
    NSInteger numberOfTenantAdded = [standardDefaults integerForKey:TOTAL_ADDED_TENANT];
    
    numberOfTenantAdded++;
    [standardDefaults setInteger:numberOfTenantAdded forKey:TOTAL_ADDED_TENANT];
    [standardDefaults synchronize];
	[self.navigationController popViewControllerAnimated:YES];
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	isMoveOut = NO;
	
	selectedIndex = NSNotFound;
	self.leasePeriodArray = [[NSMutableArray alloc] init];
	self.rentDayArray = [[NSMutableArray alloc] init];
	for(int ii = 1; ii <= 31; ii++)
	{
		[self.rentDayArray addObject:[NSString stringWithFormat:@"%d",ii]];
		[self.leasePeriodArray addObject:[NSString stringWithFormat:@"%d year",ii]];
	}
	CGRect frame;
	if(ISIPHONE)
		self.rtAddScrollView.contentSize = CGSizeMake(320, 1150);
	else
		self.rtAddScrollView.contentSize = CGSizeMake(768, 1200);

	self.tempDict = [[NSMutableDictionary alloc] init];
	
	if(ISIPHONE)
		frame = CGRectMake(0, 460, 320, 480);
	else
		frame = CGRectMake(0, 1024, 768, 1024);
	
	pView = [[UIView alloc] initWithFrame:frame];
	pView.backgroundColor = [UIColor clearColor];
	
	if(ISIPHONE)
		frame = CGRectMake(0, 199, 320, 45);
	else
		frame = CGRectMake(0, 723, 768, 65);
	
	NSMutableArray *arr = [[NSMutableArray alloc] init];
	
	UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(cancelPickerView)];
	[arr addObject:item];
	[item release]; item = nil;
	
	item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
	[arr addObject:item];
	[item release]; item = nil;
	
	item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(hidePickerView)];
	[arr addObject:item];
	[item release]; item = nil;
	UIToolbar *toolBar = [[UIToolbar alloc] initWithFrame:frame];
	[toolBar setItems:arr animated:YES];
	
	if(ISIPHONE)
		frame = CGRectMake(0, 244, 320, 216);
	else
		frame = CGRectMake(0, 788, 768, 216);
	
	pickerView = [[UIPickerView alloc] initWithFrame:frame];
	pickerView.showsSelectionIndicator = YES;
	pickerView.delegate = self;
	pickerView.dataSource = self;
	
	self.datePicker = [[UIDatePicker alloc] initWithFrame:frame];
	self.datePicker.datePickerMode = UIDatePickerModeDate;
	[pView addSubview:toolBar];

	[self.view addSubview:pView];
	[self fetchData];
	
	[toolBar release];
	[arr release];
}

-(void)fetchData
{
	AppDelegate_iPhone *app = (AppDelegate_iPhone *)[[UIApplication sharedApplication]delegate];
	
	self.buildingArray = [CoreDataHelper getObjectsFromContext:ENTITY_KEY_BUILDING :@"address" :YES :app.managedObjectContext];
	
	self.array = [[NSMutableArray alloc] init];
	
	for(Building *building in self.buildingArray)
	{
		if(building.address)
		{
			NSString *text = building.address;
			[self.array addObject:text];
		}
	}
	[pickerView reloadAllComponents];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	if([tableView isEqual:self.rtTAddTableViewFirst])
		return 1;
	return TENANT_NO_OF_SECTION;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	if([tableView isEqual:self.rtTAddTableViewFirst])
		return 3;
	
	switch (section) 
	{
		case 0:
		case 1:
		case 2:
			return 4;
		case 3:
			return 3;
		case 4:
			return 1;
		case 5:
			return 1;
	}
	return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	if(indexPath.section==5)
		return HEIGHT_FOR_NOTE_ROW;
	return HEIGHT_FOR_ROW;
	
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{	
	CustomCell *cell = nil;
	 
	if([tableView isEqual:self.rtTAddTableViewFirst])
	{
		CGRect frame;
		cell = [Utility cellForRowAtPathForTenantFirstTableView:indexPath isReadOnly:NO];

		frame = cell.textField.frame;
		frame.origin.x -=100;
		frame.size.width+=20;
		cell.textField.frame = frame;
		if(cell.textField.tag == FIRST)
			self.fName = cell.textField;
		else if(cell.textField.tag == LAST)
			self.lName = cell.textField;
		else if(cell.textField.tag == BUILDING)
			self.building = cell.textField;
		
	}
	else
	{
		cell = [Utility cellForRowAtPathForTenantSecondTableView:indexPath isReadOnly:NO];
		
		if(cell.textField.tag == ADDRESS)
			self.address = cell.textField;
		else if(cell.textField.tag == CITY)
			self.city = cell.textField;
		else if(cell.textField.tag == STATE)
			self.state = cell.textField;
		else if(cell.textField.tag == POSTALCODE)
			self.postalCode = cell.textField;
		else if(cell.textField.tag == DEP_PAID_DATE)
			self.depPaidDate = cell.textField;
		else if(cell.textField.tag == MOVE_IN_DATE)
			self.moveInDate = cell.textField;
		else if(cell.textField.tag == RENT_AMT)
			self.rentAmount = cell.textField;
		else if(cell.textField.tag == LEASE_START_DATE)
			self.txtLeaseStartDate = cell.textField;
		else if(cell.textField.tag == LEASE_PERIOD)
			self.rentLeasePeriod = cell.textField;
		else if(cell.textField.tag == RENT_DUE_DAY)
			self.rentDueDay = cell.textField;
		else if(cell.textField.tag == MOVE_OUT)
		{
			[[cell.contentView subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
			cell.textLabel.text = @"Tenant Move Out : ";
			if(isMoveOut)
				cell.accessoryType = UITableViewCellAccessoryCheckmark;
			else
				cell.accessoryType = UITableViewCellAccessoryNone;
		}
	}
	
	cell.textField.text = [self.tempDict valueForKey:[NSString stringWithFormat:@"%d",cell.textField.tag]];

	cell.textField.delegate = self;
	if(cell.textField.tag == NOTE)
	{
		[[cell.contentView subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
		cell.textLabel.text = @"NOTE :";
		CGRect frame;
		if(ISIPHONE)
			frame = CGRectMake(100, 5, 200, 122.0);
		else
			frame = CGRectMake(100, 5, 560, 122.0);
		self.note = [[UITextView alloc] initWithFrame:frame];
		self.note.backgroundColor = [UIColor clearColor];
		[cell.contentView addSubview:self.note];
		self.note.delegate = self;
		self.note.tag = NOTE;
		self.note.text = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",self.note.tag]];
	}
	return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	if(indexPath.section == 4)
	{
		isMoveOut = !isMoveOut;
		[tableView reloadData];
	}
}

-(IBAction)addPhoto:(id)sender
{
	btn = (UIButton *)sender;
	ImagePicker *picker = [[ImagePicker alloc] init];
	picker.delegate = self;
	picker.vc = self;
	[picker clickAddPictureAtViewController:[btn superview]];
}

-(void) didReceivePicture:(UIImage *)img
{
	img = [img fixOrientation];
	[self.tempDict setObject:img forKey:KEY_IMAGE];
	[btn setImage:img forState:UIControlStateNormal];
}

// returns the number of 'columns' to display.
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
	return 1;
}

// returns the # of rows in each component..
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
	if(pickerTag == RENT_DUE_DAY_PICKER)
		return [self.rentDayArray count];
	else if(pickerTag == LEASE_PERIOD_PICKER)
		return [self.leasePeriodArray count];
	return [self.array count];
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
	if(pickerTag == RENT_DUE_DAY_PICKER)
		return [self.rentDayArray objectAtIndex:row];
	else if(pickerTag == LEASE_PERIOD_PICKER)
		return [self.leasePeriodArray objectAtIndex:row];
	return [self.array objectAtIndex:row];
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
	if(pickerTag == RENT_DUE_DAY_PICKER)
	{
		self.rentDueDay.text = [self.rentDayArray objectAtIndex:row];
		[self.tempDict setObject:self.rentDueDay.text forKey:[NSString stringWithFormat:@"%d",self.rentDueDay.tag]];
		return ;
	}
	else if(pickerTag == LEASE_PERIOD_PICKER)
	{
		self.rentLeasePeriod.text = [self.leasePeriodArray objectAtIndex:row];
		[self.tempDict setObject:self.rentLeasePeriod.text forKey:[NSString stringWithFormat:@"%d",self.rentLeasePeriod.tag]];
		return ;
	}
	Building *building = [self.buildingArray objectAtIndex:row];
	self.address.text = building.address;
	self.city.text = building.city;
	self.state.text = building.state;
	self.postalCode.text = building.postal_code;
	
	tempTextField.text = [self.array objectAtIndex:row];
	selectedIndex = row;
}

-(void)cancelPickerView
{
	/*tempTextField.text = @"";
	self.address.text = @"";
	self.city.text = @"";
	self.state.text = @"";
	self.postalCode.text = @"";*/
	[Utility hidesDropDown:pView];
}


-(void)hidePickerView
{
	NSDateFormatter	*formater = nil;
	switch(pickerTag)
	{
		case DATE_PICKER:
			formater = [[NSDateFormatter alloc] init];
			[formater setDateFormat:@"MM/dd/yyyy"];
			tempTextField.text = [formater stringFromDate:self.datePicker.date];
			[self.tempDict setObject:tempTextField.text forKey:[NSString stringWithFormat:@"%d",tempTextField.tag]];
			break;
			
		case PICKER:
			if(self.address.text)
				[self.tempDict setObject:tempTextField.text?tempTextField.text : @"" forKey:[NSString stringWithFormat:@"%d",BUILDING]];
			if(self.address.text)
				[self.tempDict setObject:self.address.text forKey:[NSString stringWithFormat:@"%d",ADDRESS]];
			if(self.city.text)
				[self.tempDict setObject:self.city.text forKey:[NSString stringWithFormat:@"%d",CITY]];
			if(self.state.text)
				[self.tempDict setObject:self.state.text forKey:[NSString stringWithFormat:@"%d",STATE]];
			if(self.postalCode.text)
				[self.tempDict setObject:self.postalCode.text forKey:[NSString stringWithFormat:@"%d",POSTALCODE]];
			break;
	}
	[Utility hidesDropDown:pView];
}

#pragma mark -
#pragma mark TextField Delegate Method

// return NO to disallow editing.
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
	if(textField.tag == BUILDING)
	{
		if([tempTextField isFirstResponder])
			[tempTextField resignFirstResponder];
		if([self.note isFirstResponder])
			[self.note resignFirstResponder];
		tempTextField = textField;
		pickerTag = PICKER;
		
		if([pickerView superview])
			[pickerView removeFromSuperview];
		if([self.datePicker superview])
			[self.datePicker removeFromSuperview];
		[pickerView reloadAllComponents];
		[pickerView selectRow:0 inComponent:0 animated:YES];
		selectedIndex = 0;
		Building *building = [self.buildingArray objectAtIndex:selectedIndex];
		self.address.text = building.address;
		self.city.text = building.city;
		self.state.text = building.state;
		self.postalCode.text = building.postal_code;
		[self.tempDict setObject:building.address forKey:[NSString stringWithFormat:@"%d",BUILDING]];
		tempTextField.text = [self.array objectAtIndex:selectedIndex];
		
		[pView addSubview:pickerView];
		[Utility showDropDown:pView];
		return NO;
	}
	
	if((textField.tag == HOME_PHONE) || (textField.tag == WORK_PHONE))
	{
		[UIView beginAnimations:nil context:nil];
		[UIView setAnimationBeginsFromCurrentState:YES];
		[UIView setAnimationDuration:0.30];
		[self.rtAddScrollView setContentOffset:CGPointMake(0, 390)];
		[UIView commitAnimations];
	}
	if((textField.tag == MOBILE) || (textField.tag == EMAIL))
	{
		[UIView beginAnimations:nil context:nil];
		[UIView setAnimationBeginsFromCurrentState:YES];
		[UIView setAnimationDuration:0.30];
		[self.rtAddScrollView setContentOffset:CGPointMake(0, 480)];
		[UIView commitAnimations];
	}
			
	if((textField.tag == MOVE_IN_DATE) || (textField.tag == DEP_PAID_DATE) || (textField.tag == LEASE_START_DATE))
	{
		if([self.note isFirstResponder])
			[self.note resignFirstResponder];
		if([tempTextField isFirstResponder])
			[tempTextField resignFirstResponder];
		tempTextField = textField;
		pickerTag = DATE_PICKER;
	
		if([pickerView superview])
			[pickerView removeFromSuperview];
		if([self.datePicker superview])
			[self.datePicker removeFromSuperview];
	
		[pView addSubview:self.datePicker];
		[Utility showDropDown:pView];
		return NO;
	}
	if(textField.tag == RENT_DUE_DAY)
	{
		if([self.note isFirstResponder])
			[self.note resignFirstResponder];
		if([tempTextField isFirstResponder])
			[tempTextField resignFirstResponder];
		tempTextField = textField;
		pickerTag = RENT_DUE_DAY_PICKER;

		if([pickerView superview])
			[pickerView removeFromSuperview];
		if([self.datePicker superview])
			[self.datePicker removeFromSuperview];
		[pickerView reloadAllComponents];
		[pickerView selectRow:0 inComponent:0 animated:YES];
		[self pickerView:pickerView didSelectRow:0 inComponent:0];
		textField.text = [self.rentDayArray objectAtIndex:0];
		[self.tempDict setObject:textField.text forKey:[NSString stringWithFormat:@"%d",self.rentDueDay.tag]];
		
		
		[pView addSubview:pickerView];
		[Utility showDropDown:pView];
		return NO;
	}
	if(textField.tag == LEASE_PERIOD)
	{
		if([self.note isFirstResponder])
			[self.note resignFirstResponder];
		if([tempTextField isFirstResponder])
			[tempTextField resignFirstResponder];
		tempTextField = textField;
		pickerTag = LEASE_PERIOD_PICKER;
		
		if([pickerView superview])
			[pickerView removeFromSuperview];
		if([self.datePicker superview])
			[self.datePicker removeFromSuperview];
		[pickerView reloadAllComponents];
		
		[pickerView selectRow:0 inComponent:0 animated:YES];
		[self pickerView:pickerView didSelectRow:0 inComponent:0];
		textField.text = [self.leasePeriodArray objectAtIndex:0];
		[self.tempDict setObject:textField.text forKey:[NSString stringWithFormat:@"%d",textField.tag]];
		
		[pView addSubview:pickerView];
		[Utility showDropDown:pView];
		return NO;
	}
	tempTextField = textField;
	return YES;
}


- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
	if((textField.tag == HOME_PHONE) || (textField.tag == WORK_PHONE) || (textField.tag == MOBILE))
	{
		[Utility formatPhoneNumber:textField withRange:range replacementString:string];
		NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:VALID_INTEGER] invertedSet];
		NSString *filtered = [[string componentsSeparatedByCharactersInSet:cs] componentsJoinedByString:@""];
		return [string isEqualToString:filtered];
	}
	else if((textField.tag == DEPOSIT_AMT) || (textField.tag == RENT_AMT))
	{
		NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:VALID_FLOAT] invertedSet];
		NSString *filtered = [[string componentsSeparatedByCharactersInSet:cs] componentsJoinedByString:@""];
		return [string isEqualToString:filtered];
	}
	
	return YES;
}

 // became first responder
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
	
}

// return YES to allow editing to stop and to resign first responder status. NO to disallow the editing session to end
- (BOOL)textFieldShouldEndEditing:(UITextField *)textField         
{
	
	return YES;
}

// may be called if forced even if shouldEndEditing returns NO (e.g. view removed from window) or endEditing:YES called
- (void)textFieldDidEndEditing:(UITextField *)textField             
{
	[self.tempDict setObject:textField.text forKey:[NSString stringWithFormat:@"%d",textField.tag]];
	
}

// called when clear button pressed. return NO to ignore (no notifications)
- (BOOL)textFieldShouldClear:(UITextField *)textField
{
	return YES;
}

 // called when 'return' key pressed. return NO to ignore.
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationBeginsFromCurrentState:YES];
	[UIView setAnimationDuration:0.30];
	[self.rtAddScrollView setContentOffset:CGPointMake(0, 0)];
	[UIView commitAnimations];
	[textField resignFirstResponder];
	return YES;
}

#pragma mark -
#pragma mark TextView Delegate

- (BOOL)textViewShouldBeginEditing:(UITextView *)textView
{
	if(textView.tag == NOTE)
	{
		[self addToolBar:textView];
		[UIView beginAnimations:nil context:nil];
		[UIView setAnimationBeginsFromCurrentState:YES];
		[UIView setAnimationDuration:0.30];
		if(ISIPHONE)
			[self.rtAddScrollView setContentOffset:CGPointMake(0, 990)];
		else
			[self.rtAddScrollView setContentOffset:CGPointMake(0, 525)];
		[UIView commitAnimations];
		return YES;
	}
	return YES;
}

- (void)textViewDidEndEditing:(UITextView *)textView
{
	if([textView.text length])
		[self.tempDict setObject:textView.text forKey:[NSString stringWithFormat:@"%d",textView.tag]];
}

#pragma mark -
#pragma mark toolBar for Note
-(void)addToolBar:(UITextView *)textView
{
	UIToolbar *toolBar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, 100, 35)];
	NSMutableArray *arr = [[NSMutableArray alloc] init];
	UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(ok)];
	[arr addObject:item];
	item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
	[arr addObject:item];
	item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(cancel:)];
	[arr addObject:item];
	
	toolBar.items = arr;
	[item release];item = nil;
	[arr release];arr = nil;
	
	textView.inputAccessoryView = toolBar;
}

-(void)cancel:(id)sender
{
	self.note.text = @"";
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationBeginsFromCurrentState:YES];
	[UIView setAnimationDuration:0.30];
	[self.rtAddScrollView setContentOffset:CGPointMake(0,0)];
	[UIView commitAnimations];
	[self.note resignFirstResponder];
}
-(void)ok
{
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationBeginsFromCurrentState:YES];
	[UIView setAnimationDuration:0.30];
	[self.rtAddScrollView setContentOffset:CGPointMake(0,0)];
	[UIView commitAnimations];
	
	[self.note resignFirstResponder];
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
//	[tempDict_ release]; tempDict_ = nil;
//	[buildingArray_ release]; buildingArray_ = nil;
//	[array_ release]; array_ = nil;
} 

- (void)viewDidUnload {
    [super viewDidUnload];
	// Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
	
	self.rtTAddTableView = nil;
	self.rtTAddTableViewFirst = nil;
	self.rtAddScrollView = nil;
	self.tempDict = nil; 
	//self.btnIcon = nil;
	
	self.address = nil;
	self.city = nil;
	self.state = nil;
	self.postalCode = nil;
	
	self.array = nil;
	self.buildingArray = nil;
	self.datePicker = nil;
	
	self.depPaidDate = nil;
	self.moveInDate  = nil;
	
	self.building = nil;
	self.fName = nil;
	self.lName = nil;
	self.rentAmount = nil;
	
	self.note = nil;
	self.txtPickerField = nil;
	
	self.rentDayArray = nil;
	self.rentDueDay = nil;
	self.leasePeriodArray = nil;
	self.rentLeasePeriod = nil;
	self.txtLeaseStartDate = nil;
    
}


- (void)dealloc {
	
	self.rtTAddTableView = nil;
	self.rtTAddTableViewFirst = nil;
	self.rtAddScrollView = nil;
	self.tempDict = nil; 
	
	self.btnIcon = nil;
	self.address = nil;
	self.city = nil;
	self.state = nil;
	self.postalCode = nil;
	
	self.array = nil;
	self.buildingArray = nil;
	self.datePicker = nil;
	
	self.depPaidDate = nil;
	self.moveInDate  = nil;
	self.building = nil;
	self.fName = nil;
	self.lName = nil;
	rentAmount_ = nil;
	self.note = nil;
	self.txtPickerField = nil;
	
	self.rentDayArray = nil;
	self.rentDueDay = nil;
	self.leasePeriodArray = nil;
	self.rentLeasePeriod = nil;
	self.txtLeaseStartDate = nil;
	
	[super dealloc];
}


@end
