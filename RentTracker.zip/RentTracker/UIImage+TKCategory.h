//
//  RentTracker
//
//  Created by ASHIM SAMANTA on 28/02/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (TKCategory)


- (UIImage *)fixOrientation;


@end

