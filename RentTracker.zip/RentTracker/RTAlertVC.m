//
//  RTAlertVC.m
//  RentTracker
//
//  Created by Manas Kumar Mandal on 13/06/12.
//  Copyright (c) 2012 ObjectSol Technologies. All rights reserved.
//

#import "RTAlertVC.h"
#import "Constant.h"
#import "Utility.h"
#import "Tenant.h"
#import "RTAlertViewController.h"

@implementation RTAlertVC

@synthesize aTableView;
@synthesize arr;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"Alert";
    }
    return self;
}

#pragma mark -
#pragma mark TableView delegate method

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
	return HEIGHT_FOR_HEADER;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	return [self.arr count];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	static NSString *cellID = @"cellID";
		
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID] ;
	if(!cell)
	{
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID] autorelease];
		
	}
	cell.textLabel.text = [self.arr objectAtIndex:indexPath.row];
	return cell ;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
	RTAlertViewController *vc = [[RTAlertViewController alloc] initWithNibName:@"RTAlertViewController" bundle:nil];
    if(indexPath.row == 0)
        vc.isLateTenant = YES;
    else
        vc.isLateTenant = NO;
    [self.navigationController pushViewController:vc animated:YES];
    [vc release]; vc = nil;
	
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.arr = [[NSMutableArray alloc] initWithObjects:@"LATE TENANTS", @"EXPIRED LEASES", nil];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [self setATableView:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)dealloc {
    [aTableView release];
    [super dealloc];
}
@end
