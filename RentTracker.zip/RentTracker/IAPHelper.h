//
//  IAPHelper.h
//  TestInAppPurchase
//
//  Created by ASHIM SAMANTA on 09/02/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <StoreKit/StoreKit.h>

#define kProductsLoadedNotification         @"ProductsLoaded"
#define kProductPurchasedNotification       @"ProductPurchased"
#define kProductPurchaseFailedNotification  @"ProductPurchaseFailed"
#define kSharedSecret						  @"bea12eb07dd843b79eb76a5c905a33fd"	

@interface IAPHelper : NSObject <SKProductsRequestDelegate, SKPaymentTransactionObserver> 
{
	NSSet * _productIdentifiers;    
    NSArray * _products;
    NSMutableSet * _purchasedProducts;
    SKProductsRequest * _request;
}

@property (retain) NSSet *productIdentifiers;
@property (retain) NSArray * products;
@property (retain) NSMutableSet *purchasedProducts;
@property (retain) SKProductsRequest *request;

- (void)requestProducts;
- (id)initWithProductIdentifiers:(NSSet *)productIdentifiers;
- (void)buyProductIdentifier:(NSString *)productIdentifier;
@end
