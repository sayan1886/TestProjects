//
//  CreatePDF.h
//  VehicleInspection
//
//  Created by Avik on 10/02/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Settings.h"
#import "Building.h"
#import "Tenant.h"
#import "Constant.h"
#import "Owner.h"

@interface CreatePDF : NSObject
{
	Settings *setting;
	
	NSString *reportedFor;
	NSString *reportedBy;
	
	NSString *reportedFrom;
	NSString *reportedTo;
	
	NSInteger noOfCol;
	
	NSMutableArray *arrayOfAttribute;
	NSMutableArray *arrOfTag;
	
	NSString *entityName;

	Building *building;
	Tenant *tenant;
	Owner *owner;
	
	REPORT_TYPES_TAG reportTypesTag;
}

@property (nonatomic, retain) Settings *setting;
@property (nonatomic, retain) NSString *reportedFor;
@property (nonatomic, retain) NSString *reportedBy;
@property (nonatomic, retain) NSString *reportedFrom;
@property (nonatomic, retain) NSString *reportedTo;
@property (nonatomic) NSInteger noOfCol;
@property (nonatomic, retain) NSMutableArray *arrayOfAttribute;
@property (nonatomic, retain) NSMutableArray *arrOfTag;
@property (nonatomic, retain) NSString *entityName;
@property (nonatomic, retain) Building *building;
@property (nonatomic, retain) Tenant *tenant;
@property (nonatomic, retain) Owner *owner;

@property (nonatomic) REPORT_TYPES_TAG reportTypesTag;
 
- (void)drawString:(NSString *)str  atRect:(CGRect)rect;
- (void)drawBoldString:(NSString *)str  atRect:(CGRect)rect;
- (void)drawHeading:(NSString *)str  atRect:(CGRect)rect;
- (void)drawRect:(CGRect) rect atContext:(CGContextRef)context;
- (void)drawLineFromPoint:(CGPoint)startPonit toPoint:(CGPoint)endPoint atContext:(CGContextRef)context;
- (void)drawImage:(UIImage *)img  atPoint:(CGPoint)point inContext:(CGContextRef)ctx;
- (void)drawImage:(UIImage *)img  atRect:(CGRect)rect inContext:(CGContextRef)ctx;
- (void) createPDFWithFileName:(NSString *)pdfFilePath;

//for pdf data
-(void)expenseReportByBuilding:(CGFloat) totalHeight CurrX:(CGFloat)currentX MaxHeight:(CGFloat)maxHeight Width:(CGFloat)spaceBetweenCol;
-(void)expenseReportByOwner:(CGFloat) totalHeight CurrX:(CGFloat)currentX MaxHeight:(CGFloat)maxHeight Width:(CGFloat)spaceBetweenCol;

-(void)incomeReportByBuilding:(CGFloat) totalHeight CurrX:(CGFloat)currentX MaxHeight:(CGFloat)maxHeight Width:(CGFloat)spaceBetweenCol;
-(void)incomeReportByOwner:(CGFloat) totalHeight CurrX:(CGFloat)currentX MaxHeight:(CGFloat)maxHeight Width:(CGFloat)spaceBetweenCol;

-(void)totalFinanceByBuilding:(CGFloat) totalHeight CurrX:(CGFloat)currentX MaxHeight:(CGFloat)maxHeight Width:(CGFloat)spaceBetweenCol;
-(void)totalFinanceByOwner:(CGFloat) totalHeight CurrX:(CGFloat)currentX MaxHeight:(CGFloat)maxHeight Width:(CGFloat)spaceBetweenCol;

-(void)lateTenantReport:(CGFloat) totalHeight CurrX:(CGFloat)currentX MaxHeight:(CGFloat)maxHeight Width:(CGFloat)spaceBetweenCol;
-(void)tenantPaymentReport:(CGFloat) totalHeight CurrX:(CGFloat)currentX MaxHeight:(CGFloat)maxHeight Width:(CGFloat)spaceBetweenCol;
-(void)tenantPhoneList:(CGFloat) totalHeight CurrX:(CGFloat)currentX MaxHeight:(CGFloat)maxHeight Width:(CGFloat)spaceBetweenCol;
-(void)rentRoll:(CGFloat) totalHeight CurrX:(CGFloat)currentX MaxHeight:(CGFloat)maxHeight Width:(CGFloat)spaceBetweenCol;

-(CGFloat) incomeFromPaymentForMonth:(NSString *)mnth ForTenant:(Tenant *)ten;
-(CGFloat) expenseFromExpensesForMonth:(NSString *)mnth ForBuilding:(Building *)build;

-(BOOL)isDateBetweenReportedDate:(NSString *)date;


@end
