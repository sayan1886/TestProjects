//
//  TestIAPHelper.h
//  TestInAppPurchase
//
//  Created by ASHIM SAMANTA on 09/02/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IAPHelper.h"

@interface TestIAPHelper : IAPHelper {

}

+ (TestIAPHelper *) sharedHelper;

@end
