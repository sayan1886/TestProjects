//
//  RTExpensesListViewController.h
//  RentTracker
//
//  Created by ASHIM SAMANTA on 22/03/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Building.h"

@interface RTExpensesListViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>
{
	UITableView *rtExpencesListTableView_;
	NSMutableArray *searchText_;
	Building *building_;
	
	NSDictionary *resultdict_;
	NSArray *arr_;
	NSArray *array_;
}

@property (nonatomic, retain) IBOutlet UITableView *rtExpencesListTableView;
@property (nonatomic, retain) NSMutableArray *searchText;
@property (nonatomic, retain) Building *building;
@property (nonatomic, retain) NSDictionary *resultdict;
@property (nonatomic, retain) NSArray *arr;
@property (nonatomic, retain) NSArray *array;

-(void)getValues;
@end
