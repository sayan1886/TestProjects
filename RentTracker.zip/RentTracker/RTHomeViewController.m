//
//  RTHomeViewController.m
//  RentTracker
//
//  Created by ASHIM SAMANTA on 28/02/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import "RTHomeViewController.h"
#import "Utility.h"
#import "RTTenantViewController.h"
#import "RTBuildingViewController.h"
#import "RTOwnerViewController.h"
#import "RTContractorViewController.h"
#import "RTExpencesViewController.h"
#import "Constant.h"
#import "RTAlertViewController.h"
#import "RTReportViewController.h"
#import "RTPayementViewController.h"
#import "TestInAppPurchaseViewController.h"
#import "RTAlertVC.h"

@implementation RTHomeViewController
@synthesize btnTenant = _btnTenant;
@synthesize lblTenant = _lblTenant;
@synthesize btnBuilding = _btnBuilding;
@synthesize lblBuilding = _lblBuilding;
@synthesize btnOwner = _btnOwner;
@synthesize lblOwner = _lblOwner;
@synthesize btnContractor = _btnContractor;
@synthesize lblContractor = _lblContractor;
@synthesize btnPayment = _btnPayment;
@synthesize lblPayment = _lblPayment;
@synthesize btnExpense = _btnExpense;
@synthesize lblExpense = _lblExpense;
@synthesize btnReport = _btnReport;
@synthesize lblReport = _lblReport;
@synthesize btnAlert = _btnAlert;
@synthesize lblAlert = _lblAlert;

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
		self.title = @"RentTracker";        
        UIButton *btnInfo = [UIButton buttonWithType:UIButtonTypeInfoLight];
        [btnInfo addTarget:self action:@selector(inAppPurchase:) forControlEvents:UIControlEventTouchUpInside];
        UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithCustomView:btnInfo];
        self.navigationItem.rightBarButtonItem = item;
        item = nil; btnInfo = nil;
    }
    return self;
}

-(void)inAppPurchase:(id)sender
{
    TestInAppPurchaseViewController *vc = [[TestInAppPurchaseViewController alloc] init];
    [self.navigationController pushViewController:vc animated:YES];
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];	
	self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:ISIPHONE?BG_IMAGE_IPHONE:BG_IMAGE_IPAD]];
    
    frameTenantBtn = self.btnTenant.frame;
    frameTenantLabel = self.lblTenant.frame;
    
    frameBuildingBtn = self.btnBuilding.frame;
    frameBuildingLabel = self.lblBuilding.frame;
    
    frameOwnerBtn = self.btnOwner.frame;
    frameOwnerLabel = self.lblOwner.frame;
    
    frameContractorBtn = self.btnContractor.frame;
    frameContractorLabel = self.lblContractor.frame;
    
    framePaymentBtn = self.btnPayment.frame;
    framePaymentLabel = self.lblPayment.frame;
    
    frameExpenseBtn = self.btnExpense.frame;
    frameExpenseLabel = self.lblExpense.frame;
    
    frameReportBtn = self.btnReport.frame;
    frameReportLabel = self.lblReport.frame;
    
    frameAlertBtn = self.btnAlert.frame;
    frameAlertLabel = self.lblAlert.frame;
    
    [self createBanerView];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    NSUserDefaults *standardDefaults = [NSUserDefaults standardUserDefaults];
    NSInteger totalNoOfTenantPurchased = [standardDefaults integerForKey:PURCHASED_TENANT];
    if(totalNoOfTenantPurchased >= 10)
    {
        ADBannerView *bView = (ADBannerView *)[_adView viewWithTag:1000];
        bView.delegate = nil;
        [bView removeFromSuperview];
        _adBannerViewIsVisible = NO;
        [self manageSpaceforBaner];
    }
}

-(void)manageSpaceforBaner
{
    if (_adBannerViewIsVisible)
    {
        CGRect frame = self.btnTenant.frame;
        frame.origin.y = 50;
        frame.size.height -= 10;
        frame.size.width -= 10;
        self.btnTenant.frame = frame;
        
        frame = self.btnBuilding.frame;
        frame.origin.y = 50;
        frame.size.height -= 10;
        frame.size.width -= 10;
        self.btnBuilding.frame = frame;
        
        frame = self.lblTenant.frame;
        frame.origin.y = 110;
        frame.origin.x -= 5;
        self.lblTenant.frame = frame;
        
        frame = self.lblBuilding.frame;
        frame.origin.y = 110;
        
        self.lblBuilding.frame = frame;
        
        
        frame = self.btnOwner.frame;
        frame.origin.y += 32;
        frame.size.height -= 10;
        frame.size.width -= 10;
        self.btnOwner.frame = frame;
        
        frame = self.btnContractor.frame;
        frame.origin.y += 32;
        frame.size.height -= 10;
        frame.size.width -= 10;
        self.btnContractor.frame = frame;
        
        frame = self.lblOwner.frame;
        frame.origin.y += 20;
        frame.origin.x -= 5;
        self.lblOwner.frame = frame;
        
        frame = self.lblContractor.frame;
        frame.origin.y += 20;
        //frame.origin.x -= 5;
        self.lblContractor.frame = frame;
        
        //
        frame = self.btnPayment.frame;
        frame.origin.y += 20;
        frame.size.height -= 10;
        frame.size.width -= 10;
        self.btnPayment.frame = frame;
        
        frame = self.btnExpense.frame;
        frame.origin.y += 20;
        frame.size.height -= 10;
        frame.size.width -= 10;
        self.btnExpense.frame = frame;
        
        frame = self.lblPayment.frame;
        frame.origin.y += 10;
        //frame.origin.x -= 5;
        self.lblPayment.frame = frame;
        
        frame = self.lblExpense.frame;
        frame.origin.y += 10;
        //frame.origin.x -= 5;
        self.lblExpense.frame = frame;
        
        frame = self.btnReport.frame;
        frame.origin.y += 10;
        frame.size.height -= 10;
        frame.size.width -= 10;
        self.btnReport.frame = frame;
        
        frame = self.btnAlert.frame;
        frame.origin.y += 10;
        frame.size.height -= 10;
        frame.size.width -= 10;
        self.btnAlert.frame = frame;
        
        frame = self.lblAlert.frame;
        //frame.origin.y += 10;
        frame.origin.x -= 5;
        self.lblAlert.frame = frame;
        
        frame = self.lblReport.frame;
        //frame.origin.y += 10;
        frame.origin.x -= 5;
        self.lblReport.frame = frame;
    }
    else
    {
        self.btnTenant.frame = frameTenantBtn;
        self.lblTenant.frame = frameTenantLabel;
        
        self.btnBuilding.frame = frameBuildingBtn;
        self.lblBuilding.frame = frameBuildingLabel;
        
        self.btnOwner.frame = frameOwnerBtn;
        self.lblOwner.frame = frameOwnerLabel;
        
        self.btnContractor.frame = frameContractorBtn;
        self.lblContractor.frame = frameContractorLabel;
        
        self.btnPayment.frame = framePaymentBtn;
        self.lblPayment.frame = framePaymentLabel;
        
        self.btnExpense.frame = frameExpenseBtn;
        self.lblExpense.frame = frameExpenseLabel;
        
        self.btnReport.frame = frameReportBtn;
        self.lblReport.frame = frameReportLabel;
        
        self.btnAlert.frame = frameAlertBtn;
        self.lblAlert.frame = frameAlertLabel;
    }
}

-(void)createBanerView
{
    float y = -80;
    if(ISIPHONE)
        y = -50;
    
    _adView = [[UIView alloc] initWithFrame:CGRectMake(0, y, 320, 50)];
    _adView.backgroundColor = [UIColor clearColor];
    ADBannerView *_adBannerView = [[ADBannerView alloc] initWithFrame:CGRectMake(0, 0, 320, 50)];
    _adBannerView.delegate = self;
    _adBannerView.tag = 1000;
    [_adView addSubview:_adBannerView];
    [self.view addSubview:_adView];
    _adBannerViewIsVisible = NO;
    _adBannerView = nil;
}

-(void)manageBaner
{
    CGRect adBannerViewFrame;
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.80];
    [self manageSpaceforBaner];
    if (_adBannerViewIsVisible) 
    {
        adBannerViewFrame = [_adView frame];
        adBannerViewFrame.origin.x = 0;
        adBannerViewFrame.origin.y = 0;
        _adView.frame = adBannerViewFrame;
    } 
    else 
    {
        adBannerViewFrame = [_adView frame];
        adBannerViewFrame.origin.x = 0;
        adBannerViewFrame.origin.y = -80;
        if(ISIPHONE)
            adBannerViewFrame.origin.y = -50;
        _adView.frame = adBannerViewFrame;
    }
    [UIView commitAnimations];
} 

#pragma mark ADBannerViewDelegate

- (void)bannerViewDidLoadAd:(ADBannerView *)banner {
    if (!_adBannerViewIsVisible) {                
        _adBannerViewIsVisible = YES;
        [self manageBaner];
    }
}

- (void)bannerView:(ADBannerView *)banner didFailToReceiveAdWithError:(NSError *)error
{
    if (_adBannerViewIsVisible)
    {        
        _adBannerViewIsVisible = NO;
        [self manageBaner];
    }
}

#pragma mark -
#pragma mark Buttons

-(IBAction)tenant:(id)sender
{
	RTTenantViewController *viewController = nil;
	if(ISIPHONE)
		viewController = [[RTTenantViewController alloc] initWithNibName:@"RTTenantViewController" bundle:nil];
	else
		viewController = [[RTTenantViewController alloc] initWithNibName:@"RTTenant_Ipad" bundle:nil];
	[self.navigationController pushViewController:viewController animated:YES];
		
	[viewController release];
}
-(IBAction)building:(id)sender
{
	RTBuildingViewController *viewController = nil;
	if(ISIPHONE)
		viewController = [[RTBuildingViewController alloc] initWithNibName:@"RTBuildingViewController" bundle:nil];
	else
		viewController = [[RTBuildingViewController alloc] initWithNibName:@"RTBuilding_iPad" bundle:nil];
	[self.navigationController pushViewController:viewController animated:YES];
	[viewController release];
}
-(IBAction)payment:(id)sender
{
	RTPayementViewController *viewController = [[RTPayementViewController alloc] initWithNibName:@"RTPayementViewController" bundle:nil];
	[self.navigationController pushViewController:viewController animated:YES];
	[viewController release];
}
-(IBAction)expences:(id)sender
{
	RTExpencesViewController *viewController = nil;
	if(ISIPHONE)
		viewController = [[RTExpencesViewController alloc] initWithNibName:@"RTExpencesViewController" bundle:nil];
	else
		viewController = [[RTExpencesViewController alloc] initWithNibName:@"RTExpense_iPad" bundle:nil];
	[self.navigationController pushViewController:viewController animated:YES];
	[viewController release];
}
-(IBAction)report:(id)sender
{
	RTReportViewController *viewController;
	if(ISIPHONE)
		viewController = [[RTReportViewController alloc] initWithNibName:@"RTReportViewController" bundle:nil];
	else
		viewController = [[RTReportViewController alloc] initWithNibName:@"RTReport_iPad" bundle:nil];
	[self.navigationController pushViewController:viewController animated:YES];
	[viewController release];
	
}
-(IBAction)alert:(id)sender
{
	RTAlertVC *viewController = [[RTAlertVC alloc] initWithNibName:@"RTAlertVC" bundle:nil];
	[self.navigationController pushViewController:viewController animated:YES];
	[viewController release]; viewController = nil;
}
-(IBAction)contractor:(id)sender
{
	RTContractorViewController *viewController = nil;
	if(ISIPHONE)
		viewController = [[RTContractorViewController alloc] initWithNibName:@"RTContractorViewController" bundle:nil];
	else
		viewController = [[RTContractorViewController alloc] initWithNibName:@"RTContractor_iPad" bundle:nil];
	[self.navigationController pushViewController:viewController animated:YES];
	[viewController release];
}
-(IBAction)owner:(id)sender
{
	RTOwnerViewController *viewController = nil;
	if(ISIPHONE)		
		viewController = [[RTOwnerViewController alloc] initWithNibName:@"RTOwnerViewController" bundle:nil];
	else
		viewController = [[RTOwnerViewController alloc] initWithNibName:@"RTOwner_iPad" bundle:nil];
	
	[self.navigationController pushViewController:viewController animated:YES];
	[viewController release];
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [self setBtnTenant:nil];
    [self setLblTenant:nil];
    [self setBtnBuilding:nil];
    [self setLblBuilding:nil];
    [self setBtnOwner:nil];
    [self setLblOwner:nil];
    [self setBtnContractor:nil];
    [self setLblContractor:nil];
    [self setBtnPayment:nil];
    [self setLblPayment:nil];
    [self setBtnExpense:nil];
    [self setLblExpense:nil];
    [self setBtnReport:nil];
    [self setLblReport:nil];
    [self setBtnAlert:nil];
    [self setLblAlert:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [_btnTenant release];
    [_lblTenant release];
    [_btnBuilding release];
    [_lblBuilding release];
    [_btnOwner release];
    [_lblOwner release];
    [_btnContractor release];
    [_lblContractor release];
    [_btnPayment release];
    [_lblPayment release];
    [_btnExpense release];
    [_lblExpense release];
    [_btnReport release];
    [_lblReport release];
    [_btnAlert release];
    [_lblAlert release];
    [super dealloc];
}


@end
