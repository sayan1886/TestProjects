//
//  Building.h
//  RentTracker
//
//  Created by Manas Kumar Mandal on 20/04/12.
//  Copyright (c) 2012 ObjectSol Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class Expenses, Owner;

@interface Building : NSManagedObject

@property (nonatomic, retain) NSString * address;
@property (nonatomic, retain) NSString * postal_code;
@property (nonatomic, retain) NSString * deleted;
@property (nonatomic, retain) NSString * city;
@property (nonatomic, retain) NSString * no_of_units;
@property (nonatomic, retain) NSData * image;
@property (nonatomic, retain) NSString * state;
@property (nonatomic, retain) Owner *owner;
@property (nonatomic, retain) NSSet *expenses;
@end

@interface Building (CoreDataGeneratedAccessors)

- (void)addExpensesObject:(Expenses *)value;
- (void)removeExpensesObject:(Expenses *)value;
- (void)addExpenses:(NSSet *)values;
- (void)removeExpenses:(NSSet *)values;
@end
