//
//  RTBuildingEditViewController.h
//  RentTracker
//
//  Created by ASHIM SAMANTA on 29/02/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ImagePicker.h"
#import "Utility.h"

@class Building;

@interface RTBuildingEditViewController : UIViewController<UITableViewDataSource, UITableViewDelegate,
											UITextFieldDelegate, CaptureImage,UIPickerViewDataSource, UIPickerViewDelegate > 
{

	UITableView *rtBuildingEditTableView_;
	UIBarButtonItem *rightItem_;
	NSMutableDictionary *dict_;
	UIButton *btn;
	BOOL isReadOnly;

	UITextField *tempTextField;
	UIPickerView *pickerView;
	
	NSMutableArray *array_;
	NSMutableArray *ownerArray_;
	
	UIView *pView;
	
	NSInteger selectedIndex;
	
	Building *building_;
	UITextField *txtFld;
	
	BOOL isPickerVisible;
}

@property( nonatomic, retain) IBOutlet UITableView *rtBuildingEditTableView;
@property (nonatomic, retain) UIBarButtonItem *rightItem;
@property (nonatomic, retain) NSMutableDictionary *dict;
@property (nonatomic, retain) Building *building;

@property (nonatomic, retain) NSMutableArray *array;
@property (nonatomic, retain) NSMutableArray *ownerArray;
@property (nonatomic, retain) UIButton * btn;

-(void)fetchData;
-(void)fetchManagedObject;
-(void)loadValues;

@end
