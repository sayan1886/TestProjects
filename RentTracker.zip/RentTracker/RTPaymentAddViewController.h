//
//  RTPaymentAddViewController.h
//  RentTracker
//
//  Created by ASHIM SAMANTA on 23/03/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Tenant.h"
#import "Constant.h"

@interface RTPaymentAddViewController : UIViewController <UIPickerViewDelegate, UIPickerViewDataSource,
											UITextFieldDelegate, UITextViewDelegate>
{
	UITableView *rtPaymentAddTableView_;
//paymentFor 	
	UIPickerView *pickerPaymentFor_;
	NSMutableArray *arrayPaymentFor_;
//tenant
	Tenant *tenant_;
//for all data management
	NSMutableDictionary *tempDict_;
//For picker
	UIView *pView_;
	UIPickerView *pickerView_;
	UIDatePicker *datePicker_;
	PICKER_TAG pickerTag;
//Note
	UITextView *txtNote_;
//
	UITextField *tempTextField_;
	
	NSInteger selectedIndex;
	UITextField *textFieldToHidePicker_;
}

@property (nonatomic, retain) IBOutlet UITableView *rtPaymentAddTableView;
@property (nonatomic, retain) UIPickerView *pickerPaymentFor;
@property (nonatomic, retain) NSMutableArray *arrayPaymentFor;
@property (nonatomic, retain) Tenant *tenant;
@property (nonatomic, retain) NSMutableDictionary *tempDict;
@property (nonatomic, retain) UIView *pView;
@property (nonatomic, retain) UIPickerView *pickerView;
@property (nonatomic, retain) UIDatePicker *datePicker;
@property (nonatomic, retain) UITextView *txtNote;
@property (nonatomic, retain) UITextField *tempTextField;
@property (nonatomic, retain) UITextField *textFieldToHidePicker;

@end