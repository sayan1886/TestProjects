//
//  RTTenantAddViewController.h
//  RentTracker
//
//  Created by ASHIM SAMANTA on 29/02/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ImagePicker.h"
#import "Constant.h"

@interface RTTenantAddViewController : UIViewController <UITableViewDelegate, UIScrollViewDelegate,
									UITableViewDataSource, UITextFieldDelegate, UITextViewDelegate,
									CaptureImage, UIPickerViewDataSource, UIPickerViewDelegate>
{
	UITableView *rtTAddTableView_;
	UITableView *rtTAddTableViewFirst_;
	
	UIScrollView *rtAddScrollView_;
	
	
	NSMutableDictionary *tempDict_;
	
	UITextField *tempTextField;
	UIPickerView *pickerView;
	
	NSMutableArray *array_;
	NSMutableArray *buildingArray_;
	
	UIView *pView;
	UIDatePicker *datePicker_;
	
	UIButton *btn;
	
	UIButton *btnIcon_;
	NSInteger selectedIndex;
	
	UITextField *address_;
	UITextField *city_;
	UITextField *state_;
	UITextField *postalCode_;
	
	PICKER_TAG pickerTag;
	
	UITextField *depPaidDate_;
	UITextField *moveInDate_;
	
	UITextField *building_;
	UITextField *fName_;
	UITextField *lName_;
	UITextField *rentAmount_;
	
	UITextView *note_;
	UITextField *txtPickerField_;
	
	NSMutableArray *rentDayArray_;
	UITextField *rentDueDay_;
	
	NSMutableArray *leasePeriodArray_;
    
	UITextField *rentLeasePeriod_;
	UITextField *txtLeaseStartDate_;
    
	
	NSInteger rentDueDaySelectedIndex;
	
	BOOL isMoveOut;
}

@property (nonatomic, retain) IBOutlet UITableView *rtTAddTableView;
@property (nonatomic, retain) IBOutlet UITableView *rtTAddTableViewFirst;
@property (nonatomic, retain) IBOutlet UIScrollView *rtAddScrollView;
@property (nonatomic, retain) NSMutableDictionary *tempDict;
@property (nonatomic, retain) UIButton *btnIcon;

@property (nonatomic, retain) UITextField *address;
@property (nonatomic, retain) UITextField *city;
@property (nonatomic, retain) UITextField *state;
@property (nonatomic, retain) UITextField *postalCode;

@property (nonatomic, retain) NSMutableArray *array;
@property (nonatomic, retain) NSMutableArray *buildingArray;
@property (nonatomic, retain) UIDatePicker *datePicker;

@property (nonatomic, retain) UITextField *depPaidDate;
@property (nonatomic, retain) UITextField *moveInDate;

@property (nonatomic, retain) UITextField *building;
@property (nonatomic, retain) UITextField *fName;
@property (nonatomic, retain) UITextField *lName;
@property (nonatomic, retain) UITextField *rentAmount;

@property (nonatomic, retain) UITextView *note;
@property (nonatomic, retain) UITextField *txtPickerField;

@property (nonatomic, retain) NSMutableArray *rentDayArray;
@property (nonatomic, retain) UITextField *rentDueDay;
@property (nonatomic,retain)  NSMutableArray *leasePeriodArray;
@property (nonatomic, retain) UITextField *rentLeasePeriod;
@property (nonatomic, retain) UITextField *txtLeaseStartDate;


-(void)fetchData;
-(IBAction)addPhoto:(id)sender;
-(BOOL)hasNameBuildingAndRentAmount;
-(void)addToolBar:(UITextView *)textView;
@end
