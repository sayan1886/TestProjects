//
//  RTAlertViewController.m
//  RentTracker
//
//  Created by ASHIM SAMANTA on 07/03/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import "RTAlertViewController.h"
#import "Constant.h"
#import "Tenant.h"
#import "Payment.h"
#import "AppDelegate_iPhone.h"
#import "CoreDataHelper.h"
#import "Utility.h"
#import "RTTenantEditViewController.h"

@interface RTAlertViewController (Private)

-(void)expiredLeases;
-(void)lateTenants;

@end

@implementation RTAlertViewController

@synthesize rtAlertTableView = rtAlertTableView_;
@synthesize searchText = searchText_;
@synthesize array = array_;
@synthesize resultdict = resultdict_;
@synthesize arr = arr_;
@synthesize arrOfTenant = arrOfTenant_;
@synthesize isLateTenant;

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}

#pragma mark -
#pragma mark TableView delegate method

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
	return HEIGHT_FOR_HEADER;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
	if(![tableView isEqual:self.rtAlertTableView]) return nil;
	
	UIView *header = [[[UIView alloc]initWithFrame:CONTACT_HEADER_FRAME] autorelease];
	header.backgroundColor = [UIColor colorWithPatternImage:[[UIImage imageNamed:CONTACT_HEADER_IMAGE] stretchableImageWithLeftCapWidth:0 topCapHeight:32]];
	
	UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, 6, 20, 20)];
	
	if([tableView isEqual:self.rtAlertTableView])
	{
		label.text = [self.arr objectAtIndex:section];
	}
	
	label.backgroundColor = [UIColor clearColor];
	label.textColor = [UIColor whiteColor];
	
	[header addSubview:label];
	
	[label release];
	return header;
}

// return list of section titles to display in section index view (e.g. "ABCD...Z#")
-(NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView
{
	if(![tableView isEqual:self.rtAlertTableView]) return nil;
	NSMutableArray *toBeReturned = [[NSMutableArray alloc]init];
    for(char c = 'A'; c <= 'Z'; c++) [toBeReturned addObject:[NSString stringWithFormat:@"%c",c]];
    return [toBeReturned autorelease];
}

// tell table which section corresponds to section title/index (e.g. "B",1))

-(NSInteger)tableView:(UITableView *)tableView sectionForSectionIndexTitle:(NSString *)title atIndex:(NSInteger)index
{
	NSLog(@"index = %d", index);
	return index;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	if([tableView isEqual:self.rtAlertTableView])
	{
		NSArray *arrRes = [self.resultdict objectForKey:[self.arr objectAtIndex:section]];
		return [arrRes count];
	}
	return [self.searchText count];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	if([tableView isEqual:self.rtAlertTableView])
	{
		return [self.arr count];
	}
	return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	static NSString *cellID = @"cellID";
	NSString *text = @"";
	if([tableView isEqual:self.rtAlertTableView]) 
	{
		NSString *val = [self.arr objectAtIndex:indexPath.section];
		NSArray *arrTemp = [self.resultdict objectForKey:val];
		Tenant *tenant = [arrTemp objectAtIndex:indexPath.row];
		text = tenant.first;
		text = [text stringByAppendingString:@" "];
		if(tenant.last)
			text = [text stringByAppendingString:tenant.last];
		arrTemp = nil;
	}
	else 
	{
		text = [[self.searchText objectAtIndex:indexPath.row] valueForKey:@"first"];
		if([[self.searchText objectAtIndex:indexPath.row] valueForKey:@"last"])
			text = [text stringByAppendingFormat:@" %@",[[self.searchText objectAtIndex:indexPath.row] valueForKey:@"last"]];
	}	
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID] ;
	if(!cell)
	{
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID] autorelease];
		cell.textLabel.text = text;
	}
	else
		cell.textLabel.text = text;
	return cell ;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	Tenant *tenant = nil;
	if([tableView isEqual:self.rtAlertTableView])
	{
		NSString *val = [self.arr objectAtIndex:indexPath.section];
		NSArray *tempArr = [self.resultdict objectForKey:val];
		tenant = [tempArr objectAtIndex:indexPath.row];
		tempArr = nil;
	}
	else 
	{
		tenant = [self.searchText objectAtIndex:indexPath.row];
	}
	
	RTTenantEditViewController *viewController = [[RTTenantEditViewController alloc] initWithNibName:@"RTTenantEditViewController" bundle:nil];
	viewController.tenant = tenant;
	viewController.fromAlert = YES;
	viewController.cause = tenant.cause;
	[self.navigationController pushViewController:viewController animated:YES];
	[viewController release];viewController = nil;
}

#pragma mark -
#pragma mark SEARCH

- (BOOL)searchDisplayController:(UISearchDisplayController *)controller shouldReloadTableForSearchString:(NSString *)searchString
{    
	[self.searchText removeAllObjects];
    
    for (Tenant *tenant in self.array)
    {
		NSString *aStr = tenant.first;
		aStr = [aStr stringByAppendingFormat:@" %@",tenant.last]; 
		aStr = [aStr lowercaseString];
		if ([aStr rangeOfString:[searchString lowercaseString]].location != NSNotFound)
            [self.searchText addObject:tenant];
    }
	
    [controller.searchResultsTableView reloadData];
    return NO;
}

- (void)searchDisplayControllerWillBeginSearch:(UISearchDisplayController *)controller
{
    self.rtAlertTableView.hidden = YES;
}

- (void)searchDisplayControllerDidEndSearch:(UISearchDisplayController *)controller
{
    self.rtAlertTableView.hidden = NO;
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
    if(isLateTenant)
        self.title = @"Late Tenants";
    else
        self.title = @"Expired Leases";
	self.searchText = [[NSMutableArray alloc] init];
	self.array = [[NSMutableArray alloc] init];
	self.resultdict = [[NSMutableDictionary alloc] init];
	self.arr = [[NSMutableArray alloc] init];
    
    if(isLateTenant)
        [self lateTenants];
    else
        [self expiredLeases];
    
}


-(void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	
}

-(void)expiredLeases
{
    NSMutableArray *arrTemp = [[NSMutableArray alloc] init];
	self.arrOfTenant = [[NSMutableArray alloc] init];
	
	AppDelegate_iPhone *app = (AppDelegate_iPhone *)[[UIApplication sharedApplication]delegate];
	self.array = [CoreDataHelper getObjectsFromContext:ENTITY_KEY_TENANT :@"first" :YES :app.managedObjectContext];
	for(Tenant *tenant in self.array)
	{
		if([tenant.moveOut boolValue]) continue;
		BOOL isExpired = [Utility isLeasePeriodExpiredForTenant:tenant];
		if(isExpired)
		{
            tenant.cause = @"Lease Expired!";
			[arrTemp addObject:tenant];
		}
	}
	self.array = nil;
	self.array = arrTemp;
	self.resultdict = [Utility arrangeList:self.array sortKey:@"first"];
	self.arr = [self.resultdict allKeys];
	self.arr = [self.arr sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
	[self.rtAlertTableView reloadData];
}

-(void)lateTenants
{
    NSMutableArray *arrTemp = [[NSMutableArray alloc] init];
	self.arrOfTenant = [[NSMutableArray alloc] init];
	
	AppDelegate_iPhone *app = (AppDelegate_iPhone *)[[UIApplication sharedApplication]delegate];
	self.array = [CoreDataHelper getObjectsFromContext:ENTITY_KEY_TENANT :@"first" :YES :app.managedObjectContext];
	for(Tenant *tenant in self.array)
	{
		if([tenant.moveOut boolValue]) continue;
		BOOL isDueAmt = [Utility isDueForTenant:tenant];
		if(isDueAmt)
		{
            tenant.cause = @"Rent Due.";//[NSString stringWithFormat:@"Rent Due"];//,[NSString stringWithFormat:@"%.2f",dueAmt]];
			
			[arrTemp addObject:tenant];
		}
	}
	self.array = nil;
	self.array = arrTemp;
	self.resultdict = [Utility arrangeList:self.array sortKey:@"first"];
	self.arr = [self.resultdict allKeys];
	self.arr = [self.arr sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
	[self.rtAlertTableView reloadData];
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
	
	self.rtAlertTableView = nil ;
	self.searchText = nil;
	
	self.array = nil;
	self.resultdict = nil;
	
	self.arr = nil;
	
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	
	self.rtAlertTableView = nil;
	self.searchText = nil;
	
	self.array = nil;
	self.resultdict = nil;
	
	self.arr = nil;
	
    [super dealloc];
}


@end
