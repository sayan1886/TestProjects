//
//  RTHomeViewController.h
//  RentTracker
//
//  Created by ASHIM SAMANTA on 28/02/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <iAd/iAd.h>

@interface RTHomeViewController : UIViewController <ADBannerViewDelegate>
{
    BOOL _adBannerViewIsVisible;
    UIView *_adView;
    
    CGRect frameTenantBtn;
    CGRect frameTenantLabel;
    
    CGRect frameBuildingBtn;
    CGRect frameBuildingLabel;
    
    CGRect frameOwnerBtn;
    CGRect frameOwnerLabel;
    
    CGRect frameContractorBtn;
    CGRect frameContractorLabel;
    
    //
    CGRect framePaymentBtn;
    CGRect framePaymentLabel;
    
    CGRect frameExpenseBtn;
    CGRect frameExpenseLabel;
    
    CGRect frameReportBtn;
    CGRect frameReportLabel;
    
    CGRect frameAlertBtn;
    CGRect frameAlertLabel;
}

@property (retain, nonatomic) IBOutlet UIButton *btnTenant;
@property (retain, nonatomic) IBOutlet UILabel *lblTenant;

@property (retain, nonatomic) IBOutlet UIButton *btnBuilding;
@property (retain, nonatomic) IBOutlet UILabel *lblBuilding;

@property (retain, nonatomic) IBOutlet UIButton *btnOwner;
@property (retain, nonatomic) IBOutlet UILabel *lblOwner;

@property (retain, nonatomic) IBOutlet UIButton *btnContractor;
@property (retain, nonatomic) IBOutlet UILabel *lblContractor;

@property (retain, nonatomic) IBOutlet UIButton *btnPayment;
@property (retain, nonatomic) IBOutlet UILabel *lblPayment;

@property (retain, nonatomic) IBOutlet UIButton *btnExpense;
@property (retain, nonatomic) IBOutlet UILabel *lblExpense;

@property (retain, nonatomic) IBOutlet UIButton *btnReport;
@property (retain, nonatomic) IBOutlet UILabel *lblReport;

@property (retain, nonatomic) IBOutlet UIButton *btnAlert;
@property (retain, nonatomic) IBOutlet UILabel *lblAlert;


-(IBAction)tenant:(id)sender;
-(IBAction)building:(id)sender;
-(IBAction)payment:(id)sender;
-(IBAction)expences:(id)sender;
-(IBAction)report:(id)sender;
-(IBAction)alert:(id)sender;
-(IBAction)contractor:(id)sender;
-(IBAction)owner:(id)sender;

-(void)manageBaner;
-(void)createBanerView;
-(void)manageSpaceforBaner;

@end
