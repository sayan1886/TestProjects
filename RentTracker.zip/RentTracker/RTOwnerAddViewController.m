//
//  RTOwnerAddViewController.m
//  RentTracker
//
//  Created by ASHIM SAMANTA on 06/03/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import "RTOwnerAddViewController.h"
#import "CustomCell.h"
#import "Constant.h"
#import "ImagePicker.h"
#import "AppDelegate_iPhone.h"
#import "Owner.h"
#import "NSManagedObjectContext+insert.h"
#import "Utility.h"
#import "Constant.h"
#import "UIImage+TKCategory.h"

@implementation RTOwnerAddViewController

@synthesize rtOwnerAddTableView = rtOwnerAddTableView_;
@synthesize tempDict = tempDict_;
@synthesize txtFldOwnerFirstName = txtFldOwnerFirstName_;
@synthesize txtFldOwnerLastName = txtFldOwnerLastName_;
@synthesize btn;
// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
		self.title = @"Add Owner";
        UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(done:)];
		self.navigationItem.rightBarButtonItem = item;
		[item release];
    }
    return self;
}

-(void)done:(id)sender
{
	if([tempTextField isFirstResponder])
		[tempTextField resignFirstResponder];
	[Utility increaseHeightOfTableView:self.rtOwnerAddTableView];
	if(![self hasOwnerName])
	{
		[Utility showAlertViewWithTitle:TITLE_MANDATORY_FIELD Message:MESSAGE_OWNER_MANDATORY_FIELD CancelTitle:CANCEL_TITLE];
		return ;
	}
	if([self.tempDict objectForKey:[NSString stringWithFormat:@"%d",OWNER_EMAIL]])
	{
		if(![Utility isEmailValid:[self.tempDict objectForKey:[NSString stringWithFormat:@"%d",OWNER_EMAIL]]])
		{
			[Utility showAlertViewWithTitle:TITLE Message:MESSAGE_INVALID_EMAIL_ID CancelTitle:CANCEL_TITLE];
			return ;
		}
	}
	
	AppDelegate_iPhone *appDelegate =  (AppDelegate_iPhone *)[[UIApplication sharedApplication] delegate];
	Owner *owner = (Owner *)[appDelegate.managedObjectContext insertNewEntityWithName:ENTITY_KEY_OWNER];
	if(owner && self.tempDict)
	{
		if ([self.tempDict objectForKey:KEY_IMAGE]) 
		{
			UIImage *img = [self.tempDict objectForKey:KEY_IMAGE];
			NSData *data = UIImagePNGRepresentation(img);
			owner.image = data;
		}
		if([self.tempDict objectForKey:[NSString stringWithFormat:@"%d",OWNER_PREFIX]])
		{
			owner.prefix = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",OWNER_PREFIX]];
		}
		if([self.tempDict objectForKey:[NSString stringWithFormat:@"%d",OWNER_FIRST]])
		{
			owner.first = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",OWNER_FIRST]];
		}
		if([self.tempDict objectForKey:[NSString stringWithFormat:@"%d",OWNER_LAST]])
		{
			owner.last = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",OWNER_LAST]];
		}
		if([self.tempDict objectForKey:[NSString stringWithFormat:@"%d",OWNER_ADDRESS]])
		{
			owner.address = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",OWNER_ADDRESS]];
		}
		if([self.tempDict objectForKey:[NSString stringWithFormat:@"%d",OWNER_CITY]])
		{
			owner.city = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",OWNER_CITY]];
		}
		if([self.tempDict objectForKey:[NSString stringWithFormat:@"%d",OWNER_STATE]])
		{
			owner.state = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",OWNER_STATE]];
		}
		if([self.tempDict objectForKey:[NSString stringWithFormat:@"%d",OWNER_POSTAL_CODE]])
		{
			owner.postal_code = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",OWNER_POSTAL_CODE]];
		}
		if([self.tempDict objectForKey:[NSString stringWithFormat:@"%d",OWNER_HOME_PHONE]])
		{
			owner.home_phone = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",OWNER_HOME_PHONE]];
		}
		if([self.tempDict objectForKey:[NSString stringWithFormat:@"%d",OWNER_WORK_PHONE]])
		{
			owner.work_phone = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",OWNER_WORK_PHONE]];
		}
		if([self.tempDict objectForKey:[NSString stringWithFormat:@"%d",OWNER_MOBILE]])
		{
			owner.mobile = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",OWNER_MOBILE]];
		}
		if([self.tempDict objectForKey:[NSString stringWithFormat:@"%d",OWNER_EMAIL]])
		{
			owner.email = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",OWNER_EMAIL]];
		}
		[appDelegate saveContext];
	}
	
	[self.navigationController popViewControllerAnimated:YES];
}

-(BOOL)hasOwnerName
{
	if([self.txtFldOwnerFirstName isFirstResponder])
		[self.txtFldOwnerFirstName resignFirstResponder];
	if([self.txtFldOwnerLastName isFirstResponder])
		[self.txtFldOwnerLastName resignFirstResponder];
	
	NSString *fText = self.txtFldOwnerFirstName.text;
	NSString *lText = self.txtFldOwnerLastName.text;
	
	if(!fText) return NO;
	if(!lText) return NO;
	
	fText = [fText stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	lText = [lText stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	
	return (([fText length] > 0) && ([lText length] > 0));
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	self.tempDict = [[NSMutableDictionary alloc] init];
}

-(void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	
	[Utility increaseHeightOfTableView:self.rtOwnerAddTableView];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return OWNER_NO_OF_SECTION;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	switch (section) 
	{
		case 0:
			return 1;
		case 1:
			return 2;
		case 2:
			return 4;
		case 3:
			return 3;
		case 4:
			return 1;
	}
	return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return HEIGHT_FOR_ROW;
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	//static NSString *cellIdentifier = @"CellID";
	CustomCell *cell = [[[CustomCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil ReadOnly:NO] autorelease];
	cell.textField.delegate = self;
	
	switch(indexPath.section)
	{
		case 0:
			[cell.label removeFromSuperview];
			self.btn = [UIButton buttonWithType:UIButtonTypeCustom];
			self.btn.frame = CGRectMake(5, 5, 34, 34);
			if([self.tempDict valueForKey:KEY_IMAGE])
				[self.btn setImage:[self.tempDict valueForKey:KEY_IMAGE] forState:UIControlStateNormal];
			else
				[self.btn setImage:[UIImage imageNamed:HOUSE_ICON] forState:UIControlStateNormal];
			[self.btn addTarget:self action:@selector(takePicture:) forControlEvents:UIControlEventTouchUpInside];
			[cell.contentView addSubview:self.btn];
			cell.textField.text = @"ADD PHOTO";
			cell.textField.userInteractionEnabled = NO;
			return cell;
		case 1:
			switch(indexPath.row)
		{
			case 0:
				cell.label.text = @"First :";
				cell.textField.placeholder = @"First Name";
				cell.textField.tag = OWNER_FIRST;
				cell.textField.text = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",cell.textField.tag]];
				self.txtFldOwnerFirstName = cell.textField;
				return cell;
			case 1:
				cell.label.text = @"Last :";
				cell.textField.placeholder = @"Last Name";
				cell.textField.tag = OWNER_LAST;
				cell.textField.text = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",cell.textField.tag]];
				self.txtFldOwnerLastName = cell.textField;
				return cell;
		}
		case 2:					
			switch(indexPath.row)
			{
			case 0:
				cell.label.text = @"Address :";
				cell.textField.placeholder = @"Address";
				cell.textField.tag = OWNER_ADDRESS;
				cell.textField.text = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",cell.textField.tag]];
				return cell;
			case 1:
				cell.label.text = @"City :";
				cell.textField.placeholder = @"City";
				cell.textField.tag = OWNER_CITY;
				cell.textField.text = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",cell.textField.tag]];
				return cell;
			case 2:
				cell.label.text = @"State :";
				cell.textField.placeholder = @"State";
				cell.textField.tag = OWNER_STATE;
				cell.textField.autocapitalizationType = UITextAutocapitalizationTypeAllCharacters;
				cell.textField.text = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",cell.textField.tag]];
				return cell;
			case 3:
				cell.label.text = @"Postal Code :";
				cell.textField.placeholder = @"Postal Code";
				cell.textField.tag = OWNER_POSTAL_CODE;
				cell.textField.keyboardType = UIKeyboardTypeNumberPad;
				cell.textField.text = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",cell.textField.tag]];
				return cell;
			}
		case 3:
			switch(indexPath.row)
			{
			case 0:
				cell.label.text = @"Home Phone :";
				cell.textField.placeholder = @"Home Phone";
				cell.textField.tag = OWNER_HOME_PHONE;
				cell.textField.keyboardType = UIKeyboardTypePhonePad;	
				cell.textField.text = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",cell.textField.tag]];
				return cell;
			case 1:
				cell.label.text = @"Work Phone :";
				cell.textField.placeholder = @"Work Phone";
				cell.textField.tag = OWNER_WORK_PHONE;
				cell.textField.keyboardType = UIKeyboardTypePhonePad;
				cell.textField.text = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",cell.textField.tag]];
				return cell;
			case 2:
				cell.label.text = @"Mobile :";
				cell.textField.placeholder = @"Mobile";
				cell.textField.tag = OWNER_MOBILE;
				cell.textField.keyboardType = UIKeyboardTypePhonePad;
				cell.textField.text = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",cell.textField.tag]];
				return cell;
			}
		case 4:
			cell.label.text = @"Email :";
			cell.textField.placeholder = @"Email";
			cell.textField.tag = OWNER_EMAIL;
			cell.textField.keyboardType = UIKeyboardTypeEmailAddress;
			cell.textField.autocapitalizationType = UITextAutocapitalizationTypeNone;
			cell.textField.autocorrectionType = UITextAutocorrectionTypeNo;
			cell.textField.text = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",cell.textField.tag]];
			return cell;
	}
	return cell;
}

-(void)takePicture:(id)sender
{
	self.btn = (UIButton *)sender;
	ImagePicker *picker = [[ImagePicker alloc] init];
	picker.delegate = self;
	picker.vc = self;
	[picker clickAddPictureAtViewController:[self.btn superview]];
}

-(void) didReceivePicture:(UIImage *)img
{
	img = [img fixOrientation];
	[self.tempDict setObject:img forKey:KEY_IMAGE];
	[self.btn setImage:img forState:UIControlStateNormal];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	if(indexPath.section == 0)
	{
		self.btn = [[tableView cellForRowAtIndexPath:indexPath].contentView.subviews objectAtIndex:1];
		
		[self takePicture:self.btn];
		return;
	}
}


#pragma mark -
#pragma mark TextField Delegate Method

// return NO to disallow editing.
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
	[Utility decreaseHeightOfTableView:self.rtOwnerAddTableView];
	return YES;
}

// became first responder
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
	tempTextField = textField;
}

// return YES to allow editing to stop and to resign first responder status. NO to disallow the editing session to end
- (BOOL)textFieldShouldEndEditing:(UITextField *)textField         
{
	return YES;
}

// may be called if forced even if shouldEndEditing returns NO (e.g. view removed from window) or endEditing:YES called
- (void)textFieldDidEndEditing:(UITextField *)textField             
{
	[self.tempDict setObject:textField.text forKey:[NSString stringWithFormat:@"%d",textField.tag]];
}

// called when clear button pressed. return NO to ignore (no notifications)
- (BOOL)textFieldShouldClear:(UITextField *)textField
{
	return YES;
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
	if((textField.tag == OWNER_HOME_PHONE) 
	   || (textField.tag == OWNER_WORK_PHONE) || (textField.tag == OWNER_MOBILE))
	{
		[Utility formatPhoneNumber:textField withRange:range replacementString:string];
		NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:VALID_INTEGER] invertedSet];
		NSString *filtered = [[string componentsSeparatedByCharactersInSet:cs] componentsJoinedByString:@""];
		return [string isEqualToString:filtered];
	}
	if(textField.tag == OWNER_POSTAL_CODE)
	{
		NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:VALID_INTEGER] invertedSet];
		NSString *filtered = [[string componentsSeparatedByCharactersInSet:cs] componentsJoinedByString:@""];
		return [string isEqualToString:filtered];
	}
	return YES;
}
// called when 'return' key pressed. return NO to ignore.
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
	if(textField.tag == OWNER_EMAIL)
	{
		if(![Utility isEmailValid:textField.text])
		{
			[Utility showAlertViewWithTitle:TITLE Message:MESSAGE_INVALID_EMAIL_ID CancelTitle:CANCEL_TITLE];
			return NO;
		}
	}
	[Utility increaseHeightOfTableView:self.rtOwnerAddTableView];
	
	[textField resignFirstResponder];
	return YES;
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
	//[tempDict_ release];
}

- (void)viewDidUnload {
	
	self.rtOwnerAddTableView = nil;
	self.tempDict = nil;
	self.txtFldOwnerFirstName = nil;
	self.txtFldOwnerLastName = nil;
	
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
	
}


- (void)dealloc {
	self.rtOwnerAddTableView = nil;
	self.tempDict = nil;
	self.txtFldOwnerFirstName = nil;
	self.txtFldOwnerLastName = nil;
	
    [super dealloc];
}


@end
