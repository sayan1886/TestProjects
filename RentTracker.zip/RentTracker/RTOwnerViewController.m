//
//  RTOwnerViewController.m
//  RentTracker
//
//  Created by ASHIM SAMANTA on 06/03/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import "RTOwnerViewController.h"
#import "RTOwnerAddViewController.h"
#import "RTOwnerEditViewController.h"
#import "Constant.h"
#import "CoreDataHelper.h"
#import "AppDelegate_iPhone.h"
#import "Owner.h"
#import "Utility.h"

@implementation RTOwnerViewController

@synthesize rtOwnerTableView = rtOwnerTableView_;
@synthesize searchText = searchText_;
@synthesize array = array_;
@synthesize resultdict = resultdict_;
@synthesize arr = arr_;


// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"Owner";
		UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(add:)];
		self.navigationItem.rightBarButtonItem = item;
		[item release];
    }
    return self;
}

-(void)add:(id)sender
{
	RTOwnerAddViewController *viewController = [[RTOwnerAddViewController alloc] initWithNibName:@"RTOwnerAddViewController" bundle:nil];
	[self.navigationController pushViewController:viewController animated:YES];
	[viewController release];
}


#pragma mark -
#pragma mark TableView delegate method

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
	return HEIGHT_FOR_HEADER;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
	if(![tableView isEqual:self.rtOwnerTableView]) return nil;
	UIView *header = [[[UIView alloc]initWithFrame:CONTACT_HEADER_FRAME] autorelease];
	header.backgroundColor = [UIColor colorWithPatternImage:[[UIImage imageNamed:CONTACT_HEADER_IMAGE] stretchableImageWithLeftCapWidth:0 topCapHeight:32]];
	
	UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, 6, 20, 20)];
	
	if([tableView isEqual:self.rtOwnerTableView]) 
	{
		label.text = [self.arr objectAtIndex:section];
	}
	else
	{
		label.text = [[self.searchText objectAtIndex:section] valueForKey:@"first"];
	}
	
	label.backgroundColor = [UIColor clearColor];
	label.textColor = [UIColor whiteColor];
	
	[header addSubview:label];
	
	[label release];
	return header;
}

// return list of section titles to display in section index view (e.g. "ABCD...Z#")
-(NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView
{
	if(![tableView isEqual:self.rtOwnerTableView]) return nil;
	NSMutableArray *toBeReturned = [[NSMutableArray alloc]init];
    for(char c = 'A'; c <= 'Z'; c++) [toBeReturned addObject:[NSString stringWithFormat:@"%c",c]];
    return [toBeReturned autorelease];
}

// tell table which section corresponds to section title/index (e.g. "B",1))

-(NSInteger)tableView:(UITableView *)tableView sectionForSectionIndexTitle:(NSString *)title atIndex:(NSInteger)index
{
	NSLog(@"index = %d", index);
	return index;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	if([tableView isEqual:self.rtOwnerTableView])
	{
		NSArray *arrRes = [self.resultdict objectForKey:[self.arr objectAtIndex:section]];
		return [arrRes count];
	}
	return [self.searchText count];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	if([tableView isEqual:self.rtOwnerTableView])
	{
		return [self.arr count];
	}
	return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	static NSString *cellID = @"cellID";
	NSString *text = @"";
	if([tableView isEqual:self.rtOwnerTableView]) 
	{
		NSString *val = [self.arr objectAtIndex:indexPath.section];
		NSArray *arrTemp = [self.resultdict objectForKey:val];
		Owner *owner = [arrTemp objectAtIndex:indexPath.row];
		if(owner.first)
			text = [owner.first stringByAppendingString:@" "];
		if(owner.last)
			text = [text stringByAppendingString:owner.last];
		arrTemp = nil;
	}
	else 
	{
		text = [[self.searchText objectAtIndex:indexPath.row] valueForKey:@"first"];
		text = [text stringByAppendingFormat:@" %@",[[self.searchText objectAtIndex:indexPath.row] valueForKey:@"last"]];
	}
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
	if(!cell)
	{
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID] autorelease];
		
		cell.textLabel.text = text;
	}
	else
		cell.textLabel.text = text;
	return cell;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
	AppDelegate_iPhone *app = (AppDelegate_iPhone *)[[UIApplication sharedApplication] delegate];
	NSArray *arrTodel = [self.resultdict allKeys];
	NSString *val = [arrTodel objectAtIndex:indexPath.section];
	arrTodel = [self.resultdict objectForKey:val];
	Owner *owner = [arrTodel objectAtIndex:indexPath.row];
	[app.managedObjectContext deleteObject:owner];
	[app saveContext];
	
	[self getValuesFromContext];
	[tableView reloadData];
}
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
	
	return YES;
}
- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return UITableViewCellEditingStyleDelete;	
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	Owner *owner = nil;
	if([tableView isEqual:self.rtOwnerTableView])
	{
		NSString *val = [self.arr objectAtIndex:indexPath.section];
		self.arr = [self.resultdict objectForKey:val];
		owner = [self.arr objectAtIndex:indexPath.row];
	}
	else {
		owner = [self.searchText objectAtIndex:indexPath.row];
	}

	RTOwnerEditViewController *viewController = [[RTOwnerEditViewController alloc] initWithNibName:@"RTOwnerEditViewController" bundle:nil];
	viewController.owner = owner;
	[self.navigationController pushViewController:viewController animated:YES];
	[viewController release]; viewController = nil;
}


#pragma mark -
#pragma mark SEARCH

- (BOOL)searchDisplayController:(UISearchDisplayController *)controller shouldReloadTableForSearchString:(NSString *)searchString
{    
    [self.searchText removeAllObjects];
    
    for (Owner *own in self.array)
    {
		NSString *aStr = own.first;
		aStr = [aStr stringByAppendingFormat:@" %@",own.last]; 
		aStr = [aStr lowercaseString];
		if ([aStr rangeOfString:[searchString lowercaseString]].location != NSNotFound)
            [self.searchText addObject:own];
    }
	
    [controller.searchResultsTableView reloadData];
    
    return NO;
}

- (void)searchDisplayControllerWillBeginSearch:(UISearchDisplayController *)controller
{
    self.rtOwnerTableView.hidden = YES;
}

- (void)searchDisplayControllerDidEndSearch:(UISearchDisplayController *)controller
{
    self.rtOwnerTableView.hidden = NO;
}

-(void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	[self getValuesFromContext];
	[self.rtOwnerTableView reloadData];
}

-(void)getValuesFromContext
{
	AppDelegate_iPhone *app = (AppDelegate_iPhone *)[[UIApplication sharedApplication]delegate];
	self.array = [CoreDataHelper getObjectsFromContext:ENTITY_KEY_OWNER :@"first" :YES :app.managedObjectContext];	
	self.resultdict = [Utility arrangeList:self.array sortKey:@"first"];
	self.arr = [self.resultdict allKeys];
	self.arr = [self.arr sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	self.searchText = [[NSMutableArray alloc] init];
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
	
	self.rtOwnerTableView = nil;
	self.searchText = nil;
	self.array = nil;
	self.resultdict = nil;
	self.arr = nil;
	
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	
	self.rtOwnerTableView = nil;
	self.searchText = nil;
	self.array = nil;
	self.resultdict = nil;
	self.arr = nil;
	
    [super dealloc];
}


@end
