//
//  RTTenantEditViewController.m
//  RentTracker
//
//  Created by ASHIM SAMANTA on 29/02/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import "RTTenantEditViewController.h"
#import "Constant.h"
#import "CustomCell.h"
#import "AppDelegate_iPhone.h"
#import "Utility.h"
#import "CoreDataHelper.h"
#import "Building.h"
#import "NSManagedObjectContext+insert.h"
#import "UIImage+TKCategory.h"



@implementation RTTenantEditViewController
@synthesize fromAlert;
@synthesize cause;
@synthesize rtTableViewFirst = rtTableViewFirst_;
@synthesize rtTableView = rtTableView_;
@synthesize scrollView = scrollView_;

@synthesize labelCause = labelCause_;
@synthesize lableFirst = lableFirst_;
@synthesize lableBuilding =lableBuilding_;
@synthesize btnIcon;
@synthesize rightItem = rightItem_;
@synthesize dict;
@synthesize tenant = tenant_;
@synthesize array = array_;
@synthesize buildingArray = buildingArray_;

@synthesize address = address_;
@synthesize city = city_;
@synthesize state = state_;
@synthesize postalCode = postalCode_;
@synthesize datePicker = datePicker_;
@synthesize depPaidDate = depPaidDate_;
@synthesize moveInDate = moveInDate_;

@synthesize building = building_;
@synthesize fName = fName_;
@synthesize lName = lName_;
@synthesize rentAmount = rentAmount_;
@synthesize note = note_;
@synthesize rentDayArray = rentDayArray_;
@synthesize rentDueDay = rentDueDay_;
@synthesize leasePeriodArray = leasePeriodArray_;
@synthesize rentLeasePeriod = rentLeasePeriod_;
@synthesize txtLeaseStartDate = txtLeaseStartDate_;

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) 
	{
       
		self.rightItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem: UIBarButtonSystemItemEdit  target:self action:@selector(edit:)];
		
		self.navigationItem.rightBarButtonItem = self.rightItem;
		isReadOnly = YES;
		isPickerViewVisible = NO;
    }
    return self;
}

-(void)edit:(id)sender
{
	isReadOnly = NO;
	self.btnIcon.enabled = !isReadOnly;
	[self.rtTableView removeFromSuperview];
	
	UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem: UIBarButtonSystemItemDone  target:self action:@selector(done:)];
	[self.navigationItem setRightBarButtonItem:item animated:YES];
	[item release];item = nil;
	
	[self.navigationItem setHidesBackButton:YES animated:YES];
	item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem: UIBarButtonSystemItemCancel  target:self action:@selector(cancel:)];
	
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.05];
	[UIView setAnimationDelegate:self];
	[self.lableFirst removeFromSuperview];
	[self.lableBuilding removeFromSuperview];
	[self.navigationItem setLeftBarButtonItem:item animated:YES];
	[UIView commitAnimations];
	
	[item release];item = nil;
}

-(void)animationDidStop:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context
{
	[self addView];
}

-(void)addView
{
	[self.scrollView addSubview:self.rtTableViewFirst];
	[self.scrollView addSubview:self.rtTableView];
	[self.rtTableView reloadData];
}

-(void)done:(id)sender
{
	
	if([tempTextField isFirstResponder])
		[tempTextField resignFirstResponder];
	if([self.note isFirstResponder])
		[self.note resignFirstResponder];
	if(![self hasNameBuildingAndRentAmount])
	{
		[Utility showAlertViewWithTitle:TITLE_MANDATORY_FIELD Message:MESSAGE_TENANT_MANDATORY_FIELD CancelTitle:CANCEL_TITLE];
		return ;
	}
	isReadOnly = YES;
	self.btnIcon.enabled = !isReadOnly;
	[self.rtTableViewFirst removeFromSuperview];
	[self.scrollView addSubview:self.lableFirst];
	[self.scrollView addSubview:self.lableBuilding];
	[self.rtTableView reloadData];
	
	[self.navigationItem setRightBarButtonItem:self.rightItem animated:YES];
	[self.navigationItem setLeftBarButtonItem:nil animated:YES];
	[self.navigationItem setHidesBackButton:NO animated:YES];
	[self updateData];
	
	NSString *name = [self.dict valueForKey:[NSString stringWithFormat:@"%d",FIRST]];

	self.lableFirst.text = [name stringByAppendingFormat:@" %@",[self.dict valueForKey:[NSString stringWithFormat:@"%d",LAST]]];
	name = [self.dict valueForKey:[NSString stringWithFormat:@"%d",BUILDING]];

	self.lableBuilding.text = name;

	//modify to change.
}
-(void)cancel:(id)sender
{
	isReadOnly = YES;
	self.btnIcon.enabled = !isReadOnly;
	isReadOnly = YES;
	self.btnIcon.enabled = !isReadOnly;
	[self loadValues];
	[self.rtTableViewFirst removeFromSuperview];
	[self.scrollView addSubview:self.lableFirst];
	[self.scrollView addSubview:self.lableBuilding];
	[self.rtTableView reloadData];
	
	[self.navigationItem setRightBarButtonItem:self.rightItem animated:YES];
	[self.navigationItem setLeftBarButtonItem:nil animated:YES];
	[self.navigationItem setHidesBackButton:NO animated:YES];
	
	NSString *name = [self.dict valueForKey:[NSString stringWithFormat:@"%d",FIRST]];

	self.lableFirst.text = [name stringByAppendingFormat:@" %@",[self.dict valueForKey:[NSString stringWithFormat:@"%d",LAST]]];
	name = [self.dict valueForKey:[NSString stringWithFormat:@"%d",BUILDING]];
	self.lableBuilding.text = name;

}

#pragma mark -
#pragma mark tableView delegate method.

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	if([tableView isEqual:self.rtTableViewFirst])
		return 1;
	return TENANT_NO_OF_SECTION;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	if([tableView isEqual:self.rtTableViewFirst])
		return 3;
	
	switch (section) 
	{
		case 0:
		case 1:
		case 2:
			return 4;
		case 3:
			return 3;
		case 4:
			return 1;
		case 5:
			return 1;
	}
	return 0;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	if(indexPath.section==5)
		return HEIGHT_FOR_NOTE_ROW;
	return HEIGHT_FOR_ROW;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	CustomCell *cell = nil;
	if([tableView isEqual:self.rtTableViewFirst])
	{
		CGRect frame;
		cell = [Utility cellForRowAtPathForTenantFirstTableView:indexPath isReadOnly:isReadOnly];
		frame = cell.textField.frame;
		frame.origin.x -=100;
		frame.size.width+=20;
		cell.textField.frame = frame;
		
		if(cell.textField.tag == FIRST)
			self.fName = cell.textField;
		else if(cell.textField.tag == LAST)
			self.lName = cell.textField;
		else if(cell.textField.tag == BUILDING)
			self.building = cell.textField;
		
	}
	else
	{
		cell = [Utility cellForRowAtPathForTenantSecondTableView:indexPath isReadOnly:isReadOnly];
		
		if(cell.textField.tag == ADDRESS)
			self.address = cell.textField;
		else if(cell.textField.tag == CITY)
			self.city = cell.textField;
		else if(cell.textField.tag == STATE)
			self.state = cell.textField;
		else if(cell.textField.tag == POSTALCODE)
			self.postalCode = cell.textField;
		else if(cell.textField.tag == DEP_PAID_DATE)
			self.depPaidDate = cell.textField;
		else if(cell.textField.tag == MOVE_IN_DATE)
			self.moveInDate = cell.textField;
		else if(cell.textField.tag == RENT_AMT)
			self.rentAmount = cell.textField;
		else if(cell.textField.tag == LEASE_START_DATE)
			self.txtLeaseStartDate = cell.textField;
		else if(cell.textField.tag == LEASE_PERIOD)
			self.rentLeasePeriod = cell.textField;
		else if(cell.textField.tag == RENT_DUE_DAY)
			self.rentDueDay = cell.textField;
		else if(cell.textField.tag == MOVE_OUT)
		{
			[[cell.contentView subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
			cell.textLabel.text = @"Tenant Move Out : ";
			if(isMoveOut)
				cell.accessoryType = UITableViewCellAccessoryCheckmark;
			else
				cell.accessoryType = UITableViewCellAccessoryNone;
		}
	}
	cell.textField.text = [self.dict valueForKey:[NSString stringWithFormat:@"%d",cell.textField.tag]];
	cell.textField.delegate = self;
	
	if(cell.textField.tag == NOTE)
	{
		[[cell.contentView subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
		cell.textLabel.text = @"NOTE :";
		CGRect frame;
		if(ISIPHONE)
			frame = CGRectMake(100, 5, 200, 122.0);
		else
			frame = CGRectMake(100, 5, 560, 122.0);
		self.note = [[UITextView alloc] initWithFrame:frame];
		self.note.backgroundColor = [UIColor clearColor];
		[cell.contentView addSubview:self.note];
		self.note.delegate = self;
		self.note.tag = NOTE;
		self.note.userInteractionEnabled = !isReadOnly;
		self.note.text = [self.dict objectForKey:[NSString stringWithFormat:@"%d",self.note.tag]];
	}
	return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	if(isReadOnly)
	{
		CustomCell *cell = (CustomCell *)[tableView cellForRowAtIndexPath:indexPath];
		NSString *str = nil;
		switch(cell.textField.tag)
		{
			case ADDRESS:
			case CITY:
			case STATE:
				str = @"";
				str = [self.dict valueForKey:[NSString stringWithFormat:@"%d",ADDRESS]];
				str = [str stringByAppendingFormat:@" %@",[self.dict valueForKey:[NSString stringWithFormat:@"%d",CITY]]];
				str = [str stringByAppendingFormat:@" %@",[self.dict valueForKey:[NSString stringWithFormat:@"%d",STATE]]];
				str = [str stringByReplacingOccurrencesOfString:@" " withString:@"+"];
			    [Utility launchMapWithAddress:str];
				return ;
			case HOME_PHONE:
			case WORK_PHONE:
			case MOBILE:
				str = cell.textField.text;
				str = [str stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
				[Utility makePhoneCallWithPhoneNumber:str];
				return ;
			case EMAIL:
				str = cell.textField.text;
				str = [str stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
				NSLog(@"%d",[Utility launchMailWithTo:str]);
				return ;
				
		}
	}
	else
	{
		if(indexPath.section == 4)
		{
			isMoveOut = !isMoveOut;
			[tableView reloadData];
		}
	}
}

-(IBAction)addPhoto:(id)sender
{
	self.btnIcon = (UIButton *)sender;
	ImagePicker *picker = [[ImagePicker alloc] init] ;
	picker.delegate = self;
	picker.vc = self;
	[picker clickAddPictureAtViewController:[self.btnIcon superview]];
}

-(void) didReceivePicture:(UIImage *)img
{
	img = [img fixOrientation];
	[self.dict setObject:img forKey:KEY_IMAGE];
	[self.btnIcon setImage:img forState:UIControlStateNormal];
}

#pragma mark -
#pragma mark TextField Delegate Method

// return NO to disallow editing.
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
	if(isPickerViewVisible)
	{
		isPickerViewVisible = NO;
		[Utility hidesDropDown:pView];
	}
	if(textField.tag == BUILDING)
	{
		if([self.note isFirstResponder])
			[self.note resignFirstResponder];
		if([tempTextField isFirstResponder])
			[tempTextField resignFirstResponder];
		if([self.buildingArray count])
		{
			tempTextField = textField;
			pickerTag = PICKER;
		
			if([pickerView superview])
				[pickerView removeFromSuperview];
			if([self.datePicker superview])
				[self.datePicker removeFromSuperview];
			[pickerView reloadAllComponents];
			[pickerView selectRow:0 inComponent:0 animated:YES];
		
			selectedIndex = 0;
			Building *building = [self.buildingArray objectAtIndex:selectedIndex];
			self.address.text = building.address;
			self.city.text = building.city;
			self.state.text = building.state;
			self.postalCode.text = building.postal_code;
			[self.dict setObject:building.address forKey:[NSString stringWithFormat:@"%d",BUILDING]];
			tempTextField.text = [self.array objectAtIndex:selectedIndex];
			[pView addSubview:pickerView];
			[Utility showDropDown:pView];
		
		}
		else
		{
			[Utility showAlertViewWithTitle:TITLE_MANDATORY_FIELD Message:MESSAGE_TENANT_MANDATORY_FIELD CancelTitle:CANCEL_TITLE];
		}
		return NO;
	}
	
	if((textField.tag == HOME_PHONE) || (textField.tag == WORK_PHONE))
	{
		[UIView beginAnimations:nil context:nil];
		[UIView setAnimationBeginsFromCurrentState:YES];
		[UIView setAnimationDuration:0.30];
		[self.scrollView setContentOffset:CGPointMake(0, 390)];
		[UIView commitAnimations];
	}
	if((textField.tag == MOBILE) || (textField.tag == EMAIL))
	{
		[UIView beginAnimations:nil context:nil];
		[UIView setAnimationBeginsFromCurrentState:YES];
		[UIView setAnimationDuration:0.30];
		[self.scrollView setContentOffset:CGPointMake(0, 480)];
		[UIView commitAnimations];
	}
		
	if((textField.tag == MOVE_IN_DATE) || (textField.tag == DEP_PAID_DATE) || (textField.tag == LEASE_START_DATE))
	{
		if([self.note isFirstResponder])
			[self.note resignFirstResponder];
		if([tempTextField isFirstResponder])
			[tempTextField resignFirstResponder];
		tempTextField = textField;
		pickerTag = DATE_PICKER;
		
		if([pickerView superview])
			[pickerView removeFromSuperview];
		if([self.datePicker superview])
			[self.datePicker removeFromSuperview];
		
		[pView addSubview:self.datePicker];
		[Utility showDropDown:pView];
		return NO;
	}
	
	if(textField.tag == RENT_DUE_DAY)
	{
		if([self.note isFirstResponder])
			[self.note resignFirstResponder];
		if([tempTextField isFirstResponder])
			[tempTextField resignFirstResponder];
		tempTextField = textField;
		pickerTag = RENT_DUE_DAY_PICKER;
		
		if([pickerView superview])
			[pickerView removeFromSuperview];
		if([self.datePicker superview])
			[self.datePicker removeFromSuperview];
		[pickerView reloadAllComponents];
		[pickerView selectRow:0 inComponent:0 animated:YES];
		[self pickerView:pickerView didSelectRow:0 inComponent:0];
		[pView addSubview:pickerView];
		[Utility showDropDown:pView];
		return NO;
	}
	if(textField.tag == LEASE_PERIOD)
	{
		if([self.note isFirstResponder])
			[self.note resignFirstResponder];
		if([tempTextField isFirstResponder])
			[tempTextField resignFirstResponder];
		tempTextField = textField;
		pickerTag = LEASE_PERIOD_PICKER;
		
		if([pickerView superview])
			[pickerView removeFromSuperview];
		if([self.datePicker superview])
			[self.datePicker removeFromSuperview];
		[pickerView reloadAllComponents];
		[pickerView selectRow:0 inComponent:0 animated:YES];
		[self pickerView:pickerView didSelectRow:0 inComponent:0];
		[pView addSubview:pickerView];
		[Utility showDropDown:pView];
		return NO;
	}
	tempTextField = textField;
	return YES;
}


// became first responder
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
	
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
	if((textField.tag == HOME_PHONE) || (textField.tag == WORK_PHONE) || (textField.tag == MOBILE))
	{
		[Utility formatPhoneNumber:textField withRange:range replacementString:string];
		NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:VALID_INTEGER] invertedSet];
		NSString *filtered = [[string componentsSeparatedByCharactersInSet:cs] componentsJoinedByString:@""];
		return [string isEqualToString:filtered];
	}
	else if((textField.tag == DEPOSIT_AMT))
	{
		NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:VALID_FLOAT] invertedSet];
		NSString *filtered = [[string componentsSeparatedByCharactersInSet:cs] componentsJoinedByString:@""];
		return [string isEqualToString:filtered];
	}
	
	return YES;
}
// return YES to allow editing to stop and to resign first responder status. NO to disallow the editing session to end
- (BOOL)textFieldShouldEndEditing:(UITextField *)textField         
{
	
	return YES;
}

// may be called if forced even if shouldEndEditing returns NO (e.g. view removed from window) or endEditing:YES called
- (void)textFieldDidEndEditing:(UITextField *)textField             
{
	[self.dict setObject:textField.text forKey:[NSString stringWithFormat:@"%d",textField.tag]];
	[textField resignFirstResponder];
}

// called when clear button pressed. return NO to ignore (no notifications)
- (BOOL)textFieldShouldClear:(UITextField *)textField
{
	return YES;
}

// called when 'return' key pressed. return NO to ignore.
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationBeginsFromCurrentState:YES];
	[UIView setAnimationDuration:0.30];
	[self.scrollView setContentOffset:CGPointMake(0, 0)];
	[UIView commitAnimations];
	[textField resignFirstResponder];
	return YES;
}


#pragma mark -
#pragma mark TextView Delegate

- (BOOL)textViewShouldBeginEditing:(UITextView *)textView
{
	if(textView.tag == NOTE)
	{
		[self addToolBar:textView];
		[UIView beginAnimations:nil context:nil];
		[UIView setAnimationBeginsFromCurrentState:YES];
		[UIView setAnimationDuration:0.30];
		if(ISIPHONE)
			[self.scrollView setContentOffset:CGPointMake(0, 990)];
		else
			[self.scrollView setContentOffset:CGPointMake(0, 525)];
		[UIView commitAnimations];
		return YES;
	}
	return YES;
	
}

- (void)textViewDidEndEditing:(UITextView *)textView
{
	if([textView.text length])
		[self.dict setObject:textView.text forKey:[NSString stringWithFormat:@"%d",textView.tag]];
}

#pragma mark -
#pragma mark fetchManagedObject

-(void)fetchManagedObject
{
	AppDelegate_iPhone *app = (AppDelegate_iPhone *)[[UIApplication sharedApplication] delegate];
	NSPredicate *predicate = [NSPredicate predicateWithFormat:@"self == %@",self.tenant];
	NSMutableArray *arr = [CoreDataHelper searchObjectsInContext:ENTITY_KEY_TENANT :predicate :nil :NO :app.managedObjectContext];
	self.tenant = [arr objectAtIndex:0];
}

-(void)loadValues
{	
	if(self.tenant.image)
	{
		UIImage *img = [UIImage imageWithData:self.tenant.image];
		img = [img fixOrientation];
		[self.btnIcon setImage:img forState:UIControlStateNormal];
	}
	if(self.tenant.building)
	{
		[self.dict setObject:self.tenant.building.address forKey:[NSString stringWithFormat:@"%d",BUILDING]];
	}
	if(self.tenant.first)
	{
		[self.dict setObject:self.tenant.first forKey:[NSString stringWithFormat:@"%d",FIRST]];
	}
	if(self.tenant.last)
	{
		[self.dict setObject:self.tenant.last forKey:[NSString stringWithFormat:@"%d",LAST]];
	}
	if(self.tenant.address)
	{
		[self.dict setObject:self.tenant.address forKey:[NSString stringWithFormat:@"%d",ADDRESS]];
	}
	if(self.tenant.city)
	{
		[self.dict setObject:self.tenant.city forKey:[NSString stringWithFormat:@"%d",CITY]];
	}
	if(self.tenant.state)
	{
		[self.dict setObject:self.tenant.state forKey:[NSString stringWithFormat:@"%d",STATE]];
	}
	if(self.tenant.postal_code)
	{
		[self.dict setObject:self.tenant.postal_code forKey:[NSString stringWithFormat:@"%d",POSTALCODE]];
	}
	if(self.tenant.home_phone)
	{
		[self.dict setObject:self.tenant.home_phone forKey:[NSString stringWithFormat:@"%d",HOME_PHONE]];
	}
	if(self.tenant.work_phone)
	{
		[self.dict setObject:self.tenant.work_phone forKey:[NSString stringWithFormat:@"%d",WORK_PHONE]];
	}
	if(self.tenant.mobile)
	{
		[self.dict setObject:self.tenant.mobile forKey:[NSString stringWithFormat:@"%d",MOBILE]];
	}
	if(self.tenant.rentAmount)
	{
		[self.dict setObject:self.tenant.rentAmount forKey:[NSString stringWithFormat:@"%d",RENT_AMT]];
	}
	if(self.tenant.deposit_amount)
	{
		[self.dict setObject:self.tenant.deposit_amount forKey:[NSString stringWithFormat:@"%d",DEPOSIT_AMT]];
	}
	if(self.tenant.dep_paid_date)
	{
		[self.dict setObject:self.tenant.dep_paid_date forKey:[NSString stringWithFormat:@"%d",DEP_PAID_DATE]];
	}
	if(self.tenant.moveOut)
	{
		isMoveOut = [self.tenant.moveOut boolValue];
	}
	if(self.tenant.move_in_date)
	{
		[self.dict setObject:self.tenant.move_in_date forKey:[NSString stringWithFormat:@"%d",MOVE_IN_DATE]];
	}
	if(self.tenant.email)
	{
		[self.dict setObject:self.tenant.email forKey:[NSString stringWithFormat:@"%d",EMAIL]];
	}
	if(self.tenant.note)
	{
		[self.dict setObject:self.tenant.note forKey:[NSString stringWithFormat:@"%d",NOTE]];
	}
	if(self.tenant.leasePeriod)
		[self.dict setObject:self.tenant.leasePeriod forKey:[NSString stringWithFormat:@"%d",LEASE_PERIOD]];
	if(self.tenant.leaseStartDate)
		[self.dict setObject:self.tenant.leaseStartDate forKey:[NSString stringWithFormat:@"%d",LEASE_START_DATE]];
	if(self.tenant.rentDueDay)
		[self.dict setObject:self.tenant.rentDueDay forKey:[NSString stringWithFormat:@"%d",RENT_DUE_DAY]];
}

#pragma mark -
#pragma mark toolBar for Note
-(void)addToolBar:(UITextView *)textView
{
	UIToolbar *toolBar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, 100, 35)];
	NSMutableArray *arr = [[NSMutableArray alloc] init];
	UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(ok)];
	[arr addObject:item];
	item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
	[arr addObject:item];
	item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(noteCancel:)];
	[arr addObject:item];
	
	toolBar.items = arr;
	[item release];item = nil;
	[arr release];arr = nil;
	
	textView.inputAccessoryView = toolBar;
}

-(void)noteCancel:(id)sender
{
	self.note.text = @"";
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationBeginsFromCurrentState:YES];
	[UIView setAnimationDuration:0.30];
	[self.rtTableView setContentOffset:CGPointMake(0,0)];
	[UIView commitAnimations];
	[self.note resignFirstResponder];
}
-(void)ok
{
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationBeginsFromCurrentState:YES];
	[UIView setAnimationDuration:0.30];
	[self.rtTableView setContentOffset:CGPointMake(0,0)];
	[UIView commitAnimations];
	
	[self.note resignFirstResponder];
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	 if(self.fromAlert)
	 {
		 self.navigationItem.rightBarButtonItem = nil;
		 //self.labelCause.text = cause;
	 }
	
	self.leasePeriodArray = [[NSMutableArray alloc] init];
	self.rentDayArray = [[NSMutableArray alloc] init];
	for(int ii = 1; ii <= 31; ii++)
	{
		[self.rentDayArray addObject:[NSString stringWithFormat:@"%d",ii]];
		[self.leasePeriodArray addObject:[NSString stringWithFormat:@"%d year",ii]];
	}
	if(ISIPHONE)
		self.scrollView.contentSize = CGSizeMake(320, 1150);
	 else
		 self.scrollView.contentSize = CGSizeMake(768, 1200);
	[self.rtTableViewFirst removeFromSuperview];
	
	CGRect frame;
	self.dict = [[NSMutableDictionary alloc] init];
	
	if(ISIPHONE)
		frame = CGRectMake(0, 460, 320, 480);
	else
		frame = CGRectMake(0, 1024, 768, 1024);
	
	pView = [[UIView alloc] initWithFrame:frame];
	pView.backgroundColor = [UIColor clearColor];
	
	if(ISIPHONE)
		frame = CGRectMake(0, 199, 320, 45);
	else
		frame = CGRectMake(0, 723, 768, 65);
	
	NSMutableArray *arr = [[NSMutableArray alloc] init];
	
	UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(cancelPickerView)];
	[arr addObject:item];
	[item release]; item = nil;
	
	item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
	[arr addObject:item];
	[item release]; item = nil;
	
	item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(hidePickerView)];
	[arr addObject:item];
	[item release]; item = nil;
	
	UIToolbar *toolBar = [[UIToolbar alloc] initWithFrame:frame];
	[toolBar setItems:arr animated:YES];
	
	if(ISIPHONE)
		frame = CGRectMake(0, 244, 320, 216);
	else
		frame = CGRectMake(0, 788, 768, 216);
	
	pickerView = [[UIPickerView alloc] initWithFrame:frame];
	pickerView.showsSelectionIndicator = YES;
	pickerView.delegate = self;
	pickerView.dataSource = self;
	
	self.datePicker = [[UIDatePicker alloc] initWithFrame:frame];
	self.datePicker.datePickerMode = UIDatePickerModeDate;
	
	[pView addSubview:toolBar];

	[self.view addSubview:pView];
	[self fetchData];
	
	[toolBar release];
	[arr release];
}

#pragma mark -
#pragma mark viewWillAppear

-(void)updateAppearence
{
	[self fetchManagedObject];
	[self loadValues];
	
	NSString *name = [self.dict valueForKey:[NSString stringWithFormat:@"%d",FIRST]];
	self.lableFirst.text = [name stringByAppendingFormat:@" %@",[self.dict valueForKey:[NSString stringWithFormat:@"%d",LAST]]];
	self.lableBuilding.text = [self.dict valueForKey:[NSString stringWithFormat:@"%d",BUILDING]];
	[self.rtTableView reloadData];
}

-(void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	selectedIndex = NSNotFound;
	[self updateAppearence];
}

-(BOOL)hasNameBuildingAndRentAmount
{
	NSString *fText = self.fName.text;
	NSString *lText = self.lName.text;
	NSString *bText = self.building.text;
	NSString *rText = self.rentAmount.text;
	NSString *rDueDay = self.rentDueDay.text;
    
    NSString *leaseStartDate = self.txtLeaseStartDate.text;
    NSString *rentPeriod = self.rentLeasePeriod.text;
    
	if(!fText) return NO;
	if(!lText) return NO;
	if(!bText) return NO;
	if(!rText) return NO;
	if(!rDueDay) return NO;
    
    if(!leaseStartDate) return NO;
	if(!rentPeriod) return NO;
	
	fText = [fText stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	lText = [lText stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	bText = [bText stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	rText = [rText stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	rDueDay = [rDueDay stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    leaseStartDate = [leaseStartDate stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	rentPeriod = [rentPeriod stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
	return (([fText length] > 0) && ([lText length] > 0) && ([bText length] > 0) && ([rText length] > 0) && ([rDueDay length] > 0)&& ([leaseStartDate length] > 0)&& ([rentPeriod length] > 0));
}

-(void)updateData
{
	AppDelegate_iPhone *appDelegate =  (AppDelegate_iPhone *)[[UIApplication sharedApplication] delegate];
	
	if(self.tenant && self.dict)
	{
		if ([self.dict objectForKey:KEY_IMAGE]) 
		{
			UIImage *img = [self.dict objectForKey:KEY_IMAGE];
			NSData *data = UIImagePNGRepresentation(img);
			self.tenant.image = data;
		}
		else
			self.tenant.image = nil;
		if(selectedIndex != NSNotFound)
			self.tenant.building = [self.buildingArray objectAtIndex:selectedIndex];
		
		self.tenant.first = [self.dict objectForKey:[NSString stringWithFormat:@"%d",FIRST]];
		self.tenant.last = [self.dict objectForKey:[NSString stringWithFormat:@"%d",LAST]];
		self.tenant.address = [self.dict objectForKey:[NSString stringWithFormat:@"%d",ADDRESS]];
		self.tenant.city = [self.dict objectForKey:[NSString stringWithFormat:@"%d",CITY]];
		self.tenant.state = [self.dict objectForKey:[NSString stringWithFormat:@"%d",STATE]];
		self.tenant.postal_code = [self.dict objectForKey:[NSString stringWithFormat:@"%d",POSTALCODE]];
		self.tenant.home_phone = [self.dict objectForKey:[NSString stringWithFormat:@"%d",HOME_PHONE]];
		self.tenant.work_phone = [self.dict objectForKey:[NSString stringWithFormat:@"%d",WORK_PHONE]];
		self.tenant.mobile = [self.dict objectForKey:[NSString stringWithFormat:@"%d",MOBILE]];
		self.tenant.rentAmount = [self.dict objectForKey:[NSString stringWithFormat:@"%d",RENT_AMT]];
		self.tenant.deposit_amount = [self.dict objectForKey:[NSString stringWithFormat:@"%d",DEPOSIT_AMT]];
		self.tenant.dep_paid_date = [self.dict objectForKey:[NSString stringWithFormat:@"%d",DEP_PAID_DATE]];
		self.tenant.moveOut = [NSString stringWithString:isMoveOut?@"YES":@"NO"];
		self.tenant.move_in_date = [self.dict objectForKey:[NSString stringWithFormat:@"%d",MOVE_IN_DATE]];
		self.tenant.email = [self.dict objectForKey:[NSString stringWithFormat:@"%d",EMAIL]];
		self.tenant.note = [self.dict objectForKey:[NSString stringWithFormat:@"%d",NOTE]];
		self.tenant.leasePeriod = [self.dict objectForKey:[NSString stringWithFormat:@"%d",LEASE_PERIOD]];
		self.tenant.leaseStartDate = [self.dict objectForKey:[NSString stringWithFormat:@"%d",LEASE_START_DATE]];
		self.tenant.rentDueDay = [self.dict objectForKey:[NSString stringWithFormat:@"%d",RENT_DUE_DAY]];
		[appDelegate saveContext];
	}
}
// returns the number of 'columns' to display.
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
	return 1;
}

// returns the # of rows in each component..
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
	if(pickerTag == RENT_DUE_DAY_PICKER)
		return [self.rentDayArray count];
	else if(pickerTag == LEASE_PERIOD_PICKER)
		return [self.leasePeriodArray count];
	return [self.array count];
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
	if(pickerTag == RENT_DUE_DAY_PICKER)
		return [self.rentDayArray objectAtIndex:row];
	else if(pickerTag == LEASE_PERIOD_PICKER)
		return [self.leasePeriodArray objectAtIndex:row];
	return [self.array objectAtIndex:row];
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
	if(pickerTag == RENT_DUE_DAY_PICKER)
	{
		self.rentDueDay.text = [self.rentDayArray objectAtIndex:row];
		[self.dict setObject:self.rentDueDay.text forKey:[NSString stringWithFormat:@"%d",self.rentDueDay.tag]];
		return ;
	}
	else if(pickerTag == LEASE_PERIOD_PICKER)
	{
		self.rentLeasePeriod.text = [self.leasePeriodArray objectAtIndex:row];
		[self.dict setObject:self.rentLeasePeriod.text forKey:[NSString stringWithFormat:@"%d",self.rentLeasePeriod.tag]];
		return ;
	}
	Building *building = [self.buildingArray objectAtIndex:row];
	self.address.text = building.address;
	self.city.text = building.city;
	self.state.text = building.state;
	self.postalCode.text = building.postal_code;
	tempTextField.text = [self.array objectAtIndex:row];
	
	if(self.address.text)
		[self.dict setObject:self.address.text forKey:[NSString stringWithFormat:@"%d",BUILDING]];
	else
		[self.dict removeObjectForKey:[NSString stringWithFormat:@"%d",BUILDING]];
	if(self.address.text)
		[self.dict setObject:self.address.text forKey:[NSString stringWithFormat:@"%d",ADDRESS]];
	else
		[self.dict removeObjectForKey:[NSString stringWithFormat:@"%d",ADDRESS]];
	
	if(self.city.text)
		[self.dict setObject:self.city.text forKey:[NSString stringWithFormat:@"%d",CITY]];
	else
		[self.dict removeObjectForKey:[NSString stringWithFormat:@"%d",CITY]];
	
	if(self.state.text)
		[self.dict setObject:self.state.text forKey:[NSString stringWithFormat:@"%d",STATE]];
	else 
		[self.dict removeObjectForKey:[NSString stringWithFormat:@"%d",STATE]];

	
	if(self.postalCode.text)
		[self.dict setObject:self.postalCode.text forKey:[NSString stringWithFormat:@"%d",POSTALCODE]];
	else
		[self.dict removeObjectForKey:[NSString stringWithFormat:@"%d",POSTALCODE]];
	selectedIndex = row;
}

-(void)hidePickerView
{
	NSDateFormatter	*formater = nil;
	switch(pickerTag)
	{
		case DATE_PICKER:
			formater = [[NSDateFormatter alloc] init];
			[formater setDateFormat:@"MM/dd/yyyy"];
			tempTextField.text = [formater stringFromDate:self.datePicker.date];
			[self.dict setObject:tempTextField.text?tempTextField.text : @"" forKey:[NSString stringWithFormat:@"%d",tempTextField.tag]];
			[UIView beginAnimations:nil context:nil];
			[UIView setAnimationBeginsFromCurrentState:YES];
			[UIView setAnimationDuration:0.30];
			[self.scrollView setContentOffset:CGPointMake(0, 0)];
			[UIView commitAnimations];
			break;
			
		case PICKER:
			break;
	}
	[Utility hidesDropDown:pView];
}

-(void)fetchData
{
	AppDelegate_iPhone *app = (AppDelegate_iPhone *)[[UIApplication sharedApplication]delegate];
	
	self.buildingArray = [CoreDataHelper getObjectsFromContext:ENTITY_KEY_BUILDING :@"address" :YES :app.managedObjectContext];
	
	self.array = [[NSMutableArray alloc] init];
	
	for(Building *building in self.buildingArray)
	{
		if(building.address)
		{
			NSString *text = building.address;
			[self.array addObject:text];
		}
	}
	[pickerView reloadAllComponents];
}
-(void)cancelPickerView
{
    /*ßß
	tempTextField.text = @"";
	self.address.text = @"";
	self.city.text = @"";
	self.state.text = @"";
	self.postalCode.text = @"";*/
	[Utility hidesDropDown:pView];
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
	
	self.rtTableViewFirst = nil; 
	self.rtTableView  = nil; 
	self.scrollView  = nil;
	self.cause = nil;
	self.lableFirst = nil;
	self.lableBuilding = nil;
	self.btnIcon = nil;
	
	self.rightItem = nil; 
	
	self.dict  = nil; 
	
	self.array  = nil;
	self.buildingArray = nil; 
		
	self.datePicker = nil; 
	
	self.depPaidDate = nil;
	self.moveInDate = nil;
	self.address = nil;
	self.city = nil;
	self.state = nil;
	self.postalCode = nil;
	
	self.fName = nil;
	self.lName = nil;
	self.rentAmount = nil;
	
	self.note = nil;
	
	self.rentDayArray = nil; 
	self.rentDueDay = nil;
	self.leasePeriodArray = nil;
	self.rentLeasePeriod = nil;
	self.txtLeaseStartDate = nil;
	
	self.labelCause = nil;
}


- (void)dealloc {
	cause = nil;
	self.rtTableViewFirst = nil;
	self.rtTableView = nil;
	self.scrollView = nil;
	
	self.lableFirst = nil;
	self.lableBuilding = nil;
	self.btnIcon = nil;
	
	self.rightItem = nil;
	self.dict = nil;
	
	self.array = nil;
	self.buildingArray = nil;
	
	self.datePicker = nil;
	
	self.depPaidDate = nil;
	self.moveInDate = nil;
	self.address = nil;
	self.city = nil;
	self.state = nil;
	self.postalCode = nil;
	
	self.fName = nil;
	self.lName = nil;
	self.rentAmount = nil;
	
	self.note = nil;
	
	self.rentDayArray = nil;
	self.rentDueDay = nil;
	self.leasePeriodArray = nil;
	self.rentLeasePeriod = nil;
	self.txtLeaseStartDate = nil;
	labelCause_ = nil;
    [super dealloc];
}


@end
