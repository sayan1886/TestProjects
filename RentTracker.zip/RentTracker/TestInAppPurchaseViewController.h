//
//  TestInAppPurchaseViewController.h
//  TestInAppPurchase
//
//  Created by ASHIM SAMANTA on 09/02/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MBProgressHUD.h"

@interface TestInAppPurchaseViewController : UITableViewController <MBProgressHUDDelegate>
{
	MBProgressHUD *_hud;
	NSMutableData *responseData;
}

@property (nonatomic, retain) MBProgressHUD *hud;

@end

