//
//  RTTenantEditViewController.h
//  RentTracker
//
//  Created by ASHIM SAMANTA on 29/02/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ImagePicker.h"
#import "RTTenantAddViewController.h"
#import "Tenant.h"

@interface RTTenantEditViewController : UIViewController <UITableViewDelegate, UIScrollViewDelegate,
											UITableViewDataSource, UITextFieldDelegate,
											CaptureImage, UIPickerViewDataSource, UIPickerViewDelegate>
{
	UIScrollView *scrollView_;
	UITableView *rtTableView_;
	UITableView *rtTableViewFirst_;
	
	UILabel *lableFirst_;
	UILabel *lableBuilding_;

	UIBarButtonItem *rightItem_;
	NSMutableDictionary *dict;
	UIButton *btnIcon;
	BOOL isReadOnly;
	
	UIView *pView;
	UIPickerView *pickerView;
	
	NSMutableArray *array_;
	UITextField *tempTextField;
	NSInteger selectedIndex;
	
	NSMutableArray *buildingArray_;
	NSMutableDictionary *tempDict_;
	Tenant *tenant_;
	
	PICKER_TAG pickerTag;
	
	UITextField *address_;
	UITextField *city_;
	UITextField *state_;
	UITextField *postalCode_;
	
	UITextField *building_;
	UITextField *fName_;
	UITextField *lName_;
	UITextField *rentAmount_;
	
	UITextField *depPaidDate_;
	UITextField *moveInDate_;
	
	UIDatePicker *datePicker_;
	
	BOOL isPickerViewVisible;
	UITextView *note_;
	
	NSMutableArray *rentDayArray_;
	UITextField *rentDueDay_;
	
	NSMutableArray *leasePeriodArray_;
	UITextField *rentLeasePeriod_;
	
	UITextField *txtLeaseStartDate_;
	BOOL fromAlert;
	BOOL isMoveOut;
	
	UILabel *labelCause_;
	NSString *cause;
}
@property (nonatomic) BOOL fromAlert;
@property (nonatomic, retain) NSString *cause;

@property (nonatomic, retain) IBOutlet UITableView *rtTableViewFirst;
@property (nonatomic, retain) IBOutlet UITableView *rtTableView;
@property (nonatomic, retain) IBOutlet UIScrollView *scrollView;

@property (nonatomic, retain) IBOutlet UILabel *lableFirst;
@property (nonatomic, retain) IBOutlet UILabel *lableBuilding;
@property (nonatomic, retain) IBOutlet UIButton *btnIcon;

@property (nonatomic, retain) IBOutlet UILabel *labelCause;

@property (nonatomic, retain) UIBarButtonItem *rightItem;
@property (nonatomic, retain) NSMutableDictionary *dict;

@property (nonatomic, retain) NSMutableArray *array;
@property (nonatomic, retain) NSMutableArray *buildingArray;

@property (nonatomic, retain) Tenant *tenant;

@property (nonatomic, retain) UIDatePicker *datePicker;

@property (nonatomic, retain) UITextField *depPaidDate;
@property (nonatomic, retain) UITextField *moveInDate;
@property (nonatomic, retain) UITextField *address;
@property (nonatomic, retain) UITextField *city;
@property (nonatomic, retain) UITextField *state;
@property (nonatomic, retain) UITextField *postalCode;

@property (nonatomic, retain) UITextField *building;
@property (nonatomic, retain) UITextField *fName;
@property (nonatomic, retain) UITextField *lName;
@property (nonatomic, retain) UITextField *rentAmount;

@property (nonatomic, retain) UITextView *note;

@property (nonatomic, retain) NSMutableArray *rentDayArray;
@property (nonatomic, retain) UITextField *rentDueDay;
@property (nonatomic,retain)  NSMutableArray *leasePeriodArray;
@property (nonatomic, retain) UITextField *rentLeasePeriod;
@property (nonatomic, retain) UITextField *txtLeaseStartDate;

-(IBAction)addPhoto:(id)sender;
-(void)addView;
-(void)loadValues;
-(void)updateData;
-(void)fetchData;
-(void)addToolBar:(UITextView *)textView;
-(void)updateAppearence;
-(BOOL)hasNameBuildingAndRentAmount;

@end
