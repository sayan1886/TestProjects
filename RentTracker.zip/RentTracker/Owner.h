//
//  Owner.h
//  RentTracker
//
//  Created by Manas Kumar Mandal on 18/04/12.
//  Copyright (c) 2012 ObjectSol Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface Owner : NSManagedObject

@property (nonatomic, retain) NSString * state;
@property (nonatomic, retain) NSString * first;
@property (nonatomic, retain) NSString * prefix;
@property (nonatomic, retain) NSString * last;
@property (nonatomic, retain) NSString * mobile;
@property (nonatomic, retain) NSString * work_phone;
@property (nonatomic, retain) NSString * address;
@property (nonatomic, retain) NSData * image;
@property (nonatomic, retain) NSString * city;
@property (nonatomic, retain) NSString * home_phone;
@property (nonatomic, retain) NSString * postal_code;
@property (nonatomic, retain) NSString * email;

@end
