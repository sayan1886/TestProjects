//
//  RTContractorEditViewController.m
//  RentTracker
//
//  Created by ASHIM SAMANTA on 06/03/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import "RTContractorEditViewController.h"
#import "AppDelegate_iPhone.h"
#import "CustomCell.h"
#import "Constant.h"
#import "CoreDataHelper.h"
#import "Utility.h"
#import "UIImage+TKCategory.h"

@implementation RTContractorEditViewController

@synthesize rtContractorEditTableView = rtContractorEditTableView_;
@synthesize rightItem = rightItem_;
@synthesize tempDict ;
@synthesize contractor = contractor_;
@synthesize name = name_;
@synthesize btn;
@synthesize txtFld;

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.rightItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem: UIBarButtonSystemItemEdit  target:self action:@selector(edit:)];
		self.navigationItem.rightBarButtonItem = self.rightItem;
		isReadOnly = YES;
    }
    return self;
}

-(void)edit:(id)sender
{
	isReadOnly = NO;
	[self.rtContractorEditTableView reloadData];
	UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem: UIBarButtonSystemItemDone  target:self action:@selector(done:)];
	[self.navigationItem setRightBarButtonItem:item animated:YES];
	[item release];item = nil;
	
	[self.navigationItem setHidesBackButton:YES animated:YES];
	item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem: UIBarButtonSystemItemCancel  target:self action:@selector(cancel:)];
	[self.navigationItem setLeftBarButtonItem:item animated:YES];
	[item release];item = nil;
}

#pragma mark -
#pragma mark done
-(void)done:(id)sender
{
	isReadOnly = YES;
	
	[Utility increaseHeightOfTableView:self.rtContractorEditTableView];
	
	[self.rtContractorEditTableView reloadData];
	
	[self.navigationItem setRightBarButtonItem:self.rightItem  animated:YES];
	[self.navigationItem setLeftBarButtonItem:nil animated:YES];
	[self.navigationItem setHidesBackButton:NO animated:YES];
	[self updateData];
}

-(BOOL)hasContractorName
{
	if([self.name isFirstResponder])
		[self.name resignFirstResponder];
	
	NSString *fText = self.name.text;
	
	if(!fText) return NO;
	
	fText = [fText stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	
	return ([fText length] > 0);
	
}

-(void)updateData
{
	if([self.txtFld isFirstResponder])
		[self.txtFld resignFirstResponder];
	
	if(![self hasContractorName])
	{
		[Utility showAlertViewWithTitle:TITLE_MANDATORY_FIELD Message:MESSAGE_CONTRACTOR_MANDATORY_FIELD CancelTitle:CANCEL_TITLE];
		return ;
	}
	
	if([self.tempDict objectForKey:[NSString stringWithFormat:@"%d",CONTRACTOR_EMAIL]])
	{
		if(![Utility isEmailValid:[self.tempDict objectForKey:[NSString stringWithFormat:@"%d",CONTRACTOR_EMAIL]]])
		{
			[Utility showAlertViewWithTitle:TITLE Message:MESSAGE_INVALID_EMAIL_ID CancelTitle:CANCEL_TITLE];
			return ;
		}
	}
	AppDelegate_iPhone *appDelegate =  (AppDelegate_iPhone *)[[UIApplication sharedApplication] delegate];
	
	if(self.contractor && self.tempDict)
	{
		if ([self.tempDict objectForKey:KEY_IMAGE]) 
		{
			UIImage *img = [self.tempDict objectForKey:KEY_IMAGE];
			NSData *data = UIImagePNGRepresentation(img);
			self.contractor.image = data;
		}
		if([self.tempDict objectForKey:[NSString stringWithFormat:@"%d",CONTRACTOR_NAME]])
		{
			self.contractor.name = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",CONTRACTOR_NAME]];
		}
		if([self.tempDict objectForKey:[NSString stringWithFormat:@"%d",CONTRACTOR_WEBSITE]])
		{
			self.contractor.webSite = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",CONTRACTOR_WEBSITE]];
		}
		if([self.tempDict objectForKey:[NSString stringWithFormat:@"%d",CONTRACTOR_ADDRESS]])
		{
			self.contractor.address = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",CONTRACTOR_ADDRESS]];
		}
		if([self.tempDict objectForKey:[NSString stringWithFormat:@"%d",CONTRACTOR_CITY]])
		{
			self.contractor.city = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",CONTRACTOR_CITY]];
		}
		if([self.tempDict objectForKey:[NSString stringWithFormat:@"%d",CONTRACTOR_STATE]])
		{
			self.contractor.state = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",CONTRACTOR_STATE]];
		}
		if([self.tempDict objectForKey:[NSString stringWithFormat:@"%d",CONTRACTOR_POSTAL_CODE]])
		{
			self.contractor.postalCode = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",CONTRACTOR_POSTAL_CODE]];
		}
		if([self.tempDict objectForKey:[NSString stringWithFormat:@"%d",CONTRACTOR_WORK_PHONE]])
		{
			self.contractor.workPhone = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",CONTRACTOR_WORK_PHONE]];
		}
		if([self.tempDict objectForKey:[NSString stringWithFormat:@"%d",CONTRACTOR_CELL_PHONE]])
		{
			self.contractor.cellPhone = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",CONTRACTOR_CELL_PHONE]];
		}
		if([self.tempDict objectForKey:[NSString stringWithFormat:@"%d",CONTRACTOR_FAX]])
		{
			self.contractor.fax = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",CONTRACTOR_FAX]];
		}
		if([self.tempDict objectForKey:[NSString stringWithFormat:@"%d",CONTRACTOR_EMAIL]])
		{
			self.contractor.email = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",CONTRACTOR_EMAIL]];
		}
		if([self.tempDict objectForKey:[NSString stringWithFormat:@"%d",CONTRACTOR_NOTES]])
		{
			self.contractor.notes = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",CONTRACTOR_NOTES]];
		}
		
		[appDelegate saveContext];
	}
	
}

#pragma mark -
#pragma mark cancel
-(void)cancel:(id)sender
{
	[Utility increaseHeightOfTableView:self.rtContractorEditTableView];
	isReadOnly = YES;
	if([tempTextField isFirstResponder])
		[tempTextField resignFirstResponder];
	if([tempTextView isFirstResponder])
		[tempTextView resignFirstResponder];
	[self loadValues];
	[self.navigationItem setRightBarButtonItem:self.rightItem animated:YES];
	[self.navigationItem setLeftBarButtonItem:nil animated:YES];
	[self.navigationItem setHidesBackButton:NO animated:YES];
	[self.rtContractorEditTableView reloadData];
	//mnodify to change.
}

#pragma mark -
#pragma mark tableViewDelegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return CONTRACTOR_NO_OF_SECTION;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	switch (section) 
	{
		case 0:
			return 1;
		case 1:
			return 5;
		case 2:
			return 4;
		case 3:
			return 1;
			
	}
	return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	if(indexPath.section == 3) return HEIGHT_FOR_NOTE_ROW;
	return HEIGHT_FOR_ROW;
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	//static NSString *cellIdentifier = @"CellID";
	CustomCell *cell = [[[CustomCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil ReadOnly:isReadOnly] autorelease];
	cell.textField.delegate = self;
	
	switch(indexPath.section)
	{
		case 0:
			[cell.label removeFromSuperview];
			self.btn = [UIButton buttonWithType:UIButtonTypeCustom];
			self.btn.frame = CGRectMake(5, 5, 34, 34);
			self.btn.enabled = !isReadOnly;
			if([self.tempDict valueForKey:KEY_IMAGE])
				[self.btn setImage:[self.tempDict valueForKey:KEY_IMAGE] forState:UIControlStateNormal];
			else
				[self.btn setImage:[UIImage imageNamed:HOUSE_ICON] forState:UIControlStateNormal];
			[self.btn addTarget:self action:@selector(takePicture:) forControlEvents:UIControlEventTouchUpInside];
			[cell.contentView addSubview:self.btn];
			cell.textField.placeholder = @"Name";
			cell.textField.tag = CONTRACTOR_NAME;
			cell.textField.text = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",cell.textField.tag]];
			self.name = cell.textField;
			return cell;
		case 1:
			
			switch(indexPath.row)
		{
			case 0:
				cell.label.text = @"Website :";
				cell.textField.placeholder = @"Website";
				cell.textField.tag = CONTRACTOR_WEBSITE;
				cell.textField.keyboardType = UIKeyboardTypeURL;
				cell.textField.text = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",cell.textField.tag]];
				return cell;
			case 1:
				cell.label.text = @"Address :";
				cell.textField.placeholder = @"Address";
				cell.textField.tag = CONTRACTOR_ADDRESS;
				cell.textField.text = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",cell.textField.tag]];
				return cell;
			case 2:
				cell.label.text = @"City :";
				cell.textField.placeholder = @"City";
				cell.textField.tag = CONTRACTOR_CITY;
				cell.textField.text = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",cell.textField.tag]];
				return cell;
			case 3:
				cell.label.text = @"State :";
				cell.textField.placeholder = @"State";
				cell.textField.tag = CONTRACTOR_STATE;
				cell.textField.autocapitalizationType = UITextAutocapitalizationTypeAllCharacters;
				cell.textField.text = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",cell.textField.tag]];
				return cell;
			case 4:
				cell.label.text = @"Postal Code :";
				cell.textField.placeholder = @"Postal Code";
				cell.textField.tag = CONTRACTOR_POSTAL_CODE;
				cell.textField.text = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",cell.textField.tag]];
				return cell;
		}
			
		case 2:
			
			switch(indexPath.row)
		{
			case 0:
				cell.label.text = @"Work Phone :";
				cell.textField.placeholder = @"Work Phone";
				cell.textField.tag = CONTRACTOR_WORK_PHONE;
				cell.textField.text = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",cell.textField.tag]];
				return cell;
			case 1:
				cell.label.text = @"Cell Phone :";
				cell.textField.placeholder = @"Cell Phone";
				cell.textField.tag = CONTRACTOR_CELL_PHONE;
				cell.textField.text = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",cell.textField.tag]];
				return cell;
			case 2:
				cell.label.text = @"Fax :";
				cell.textField.placeholder = @"Fax";
				cell.textField.tag = CONTRACTOR_FAX;
				cell.textField.text = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",cell.textField.tag]];
				return cell;
			case 3:
				cell.label.text = @"Email :";
				cell.textField.placeholder = @"Email";
				cell.textField.tag = CONTRACTOR_EMAIL;
				cell.textField.keyboardType = UIKeyboardTypeEmailAddress;
				cell.textField.autocapitalizationType = UITextAutocapitalizationTypeNone;
				cell.textField.autocorrectionType = UITextAutocorrectionTypeNo;
				cell.textField.text = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",cell.textField.tag]];
				return cell;
		}
		case 3:
			[[cell.contentView subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
			cell.textLabel.text = @"NOTE :";
			CGRect frame;
			if(ISIPHONE)
				frame = CGRectMake(100, 5, 200, 122.0);
			else
				frame = CGRectMake(100, 5, 560, 122.0);
			tempTextView = [[UITextView alloc] initWithFrame:frame];
			tempTextView.userInteractionEnabled = !isReadOnly;
			tempTextView.backgroundColor = [UIColor clearColor];
			[cell.contentView addSubview:tempTextView];
			tempTextView.delegate = self;
			tempTextView.tag = CONTRACTOR_NOTES;
			tempTextView.text = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",tempTextView.tag]];

			return cell;
	}
	return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	if(isReadOnly)
	{
		CustomCell *cell = (CustomCell *)[tableView cellForRowAtIndexPath:indexPath];
		NSString *str = nil;
		switch(cell.textField.tag)
		{
			case CONTRACTOR_ADDRESS:
			case CONTRACTOR_CITY:
			case CONTRACTOR_STATE:
				str = @"";
				str = [self.tempDict valueForKey:[NSString stringWithFormat:@"%d",CONTRACTOR_ADDRESS]];
				str = [str stringByAppendingFormat:@" %@",[self.tempDict valueForKey:[NSString stringWithFormat:@"%d",CONTRACTOR_CITY]]];
				str = [str stringByAppendingFormat:@" %@",[self.tempDict valueForKey:[NSString stringWithFormat:@"%d",CONTRACTOR_STATE]]];
				str = [str stringByReplacingOccurrencesOfString:@" " withString:@"+"];
				[Utility launchMapWithAddress:str];
				return ;
			case CONTRACTOR_WORK_PHONE:
			case CONTRACTOR_CELL_PHONE:
				str = cell.textField.text;
				str = [str stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
				[Utility makePhoneCallWithPhoneNumber:str];
				return ;
			case EMAIL:
				str = cell.textField.text;
				str = [str stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
				NSLog(@"%d",[Utility launchMailWithTo:str]);
				return ;
		}
		return ;
	}
	if(indexPath.section == 0)
	{
		self.btn = [[tableView cellForRowAtIndexPath:indexPath].contentView.subviews objectAtIndex:1];
 		[self takePicture:self.btn];
		return;
	}
}

#pragma mark -
#pragma mark textView Delegate Method

- (BOOL)textViewShouldBeginEditing:(UITextView *)textView
{
	if(textView.tag == CONTRACTOR_NOTES)
	{
		[self addToolBar:textView];
		[Utility decreaseHeightOfTableView:self.rtContractorEditTableView];
		return YES;
	}
	return YES;
}

- (void)textViewDidEndEditing:(UITextView *)textView
{
	[self.tempDict setObject:textView.text forKey:[NSString stringWithFormat:@"%d",textView.tag]];
}

#pragma mark -
#pragma mark TextField Delegate Method

// return NO to disallow editing.
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
	[Utility decreaseHeightOfTableView:self.rtContractorEditTableView];
	self.txtFld = textField;
	
	return YES;
}

// became first responder
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
	
}

// return YES to allow editing to stop and to resign first responder status. NO to disallow the editing session to end
- (BOOL)textFieldShouldEndEditing:(UITextField *)textField         
{
	
	return YES;
}

// may be called if forced even if shouldEndEditing returns NO (e.g. view removed from window) or endEditing:YES called
- (void)textFieldDidEndEditing:(UITextField *)textField             
{
	[self.tempDict setObject:textField.text forKey:[NSString stringWithFormat:@"%d",textField.tag]];
}

// called when clear button pressed. return NO to ignore (no notifications)
- (BOOL)textFieldShouldClear:(UITextField *)textField
{
	return YES;
}

// called when 'return' key pressed. return NO to ignore.
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
	[Utility increaseHeightOfTableView:self.rtContractorEditTableView];
	
	if(textField.tag == CONTRACTOR_EMAIL)
	{
		if(![Utility isEmailValid:textField.text])
		{
			[Utility showAlertViewWithTitle:TITLE Message:MESSAGE_INVALID_EMAIL_ID CancelTitle:CANCEL_TITLE];
			return NO;
		}
	}
	[textField resignFirstResponder];
	
	
	
	return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
	if((textField.tag == CONTRACTOR_FAX) || (textField.tag == CONTRACTOR_CELL_PHONE) 
	   || (textField.tag == CONTRACTOR_WORK_PHONE) || (textField.tag == CONTRACTOR_CELL_PHONE))
	{
		[Utility formatPhoneNumber:textField withRange:range replacementString:string];
		NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:VALID_INTEGER] invertedSet];
		NSString *filtered = [[string componentsSeparatedByCharactersInSet:cs] componentsJoinedByString:@""];
		return [string isEqualToString:filtered];
	}
	if((textField.tag == CONTRACTOR_POSTAL_CODE))
	{
		NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:VALID_INTEGER] invertedSet];
		NSString *filtered = [[string componentsSeparatedByCharactersInSet:cs] componentsJoinedByString:@""];
		return [string isEqualToString:filtered];
	}
	return YES;
}


-(void)takePicture:(id)sender
{
	self.btn = (UIButton *)sender;
	ImagePicker *picker = [[ImagePicker alloc] init];
	picker.delegate = self;
	picker.vc = self;
	[picker clickAddPictureAtViewController:[self.btn superview]];
}

-(void) didReceivePicture:(UIImage *)img
{
	img = [img fixOrientation];
	[self.tempDict setObject:img forKey:KEY_IMAGE];
	[self.btn setImage:img forState:UIControlStateNormal];
}

-(void)addToolBar:(UITextView *)textView
{
	UIToolbar *toolBar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, 100, 35)];
	NSMutableArray *arr = [[NSMutableArray alloc] init];
	UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(ok)];
	[arr addObject:item];
	[item release];item = nil;
	
	item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
	[arr addObject:item];
	[item release];item = nil;
	
	item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(res:)];
	[arr addObject:item];
	[item release];item = nil;
	
	toolBar.items = arr;
	
	[arr release];arr = nil;
	
	textView.inputAccessoryView = toolBar;
}
-(void)res:(id)sender
{
	[Utility increaseHeightOfTableView:self.rtContractorEditTableView];
	[tempTextView resignFirstResponder];
	
}
-(void)ok
{
	[Utility increaseHeightOfTableView:self.rtContractorEditTableView];
	[tempTextView resignFirstResponder];
}



// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	self.tempDict = [[NSMutableDictionary alloc] init];
	[self fetchManagedObject];
	[self loadValues];
}

-(void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	
	[Utility increaseHeightOfTableView:self.rtContractorEditTableView];
}

-(void)fetchManagedObject
{
	AppDelegate_iPhone *app = (AppDelegate_iPhone *)[[UIApplication sharedApplication] delegate];
	NSPredicate *predicate = [NSPredicate predicateWithFormat:@"self == %@",self.contractor];
	NSMutableArray *arr = [CoreDataHelper searchObjectsInContext:ENTITY_KEY_CONTRACTOR :predicate :nil :NO :app.managedObjectContext];
	self.contractor = [arr objectAtIndex:0];
}

-(void)loadValues
{	
	if(self.contractor.name)
		[self.tempDict setValue:self.contractor.name forKey:[NSString stringWithFormat:@"%d",CONTRACTOR_NAME]];

	if(self.contractor.webSite )
		[self.tempDict setValue:self.contractor.webSite forKey:[NSString stringWithFormat:@"%d",CONTRACTOR_WEBSITE]];
	
	if(self.contractor.address )
		[self.tempDict setValue:self.contractor.address forKey:[NSString stringWithFormat:@"%d",CONTRACTOR_ADDRESS]];
	
	if(self.contractor.city )
		[self.tempDict setValue:self.contractor.city forKey:[NSString stringWithFormat:@"%d",CONTRACTOR_CITY]];
	
	if(self.contractor.state )
		[self.tempDict setValue:self.contractor.state forKey:[NSString stringWithFormat:@"%d",CONTRACTOR_STATE]];
	
	if(self.contractor.postalCode )
		[self.tempDict setValue:self.contractor.postalCode forKey:[NSString stringWithFormat:@"%d",CONTRACTOR_POSTAL_CODE]];
	
	if(self.contractor.workPhone )
		[self.tempDict setValue:self.contractor.workPhone forKey:[NSString stringWithFormat:@"%d",CONTRACTOR_WORK_PHONE]];
	
	if(self.contractor.cellPhone )
		[self.tempDict setValue:self.contractor.cellPhone forKey:[NSString stringWithFormat:@"%d",CONTRACTOR_CELL_PHONE]];
	
	if(self.contractor.fax )
		[self.tempDict setValue:self.contractor.fax forKey:[NSString stringWithFormat:@"%d",CONTRACTOR_FAX]];
	
	if(self.contractor.email )
		[self.tempDict setValue:self.contractor.email forKey:[NSString stringWithFormat:@"%d",CONTRACTOR_EMAIL]];
	
	if(self.contractor.notes )
		[self.tempDict setValue:self.contractor.notes forKey:[NSString stringWithFormat:@"%d",CONTRACTOR_NOTES]];
	
	if(self.contractor.image )
	{
		UIImage *img = [UIImage imageWithData:self.contractor.image];
		img = [img fixOrientation];
		[self.tempDict setObject:img forKey:KEY_IMAGE];	
	}
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
	
	self.rtContractorEditTableView = nil;
	self.rightItem = nil;
	self.tempDict = nil;
	self.name = nil;
	
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	
	self.rtContractorEditTableView = nil;
	self.rightItem = nil;
	self.tempDict = nil;
	self.name = nil;
	
    [super dealloc];
}


@end
