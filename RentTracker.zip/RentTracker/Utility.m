//
//  Utility.m
//  RentTracker
//
//  Created by ASHIM SAMANTA on 28/02/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import "Utility.h"
#import "CoreDataHelper.h"
#import "Reachability.h"

@implementation Utility

+(NSMutableDictionary *)arrangeList:(NSMutableArray *)list sortKey:(NSString *)sKey
{
	NSMutableArray *inputArray = [[[NSMutableArray alloc]init] autorelease];
	
	NSMutableDictionary *data=[[[NSMutableDictionary alloc]init] autorelease];
	int count = [list count];
	if(count > 0)
	{
		for(int i = 0; i< count; i++)
		{
			NSString *key =[[list objectAtIndex:i] valueForKey:sKey]; 
			
			if(key == nil || [key length] == 0 ) continue;
			
			[inputArray addObject:key];
			
			NSString *firstLetter = (key == nil || [key length] == 0 )? @"" : [[key substringToIndex:1] uppercaseString];
			
			//for 0-9
			char c = [firstLetter characterAtIndex:0];
			int intFirstAscii = c;
			if((intFirstAscii < 65) || (intFirstAscii > 91))
			{
				firstLetter = @"0-9";
			}
			
			NSMutableArray *indexArray = [data objectForKey:firstLetter];
			if (indexArray == nil) 
			{
				indexArray = [[[NSMutableArray alloc] init] autorelease]; 
			}
			[indexArray addObject:[list objectAtIndex:i]];
			[data setObject:indexArray forKey:firstLetter]; 
		}
	}
	
	return data;
}
+(BOOL)isEmailValid:(NSString *)emailID
{
	NSPredicate *regExPredicate =[NSPredicate predicateWithFormat:@"SELF MATCHES %@", VALID_MAIL_REGEX];
	return [regExPredicate evaluateWithObject:emailID];
}

+(void)showDropDown:(UIView *)pickerView
{
	CGRect frame = pickerView.frame;
	frame.origin.y = 0;
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationBeginsFromCurrentState:YES];
	[UIView setAnimationDuration:0.40];
	pickerView.frame = frame;
	[UIView commitAnimations];
	
}

+(void)hidesDropDown:(UIView *)pickerView
{
	CGRect frame = pickerView.frame;
	if(ISIPHONE)
		frame.origin.y = 460;
	else
		frame.origin.y = 1024;
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationBeginsFromCurrentState:YES];
	[UIView setAnimationDuration:0.40];
	pickerView.frame = frame;
	[UIView commitAnimations];
}

#pragma mark -
#pragma mark Phone Call
+(BOOL)makePhoneCallWithPhoneNumber:(NSString *)phoneNumber
{
    if(!phoneNumber) return NO;
    phoneNumber = [phoneNumber stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    phoneNumber = [phoneNumber stringByReplacingOccurrencesOfString:@"(" withString:@""];
    phoneNumber = [phoneNumber stringByReplacingOccurrencesOfString:@")" withString:@""];
    phoneNumber = [phoneNumber stringByReplacingOccurrencesOfString:@"-" withString:@""];
    phoneNumber = [phoneNumber stringByReplacingOccurrencesOfString:@" " withString:@""];
    if([phoneNumber length] == 0) return NO;
    BOOL retVal =  [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"tel://%@", phoneNumber]]];
    NSLog(@"Phone Call available : %@", retVal ? @"YES":@"NO");
    return retVal;
}

#pragma mark -
#pragma mark Email 

+(BOOL)launchMailWithTo:(NSString *)mailTo
{
	NSString *emailBody = @"";
	NSString *recipients = [NSString stringWithFormat:@"mailto:?to=%@&subject=%@",mailTo,@""];
	NSString *body = [NSString stringWithFormat:@"&body=%@",emailBody];
	
	NSString *email = [NSString stringWithFormat:@"%@%@", recipients, body];
	email = [email stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
	
	return [[UIApplication sharedApplication] openURL:[NSURL URLWithString:email]];
}

#pragma mark -
#pragma mark Google Map

+(BOOL)launchMapWithAddress:(NSString *)address
{
    if(!address) return NO;
    address = [address stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if([address length] == 0) return NO;
	NSString *addr = [NSString stringWithFormat:@"http://maps.google.com/maps?q=%@",address];
	return [[UIApplication sharedApplication] openURL:[NSURL URLWithString:addr]];
}

#pragma mark -
#pragma mark TENANT CELL

+(CustomCell *)cellForRowAtPathForTenantFirstTableView:( NSIndexPath *)path isReadOnly:(BOOL)readOnly
{
	CustomCell *cell = [[[CustomCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil ReadOnly:readOnly] autorelease];
	[cell.label removeFromSuperview];
	switch(path.row)
	{
		case 0:
			cell.textField.placeholder = @"First";
			cell.textField.tag = FIRST;
			return cell;
			
		case 1:
			cell.textField.placeholder = @"Last";
			cell.textField.tag = LAST;
			return cell;
		case 2:
			cell.textField.placeholder = @"Building";
			cell.textField.tag = BUILDING;
			return cell;
	}
	return cell;
}
+(CustomCell *)cellForRowAtPathForTenantSecondTableView:( NSIndexPath *)path isReadOnly:(BOOL) readOnly
{
	CustomCell *cell = [[[CustomCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil ReadOnly:readOnly] autorelease];
	switch(path.section)
	{
		case 0:
		switch(path.row)
		{
			case 0:
				cell.label.text = @"Address :";
				cell.textField.placeholder = @"Address";
				cell.textField.tag = ADDRESS;
				return cell;
			case 1:
				cell.label.text = @"City :";
				cell.textField.placeholder = @"City";
				cell.textField.tag = CITY;
				cell.textField.userInteractionEnabled = NO;
				return cell;
			case 2:
				cell.label.text = @"State :";
				cell.textField.placeholder = @"State";
				cell.textField.tag = STATE;
				cell.textField.autocapitalizationType = UITextAutocapitalizationTypeAllCharacters;
				cell.textField.userInteractionEnabled = NO;
				return cell;
			case 3:
				cell.label.text = @"Postal Code :";
				cell.textField.placeholder = @"Postal Code";
				cell.textField.userInteractionEnabled = NO;	
				cell.textField.tag = POSTALCODE;
				return cell;
		}
		case 1:
		switch(path.row)
		{
			case 0:
				cell.label.text = @"Home Phone :";
				cell.textField.placeholder = @"Home Phone";
				cell.textField.tag = HOME_PHONE;
				cell.textField.keyboardType = UIKeyboardTypePhonePad;
				return cell;
			case 1:
				cell.label.text = @"Work Phone :";
				cell.textField.placeholder = @"Work Phone";
				cell.textField.tag = WORK_PHONE;
				cell.textField.keyboardType = UIKeyboardTypePhonePad;
				return cell;
			case 2:
				cell.label.text = @"Mobile :";
				cell.textField.placeholder = @"Mobile";
				cell.textField.tag = MOBILE;
				cell.textField.keyboardType = UIKeyboardTypePhonePad;
				return cell;
			case 3:
				cell.label.text = @"Email :";
				cell.textField.placeholder = @"Email";
				cell.textField.tag = EMAIL;
				cell.textField.keyboardType = UIKeyboardTypeEmailAddress;
				cell.textField.autocapitalizationType = UITextAutocapitalizationTypeNone;
				cell.textField.autocorrectionType = UITextAutocorrectionTypeNo;
				return cell;
		}
		case 2:
		switch(path.row)
		{
			case 0:
				cell.label.text = @"Rent Amount :";
				cell.textField.placeholder = @"Rent Amount";
				cell.textField.tag = RENT_AMT;
                if(ISIPHONE)
                    cell.textField.keyboardType = UIKeyboardTypeDecimalPad;
                else
                    cell.textField.keyboardType = UIKeyboardTypeNumberPad;
				return cell;
				
			case 1:
				cell.label.text = @"Deposit Amt :";
				cell.textField.placeholder = @"Deposit Amt";
				cell.textField.tag = DEPOSIT_AMT;
				if(ISIPHONE)
                    cell.textField.keyboardType = UIKeyboardTypeDecimalPad;
                else
                    cell.textField.keyboardType = UIKeyboardTypeNumberPad;
				return cell;
			
			case 2:
				cell.label.text = @"Dep Paiddate :";
				cell.textField.placeholder = @"Dep Paiddate";
				cell.textField.tag = DEP_PAID_DATE;
				return cell;
				
			case 3:
				cell.label.text = @"Move In Date :";
				cell.textField.placeholder = @"Move In Date";
				cell.textField.tag = MOVE_IN_DATE;
				return cell;
		}
		case 3:
			switch(path.row)
		{
			case 0:
				cell.label.text = @"Lease start date :";
				cell.textField.placeholder = @"dd/mm/yyyy";
				cell.textField.tag = LEASE_START_DATE;
				return cell;
			case 1:
				cell.label.text = @"Lease period :";
				cell.textField.placeholder = @"Select lease period";
				cell.textField.tag = LEASE_PERIOD;
				return cell;
			case 2:
				cell.label.text = @"Rent Due day :";
				cell.textField.placeholder = @"Rent Due day";
				cell.textField.tag = RENT_DUE_DAY;
				return cell;
		}
		case 4:
			
			cell.textField.tag = MOVE_OUT;
			return cell;
		case 5:
			cell.textField.tag = NOTE;
			return cell;
	}
	return cell;
}

+(void)showAlertViewWithTitle:(NSString *)title Message:(NSString *)msg CancelTitle:(NSString *)cancelTitle
{
	UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:title message:msg delegate:nil cancelButtonTitle:cancelTitle otherButtonTitles:nil] autorelease];
	[alert show];
}

+ (NSString *)applicationDocumentsDirectory 
{/*
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *basePath = ([paths count] > 0) ? [paths objectAtIndex:0] : nil;*/
    NSString *basePath = NSTemporaryDirectory();
    NSLog(@"NSTemporaryDirectory = %@",basePath);
	return basePath;
}

+(void)increaseHeightOfTableView:(UITableView *)tableView
{
	CGRect frame = tableView.frame;
	if(ISIPHONE)
		frame.size.height = 416;
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationBeginsFromCurrentState:YES];
	[UIView setAnimationDuration:0.30];
	
	tableView.frame = frame;
	
	[UIView commitAnimations];
}

+(void)decreaseHeightOfTableView:(UITableView *)tableView
{
	CGRect frame = tableView.frame;
	if(ISIPHONE)
		frame.size.height = 200;
	
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationBeginsFromCurrentState:YES];
	[UIView setAnimationDuration:0.30];
	tableView.frame = frame;
	[UIView commitAnimations];
}

+(void)formatPhoneNumber:(UITextField *)textField withRange:(NSRange)range replacementString:(NSString *)string
{
	NSUInteger currentLength = textField.text.length;
	NSCharacterSet *numbers = [NSCharacterSet decimalDigitCharacterSet];
	if (range.length == 1) {
        if(currentLength == 10)
        {
            NSString *str = textField.text;
            str = [str stringByReplacingOccurrencesOfString:@"(" withString:@""];
            str = [str stringByReplacingOccurrencesOfString:@")" withString:@""];
            [textField setText:str];
        }
        else if(currentLength == 4)
        {
            NSString *str = textField.text;
            str = [str stringByReplacingOccurrencesOfString:@"-" withString:@""];
            [textField setText:str];
        }
		return ;
	}
	
	if ([numbers characterIsMember:[string characterAtIndex:0]]) {
		
		if (currentLength == 3) 
		{
			
			if (range.length != 1) 
			{
				
				NSString *firstThreeDigits = [textField.text substringWithRange:NSMakeRange(0, 3)];
				
				NSString *updatedText;
				
				if ([string isEqualToString:@"-"]) 
				{
					updatedText = [NSString stringWithFormat:@"%@",firstThreeDigits];
				}
				
				else 
				{
					updatedText = [NSString stringWithFormat:@"%@-",firstThreeDigits];
				}
				
				[textField setText:updatedText];
			}           
		}
		
		else if ( currentLength > 3 && currentLength < 8 ) 
		{
			
			if ( range.length != 1 ) 
			{
				
				NSString *firstThree = [textField.text substringWithRange:NSMakeRange(0, 3)];
				NSString *dash = [textField.text substringWithRange:NSMakeRange(3, 1)];
				
				NSUInteger newLenght = range.location - 4;
				
				NSString *nextDigits = [textField.text substringWithRange:NSMakeRange(4, newLenght)];
				
				NSString *updatedText = [NSString stringWithFormat:@"%@%@%@",firstThree,dash,nextDigits];
				
				[textField setText:updatedText];
				
			}
			
		}
		
		else if ( currentLength == 8 ) 
		{
			
			if ( range.length != 1 ) 
			{
				NSString *areaCode = [textField.text substringWithRange:NSMakeRange(0, 3)];
				
				NSString *firstThree = [textField.text substringWithRange:NSMakeRange(4, 3)];
				
				NSString *nextDigit = [textField.text substringWithRange:NSMakeRange(7, 1)];
				
				[textField setText:[NSString stringWithFormat:@"(%@) %@-%@",areaCode,firstThree,nextDigit]];
			}
			
		}
	}
}

+(void)formatSSNNumber:(UITextField *)textField withRange:(NSRange)range replacementString:(NSString *)string
{
	NSUInteger currentLength = textField.text.length;
	NSCharacterSet *numbers = [NSCharacterSet decimalDigitCharacterSet];
	if (range.length == 1) {
        if(currentLength == 8)
        {
            NSString *str = textField.text;
            str = [str stringByReplacingCharactersInRange:NSMakeRange(6, 1) withString:@""];
            //str = [str stringByReplacingOccurrencesOfString:@"-" withString:@""];
            //str = [str stringByReplacingOccurrencesOfString:@")" withString:@""];
            [textField setText:str];
        }
        else if(currentLength == 5)
        {
            NSString *str = textField.text;
            str = [str stringByReplacingOccurrencesOfString:@"-" withString:@""];
            [textField setText:str];
        }
		return ;
	}
	
	if ([numbers characterIsMember:[string characterAtIndex:0]]) 
    {
		
		if (currentLength == 3) 
		{
			
			if (range.length != 1) 
			{
				
				NSString *firstThreeDigits = [textField.text substringWithRange:NSMakeRange(0, 3)];
				
				NSString *updatedText;
				
				if ([string isEqualToString:@"-"]) 
				{
					updatedText = [NSString stringWithFormat:@"%@",firstThreeDigits];
				}
				
				else 
				{
					updatedText = [NSString stringWithFormat:@"%@-",firstThreeDigits];
				}
				
				[textField setText:updatedText];
			}           
		}
		
		else if ( currentLength == 7 ) 
		{
			if ( range.length != 1 ) 
			{
				
				NSString *firstThree = [textField.text substringWithRange:NSMakeRange(0, 3)];
				NSString *dash = [textField.text substringWithRange:NSMakeRange(3, 1)];
								
				NSString *nextDigits = [textField.text substringWithRange:NSMakeRange(4, 2)];
				
                NSString *lastString = [textField.text substringWithRange:NSMakeRange(6, 1)];
				NSString *updatedText = [NSString stringWithFormat:@"%@%@%@-%@",firstThree,dash,nextDigits,lastString];
				
				[textField setText:updatedText];
			}
		}
	}
}


+(EXPENSES_CATEGOTY)expenseCategoryTag:(NSString *)category
{
	if([category isEqualToString:@"Advertising"])
		return Advertising;
	else if([category isEqualToString:@"Travel"])
		return Travel;
	else if([category isEqualToString:@"Cleaning/Maint"])
		return Cleaning;
	else if([category isEqualToString:@"Commissions"])
		return Commissions;
	else if([category isEqualToString:@"Insurance"])
		return Insurance;
	else if([category isEqualToString:@"Professional Fees"])
		return Professional_Fees;
	else if([category isEqualToString:@"Management Fees"])
		return Management_Fees;
	else if([category isEqualToString:@"Repairs"])
		return Repairs;
	else if([category isEqualToString:@"Supplies"])
		return Supplies;
	else if([category isEqualToString:@"Real Estate Taxes"])
		return Real_Estate_Taxes;
	else if([category isEqualToString:@"Other Taxes"])
		return Other_Taxes;
	else if([category isEqualToString:@"Utilities"])
		return Utilities;
    else if([category isEqualToString:@"Depreciable Expense"])
        return Depreciable_Expense;
	else
		return UNKNOWN;
}

+(NSArray *)sortExpenseByDate:(NSArray *)arrayToSort
{
	NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
	[formatter setDateFormat:@"MM/dd/yyyy"];
	
	NSArray *sortedArray = [arrayToSort sortedArrayUsingComparator:^(id a, id b) {
		Expenses *fObj = (Expenses *)a;
		Expenses *lObj = (Expenses *)b;
		NSDate *first = [formatter dateFromString:fObj.date];
		NSDate *second = [formatter dateFromString:lObj.date];
		fObj = nil; lObj = nil;
		return [first compare:second];
	}];
	formatter = nil;
	return sortedArray;
}

+(BOOL)isLeasePeriodExpiredForTenant:(Tenant *)tenant
{
	NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
	[formatter setDateFormat:@"MM/dd/yyyy"];
	
	NSInteger leasePeriod = [[tenant.leasePeriod substringToIndex:2] intValue];
	
	NSDate *date = [formatter dateFromString:tenant.leaseStartDate];
	NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
	NSDateComponents *dateComponents = [[NSDateComponents alloc] init];
	[dateComponents setYear:leasePeriod];
	//[dateComponents setDay:1];
	
	
	date = [gregorian dateByAddingComponents:dateComponents toDate:date  options:0];
	[dateComponents release]; dateComponents = nil; formatter = nil;
	[gregorian release]; gregorian = nil;
	
	NSDate *today = [NSDate date];
	
	NSComparisonResult result = [date compare:today];
	
	if(result == NSOrderedAscending) return YES;
	return NO;
}

+(BOOL)isDueForTenant:(Tenant *)ten
{
    NSDateComponents *components = [[NSCalendar currentCalendar] components:NSDayCalendarUnit | NSMonthCalendarUnit | NSYearCalendarUnit fromDate:[NSDate date]];	
    //Current date	
	NSInteger currMonth = [components month];
	NSInteger currYear = [components year];
	NSInteger currDay = [components day];
    
    //last payment made
	NSInteger lastPaymentMadeForMonth = [ten.paymentForIndex intValue];
	CGFloat lastDayOfPayment = [ten.rentDueDay intValue];
    
    //lease start.
	NSInteger leaseStartMonth  = 0;
	NSInteger leaseStartDay = 0;
	NSInteger leaseStartYear = 0;
	
	if(ten.leaseStartDate)
	{
		NSArray *comp = [ten.leaseStartDate componentsSeparatedByString:@"/"];
		if([comp count] > 2)
		{
			leaseStartMonth = [[comp objectAtIndex:0] intValue];
			leaseStartDay = [[comp objectAtIndex:1] intValue];
			leaseStartYear = [[comp objectAtIndex:2] intValue];
		}
		comp = nil;
	}
    
    //modified
    
    if([ten.lastPaymentYear intValue] < currYear) return YES;
    
    NSArray *allPayments = [ten.payments allObjects];
    
    NSMutableArray *currArr = [[NSMutableArray alloc] init];
    
    for(Payment *payment in allPayments)
    {
        MONTHS month = [Utility paymentMadeForMonth:payment.paymentFor];
        if(currDay > lastDayOfPayment)
        {
            if(currMonth == 12) currMonth = 0;
            if((month == currMonth+1) && ([payment.year intValue] == currYear))
                [currArr addObject:payment];
        }
        else
        {
            if((month == currMonth) && ([payment.year intValue] == currYear))
                [currArr addObject:payment];
        }
    }
    float partialPayment = 0.0;
    for(Payment *pay in currArr)
    {
        partialPayment += [pay.amount floatValue];
    }
    
    if(partialPayment < [ten.rentAmount floatValue])
        return YES;
    
    return NO;
    /*
    if(lastPaymentMadeForMonth == -1)
        return YES;
    else if([ten.rentDue floatValue] > 0.0)
        return YES;
    else if(currYear > [ten.lastPaymentYear intValue])
        return YES;
    else if([ten.lastPaymentYear intValue] > currYear) return NO;
    else if(currMonth - 2 == lastPaymentMadeForMonth)
    {
        if(currDay > lastDayOfPayment)
            return YES;
        else
            return NO;
    }
    else if(currMonth - 1 > lastPaymentMadeForMonth)
        return YES;

    return NO;*/
}

#define MTYPE(type)([str caseInsensitiveCompare:@#type] == NSOrderedSame )

+(MONTHS)paymentMadeForMonth:(NSString *)paymentDate
{
    NSString*str = [paymentDate substringToIndex:3];
    if(MTYPE(jan))
        return FEB;
    if(MTYPE(feb))
        return MAR;
    if(MTYPE(mar))
        return APR;
    if(MTYPE(apr))
        return MAY;
    if(MTYPE(may))
        return JUNE;
    if(MTYPE(jun))
        return JULY;
    if(MTYPE(jul))
        return AUG;
    if(MTYPE(aug))
        return SEP;
    if(MTYPE(sep))
        return OCT;
    if(MTYPE(oct))
        return NOV;
    if(MTYPE(nov))
        return DEC;
    if(MTYPE(dec))
        return JAN;
    return UNKNOWN_MONTH;
}

/*
+(CGFloat)dueAmountForTenant:(Tenant *)ten
{	
	NSDateComponents *components = [[NSCalendar currentCalendar] components:NSDayCalendarUnit | NSMonthCalendarUnit | NSYearCalendarUnit fromDate:[NSDate date]];	
//Current date	
	NSInteger currMonth = [components month];
	NSInteger currYear = [components year];
	NSInteger currDay = [components day];

//last payment made
	NSInteger lastPaymentMadeForMonth = [ten.paymentForIndex intValue];
	CGFloat lastDayOfPayment = [ten.rentDueDay intValue];
//lease start.
	NSInteger leaseStartMonth  = 0;
	NSInteger leaseStartDay = 0;
	NSInteger leaseStartYear = 0;
	NSInteger numOfPaymentDue = 0;
	
	if(ten.leaseStartDate)
	{
		NSArray *comp = [ten.leaseStartDate componentsSeparatedByString:@"/"];
		if([comp count] > 2)
		{
			leaseStartMonth = [[comp objectAtIndex:0] intValue];
			leaseStartDay = [[comp objectAtIndex:1] intValue];
			leaseStartYear = [[comp objectAtIndex:2] intValue];
		}
		comp = nil;
	}
	
	//if no payment made
	if(lastPaymentMadeForMonth == -1)
	{
		//if last day was off
		if(leaseStartDay > lastDayOfPayment)
		{
			//if lease is started previous year.
			if(leaseStartYear < currYear)
			{
				int noOfMnth = (12 - leaseStartMonth) + currMonth;
				int year = currYear - (leaseStartYear + 1);
				if(year)
				{
					numOfPaymentDue = year*noOfMnth;
				}
				else
					numOfPaymentDue = noOfMnth;
			}
			else
				numOfPaymentDue = currMonth - leaseStartMonth;
		}
		else 
		{
			if(leaseStartYear < currYear)
			{
				int noOfMnth =(12 - leaseStartMonth) + currMonth - 1;
				int year = currYear - (leaseStartYear + 1);
				if(year)
				{
					numOfPaymentDue = year*noOfMnth;
				}
				else
					numOfPaymentDue = noOfMnth;
			}
			else
				numOfPaymentDue = (currMonth - leaseStartMonth) - 1;
		}
	}
	else
	{
		int lastPaymentYear = [ten.lastPaymentYear intValue];
		if(currDay > lastDayOfPayment)
		{
			if(lastPaymentYear < currYear)
			{
				int noOfMnth = (11 - lastPaymentMadeForMonth) + currMonth - 1;
				int year = currYear - (lastPaymentYear + 1);
				if(year)
				{
					numOfPaymentDue = year*noOfMnth;
				}
				else
					numOfPaymentDue = noOfMnth;
			}
			else
				numOfPaymentDue = currMonth - (lastPaymentMadeForMonth + 2);
		}
		else 
		{
			if(lastPaymentYear < currYear)
			{
				int noOfMnth = (11 - lastPaymentMadeForMonth) + currMonth - 2;
				int year = currYear - (lastPaymentYear + 1);
				if(year)
				{
					numOfPaymentDue = year*noOfMnth;
				}
				else
					numOfPaymentDue = noOfMnth;
			}
			else
				numOfPaymentDue = (currMonth - lastPaymentMadeForMonth+2) - 1;
		}
	}
	return [ten.rentAmount floatValue] * numOfPaymentDue + [ten.rentDue floatValue];
}*/

#pragma mark -
#pragma mark Find and null Contractor name from Expenses

+(void)didFindContractor:(Contractor *)contractor
{
	AppDelegate_iPhone *appDelegate = (AppDelegate_iPhone *)[[UIApplication sharedApplication] delegate];
	
	NSMutableArray *arrOfBuilding = [CoreDataHelper getObjectsFromContext:ENTITY_KEY_BUILDING :nil :NO :appDelegate.managedObjectContext];
	appDelegate= nil;
	for(Building *building in arrOfBuilding)
	{
		NSArray *arrOfExpenses = [building.expenses allObjects];
		for(Expenses *expenses in arrOfExpenses)
		{
			if([expenses.payee isEqualToString:contractor.name])
			{
				expenses.payee = nil;
				arrOfBuilding = nil; arrOfExpenses = nil;
				return ;
			}
		}
		arrOfExpenses = nil;
	}
	arrOfBuilding = nil;
}

#pragma mark -
#pragma mark didFindOwner

+(void)didFindOwner:(Owner *)owner
{
	AppDelegate_iPhone *appDelegate = (AppDelegate_iPhone *)[[UIApplication sharedApplication] delegate];
	NSMutableArray *arrOfBuilding = [CoreDataHelper getObjectsFromContext:ENTITY_KEY_BUILDING :nil :NO :appDelegate.managedObjectContext];
	appDelegate= nil;
	
	for(Building *building in arrOfBuilding)
	{
		if([building.owner isEqual:owner])
		{
			building.owner = nil;
			arrOfBuilding = nil;
			return ;
		}
	}
	arrOfBuilding = nil;
}

#pragma mark -
#pragma mark didFindBuilding

+(void)didFindBuilding:(Building *)building
{
	AppDelegate_iPhone *appDelegate = (AppDelegate_iPhone *)[[UIApplication sharedApplication] delegate];
	NSMutableArray *arrOfTenant = [CoreDataHelper getObjectsFromContext:ENTITY_KEY_TENANT :nil :NO :appDelegate.managedObjectContext];
	appDelegate= nil;
	
	for(Tenant *tenant in arrOfTenant)
	{
		if([tenant.building isEqual:building])
		{
			tenant.building = nil;
			arrOfTenant = nil;
			return ;
		}
	}
	arrOfTenant = nil;
}

#pragma mark
#pragma mark Rechability

+(BOOL)isNetworkAvailable
{
	if([[Reachability sharedReachability] remoteHostStatus] == NotReachable)
		return NO;
	else 
		return YES;
}


+(void)updateRemainingTenant
{
    NSUserDefaults *standardDefaults = [NSUserDefaults standardUserDefaults];
    NSInteger totalNoOfTenantPurchased = [standardDefaults integerForKey:PURCHASED_TENANT];
    NSInteger numberOfTenantAdded = [standardDefaults integerForKey:TOTAL_ADDED_TENANT];
    --numberOfTenantAdded;
    [standardDefaults setInteger:numberOfTenantAdded forKey:TOTAL_ADDED_TENANT];
}
@end
