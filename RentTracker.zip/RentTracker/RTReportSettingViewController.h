//
//  RTReportSettingViewController.h
//  RentTracker
//
//  Created by ASHIM SAMANTA on 28/03/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ImagePicker.h"
#import "Settings.h"

@interface RTReportSettingViewController : UIViewController <UITextFieldDelegate, CaptureImage>
{

	UITextField *compName_;
	UITextField *propExperts_;
	UITextField *street_;
	UITextField *town_;
	UITextField *country_;
	UIImageView *logoView_;
	
	Settings *setting_;
}

@property (nonatomic, retain) IBOutlet UITextField *compName;
@property (nonatomic, retain) IBOutlet UITextField *propExperts;
@property (nonatomic, retain) IBOutlet UITextField *street;
@property (nonatomic, retain) IBOutlet UITextField *town;
@property (nonatomic, retain) IBOutlet UITextField *country;

@property (nonatomic, retain) IBOutlet UIImageView *logoView;

@property (nonatomic, retain) Settings *setting;

-(IBAction)selectLogo:(id)sender;
-(IBAction)appLogo:(id)sender;
-(void)takePicture;
-(void)loadSettings;
-(void)saveData;

@end
