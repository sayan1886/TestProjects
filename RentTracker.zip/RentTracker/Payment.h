//
//  Payment.h
//  RentTracker
//
//  Created by Manas Kumar Mandal on 18/04/12.
//  Copyright (c) 2012 ObjectSol Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface Payment : NSManagedObject

@property (nonatomic, retain) NSString * amount;
@property (nonatomic, retain) NSString * datePaid;
@property (nonatomic, retain) NSString * year;
@property (nonatomic, retain) NSString * note;
@property (nonatomic, retain) NSString * paymentFor;

@end
