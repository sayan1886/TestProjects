//
//  PdfViewer.h
//  RentTracker
//
//  Created by ASHIM SAMANTA on 03/04/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface PdfViewer : UIViewController 
{
	NSString *url;
}

@property (nonatomic, retain) NSString *url;

@end
