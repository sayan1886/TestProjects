//
//  TestIAPHelper.m
//  TestInAppPurchase
//
//  Created by ASHIM SAMANTA on 09/02/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import "TestIAPHelper.h"
#import "Constant.h"

@implementation TestIAPHelper

static TestIAPHelper * _sharedHelper;

+ (TestIAPHelper *) sharedHelper 
{
    if (_sharedHelper != nil) 
	{
        return _sharedHelper;
    }
    _sharedHelper = [[TestIAPHelper alloc] init];
    return _sharedHelper;
}

- (id)init 
{
    NSSet *productIdentifiers = [NSSet setWithObjects:ONE_TENANT_PROCUCT_ID, TEN_TENANT_PRODUCTID, FIFTY_TENANT_PRODUCTID, nil];
								 	
    if ((self = [super initWithProductIdentifiers:productIdentifiers])) {
    }
    return self;
}

@end
