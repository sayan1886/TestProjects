//
//  RTExpencesAddViewController.m
//  RentTracker
//
//  Created by ASHIM SAMANTA on 06/03/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import "RTExpencesAddViewController.h"
#import "AppDelegate_iPhone.h"
#import "NSManagedObjectContext+insert.h"
#import "CustomCell.h"
#import "Utility.h"
#import "Constant.h"
#import "Expenses.h"
#import "CoreDataHelper.h"
#import "Contractor.h"

@implementation RTExpencesAddViewController

@synthesize rtExpencesAddTableView = rtExpencesAddTableView_;
@synthesize tempDict = tempDict_;
@synthesize building = building_;
@synthesize pView = pView_;
@synthesize datePicker =datePicker_;
@synthesize pickerView = pickerView_;
@synthesize textFieldToHidePicker = textFieldToHidePicker_;
@synthesize contractorPickerArray = contractorPickerArray_;
@synthesize txtNote = txtNote;
// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"Add Expenses";
        UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(done:)];
		self.navigationItem.rightBarButtonItem = item;
		[item release];
    }
    return self;
}
-(BOOL)hasDescription
{
	NSString *key = [NSString stringWithFormat:@"%d",EXENCES_DESCRIPTION];
	NSString *desc = [self.tempDict objectForKey:key];
	key = nil;
	if(!desc) return NO;
	
	desc = [desc stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	return ([desc length] > 0);
}
-(void)done:(id)sender
{
	if([self.txtNote isFirstResponder])
		[self.txtNote resignFirstResponder];
	if([self.textFieldToHidePicker isFirstResponder])
		[self.textFieldToHidePicker resignFirstResponder];
	[Utility increaseHeightOfTableView:self.rtExpencesAddTableView];
	if(![self hasDescription])
	{
		[Utility showAlertViewWithTitle:TITLE_MANDATORY_FIELD Message:MESSAGE_EXPENSE_MANDATORY_FIELD CancelTitle:CANCEL_TITLE];
		return ;
	}
	AppDelegate_iPhone *appDelegate =  (AppDelegate_iPhone *)[[UIApplication sharedApplication] delegate];
	Expenses *expenses = (Expenses *)[appDelegate.managedObjectContext insertNewEntityWithName:ENTITY_KEY_EXPENSES];
	
	if(self.building && self.tempDict)
	{
		expenses.descriptions = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",EXENCES_DESCRIPTION]];
		expenses.payee = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",EXENCES_PAYEE]];
		expenses.amount = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",EXENCES_AMOUNT]];
		expenses.date = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",EXENCES_DATE]];
		expenses.checkNo = [self.tempDict valueForKey:[NSString stringWithFormat:@"%d",EXENCES_CHECK_NO]];
		
		expenses.note = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",EXENCES_NOTE]];
		expenses.category = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",EXENCES_CATEGORIES]];
		expenses.building = self.building;
		
		[self.building addExpensesObject:expenses];
		[appDelegate saveContext];
	}
	[self.navigationController popViewControllerAnimated:YES];
}

-(void)loadContractor
{
	AppDelegate_iPhone *app = (AppDelegate_iPhone *)[[UIApplication sharedApplication]delegate];
	NSMutableArray *arrTemp = [CoreDataHelper getObjectsFromContext:ENTITY_KEY_CONTRACTOR :nil :NO :app.managedObjectContext];
	for(Contractor *cont in arrTemp)
	{
		[self.contractorPickerArray addObject:cont.name];
	}
	arrTemp = nil;
}

#pragma mark -
#pragma mark viewDidLoad

- (void)viewDidLoad {
    [super viewDidLoad];
	
	if(!pickerArray) pickerArray = [[NSMutableArray alloc] initWithObjects:@"Advertising",
									@"Travel", @"Cleaning/Maint", @"Commissions",
									@"Insurance",@"Professional Fees",
									@"Management Fees",@"Repairs",@"Supplies",
									@"Real Estate Taxes",@"Other Taxes",@"Utilities",@"Depreciable Expense", nil];
	self.contractorPickerArray = [[NSMutableArray alloc] init];
	[self loadContractor];
	//[self loadContractor];
	CGRect frame;
	if(ISIPHONE)
		frame = CGRectMake(0, 460, 320, 480);
	else
		frame = CGRectMake(0, 1024, 768, 1024);
	
	self.pView = [[UIView alloc] initWithFrame:frame];
	self.pView.backgroundColor = [UIColor clearColor];
	
	if(ISIPHONE)
		frame = CGRectMake(0, 199, 320, 45);
	else
		frame = CGRectMake(0, 723, 768, 65);
	
	NSMutableArray *arr = [[NSMutableArray alloc] init];
	
	UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(cancelPickerView)];
	[arr addObject:item];
	[item release]; item = nil;
	
	item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
	[arr addObject:item];
	[item release]; item = nil;
	
	item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(hidePickerView)];
	[arr addObject:item];
	[item release]; item = nil;
	UIToolbar *toolBar = [[UIToolbar alloc] initWithFrame:frame];
	[toolBar setItems:arr animated:YES];
	
	if(ISIPHONE)
		frame = CGRectMake(0, 244, 320, 216);
	else
		frame = CGRectMake(0, 788, 768, 216);
	
	self.pickerView = [[UIPickerView alloc] initWithFrame:frame];
	self.pickerView.showsSelectionIndicator = YES;
	self.pickerView.delegate = self;
	self.pickerView.dataSource = self;
	
	self.datePicker = [[UIDatePicker alloc] initWithFrame:frame];
	self.datePicker.datePickerMode = UIDatePickerModeDate;
	
	[self.pView addSubview:toolBar];
	
	[self.view addSubview:self.pView];
	
	self.tempDict = [[NSMutableDictionary alloc] init];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{

	return EXENCES_NO_OF_SECTION;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	switch (section) 
	{
		case 0:
			return 1;
		case 1:
		case 2:
			return 2;
		case 3:
		case 4:
		case 5:
			return 1;
	}
	return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	if(indexPath.section == 5) return HEIGHT_FOR_NOTE_ROW;
	return HEIGHT_FOR_ROW;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	//static NSString *cellIdentifier = @"CellID";
	CustomCell *cell = [[[CustomCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil ReadOnly:NO] autorelease ];
	cell.textField.delegate = self;
	
	switch(indexPath.section)
	{
		case 0:
			cell.label.text = @"Description :";
			cell.textField.placeholder = @"Description";
			cell.textField.tag = EXENCES_DESCRIPTION;
			cell.textField.text = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",cell.textField.tag]];
			return cell;
			
		case 1:					
			switch(indexPath.row)
		{
			case 0:
				cell.label.text = @"Building :";
				cell.textField.placeholder = @"Building";
				cell.textField.tag = EXENCES_BUILDING;
				cell.textField.text = self.building.address;
				cell.textField.userInteractionEnabled = NO;
				return cell;
			case 1:
				cell.label.text = @"Payee :";
				cell.textField.placeholder = @"Payee";
				cell.textField.tag = EXENCES_PAYEE;
				cell.textField.text = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",cell.textField.tag]];
				return cell;
		}
			
		case 2:
			switch(indexPath.row)
		{
			case 0:
				cell.label.text = @"Expense Amt :";
				cell.textField.placeholder = @"Expense Amt";
				cell.textField.tag = EXENCES_AMOUNT;
				if(ISIPHONE)
                    cell.textField.keyboardType = UIKeyboardTypeDecimalPad;
                else
                    cell.textField.keyboardType = UIKeyboardTypeNumberPad;
				cell.textField.text = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",cell.textField.tag]];
				return cell;
			case 1:
				cell.label.text = @"Expenses Date :";
				cell.textField.placeholder = @"mm/dd/yyyy";
				cell.textField.tag = EXENCES_DATE;
				cell.textField.text = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",cell.textField.tag]];
				return cell;
		}
		case 3:
			switch(indexPath.row)
		{
			case 0:
				cell.label.text = @"Check No :";
				cell.textField.placeholder = @"Check No";
				cell.textField.tag = EXENCES_CHECK_NO;
				cell.textField.keyboardType = UIKeyboardTypeNumberPad;
				cell.textField.text = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",cell.textField.tag]];
				return cell;
		}
		
		case 4:
			switch(indexPath.row)
		{
			case 0:
				cell.label.text = @"Categories :";
				cell.textField.tag = EXENCES_CATEGORIES;
				cell.textField.text = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",cell.textField.tag]];
				return cell;
		}
		case 5:
			[[cell.contentView subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
			cell.textLabel.text = @"NOTE :";
			CGRect frame;
			if(ISIPHONE)
				frame = CGRectMake(100, 5, 200, 122.0);
			else
				frame = CGRectMake(100, 5, 560, 122.0);
			self.txtNote = [[UITextView alloc] initWithFrame:frame];
			self.txtNote.backgroundColor = [UIColor clearColor];
			[cell.contentView addSubview:self.txtNote];
			self.txtNote.delegate = self;
			self.txtNote.tag = EXENCES_NOTE;
			self.txtNote.text = [self.tempDict objectForKey:[NSString stringWithFormat:@"%d",self.txtNote.tag]];
			return cell;
	}
	return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
}

-(void)addToolBar:(UITextView *)textView
{
	UIToolbar *toolBar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, 100, 35)];
	NSMutableArray *arr = [[NSMutableArray alloc] init];
	UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(ok)];
	[arr addObject:item];
	[item release];item = nil;
	
	item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
	[arr addObject:item];
	[item release];item = nil;
	
	item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(cancel:)];
	[arr addObject:item];
	[item release];item = nil;
	
	toolBar.items = arr;
	
	[arr release];arr = nil;
	
	textView.inputAccessoryView = toolBar;
}

-(void)cancel:(id)sender
{
	[Utility increaseHeightOfTableView:self.rtExpencesAddTableView];
	self.txtNote.text = @"";
	[self.txtNote resignFirstResponder];
}
-(void)ok
{
	[Utility increaseHeightOfTableView:self.rtExpencesAddTableView];
	[self.txtNote resignFirstResponder];
}
- (BOOL)textViewShouldBeginEditing:(UITextView *)textView
{
	if(textView.tag == EXENCES_NOTE)
	{
		[self addToolBar:textView];
		[Utility decreaseHeightOfTableView:self.rtExpencesAddTableView];
		return YES;
	}
	return YES;
}

- (void)textViewDidEndEditing:(UITextView *)textView
{
	if(textView.text)
		[self.tempDict setObject:textView.text forKey:[NSString stringWithFormat:@"%d",textView.tag]];
}


// returns the number of 'columns' to display.
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
	return 1;
}

// returns the # of rows in each component..
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
	if(pickerTag == CONTRACTOR_PICKER)
		return [self.contractorPickerArray count];
	return [pickerArray count];
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
	if(pickerTag == CONTRACTOR_PICKER)
		return [self.contractorPickerArray objectAtIndex:row];
	return [pickerArray objectAtIndex:row];
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
	if(pickerTag == CONTRACTOR_PICKER)
	{
		tempTextField.text = [self.contractorPickerArray objectAtIndex:row] ;
		return ;
	}
	tempTextField.text = [pickerArray objectAtIndex:row];
	selectedIndex = row;
}

-(void)hidePickerView
{
	NSDateFormatter *formatter = nil;
	switch (pickerTag) 
	{
		case PICKER:
		case CONTRACTOR_PICKER:
			//tempTextField.text = [pickerArray objectAtIndex:selectedIndex];
			break;
		case DATE_PICKER:
			formatter = [[NSDateFormatter alloc] init];
			[formatter setDateFormat:@"MM/dd/yyyy"];
			tempTextField.text = [formatter stringFromDate:self.datePicker.date];
			break;
	}
	if(tempTextField.text)
		[self.tempDict setObject:tempTextField.text forKey:[NSString stringWithFormat:@"%d",tempTextField.tag]];
	[Utility hidesDropDown:self.pView];
	[Utility increaseHeightOfTableView:self.rtExpencesAddTableView];
}

-(void)cancelPickerView
{
	//tempTextField.text = @"";
	[Utility hidesDropDown:self.pView];
	[Utility increaseHeightOfTableView:self.rtExpencesAddTableView];
}


#pragma mark -
#pragma mark TextField Delegate Method

// return NO to disallow editing.
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
	if(textField.tag == EXENCES_CATEGORIES)
	{
		if([self.pickerView superview])
			[self.pickerView removeFromSuperview];
		if([self.datePicker superview])
			[self.datePicker removeFromSuperview];
		if([self.txtNote isFirstResponder])
			[self.txtNote resignFirstResponder];
		if([self.textFieldToHidePicker isFirstResponder])
		{
			[self.textFieldToHidePicker resignFirstResponder];
			[Utility increaseHeightOfTableView:self.rtExpencesAddTableView];
		}
		pickerTag = PICKER;
		[self.pickerView reloadAllComponents];
		
		tempTextField = textField;
		[self.pickerView selectRow:0 inComponent:0 animated:YES];
		[self pickerView:self.pickerView didSelectRow:0 inComponent:0];
		[self.pView addSubview:self.pickerView];
		[Utility showDropDown:self.pView];
		return NO;
	}
	if(textField.tag == EXENCES_PAYEE)
	{
		if([self.pickerView superview])
			[self.pickerView removeFromSuperview];
		if([self.datePicker superview])
			[self.datePicker removeFromSuperview];
		if([self.txtNote isFirstResponder])
			[self.txtNote resignFirstResponder];
		if([self.textFieldToHidePicker isFirstResponder])
		{
			[self.textFieldToHidePicker resignFirstResponder];
			[Utility increaseHeightOfTableView:self.rtExpencesAddTableView];
		}
		
		tempTextField = textField;
		pickerTag = CONTRACTOR_PICKER;
		[self.pickerView reloadAllComponents];
		[self.pickerView selectRow:0 inComponent:0 animated:YES];
		[self pickerView:self.pickerView didSelectRow:0 inComponent:0];
		[self.pView addSubview:self.pickerView];
		[Utility showDropDown:self.pView];
		return NO;
	}
	if(textField.tag == EXENCES_DATE)
	{
		if([self.pickerView superview])
			[self.pickerView removeFromSuperview];
		if([self.datePicker superview])
			[self.datePicker removeFromSuperview];
		if([self.textFieldToHidePicker isFirstResponder])
		{
			[self.textFieldToHidePicker resignFirstResponder];
			[Utility increaseHeightOfTableView:self.rtExpencesAddTableView];
		}
		
		tempTextField = textField;
		pickerTag = DATE_PICKER;
		[self.pView addSubview:self.datePicker];
		[Utility showDropDown:self.pView];
		return NO;
	}
	
	[Utility decreaseHeightOfTableView:self.rtExpencesAddTableView];
	
	self.textFieldToHidePicker = textField;
	return YES;
}

// became first responder
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
	
}

// return YES to allow editing to stop and to resign first responder status. NO to disallow the editing session to end
- (BOOL)textFieldShouldEndEditing:(UITextField *)textField         
{
	
	return YES;
}

// may be called if forced even if shouldEndEditing returns NO (e.g. view removed from window) or endEditing:YES called
- (void)textFieldDidEndEditing:(UITextField *)textField             
{
	[self.tempDict setObject:textField.text forKey:[NSString stringWithFormat:@"%d",textField.tag]];
	[textField resignFirstResponder];
}

// called when clear button pressed. return NO to ignore (no notifications)
- (BOOL)textFieldShouldClear:(UITextField *)textField
{
	return YES;
}

// called when 'return' key pressed. return NO to ignore.
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
	[textField resignFirstResponder];
	
	[Utility increaseHeightOfTableView:self.rtExpencesAddTableView];
	
	return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
	if(textField.tag == EXENCES_AMOUNT)
	{
		NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:VALID_FLOAT] invertedSet];
		NSString *filtered = [[string componentsSeparatedByCharactersInSet:cs] componentsJoinedByString:@""];
		return [string isEqualToString:filtered];
	}
	
	return YES;
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
	
	self.rtExpencesAddTableView = nil;
	self.tempDict = nil;
	self.pView = nil;
	self.datePicker = nil;
	self.pickerView = nil;
	self.textFieldToHidePicker = nil;
	self.contractorPickerArray = nil;
	self.txtNote = nil;
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	
	self.rtExpencesAddTableView = nil;
	self.tempDict = nil;
	self.pView = nil;
	self.datePicker = nil;
	self.pickerView = nil;
	self.textFieldToHidePicker = nil;
	self.contractorPickerArray = nil;
	self.txtNote = nil;
    [super dealloc];
}


@end
