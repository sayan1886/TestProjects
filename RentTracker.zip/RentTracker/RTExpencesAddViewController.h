//
//  RTExpencesAddViewController.h
//  RentTracker
//
//  Created by ASHIM SAMANTA on 06/03/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Building.h"
#import "Constant.h"

@interface RTExpencesAddViewController : UIViewController <UITableViewDelegate, UITextViewDelegate,
											UITableViewDataSource, UITextFieldDelegate,
											UIPickerViewDataSource, UIPickerViewDelegate>
{
	UITableView *rtExpencesAddTableView_;
	NSMutableDictionary *tempDict_;
	UIButton * btn;
	
	NSMutableArray *pickerArray;
	UITextField *tempTextField;
	
	NSMutableArray *contractorPickerArray_;
	
	Building *building_;
	
	UITextView *txtNote;
// for picker	
	UIView *pView_;
	PICKER_TAG pickerTag;
	UIDatePicker *datePicker_;
	UIPickerView *pickerView_;
	UITextField *textFieldToHidePicker_;
	NSInteger selectedIndex;
	
}
@property (nonatomic, retain) IBOutlet UITableView *rtExpencesAddTableView;
@property (nonatomic, retain) NSMutableDictionary *tempDict;
@property (nonatomic, retain) Building *building;
@property (nonatomic, retain) UIView *pView;
@property (nonatomic, retain) UIDatePicker *datePicker;
@property (nonatomic, retain) UIPickerView *pickerView;
@property (nonatomic, retain) UITextField *textFieldToHidePicker;
@property (nonatomic, retain) NSMutableArray *contractorPickerArray;
@property (nonatomic, retain) UITextView *txtNote;

@end
