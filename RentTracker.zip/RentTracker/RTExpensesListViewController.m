//
//  RTExpensesListViewController.m
//  RentTracker
//
//  Created by ASHIM SAMANTA on 22/03/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import "RTExpensesListViewController.h"
#import "RTExpencesAddViewController.h"
#import "RTExpenseEditViewController.h"
#import "AppDelegate_iPhone.h"
#import "CoreDataHelper.h"
#import "Utility.h"
#import "Constant.h"
#import "Expenses.h"


@implementation RTExpensesListViewController
@synthesize rtExpencesListTableView = rtExpencesListTableView_;
@synthesize searchText = searchText_;
@synthesize building = building_;
@synthesize resultdict = resultdict_;
@synthesize arr = arr_;
@synthesize array = array_;

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"Expenses";
		UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(add:)];
		 self.navigationItem.rightBarButtonItem = item;
		 [item release];
    }
    return self;
}

-(void)add:(id)sender
{
	AppDelegate_iPhone *app = (AppDelegate_iPhone *)[[UIApplication sharedApplication]delegate];
	NSMutableArray *arrResult = [CoreDataHelper getObjectsFromContext:ENTITY_KEY_CONTRACTOR :nil :NO :app.managedObjectContext];
	if(!arrResult || [arrResult count] == 0)
	{
		[Utility showAlertViewWithTitle:TITLE Message:MESSAGE_NO_CONTRACTOR CancelTitle:CANCEL_TITLE];
		return ;
	}
	arrResult = nil;
	RTExpencesAddViewController *viewController = [[RTExpencesAddViewController alloc] initWithNibName:@"RTExpencesAddViewController" bundle:nil];
	viewController.building = self.building;
	[self.navigationController pushViewController:viewController animated:YES];
	[viewController release];
}


#pragma mark -
#pragma mark TableView delegate method

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
	return HEIGHT_FOR_HEADER;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
	
	if(![tableView isEqual:self.rtExpencesListTableView]) return nil;
	
	UIView *header = [[[UIView alloc]initWithFrame:CONTACT_HEADER_FRAME] autorelease];
	header.backgroundColor = [UIColor colorWithPatternImage:[[UIImage imageNamed:CONTACT_HEADER_IMAGE] stretchableImageWithLeftCapWidth:0 topCapHeight:32]];
	
	UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, 6, 20, 20)];
	
	if([tableView isEqual:self.rtExpencesListTableView])
	{
		label.text = [self.arr objectAtIndex:section];
	}
	
	label.backgroundColor = [UIColor clearColor];
	label.textColor = [UIColor whiteColor];
	
	[header addSubview:label];
	
	[label release];
	return header;
}

// return list of section titles to display in section index view (e.g. "ABCD...Z#")
-(NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView
{
	if(![tableView isEqual:self.rtExpencesListTableView]) return nil;
	NSMutableArray *toBeReturned = [[NSMutableArray alloc]init];
    for(char c = 'A'; c <= 'Z'; c++) [toBeReturned addObject:[NSString stringWithFormat:@"%c",c]];
    return [toBeReturned autorelease];
}

// tell table which section corresponds to section title/index (e.g. "B",1))

-(NSInteger)tableView:(UITableView *)tableView sectionForSectionIndexTitle:(NSString *)title atIndex:(NSInteger)index
{
	NSLog(@"index = %d", index);
	return index;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	if([tableView isEqual:self.rtExpencesListTableView])
	{
		NSArray *arrRes = [self.resultdict objectForKey:[self.arr objectAtIndex:section]];
		return [arrRes count];
	}
	return [self.searchText count];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	if([tableView isEqual:self.rtExpencesListTableView])
	{
		return [self.arr count];
	}
	return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	NSString *text = @"";
	if([tableView isEqual:self.rtExpencesListTableView]) 
	{
		NSString *val = [self.arr objectAtIndex:indexPath.section];
		NSArray *tempArr = [self.resultdict objectForKey:val];
		Expenses *expen = [tempArr objectAtIndex:indexPath.row];
		text = expen.descriptions;
		tempArr = nil;
	}
	else 
	{
		text = [[self.searchText objectAtIndex:indexPath.row] valueForKey:@"descriptions"];
	}	
	UITableViewCell *cell = cell = [[[UITableViewCell alloc] initWithStyle:UITableViewStylePlain reuseIdentifier:nil] autorelease];
	cell.textLabel.text = text;
	return cell;
}
#pragma mark -
#pragma mark Delete for swipe

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
	AppDelegate_iPhone *app = (AppDelegate_iPhone *)[[UIApplication sharedApplication] delegate];
	NSArray *arrTodel = [self.resultdict allKeys];
	NSString *val = [self.arr objectAtIndex:indexPath.section];
	arrTodel = nil;
	arrTodel = [self.resultdict objectForKey:val];
	Expenses *expen = [arrTodel objectAtIndex:indexPath.row];
	arrTodel = nil;
	[self.building removeExpensesObject:expen];
	[app saveContext];
	[self getValues];
	
	[tableView reloadData];
}
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
	return YES;
}
- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return UITableViewCellEditingStyleDelete;	
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	Expenses *expen = nil;
	if([tableView isEqual:self.rtExpencesListTableView])
	{
		NSString *val = [self.arr objectAtIndex:indexPath.section];
		NSArray *tempArr = [self.resultdict objectForKey:val];
		expen = [tempArr objectAtIndex:indexPath.row];
		tempArr = nil;
	}
	else 
	{
		expen = [self.searchText objectAtIndex:indexPath.row];
	}
	
	RTExpenseEditViewController *viewController = [[RTExpenseEditViewController alloc] initWithNibName:@"RTExpenseEditViewController" bundle:nil];
	viewController.building = self.building;
	viewController.expenses = expen;
	[self.navigationController pushViewController:viewController animated:YES];
	[viewController release];viewController = nil;
}


#pragma mark -
#pragma mark SEARCH

- (BOOL)searchDisplayController:(UISearchDisplayController *)controller shouldReloadTableForSearchString:(NSString *)searchString
{    
    [self.searchText removeAllObjects];
    
    for (Expenses *expen in self.array)
    {
		NSString *aStr = [expen.descriptions lowercaseString];
		if ([aStr rangeOfString:[searchString lowercaseString]].location != NSNotFound)
            [self.searchText addObject:expen];
    }
	
    [controller.searchResultsTableView reloadData];
    
    return NO;
}

- (void)searchDisplayControllerWillBeginSearch:(UISearchDisplayController *)controller
{
    self.rtExpencesListTableView.hidden = YES;
}

- (void)searchDisplayControllerDidEndSearch:(UISearchDisplayController *)controller
{
    self.rtExpencesListTableView.hidden = NO;
}

-(void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	[self getValues];
	[self.rtExpencesListTableView reloadData];
}

-(void)getValues
{
	self.array = [self.building.expenses allObjects];
	self.resultdict = [Utility arrangeList:self.array sortKey:@"descriptions"];
	self.arr = [self.resultdict allKeys];
	self.arr = [self.arr sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	self.searchText = [[NSMutableArray alloc] init];
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
	
	self.rtExpencesListTableView = nil;
	self.searchText = nil;
	
	self.resultdict = nil;
	self.arr = nil;
	self.array = nil;
	
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
	
	self.rtExpencesListTableView = nil;
	self.searchText = nil;
	
	self.resultdict = nil;
	self.arr = nil;
	self.array = nil;
	
    [super dealloc];
}


@end
