// 
//  Tenant.m
//  RentTracker
//
//  Created by ASHIM SAMANTA on 14/03/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import "Tenant.h"

#import "Building.h"

@implementation Tenant 

@dynamic first;
@dynamic sep_paid_date;
@dynamic state;
@dynamic last;
@dynamic move_in_date;
@dynamic mobile;
@dynamic rent_due;
@dynamic work_phone;
@dynamic address;
@dynamic city;
@dynamic deposit_amount;
@dynamic home_phone;
@dynamic postal_code;
@dynamic email;
@dynamic building;

@end
