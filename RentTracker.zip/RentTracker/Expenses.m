//
//  Expenses.m
//  RentTracker
//
//  Created by Manas Kumar Mandal on 18/04/12.
//  Copyright (c) 2012 ObjectSol Technologies. All rights reserved.
//

#import "Expenses.h"
#import "Building.h"


@implementation Expenses

@dynamic amount;
@dynamic category;
@dynamic note;
@dynamic descriptions;
@dynamic date;
@dynamic payee;
@dynamic checkNo;
@dynamic building;

@end
