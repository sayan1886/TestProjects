//
//  RTReportViewController.m
//  RentTracker
//
//  Created by ASHIM SAMANTA on 07/03/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import "RTReportViewController.h"
#import "Utility.h"
#import "CoreDataHelper.h"
#import "Tenant.h"
#import "Building.h"
#import "Owner.h"
#import "CoreDataHelper.h"
#import "AppDelegate_iPhone.h"
#import "MBProgressHUD.h"
#import "CreatePDF.h"
#import "RTReportSettingViewController.h"
#import "mail.h"
#import "PdfViewer.h"

@implementation RTReportViewController

@synthesize txtFldFrom = txtFldFrom_;
@synthesize txtFldTo = txtFldTo_;
@synthesize txtFldReport = txtFldReport_;
@synthesize datePicker = datePicker_;
@synthesize reportPicker = reportPicker_;
@synthesize rightItem = rightItem_;

@synthesize pView = pView_;
@synthesize pickerView = pickerView_;
@synthesize tempTextField = tempTextField_;
@synthesize txtFldSelect = txtFldSelect_;
@synthesize lblSelect = lblSelect_;
@synthesize arrOfSelect = arrOfSelect_;
@synthesize selectPicker = selectPicker_;
@synthesize arrOfObjects = arrOfObjects_;
@synthesize btnRunReport;

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"Reports";
		self.rightItem = [[UIBarButtonItem alloc] initWithTitle:@"Settings" style:UIBarButtonItemStyleDone target:self action:@selector(setting:)];
    }
    return self;
}
- (void)showLoadingView
{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
}

- (void)hideLoadingView
{
    [MBProgressHUD hideHUDForView:self.view animated:YES];
}
-(void)setting:(id)sender
{
	RTReportSettingViewController *viewController = [[RTReportSettingViewController alloc] initWithNibName:@"RTReportSettingViewController" bundle:nil];
	[self.navigationController pushViewController:viewController animated:YES];
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	[self.navigationItem setRightBarButtonItem:self.rightItem animated:YES];
	
	self.arrOfObjects = [[NSMutableArray alloc] init];
	self.arrOfSelect = [[NSMutableArray alloc] init];
	
	arrOfReportTypes = [[NSMutableArray alloc] 
						initWithObjects:@"Income Report By Building",
										@"Income Report By Owner",
										@"Expense Report By Building",
										@"Expense Report By Owner",
										@"Total Finance By Building",
										@"Total Finance By Owner",
										@"Tenant Payment Report",
										@"Late Tenant Report",
										@"Tenant Phone List",
						@"Rent Roll", nil];
	
	self.txtFldFrom.tag = FROM;
	self.txtFldTo.tag = TO;
	self.txtFldReport.tag = REPORT;
	self.txtFldSelect.tag = SELECT;
	
	CGRect frame;
	if(ISIPHONE)
		frame = CGRectMake(0, 460, 320, 480);
	else
		frame = CGRectMake(0, 1024, 768, 1024);
	
	self.pView = [[UIView alloc] initWithFrame:frame];
	self.pView.backgroundColor = [UIColor clearColor];
	
	if(ISIPHONE)
		frame = CGRectMake(0, 199, 320, 45);
	else
		frame = CGRectMake(0, 723, 768, 65);
	
	NSMutableArray *arr = [[NSMutableArray alloc] init];
	
	UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(cancelPickerView)];
	[arr addObject:item];
	[item release]; item = nil;
	
	item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
	[arr addObject:item];
	[item release]; item = nil;
	
	item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(hidePickerView)];
	[arr addObject:item];
	[item release]; item = nil;
	UIToolbar *toolBar = [[UIToolbar alloc] initWithFrame:frame];
	[toolBar setItems:arr animated:YES];
	
	if(ISIPHONE)
		frame = CGRectMake(0, 244, 320, 216);
	else
		frame = CGRectMake(0, 788, 768, 216);
	
	self.pickerView = [[UIPickerView alloc] initWithFrame:frame];
	self.pickerView.showsSelectionIndicator = YES;
	self.pickerView.delegate = self;
	self.pickerView.dataSource = self;
	
	self.selectPicker = [[UIPickerView alloc] initWithFrame:frame];
	self.selectPicker.showsSelectionIndicator = YES;
	self.selectPicker.delegate = self;
	self.selectPicker.dataSource = self;
	
	self.datePicker = [[UIDatePicker alloc] initWithFrame:frame];
	self.datePicker.datePickerMode = UIDatePickerModeDate;
	
	NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
	[formatter setDateFormat:@"yyyy"];
	
	NSString *year = [formatter stringFromDate:[NSDate date]];
	self.txtFldFrom.text = [NSString stringWithFormat:@"01/01/%@",year];
	self.txtFldTo.text = [NSString stringWithFormat:@"12/31/%@",year];
	[self.pView addSubview:toolBar];
	
	[self.view addSubview:self.pView];
}

#pragma mark -
#pragma mark runReport

-(IBAction)runReport:(id)sender
{
	if(self.txtFldSelect.alpha == 1.0)
	{
		if([self.txtFldSelect.text length] == 0)
		{
			[Utility showAlertViewWithTitle:@"No Data!!!" Message:@"Please Select One." CancelTitle:CANCEL_TITLE];
			return ;
		}
		else
		{
			;
			
		}
	}
	else
	{
		;
	}
	CreatePDF *pdfCreate = [[CreatePDF alloc] init];
	NSString *fileName = @"";
	mail *email = [[mail alloc] init];
	email.con = self;
    
    if([self.arrOfObjects count] == 0) return;
    
	switch (reportTypesTag) 
	{
		case INCOME_REPORT_BY_BUILDING:
			pdfCreate.arrOfTag = [[NSMutableArray alloc] initWithObjects:@"datePaid",
								  @"paymentFor", @"year",@"first", @"last",@"amount",nil];
			
			pdfCreate.arrayOfAttribute = [[NSMutableArray alloc] initWithObjects:
										  @"DATE PAID",										  
										  @"FOR MONTH",										  
										  @"FOR YEAR",										  
										  @"FIRST NAME",										  
										  @"LAST NAME",
										  @"AMOUNT PAID",nil];
			pdfCreate.reportTypesTag = reportTypesTag;
			pdfCreate.building = [self.arrOfObjects objectAtIndex:selectedIndex];
			pdfCreate.noOfCol = 6;
			pdfCreate.reportedBy = self.txtFldReport.text;
			pdfCreate.reportedFor = [NSString stringWithFormat:@"Report For Building : %@",self.txtFldSelect.text];
			fileName = @"/incomeReportByBuilding.pdf";
			pdfCreate.reportedFrom = self.txtFldFrom.text;
			pdfCreate.reportedTo = self.txtFldTo.text;
			[pdfCreate createPDFWithFileName:fileName];
			//[email mailWithData:fileName];
			
			break;
			
		case INCOME_REPORT_BY_OWNER:
			pdfCreate.arrOfTag = [[NSMutableArray alloc] initWithObjects:@"address",@"datePaid",
								  @"paymentFor", @"year",@"first", @"last",@"amount",nil];
			
			pdfCreate.arrayOfAttribute = [[NSMutableArray alloc] initWithObjects:@"BUILDING ADDRESS",
										  @"DATE PAID",										  
										  @"FOR MONTH",										  
										  @"FOR YEAR",										  
										  @"FIRST NAME",										  
										  @"LAST NAME",
										  @"AMOUNT PAID",nil];
			pdfCreate.reportTypesTag = reportTypesTag;
			pdfCreate.owner = [self.arrOfObjects objectAtIndex:selectedIndex];
			pdfCreate.noOfCol = 7;
			pdfCreate.reportedBy = self.txtFldReport.text;
			pdfCreate.reportedFor = [NSString stringWithFormat:@"Report For Owner : %@",self.txtFldSelect.text];
			fileName = @"/incomeReportByOwner.pdf";
			pdfCreate.reportedFrom = self.txtFldFrom.text;
			pdfCreate.reportedTo = self.txtFldTo.text;
			[pdfCreate createPDFWithFileName:fileName];
			//[email mailWithData:fileName];
			break;
			
		case EXPENSE_REPORT_BY_BUILDING:
			
			pdfCreate.arrOfTag = [[NSMutableArray alloc] initWithObjects:@"date",@"descriptions",
								  @"payee", @"note",@"category", @"amount",nil];
			pdfCreate.arrayOfAttribute = [[NSMutableArray alloc] initWithObjects:@"PAID DATE",
										  @"DESCRIPTION",										  
										  @"PAYEE",										  
										  @"NOTES",										  
										  @"CATEGORY",										  
										  @"EXPENSE AMOUNT",nil];
			pdfCreate.reportTypesTag = reportTypesTag;
			pdfCreate.building = [self.arrOfObjects objectAtIndex:selectedIndex];
			pdfCreate.noOfCol = 6;
			pdfCreate.reportedBy = self.txtFldReport.text;
			pdfCreate.reportedFor = [NSString stringWithFormat:@"Report For Building Address : %@",self.txtFldSelect.text];
			fileName = @"/ExpenseReportByBuilding.pdf";
			pdfCreate.reportedFrom = self.txtFldFrom.text;
			pdfCreate.reportedTo = self.txtFldTo.text;
			[pdfCreate createPDFWithFileName:fileName];
			//[email mailWithData:fileName];
			break;
			
		case EXPENSE_REPORT_BY_OWNER:
			
			pdfCreate.arrOfTag = [[NSMutableArray alloc] initWithObjects:@"address",@"date",
								 @"descriptions", @"payee", @"note",@"category", @"amount",nil];
			pdfCreate.arrayOfAttribute = [[NSMutableArray alloc] initWithObjects:@"ADDRESS",
										  @"PAID DATE",										  
										  @"DESCRIPTION",										  
										  @"PAYEE",										  
										  @"NOTES",										  
										  @"CATEGORY",@"EXPENSE AMOUNT",nil];
			pdfCreate.reportTypesTag = reportTypesTag;
			pdfCreate.owner = [self.arrOfObjects objectAtIndex:selectedIndex];
			pdfCreate.noOfCol = 7;
			pdfCreate.reportedBy = self.txtFldReport.text;
			pdfCreate.reportedFor = [NSString stringWithFormat:@"Report For Owner : %@",self.txtFldSelect.text];
			fileName = @"/ExpenseReportByOwner.pdf";
			pdfCreate.reportedFrom = self.txtFldFrom.text;
			pdfCreate.reportedTo = self.txtFldTo.text;
			[pdfCreate createPDFWithFileName:fileName];
			//[email mailWithData:fileName];			
			break;
			
		case TOTAL_FINANCE_BY_BUILDING:
			pdfCreate.arrOfTag = [[NSMutableArray alloc] initWithObjects:@"month",@"income",
								  @"expense", @"total",nil];
			
			pdfCreate.arrayOfAttribute = [[NSMutableArray alloc] initWithObjects:@"MONTH",
										  @"INCOME",		
										  @"EXPENSE",										  
										  @"TOTAL",										  
										  nil];
			
			pdfCreate.reportTypesTag = reportTypesTag;
			pdfCreate.building = [self.arrOfObjects objectAtIndex:selectedIndex];
			pdfCreate.noOfCol = 4;
			pdfCreate.reportedBy = [NSString stringWithFormat:@"Total Finance By Building : %@",self.txtFldSelect.text];
			//pdfCreate.reportedFor = [NSString stringWithFormat:@"Tenant Phone List"];
			fileName = @"/financeBybuilding.pdf";
			pdfCreate.reportedFrom = self.txtFldFrom.text;
			pdfCreate.reportedTo = self.txtFldTo.text;
			[pdfCreate createPDFWithFileName:fileName];
			//[email mailWithData:fileName];
			break;
			
		case TOTAL_FINANCE_BY_OWNER:
			pdfCreate.arrOfTag = [[NSMutableArray alloc] initWithObjects:@"month",@"income",
								  @"expense", @"total",nil];
			
			pdfCreate.arrayOfAttribute = [[NSMutableArray alloc] initWithObjects:@"MONTH",
										  @"INCOME",		
										  @"EXPENSE",										  
										  @"TOTAL",										  
										  nil];
			
			pdfCreate.reportTypesTag = reportTypesTag;
			pdfCreate.owner = [self.arrOfObjects objectAtIndex:selectedIndex];
			pdfCreate.noOfCol = 4;
			pdfCreate.reportedBy = @"Total Finance By Owner";
			//pdfCreate.reportedFor = [NSString stringWithFormat:@"Tenant Phone List"];
			fileName = @"/financeByOwner.pdf";
			pdfCreate.reportedFrom = self.txtFldFrom.text;
			pdfCreate.reportedTo = self.txtFldTo.text;
			[pdfCreate createPDFWithFileName:fileName];
			//[email mailWithData:fileName];
			break;
			
		case TENANT_PAYMENT_REPORT:
			
			pdfCreate.arrOfTag = [[NSMutableArray alloc] initWithObjects:@"last",@"first",
								  @"datePaid", @"amount",@"paymentFor", @"year",@"note",nil];
			
			pdfCreate.arrayOfAttribute = [[NSMutableArray alloc] initWithObjects:@"LAST NAME",
										  @"FIRST NAME",										  
										  @"DATEPAID",										  
										  @"AMOUNT PAID",										  
										  @"FORMONTH",										  
										  @"FORYEAR",
										  @"NOTES",nil];
			pdfCreate.reportTypesTag = reportTypesTag;
			pdfCreate.tenant = [self.arrOfObjects objectAtIndex:selectedIndex];
			pdfCreate.noOfCol = 7;
			pdfCreate.reportedBy = self.txtFldReport.text;
			pdfCreate.reportedFor = [NSString stringWithFormat:@"Report For Tenant %@",self.txtFldSelect.text];
			fileName = @"/TenantPaymentReport.pdf";
			pdfCreate.reportedFrom = self.txtFldFrom.text;
			pdfCreate.reportedTo = self.txtFldTo.text;
			[pdfCreate createPDFWithFileName:fileName];
			//[email mailWithData:fileName];
			break;
			
		case LATE_TENANT_REPORT:
			pdfCreate.arrOfTag = [[NSMutableArray alloc] initWithObjects:@"last",@"first",
								  @"address", @"home_phone",@"work_phone", @"mobile",@"rent_due",nil];
			
			
			pdfCreate.arrayOfAttribute = [[NSMutableArray alloc] initWithObjects:@"LAST NAME",
										  @"FIRST NAME",		
										  @"ADDRESS",										  
										  @"HOME PHONE",										  
										  @"WORK PHONE",										  
										  @"MOBILE PHONE",nil];
			
			pdfCreate.reportTypesTag = reportTypesTag;
			pdfCreate.tenant = [self.arrOfObjects objectAtIndex:selectedIndex];
			pdfCreate.noOfCol = 6;
			pdfCreate.reportedBy = @"Late Tenant Report";
			
			fileName = @"/LateTenantReport.pdf";
			
			[pdfCreate createPDFWithFileName:fileName];
			
			break;
			
		case TENANT_PHONE_LIST:
			pdfCreate.arrOfTag = [[NSMutableArray alloc] initWithObjects:@"last",@"first",
								  @"address", @"home_phone",@"work_phone", @"mobile",nil];
			
			pdfCreate.arrayOfAttribute = [[NSMutableArray alloc] initWithObjects:@"LAST NAME",
										  @"FIRST NAME",		
										  @"ADDRESS",										  
										  @"HOME PHONE",										  
										  @"WORK PHONE",										  
										  @"MOBILE PHONE", nil];
										 
			pdfCreate.reportTypesTag = reportTypesTag;
			pdfCreate.tenant = [self.arrOfObjects objectAtIndex:selectedIndex];
			pdfCreate.noOfCol = 6;
			pdfCreate.reportedBy = @"Tenant Phone List";
			//pdfCreate.reportedFor = [NSString stringWithFormat:@"Tenant Phone List"];
			fileName = @"/TenantPhoneList.pdf";
			pdfCreate.reportedFrom = self.txtFldFrom.text;
			pdfCreate.reportedTo = self.txtFldTo.text;
			[pdfCreate createPDFWithFileName:fileName];
			//[email mailWithData:fileName];
			break;		
		case RENT_ROLL:
			pdfCreate.arrOfTag = [[NSMutableArray alloc] initWithObjects:@"last",@"first",
								  @"datePaid", @"amount",@"paymentFor", @"year",@"note",nil];
			
			pdfCreate.arrayOfAttribute = [[NSMutableArray alloc] initWithObjects:@"LAST NAME",
										  @"FIRST NAME",										  
										  @"DATEPAID",										  
										  @"AMOUNT PAID",										  
										  @"FORMONTH",										  
										  @"FORYEAR",
										  @"NOTES",nil];
			pdfCreate.reportTypesTag = reportTypesTag;
			//pdfCreate.tenant = [self.arrOfObjects objectAtIndex:selectedIndex];
			pdfCreate.noOfCol = 7;
			pdfCreate.reportedBy = @"Rent Roll";
			//pdfCreate.reportedFor = [NSString stringWithFormat:@"Report For Tenant %@",self.txtFldSelect.text];
			fileName = @"/RentRoll.pdf";
			pdfCreate.reportedFrom = self.txtFldFrom.text;
			pdfCreate.reportedTo = self.txtFldTo.text;
			[pdfCreate createPDFWithFileName:fileName];
			//[email mailWithData:fileName];
			break;
	}
	
	PdfViewer *pdfViewer = [[PdfViewer alloc] init];
	pdfViewer.url = fileName;
	[self presentModalViewController:pdfViewer animated:YES];
	pdfViewer = nil;
}
-(void)cancelPickerView
{
	if(reportTag == REPORT)
	{
		[Utility hidesDropDown:self.pView];
		return ;
	}
	[Utility hidesDropDown:self.pView];
}


-(void)hidePickerView
{
	NSDateFormatter *formatter = nil;
	switch (reportTag) 
	{
		case FROM:
		case TO:
			formatter = [[NSDateFormatter alloc] init];
			[formatter setDateFormat:@"MM/dd/yyyy"];
			self.tempTextField.text = [formatter stringFromDate:self.datePicker.date];
			break;
			
		case REPORT:
			[self showLoadingView];
			self.txtFldSelect.text = @"";
			[self loadDataForSelection];
			break;
		case SELECT:
			break;
			
	}
	[Utility hidesDropDown:self.pView];
}
#pragma mark -
#pragma mark Picker View Delegate Method

// returns the number of 'columns' to display.
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
	return 1;
}

// returns the # of rows in each component..
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
	if([pickerView isEqual:self.selectPicker])
		return [self.arrOfSelect count];
	return [arrOfReportTypes count];
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
	if([pickerView isEqual:self.selectPicker])
	{
		if([self.arrOfSelect count] == 0) return nil;
		return [self.arrOfSelect objectAtIndex:row];
	}
	return [arrOfReportTypes objectAtIndex:row];
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
	
	if([pickerView isEqual:self.selectPicker])
	{
		if([self.arrOfSelect count] == 0) return ;
		self.txtFldSelect.text = [self.arrOfSelect objectAtIndex:row];
		selectedIndex = row;
		return ;
	}
	self.btnRunReport.enabled = YES;
	self.txtFldReport.text = [arrOfReportTypes objectAtIndex:row];
	reportTypesTag = row;
	NSString *text = @"";
	switch(row)
	{
		case 0:
		case 2:
		case 4:
			text = @"Select Building :";
			selectedTag = BUILDING_TAG;
			break;
		case 1:
		case 3:
		case 5:
			text = @"Select Owner :";
			selectedTag = OWNER_TAG;
			break;
		case 6:
			text = @"Select Tenant :";
			selectedTag = TENANT_TAG;
			break;
	}
	[self showSelectTextAndLabel:row WithLabel:text];
}

-(void)showSelectTextAndLabel:(NSInteger)rowNum WithLabel:(NSString *)labelText
{
	if(rowNum <= 6 )
	{
		self.txtFldSelect.alpha = 1.0;
		self.lblSelect.text = labelText;
	}
	else
	{
		self.txtFldSelect.alpha = 0.0;
		self.lblSelect.text = @"";
	}
}

-(void)loadDataForSelection
{
	self.arrOfSelect = nil;
	self.arrOfSelect = [[NSMutableArray alloc] init];
	switch (selectedTag) 
	{
		case BUILDING_TAG:
			[self loadAllDataForEntity:ENTITY_KEY_BUILDING];
			break;
		case OWNER_TAG:
			[self loadAllDataForEntity:ENTITY_KEY_OWNER];
			break;
		case TENANT_TAG:
			[self loadAllDataForEntity:ENTITY_KEY_TENANT];
			break;
	}
}

-(void)loadAllDataForEntity:(NSString *)entityName
{
	AppDelegate_iPhone *appDelegate = (AppDelegate_iPhone *)[[UIApplication sharedApplication] delegate];
	self.arrOfObjects = nil;
	self.arrOfObjects = [CoreDataHelper getObjectsFromContext:entityName :nil :NO :appDelegate.managedObjectContext];
	if(selectedTag == TENANT_TAG)
	{
        NSMutableArray *arr = [NSMutableArray arrayWithArray:self.arrOfObjects];
        [arr retain];
		for(Tenant *tenant in self.arrOfObjects)
		{
			if([tenant.moveOut boolValue])
			{
				[arr removeObject:tenant];
				continue;
			}
			NSString *str = tenant.first;
			if(tenant.last)
				str = [str stringByAppendingFormat:@" %@",tenant.last];
			[self.arrOfSelect addObject:str];
		}
        self.arrOfObjects = [arr mutableCopy];
        arr = nil;
	}
	else if(selectedTag == BUILDING_TAG)
	{
		for(Building *building in self.arrOfObjects)
		{
			NSString *str = building.address;
			[self.arrOfSelect addObject:str];
			str = nil;
		}
	}
	else if(selectedTag == OWNER_TAG)
	{
		for(Owner *owner in self.arrOfObjects)
		{
			NSString *str = owner.first;
			if(owner.last)
				str = [str stringByAppendingFormat:@" %@",owner.last];
			[self.arrOfSelect addObject:str];
			str = nil;
		}
	}
	[self hideLoadingView];
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
	if(textField.tag == FROM)
	{
		reportTag = FROM;		
		self.tempTextField = textField;
		[self.pView addSubview:self.datePicker];
		[Utility showDropDown:self.pView];
		return NO;
	}
	else if(textField.tag == TO)
	{
		reportTag = TO;
		self.tempTextField = textField;
		[self.pView addSubview:self.datePicker];
		[Utility showDropDown:self.pView];
		return NO;
	}
	else if(textField.tag == REPORT)
	{
		reportTag = REPORT;
		self.tempTextField = textField;
		[self.pView addSubview:self.pickerView];
		[self.pickerView selectRow:0 inComponent:0 animated:YES];
		
		[self pickerView:self.pickerView didSelectRow:0 inComponent:0];
		[Utility showDropDown:self.pView];
		return NO;
	}
	else if(textField.tag == SELECT)
	{
		reportTag = SELECT;
		[self.selectPicker reloadAllComponents];
		[self.pView addSubview:self.selectPicker];
		[self.selectPicker selectRow:0 inComponent:0 animated:YES];
		
		[self pickerView:self.selectPicker didSelectRow:0 inComponent:0];
		[Utility showDropDown:self.pView];
		return NO;
	}
	return YES;
}

// became first responder
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
	
}

// return YES to allow editing to stop and to resign first responder status. NO to disallow the editing session to end
- (BOOL)textFieldShouldEndEditing:(UITextField *)textField         
{
	
	return YES;
}

// may be called if forced even if shouldEndEditing returns NO (e.g. view removed from window) or endEditing:YES called
- (void)textFieldDidEndEditing:(UITextField *)textField             
{
	//[self.tempDict setObject:textField.text forKey:[NSString stringWithFormat:@"%d",textField.tag]];
	[textField resignFirstResponder];
}

// called when 'return' key pressed. return NO to ignore.
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
	[textField resignFirstResponder];
	return YES;
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    
	self.txtFldFrom = nil;
	self.txtFldTo = nil;
	self.txtFldReport = nil;
	self.datePicker = nil;
	self.reportPicker = nil;
	self.rightItem = nil;
	self.pView = nil;
	self.pickerView = nil;
	self.tempTextField = nil;
	self.txtFldSelect = nil;
	self.lblSelect = nil;
	self.arrOfSelect = nil;
	self.selectPicker = nil;
	self.btnRunReport = nil;
	
	[super viewDidUnload];
	// Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	
	self.txtFldFrom = nil;
	self.txtFldTo = nil;
	self.txtFldReport = nil;
	self.datePicker = nil;
	self.reportPicker = nil;
	self.rightItem = nil;
	self.pView = nil;
	self.pickerView = nil;
	self.tempTextField = nil;
	self.txtFldSelect = nil;
	self.lblSelect = nil;
	self.arrOfSelect = nil;
	self.selectPicker = nil;
	self.btnRunReport = nil;
	
    [super dealloc];
}


@end
