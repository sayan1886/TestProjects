//
//  RTPayementViewController.h
//  RentTracker
//
//  Created by ASHIM SAMANTA on 07/03/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Constant.h"


@interface RTPayementViewController : UIViewController 
{
	UITableView *rtPaymentTableView_;
	NSMutableArray *searchText_;
	
	NSMutableArray *array_;
	NSMutableDictionary *resultdict_;
	
	NSArray *arr_;
}
@property (nonatomic, retain) IBOutlet UITableView *rtPaymentTableView;
@property (nonatomic, retain) NSMutableArray *searchText;
@property (nonatomic, retain) NSMutableArray *array;
@property (nonatomic, retain) NSMutableDictionary *resultdict;
@property (nonatomic, retain) NSArray *arr;

@end
