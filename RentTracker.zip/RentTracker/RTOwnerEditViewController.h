//
//  RTOwnerEditViewController.h
//  RentTracker
//
//  Created by ASHIM SAMANTA on 06/03/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ImagePicker.h"
#import "Owner.h"
@interface RTOwnerEditViewController : UIViewController <UITableViewDelegate, UITableViewDataSource,
											UITextFieldDelegate, CaptureImage> 
{

	UITableView *rtOwnerEditTableView_;
	UIBarButtonItem *rightItem_;
	NSMutableDictionary *dict_;
	UIButton *btn;
	BOOL isReadOnly;
	Owner *owner_;
												
	UITextField *txtFld;
	
	UITextField *txtFldOwnerFirstName_;
	UITextField *txtFldOwnerLastName_;
	
	UITextField *tempTextField;
}

@property( nonatomic, retain) IBOutlet UITableView *rtOwnerEditTableView;
@property (nonatomic, retain) UIBarButtonItem *rightItem;
@property (nonatomic, retain) NSMutableDictionary *dict;
@property (nonatomic, retain) Owner *owner;
@property (nonatomic, retain) UITextField *txtFldOwnerFirstName;
@property (nonatomic, retain) UITextField *txtFldOwnerLastName;
@property (nonatomic, retain) UIButton *btn;
-(void)fetchManagedObject;
-(void)loadValues;

@end
