//
//  AppDelegate_iPad.h
//  RentTracker
//
//  Created by ASHIM SAMANTA on 28/02/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate_Shared.h"


@interface AppDelegate_iPad : AppDelegate_Shared 
{

}

@end

