//
//  RTBuildingEditViewController.m
//  RentTracker
//
//  Created by ASHIM SAMANTA on 29/02/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import "RTBuildingEditViewController.h"
#import "AppDelegate_iPhone.h"
#import "CustomCell.h"
#import "Constant.h"
#import "CoreDataHelper.h"
#import "Utility.h"
#import "Building.h"
#import "Owner.h"
#import "UIImage+TKCategory.h"

@implementation RTBuildingEditViewController
@synthesize rtBuildingEditTableView = rtBuildingEditTableView_;
@synthesize rightItem = rightItem_;
@synthesize dict = dict_;
@synthesize building = building_;
@synthesize array = array_;
@synthesize ownerArray = ownerArray_;
@synthesize btn;
// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
		self.rightItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem: UIBarButtonSystemItemEdit  target:self action:@selector(edit:)];
		self.navigationItem.rightBarButtonItem = self.rightItem;
		isReadOnly = YES;
    }
    return self;
}
#pragma mark -
#pragma mark edit
-(void)edit:(id)sender
{
	isReadOnly = NO;
	[self.rtBuildingEditTableView reloadData];
	
	UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem: UIBarButtonSystemItemDone  target:self action:@selector(done:)];
	[self.navigationItem setRightBarButtonItem:item animated:YES];
	[item release];item = nil;
	
	[self.navigationItem setHidesBackButton:YES animated:YES];
	item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem: UIBarButtonSystemItemCancel  target:self action:@selector(cancel:)];
	[self.navigationItem setLeftBarButtonItem:item animated:YES];
	[item release];item = nil;
}

#pragma mark -
#pragma mark done
-(void)done:(id)sender
{
	if([txtFld isFirstResponder])
		[txtFld resignFirstResponder];
	[Utility increaseHeightOfTableView:self.rtBuildingEditTableView];
	isReadOnly = YES;
	[self.rtBuildingEditTableView reloadData];
	
	AppDelegate_iPhone *appDelegate =  (AppDelegate_iPhone *)[[UIApplication sharedApplication] delegate];
	
	if(self.building && self.dict)
	{
		if ([self.dict objectForKey:KEY_IMAGE]) 
		{
			UIImage *img = [self.dict objectForKey:KEY_IMAGE];
			NSData *data = UIImagePNGRepresentation(img);
			self.building.image = data;
		}
		else
			self.building.image = nil;
		if([self.dict objectForKey:[NSString stringWithFormat:@"%d",BUILDING_OWNER]])
		{
			if(selectedIndex != NSNotFound)
				self.building.owner = [self.ownerArray objectAtIndex:selectedIndex];
		}
		else
		self.building.owner = nil;
		self.building.address = [self.dict objectForKey:[NSString stringWithFormat:@"%d",BUILDING_ADDRESS]];
		self.building.city = [self.dict objectForKey:[NSString stringWithFormat:@"%d",BUILDING_CITY]];
		self.building.state = [self.dict objectForKey:[NSString stringWithFormat:@"%d",BUILDING_STATE]];
		
		self.building.postal_code = [self.dict objectForKey:[NSString stringWithFormat:@"%d",BUILDING_POSTAL_CODE]];
		self.building.no_of_units = [self.dict objectForKey:[NSString stringWithFormat:@"%d",BUILDING_NO_OF_UNITS]];
		
		[appDelegate saveContext];
	}
	
	[self.navigationItem setRightBarButtonItem:self.rightItem animated:YES];
	[self.navigationItem setLeftBarButtonItem:nil animated:YES];
	[self.navigationItem setHidesBackButton:NO animated:YES];
	
	//modify to change.
}

#pragma mark -
#pragma mark cancel
-(void)cancel:(id)sender
{
	[Utility increaseHeightOfTableView:self.rtBuildingEditTableView];
	isReadOnly = YES;
	[txtFld resignFirstResponder];
	[self loadValues];
	[self.rtBuildingEditTableView reloadData];
	[self.navigationItem setRightBarButtonItem:self.rightItem animated:YES];
	[self.navigationItem setLeftBarButtonItem:nil animated:YES];
	[self.navigationItem setHidesBackButton:NO animated:YES];
	//mnodify to change.
}

#pragma mark -
#pragma mark tableViewDelegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return BUILDING_NO_OF_SECTION;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	switch (section) 
	{
		case 0:
			return 1;
		case 1:
			return 1;
		case 2:
			return 4;
	}
	return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return HEIGHT_FOR_ROW;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	CustomCell *cell = [[[CustomCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil ReadOnly:isReadOnly] autorelease];
	cell.textField.delegate = self;
	
	switch(indexPath.section)
	{
		case 0:
			[cell.label removeFromSuperview];
			self.btn = [UIButton buttonWithType:UIButtonTypeCustom];
			self.btn.frame = CGRectMake(5, 5, 34, 34);
			self.btn.enabled = !isReadOnly;
			if([self.dict valueForKey:KEY_IMAGE])
				[self.btn setImage:[self.dict valueForKey:KEY_IMAGE] forState:UIControlStateNormal];
			else
				[self.btn setImage:[UIImage imageNamed:HOUSE_ICON] forState:UIControlStateNormal];
			[self.btn addTarget:self action:@selector(takePicture:) forControlEvents:UIControlEventTouchUpInside];
			[cell.contentView addSubview:self.btn];
			//cell.label.text = @"Address :";
			cell.textField.placeholder = @"Address";
			cell.textField.tag = BUILDING_ADDRESS;
			cell.textField.text = [self.dict objectForKey:[NSString stringWithFormat:@"%d",cell.textField.tag]];
			return cell;
			
			return cell;
		case 1:					
			switch(indexPath.row)
		{
			case 0:
				cell.label.text = @"Owner :";
				cell.textField.placeholder = @"Owner";
				cell.textField.tag = BUILDING_OWNER;
				cell.textField.delegate = self;
				cell.textField.text = [self.dict objectForKey:[NSString stringWithFormat:@"%d",cell.textField.tag]];
				return cell;
		}
			
		case 2:
			switch(indexPath.row)
			{
			case 0:
					cell.label.text = @"No Of Units :";
					cell.textField.placeholder = @"No Of Units";
					cell.textField.tag = BUILDING_NO_OF_UNITS;
					cell.textField.keyboardType = UIKeyboardTypeNumberPad;
					NSNumber *num = [self.dict objectForKey:[NSString stringWithFormat:@"%d",cell.textField.tag]];
					cell.textField.text = [NSString stringWithFormat:@"%@",num];
					return cell;
			case 1:
				cell.label.text = @"City :";
				cell.textField.placeholder = @"City";
				cell.textField.tag = BUILDING_CITY;
				cell.textField.text = [self.dict objectForKey:[NSString stringWithFormat:@"%d",cell.textField.tag]];
				return cell;
			case 2:
				cell.label.text = @"State :";
				cell.textField.placeholder = @"State";
				cell.textField.autocapitalizationType = UITextAutocapitalizationTypeAllCharacters;
				cell.textField.tag = BUILDING_STATE;
				cell.textField.text = [self.dict objectForKey:[NSString stringWithFormat:@"%d",cell.textField.tag]];
				return cell;
			case 3:
				cell.label.text = @"Postal Code :";
				cell.textField.placeholder = @"Postal Code";
				cell.textField.tag = BUILDING_POSTAL_CODE;
				cell.textField.keyboardType = UIKeyboardTypePhonePad;
				cell.textField.text = [self.dict objectForKey:[NSString stringWithFormat:@"%d",cell.textField.tag]];
				return cell;
			}
	}
	return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	if(isReadOnly)
	{
		CustomCell *cell = (CustomCell *)[tableView cellForRowAtIndexPath:indexPath];
		NSString *str = nil;
		switch(cell.textField.tag)
		{
			case BUILDING_STATE:
			case BUILDING_CITY:
			case BUILDING_ADDRESS:
				str = @"";
				str = [self.dict valueForKey:[NSString stringWithFormat:@"%d",BUILDING_ADDRESS]];
				str = [str stringByAppendingFormat:@" %@",[self.dict valueForKey:[NSString stringWithFormat:@"%d",BUILDING_CITY]]];
				str = [str stringByAppendingFormat:@" %@",[self.dict valueForKey:[NSString stringWithFormat:@"%d",BUILDING_STATE]]];
				str = [str stringByReplacingOccurrencesOfString:@" " withString:@"+"];
			    [Utility launchMapWithAddress:str];
				return ;
		}
	}
}
-(void)takePicture:(id)sender
{
	self.btn = (UIButton *)sender;
	ImagePicker *picker = [[ImagePicker alloc] init] ;
	picker.delegate = self;
	picker.vc = self;
	[picker clickAddPictureAtViewController:[self.btn superview]];
}

-(void) didReceivePicture:(UIImage *)img
{
	img = [img fixOrientation];
	[self.dict setObject:img forKey:KEY_IMAGE];
	[self.btn setImage:img forState:UIControlStateNormal];
}

// returns the number of 'columns' to display.
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
	return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
	return [self.array count];
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
	return [self.array objectAtIndex:row];
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
	tempTextField.text = [self.array objectAtIndex:row];
	selectedIndex = row;
}

-(void)hidePickerView
{
	[Utility increaseHeightOfTableView:self.rtBuildingEditTableView];	isPickerVisible = NO;
	tempTextField.userInteractionEnabled = YES;
	if(tempTextField.text)
	[self.dict setObject:tempTextField.text forKey:[NSString stringWithFormat:@"%d",BUILDING]];
	[Utility hidesDropDown:pView];
}
-(void)cancelPickerView
{
	[Utility increaseHeightOfTableView:self.rtBuildingEditTableView];
	//tempTextField.text = @"";
	tempTextField.userInteractionEnabled = YES;
	isPickerVisible = NO;
	[Utility hidesDropDown:pView];
}
#pragma mark -
#pragma mark TextField Delegate Method

// return NO to disallow editing.
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
	if(isPickerVisible)
	{
		tempTextField.userInteractionEnabled = YES;
		[self hidePickerView];
	}
	if(textField.tag == BUILDING_OWNER)
	{
		if([txtFld isFirstResponder])
			[txtFld resignFirstResponder];
		if([self.array count])
		{
			tempTextField = textField;
			isPickerVisible = YES;
			tempTextField.text = [self.array objectAtIndex:0];
			selectedIndex = 0;
			
			[Utility showDropDown:pView];
		}
		else
		{
			[Utility showAlertViewWithTitle:TITLE Message:MESSAGE_NO_OWNER CancelTitle:@"Ok"];
			return NO;
		}
		return NO;
	}
	
	[Utility decreaseHeightOfTableView:self.rtBuildingEditTableView];
	txtFld = textField;

	return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
	if((textField.tag == BUILDING_NO_OF_UNITS) || (textField.tag == BUILDING_POSTAL_CODE))
	{
		NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:VALID_INTEGER] invertedSet];
		NSString *filtered = [[string componentsSeparatedByCharactersInSet:cs] componentsJoinedByString:@""];
		return [string isEqualToString:filtered];
	}
	return YES;
}

// became first responder
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
	
}

// return YES to allow editing to stop and to resign first responder status. NO to disallow the editing session to end
- (BOOL)textFieldShouldEndEditing:(UITextField *)textField         
{
	
	return YES;
}

// may be called if forced even if shouldEndEditing returns NO (e.g. view removed from window) or endEditing:YES called
- (void)textFieldDidEndEditing:(UITextField *)textField             
{
	
	[self.dict setObject:textField.text forKey:[NSString stringWithFormat:@"%d",textField.tag]];
	[textField resignFirstResponder];
}

// called when clear button pressed. return NO to ignore (no notifications)
- (BOOL)textFieldShouldClear:(UITextField *)textField
{
	return YES;
}

// called when 'return' key pressed. return NO to ignore.
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
	[textField resignFirstResponder];
	
	[Utility increaseHeightOfTableView:self.rtBuildingEditTableView];
	
	return YES;
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	isPickerVisible = NO;
	selectedIndex = NSNotFound;
	CGRect frame;	
	self.dict = [[NSMutableDictionary alloc] init];
	
	if(ISIPHONE)
		frame = CGRectMake(0, 460, 320, 480);
	else
		frame = CGRectMake(0, 1024, 768, 1024);
	frame.origin.y-=45;
	frame.size.height+=45;
	
	pView = [[UIView alloc] initWithFrame:frame];
	pView.backgroundColor = [UIColor clearColor];
	
	if(ISIPHONE)
		frame = CGRectMake(0, 199, 320, 45);
	else
		frame = CGRectMake(0, 723, 768, 65);
	
	NSMutableArray *arr = [[NSMutableArray alloc] init];
	
	UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(cancelPickerView)];
	[arr addObject:item];
	[item release]; item = nil;
	
	item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
	[arr addObject:item];
	[item release]; item = nil;
	
	item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(hidePickerView)];
	[arr addObject:item];
	[item release]; item = nil;
	
	UIToolbar *toolBar = [[UIToolbar alloc] initWithFrame:frame];
	[toolBar setItems:arr animated:YES];
	
	if(ISIPHONE)
		frame = CGRectMake(0, 244, 320, 216);
	else
		frame = CGRectMake(0, 788, 768, 216);
	
	pickerView = [[UIPickerView alloc] initWithFrame:frame];
	pickerView.showsSelectionIndicator = YES;
	pickerView.delegate = self;
	pickerView.dataSource = self;
	
	
	[pView addSubview:toolBar];
	[pView addSubview:pickerView];
	[self.view addSubview:pView];
	[self fetchData];
	
	[toolBar release];
	[arr release];
}

-(void)fetchData
{
	AppDelegate_iPhone *app = (AppDelegate_iPhone *)[[UIApplication sharedApplication]delegate];
	
	self.ownerArray = [CoreDataHelper getObjectsFromContext:ENTITY_KEY_OWNER :@"first" :YES :app.managedObjectContext];
	
	self.array = [[NSMutableArray alloc] init];
	
	for(Owner *owner in self.ownerArray)
	{
		NSString *text = nil;
		if(owner.first)
		text = owner.first;
		if(owner.last)
		text = [text stringByAppendingFormat:@" %@",owner.last];
		if(text)
		[self.array addObject:text];
	}
	if([self.array count])
	[pickerView reloadAllComponents];
}

-(void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	[Utility increaseHeightOfTableView:self.rtBuildingEditTableView];
	[self fetchManagedObject];
	[self loadValues];
}

-(void)fetchManagedObject
{
	AppDelegate_iPhone *app = (AppDelegate_iPhone *)[[UIApplication sharedApplication] delegate];
	NSPredicate *predicate = [NSPredicate predicateWithFormat:@"self == %@",self.building];
	NSMutableArray *arr = [CoreDataHelper searchObjectsInContext:ENTITY_KEY_BUILDING :predicate :nil :NO :app.managedObjectContext];
	self.building = [arr objectAtIndex:0];
}

-(void)loadValues
{	
	if(self.building.owner && self.building.owner.first && self.building.owner.last)
	{
		NSString *text = [self.building.owner.first stringByAppendingFormat:@" %@", self.building.owner.last];
		[self.dict setValue:text forKey:[NSString stringWithFormat:@"%d",BUILDING_OWNER]];
	}
	if(self.building.address)
		[self.dict setValue:self.building.address forKey:[NSString stringWithFormat:@"%d",BUILDING_ADDRESS]];
	if(self.building.city)
		[self.dict setValue:self.building.city forKey:[NSString stringWithFormat:@"%d",BUILDING_CITY]];
	if(self.building.state)
		[self.dict setValue:self.building.state forKey:[NSString stringWithFormat:@"%d",BUILDING_STATE]];
	if(self.building.postal_code)
		[self.dict setValue:self.building.postal_code forKey:[NSString stringWithFormat:@"%d",BUILDING_POSTAL_CODE]];
	if(self.building.no_of_units)
	[self.dict setValue:self.building.no_of_units forKey:[NSString stringWithFormat:@"%d",BUILDING_NO_OF_UNITS]];
	if(self.building.image)
	{
		UIImage *img = [UIImage imageWithData:self.building.image];
		img = [img fixOrientation];
		[self.dict setObject:img forKey:KEY_IMAGE];	
	}
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
	
	self.rtBuildingEditTableView = nil;
	self.rightItem = nil;
	self.dict = nil;
	
 	self.array = nil;
	self.ownerArray = nil;
	
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	
	self.rtBuildingEditTableView = nil;
	self.rightItem = nil;
	self.dict = nil;
	
 	self.array = nil;
	 self.ownerArray = nil;
	
    [super dealloc];
}


@end
