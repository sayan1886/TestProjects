//
//  AppDelegate_iPhone.m
//  RentTracker
//
//  Created by ASHIM SAMANTA on 28/02/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import "AppDelegate_iPhone.h"
#import "Constant.h"
#import "Contractor.h"
#import "Utility.h"
#import <StoreKit/StoreKit.h>
#import "TestIAPHelper.h"
#import "Appirater.h"

@implementation AppDelegate_iPhone

#pragma mark -
#pragma mark Application lifecycle

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {    
    
    [Appirater appLaunched:YES];
    // Override point for customization after application launch.
	
    [[SKPaymentQueue defaultQueue] addTransactionObserver:[TestIAPHelper sharedHelper]];
    
    NSUserDefaults *standardDefaults = [NSUserDefaults standardUserDefaults];
    NSInteger totalNoOfTenantPurchased = [standardDefaults integerForKey:PURCHASED_TENANT];
    
    if(totalNoOfTenantPurchased == 0)
    {
        totalNoOfTenantPurchased = 3;
        [standardDefaults setInteger:totalNoOfTenantPurchased forKey:PURCHASED_TENANT];
        [standardDefaults synchronize];
        standardDefaults = nil;
    }
    
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(deletedObject:) name:NSManagedObjectContextObjectsDidChangeNotification object:nil];
	RTHomeViewController *viewController_ = [[RTHomeViewController alloc] initWithNibName:@"RTHomeViewController" bundle:nil];
	
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:viewController_] ;
	[self.window addSubview:nav.view];
	[viewController_ release];viewController_ = nil;
    [self.window makeKeyAndVisible];
    
    return YES;
}


- (void)applicationWillResignActive:(UIApplication *)application {
	[[NSNotificationCenter defaultCenter] removeObserver:self name:NSManagedObjectContextObjectsDidChangeNotification object:nil];
    /*
     Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
     Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
     */
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    /*
     Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
     If your application supports background execution, called instead of applicationWillTerminate: when the user quits.

     Superclass implementation saves changes in the application's managed object context before the application terminates.
     */
	[[NSNotificationCenter defaultCenter] removeObserver:self name:NSManagedObjectContextObjectsDidChangeNotification object:nil];
	[super applicationDidEnterBackground:application];
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    [Appirater appEnteredForeground:YES];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(deletedObject:) name:NSManagedObjectContextObjectsDidChangeNotification object:nil];
    /*
     Called as part of the transition from the background to the inactive state: here you can undo many of the changes made on entering the background.
     */
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(deletedObject:) name:NSManagedObjectContextObjectsDidChangeNotification object:nil];
    /*
     Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
     */
}


/**
 Superclass implementation saves changes in the application's managed object context before the application terminates.
 */
- (void)applicationWillTerminate:(UIApplication *)application {
	[[NSNotificationCenter defaultCenter] removeObserver:self name:NSManagedObjectContextObjectsDidChangeNotification object:nil];
	[super applicationWillTerminate:application];
}


#pragma mark -
#pragma mark Memory management

- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application {
    /*
     Free up as much memory as possible by purging cached data objects that can be recreated (or reloaded from disk) later.
     */
    [super applicationDidReceiveMemoryWarning:application];
}

#pragma mark -
#pragma mark deletedObject

-(void)deletedObject:(NSNotification *)notif
{
	NSDictionary *notifDict = [notif userInfo];
	
	NSSet *deletedObjectset = [notifDict objectForKey:NSDeletedObjectsKey];
	
	NSArray *arrOfDeltedObject = [deletedObjectset allObjects];
	
	for(id object in arrOfDeltedObject)
	{
		if([object isKindOfClass:[Contractor class]])
		{
			[Utility didFindContractor:object];
		}
		else if([object isKindOfClass:[Owner class]])
		{
			[Utility didFindOwner:object];
		}
		else if([object isKindOfClass:[Building class]])
		{
			[Utility didFindBuilding:object];
		}
	}
	
	notifDict = nil;
	deletedObjectset = nil;
	arrOfDeltedObject = nil;
}

#pragma mark iAd


- (void)dealloc {
	
    
	[super dealloc];
}


@end

