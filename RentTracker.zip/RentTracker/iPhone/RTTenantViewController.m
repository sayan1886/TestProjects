//
//  RTTenantViewController.m
//  RentTracker
//
//  Created by ASHIM SAMANTA on 28/02/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import "RTTenantViewController.h"
#import "Constant.h"
#import "RTTenantAddViewController.h"
#import "RTTenantEditViewController.h"
#import "CoreDataHelper.h"
#import "Utility.h"
#import "AppDelegate_iPhone.h"
#import "Tenant.h"
#import "TestInAppPurchaseViewController.h"

@implementation RTTenantViewController

@synthesize rttableView = rttableView_;
@synthesize searchText = searchText_;
@synthesize segmentController = segmentController_;
@synthesize array = array_;
@synthesize resultdict = resultdict_;
@synthesize arr = arr_;

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"Tenant";
		UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(add:)];
		self.navigationItem.rightBarButtonItem = item;
		[item release];
    }
    return self;
}

#pragma mark -
#pragma mark Segment Changed
-(IBAction)segmentValueChanged:(id)sender
{
	UISegmentedControl *segment = (UISegmentedControl *)sender;
	
	if(segment.selectedSegmentIndex == 0)
		[self getCurrentValueFromContext];
	else
		[self getPastValueFromContext];
	[self.rttableView reloadData];
}

-(void)add:(id)sender
{
    NSUserDefaults *standardDefaults = [NSUserDefaults standardUserDefaults];
    NSInteger totalNoOfTenantPurchased = [standardDefaults integerForKey:PURCHASED_TENANT];
    NSInteger numberOfTenantAdded = [standardDefaults integerForKey:TOTAL_ADDED_TENANT];
    
    if(numberOfTenantAdded < totalNoOfTenantPurchased)
    {
        AppDelegate_iPhone *app = (AppDelegate_iPhone *)[[UIApplication sharedApplication]delegate];
        NSMutableArray *arrResult = [CoreDataHelper getObjectsFromContext:ENTITY_KEY_BUILDING :nil :NO :app.managedObjectContext];
        if(!arrResult || [arrResult count] == 0)
        {
            [Utility showAlertViewWithTitle:TITLE Message:MESSAGE_NO_BUILDING CancelTitle:@"Ok"];
            return ;
        }
        RTTenantAddViewController *viewController = nil;
        if(ISIPHONE)
            viewController = [[RTTenantAddViewController alloc] initWithNibName:@"RTTenantAddViewController" bundle:nil];
        else
            viewController = [[RTTenantAddViewController alloc] initWithNibName:@"RTTenantAdd_iPad" bundle:nil];
        [self.navigationController pushViewController:viewController animated:YES];
        [viewController release];
    }
    else
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:TITLE_NEED_INAPP_PURCHASE message:MESSAGE_NEED_INAPP_PURCHASE delegate:self cancelButtonTitle:INAPP_PURCHASE_CANCEL_TITLE otherButtonTitles:nil];
        [alertView addButtonWithTitle:INAPP_PURCHASE_OK_TITLE];
        [alertView show];
        alertView = nil;
    }
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    [alertView dismissWithClickedButtonIndex:buttonIndex animated:YES];
    if(buttonIndex == 0)
        NSLog(@"Cancel");
    else
    {
        TestInAppPurchaseViewController *vc = [[TestInAppPurchaseViewController alloc] init];
        [self.navigationController pushViewController:vc animated:YES];
    }
}

#pragma mark -
#pragma mark TableView delegate method

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
	return HEIGHT_FOR_HEADER;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
	if(![tableView isEqual:self.rttableView]) return nil;
	
	UIView *header = [[[UIView alloc]initWithFrame:CONTACT_HEADER_FRAME] autorelease];
	header.backgroundColor = [UIColor colorWithPatternImage:[[UIImage imageNamed:CONTACT_HEADER_IMAGE] stretchableImageWithLeftCapWidth:0 topCapHeight:32]];
	
	UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, 6, 20, 20)];
	
	if([tableView isEqual:self.rttableView])
	{
		label.text = [self.arr objectAtIndex:section];
	}
	
	label.backgroundColor = [UIColor clearColor];
	label.textColor = [UIColor whiteColor];
	
	[header addSubview:label];
	
	[label release];
	return header;
}

// return list of section titles to display in section index view (e.g. "ABCD...Z#")
-(NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView
{
	if(![tableView isEqual:self.rttableView]) return nil;
	NSMutableArray *toBeReturned = [[NSMutableArray alloc]init];
    for(char c = 'A'; c <= 'Z'; c++) [toBeReturned addObject:[NSString stringWithFormat:@"%c",c]];
    return [toBeReturned autorelease];
}

// tell table which section corresponds to section title/index (e.g. "B",1))

-(NSInteger)tableView:(UITableView *)tableView sectionForSectionIndexTitle:(NSString *)title atIndex:(NSInteger)index
{
	NSLog(@"index = %d", index);
	return index;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	if([tableView isEqual:self.rttableView])
	{
		NSArray *arrRes = [self.resultdict objectForKey:[self.arr objectAtIndex:section]];
		return [arrRes count];
	}
	return [self.searchText count];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	if([tableView isEqual:self.rttableView])
	{
		return [self.arr count];
	}
	return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	static NSString *cellID = @"cellID";
	NSString *text = @"";
	if([tableView isEqual:self.rttableView]) 
	{
		NSString *val = [self.arr objectAtIndex:indexPath.section];
		NSArray *arrTemp = [self.resultdict objectForKey:val];
		Tenant *tenant = [arrTemp objectAtIndex:indexPath.row];
		text = tenant.first;
		text = [text stringByAppendingString:@" "];
		if(tenant.last)
		text = [text stringByAppendingString:tenant.last];
		arrTemp = nil;
	}
	else 
	{
		text = [[self.searchText objectAtIndex:indexPath.row] valueForKey:@"first"];
		if([[self.searchText objectAtIndex:indexPath.row] valueForKey:@"last"])
		text = [text stringByAppendingFormat:@" %@",[[self.searchText objectAtIndex:indexPath.row] valueForKey:@"last"]];
	}	
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID] ;
	if(!cell)
	{
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID] autorelease];
		cell.textLabel.text = text;
	}
	else
		cell.textLabel.text = text;
	return cell ;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
	AppDelegate_iPhone *app = (AppDelegate_iPhone *)[[UIApplication sharedApplication] delegate];
	NSMutableArray *arrTodel = [self.resultdict allKeys];
	NSString *val = [arrTodel objectAtIndex:indexPath.section];
	arrTodel = [self.resultdict objectForKey:val];
	Tenant *tenant = [arrTodel objectAtIndex:indexPath.row];
	[app.managedObjectContext deleteObject:tenant];
	[app saveContext];
	[Utility updateRemainingTenant];
	if(self.segmentController.selectedSegmentIndex == 0)
		[self getCurrentValueFromContext];
	else
		[self getPastValueFromContext];
	
	[tableView reloadData];
}
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
	return YES;
}
- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return UITableViewCellEditingStyleDelete;	
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	Tenant *tenant = nil;
	if([tableView isEqual:self.rttableView])
	{
		NSString *val = [self.arr objectAtIndex:indexPath.section];
		NSArray *tempArr = [self.resultdict objectForKey:val];
		tenant = [tempArr objectAtIndex:indexPath.row];
		tempArr = nil;
	}
	else 
	{
		tenant = [self.searchText objectAtIndex:indexPath.row];
	}
	
	RTTenantEditViewController *viewController = nil;
	if(ISIPHONE)
		viewController = [[RTTenantEditViewController alloc] initWithNibName:@"RTTenantEditViewController" bundle:nil];
	else
		viewController = [[RTTenantEditViewController alloc] initWithNibName:@"RTTenantEdit_iPad" bundle:nil];
	viewController.tenant = tenant;
	[self.navigationController pushViewController:viewController animated:YES];
	[viewController release];viewController = nil;
}

#pragma mark -
#pragma mark SEARCH

-(BOOL)searchDisplayController:(UISearchDisplayController *)controller shouldReloadTableForSearchString:(NSString *)searchString
{   
    [self.searchText removeAllObjects];
    
    for (Tenant *tenant in self.array)
    {
		NSString *aStr = tenant.first;
		aStr = [aStr stringByAppendingFormat:@" %@",tenant.last]; 
		aStr = [aStr lowercaseString];
		if ([aStr rangeOfString:[searchString lowercaseString]].location != NSNotFound)
            [self.searchText addObject:tenant];
    }
	
    [controller.searchResultsTableView reloadData];
    return NO;
}

-(void)searchDisplayControllerWillBeginSearch:(UISearchDisplayController *)controller
{
    self.rttableView.hidden = YES;
	self.segmentController.userInteractionEnabled = NO;
}

-(void)searchDisplayControllerDidEndSearch:(UISearchDisplayController *)controller
{
    self.rttableView.hidden = NO;
	self.segmentController.userInteractionEnabled = YES;
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
-(void)viewDidLoad {
    [super viewDidLoad];
	
	self.searchText = [[NSMutableArray alloc] init];
	self.array = [[NSMutableArray alloc] init];
	self.resultdict = [[NSMutableDictionary alloc] init];
	self.arr = [[NSMutableArray alloc] init];
}

-(void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	if(self.segmentController.selectedSegmentIndex == 0)
		[self getCurrentValueFromContext];
	else
		[self getPastValueFromContext];
	[self.rttableView reloadData];
}

-(void)getCurrentValueFromContext
{
	AppDelegate_iPhone *app = (AppDelegate_iPhone *)[[UIApplication sharedApplication]delegate];	
	self.array = [CoreDataHelper getObjectsFromContext:ENTITY_KEY_TENANT :@"first" :YES :app.managedObjectContext];
	NSMutableArray *tempArr = [[NSMutableArray alloc] init];
	for(Tenant *tenant in self.array)
	{
		if(![tenant.moveOut boolValue])
			[tempArr addObject:tenant];
	}
	self.array = tempArr;
	self.resultdict = [Utility arrangeList:self.array sortKey:@"first"];
	self.arr = [self.resultdict allKeys];
	self.arr = [self.arr sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
}

-(void)getPastValueFromContext
{
	AppDelegate_iPhone *app = (AppDelegate_iPhone *)[[UIApplication sharedApplication]delegate];	
	self.array = [CoreDataHelper getObjectsFromContext:ENTITY_KEY_TENANT :@"first" :YES :app.managedObjectContext];
	NSMutableArray *tempArr = [[NSMutableArray alloc] init];
	for(Tenant *tenant in self.array)
	{
		if([tenant.moveOut boolValue])
			[tempArr addObject:tenant];
	}
	self.array = tempArr;
	self.resultdict = [Utility arrangeList:self.array sortKey:@"first"];
	self.arr = [self.resultdict allKeys];
	self.arr = [self.arr sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

-(void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
	
	self.rttableView = nil ;
	self.segmentController = nil;
	self.searchText = nil;
	
	self.array = nil;
	self.resultdict = nil;
	
	self.arr = nil;
	
    [super viewDidUnload];
	
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	
	rttableView_ = nil;
	segmentController_ = nil;
	searchText_ = nil;
	
	array_ = nil;
	resultdict_ = nil;
	
	arr_ = nil;
	
    [super dealloc];
}


@end
