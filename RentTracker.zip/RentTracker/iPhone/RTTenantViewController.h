//
//  RTTenantViewController.h
//  RentTracker
//
//  Created by ASHIM SAMANTA on 28/02/12.
//  Copyright 2012 ObjectSol Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface RTTenantViewController : UIViewController<UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate> {

	UITableView *rttableView_;
	NSMutableArray *searchText_;
	UISegmentedControl *segmentController_;
	
	NSMutableArray *array_;
	NSMutableDictionary *resultdict_;
	
	NSArray *arr_;
}

@property (nonatomic, retain) IBOutlet UITableView *rttableView;
@property (nonatomic, retain) IBOutlet UISegmentedControl *segmentController;
@property (nonatomic, retain) NSMutableArray *searchText;

@property (nonatomic, retain) NSMutableArray *array;
@property (nonatomic, retain) NSMutableDictionary *resultdict;

@property (nonatomic, retain) NSArray *arr;

-(IBAction)segmentValueChanged:(id)sender;
-(void)add:(id)sender;
-(void)getCurrentValueFromContext;
-(void)getPastValueFromContext;
@end
