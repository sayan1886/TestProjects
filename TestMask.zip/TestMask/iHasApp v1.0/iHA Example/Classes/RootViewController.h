//
//  RootViewController.h
//  iHA Example
//
//  Created by Daniel Amitay on 2/16/11.
//  Copyright 2011 Daniel Amitay. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "iHasApp.h"

@interface RootViewController : UITableViewController<iHasAppDelegate> {
	NSMutableArray *appsArray;
	iHasApp *appObject;
}
@property (nonatomic, retain) NSMutableArray *appsArray;
@property (nonatomic, retain) iHasApp *appObject;

@end
