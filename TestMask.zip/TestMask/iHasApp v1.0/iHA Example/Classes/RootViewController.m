//
//  RootViewController.m
//  iHA Example
//
//  Created by Daniel Amitay on 2/16/11.
//  Copyright 2011 Daniel Amitay. All rights reserved.
//

#import "RootViewController.h"
#import "iHasApp.h"


@implementation RootViewController
@synthesize appsArray;
@synthesize appObject;

#pragma mark -
#pragma mark View lifecycle


- (void)viewDidLoad {
    [super viewDidLoad];

	self.title = @"iHasApp Example";
	self.tableView.rowHeight = 57.0f;
	
	appsArray = [[NSMutableArray alloc] init];
	
	appObject = [[iHasApp alloc] init];
	appObject.delegate = self;
	if([appObject schemesLoaded]){
		NSLog(@"findApps");
		[appObject findApps];
	} else {
		NSLog(@"loadSchemes");
		[appObject loadSchemes];
	}
	
}




// App search callback
- (void) appSearchSuccess:(NSArray *)appList{
	NSLog(@"appList = %@", appList);
	[appsArray removeAllObjects];
	[appsArray addObjectsFromArray:appList];
	[self.tableView reloadData];
}

// Scheme load callback
- (void) appSchemesSuccess{
	NSLog(@"appSchemesSuccess");
	[appObject findApps];
}

// Connectivity fail callback
- (void) loadFailure:(NSError *)error{
	NSLog(@"loadFailure");
}


#pragma mark -
#pragma mark Table view data source

// Customize the number of sections in the table view.
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}


// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return appsArray.count;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
	if(appsArray.count != 0){
		return [NSString stringWithFormat:@"%i Apps Detected",appsArray.count];
	} else {
	return @"";	
	}	
}




// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier] autorelease];
    }
    
	// Configure the cell.
	
	
	cell.textLabel.text = [[appsArray objectAtIndex:indexPath.row] objectForKey:@"APP_NAME"];
	cell.detailTextLabel.text = [[appsArray objectAtIndex:indexPath.row] objectForKey:@"APP_ID"];
	
	
	
	
	
	
	//The following code handles the asynchronous loading and storage of the images
	//Irrelevant to the functionality of the iHasApp API
	
	NSString *imgurlString = [[appsArray objectAtIndex:indexPath.row] objectForKey:@"ICON_IMAGE"];
	NSString *escapedString = [imgurlString stringByReplacingOccurrencesOfString:@"." withString:@""];
	escapedString = [escapedString stringByReplacingOccurrencesOfString:@"/" withString:@""];
	
	NSString  *jpgPath = [NSHomeDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"Documents/thumb-%@", escapedString]];
	NSData *imageData = [[[NSData alloc] initWithContentsOfFile:jpgPath] autorelease];
	
	if(imageData){
		UIImage *currentImage = [UIImage imageWithData:imageData];
		cell.imageView.image = currentImage;
	} else {
		
		cell.imageView.image = [UIImage imageNamed:@"placeholder-icon.png"];
		NSString *indexRow = [NSString stringWithFormat:@"%i", indexPath.row];
		NSArray *array = [NSArray arrayWithObjects:[[appsArray objectAtIndex:indexPath.row] objectForKey:@"ICON_IMAGE"], cell, indexRow, nil];
		[self performSelectorInBackground:@selector(LoadImage:) withObject:array];
		
	}
	
	
	
	
	
    return cell;
}






- (void)LoadImage:(NSArray*)array {
	
	//The following code handles the asynchronous loading and storage of the images
	//Irrelevant to the functionality of the iHasApp API
	
	
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	
	UIImage *currentImage = nil;
	NSData *imageData = [NSData dataWithContentsOfURL:[NSURL URLWithString:[array objectAtIndex:0]]];
	
	NSString *imgurlString = [array objectAtIndex:0];
	NSString *escapedString = [imgurlString stringByReplacingOccurrencesOfString:@"." withString:@""];
	escapedString = [escapedString stringByReplacingOccurrencesOfString:@"/" withString:@""];
		
	NSString  *jpgPath2 = [NSHomeDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"Documents/thumb-%@", escapedString]];
	[imageData writeToFile:jpgPath2 atomically:YES];
	
	NSArray *indexes = [self.tableView indexPathsForVisibleRows];
	if([indexes containsObject:[NSIndexPath indexPathForRow:[[array objectAtIndex:2] intValue] inSection:0]]){
		
		UITableViewCell *cell = [array objectAtIndex:1];
		UIImage *img = [UIImage imageWithData:imageData];
		cell.imageView.image = img;
		
	}
	
	[pool release];
	
}






#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
}


#pragma mark -
#pragma mark Memory management

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Relinquish ownership any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    // Relinquish ownership of anything that can be recreated in viewDidLoad or on demand.
    // For example: self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end

