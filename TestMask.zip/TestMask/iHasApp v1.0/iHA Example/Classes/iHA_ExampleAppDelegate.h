//
//  iHA_ExampleAppDelegate.h
//  iHA Example
//
//  Created by Daniel Amitay on 2/16/11.
//  Copyright 2011 Daniel Amitay. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface iHA_ExampleAppDelegate : NSObject <UIApplicationDelegate> {
    
    UIWindow *window;
    UINavigationController *navigationController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet UINavigationController *navigationController;

@end

