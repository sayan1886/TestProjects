//
//  main.m
//  iHA Example
//
//  Created by Daniel Amitay on 2/16/11.
//  Copyright 2011 Daniel Amitay. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
