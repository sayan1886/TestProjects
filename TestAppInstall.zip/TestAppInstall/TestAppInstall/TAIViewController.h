//
//  TAIViewController.h
//  TestAppInstall
//
//  Created by Sayan on 27/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FilteredAppListTableView.h"

@interface TAIViewController : UIViewController<FilteredAppListDelegate>

@end
