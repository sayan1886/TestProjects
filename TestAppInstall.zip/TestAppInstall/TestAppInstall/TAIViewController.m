//
//  TAIViewController.m
//  TestAppInstall
//
//  Created by Sayan on 27/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "TAIViewController.h"
#import "FilteredAppListCell.h"
#import <mach/mach.h>
#import <objc/runtime.h>

@interface TAIViewController ()

@end

@implementation TAIViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    FilteredAppListTableView *list = [[FilteredAppListTableView alloc] initForContentSize:CGSizeMake(320, 480) delegate:self filteredAppType:FilteredAppAll enableForce:YES];
    [self.view addSubview:[list view]];
    
    static char overviewKey;
    
    NSArray *array =
    [[NSArray alloc] initWithObjects:@"One", @"Two", @"Three", nil];
    // For the purposes of illustration, use initWithFormat: to ensure
    // the string can be deallocated
    NSString *overview =
    [[NSString alloc] initWithFormat:@"%@", @"First three numbers"];
    
    objc_setAssociatedObject (
                              array,
                              &overviewKey,
                              overview,
                              OBJC_ASSOCIATION_RETAIN
                              );
    
    [overview release];
    // (1) overview valid
    NSLog(@"ARRAY : %@",array);
    [array release];
    // (2) overview invalid
    
    //memoryInBytes/1048576;
    [list loadFilteredList];
    print_free_memory();
    report_memory();
    report_memory_enhanced();
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (FilteredListType)filteredListTypeForIdentifier:(NSString *)identifier{
    return FilteredListNone;
}
- (void)didSelectRowAtCell:(FilteredAppListCell *)cell{
    //cell.
}
/*
- (BOOL)isOtherFilteredForIdentifier:(NSString *)identifier{
    
}
 */

#pragma mark - Memory 

static void print_free_memory () {
    mach_port_t host_port;
    mach_msg_type_number_t host_size;
    vm_size_t pagesize;
    
    host_port = mach_host_self();
    host_size = sizeof(vm_statistics_data_t) / sizeof(integer_t);
    host_page_size(host_port, &pagesize);        
    
    vm_statistics_data_t vm_stat;
    
    if (host_statistics(host_port, HOST_VM_INFO, (host_info_t)&vm_stat, &host_size) != KERN_SUCCESS)
        NSLog(@"Failed to fetch vm statistics");
    
    /* Stats in bytes */ 
    natural_t mem_used = (vm_stat.active_count +
                          vm_stat.inactive_count +
                          vm_stat.wire_count) * pagesize;
    natural_t mem_free = vm_stat.free_count * pagesize;
    natural_t mem_total = mem_used + mem_free;
    NSLog(@"used: %u free: %u total: %u", mem_used, mem_free, mem_total);
}

void report_memory(void) {
    struct task_basic_info info;
    mach_msg_type_number_t size = sizeof(info);
    kern_return_t kerr = task_info(mach_task_self(),
                                   TASK_BASIC_INFO,
                                   (task_info_t)&info,
                                   &size);
    if( kerr == KERN_SUCCESS ) {
        NSLog(@"Memory in use (in bytes): %u", info.resident_size);
    } else {
        NSLog(@"Error with task_info(): %s", mach_error_string(kerr));
    }
}

void report_memory_enhanced(void) {
    static unsigned last_resident_size=0;
    static unsigned greatest = 0;
    static unsigned last_greatest = 0;
    
    struct task_basic_info info;
    mach_msg_type_number_t size = sizeof(info);
    kern_return_t kerr = task_info(mach_task_self(),
                                   TASK_BASIC_INFO,
                                   (task_info_t)&info,
                                   &size);
    if( kerr == KERN_SUCCESS ) {
        int diff = (int)info.resident_size - (int)last_resident_size;
        unsigned latest = info.resident_size;
        if( latest > greatest   )   greatest = latest;  // track greatest mem usage
        int greatest_diff = greatest - last_greatest;
        int latest_greatest_diff = latest - greatest;
        NSLog(@"Mem: %10u (%10d) : %10d :   greatest: %10u (%d)", info.resident_size, diff,
              latest_greatest_diff,
              greatest, greatest_diff  );
    } else {
        NSLog(@"Error with task_info(): %s", mach_error_string(kerr));
    }
    last_resident_size = info.resident_size;
    last_greatest = greatest;
}

@end
