//
//  ViewController.h
//  TestLoaction
//
//  Created by Sayan on 23/05/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RAAppManager.h"

@interface ViewController : UIViewController<RAManagerDelegate>
- (IBAction)getLocation:(id)sender;

@end
