//
//  ViewController.m
//  TestLoaction
//
//  Created by Sayan on 23/05/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (IBAction)getLocation:(id)sender {
    [[RAAppManager defaultManager] getUserLocation];
    [RAAppManager defaultManager].delegate = self;
}

#pragma mark - RAManagerDelegate

- (void) getCurrentLatitude:(NSString *)latitude andLongitude:(NSString *)longitude{
    ((UILabel *)[self.view viewWithTag:101]).text = latitude;
    ((UILabel *)[self.view viewWithTag:102]).text = longitude;
}

- (void) locationError:(NSString *)errorMsg{
    ((UILabel *)[self.view viewWithTag:101]).text = @"";
    ((UILabel *)[self.view viewWithTag:102]).text = @"";
    [[[[UIAlertView alloc] initWithTitle:@"Lcoation Error" message:errorMsg delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] autorelease] show];
}

@end
