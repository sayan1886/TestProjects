//
//  RAAppManager.h
//  RangleAdmin
//
//  Created by Sayan on 25/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <CoreLocation/CoreLocation.h>
#import "UserCurrentLocation.h"

@class BusyIndicatorView;

@protocol RAManagerDelegate <NSObject>

@optional

- (void) userDidLoginSuccessfully;
- (void) userDidEncounterWithAnError:(NSString *)errorDetails;
- (void) userDidLogoutSuccessfully:(NSString *)logoutMsg;
- (void) adminLoggedIn;
- (void) adminLoggedOut:(NSString *)msg;
- (void) userDidGetClubLocations:(NSDictionary *)clubLocations;
- (void) clubLocationsUpdated:(NSString *)updationMsg;

- (void) getCurrentLatitude:(NSString *)latitude andLongitude:(NSString *)longitude;
- (void) locationError:(NSString *)errorMsg;

@end


enum web_actions{
    LOGIN_ACTION = 0,
    LOGOUT_ACTION,
    FETCH_CLUBLIST_ACTION,
    UPDATE_CLUB_LOCATION_ACTION,
} ;

typedef enum web_actions WEB_ACTIONS;

@interface RAAppManager : NSObject <CurrentLocationDelegate>{
    BusyIndicatorView *loadingView;
    NSString *addminid;
    NSString *passkey;
    NSMutableArray *hotSpotList;
    //CLLocationManager *locationManager;
    //CLLocation *currentLocation;
    WEB_ACTIONS action;
    
    id<RAManagerDelegate> delegate;
}

@property (strong,nonatomic) NSMutableArray *hotSpotList;
@property (strong,nonatomic)  NSString *addminid;
@property (strong,nonatomic)  NSString *passkey;
@property (assign,nonatomic) WEB_ACTIONS action;
@property (weak,nonatomic) id<RAManagerDelegate> delegate;

//@property (nonatomic, retain) CLLocation *currentLocation;

+ (RAAppManager *) defaultManager;
- (void) userWillLoggedIn:(NSArray *)userDetails;
- (void) userWillLogOut;
- (void) fetchClubList;
- (void) checkForLoginStatus;
- (void) getClubLocation:(NSString *)clubid;
- (void) updateClubLocations:(NSDictionary *)locations forClub:(NSString *)clubid;

//location methods
- (void) getUserLocation;
//-(void) start;
//-(void) stop;
//-(BOOL) locationKnown;

@end
