//
//  TestWebViewViewController.m
//  TestWebView
//
//  Created by Sayan Chatterjee on 27/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "TestWebViewViewController.h"

@implementation TestWebViewViewController

@synthesize webView;

/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/



// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	[super viewDidLoad];
	NSString *filePath = [[NSBundle mainBundle] bundlePath];
	webView.scalesPageToFit = NO;
    
    // set the name of the html file to be the name of the animal chosen on the picker
    // with ".html" appended to it; also need to dynamically remove spaces from the
    // name because the animal might have spaces in it (like "Black Bear")
	NSMutableString *htmlName = [NSMutableString stringWithString:@"BlackBear"];
	[htmlName appendString:@".html"];
	
	NSInteger htmlNameLength = [htmlName length];
	[htmlName replaceOccurrencesOfString:@" " withString:@"" options:NSCaseInsensitiveSearch range:NSMakeRange(0, htmlNameLength)];
	NSURL *baseURL = [NSURL fileURLWithPath:filePath isDirectory:YES];
	NSString *htmlPath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent: htmlName /*@"home.html"*/];
    
	NSMutableString *htmlContent =[[NSMutableString alloc]init];
	NSError *error;
	htmlContent =[NSString stringWithContentsOfFile:htmlPath encoding:NSUTF8StringEncoding error:&error];
	//[htmlContent retain];
	if(error){
		NSLog(@"error: %@",[error description]);
	}
	//NSString* htmlFilePath = [[NSBundle mainBundle] pathForResource:htmlName ofType:nil];
	//NSLog(@"html file path: %@",htmlFilePath);
	//NSString *htmlFileContent = [NSString stringWithContentsOfFile:htmlFilePath encoding:NSUTF8StringEncoding error:NULL];
	[webView loadHTMLString:htmlContent baseURL: baseURL];
}



/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}

@end
