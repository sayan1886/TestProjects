//
//  TestWebViewAppDelegate.h
//  TestWebView
//
//  Created by Sayan Chatterjee on 27/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class TestWebViewViewController;

@interface TestWebViewAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    TestWebViewViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet TestWebViewViewController *viewController;

@end

