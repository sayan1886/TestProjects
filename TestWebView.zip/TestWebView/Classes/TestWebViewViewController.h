//
//  TestWebViewViewController.h
//  TestWebView
//
//  Created by Sayan Chatterjee on 27/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TestWebViewViewController : UIViewController {

	IBOutlet UIWebView *webView;
}

@property (nonatomic,retain) UIWebView *webView;
@end

